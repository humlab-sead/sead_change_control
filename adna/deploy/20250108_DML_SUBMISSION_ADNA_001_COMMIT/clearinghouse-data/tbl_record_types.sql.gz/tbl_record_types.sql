1	DNA	Any type of DNA analysis (e.g. ancient humans or sedimentary)	2025-01-30 14:31:26.355331+00	1	1	-1	\N	C	2025-01-30 14:31:26.950118+00	22
