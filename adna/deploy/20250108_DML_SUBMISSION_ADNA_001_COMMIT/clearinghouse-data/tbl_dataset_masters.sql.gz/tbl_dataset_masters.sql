1	-2	\N	SciLifelab Ancient DNA	\N	https://www.scilifelab.se/units/ancient-dna/	2025-01-30 14:31:26.355331+00	7eac557c-2d39-4322-97fb-03dd48a04fe5	1	1	-1	\N	C	2025-01-30 14:31:26.950118+00	12
