3	\N	19	Molecular sex	category	\N	Molecular sex	1	1	-3	\N	C	2025-01-30 14:31:26.950118+00	17
5	\N	19	Damage treatment	category	\N	Type of damage treatment	1	1	-5	\N	C	2025-01-30 14:31:26.950118+00	16
6	\N	19	SNP capture	category	\N	Type of SNP capture.	1	1	-6	\N	C	2025-01-30 14:31:26.950118+00	15
8	\N	19	Library preparation	category	\N	Type of sequence library preparation	1	1	-8	\N	C	2025-01-30 14:31:26.950118+00	14
