1	test_reader	Test Reader	$2y$10$/u3RCeK8Q.2s75UsZmvQ4.4TOxvLNKH8EoH4k6NYYtkAMavjP.dry	roger.mahler@umu.se	f	1	0	f	2013-10-08
2	test_normal	Test Normal	$2y$10$/u3RCeK8Q.2s75UsZmvQ4.4TOxvLNKH8EoH4k6NYYtkAMavjP.dry	roger.mahler@umu.se	f	2	0	f	2013-10-08
3	test_admin	Test Administrator	$2y$10$/u3RCeK8Q.2s75UsZmvQ4.4TOxvLNKH8EoH4k6NYYtkAMavjP.dry	roger.mahler@umu.se	t	3	0	f	2013-10-08
4	test_provider	Test Provider	$2y$10$/u3RCeK8Q.2s75UsZmvQ4.4TOxvLNKH8EoH4k6NYYtkAMavjP.dry	roger.mahler@umu.se	t	3	3	f	2013-10-08
5	phil_admin	Phil Buckland	$2y$10$/u3RCeK8Q.2s75UsZmvQ4.4TOxvLNKH8EoH4k6NYYtkAMavjP.dry	phil.buckland@umu.se	t	3	3	f	2013-10-08
6	mattias_admin	Mattias Sjölander	$2y$10$/u3RCeK8Q.2s75UsZmvQ4.4TOxvLNKH8EoH4k6NYYtkAMavjP.dry	mattias.sjolander@umu.se	t	3	3	f	2013-10-08
