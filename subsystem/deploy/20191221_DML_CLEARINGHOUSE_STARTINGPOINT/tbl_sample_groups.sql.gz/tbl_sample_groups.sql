12	-31	17	10	61362 Bostadshus	\N	\N	2	1	-12	\N	C	2019-12-20 22:14:09.31687+00	5782
13	-11	17	10	61372 Bostadshus	\N	\N	2	1	-13	\N	C	2019-12-20 22:14:09.31687+00	5781
14	-39	17	10	61384 Bostadshus	\N	\N	2	1	-14	\N	C	2019-12-20 22:14:09.31687+00	5780
15	-37	17	10	61388 Bostadshus	\N	\N	2	1	-15	\N	C	2019-12-20 22:14:09.31687+00	5779
16	-18	17	10	61395 Bostadshus	\N	\N	2	1	-16	\N	C	2019-12-20 22:14:09.31687+00	5778
17	-25	17	10	61467 Bostadshus	\N	\N	2	1	-17	\N	C	2019-12-20 22:14:09.31687+00	5777
19	-27	17	10	61491 Bostadshus	\N	\N	2	1	-19	\N	C	2019-12-20 22:14:09.31687+00	5775
20	-8	17	10	61510 Bostadshus	\N	\N	2	1	-20	\N	C	2019-12-20 22:14:09.31687+00	5774
21	-21	17	10	61511 Bod	\N	\N	2	1	-21	\N	C	2019-12-20 22:14:09.31687+00	5773
22	-20	17	10	64197 Bod	\N	\N	2	1	-22	\N	C	2019-12-20 22:14:09.31687+00	5772
23	-52	17	10	75001 Bod	\N	\N	2	1	-23	\N	C	2019-12-20 22:14:09.31687+00	5771
24	-4	17	10	75011 Bod	\N	\N	2	1	-24	\N	C	2019-12-20 22:14:09.31687+00	5770
25	-3	17	10	75021 Bod	\N	\N	2	1	-25	\N	C	2019-12-20 22:14:09.31687+00	5769
26	-36	17	10	75040 Bostadshus	\N	\N	2	1	-26	\N	C	2019-12-20 22:14:09.31687+00	5768
27	-1	17	10	75049 Bostadshus/Verkstad	\N	\N	2	1	-27	\N	C	2019-12-20 22:14:09.31687+00	5767
28	-5	17	10	75059 Bod	\N	\N	2	1	-28	\N	C	2019-12-20 22:14:09.31687+00	5766
29	-23	17	10	75082 Kyrka	\N	\N	2	1	-29	\N	C	2019-12-20 22:14:09.31687+00	5765
30	-15	17	10	75109 Kyrka	\N	\N	2	1	-30	\N	C	2019-12-20 22:14:09.31687+00	5764
31	-43	17	10	75128 Bostadshus	\N	\N	2	1	-31	\N	C	2019-12-20 22:14:09.31687+00	5763
32	-29	17	10	75150 Ekonomibyggnad	\N	\N	2	1	-32	\N	C	2019-12-20 22:14:09.31687+00	5762
33	-24	17	10	75154 Bostadshus	\N	\N	2	1	-33	\N	C	2019-12-20 22:14:09.31687+00	5761
34	-44	17	10	75164 Bostadshus	\N	\N	2	1	-34	\N	C	2019-12-20 22:14:09.31687+00	5760
35	-29	17	10	75176 Bostadshus	\N	\N	2	1	-35	\N	C	2019-12-20 22:14:09.31687+00	5759
36	-9	17	10	75190 Bostadshus	\N	\N	2	1	-36	\N	C	2019-12-20 22:14:09.31687+00	5758
37	-53	17	10	75304 Dendro	\N	\N	2	1	-37	\N	C	2019-12-20 22:14:09.31687+00	5757
38	-47	17	10	75308 Bostadshus	\N	\N	2	1	-38	\N	C	2019-12-20 22:14:09.31687+00	5756
39	-47	17	10	75315 Bod	\N	\N	2	1	-39	\N	C	2019-12-20 22:14:09.31687+00	5755
40	-13	17	10	75330 Kyrka	\N	\N	2	1	-40	\N	C	2019-12-20 22:14:09.31687+00	5754
41	-48	17	10	75353 Bostadshus	\N	\N	2	1	-41	\N	C	2019-12-20 22:14:09.31687+00	5753
42	-22	17	10	75359 Bostadshus	\N	\N	2	1	-42	\N	C	2019-12-20 22:14:09.31687+00	5752
43	-28	17	10	75360 Bostadshus	\N	\N	2	1	-43	\N	C	2019-12-20 22:14:09.31687+00	5751
44	-28	17	10	75362 Bostadshus	\N	\N	2	1	-44	\N	C	2019-12-20 22:14:09.31687+00	5750
45	-49	17	10	75375 Bostadshus	\N	\N	2	1	-45	\N	C	2019-12-20 22:14:09.31687+00	5749
46	-54	17	10	75377 Kyrka	\N	\N	2	1	-46	\N	C	2019-12-20 22:14:09.31687+00	5748
47	-2	17	10	75384 Bod	\N	\N	2	1	-47	\N	C	2019-12-20 22:14:09.31687+00	5747
48	-2	17	10	75387 Uthus	\N	\N	2	1	-48	\N	C	2019-12-20 22:14:09.31687+00	5746
49	-2	17	10	75390 Bostadshus	\N	\N	2	1	-49	\N	C	2019-12-20 22:14:09.31687+00	5745
50	-12	17	10	75393 Bostadshus	\N	\N	2	1	-50	\N	C	2019-12-20 22:14:09.31687+00	5744
51	-12	17	10	75421 Bostadshus	\N	\N	2	1	-51	\N	C	2019-12-20 22:14:09.31687+00	5743
52	-50	17	10	75434 Bostadshus	\N	\N	2	1	-52	\N	C	2019-12-20 22:14:09.31687+00	5742
53	-19	17	10	75438 Bostadshus	\N	\N	2	1	-53	\N	C	2019-12-20 22:14:09.31687+00	5741
54	-29	17	10	75441 Bostadshus	\N	\N	2	1	-54	\N	C	2019-12-20 22:14:09.31687+00	5740
55	-14	17	10	75442 Bostadshus	\N	\N	2	1	-55	\N	C	2019-12-20 22:14:09.31687+00	5739
56	-51	17	10	75466 Bostadshus	\N	\N	2	1	-56	\N	C	2019-12-20 22:14:09.31687+00	5738
57	-34	17	10	75493 Ekonomibyggnad	\N	\N	2	1	-57	\N	C	2019-12-20 22:14:09.31687+00	5737
58	-34	17	10	75625 Ekonomibyggnad	\N	\N	2	1	-58	\N	C	2019-12-20 22:14:09.31687+00	5736
59	-34	17	10	75627 Ekonomibyggnad	\N	\N	2	1	-59	\N	C	2019-12-20 22:14:09.31687+00	5735
60	-34	17	10	75628 Ekonomibyggnad	\N	\N	2	1	-60	\N	C	2019-12-20 22:14:09.31687+00	5734
61	-34	17	10	75629 Ekonomibyggnad	\N	\N	2	1	-61	\N	C	2019-12-20 22:14:09.31687+00	5733
62	-10	17	10	Grankvistgården borgarhus	\N	\N	2	1	-62	\N	C	2019-12-20 22:14:09.31687+00	5732
63	-17	17	10	Källa gamla kyrka	\N	\N	2	1	-63	\N	C	2019-12-20 22:14:09.31687+00	5731
64	-45	17	10	R75220 Bostadshus	\N	\N	2	1	-64	\N	C	2019-12-20 22:14:09.31687+00	5730
65	-46	17	10	R75222 Dendro	\N	\N	2	1	-65	\N	C	2019-12-20 22:14:09.31687+00	5729
66	-30	17	10	Skrikebo gård huvudbyggnad	\N	\N	2	1	-66	\N	C	2019-12-20 22:14:09.31687+00	5728
67	-32	17	10	Uranäsboden	\N	\N	2	1	-67	\N	C	2019-12-20 22:14:09.31687+00	5727
68	-33	17	10	Wahlbomska huset	\N	\N	2	1	-68	\N	C	2019-12-20 22:14:09.31687+00	5726
69	-34	17	10	Viggesbo säteri bränneriet	\N	\N	2	1	-69	\N	C	2019-12-20 22:14:09.31687+00	5725
70	-34	17	10	Viggesbo säteri huvudbyggnad	\N	\N	2	1	-70	\N	C	2019-12-20 22:14:09.31687+00	5724
71	-34	17	10	Viggesbo säteri rättarbostad	\N	\N	2	1	-71	\N	C	2019-12-20 22:14:09.31687+00	5723
11	-7	18	10	61056 syll	\N	\N	3	1	-11	\N	C	2019-12-20 22:14:19.067462+00	5952
12	-7	18	10	61057 stock, grundläggning	\N	\N	3	1	-12	\N	C	2019-12-20 22:14:19.067462+00	5951
13	-7	18	10	61058 Jönköping 50:1	\N	\N	3	1	-13	\N	C	2019-12-20 22:14:19.067462+00	5950
14	-7	18	10	61059 tröskelstock	\N	\N	3	1	-14	\N	C	2019-12-20 22:14:19.067462+00	5949
15	-7	18	10	61060 dragare	\N	\N	3	1	-15	\N	C	2019-12-20 22:14:19.067462+00	5948
16	-7	18	10	61061 Rustbädd	\N	\N	3	1	-16	\N	C	2019-12-20 22:14:19.067462+00	5947
17	-7	18	10	61062 dragare	\N	\N	3	1	-17	\N	C	2019-12-20 22:14:19.067462+00	5946
18	-7	18	10	61063 stock, grundläggning	\N	\N	3	1	-18	\N	C	2019-12-20 22:14:19.067462+00	5945
19	-7	18	10	61065 grundläggningskista	\N	\N	3	1	-19	\N	C	2019-12-20 22:14:19.067462+00	5944
20	-7	18	10	61066 syll	\N	\N	3	1	-20	\N	C	2019-12-20 22:14:19.067462+00	5943
21	-7	18	10	61067 Rustbädd	\N	\N	3	1	-21	\N	C	2019-12-20 22:14:19.067462+00	5942
22	-7	18	10	61070 träkista 200415	\N	\N	3	1	-22	\N	C	2019-12-20 22:14:19.067462+00	5941
23	-7	18	10	61071 syll eller grundläggning	\N	\N	3	1	-23	\N	C	2019-12-20 22:14:19.067462+00	5940
24	-7	18	10	61073 plank	\N	\N	3	1	-24	\N	C	2019-12-20 22:14:19.067462+00	5939
25	-7	18	10	61074 träkista 200415	\N	\N	3	1	-25	\N	C	2019-12-20 22:14:19.067462+00	5938
26	-7	18	10	61075 stock	\N	\N	3	1	-26	\N	C	2019-12-20 22:14:19.067462+00	5937
27	-7	18	10	61076 stock, grundläggning	\N	\N	3	1	-27	\N	C	2019-12-20 22:14:19.067462+00	5936
28	-7	18	10	61079 syll	\N	\N	3	1	-28	\N	C	2019-12-20 22:14:19.067462+00	5935
29	-7	18	10	61080 stock, grundläggning	\N	\N	3	1	-29	\N	C	2019-12-20 22:14:19.067462+00	5934
30	-7	18	10	61081 Jönköping 50:1	\N	\N	3	1	-30	\N	C	2019-12-20 22:14:19.067462+00	5933
31	-7	18	10	61082 Jönköping 50:1	\N	\N	3	1	-31	\N	C	2019-12-20 22:14:19.067462+00	5932
32	-7	18	10	61083 grundläggningskista	\N	\N	3	1	-32	\N	C	2019-12-20 22:14:19.067462+00	5931
33	-12	18	10	61094 Pålspärr	\N	\N	3	1	-33	\N	C	2019-12-20 22:14:19.067462+00	5930
34	-7	18	10	61131 Timmerkista	\N	\N	3	1	-34	\N	C	2019-12-20 22:14:19.067462+00	5929
35	-7	18	10	61132 Träsyll	\N	\N	3	1	-35	\N	C	2019-12-20 22:14:19.067462+00	5928
36	-7	18	10	61133 Timmerkista	\N	\N	3	1	-36	\N	C	2019-12-20 22:14:19.067462+00	5927
37	-7	18	10	61135 Timmerkista	\N	\N	3	1	-37	\N	C	2019-12-20 22:14:19.067462+00	5926
38	-7	18	10	61138 Rustbädd	\N	\N	3	1	-38	\N	C	2019-12-20 22:14:19.067462+00	5925
39	-7	18	10	61140 Rustbädd	\N	\N	3	1	-39	\N	C	2019-12-20 22:14:19.067462+00	5924
40	-7	18	10	61142 Pålning	\N	\N	3	1	-40	\N	C	2019-12-20 22:14:19.067462+00	5923
41	-7	18	10	61145 Pålning	\N	\N	3	1	-41	\N	C	2019-12-20 22:14:19.067462+00	5922
42	-7	18	10	61148 Golvregel	\N	\N	3	1	-42	\N	C	2019-12-20 22:14:19.067462+00	5921
43	-7	18	10	61149 Trävägg	\N	\N	3	1	-43	\N	C	2019-12-20 22:14:19.067462+00	5920
44	-7	18	10	61152 Träsyll	\N	\N	3	1	-44	\N	C	2019-12-20 22:14:19.067462+00	5919
45	-7	18	10	61155 Jönköping 50:1	\N	\N	3	1	-45	\N	C	2019-12-20 22:14:19.067462+00	5918
46	-7	18	10	61156 Stensyll	\N	\N	3	1	-46	\N	C	2019-12-20 22:14:19.067462+00	5917
47	-7	18	10	61159 Jönköping 50:1	\N	\N	3	1	-47	\N	C	2019-12-20 22:14:19.067462+00	5916
48	-7	18	10	61160 Rustbädd	\N	\N	3	1	-48	\N	C	2019-12-20 22:14:19.067462+00	5915
49	-7	18	10	61161 Träsyll	\N	\N	3	1	-49	\N	C	2019-12-20 22:14:19.067462+00	5914
50	-7	18	10	61168 Rustbädd	\N	\N	3	1	-50	\N	C	2019-12-20 22:14:19.067462+00	5913
51	-7	18	10	61171 Pålning	\N	\N	3	1	-51	\N	C	2019-12-20 22:14:19.067462+00	5912
52	-7	18	10	61174 Brygga	\N	\N	3	1	-52	\N	C	2019-12-20 22:14:19.067462+00	5911
53	-7	18	10	61177 Kajfront	\N	\N	3	1	-53	\N	C	2019-12-20 22:14:19.067462+00	5910
54	-7	18	10	61186 Trävägg	\N	\N	3	1	-54	\N	C	2019-12-20 22:14:19.067462+00	5909
55	-7	18	10	61187 Trägolv	\N	\N	3	1	-55	\N	C	2019-12-20 22:14:19.067462+00	5908
56	-7	18	10	61189 Jönköping 50:1	\N	\N	3	1	-56	\N	C	2019-12-20 22:14:19.067462+00	5907
57	-7	18	10	61190 Träsyll	\N	\N	3	1	-57	\N	C	2019-12-20 22:14:19.067462+00	5906
58	-7	18	10	61191 Rustbädd	\N	\N	3	1	-58	\N	C	2019-12-20 22:14:19.067462+00	5905
59	-7	18	10	61194 Träläggning	\N	\N	3	1	-59	\N	C	2019-12-20 22:14:19.067462+00	5904
60	-7	18	10	61196 Rustbädd	\N	\N	3	1	-60	\N	C	2019-12-20 22:14:19.067462+00	5903
61	-7	18	10	61197 Fundament	\N	\N	3	1	-61	\N	C	2019-12-20 22:14:19.067462+00	5902
62	-7	18	10	61198 Trägolv	\N	\N	3	1	-62	\N	C	2019-12-20 22:14:19.067462+00	5901
63	-7	18	10	61199 Trägolv	\N	\N	3	1	-63	\N	C	2019-12-20 22:14:19.067462+00	5900
64	-7	18	10	61200 Brygga	\N	\N	3	1	-64	\N	C	2019-12-20 22:14:19.067462+00	5899
65	-7	18	10	61202 Pålning	\N	\N	3	1	-65	\N	C	2019-12-20 22:14:19.067462+00	5898
66	-7	18	10	61204 Rustbädd	\N	\N	3	1	-66	\N	C	2019-12-20 22:14:19.067462+00	5897
67	-7	18	10	61205 Golvregel	\N	\N	3	1	-67	\N	C	2019-12-20 22:14:19.067462+00	5896
68	-7	18	10	61206 Rustbädd	\N	\N	3	1	-68	\N	C	2019-12-20 22:14:19.067462+00	5895
69	-7	18	10	61208 Regelstock	\N	\N	3	1	-69	\N	C	2019-12-20 22:14:19.067462+00	5894
70	-7	18	10	61210 Rustbädd	\N	\N	3	1	-70	\N	C	2019-12-20 22:14:19.067462+00	5893
71	-7	18	10	61211 Träläggning	\N	\N	3	1	-71	\N	C	2019-12-20 22:14:19.067462+00	5892
72	-7	18	10	61213 Träläggning	\N	\N	3	1	-72	\N	C	2019-12-20 22:14:19.067462+00	5891
73	-7	18	10	61214 Träläggning	\N	\N	3	1	-73	\N	C	2019-12-20 22:14:19.067462+00	5890
74	-7	18	10	61218 Träsyll	\N	\N	3	1	-74	\N	C	2019-12-20 22:14:19.067462+00	5889
75	-7	18	10	61220 Träsyll	\N	\N	3	1	-75	\N	C	2019-12-20 22:14:19.067462+00	5888
76	-7	18	10	61222 Regelstock	\N	\N	3	1	-76	\N	C	2019-12-20 22:14:19.067462+00	5887
77	-7	18	10	61224 Timmerkista	\N	\N	3	1	-77	\N	C	2019-12-20 22:14:19.067462+00	5886
78	-7	18	10	61226 Rustbädd	\N	\N	3	1	-78	\N	C	2019-12-20 22:14:19.067462+00	5885
79	-7	18	10	61232 Stolpe	\N	\N	3	1	-79	\N	C	2019-12-20 22:14:19.067462+00	5884
80	-7	18	10	61233 Timmerkista	\N	\N	3	1	-80	\N	C	2019-12-20 22:14:19.067462+00	5883
81	-7	18	10	61236 Jönköping 50:1	\N	\N	3	1	-81	\N	C	2019-12-20 22:14:19.067462+00	5882
82	-7	18	10	61239 Timmerkista	\N	\N	3	1	-82	\N	C	2019-12-20 22:14:19.067462+00	5881
83	-7	18	10	61243 Timmerkista	\N	\N	3	1	-83	\N	C	2019-12-20 22:14:19.067462+00	5880
84	-7	18	10	61247 Timmerkista	\N	\N	3	1	-84	\N	C	2019-12-20 22:14:19.067462+00	5879
85	-7	18	10	61254 Träsyll	\N	\N	3	1	-85	\N	C	2019-12-20 22:14:19.067462+00	5878
86	-7	18	10	61256 Rustbädd	\N	\N	3	1	-86	\N	C	2019-12-20 22:14:19.067462+00	5877
87	-7	18	10	61257 Stör	\N	\N	3	1	-87	\N	C	2019-12-20 22:14:19.067462+00	5876
88	-7	18	10	61259 Timmerkista	\N	\N	3	1	-88	\N	C	2019-12-20 22:14:19.067462+00	5875
89	-7	18	10	61261 Jönköping 50:1	\N	\N	3	1	-89	\N	C	2019-12-20 22:14:19.067462+00	5874
90	-7	18	10	61262 Timmerkista	\N	\N	3	1	-90	\N	C	2019-12-20 22:14:19.067462+00	5873
91	-7	18	10	61264 Jönköping 50:1	\N	\N	3	1	-91	\N	C	2019-12-20 22:14:19.067462+00	5872
92	-7	18	10	61266 Jönköping 50:1	\N	\N	3	1	-92	\N	C	2019-12-20 22:14:19.067462+00	5871
93	-7	18	10	61268 Jönköping 50:1	\N	\N	3	1	-93	\N	C	2019-12-20 22:14:19.067462+00	5870
94	-7	18	10	61270 Timmerkista	\N	\N	3	1	-94	\N	C	2019-12-20 22:14:19.067462+00	5869
95	-7	18	10	61274 Rustbädd	\N	\N	3	1	-95	\N	C	2019-12-20 22:14:19.067462+00	5868
96	-7	18	10	61276 Träsyll	\N	\N	3	1	-96	\N	C	2019-12-20 22:14:19.067462+00	5867
97	-7	18	10	61277 Fundament	\N	\N	3	1	-97	\N	C	2019-12-20 22:14:19.067462+00	5866
98	-7	18	10	61280 Timmerkista	\N	\N	3	1	-98	\N	C	2019-12-20 22:14:19.067462+00	5865
99	-7	18	10	61284 Stör	\N	\N	3	1	-99	\N	C	2019-12-20 22:14:19.067462+00	5864
100	-7	18	10	61285 Jönköping 50:1	\N	\N	3	1	-100	\N	C	2019-12-20 22:14:19.067462+00	5863
101	-7	18	10	61286 Jönköping 50:1	\N	\N	3	1	-101	\N	C	2019-12-20 22:14:19.067462+00	5862
102	-7	18	10	61287 Timmerkista	\N	\N	3	1	-102	\N	C	2019-12-20 22:14:19.067462+00	5861
103	-7	18	10	61295 Stolpe	\N	\N	3	1	-103	\N	C	2019-12-20 22:14:19.067462+00	5860
104	-7	18	10	61303 Timmerkista	\N	\N	3	1	-104	\N	C	2019-12-20 22:14:19.067462+00	5859
105	-7	18	10	61309 Fundament	\N	\N	3	1	-105	\N	C	2019-12-20 22:14:19.067462+00	5858
107	-7	18	10	61320 Hägnad	\N	\N	3	1	-107	\N	C	2019-12-20 22:14:19.067462+00	5856
108	-7	18	10	61321 Hägnad	\N	\N	3	1	-108	\N	C	2019-12-20 22:14:19.067462+00	5855
109	-7	18	10	61322 Träsyll	\N	\N	3	1	-109	\N	C	2019-12-20 22:14:19.067462+00	5854
110	-7	18	10	61323 Jönköping 50:1	\N	\N	3	1	-110	\N	C	2019-12-20 22:14:19.067462+00	5853
111	-7	18	10	61324 Träsyll	\N	\N	3	1	-111	\N	C	2019-12-20 22:14:19.067462+00	5852
112	-7	18	10	61325 Stolpe	\N	\N	3	1	-112	\N	C	2019-12-20 22:14:19.067462+00	5851
113	-7	18	10	61328 kista	\N	\N	3	1	-113	\N	C	2019-12-20 22:14:19.067462+00	5850
114	-4	18	10	61352 slaggdeponi	\N	\N	3	1	-114	\N	C	2019-12-20 22:14:19.067462+00	5849
115	-8	18	10	61356 Kalmar 93:1	\N	\N	3	1	-115	\N	C	2019-12-20 22:14:19.067462+00	5848
116	-7	18	10	61366 kista	\N	\N	3	1	-116	\N	C	2019-12-20 22:14:19.067462+00	5847
117	-7	18	10	61370 bottenstock; tröskelstock	\N	\N	3	1	-117	\N	C	2019-12-20 22:14:19.067462+00	5846
118	-8	18	10	61394 stolpe	\N	\N	3	1	-118	\N	C	2019-12-20 22:14:19.067462+00	5845
119	-8	18	10	61405 kista	\N	\N	3	1	-119	\N	C	2019-12-20 22:14:19.067462+00	5844
120	-8	18	10	61408 pålverk	\N	\N	3	1	-120	\N	C	2019-12-20 22:14:19.067462+00	5843
121	-13	18	10	61409 förvaringsgrop	\N	\N	3	1	-121	\N	C	2019-12-20 22:14:19.067462+00	5842
122	-13	18	10	61411 uppsamlingsgrop	\N	\N	3	1	-122	\N	C	2019-12-20 22:14:19.067462+00	5841
123	-13	18	10	61412 pipstock	\N	\N	3	1	-123	\N	C	2019-12-20 22:14:19.067462+00	5840
124	-13	18	10	61413 tjärtratt	\N	\N	3	1	-124	\N	C	2019-12-20 22:14:19.067462+00	5839
125	-13	18	10	61415 förvaringsgrop	\N	\N	3	1	-125	\N	C	2019-12-20 22:14:19.067462+00	5838
126	-13	18	10	61419 pipstock	\N	\N	3	1	-126	\N	C	2019-12-20 22:14:19.067462+00	5837
127	-13	18	10	61421 uppsamlingsgrop	\N	\N	3	1	-127	\N	C	2019-12-20 22:14:19.067462+00	5836
128	-13	18	10	61422 förvaringsgrop	\N	\N	3	1	-128	\N	C	2019-12-20 22:14:19.067462+00	5835
129	-3	18	10	61432 rost	\N	\N	3	1	-129	\N	C	2019-12-20 22:14:19.067462+00	5834
130	-3	18	10	61433 rost	\N	\N	3	1	-130	\N	C	2019-12-20 22:14:19.067462+00	5833
131	-3	18	10	61435 rost	\N	\N	3	1	-131	\N	C	2019-12-20 22:14:19.067462+00	5832
132	-3	18	10	61436 rost	\N	\N	3	1	-132	\N	C	2019-12-20 22:14:19.067462+00	5831
133	-3	18	10	61437 ränna	\N	\N	3	1	-133	\N	C	2019-12-20 22:14:19.067462+00	5830
134	-3	18	10	61438 hästvandring	\N	\N	3	1	-134	\N	C	2019-12-20 22:14:19.067462+00	5829
135	-3	18	10	61439 plattform	\N	\N	3	1	-135	\N	C	2019-12-20 22:14:19.067462+00	5828
136	-3	18	10	61440 ränna	\N	\N	3	1	-136	\N	C	2019-12-20 22:14:19.067462+00	5827
137	-3	18	10	61444 rost	\N	\N	3	1	-137	\N	C	2019-12-20 22:14:19.067462+00	5826
138	-3	18	10	61446 timmerbröte	\N	\N	3	1	-138	\N	C	2019-12-20 22:14:19.067462+00	5825
139	-8	18	10	61450 pålverk	\N	\N	3	1	-139	\N	C	2019-12-20 22:14:19.067462+00	5824
140	-8	18	10	61451 pålverk	\N	\N	3	1	-140	\N	C	2019-12-20 22:14:19.067462+00	5823
141	-8	18	10	61452 pålverk	\N	\N	3	1	-141	\N	C	2019-12-20 22:14:19.067462+00	5822
142	-8	18	10	61457 pålverk	\N	\N	3	1	-142	\N	C	2019-12-20 22:14:19.067462+00	5821
143	-7	18	10	61459 hägnad	\N	\N	3	1	-143	\N	C	2019-12-20 22:14:19.067462+00	5820
144	-7	18	10	61460 rustbädd	\N	\N	3	1	-144	\N	C	2019-12-20 22:14:19.067462+00	5819
145	-7	18	10	61462 vret	\N	\N	3	1	-145	\N	C	2019-12-20 22:14:19.067462+00	5818
146	-7	18	10	61463 hägnad	\N	\N	3	1	-146	\N	C	2019-12-20 22:14:19.067462+00	5817
147	-7	18	10	61464 rustbädd	\N	\N	3	1	-147	\N	C	2019-12-20 22:14:19.067462+00	5816
148	-7	18	10	61465 syll	\N	\N	3	1	-148	\N	C	2019-12-20 22:14:19.067462+00	5815
149	-6	18	10	61486 Jönköping 137:1	\N	\N	3	1	-149	\N	C	2019-12-20 22:14:19.067462+00	5814
150	-17	18	10	75069 pålbro	\N	\N	3	1	-150	\N	C	2019-12-20 22:14:19.067462+00	5813
151	-2	18	10	75073 strandskoning	\N	\N	3	1	-151	\N	C	2019-12-20 22:14:19.067462+00	5812
152	-2	18	10	75078 kavelbro	\N	\N	3	1	-152	\N	C	2019-12-20 22:14:19.067462+00	5811
153	-10	18	10	75081 befästningsanläggning	\N	\N	3	1	-153	\N	C	2019-12-20 22:14:19.067462+00	5810
154	-15	18	10	75107 skans	\N	\N	3	1	-154	\N	C	2019-12-20 22:14:19.067462+00	5809
155	-2	18	10	75139 Gamleby 450:1	\N	\N	3	1	-155	\N	C	2019-12-20 22:14:19.067462+00	5808
156	-14	18	10	75210 bro	\N	\N	3	1	-156	\N	C	2019-12-20 22:14:19.067462+00	5807
157	-8	18	10	75216 pålverk	\N	\N	3	1	-157	\N	C	2019-12-20 22:14:19.067462+00	5806
158	-8	18	10	75218 avspärrning	\N	\N	3	1	-158	\N	C	2019-12-20 22:14:19.067462+00	5805
159	-8	18	10	75220 brygga	\N	\N	3	1	-159	\N	C	2019-12-20 22:14:19.067462+00	5804
160	-8	18	10	75302 bro	\N	\N	3	1	-160	\N	C	2019-12-20 22:14:19.067462+00	5803
161	-9	18	10	75303 begränsning till ett kulturlager	\N	\N	3	1	-161	\N	C	2019-12-20 22:14:19.067462+00	5802
162	-2	18	10	75340 träanläggning	\N	\N	3	1	-162	\N	C	2019-12-20 22:14:19.067462+00	5801
163	-11	18	10	75343 bryggkonstruktion	\N	\N	3	1	-163	\N	C	2019-12-20 22:14:19.067462+00	5800
164	-1	18	10	75351 Träkar	\N	\N	3	1	-164	\N	C	2019-12-20 22:14:19.067462+00	5799
165	-8	18	10	75370 kajanläggning	\N	\N	3	1	-165	\N	C	2019-12-20 22:14:19.067462+00	5798
166	-8	18	10	75372 kajanläggning	\N	\N	3	1	-166	\N	C	2019-12-20 22:14:19.067462+00	5797
167	-18	18	10	75381 väganläggning	\N	\N	3	1	-167	\N	C	2019-12-20 22:14:19.067462+00	5796
168	-16	18	10	75437 bro	\N	\N	3	1	-168	\N	C	2019-12-20 22:14:19.067462+00	5795
169	-5	18	10	75458 kavelbro	\N	\N	3	1	-169	\N	C	2019-12-20 22:14:19.067462+00	5794
944	-47	\N	-2	YA1	Sample group consisting of one specific shard of ceramic.	\N	4	1	-944	\N	C	2019-12-20 22:14:28.053842+00	5963
943	-47	\N	-2	YA4	Sample group consisting of one specific shard of ceramic.	\N	4	1	-943	\N	C	2019-12-20 22:14:28.053842+00	5964
942	-47	\N	-2	YA5	Sample group consisting of one specific shard of ceramic.	\N	4	1	-942	\N	C	2019-12-20 22:14:28.053842+00	5965
941	-47	\N	-2	YA2	Sample group consisting of one specific shard of ceramic.	\N	4	1	-941	\N	C	2019-12-20 22:14:28.053842+00	5966
940	-47	\N	-2	YA3	Sample group consisting of one specific shard of ceramic.	\N	4	1	-940	\N	C	2019-12-20 22:14:28.053842+00	5967
939	-47	\N	-2	YJ65	Sample group consisting of one specific shard of ceramic.	\N	4	1	-939	\N	C	2019-12-20 22:14:28.053842+00	5968
938	-47	\N	-2	YJ64	Sample group consisting of one specific shard of ceramic.	\N	4	1	-938	\N	C	2019-12-20 22:14:28.053842+00	5969
937	-47	\N	-2	YJ63	Sample group consisting of one specific shard of ceramic.	\N	4	1	-937	\N	C	2019-12-20 22:14:28.053842+00	5970
936	-47	\N	-2	YJ62	Sample group consisting of one specific shard of ceramic.	\N	4	1	-936	\N	C	2019-12-20 22:14:28.053842+00	5971
935	-47	\N	-2	YJ61	Sample group consisting of one specific shard of ceramic.	\N	4	1	-935	\N	C	2019-12-20 22:14:28.053842+00	5972
934	-43	\N	-2	TOS194	Sample group consisting of one specific shard of ceramic.	\N	4	1	-934	\N	C	2019-12-20 22:14:28.053842+00	5973
933	-43	\N	-2	TOS193	Sample group consisting of one specific shard of ceramic.	\N	4	1	-933	\N	C	2019-12-20 22:14:28.053842+00	5974
932	-43	\N	-2	TOS192	Sample group consisting of one specific shard of ceramic.	\N	4	1	-932	\N	C	2019-12-20 22:14:28.053842+00	5975
931	-43	\N	-2	TOS191	Sample group consisting of one specific shard of ceramic.	\N	4	1	-931	\N	C	2019-12-20 22:14:28.053842+00	5976
930	-43	\N	-2	TOS190	Sample group consisting of one specific shard of ceramic.	\N	4	1	-930	\N	C	2019-12-20 22:14:28.053842+00	5977
929	-43	\N	-2	TOS189	Sample group consisting of one specific shard of ceramic.	\N	4	1	-929	\N	C	2019-12-20 22:14:28.053842+00	5978
928	-43	\N	-2	TOS188	Sample group consisting of one specific shard of ceramic.	\N	4	1	-928	\N	C	2019-12-20 22:14:28.053842+00	5979
927	-43	\N	-2	TOS187	Sample group consisting of one specific shard of ceramic.	\N	4	1	-927	\N	C	2019-12-20 22:14:28.053842+00	5980
926	-43	\N	-2	TOS186	Sample group consisting of one specific shard of ceramic.	\N	4	1	-926	\N	C	2019-12-20 22:14:28.053842+00	5981
925	-43	\N	-2	TOS184	Sample group consisting of one specific shard of ceramic.	\N	4	1	-925	\N	C	2019-12-20 22:14:28.053842+00	5982
924	-43	\N	-2	TOS183	Sample group consisting of one specific shard of ceramic.	\N	4	1	-924	\N	C	2019-12-20 22:14:28.053842+00	5983
923	-43	\N	-2	TOS182	Sample group consisting of one specific shard of ceramic.	\N	4	1	-923	\N	C	2019-12-20 22:14:28.053842+00	5984
922	-43	\N	-2	TOS181	Sample group consisting of one specific shard of ceramic.	\N	4	1	-922	\N	C	2019-12-20 22:14:28.053842+00	5985
921	-36	\N	-2	T8J60	Sample group consisting of one specific shard of ceramic.	\N	4	1	-921	\N	C	2019-12-20 22:14:28.053842+00	5986
920	-36	\N	-2	T8J59	Sample group consisting of one specific shard of ceramic.	\N	4	1	-920	\N	C	2019-12-20 22:14:28.053842+00	5987
919	-36	\N	-2	T8J58	Sample group consisting of one specific shard of ceramic.	\N	4	1	-919	\N	C	2019-12-20 22:14:28.053842+00	5988
918	-36	\N	-2	T8J53	Sample group consisting of one specific shard of ceramic.	\N	4	1	-918	\N	C	2019-12-20 22:14:28.053842+00	5989
917	-36	\N	-2	T8J51	Sample group consisting of one specific shard of ceramic.	\N	4	1	-917	\N	C	2019-12-20 22:14:28.053842+00	5990
916	-36	\N	-2	T8J50	Sample group consisting of one specific shard of ceramic.	\N	4	1	-916	\N	C	2019-12-20 22:14:28.053842+00	5991
915	-36	\N	-2	T8J49	Sample group consisting of one specific shard of ceramic.	\N	4	1	-915	\N	C	2019-12-20 22:14:28.053842+00	5992
914	-36	\N	-2	T8J48	Sample group consisting of one specific shard of ceramic.	\N	4	1	-914	\N	C	2019-12-20 22:14:28.053842+00	5993
913	-36	\N	-2	T8J47	Sample group consisting of one specific shard of ceramic.	\N	4	1	-913	\N	C	2019-12-20 22:14:28.053842+00	5994
912	-36	\N	-2	T8J46	Sample group consisting of one specific shard of ceramic.	\N	4	1	-912	\N	C	2019-12-20 22:14:28.053842+00	5995
911	-36	\N	-2	T8J45	Sample group consisting of one specific shard of ceramic.	\N	4	1	-911	\N	C	2019-12-20 22:14:28.053842+00	5996
910	-36	\N	-2	T8J44	Sample group consisting of one specific shard of ceramic.	\N	4	1	-910	\N	C	2019-12-20 22:14:28.053842+00	5997
909	-36	\N	-2	T8J43	Sample group consisting of one specific shard of ceramic.	\N	4	1	-909	\N	C	2019-12-20 22:14:28.053842+00	5998
908	-36	\N	-2	T8J42	Sample group consisting of one specific shard of ceramic.	\N	4	1	-908	\N	C	2019-12-20 22:14:28.053842+00	5999
907	-36	\N	-2	T8J26	Sample group consisting of one specific shard of ceramic.	\N	4	1	-907	\N	C	2019-12-20 22:14:28.053842+00	6000
906	-35	\N	-2	T7J41	Sample group consisting of one specific shard of ceramic.	\N	4	1	-906	\N	C	2019-12-20 22:14:28.053842+00	6001
905	-35	\N	-2	T7J40	Sample group consisting of one specific shard of ceramic.	\N	4	1	-905	\N	C	2019-12-20 22:14:28.053842+00	6002
904	-35	\N	-2	T7J39	Sample group consisting of one specific shard of ceramic.	\N	4	1	-904	\N	C	2019-12-20 22:14:28.053842+00	6003
903	-35	\N	-2	T7J38	Sample group consisting of one specific shard of ceramic.	\N	4	1	-903	\N	C	2019-12-20 22:14:28.053842+00	6004
902	-35	\N	-2	T7J37	Sample group consisting of one specific shard of ceramic.	\N	4	1	-902	\N	C	2019-12-20 22:14:28.053842+00	6005
901	-34	\N	-2	T6-52_1_8_741_F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-901	\N	C	2019-12-20 22:14:28.053842+00	6006
900	-34	\N	-2	T6-52_1_8_483_F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-900	\N	C	2019-12-20 22:14:28.053842+00	6007
899	-33	\N	-2	KT3-5_F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-899	\N	C	2019-12-20 22:14:28.053842+00	6008
898	-33	\N	-2	KT3_17d_8b_F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-898	\N	C	2019-12-20 22:14:28.053842+00	6009
897	-33	\N	-2	KT3-J36	Sample group consisting of one specific shard of ceramic.	\N	4	1	-897	\N	C	2019-12-20 22:14:28.053842+00	6010
896	-33	\N	-2	KT3-J35	Sample group consisting of one specific shard of ceramic.	\N	4	1	-896	\N	C	2019-12-20 22:14:28.053842+00	6011
895	-33	\N	-2	KT3-J34	Sample group consisting of one specific shard of ceramic.	\N	4	1	-895	\N	C	2019-12-20 22:14:28.053842+00	6012
894	-33	\N	-2	KT3-J33	Sample group consisting of one specific shard of ceramic.	\N	4	1	-894	\N	C	2019-12-20 22:14:28.053842+00	6013
893	-33	\N	-2	KT3-J32	Sample group consisting of one specific shard of ceramic.	\N	4	1	-893	\N	C	2019-12-20 22:14:28.053842+00	6014
892	-24	\N	-2	NIS236	Sample group consisting of one specific shard of ceramic.	\N	4	1	-892	\N	C	2019-12-20 22:14:28.053842+00	6015
891	-24	\N	-2	NIS235	Sample group consisting of one specific shard of ceramic.	\N	4	1	-891	\N	C	2019-12-20 22:14:28.053842+00	6016
890	-18	\N	-2	M1J8	Sample group consisting of one specific shard of ceramic.	\N	4	1	-890	\N	C	2019-12-20 22:14:28.053842+00	6017
889	-10	\N	-2	KAK-22	Sample group consisting of one specific shard of ceramic.	\N	4	1	-889	\N	C	2019-12-20 22:14:28.053842+00	6018
888	-10	\N	-2	KAK-21	Sample group consisting of one specific shard of ceramic.	\N	4	1	-888	\N	C	2019-12-20 22:14:28.053842+00	6019
887	-10	\N	-2	KAK-20	Sample group consisting of one specific shard of ceramic.	\N	4	1	-887	\N	C	2019-12-20 22:14:28.053842+00	6020
886	-10	\N	-2	KAK-19	Sample group consisting of one specific shard of ceramic.	\N	4	1	-886	\N	C	2019-12-20 22:14:28.053842+00	6021
885	-10	\N	-2	KAK-18	Sample group consisting of one specific shard of ceramic.	\N	4	1	-885	\N	C	2019-12-20 22:14:28.053842+00	6022
884	-10	\N	-2	KAK-17	Sample group consisting of one specific shard of ceramic.	\N	4	1	-884	\N	C	2019-12-20 22:14:28.053842+00	6023
883	-10	\N	-2	KAK-16	Sample group consisting of one specific shard of ceramic.	\N	4	1	-883	\N	C	2019-12-20 22:14:28.053842+00	6024
882	-10	\N	-2	KAK-15	Sample group consisting of one specific shard of ceramic.	\N	4	1	-882	\N	C	2019-12-20 22:14:28.053842+00	6025
881	-10	\N	-2	KAK-14	Sample group consisting of one specific shard of ceramic.	\N	4	1	-881	\N	C	2019-12-20 22:14:28.053842+00	6026
880	-10	\N	-2	KAK-13	Sample group consisting of one specific shard of ceramic.	\N	4	1	-880	\N	C	2019-12-20 22:14:28.053842+00	6027
879	-10	\N	-2	KAK-12	Sample group consisting of one specific shard of ceramic.	\N	4	1	-879	\N	C	2019-12-20 22:14:28.053842+00	6028
878	-10	\N	-2	KAK-11	Sample group consisting of one specific shard of ceramic.	\N	4	1	-878	\N	C	2019-12-20 22:14:28.053842+00	6029
877	-10	\N	-2	KAK-10	Sample group consisting of one specific shard of ceramic.	\N	4	1	-877	\N	C	2019-12-20 22:14:28.053842+00	6030
876	-10	\N	-2	KAK-09	Sample group consisting of one specific shard of ceramic.	\N	4	1	-876	\N	C	2019-12-20 22:14:28.053842+00	6031
875	-10	\N	-2	KAK-08	Sample group consisting of one specific shard of ceramic.	\N	4	1	-875	\N	C	2019-12-20 22:14:28.053842+00	6032
874	-10	\N	-2	KAK-07	Sample group consisting of one specific shard of ceramic.	\N	4	1	-874	\N	C	2019-12-20 22:14:28.053842+00	6033
873	-10	\N	-2	KAK-06	Sample group consisting of one specific shard of ceramic.	\N	4	1	-873	\N	C	2019-12-20 22:14:28.053842+00	6034
872	-10	\N	-2	KAK-05	Sample group consisting of one specific shard of ceramic.	\N	4	1	-872	\N	C	2019-12-20 22:14:28.053842+00	6035
871	-10	\N	-2	KAK-04	Sample group consisting of one specific shard of ceramic.	\N	4	1	-871	\N	C	2019-12-20 22:14:28.053842+00	6036
870	-10	\N	-2	KAK-03	Sample group consisting of one specific shard of ceramic.	\N	4	1	-870	\N	C	2019-12-20 22:14:28.053842+00	6037
869	-10	\N	-2	KAK-02	Sample group consisting of one specific shard of ceramic.	\N	4	1	-869	\N	C	2019-12-20 22:14:28.053842+00	6038
868	-10	\N	-2	KAK-01	Sample group consisting of one specific shard of ceramic.	\N	4	1	-868	\N	C	2019-12-20 22:14:28.053842+00	6039
867	-1	\N	-2	AKJ31	Sample group consisting of one specific shard of ceramic.	\N	4	1	-867	\N	C	2019-12-20 22:14:28.053842+00	6040
866	-1	\N	-2	AKJ30	Sample group consisting of one specific shard of ceramic.	\N	4	1	-866	\N	C	2019-12-20 22:14:28.053842+00	6041
865	-1	\N	-2	AKJ29	Sample group consisting of one specific shard of ceramic.	\N	4	1	-865	\N	C	2019-12-20 22:14:28.053842+00	6042
864	-1	\N	-2	AKJ28	Sample group consisting of one specific shard of ceramic.	\N	4	1	-864	\N	C	2019-12-20 22:14:28.053842+00	6043
863	-1	\N	-2	AKJ27	Sample group consisting of one specific shard of ceramic.	\N	4	1	-863	\N	C	2019-12-20 22:14:28.053842+00	6044
862	-27	\N	-2	SA179	Sample group consisting of one specific shard of ceramic.	\N	4	1	-862	\N	C	2019-12-20 22:14:28.053842+00	6045
861	-40	\N	-2	T418S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-861	\N	C	2019-12-20 22:14:28.053842+00	6046
860	-40	\N	-2	T419S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-860	\N	C	2019-12-20 22:14:28.053842+00	6047
859	-40	\N	-2	T308Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-859	\N	C	2019-12-20 22:14:28.053842+00	6048
858	-40	\N	-2	T307Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-858	\N	C	2019-12-20 22:14:28.053842+00	6049
857	-40	\N	-2	T306Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-857	\N	C	2019-12-20 22:14:28.053842+00	6050
856	-40	\N	-2	T305Fe	Sample group consisting of one specific shard of ceramic.	\N	4	1	-856	\N	C	2019-12-20 22:14:28.053842+00	6051
855	-40	\N	-2	T304Fe	Sample group consisting of one specific shard of ceramic.	\N	4	1	-855	\N	C	2019-12-20 22:14:28.053842+00	6052
854	-40	\N	-2	T404S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-854	\N	C	2019-12-20 22:14:28.053842+00	6053
853	-40	\N	-2	T403S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-853	\N	C	2019-12-20 22:14:28.053842+00	6054
852	-40	\N	-2	T402S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-852	\N	C	2019-12-20 22:14:28.053842+00	6055
851	-40	\N	-2	T401S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-851	\N	C	2019-12-20 22:14:28.053842+00	6056
850	-40	\N	-2	T303Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-850	\N	C	2019-12-20 22:14:28.053842+00	6057
849	-40	\N	-2	T302Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-849	\N	C	2019-12-20 22:14:28.053842+00	6058
848	-40	\N	-2	T301Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-848	\N	C	2019-12-20 22:14:28.053842+00	6059
847	-40	\N	-2	T300Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-847	\N	C	2019-12-20 22:14:28.053842+00	6060
846	-40	\N	-2	T416S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-846	\N	C	2019-12-20 22:14:28.053842+00	6061
845	-40	\N	-2	T415S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-845	\N	C	2019-12-20 22:14:28.053842+00	6062
844	-40	\N	-2	T415Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-844	\N	C	2019-12-20 22:14:28.053842+00	6063
843	-40	\N	-2	T414S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-843	\N	C	2019-12-20 22:14:28.053842+00	6064
842	-40	\N	-2	T413S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-842	\N	C	2019-12-20 22:14:28.053842+00	6065
841	-40	\N	-2	T297Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-841	\N	C	2019-12-20 22:14:28.053842+00	6066
840	-40	\N	-2	T296Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-840	\N	C	2019-12-20 22:14:28.053842+00	6067
839	-40	\N	-2	T295Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-839	\N	C	2019-12-20 22:14:28.053842+00	6068
838	-40	\N	-2	T294Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-838	\N	C	2019-12-20 22:14:28.053842+00	6069
837	-40	\N	-2	T293Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-837	\N	C	2019-12-20 22:14:28.053842+00	6070
836	-40	\N	-2	T412S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-836	\N	C	2019-12-20 22:14:28.053842+00	6071
835	-40	\N	-2	T411S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-835	\N	C	2019-12-20 22:14:28.053842+00	6072
834	-40	\N	-2	T411Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-834	\N	C	2019-12-20 22:14:28.053842+00	6073
833	-40	\N	-2	T410S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-833	\N	C	2019-12-20 22:14:28.053842+00	6074
832	-40	\N	-2	T409S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-832	\N	C	2019-12-20 22:14:28.053842+00	6075
831	-40	\N	-2	T408S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-831	\N	C	2019-12-20 22:14:28.053842+00	6076
830	-40	\N	-2	T408Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-830	\N	C	2019-12-20 22:14:28.053842+00	6077
829	-40	\N	-2	T407S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-829	\N	C	2019-12-20 22:14:28.053842+00	6078
828	-40	\N	-2	T407Fe	Sample group consisting of one specific shard of ceramic.	\N	4	1	-828	\N	C	2019-12-20 22:14:28.053842+00	6079
827	-40	\N	-2	T407Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-827	\N	C	2019-12-20 22:14:28.053842+00	6080
826	-40	\N	-2	T406S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-826	\N	C	2019-12-20 22:14:28.053842+00	6081
825	-40	\N	-2	T406Fe	Sample group consisting of one specific shard of ceramic.	\N	4	1	-825	\N	C	2019-12-20 22:14:28.053842+00	6082
824	-40	\N	-2	T405S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-824	\N	C	2019-12-20 22:14:28.053842+00	6083
823	-40	\N	-2	T405Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-823	\N	C	2019-12-20 22:14:28.053842+00	6084
822	-40	\N	-2	T299Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-822	\N	C	2019-12-20 22:14:28.053842+00	6085
821	-40	\N	-2	T298Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-821	\N	C	2019-12-20 22:14:28.053842+00	6086
820	-40	\N	-2	T292Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-820	\N	C	2019-12-20 22:14:28.053842+00	6087
819	-40	\N	-2	T291Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-819	\N	C	2019-12-20 22:14:28.053842+00	6088
818	-40	\N	-2	T287Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-818	\N	C	2019-12-20 22:14:28.053842+00	6089
817	-40	\N	-2	T286Fe	Sample group consisting of one specific shard of ceramic.	\N	4	1	-817	\N	C	2019-12-20 22:14:28.053842+00	6090
816	-40	\N	-2	T285Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-816	\N	C	2019-12-20 22:14:28.053842+00	6091
815	-40	\N	-2	T284Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-815	\N	C	2019-12-20 22:14:28.053842+00	6092
814	-40	\N	-2	T283Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-814	\N	C	2019-12-20 22:14:28.053842+00	6093
813	-40	\N	-2	T282Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-813	\N	C	2019-12-20 22:14:28.053842+00	6094
812	-40	\N	-2	T442S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-812	\N	C	2019-12-20 22:14:28.053842+00	6095
811	-40	\N	-2	T441S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-811	\N	C	2019-12-20 22:14:28.053842+00	6096
810	-40	\N	-2	T440S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-810	\N	C	2019-12-20 22:14:28.053842+00	6097
809	-40	\N	-2	T439S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-809	\N	C	2019-12-20 22:14:28.053842+00	6098
808	-40	\N	-2	T438S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-808	\N	C	2019-12-20 22:14:28.053842+00	6099
807	-40	\N	-2	T437S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-807	\N	C	2019-12-20 22:14:28.053842+00	6100
806	-40	\N	-2	T436S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-806	\N	C	2019-12-20 22:14:28.053842+00	6101
805	-40	\N	-2	T435S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-805	\N	C	2019-12-20 22:14:28.053842+00	6102
804	-40	\N	-2	T434S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-804	\N	C	2019-12-20 22:14:28.053842+00	6103
803	-40	\N	-2	T433S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-803	\N	C	2019-12-20 22:14:28.053842+00	6104
802	-40	\N	-2	T432S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-802	\N	C	2019-12-20 22:14:28.053842+00	6105
801	-40	\N	-2	T431S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-801	\N	C	2019-12-20 22:14:28.053842+00	6106
800	-40	\N	-2	T430S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-800	\N	C	2019-12-20 22:14:28.053842+00	6107
799	-40	\N	-2	T429S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-799	\N	C	2019-12-20 22:14:28.053842+00	6108
798	-40	\N	-2	T428S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-798	\N	C	2019-12-20 22:14:28.053842+00	6109
797	-40	\N	-2	T427S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-797	\N	C	2019-12-20 22:14:28.053842+00	6110
796	-40	\N	-2	T426S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-796	\N	C	2019-12-20 22:14:28.053842+00	6111
795	-40	\N	-2	T425S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-795	\N	C	2019-12-20 22:14:28.053842+00	6112
794	-40	\N	-2	T424S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-794	\N	C	2019-12-20 22:14:28.053842+00	6113
793	-40	\N	-2	T423S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-793	\N	C	2019-12-20 22:14:28.053842+00	6114
792	-40	\N	-2	T422S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-792	\N	C	2019-12-20 22:14:28.053842+00	6115
791	-40	\N	-2	T309Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-791	\N	C	2019-12-20 22:14:28.053842+00	6116
790	-40	\N	-2	T290Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-790	\N	C	2019-12-20 22:14:28.053842+00	6117
789	-40	\N	-2	T289Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-789	\N	C	2019-12-20 22:14:28.053842+00	6118
788	-40	\N	-2	T281S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-788	\N	C	2019-12-20 22:14:28.053842+00	6119
787	-40	\N	-2	T281Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-787	\N	C	2019-12-20 22:14:28.053842+00	6120
786	-40	\N	-2	T280S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-786	\N	C	2019-12-20 22:14:28.053842+00	6121
785	-40	\N	-2	T280Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-785	\N	C	2019-12-20 22:14:28.053842+00	6122
784	-40	\N	-2	T279S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-784	\N	C	2019-12-20 22:14:28.053842+00	6123
783	-40	\N	-2	T279Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-783	\N	C	2019-12-20 22:14:28.053842+00	6124
782	-40	\N	-2	T276Fe	Sample group consisting of one specific shard of ceramic.	\N	4	1	-782	\N	C	2019-12-20 22:14:28.053842+00	6125
781	-40	\N	-2	T400S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-781	\N	C	2019-12-20 22:14:28.053842+00	6126
780	-40	\N	-2	T399S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-780	\N	C	2019-12-20 22:14:28.053842+00	6127
779	-40	\N	-2	T448S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-779	\N	C	2019-12-20 22:14:28.053842+00	6128
778	-40	\N	-2	T447S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-778	\N	C	2019-12-20 22:14:28.053842+00	6129
777	-40	\N	-2	T446S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-777	\N	C	2019-12-20 22:14:28.053842+00	6130
776	-40	\N	-2	T275Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-776	\N	C	2019-12-20 22:14:28.053842+00	6131
775	-40	\N	-2	T274Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-775	\N	C	2019-12-20 22:14:28.053842+00	6132
774	-40	\N	-2	T273Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-774	\N	C	2019-12-20 22:14:28.053842+00	6133
773	-40	\N	-2	T272Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-773	\N	C	2019-12-20 22:14:28.053842+00	6134
772	-40	\N	-2	T271Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-772	\N	C	2019-12-20 22:14:28.053842+00	6135
771	-40	\N	-2	T270Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-771	\N	C	2019-12-20 22:14:28.053842+00	6136
770	-40	\N	-2	T269Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-770	\N	C	2019-12-20 22:14:28.053842+00	6137
769	-40	\N	-2	T268Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-769	\N	C	2019-12-20 22:14:28.053842+00	6138
768	-40	\N	-2	T398S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-768	\N	C	2019-12-20 22:14:28.053842+00	6139
767	-40	\N	-2	T397S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-767	\N	C	2019-12-20 22:14:28.053842+00	6140
766	-40	\N	-2	T445Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-766	\N	C	2019-12-20 22:14:28.053842+00	6141
765	-40	\N	-2	T444Fe	Sample group consisting of one specific shard of ceramic.	\N	4	1	-765	\N	C	2019-12-20 22:14:28.053842+00	6142
764	-40	\N	-2	T443Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-764	\N	C	2019-12-20 22:14:28.053842+00	6143
763	-40	\N	-2	T421S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-763	\N	C	2019-12-20 22:14:28.053842+00	6144
762	-40	\N	-2	T420S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-762	\N	C	2019-12-20 22:14:28.053842+00	6145
761	-40	\N	-2	T396S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-761	\N	C	2019-12-20 22:14:28.053842+00	6146
760	-40	\N	-2	T396Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-760	\N	C	2019-12-20 22:14:28.053842+00	6147
759	-40	\N	-2	T395S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-759	\N	C	2019-12-20 22:14:28.053842+00	6148
758	-40	\N	-2	T395Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-758	\N	C	2019-12-20 22:14:28.053842+00	6149
757	-40	\N	-2	T393S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-757	\N	C	2019-12-20 22:14:28.053842+00	6150
756	-40	\N	-2	T392S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-756	\N	C	2019-12-20 22:14:28.053842+00	6151
755	-40	\N	-2	T391S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-755	\N	C	2019-12-20 22:14:28.053842+00	6152
754	-40	\N	-2	T391Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-754	\N	C	2019-12-20 22:14:28.053842+00	6153
753	-40	\N	-2	T160Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-753	\N	C	2019-12-20 22:14:28.053842+00	6154
752	-40	\N	-2	T159Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-752	\N	C	2019-12-20 22:14:28.053842+00	6155
751	-40	\N	-2	T158Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-751	\N	C	2019-12-20 22:14:28.053842+00	6156
750	-40	\N	-2	T157Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-750	\N	C	2019-12-20 22:14:28.053842+00	6157
749	-40	\N	-2	T156Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-749	\N	C	2019-12-20 22:14:28.053842+00	6158
748	-40	\N	-2	T155Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-748	\N	C	2019-12-20 22:14:28.053842+00	6159
747	-40	\N	-2	T154Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-747	\N	C	2019-12-20 22:14:28.053842+00	6160
746	-40	\N	-2	T153Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-746	\N	C	2019-12-20 22:14:28.053842+00	6161
745	-40	\N	-2	T152Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-745	\N	C	2019-12-20 22:14:28.053842+00	6162
744	-40	\N	-2	T151Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-744	\N	C	2019-12-20 22:14:28.053842+00	6163
743	-40	\N	-2	T150Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-743	\N	C	2019-12-20 22:14:28.053842+00	6164
742	-40	\N	-2	T149Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-742	\N	C	2019-12-20 22:14:28.053842+00	6165
741	-40	\N	-2	T148Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-741	\N	C	2019-12-20 22:14:28.053842+00	6166
740	-40	\N	-2	T147Fe	Sample group consisting of one specific shard of ceramic.	\N	4	1	-740	\N	C	2019-12-20 22:14:28.053842+00	6167
739	-40	\N	-2	T146Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-739	\N	C	2019-12-20 22:14:28.053842+00	6168
738	-40	\N	-2	T145Fe	Sample group consisting of one specific shard of ceramic.	\N	4	1	-738	\N	C	2019-12-20 22:14:28.053842+00	6169
737	-40	\N	-2	T144Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-737	\N	C	2019-12-20 22:14:28.053842+00	6170
736	-40	\N	-2	T143Fe	Sample group consisting of one specific shard of ceramic.	\N	4	1	-736	\N	C	2019-12-20 22:14:28.053842+00	6171
735	-40	\N	-2	T142Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-735	\N	C	2019-12-20 22:14:28.053842+00	6172
734	-40	\N	-2	T141Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-734	\N	C	2019-12-20 22:14:28.053842+00	6173
733	-40	\N	-2	T140Fe	Sample group consisting of one specific shard of ceramic.	\N	4	1	-733	\N	C	2019-12-20 22:14:28.053842+00	6174
732	-40	\N	-2	T140Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-732	\N	C	2019-12-20 22:14:28.053842+00	6175
731	-40	\N	-2	T138Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-731	\N	C	2019-12-20 22:14:28.053842+00	6176
730	-40	\N	-2	T136Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-730	\N	C	2019-12-20 22:14:28.053842+00	6177
729	-40	\N	-2	T135Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-729	\N	C	2019-12-20 22:14:28.053842+00	6178
728	-40	\N	-2	T134Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-728	\N	C	2019-12-20 22:14:28.053842+00	6179
727	-40	\N	-2	T133Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-727	\N	C	2019-12-20 22:14:28.053842+00	6180
726	-40	\N	-2	T132Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-726	\N	C	2019-12-20 22:14:28.053842+00	6181
725	-40	\N	-2	T131Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-725	\N	C	2019-12-20 22:14:28.053842+00	6182
724	-40	\N	-2	T130Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-724	\N	C	2019-12-20 22:14:28.053842+00	6183
723	-40	\N	-2	T129Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-723	\N	C	2019-12-20 22:14:28.053842+00	6184
722	-40	\N	-2	T128Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-722	\N	C	2019-12-20 22:14:28.053842+00	6185
721	-40	\N	-2	T127Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-721	\N	C	2019-12-20 22:14:28.053842+00	6186
720	-40	\N	-2	T126Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-720	\N	C	2019-12-20 22:14:28.053842+00	6187
719	-40	\N	-2	T125Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-719	\N	C	2019-12-20 22:14:28.053842+00	6188
718	-40	\N	-2	T124Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-718	\N	C	2019-12-20 22:14:28.053842+00	6189
717	-40	\N	-2	T77Fe	Sample group consisting of one specific shard of ceramic.	\N	4	1	-717	\N	C	2019-12-20 22:14:28.053842+00	6190
716	-40	\N	-2	T77Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-716	\N	C	2019-12-20 22:14:28.053842+00	6191
715	-40	\N	-2	T76Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-715	\N	C	2019-12-20 22:14:28.053842+00	6192
714	-40	\N	-2	T75Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-714	\N	C	2019-12-20 22:14:28.053842+00	6193
713	-40	\N	-2	T74Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-713	\N	C	2019-12-20 22:14:28.053842+00	6194
712	-40	\N	-2	T73Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-712	\N	C	2019-12-20 22:14:28.053842+00	6195
711	-40	\N	-2	T72Fe	Sample group consisting of one specific shard of ceramic.	\N	4	1	-711	\N	C	2019-12-20 22:14:28.053842+00	6196
710	-40	\N	-2	T72Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-710	\N	C	2019-12-20 22:14:28.053842+00	6197
709	-40	\N	-2	T70Fe	Sample group consisting of one specific shard of ceramic.	\N	4	1	-709	\N	C	2019-12-20 22:14:28.053842+00	6198
708	-40	\N	-2	T69Fe	Sample group consisting of one specific shard of ceramic.	\N	4	1	-708	\N	C	2019-12-20 22:14:28.053842+00	6199
707	-40	\N	-2	T69Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-707	\N	C	2019-12-20 22:14:28.053842+00	6200
706	-40	\N	-2	T68Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-706	\N	C	2019-12-20 22:14:28.053842+00	6201
705	-40	\N	-2	T66Fe	Sample group consisting of one specific shard of ceramic.	\N	4	1	-705	\N	C	2019-12-20 22:14:28.053842+00	6202
704	-40	\N	-2	T66Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-704	\N	C	2019-12-20 22:14:28.053842+00	6203
703	-40	\N	-2	T79Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-703	\N	C	2019-12-20 22:14:28.053842+00	6204
702	-40	\N	-2	T78Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-702	\N	C	2019-12-20 22:14:28.053842+00	6205
701	-40	\N	-2	T81S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-701	\N	C	2019-12-20 22:14:28.053842+00	6206
700	-40	\N	-2	T81Fi	Sample group consisting of one specific shard of ceramic.	\N	4	1	-700	\N	C	2019-12-20 22:14:28.053842+00	6207
699	-27	\N	-2	SA449	Sample group consisting of one specific shard of ceramic.	\N	4	1	-699	\N	C	2019-12-20 22:14:28.053842+00	6208
698	-27	\N	-2	SA441	Sample group consisting of one specific shard of ceramic.	\N	4	1	-698	\N	C	2019-12-20 22:14:28.053842+00	6209
697	-27	\N	-2	SA175	Sample group consisting of one specific shard of ceramic.	\N	4	1	-697	\N	C	2019-12-20 22:14:28.053842+00	6210
696	-27	\N	-2	SA174	Sample group consisting of one specific shard of ceramic.	\N	4	1	-696	\N	C	2019-12-20 22:14:28.053842+00	6211
695	-27	\N	-2	SA173	Sample group consisting of one specific shard of ceramic.	\N	4	1	-695	\N	C	2019-12-20 22:14:28.053842+00	6212
694	-27	\N	-2	SA172	Sample group consisting of one specific shard of ceramic.	\N	4	1	-694	\N	C	2019-12-20 22:14:28.053842+00	6213
693	-27	\N	-2	SA171	Sample group consisting of one specific shard of ceramic.	\N	4	1	-693	\N	C	2019-12-20 22:14:28.053842+00	6214
692	-27	\N	-2	SA170	Sample group consisting of one specific shard of ceramic.	\N	4	1	-692	\N	C	2019-12-20 22:14:28.053842+00	6215
691	-27	\N	-2	SA169	Sample group consisting of one specific shard of ceramic.	\N	4	1	-691	\N	C	2019-12-20 22:14:28.053842+00	6216
690	-27	\N	-2	SA168	Sample group consisting of one specific shard of ceramic.	\N	4	1	-690	\N	C	2019-12-20 22:14:28.053842+00	6217
689	-27	\N	-2	SA167	Sample group consisting of one specific shard of ceramic.	\N	4	1	-689	\N	C	2019-12-20 22:14:28.053842+00	6218
688	-27	\N	-2	SA166	Sample group consisting of one specific shard of ceramic.	\N	4	1	-688	\N	C	2019-12-20 22:14:28.053842+00	6219
687	-27	\N	-2	SA165	Sample group consisting of one specific shard of ceramic.	\N	4	1	-687	\N	C	2019-12-20 22:14:28.053842+00	6220
686	-27	\N	-2	SA164	Sample group consisting of one specific shard of ceramic.	\N	4	1	-686	\N	C	2019-12-20 22:14:28.053842+00	6221
685	-27	\N	-2	SA163	Sample group consisting of one specific shard of ceramic.	\N	4	1	-685	\N	C	2019-12-20 22:14:28.053842+00	6222
684	-27	\N	-2	SA162	Sample group consisting of one specific shard of ceramic.	\N	4	1	-684	\N	C	2019-12-20 22:14:28.053842+00	6223
683	-27	\N	-2	SA161	Sample group consisting of one specific shard of ceramic.	\N	4	1	-683	\N	C	2019-12-20 22:14:28.053842+00	6224
682	-27	\N	-2	J178	Sample group consisting of one specific shard of ceramic.	\N	4	1	-682	\N	C	2019-12-20 22:14:28.053842+00	6225
681	-27	\N	-2	J177	Sample group consisting of one specific shard of ceramic.	\N	4	1	-681	\N	C	2019-12-20 22:14:28.053842+00	6226
680	-27	\N	-2	J176	Sample group consisting of one specific shard of ceramic.	\N	4	1	-680	\N	C	2019-12-20 22:14:28.053842+00	6227
679	-27	\N	-2	J172	Sample group consisting of one specific shard of ceramic.	\N	4	1	-679	\N	C	2019-12-20 22:14:28.053842+00	6228
678	-27	\N	-2	J170	Sample group consisting of one specific shard of ceramic.	\N	4	1	-678	\N	C	2019-12-20 22:14:28.053842+00	6229
677	-27	\N	-2	J168	Sample group consisting of one specific shard of ceramic.	\N	4	1	-677	\N	C	2019-12-20 22:14:28.053842+00	6230
676	-4	\N	-2	HGM15F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-676	\N	C	2019-12-20 22:14:28.053842+00	6231
675	-4	\N	-2	HGM14F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-675	\N	C	2019-12-20 22:14:28.053842+00	6232
674	-4	\N	-2	HGM13F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-674	\N	C	2019-12-20 22:14:28.053842+00	6233
673	-4	\N	-2	HGM12F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-673	\N	C	2019-12-20 22:14:28.053842+00	6234
672	-4	\N	-2	HGM11F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-672	\N	C	2019-12-20 22:14:28.053842+00	6235
671	-4	\N	-2	HGM10F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-671	\N	C	2019-12-20 22:14:28.053842+00	6236
670	-4	\N	-2	HGM09F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-670	\N	C	2019-12-20 22:14:28.053842+00	6237
669	-4	\N	-2	HGM08F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-669	\N	C	2019-12-20 22:14:28.053842+00	6238
668	-4	\N	-2	HGM07F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-668	\N	C	2019-12-20 22:14:28.053842+00	6239
667	-4	\N	-2	HGM06F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-667	\N	C	2019-12-20 22:14:28.053842+00	6240
666	-4	\N	-2	HGM05F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-666	\N	C	2019-12-20 22:14:28.053842+00	6241
665	-4	\N	-2	HGM04F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-665	\N	C	2019-12-20 22:14:28.053842+00	6242
664	-4	\N	-2	HGM03F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-664	\N	C	2019-12-20 22:14:28.053842+00	6243
663	-4	\N	-2	HGM02F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-663	\N	C	2019-12-20 22:14:28.053842+00	6244
662	-4	\N	-2	HGM01F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-662	\N	C	2019-12-20 22:14:28.053842+00	6245
661	-4	\N	-2	HGM40	Sample group consisting of one specific shard of ceramic.	\N	4	1	-661	\N	C	2019-12-20 22:14:28.053842+00	6246
660	-4	\N	-2	HGM39	Sample group consisting of one specific shard of ceramic.	\N	4	1	-660	\N	C	2019-12-20 22:14:28.053842+00	6247
659	-4	\N	-2	HGM38	Sample group consisting of one specific shard of ceramic.	\N	4	1	-659	\N	C	2019-12-20 22:14:28.053842+00	6248
658	-4	\N	-2	HGM37	Sample group consisting of one specific shard of ceramic.	\N	4	1	-658	\N	C	2019-12-20 22:14:28.053842+00	6249
657	-4	\N	-2	HGM36	Sample group consisting of one specific shard of ceramic.	\N	4	1	-657	\N	C	2019-12-20 22:14:28.053842+00	6250
656	-4	\N	-2	HGM35	Sample group consisting of one specific shard of ceramic.	\N	4	1	-656	\N	C	2019-12-20 22:14:28.053842+00	6251
655	-4	\N	-2	HGM34	Sample group consisting of one specific shard of ceramic.	\N	4	1	-655	\N	C	2019-12-20 22:14:28.053842+00	6252
654	-4	\N	-2	HGM33	Sample group consisting of one specific shard of ceramic.	\N	4	1	-654	\N	C	2019-12-20 22:14:28.053842+00	6253
653	-4	\N	-2	HGM32	Sample group consisting of one specific shard of ceramic.	\N	4	1	-653	\N	C	2019-12-20 22:14:28.053842+00	6254
652	-4	\N	-2	HGM31	Sample group consisting of one specific shard of ceramic.	\N	4	1	-652	\N	C	2019-12-20 22:14:28.053842+00	6255
651	-4	\N	-2	HGM30	Sample group consisting of one specific shard of ceramic.	\N	4	1	-651	\N	C	2019-12-20 22:14:28.053842+00	6256
650	-4	\N	-2	HGM29	Sample group consisting of one specific shard of ceramic.	\N	4	1	-650	\N	C	2019-12-20 22:14:28.053842+00	6257
649	-4	\N	-2	HGM28	Sample group consisting of one specific shard of ceramic.	\N	4	1	-649	\N	C	2019-12-20 22:14:28.053842+00	6258
648	-4	\N	-2	HGM27	Sample group consisting of one specific shard of ceramic.	\N	4	1	-648	\N	C	2019-12-20 22:14:28.053842+00	6259
647	-4	\N	-2	HGM26	Sample group consisting of one specific shard of ceramic.	\N	4	1	-647	\N	C	2019-12-20 22:14:28.053842+00	6260
646	-4	\N	-2	HGM25	Sample group consisting of one specific shard of ceramic.	\N	4	1	-646	\N	C	2019-12-20 22:14:28.053842+00	6261
645	-4	\N	-2	HGM24	Sample group consisting of one specific shard of ceramic.	\N	4	1	-645	\N	C	2019-12-20 22:14:28.053842+00	6262
644	-4	\N	-2	HGM23	Sample group consisting of one specific shard of ceramic.	\N	4	1	-644	\N	C	2019-12-20 22:14:28.053842+00	6263
643	-4	\N	-2	HGM22	Sample group consisting of one specific shard of ceramic.	\N	4	1	-643	\N	C	2019-12-20 22:14:28.053842+00	6264
642	-4	\N	-2	HGM21	Sample group consisting of one specific shard of ceramic.	\N	4	1	-642	\N	C	2019-12-20 22:14:28.053842+00	6265
641	-4	\N	-2	HGM20	Sample group consisting of one specific shard of ceramic.	\N	4	1	-641	\N	C	2019-12-20 22:14:28.053842+00	6266
640	-4	\N	-2	HGM19	Sample group consisting of one specific shard of ceramic.	\N	4	1	-640	\N	C	2019-12-20 22:14:28.053842+00	6267
639	-4	\N	-2	HGM18	Sample group consisting of one specific shard of ceramic.	\N	4	1	-639	\N	C	2019-12-20 22:14:28.053842+00	6268
638	-4	\N	-2	HGM17	Sample group consisting of one specific shard of ceramic.	\N	4	1	-638	\N	C	2019-12-20 22:14:28.053842+00	6269
637	-4	\N	-2	HGM16	Sample group consisting of one specific shard of ceramic.	\N	4	1	-637	\N	C	2019-12-20 22:14:28.053842+00	6270
636	-4	\N	-2	HGM15	Sample group consisting of one specific shard of ceramic.	\N	4	1	-636	\N	C	2019-12-20 22:14:28.053842+00	6271
635	-4	\N	-2	HGM14	Sample group consisting of one specific shard of ceramic.	\N	4	1	-635	\N	C	2019-12-20 22:14:28.053842+00	6272
634	-4	\N	-2	HGM13	Sample group consisting of one specific shard of ceramic.	\N	4	1	-634	\N	C	2019-12-20 22:14:28.053842+00	6273
633	-4	\N	-2	HGM12	Sample group consisting of one specific shard of ceramic.	\N	4	1	-633	\N	C	2019-12-20 22:14:28.053842+00	6274
632	-4	\N	-2	HGM11	Sample group consisting of one specific shard of ceramic.	\N	4	1	-632	\N	C	2019-12-20 22:14:28.053842+00	6275
631	-4	\N	-2	HGM10	Sample group consisting of one specific shard of ceramic.	\N	4	1	-631	\N	C	2019-12-20 22:14:28.053842+00	6276
630	-4	\N	-2	HGM09	Sample group consisting of one specific shard of ceramic.	\N	4	1	-630	\N	C	2019-12-20 22:14:28.053842+00	6277
629	-4	\N	-2	HGM08	Sample group consisting of one specific shard of ceramic.	\N	4	1	-629	\N	C	2019-12-20 22:14:28.053842+00	6278
628	-4	\N	-2	HGM07	Sample group consisting of one specific shard of ceramic.	\N	4	1	-628	\N	C	2019-12-20 22:14:28.053842+00	6279
627	-4	\N	-2	HGM06	Sample group consisting of one specific shard of ceramic.	\N	4	1	-627	\N	C	2019-12-20 22:14:28.053842+00	6280
626	-4	\N	-2	HGM05	Sample group consisting of one specific shard of ceramic.	\N	4	1	-626	\N	C	2019-12-20 22:14:28.053842+00	6281
625	-4	\N	-2	HGM04	Sample group consisting of one specific shard of ceramic.	\N	4	1	-625	\N	C	2019-12-20 22:14:28.053842+00	6282
624	-4	\N	-2	HGM03	Sample group consisting of one specific shard of ceramic.	\N	4	1	-624	\N	C	2019-12-20 22:14:28.053842+00	6283
623	-4	\N	-2	HGM02	Sample group consisting of one specific shard of ceramic.	\N	4	1	-623	\N	C	2019-12-20 22:14:28.053842+00	6284
622	-4	\N	-2	HGM01	Sample group consisting of one specific shard of ceramic.	\N	4	1	-622	\N	C	2019-12-20 22:14:28.053842+00	6285
621	-4	\N	-2	HGM324F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-621	\N	C	2019-12-20 22:14:28.053842+00	6286
620	-4	\N	-2	HGM011S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-620	\N	C	2019-12-20 22:14:28.053842+00	6287
619	-4	\N	-2	HGM011F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-619	\N	C	2019-12-20 22:14:28.053842+00	6288
618	-4	\N	-2	HGM478F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-618	\N	C	2019-12-20 22:14:28.053842+00	6289
617	-4	\N	-2	HGM142F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-617	\N	C	2019-12-20 22:14:28.053842+00	6290
616	-4	\N	-2	HGM181S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-616	\N	C	2019-12-20 22:14:28.053842+00	6291
615	-4	\N	-2	HGM181F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-615	\N	C	2019-12-20 22:14:28.053842+00	6292
614	-4	\N	-2	HGM150F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-614	\N	C	2019-12-20 22:14:28.053842+00	6293
613	-32	\N	-2	SBZ10F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-613	\N	C	2019-12-20 22:14:28.053842+00	6294
612	-32	\N	-2	SBZ09F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-612	\N	C	2019-12-20 22:14:28.053842+00	6295
611	-32	\N	-2	SBZ14	Sample group consisting of one specific shard of ceramic.	\N	4	1	-611	\N	C	2019-12-20 22:14:28.053842+00	6296
610	-32	\N	-2	SBZ13	Sample group consisting of one specific shard of ceramic.	\N	4	1	-610	\N	C	2019-12-20 22:14:28.053842+00	6297
609	-32	\N	-2	SBZ12	Sample group consisting of one specific shard of ceramic.	\N	4	1	-609	\N	C	2019-12-20 22:14:28.053842+00	6298
608	-32	\N	-2	SBZ11	Sample group consisting of one specific shard of ceramic.	\N	4	1	-608	\N	C	2019-12-20 22:14:28.053842+00	6299
607	-32	\N	-2	SBZ10	Sample group consisting of one specific shard of ceramic.	\N	4	1	-607	\N	C	2019-12-20 22:14:28.053842+00	6300
606	-32	\N	-2	SBZ09	Sample group consisting of one specific shard of ceramic.	\N	4	1	-606	\N	C	2019-12-20 22:14:28.053842+00	6301
605	-32	\N	-2	SBZ08	Sample group consisting of one specific shard of ceramic.	\N	4	1	-605	\N	C	2019-12-20 22:14:28.053842+00	6302
604	-32	\N	-2	SBZ07	Sample group consisting of one specific shard of ceramic.	\N	4	1	-604	\N	C	2019-12-20 22:14:28.053842+00	6303
603	-32	\N	-2	SBZ06	Sample group consisting of one specific shard of ceramic.	\N	4	1	-603	\N	C	2019-12-20 22:14:28.053842+00	6304
602	-32	\N	-2	SBZ05	Sample group consisting of one specific shard of ceramic.	\N	4	1	-602	\N	C	2019-12-20 22:14:28.053842+00	6305
601	-32	\N	-2	SBZ04	Sample group consisting of one specific shard of ceramic.	\N	4	1	-601	\N	C	2019-12-20 22:14:28.053842+00	6306
600	-32	\N	-2	SBZ03	Sample group consisting of one specific shard of ceramic.	\N	4	1	-600	\N	C	2019-12-20 22:14:28.053842+00	6307
599	-32	\N	-2	SBZ02	Sample group consisting of one specific shard of ceramic.	\N	4	1	-599	\N	C	2019-12-20 22:14:28.053842+00	6308
598	-32	\N	-2	SBZ01	Sample group consisting of one specific shard of ceramic.	\N	4	1	-598	\N	C	2019-12-20 22:14:28.053842+00	6309
597	-44	\N	-2	UEN-258f	Sample group consisting of one specific shard of ceramic.	\N	4	1	-597	\N	C	2019-12-20 22:14:28.053842+00	6310
596	-44	\N	-2	UEN-258d	Sample group consisting of one specific shard of ceramic.	\N	4	1	-596	\N	C	2019-12-20 22:14:28.053842+00	6311
595	-44	\N	-2	UEN-257d	Sample group consisting of one specific shard of ceramic.	\N	4	1	-595	\N	C	2019-12-20 22:14:28.053842+00	6312
594	-44	\N	-2	UEN-267f	Sample group consisting of one specific shard of ceramic.	\N	4	1	-594	\N	C	2019-12-20 22:14:28.053842+00	6313
593	-44	\N	-2	UEN-266f	Sample group consisting of one specific shard of ceramic.	\N	4	1	-593	\N	C	2019-12-20 22:14:28.053842+00	6314
592	-44	\N	-2	UEN-264d	Sample group consisting of one specific shard of ceramic.	\N	4	1	-592	\N	C	2019-12-20 22:14:28.053842+00	6315
591	-44	\N	-2	UEN-263d	Sample group consisting of one specific shard of ceramic.	\N	4	1	-591	\N	C	2019-12-20 22:14:28.053842+00	6316
590	-44	\N	-2	UEN-261d	Sample group consisting of one specific shard of ceramic.	\N	4	1	-590	\N	C	2019-12-20 22:14:28.053842+00	6317
589	-44	\N	-2	UEN-260d	Sample group consisting of one specific shard of ceramic.	\N	4	1	-589	\N	C	2019-12-20 22:14:28.053842+00	6318
588	-44	\N	-2	UEN-12037	Sample group consisting of one specific shard of ceramic.	\N	4	1	-588	\N	C	2019-12-20 22:14:28.053842+00	6319
587	-44	\N	-2	UEN-8548	Sample group consisting of one specific shard of ceramic.	\N	4	1	-587	\N	C	2019-12-20 22:14:28.053842+00	6320
586	-44	\N	-2	UEN-7717	Sample group consisting of one specific shard of ceramic.	\N	4	1	-586	\N	C	2019-12-20 22:14:28.053842+00	6321
585	-44	\N	-2	UEN-6189	Sample group consisting of one specific shard of ceramic.	\N	4	1	-585	\N	C	2019-12-20 22:14:28.053842+00	6322
584	-44	\N	-2	UEN-5658	Sample group consisting of one specific shard of ceramic.	\N	4	1	-584	\N	C	2019-12-20 22:14:28.053842+00	6323
583	-44	\N	-2	UEN-4718	Sample group consisting of one specific shard of ceramic.	\N	4	1	-583	\N	C	2019-12-20 22:14:28.053842+00	6324
582	-44	\N	-2	UEN-4557	Sample group consisting of one specific shard of ceramic.	\N	4	1	-582	\N	C	2019-12-20 22:14:28.053842+00	6325
581	-44	\N	-2	UEN-3702	Sample group consisting of one specific shard of ceramic.	\N	4	1	-581	\N	C	2019-12-20 22:14:28.053842+00	6326
580	-44	\N	-2	UEN-3102	Sample group consisting of one specific shard of ceramic.	\N	4	1	-580	\N	C	2019-12-20 22:14:28.053842+00	6327
579	-44	\N	-2	UEN-3076	Sample group consisting of one specific shard of ceramic.	\N	4	1	-579	\N	C	2019-12-20 22:14:28.053842+00	6328
578	-44	\N	-2	UEN-2970	Sample group consisting of one specific shard of ceramic.	\N	4	1	-578	\N	C	2019-12-20 22:14:28.053842+00	6329
577	-44	\N	-2	UEN-2580	Sample group consisting of one specific shard of ceramic.	\N	4	1	-577	\N	C	2019-12-20 22:14:28.053842+00	6330
576	-44	\N	-2	UEN-2547	Sample group consisting of one specific shard of ceramic.	\N	4	1	-576	\N	C	2019-12-20 22:14:28.053842+00	6331
575	-44	\N	-2	UEN-2542	Sample group consisting of one specific shard of ceramic.	\N	4	1	-575	\N	C	2019-12-20 22:14:28.053842+00	6332
574	-44	\N	-2	UEN-2409	Sample group consisting of one specific shard of ceramic.	\N	4	1	-574	\N	C	2019-12-20 22:14:28.053842+00	6333
573	-44	\N	-2	UEN-1218	Sample group consisting of one specific shard of ceramic.	\N	4	1	-573	\N	C	2019-12-20 22:14:28.053842+00	6334
572	-44	\N	-2	UEN-1183	Sample group consisting of one specific shard of ceramic.	\N	4	1	-572	\N	C	2019-12-20 22:14:28.053842+00	6335
571	-44	\N	-2	UEN-1157	Sample group consisting of one specific shard of ceramic.	\N	4	1	-571	\N	C	2019-12-20 22:14:28.053842+00	6336
570	-44	\N	-2	UEN-800	Sample group consisting of one specific shard of ceramic.	\N	4	1	-570	\N	C	2019-12-20 22:14:28.053842+00	6337
569	-44	\N	-2	UEN-676	Sample group consisting of one specific shard of ceramic.	\N	4	1	-569	\N	C	2019-12-20 22:14:28.053842+00	6338
568	-44	\N	-2	UEN-588	Sample group consisting of one specific shard of ceramic.	\N	4	1	-568	\N	C	2019-12-20 22:14:28.053842+00	6339
567	-44	\N	-2	UEN-487	Sample group consisting of one specific shard of ceramic.	\N	4	1	-567	\N	C	2019-12-20 22:14:28.053842+00	6340
566	-44	\N	-2	UEN-349	Sample group consisting of one specific shard of ceramic.	\N	4	1	-566	\N	C	2019-12-20 22:14:28.053842+00	6341
565	-44	\N	-2	UEN-266	Sample group consisting of one specific shard of ceramic.	\N	4	1	-565	\N	C	2019-12-20 22:14:28.053842+00	6342
564	-44	\N	-2	UEN-95	Sample group consisting of one specific shard of ceramic.	\N	4	1	-564	\N	C	2019-12-20 22:14:28.053842+00	6343
563	-44	\N	-2	UEN-0	Sample group consisting of one specific shard of ceramic.	\N	4	1	-563	\N	C	2019-12-20 22:14:28.053842+00	6344
562	-17	\N	-2	MAE-5x	Sample group consisting of one specific shard of ceramic.	\N	4	1	-562	\N	C	2019-12-20 22:14:28.053842+00	6345
561	-17	\N	-2	MAE-29B	Sample group consisting of one specific shard of ceramic.	\N	4	1	-561	\N	C	2019-12-20 22:14:28.053842+00	6346
560	-17	\N	-2	MAE-21x	Sample group consisting of one specific shard of ceramic.	\N	4	1	-560	\N	C	2019-12-20 22:14:28.053842+00	6347
559	-17	\N	-2	MAE-1347x	Sample group consisting of one specific shard of ceramic.	\N	4	1	-559	\N	C	2019-12-20 22:14:28.053842+00	6348
558	-17	\N	-2	MAE-76060	Sample group consisting of one specific shard of ceramic.	\N	4	1	-558	\N	C	2019-12-20 22:14:28.053842+00	6349
557	-17	\N	-2	MAE-61009	Sample group consisting of one specific shard of ceramic.	\N	4	1	-557	\N	C	2019-12-20 22:14:28.053842+00	6350
556	-17	\N	-2	MAE-60697	Sample group consisting of one specific shard of ceramic.	\N	4	1	-556	\N	C	2019-12-20 22:14:28.053842+00	6351
555	-17	\N	-2	MAE-59537	Sample group consisting of one specific shard of ceramic.	\N	4	1	-555	\N	C	2019-12-20 22:14:28.053842+00	6352
554	-17	\N	-2	MAE-57694	Sample group consisting of one specific shard of ceramic.	\N	4	1	-554	\N	C	2019-12-20 22:14:28.053842+00	6353
553	-17	\N	-2	MAE-56171	Sample group consisting of one specific shard of ceramic.	\N	4	1	-553	\N	C	2019-12-20 22:14:28.053842+00	6354
552	-17	\N	-2	MAE-53602	Sample group consisting of one specific shard of ceramic.	\N	4	1	-552	\N	C	2019-12-20 22:14:28.053842+00	6355
551	-17	\N	-2	MAE-53336	Sample group consisting of one specific shard of ceramic.	\N	4	1	-551	\N	C	2019-12-20 22:14:28.053842+00	6356
550	-17	\N	-2	MAE-51293	Sample group consisting of one specific shard of ceramic.	\N	4	1	-550	\N	C	2019-12-20 22:14:28.053842+00	6357
549	-17	\N	-2	MAE-49378	Sample group consisting of one specific shard of ceramic.	\N	4	1	-549	\N	C	2019-12-20 22:14:28.053842+00	6358
548	-17	\N	-2	MAE-49328	Sample group consisting of one specific shard of ceramic.	\N	4	1	-548	\N	C	2019-12-20 22:14:28.053842+00	6359
547	-17	\N	-2	MAE-45150	Sample group consisting of one specific shard of ceramic.	\N	4	1	-547	\N	C	2019-12-20 22:14:28.053842+00	6360
546	-17	\N	-2	MAE-44027	Sample group consisting of one specific shard of ceramic.	\N	4	1	-546	\N	C	2019-12-20 22:14:28.053842+00	6361
545	-17	\N	-2	MAE-42995	Sample group consisting of one specific shard of ceramic.	\N	4	1	-545	\N	C	2019-12-20 22:14:28.053842+00	6362
544	-17	\N	-2	MAE-41749	Sample group consisting of one specific shard of ceramic.	\N	4	1	-544	\N	C	2019-12-20 22:14:28.053842+00	6363
543	-17	\N	-2	MAE-39126	Sample group consisting of one specific shard of ceramic.	\N	4	1	-543	\N	C	2019-12-20 22:14:28.053842+00	6364
542	-17	\N	-2	MAE-35921	Sample group consisting of one specific shard of ceramic.	\N	4	1	-542	\N	C	2019-12-20 22:14:28.053842+00	6365
541	-17	\N	-2	MAE-35281	Sample group consisting of one specific shard of ceramic.	\N	4	1	-541	\N	C	2019-12-20 22:14:28.053842+00	6366
540	-17	\N	-2	MAE-34645	Sample group consisting of one specific shard of ceramic.	\N	4	1	-540	\N	C	2019-12-20 22:14:28.053842+00	6367
539	-17	\N	-2	MAE-32110	Sample group consisting of one specific shard of ceramic.	\N	4	1	-539	\N	C	2019-12-20 22:14:28.053842+00	6368
538	-17	\N	-2	MAE-28427	Sample group consisting of one specific shard of ceramic.	\N	4	1	-538	\N	C	2019-12-20 22:14:28.053842+00	6369
537	-17	\N	-2	MAE-18039	Sample group consisting of one specific shard of ceramic.	\N	4	1	-537	\N	C	2019-12-20 22:14:28.053842+00	6370
536	-17	\N	-2	MAE-17443	Sample group consisting of one specific shard of ceramic.	\N	4	1	-536	\N	C	2019-12-20 22:14:28.053842+00	6371
535	-17	\N	-2	MAE-17287	Sample group consisting of one specific shard of ceramic.	\N	4	1	-535	\N	C	2019-12-20 22:14:28.053842+00	6372
534	-17	\N	-2	MAE-17109	Sample group consisting of one specific shard of ceramic.	\N	4	1	-534	\N	C	2019-12-20 22:14:28.053842+00	6373
533	-17	\N	-2	MAE-16196	Sample group consisting of one specific shard of ceramic.	\N	4	1	-533	\N	C	2019-12-20 22:14:28.053842+00	6374
532	-17	\N	-2	MAE-15372	Sample group consisting of one specific shard of ceramic.	\N	4	1	-532	\N	C	2019-12-20 22:14:28.053842+00	6375
531	-17	\N	-2	MAE-14763	Sample group consisting of one specific shard of ceramic.	\N	4	1	-531	\N	C	2019-12-20 22:14:28.053842+00	6376
530	-17	\N	-2	MAE-14252	Sample group consisting of one specific shard of ceramic.	\N	4	1	-530	\N	C	2019-12-20 22:14:28.053842+00	6377
529	-17	\N	-2	MAE-13841	Sample group consisting of one specific shard of ceramic.	\N	4	1	-529	\N	C	2019-12-20 22:14:28.053842+00	6378
528	-17	\N	-2	MAE-12088	Sample group consisting of one specific shard of ceramic.	\N	4	1	-528	\N	C	2019-12-20 22:14:28.053842+00	6379
527	-17	\N	-2	MAE-12054	Sample group consisting of one specific shard of ceramic.	\N	4	1	-527	\N	C	2019-12-20 22:14:28.053842+00	6380
526	-17	\N	-2	MAE-11609	Sample group consisting of one specific shard of ceramic.	\N	4	1	-526	\N	C	2019-12-20 22:14:28.053842+00	6381
525	-17	\N	-2	MAE-11458	Sample group consisting of one specific shard of ceramic.	\N	4	1	-525	\N	C	2019-12-20 22:14:28.053842+00	6382
524	-17	\N	-2	MAE-11414	Sample group consisting of one specific shard of ceramic.	\N	4	1	-524	\N	C	2019-12-20 22:14:28.053842+00	6383
523	-17	\N	-2	MAE-9240	Sample group consisting of one specific shard of ceramic.	\N	4	1	-523	\N	C	2019-12-20 22:14:28.053842+00	6384
522	-17	\N	-2	MAE-8955	Sample group consisting of one specific shard of ceramic.	\N	4	1	-522	\N	C	2019-12-20 22:14:28.053842+00	6385
521	-17	\N	-2	MAE-8880	Sample group consisting of one specific shard of ceramic.	\N	4	1	-521	\N	C	2019-12-20 22:14:28.053842+00	6386
520	-17	\N	-2	MAE-8300	Sample group consisting of one specific shard of ceramic.	\N	4	1	-520	\N	C	2019-12-20 22:14:28.053842+00	6387
519	-17	\N	-2	MAE-7780	Sample group consisting of one specific shard of ceramic.	\N	4	1	-519	\N	C	2019-12-20 22:14:28.053842+00	6388
518	-17	\N	-2	MAE-7378	Sample group consisting of one specific shard of ceramic.	\N	4	1	-518	\N	C	2019-12-20 22:14:28.053842+00	6389
517	-17	\N	-2	MAE-7232	Sample group consisting of one specific shard of ceramic.	\N	4	1	-517	\N	C	2019-12-20 22:14:28.053842+00	6390
516	-17	\N	-2	MAE-7169	Sample group consisting of one specific shard of ceramic.	\N	4	1	-516	\N	C	2019-12-20 22:14:28.053842+00	6391
515	-17	\N	-2	MAE-6934	Sample group consisting of one specific shard of ceramic.	\N	4	1	-515	\N	C	2019-12-20 22:14:28.053842+00	6392
514	-17	\N	-2	MAE-6739	Sample group consisting of one specific shard of ceramic.	\N	4	1	-514	\N	C	2019-12-20 22:14:28.053842+00	6393
513	-17	\N	-2	MAE-6462	Sample group consisting of one specific shard of ceramic.	\N	4	1	-513	\N	C	2019-12-20 22:14:28.053842+00	6394
512	-17	\N	-2	MAE-6203	Sample group consisting of one specific shard of ceramic.	\N	4	1	-512	\N	C	2019-12-20 22:14:28.053842+00	6395
511	-17	\N	-2	MAE-5327	Sample group consisting of one specific shard of ceramic.	\N	4	1	-511	\N	C	2019-12-20 22:14:28.053842+00	6396
510	-17	\N	-2	MAE-5097	Sample group consisting of one specific shard of ceramic.	\N	4	1	-510	\N	C	2019-12-20 22:14:28.053842+00	6397
509	-17	\N	-2	MAE-4971	Sample group consisting of one specific shard of ceramic.	\N	4	1	-509	\N	C	2019-12-20 22:14:28.053842+00	6398
508	-17	\N	-2	MAE-4765	Sample group consisting of one specific shard of ceramic.	\N	4	1	-508	\N	C	2019-12-20 22:14:28.053842+00	6399
507	-17	\N	-2	MAE-4710	Sample group consisting of one specific shard of ceramic.	\N	4	1	-507	\N	C	2019-12-20 22:14:28.053842+00	6400
506	-17	\N	-2	MAE-4491	Sample group consisting of one specific shard of ceramic.	\N	4	1	-506	\N	C	2019-12-20 22:14:28.053842+00	6401
505	-17	\N	-2	MAE-44079	Sample group consisting of one specific shard of ceramic.	\N	4	1	-505	\N	C	2019-12-20 22:14:28.053842+00	6402
504	-17	\N	-2	MAE-3942	Sample group consisting of one specific shard of ceramic.	\N	4	1	-504	\N	C	2019-12-20 22:14:28.053842+00	6403
503	-17	\N	-2	MAE-3689	Sample group consisting of one specific shard of ceramic.	\N	4	1	-503	\N	C	2019-12-20 22:14:28.053842+00	6404
502	-17	\N	-2	MAE-3481	Sample group consisting of one specific shard of ceramic.	\N	4	1	-502	\N	C	2019-12-20 22:14:28.053842+00	6405
501	-17	\N	-2	MAE-3470	Sample group consisting of one specific shard of ceramic.	\N	4	1	-501	\N	C	2019-12-20 22:14:28.053842+00	6406
500	-17	\N	-2	MAE-3316	Sample group consisting of one specific shard of ceramic.	\N	4	1	-500	\N	C	2019-12-20 22:14:28.053842+00	6407
499	-17	\N	-2	MAE-3097	Sample group consisting of one specific shard of ceramic.	\N	4	1	-499	\N	C	2019-12-20 22:14:28.053842+00	6408
498	-17	\N	-2	MAE-2915	Sample group consisting of one specific shard of ceramic.	\N	4	1	-498	\N	C	2019-12-20 22:14:28.053842+00	6409
497	-17	\N	-2	MAE-1920	Sample group consisting of one specific shard of ceramic.	\N	4	1	-497	\N	C	2019-12-20 22:14:28.053842+00	6410
496	-17	\N	-2	MAE-1834	Sample group consisting of one specific shard of ceramic.	\N	4	1	-496	\N	C	2019-12-20 22:14:28.053842+00	6411
495	-17	\N	-2	MAE-30	Sample group consisting of one specific shard of ceramic.	\N	4	1	-495	\N	C	2019-12-20 22:14:28.053842+00	6412
494	-17	\N	-2	MAE-29	Sample group consisting of one specific shard of ceramic.	\N	4	1	-494	\N	C	2019-12-20 22:14:28.053842+00	6413
493	-17	\N	-2	MAE-28	Sample group consisting of one specific shard of ceramic.	\N	4	1	-493	\N	C	2019-12-20 22:14:28.053842+00	6414
492	-45	\N	-2	Unoki_C10-S1	Sample group consisting of one specific shard of ceramic.	\N	4	1	-492	\N	C	2019-12-20 22:14:28.053842+00	6415
491	-45	\N	-2	Unoki_B16-S2	Sample group consisting of one specific shard of ceramic.	\N	4	1	-491	\N	C	2019-12-20 22:14:28.053842+00	6416
490	-45	\N	-2	Unoki_B15-S2	Sample group consisting of one specific shard of ceramic.	\N	4	1	-490	\N	C	2019-12-20 22:14:28.053842+00	6417
489	-41	\N	-2	T137F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-489	\N	C	2019-12-20 22:14:28.053842+00	6418
488	-45	\N	-2	Unoki_A2-S1	Sample group consisting of one specific shard of ceramic.	\N	4	1	-488	\N	C	2019-12-20 22:14:28.053842+00	6419
487	-37	\N	-2	TA179	Sample group consisting of one specific shard of ceramic.	\N	4	1	-487	\N	C	2019-12-20 22:14:28.053842+00	6420
486	-28	\N	-2	MSKB_R467_F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-486	\N	C	2019-12-20 22:14:28.053842+00	6421
485	-28	\N	-2	MSKB_no70-72_(R220)_F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-485	\N	C	2019-12-20 22:14:28.053842+00	6422
484	-28	\N	-2	MSKB_BAG11_R211_F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-484	\N	C	2019-12-20 22:14:28.053842+00	6423
483	-28	\N	-2	MSKB_29_148_(R192)_F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-483	\N	C	2019-12-20 22:14:28.053842+00	6424
482	-28	\N	-2	MSKB_26_45_S125_F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-482	\N	C	2019-12-20 22:14:28.053842+00	6425
481	-28	\N	-2	MSKB_26_29_R295_F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-481	\N	C	2019-12-20 22:14:28.053842+00	6426
480	-28	\N	-2	MSKB_25_26_S1825_F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-480	\N	C	2019-12-20 22:14:28.053842+00	6427
479	-28	\N	-2	MSKB_24_7_S834_F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-479	\N	C	2019-12-20 22:14:28.053842+00	6428
478	-28	\N	-2	MSKB_23_6_S750 S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-478	\N	C	2019-12-20 22:14:28.053842+00	6429
477	-28	\N	-2	MSKB_23_6_S750 F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-477	\N	C	2019-12-20 22:14:28.053842+00	6430
476	-26	\N	-2	Saigura_HY141_S2	Sample group consisting of one specific shard of ceramic.	\N	4	1	-476	\N	C	2019-12-20 22:14:28.053842+00	6431
475	-22	\N	-2	MNK_9052_44_F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-475	\N	C	2019-12-20 22:14:28.053842+00	6432
474	-22	\N	-2	MNK_8856_95_F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-474	\N	C	2019-12-20 22:14:28.053842+00	6433
473	-22	\N	-2	MNK_8614_102_F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-473	\N	C	2019-12-20 22:14:28.053842+00	6434
472	-22	\N	-2	MNK_36894_F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-472	\N	C	2019-12-20 22:14:28.053842+00	6435
471	-22	\N	-2	MNK_3411_77_F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-471	\N	C	2019-12-20 22:14:28.053842+00	6436
470	-22	\N	-2	MNK_31854_245_F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-470	\N	C	2019-12-20 22:14:28.053842+00	6437
469	-22	\N	-2	MNK_3153_152_F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-469	\N	C	2019-12-20 22:14:28.053842+00	6438
468	-20	\N	-2	MC_3m4-9	Sample group consisting of one specific shard of ceramic.	\N	4	1	-468	\N	C	2019-12-20 22:14:28.053842+00	6439
467	-20	\N	-2	MC_3m4-8B	Sample group consisting of one specific shard of ceramic.	\N	4	1	-467	\N	C	2019-12-20 22:14:28.053842+00	6440
466	-20	\N	-2	MC_3m4-4	Sample group consisting of one specific shard of ceramic.	\N	4	1	-466	\N	C	2019-12-20 22:14:28.053842+00	6441
465	-20	\N	-2	MC_3m3-9	Sample group consisting of one specific shard of ceramic.	\N	4	1	-465	\N	C	2019-12-20 22:14:28.053842+00	6442
464	-20	\N	-2	MC_3m2-10	Sample group consisting of one specific shard of ceramic.	\N	4	1	-464	\N	C	2019-12-20 22:14:28.053842+00	6443
463	-20	\N	-2	MC_2m2-10	Sample group consisting of one specific shard of ceramic.	\N	4	1	-463	\N	C	2019-12-20 22:14:28.053842+00	6444
462	-19	\N	-2	MOT-79_S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-462	\N	C	2019-12-20 22:14:28.053842+00	6445
461	-19	\N	-2	MOT-79_F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-461	\N	C	2019-12-20 22:14:28.053842+00	6446
460	-19	\N	-2	MOT-33_F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-460	\N	C	2019-12-20 22:14:28.053842+00	6447
459	-19	\N	-2	MOT-31_S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-459	\N	C	2019-12-20 22:14:28.053842+00	6448
458	-19	\N	-2	MOT-31_F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-458	\N	C	2019-12-20 22:14:28.053842+00	6449
457	-19	\N	-2	MOT-30_F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-457	\N	C	2019-12-20 22:14:28.053842+00	6450
456	-19	\N	-2	MOT-08_7_23(162)_F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-456	\N	C	2019-12-20 22:14:28.053842+00	6451
455	-16	\N	-2	KBM5S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-455	\N	C	2019-12-20 22:14:28.053842+00	6452
454	-16	\N	-2	KBM5F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-454	\N	C	2019-12-20 22:14:28.053842+00	6453
453	-16	\N	-2	KBM1	Sample group consisting of one specific shard of ceramic.	\N	4	1	-453	\N	C	2019-12-20 22:14:28.053842+00	6454
452	-16	\N	-2	KBM2	Sample group consisting of one specific shard of ceramic.	\N	4	1	-452	\N	C	2019-12-20 22:14:28.053842+00	6455
451	-16	\N	-2	KBM3	Sample group consisting of one specific shard of ceramic.	\N	4	1	-451	\N	C	2019-12-20 22:14:28.053842+00	6456
450	-15	\N	-2	HY92_25	Sample group consisting of one specific shard of ceramic.	\N	4	1	-450	\N	C	2019-12-20 22:14:28.053842+00	6457
449	-14	\N	-2	KM-508F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-449	\N	C	2019-12-20 22:14:28.053842+00	6458
448	-14	\N	-2	KM-432F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-448	\N	C	2019-12-20 22:14:28.053842+00	6459
447	-11	\N	-2	KG_77_F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-447	\N	C	2019-12-20 22:14:28.053842+00	6460
446	-11	\N	-2	KG_70_F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-446	\N	C	2019-12-20 22:14:28.053842+00	6461
445	-11	\N	-2	KG_329_F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-445	\N	C	2019-12-20 22:14:28.053842+00	6462
444	-11	\N	-2	KG_102_F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-444	\N	C	2019-12-20 22:14:28.053842+00	6463
443	-8	\N	-2	Jin_HY_32_1_2	Sample group consisting of one specific shard of ceramic.	\N	4	1	-443	\N	C	2019-12-20 22:14:28.053842+00	6464
442	-8	\N	-2	Jin_HY_32_1_1_no3	Sample group consisting of one specific shard of ceramic.	\N	4	1	-442	\N	C	2019-12-20 22:14:28.053842+00	6465
441	-8	\N	-2	Jin_HY_32_1_1_no1	Sample group consisting of one specific shard of ceramic.	\N	4	1	-441	\N	C	2019-12-20 22:14:28.053842+00	6466
440	-7	\N	-2	ISH-EI_F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-440	\N	C	2019-12-20 22:14:28.053842+00	6467
439	-7	\N	-2	ISH-BVII_016_F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-439	\N	C	2019-12-20 22:14:28.053842+00	6468
438	-7	\N	-2	ISH-BOX2_F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-438	\N	C	2019-12-20 22:14:28.053842+00	6469
437	-21	\N	-2	NAG-7784	Sample group consisting of one specific shard of ceramic.	\N	4	1	-437	\N	C	2019-12-20 22:14:28.053842+00	6470
436	-21	\N	-2	NAG-6714	Sample group consisting of one specific shard of ceramic.	\N	4	1	-436	\N	C	2019-12-20 22:14:28.053842+00	6471
435	-21	\N	-2	NAG-6540	Sample group consisting of one specific shard of ceramic.	\N	4	1	-435	\N	C	2019-12-20 22:14:28.053842+00	6472
434	-21	\N	-2	NAG-6039	Sample group consisting of one specific shard of ceramic.	\N	4	1	-434	\N	C	2019-12-20 22:14:28.053842+00	6473
433	-21	\N	-2	NAG-6005	Sample group consisting of one specific shard of ceramic.	\N	4	1	-433	\N	C	2019-12-20 22:14:28.053842+00	6474
432	-21	\N	-2	NAG-5862	Sample group consisting of one specific shard of ceramic.	\N	4	1	-432	\N	C	2019-12-20 22:14:28.053842+00	6475
431	-21	\N	-2	NAG-5100	Sample group consisting of one specific shard of ceramic.	\N	4	1	-431	\N	C	2019-12-20 22:14:28.053842+00	6476
430	-21	\N	-2	NAG-4536	Sample group consisting of one specific shard of ceramic.	\N	4	1	-430	\N	C	2019-12-20 22:14:28.053842+00	6477
429	-21	\N	-2	NAG-1341	Sample group consisting of one specific shard of ceramic.	\N	4	1	-429	\N	C	2019-12-20 22:14:28.053842+00	6478
428	-21	\N	-2	NAG-1039	Sample group consisting of one specific shard of ceramic.	\N	4	1	-428	\N	C	2019-12-20 22:14:28.053842+00	6479
427	-9	\N	-2	JOZ-7X90	Sample group consisting of one specific shard of ceramic.	\N	4	1	-427	\N	C	2019-12-20 22:14:28.053842+00	6480
426	-9	\N	-2	JOZ-601X3	Sample group consisting of one specific shard of ceramic.	\N	4	1	-426	\N	C	2019-12-20 22:14:28.053842+00	6481
425	-9	\N	-2	JOZ-281XX	Sample group consisting of one specific shard of ceramic.	\N	4	1	-425	\N	C	2019-12-20 22:14:28.053842+00	6482
424	-9	\N	-2	JOZ-60222	Sample group consisting of one specific shard of ceramic.	\N	4	1	-424	\N	C	2019-12-20 22:14:28.053842+00	6483
423	-9	\N	-2	JOZ-53806	Sample group consisting of one specific shard of ceramic.	\N	4	1	-423	\N	C	2019-12-20 22:14:28.053842+00	6484
422	-9	\N	-2	JOZ-53755	Sample group consisting of one specific shard of ceramic.	\N	4	1	-422	\N	C	2019-12-20 22:14:28.053842+00	6485
421	-9	\N	-2	JOZ-52303	Sample group consisting of one specific shard of ceramic.	\N	4	1	-421	\N	C	2019-12-20 22:14:28.053842+00	6486
420	-9	\N	-2	JOZ-51663	Sample group consisting of one specific shard of ceramic.	\N	4	1	-420	\N	C	2019-12-20 22:14:28.053842+00	6487
419	-9	\N	-2	JOZ-48728	Sample group consisting of one specific shard of ceramic.	\N	4	1	-419	\N	C	2019-12-20 22:14:28.053842+00	6488
418	-9	\N	-2	JOZ-46672	Sample group consisting of one specific shard of ceramic.	\N	4	1	-418	\N	C	2019-12-20 22:14:28.053842+00	6489
417	-9	\N	-2	JOZ-45557	Sample group consisting of one specific shard of ceramic.	\N	4	1	-417	\N	C	2019-12-20 22:14:28.053842+00	6490
416	-9	\N	-2	JOZ-43824	Sample group consisting of one specific shard of ceramic.	\N	4	1	-416	\N	C	2019-12-20 22:14:28.053842+00	6491
415	-9	\N	-2	JOZ-20814	Sample group consisting of one specific shard of ceramic.	\N	4	1	-415	\N	C	2019-12-20 22:14:28.053842+00	6492
414	-9	\N	-2	JOZ-20028	Sample group consisting of one specific shard of ceramic.	\N	4	1	-414	\N	C	2019-12-20 22:14:28.053842+00	6493
413	-9	\N	-2	JOZ-18595	Sample group consisting of one specific shard of ceramic.	\N	4	1	-413	\N	C	2019-12-20 22:14:28.053842+00	6494
412	-9	\N	-2	JOZ-18519	Sample group consisting of one specific shard of ceramic.	\N	4	1	-412	\N	C	2019-12-20 22:14:28.053842+00	6495
411	-9	\N	-2	JOZ-14336	Sample group consisting of one specific shard of ceramic.	\N	4	1	-411	\N	C	2019-12-20 22:14:28.053842+00	6496
410	-9	\N	-2	JOZ-14011	Sample group consisting of one specific shard of ceramic.	\N	4	1	-410	\N	C	2019-12-20 22:14:28.053842+00	6497
409	-9	\N	-2	JOZ-8959	Sample group consisting of one specific shard of ceramic.	\N	4	1	-409	\N	C	2019-12-20 22:14:28.053842+00	6498
408	-9	\N	-2	JOZ-7583	Sample group consisting of one specific shard of ceramic.	\N	4	1	-408	\N	C	2019-12-20 22:14:28.053842+00	6499
407	-9	\N	-2	JOZ-4897	Sample group consisting of one specific shard of ceramic.	\N	4	1	-407	\N	C	2019-12-20 22:14:28.053842+00	6500
406	-9	\N	-2	JOZ-4873	Sample group consisting of one specific shard of ceramic.	\N	4	1	-406	\N	C	2019-12-20 22:14:28.053842+00	6501
405	-9	\N	-2	JOZ-4675	Sample group consisting of one specific shard of ceramic.	\N	4	1	-405	\N	C	2019-12-20 22:14:28.053842+00	6502
404	-9	\N	-2	JOZ-4197	Sample group consisting of one specific shard of ceramic.	\N	4	1	-404	\N	C	2019-12-20 22:14:28.053842+00	6503
403	-9	\N	-2	JOZ-2683	Sample group consisting of one specific shard of ceramic.	\N	4	1	-403	\N	C	2019-12-20 22:14:28.053842+00	6504
402	-9	\N	-2	JOZ-331	Sample group consisting of one specific shard of ceramic.	\N	4	1	-402	\N	C	2019-12-20 22:14:28.053842+00	6505
401	-9	\N	-2	JOZ-190	Sample group consisting of one specific shard of ceramic.	\N	4	1	-401	\N	C	2019-12-20 22:14:28.053842+00	6506
400	-9	\N	-2	JOZ-99	Sample group consisting of one specific shard of ceramic.	\N	4	1	-400	\N	C	2019-12-20 22:14:28.053842+00	6507
399	-9	\N	-2	JOZ-31	Sample group consisting of one specific shard of ceramic.	\N	4	1	-399	\N	C	2019-12-20 22:14:28.053842+00	6508
398	-9	\N	-2	JOZ-16	Sample group consisting of one specific shard of ceramic.	\N	4	1	-398	\N	C	2019-12-20 22:14:28.053842+00	6509
397	-40	\N	-2	TON-10	Sample group consisting of one specific shard of ceramic.	\N	4	1	-397	\N	C	2019-12-20 22:14:28.053842+00	6510
396	-40	\N	-2	TON-9	Sample group consisting of one specific shard of ceramic.	\N	4	1	-396	\N	C	2019-12-20 22:14:28.053842+00	6511
395	-40	\N	-2	TON-8	Sample group consisting of one specific shard of ceramic.	\N	4	1	-395	\N	C	2019-12-20 22:14:28.053842+00	6512
394	-40	\N	-2	TON-7	Sample group consisting of one specific shard of ceramic.	\N	4	1	-394	\N	C	2019-12-20 22:14:28.053842+00	6513
393	-40	\N	-2	TON-6	Sample group consisting of one specific shard of ceramic.	\N	4	1	-393	\N	C	2019-12-20 22:14:28.053842+00	6514
392	-40	\N	-2	TON-5	Sample group consisting of one specific shard of ceramic.	\N	4	1	-392	\N	C	2019-12-20 22:14:28.053842+00	6515
391	-40	\N	-2	TON-4	Sample group consisting of one specific shard of ceramic.	\N	4	1	-391	\N	C	2019-12-20 22:14:28.053842+00	6516
390	-40	\N	-2	TON-3	Sample group consisting of one specific shard of ceramic.	\N	4	1	-390	\N	C	2019-12-20 22:14:28.053842+00	6517
389	-40	\N	-2	TON-2	Sample group consisting of one specific shard of ceramic.	\N	4	1	-389	\N	C	2019-12-20 22:14:28.053842+00	6518
388	-40	\N	-2	TON-1	Sample group consisting of one specific shard of ceramic.	\N	4	1	-388	\N	C	2019-12-20 22:14:28.053842+00	6519
387	-38	\N	-2	TEN-10	Sample group consisting of one specific shard of ceramic.	\N	4	1	-387	\N	C	2019-12-20 22:14:28.053842+00	6520
386	-38	\N	-2	TEN-9	Sample group consisting of one specific shard of ceramic.	\N	4	1	-386	\N	C	2019-12-20 22:14:28.053842+00	6521
385	-38	\N	-2	TEN-8	Sample group consisting of one specific shard of ceramic.	\N	4	1	-385	\N	C	2019-12-20 22:14:28.053842+00	6522
384	-38	\N	-2	TEN-7	Sample group consisting of one specific shard of ceramic.	\N	4	1	-384	\N	C	2019-12-20 22:14:28.053842+00	6523
383	-38	\N	-2	TEN-6	Sample group consisting of one specific shard of ceramic.	\N	4	1	-383	\N	C	2019-12-20 22:14:28.053842+00	6524
382	-38	\N	-2	TEN-5	Sample group consisting of one specific shard of ceramic.	\N	4	1	-382	\N	C	2019-12-20 22:14:28.053842+00	6525
381	-38	\N	-2	TEN-4	Sample group consisting of one specific shard of ceramic.	\N	4	1	-381	\N	C	2019-12-20 22:14:28.053842+00	6526
380	-38	\N	-2	TEN-3	Sample group consisting of one specific shard of ceramic.	\N	4	1	-380	\N	C	2019-12-20 22:14:28.053842+00	6527
379	-38	\N	-2	TEN-2	Sample group consisting of one specific shard of ceramic.	\N	4	1	-379	\N	C	2019-12-20 22:14:28.053842+00	6528
378	-38	\N	-2	TEN-1	Sample group consisting of one specific shard of ceramic.	\N	4	1	-378	\N	C	2019-12-20 22:14:28.053842+00	6529
377	-29	\N	-2	SET-10	Sample group consisting of one specific shard of ceramic.	\N	4	1	-377	\N	C	2019-12-20 22:14:28.053842+00	6530
376	-29	\N	-2	SET-9	Sample group consisting of one specific shard of ceramic.	\N	4	1	-376	\N	C	2019-12-20 22:14:28.053842+00	6531
375	-29	\N	-2	SET-8	Sample group consisting of one specific shard of ceramic.	\N	4	1	-375	\N	C	2019-12-20 22:14:28.053842+00	6532
374	-29	\N	-2	SET-7	Sample group consisting of one specific shard of ceramic.	\N	4	1	-374	\N	C	2019-12-20 22:14:28.053842+00	6533
373	-29	\N	-2	SET-6	Sample group consisting of one specific shard of ceramic.	\N	4	1	-373	\N	C	2019-12-20 22:14:28.053842+00	6534
372	-29	\N	-2	SET-5	Sample group consisting of one specific shard of ceramic.	\N	4	1	-372	\N	C	2019-12-20 22:14:28.053842+00	6535
371	-29	\N	-2	SET-4	Sample group consisting of one specific shard of ceramic.	\N	4	1	-371	\N	C	2019-12-20 22:14:28.053842+00	6536
370	-29	\N	-2	SET-3	Sample group consisting of one specific shard of ceramic.	\N	4	1	-370	\N	C	2019-12-20 22:14:28.053842+00	6537
369	-29	\N	-2	SET-2	Sample group consisting of one specific shard of ceramic.	\N	4	1	-369	\N	C	2019-12-20 22:14:28.053842+00	6538
368	-29	\N	-2	SET-1	Sample group consisting of one specific shard of ceramic.	\N	4	1	-368	\N	C	2019-12-20 22:14:28.053842+00	6539
367	-3	\N	-2	HAI-10	Sample group consisting of one specific shard of ceramic.	\N	4	1	-367	\N	C	2019-12-20 22:14:28.053842+00	6540
366	-3	\N	-2	HAI-9	Sample group consisting of one specific shard of ceramic.	\N	4	1	-366	\N	C	2019-12-20 22:14:28.053842+00	6541
365	-3	\N	-2	HAI-8	Sample group consisting of one specific shard of ceramic.	\N	4	1	-365	\N	C	2019-12-20 22:14:28.053842+00	6542
364	-3	\N	-2	HAI-7	Sample group consisting of one specific shard of ceramic.	\N	4	1	-364	\N	C	2019-12-20 22:14:28.053842+00	6543
363	-3	\N	-2	HAI-6	Sample group consisting of one specific shard of ceramic.	\N	4	1	-363	\N	C	2019-12-20 22:14:28.053842+00	6544
362	-3	\N	-2	HAI-5	Sample group consisting of one specific shard of ceramic.	\N	4	1	-362	\N	C	2019-12-20 22:14:28.053842+00	6545
361	-3	\N	-2	HAI-4	Sample group consisting of one specific shard of ceramic.	\N	4	1	-361	\N	C	2019-12-20 22:14:28.053842+00	6546
360	-3	\N	-2	HAI-3	Sample group consisting of one specific shard of ceramic.	\N	4	1	-360	\N	C	2019-12-20 22:14:28.053842+00	6547
359	-3	\N	-2	HAI-2	Sample group consisting of one specific shard of ceramic.	\N	4	1	-359	\N	C	2019-12-20 22:14:28.053842+00	6548
358	-3	\N	-2	HAI-1	Sample group consisting of one specific shard of ceramic.	\N	4	1	-358	\N	C	2019-12-20 22:14:28.053842+00	6549
357	-2	\N	-2	AW-III_28_F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-357	\N	C	2019-12-20 22:14:28.053842+00	6550
356	-2	\N	-2	AW-H24_84_F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-356	\N	C	2019-12-20 22:14:28.053842+00	6551
355	-2	\N	-2	AW-H24_83_S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-355	\N	C	2019-12-20 22:14:28.053842+00	6552
354	-2	\N	-2	AW-H24_83_F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-354	\N	C	2019-12-20 22:14:28.053842+00	6553
353	-2	\N	-2	AW-H24_61_F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-353	\N	C	2019-12-20 22:14:28.053842+00	6554
352	-2	\N	-2	AW-H24_33_F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-352	\N	C	2019-12-20 22:14:28.053842+00	6555
351	-2	\N	-2	AW-H24_23_F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-351	\N	C	2019-12-20 22:14:28.053842+00	6556
350	-2	\N	-2	AW-H24_1_F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-350	\N	C	2019-12-20 22:14:28.053842+00	6557
349	-2	\N	-2	AW-32_S	Sample group consisting of one specific shard of ceramic.	\N	4	1	-349	\N	C	2019-12-20 22:14:28.053842+00	6558
348	-2	\N	-2	AW-32_F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-348	\N	C	2019-12-20 22:14:28.053842+00	6559
347	-25	\N	-2	SSK105	Sample group consisting of one specific shard of ceramic.	\N	4	1	-347	\N	C	2019-12-20 22:14:28.053842+00	6560
346	-25	\N	-2	SSK104	Sample group consisting of one specific shard of ceramic.	\N	4	1	-346	\N	C	2019-12-20 22:14:28.053842+00	6561
345	-25	\N	-2	SSK103	Sample group consisting of one specific shard of ceramic.	\N	4	1	-345	\N	C	2019-12-20 22:14:28.053842+00	6562
344	-25	\N	-2	SSK102	Sample group consisting of one specific shard of ceramic.	\N	4	1	-344	\N	C	2019-12-20 22:14:28.053842+00	6563
343	-25	\N	-2	SSK101	Sample group consisting of one specific shard of ceramic.	\N	4	1	-343	\N	C	2019-12-20 22:14:28.053842+00	6564
342	-48	\N	-2	TGY50C	Sample group consisting of one specific shard of ceramic.	\N	4	1	-342	\N	C	2019-12-20 22:14:28.053842+00	6565
341	-48	\N	-2	TGY50B	Sample group consisting of one specific shard of ceramic.	\N	4	1	-341	\N	C	2019-12-20 22:14:28.053842+00	6566
340	-48	\N	-2	TGY50A	Sample group consisting of one specific shard of ceramic.	\N	4	1	-340	\N	C	2019-12-20 22:14:28.053842+00	6567
339	-48	\N	-2	TGY49	Sample group consisting of one specific shard of ceramic.	\N	4	1	-339	\N	C	2019-12-20 22:14:28.053842+00	6568
338	-46	\N	-2	TGU48C	Sample group consisting of one specific shard of ceramic.	\N	4	1	-338	\N	C	2019-12-20 22:14:28.053842+00	6569
337	-46	\N	-2	TGU48B	Sample group consisting of one specific shard of ceramic.	\N	4	1	-337	\N	C	2019-12-20 22:14:28.053842+00	6570
336	-46	\N	-2	TGU48A	Sample group consisting of one specific shard of ceramic.	\N	4	1	-336	\N	C	2019-12-20 22:14:28.053842+00	6571
335	-46	\N	-2	TGU47B	Sample group consisting of one specific shard of ceramic.	\N	4	1	-335	\N	C	2019-12-20 22:14:28.053842+00	6572
334	-46	\N	-2	TGU47A	Sample group consisting of one specific shard of ceramic.	\N	4	1	-334	\N	C	2019-12-20 22:14:28.053842+00	6573
333	-46	\N	-2	TGU46	Sample group consisting of one specific shard of ceramic.	\N	4	1	-333	\N	C	2019-12-20 22:14:28.053842+00	6574
332	-46	\N	-2	TGU45	Sample group consisting of one specific shard of ceramic.	\N	4	1	-332	\N	C	2019-12-20 22:14:28.053842+00	6575
331	-5	\N	-2	TGI44	Sample group consisting of one specific shard of ceramic.	\N	4	1	-331	\N	C	2019-12-20 22:14:28.053842+00	6576
330	-5	\N	-2	TGI43	Sample group consisting of one specific shard of ceramic.	\N	4	1	-330	\N	C	2019-12-20 22:14:28.053842+00	6577
329	-5	\N	-2	TGI42H	Sample group consisting of one specific shard of ceramic.	\N	4	1	-329	\N	C	2019-12-20 22:14:28.053842+00	6578
328	-5	\N	-2	TGI42G	Sample group consisting of one specific shard of ceramic.	\N	4	1	-328	\N	C	2019-12-20 22:14:28.053842+00	6579
327	-5	\N	-2	TGI42F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-327	\N	C	2019-12-20 22:14:28.053842+00	6580
326	-5	\N	-2	TGI42E	Sample group consisting of one specific shard of ceramic.	\N	4	1	-326	\N	C	2019-12-20 22:14:28.053842+00	6581
325	-5	\N	-2	TGI42D	Sample group consisting of one specific shard of ceramic.	\N	4	1	-325	\N	C	2019-12-20 22:14:28.053842+00	6582
324	-5	\N	-2	TGI42C	Sample group consisting of one specific shard of ceramic.	\N	4	1	-324	\N	C	2019-12-20 22:14:28.053842+00	6583
323	-5	\N	-2	TGI42B	Sample group consisting of one specific shard of ceramic.	\N	4	1	-323	\N	C	2019-12-20 22:14:28.053842+00	6584
322	-5	\N	-2	TGI42A	Sample group consisting of one specific shard of ceramic.	\N	4	1	-322	\N	C	2019-12-20 22:14:28.053842+00	6585
321	-5	\N	-2	TGI41C	Sample group consisting of one specific shard of ceramic.	\N	4	1	-321	\N	C	2019-12-20 22:14:28.053842+00	6586
320	-5	\N	-2	TGI41B	Sample group consisting of one specific shard of ceramic.	\N	4	1	-320	\N	C	2019-12-20 22:14:28.053842+00	6587
319	-5	\N	-2	TGI41A	Sample group consisting of one specific shard of ceramic.	\N	4	1	-319	\N	C	2019-12-20 22:14:28.053842+00	6588
318	-5	\N	-2	TGI40	Sample group consisting of one specific shard of ceramic.	\N	4	1	-318	\N	C	2019-12-20 22:14:28.053842+00	6589
317	-5	\N	-2	TGI39B	Sample group consisting of one specific shard of ceramic.	\N	4	1	-317	\N	C	2019-12-20 22:14:28.053842+00	6590
316	-5	\N	-2	TGI39A	Sample group consisting of one specific shard of ceramic.	\N	4	1	-316	\N	C	2019-12-20 22:14:28.053842+00	6591
315	-5	\N	-2	TGI38E	Sample group consisting of one specific shard of ceramic.	\N	4	1	-315	\N	C	2019-12-20 22:14:28.053842+00	6592
314	-5	\N	-2	TGI38D	Sample group consisting of one specific shard of ceramic.	\N	4	1	-314	\N	C	2019-12-20 22:14:28.053842+00	6593
313	-5	\N	-2	TGI38C	Sample group consisting of one specific shard of ceramic.	\N	4	1	-313	\N	C	2019-12-20 22:14:28.053842+00	6594
312	-5	\N	-2	TGI38B	Sample group consisting of one specific shard of ceramic.	\N	4	1	-312	\N	C	2019-12-20 22:14:28.053842+00	6595
311	-5	\N	-2	TGI38A	Sample group consisting of one specific shard of ceramic.	\N	4	1	-311	\N	C	2019-12-20 22:14:28.053842+00	6596
310	-5	\N	-2	TGI37B	Sample group consisting of one specific shard of ceramic.	\N	4	1	-310	\N	C	2019-12-20 22:14:28.053842+00	6597
309	-5	\N	-2	TGI37A	Sample group consisting of one specific shard of ceramic.	\N	4	1	-309	\N	C	2019-12-20 22:14:28.053842+00	6598
308	-5	\N	-2	TGI36G	Sample group consisting of one specific shard of ceramic.	\N	4	1	-308	\N	C	2019-12-20 22:14:28.053842+00	6599
307	-5	\N	-2	TGI36F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-307	\N	C	2019-12-20 22:14:28.053842+00	6600
306	-5	\N	-2	TGI36E	Sample group consisting of one specific shard of ceramic.	\N	4	1	-306	\N	C	2019-12-20 22:14:28.053842+00	6601
305	-5	\N	-2	TGI36D	Sample group consisting of one specific shard of ceramic.	\N	4	1	-305	\N	C	2019-12-20 22:14:28.053842+00	6602
304	-5	\N	-2	TGI36C	Sample group consisting of one specific shard of ceramic.	\N	4	1	-304	\N	C	2019-12-20 22:14:28.053842+00	6603
303	-5	\N	-2	TGI36B	Sample group consisting of one specific shard of ceramic.	\N	4	1	-303	\N	C	2019-12-20 22:14:28.053842+00	6604
302	-5	\N	-2	TGI36A	Sample group consisting of one specific shard of ceramic.	\N	4	1	-302	\N	C	2019-12-20 22:14:28.053842+00	6605
301	-5	\N	-2	TGI35C	Sample group consisting of one specific shard of ceramic.	\N	4	1	-301	\N	C	2019-12-20 22:14:28.053842+00	6606
300	-5	\N	-2	TGI35B	Sample group consisting of one specific shard of ceramic.	\N	4	1	-300	\N	C	2019-12-20 22:14:28.053842+00	6607
299	-5	\N	-2	TGI35A	Sample group consisting of one specific shard of ceramic.	\N	4	1	-299	\N	C	2019-12-20 22:14:28.053842+00	6608
298	-5	\N	-2	TGI34F	Sample group consisting of one specific shard of ceramic.	\N	4	1	-298	\N	C	2019-12-20 22:14:28.053842+00	6609
297	-5	\N	-2	TGI34E	Sample group consisting of one specific shard of ceramic.	\N	4	1	-297	\N	C	2019-12-20 22:14:28.053842+00	6610
296	-5	\N	-2	TGI34D	Sample group consisting of one specific shard of ceramic.	\N	4	1	-296	\N	C	2019-12-20 22:14:28.053842+00	6611
295	-5	\N	-2	TGI34C	Sample group consisting of one specific shard of ceramic.	\N	4	1	-295	\N	C	2019-12-20 22:14:28.053842+00	6612
294	-5	\N	-2	TGI34B	Sample group consisting of one specific shard of ceramic.	\N	4	1	-294	\N	C	2019-12-20 22:14:28.053842+00	6613
293	-5	\N	-2	TGI34A	Sample group consisting of one specific shard of ceramic.	\N	4	1	-293	\N	C	2019-12-20 22:14:28.053842+00	6614
292	-5	\N	-2	TGI33C	Sample group consisting of one specific shard of ceramic.	\N	4	1	-292	\N	C	2019-12-20 22:14:28.053842+00	6615
291	-5	\N	-2	TGI33B	Sample group consisting of one specific shard of ceramic.	\N	4	1	-291	\N	C	2019-12-20 22:14:28.053842+00	6616
290	-5	\N	-2	TGI33A	Sample group consisting of one specific shard of ceramic.	\N	4	1	-290	\N	C	2019-12-20 22:14:28.053842+00	6617
289	-5	\N	-2	TGI32B	Sample group consisting of one specific shard of ceramic.	\N	4	1	-289	\N	C	2019-12-20 22:14:28.053842+00	6618
288	-5	\N	-2	TGI32A	Sample group consisting of one specific shard of ceramic.	\N	4	1	-288	\N	C	2019-12-20 22:14:28.053842+00	6619
287	-5	\N	-2	TGI31	Sample group consisting of one specific shard of ceramic.	\N	4	1	-287	\N	C	2019-12-20 22:14:28.053842+00	6620
286	-5	\N	-2	TGI30	Sample group consisting of one specific shard of ceramic.	\N	4	1	-286	\N	C	2019-12-20 22:14:28.053842+00	6621
285	-5	\N	-2	TGI29	Sample group consisting of one specific shard of ceramic.	\N	4	1	-285	\N	C	2019-12-20 22:14:28.053842+00	6622
284	-5	\N	-2	TGI28E	Sample group consisting of one specific shard of ceramic.	\N	4	1	-284	\N	C	2019-12-20 22:14:28.053842+00	6623
283	-5	\N	-2	TGI28	Sample group consisting of one specific shard of ceramic.	\N	4	1	-283	\N	C	2019-12-20 22:14:28.053842+00	6624
282	-5	\N	-2	TGI27	Sample group consisting of one specific shard of ceramic.	\N	4	1	-282	\N	C	2019-12-20 22:14:28.053842+00	6625
281	-5	\N	-2	TGI26	Sample group consisting of one specific shard of ceramic.	\N	4	1	-281	\N	C	2019-12-20 22:14:28.053842+00	6626
280	-5	\N	-2	TGI25	Sample group consisting of one specific shard of ceramic.	\N	4	1	-280	\N	C	2019-12-20 22:14:28.053842+00	6627
279	-5	\N	-2	TGI24	Sample group consisting of one specific shard of ceramic.	\N	4	1	-279	\N	C	2019-12-20 22:14:28.053842+00	6628
278	-5	\N	-2	TGI23	Sample group consisting of one specific shard of ceramic.	\N	4	1	-278	\N	C	2019-12-20 22:14:28.053842+00	6629
277	-5	\N	-2	TGI22	Sample group consisting of one specific shard of ceramic.	\N	4	1	-277	\N	C	2019-12-20 22:14:28.053842+00	6630
276	-5	\N	-2	TGI21B	Sample group consisting of one specific shard of ceramic.	\N	4	1	-276	\N	C	2019-12-20 22:14:28.053842+00	6631
275	-5	\N	-2	TGI21A	Sample group consisting of one specific shard of ceramic.	\N	4	1	-275	\N	C	2019-12-20 22:14:28.053842+00	6632
274	-5	\N	-2	TGI20	Sample group consisting of one specific shard of ceramic.	\N	4	1	-274	\N	C	2019-12-20 22:14:28.053842+00	6633
273	-5	\N	-2	TGI19	Sample group consisting of one specific shard of ceramic.	\N	4	1	-273	\N	C	2019-12-20 22:14:28.053842+00	6634
272	-5	\N	-2	TGI18	Sample group consisting of one specific shard of ceramic.	\N	4	1	-272	\N	C	2019-12-20 22:14:28.053842+00	6635
271	-5	\N	-2	TGI17	Sample group consisting of one specific shard of ceramic.	\N	4	1	-271	\N	C	2019-12-20 22:14:28.053842+00	6636
270	-5	\N	-2	TGI16	Sample group consisting of one specific shard of ceramic.	\N	4	1	-270	\N	C	2019-12-20 22:14:28.053842+00	6637
269	-5	\N	-2	TGI15	Sample group consisting of one specific shard of ceramic.	\N	4	1	-269	\N	C	2019-12-20 22:14:28.053842+00	6638
268	-5	\N	-2	TGI13B	Sample group consisting of one specific shard of ceramic.	\N	4	1	-268	\N	C	2019-12-20 22:14:28.053842+00	6639
267	-5	\N	-2	TGI13A	Sample group consisting of one specific shard of ceramic.	\N	4	1	-267	\N	C	2019-12-20 22:14:28.053842+00	6640
266	-5	\N	-2	TGI12	Sample group consisting of one specific shard of ceramic.	\N	4	1	-266	\N	C	2019-12-20 22:14:28.053842+00	6641
265	-5	\N	-2	TGI11	Sample group consisting of one specific shard of ceramic.	\N	4	1	-265	\N	C	2019-12-20 22:14:28.053842+00	6642
264	-5	\N	-2	TGI10	Sample group consisting of one specific shard of ceramic.	\N	4	1	-264	\N	C	2019-12-20 22:14:28.053842+00	6643
263	-5	\N	-2	TGI09	Sample group consisting of one specific shard of ceramic.	\N	4	1	-263	\N	C	2019-12-20 22:14:28.053842+00	6644
262	-5	\N	-2	TGI08	Sample group consisting of one specific shard of ceramic.	\N	4	1	-262	\N	C	2019-12-20 22:14:28.053842+00	6645
261	-5	\N	-2	TGI07	Sample group consisting of one specific shard of ceramic.	\N	4	1	-261	\N	C	2019-12-20 22:14:28.053842+00	6646
260	-5	\N	-2	TGI06	Sample group consisting of one specific shard of ceramic.	\N	4	1	-260	\N	C	2019-12-20 22:14:28.053842+00	6647
259	-5	\N	-2	TGI05	Sample group consisting of one specific shard of ceramic.	\N	4	1	-259	\N	C	2019-12-20 22:14:28.053842+00	6648
258	-5	\N	-2	TGI04	Sample group consisting of one specific shard of ceramic.	\N	4	1	-258	\N	C	2019-12-20 22:14:28.053842+00	6649
257	-5	\N	-2	TGI03	Sample group consisting of one specific shard of ceramic.	\N	4	1	-257	\N	C	2019-12-20 22:14:28.053842+00	6650
256	-5	\N	-2	TGI02	Sample group consisting of one specific shard of ceramic.	\N	4	1	-256	\N	C	2019-12-20 22:14:28.053842+00	6651
255	-5	\N	-2	TGI01	Sample group consisting of one specific shard of ceramic.	\N	4	1	-255	\N	C	2019-12-20 22:14:28.053842+00	6652
254	-31	\N	-2	SMJ16	Sample group consisting of one specific shard of ceramic.	\N	4	1	-254	\N	C	2019-12-20 22:14:28.053842+00	6653
253	-31	\N	-2	SMJ15	Sample group consisting of one specific shard of ceramic.	\N	4	1	-253	\N	C	2019-12-20 22:14:28.053842+00	6654
252	-31	\N	-2	SMJ14	Sample group consisting of one specific shard of ceramic.	\N	4	1	-252	\N	C	2019-12-20 22:14:28.053842+00	6655
251	-31	\N	-2	SMJ13	Sample group consisting of one specific shard of ceramic.	\N	4	1	-251	\N	C	2019-12-20 22:14:28.053842+00	6656
250	-31	\N	-2	SMJ12	Sample group consisting of one specific shard of ceramic.	\N	4	1	-250	\N	C	2019-12-20 22:14:28.053842+00	6657
249	-31	\N	-2	SMJ11	Sample group consisting of one specific shard of ceramic.	\N	4	1	-249	\N	C	2019-12-20 22:14:28.053842+00	6658
248	-31	\N	-2	SMJ10	Sample group consisting of one specific shard of ceramic.	\N	4	1	-248	\N	C	2019-12-20 22:14:28.053842+00	6659
247	-31	\N	-2	SMJ09	Sample group consisting of one specific shard of ceramic.	\N	4	1	-247	\N	C	2019-12-20 22:14:28.053842+00	6660
246	-31	\N	-2	SMJ08	Sample group consisting of one specific shard of ceramic.	\N	4	1	-246	\N	C	2019-12-20 22:14:28.053842+00	6661
245	-31	\N	-2	SMJ07	Sample group consisting of one specific shard of ceramic.	\N	4	1	-245	\N	C	2019-12-20 22:14:28.053842+00	6662
244	-31	\N	-2	SMJ06	Sample group consisting of one specific shard of ceramic.	\N	4	1	-244	\N	C	2019-12-20 22:14:28.053842+00	6663
243	-31	\N	-2	SMJ05	Sample group consisting of one specific shard of ceramic.	\N	4	1	-243	\N	C	2019-12-20 22:14:28.053842+00	6664
242	-31	\N	-2	SMJ04	Sample group consisting of one specific shard of ceramic.	\N	4	1	-242	\N	C	2019-12-20 22:14:28.053842+00	6665
241	-31	\N	-2	SMJ03	Sample group consisting of one specific shard of ceramic.	\N	4	1	-241	\N	C	2019-12-20 22:14:28.053842+00	6666
240	-31	\N	-2	SMJ02	Sample group consisting of one specific shard of ceramic.	\N	4	1	-240	\N	C	2019-12-20 22:14:28.053842+00	6667
239	-31	\N	-2	SMJ01	Sample group consisting of one specific shard of ceramic.	\N	4	1	-239	\N	C	2019-12-20 22:14:28.053842+00	6668
238	-30	\N	-2	YHS08	Sample group consisting of one specific shard of ceramic.	\N	4	1	-238	\N	C	2019-12-20 22:14:28.053842+00	6669
237	-30	\N	-2	YHS07	Sample group consisting of one specific shard of ceramic.	\N	4	1	-237	\N	C	2019-12-20 22:14:28.053842+00	6670
236	-30	\N	-2	YHS06	Sample group consisting of one specific shard of ceramic.	\N	4	1	-236	\N	C	2019-12-20 22:14:28.053842+00	6671
235	-30	\N	-2	YHS05	Sample group consisting of one specific shard of ceramic.	\N	4	1	-235	\N	C	2019-12-20 22:14:28.053842+00	6672
234	-30	\N	-2	YHS04	Sample group consisting of one specific shard of ceramic.	\N	4	1	-234	\N	C	2019-12-20 22:14:28.053842+00	6673
233	-30	\N	-2	YHS03	Sample group consisting of one specific shard of ceramic.	\N	4	1	-233	\N	C	2019-12-20 22:14:28.053842+00	6674
232	-30	\N	-2	YHS02	Sample group consisting of one specific shard of ceramic.	\N	4	1	-232	\N	C	2019-12-20 22:14:28.053842+00	6675
231	-30	\N	-2	YHS01	Sample group consisting of one specific shard of ceramic.	\N	4	1	-231	\N	C	2019-12-20 22:14:28.053842+00	6676
230	-39	\N	-2	TOK14	Sample group consisting of one specific shard of ceramic.	\N	4	1	-230	\N	C	2019-12-20 22:14:28.053842+00	6677
229	-39	\N	-2	TOK13	Sample group consisting of one specific shard of ceramic.	\N	4	1	-229	\N	C	2019-12-20 22:14:28.053842+00	6678
228	-39	\N	-2	TOK12	Sample group consisting of one specific shard of ceramic.	\N	4	1	-228	\N	C	2019-12-20 22:14:28.053842+00	6679
227	-39	\N	-2	TOK11	Sample group consisting of one specific shard of ceramic.	\N	4	1	-227	\N	C	2019-12-20 22:14:28.053842+00	6680
226	-39	\N	-2	TOK10	Sample group consisting of one specific shard of ceramic.	\N	4	1	-226	\N	C	2019-12-20 22:14:28.053842+00	6681
225	-39	\N	-2	TOK9	Sample group consisting of one specific shard of ceramic.	\N	4	1	-225	\N	C	2019-12-20 22:14:28.053842+00	6682
224	-39	\N	-2	TOK8	Sample group consisting of one specific shard of ceramic.	\N	4	1	-224	\N	C	2019-12-20 22:14:28.053842+00	6683
223	-39	\N	-2	TOK7	Sample group consisting of one specific shard of ceramic.	\N	4	1	-223	\N	C	2019-12-20 22:14:28.053842+00	6684
222	-39	\N	-2	TOK6	Sample group consisting of one specific shard of ceramic.	\N	4	1	-222	\N	C	2019-12-20 22:14:28.053842+00	6685
221	-39	\N	-2	TOK5	Sample group consisting of one specific shard of ceramic.	\N	4	1	-221	\N	C	2019-12-20 22:14:28.053842+00	6686
220	-39	\N	-2	TOK4	Sample group consisting of one specific shard of ceramic.	\N	4	1	-220	\N	C	2019-12-20 22:14:28.053842+00	6687
219	-39	\N	-2	TOK3	Sample group consisting of one specific shard of ceramic.	\N	4	1	-219	\N	C	2019-12-20 22:14:28.053842+00	6688
218	-39	\N	-2	TOK2	Sample group consisting of one specific shard of ceramic.	\N	4	1	-218	\N	C	2019-12-20 22:14:28.053842+00	6689
217	-39	\N	-2	TOK1	Sample group consisting of one specific shard of ceramic.	\N	4	1	-217	\N	C	2019-12-20 22:14:28.053842+00	6690
216	-23	\N	-2	NJO20	Sample group consisting of one specific shard of ceramic.	\N	4	1	-216	\N	C	2019-12-20 22:14:28.053842+00	6691
215	-23	\N	-2	NJO19	Sample group consisting of one specific shard of ceramic.	\N	4	1	-215	\N	C	2019-12-20 22:14:28.053842+00	6692
214	-23	\N	-2	NJO18	Sample group consisting of one specific shard of ceramic.	\N	4	1	-214	\N	C	2019-12-20 22:14:28.053842+00	6693
213	-23	\N	-2	NJO17	Sample group consisting of one specific shard of ceramic.	\N	4	1	-213	\N	C	2019-12-20 22:14:28.053842+00	6694
212	-23	\N	-2	NJO16	Sample group consisting of one specific shard of ceramic.	\N	4	1	-212	\N	C	2019-12-20 22:14:28.053842+00	6695
211	-23	\N	-2	NJO15	Sample group consisting of one specific shard of ceramic.	\N	4	1	-211	\N	C	2019-12-20 22:14:28.053842+00	6696
210	-23	\N	-2	NJO14	Sample group consisting of one specific shard of ceramic.	\N	4	1	-210	\N	C	2019-12-20 22:14:28.053842+00	6697
209	-23	\N	-2	NJO13	Sample group consisting of one specific shard of ceramic.	\N	4	1	-209	\N	C	2019-12-20 22:14:28.053842+00	6698
208	-23	\N	-2	NJO12	Sample group consisting of one specific shard of ceramic.	\N	4	1	-208	\N	C	2019-12-20 22:14:28.053842+00	6699
207	-23	\N	-2	NJO11	Sample group consisting of one specific shard of ceramic.	\N	4	1	-207	\N	C	2019-12-20 22:14:28.053842+00	6700
206	-23	\N	-2	NJO10	Sample group consisting of one specific shard of ceramic.	\N	4	1	-206	\N	C	2019-12-20 22:14:28.053842+00	6701
205	-23	\N	-2	NJO09	Sample group consisting of one specific shard of ceramic.	\N	4	1	-205	\N	C	2019-12-20 22:14:28.053842+00	6702
204	-23	\N	-2	NJO08	Sample group consisting of one specific shard of ceramic.	\N	4	1	-204	\N	C	2019-12-20 22:14:28.053842+00	6703
203	-23	\N	-2	NJO07	Sample group consisting of one specific shard of ceramic.	\N	4	1	-203	\N	C	2019-12-20 22:14:28.053842+00	6704
202	-23	\N	-2	NJO06	Sample group consisting of one specific shard of ceramic.	\N	4	1	-202	\N	C	2019-12-20 22:14:28.053842+00	6705
201	-23	\N	-2	NJO05	Sample group consisting of one specific shard of ceramic.	\N	4	1	-201	\N	C	2019-12-20 22:14:28.053842+00	6706
200	-23	\N	-2	NJO04	Sample group consisting of one specific shard of ceramic.	\N	4	1	-200	\N	C	2019-12-20 22:14:28.053842+00	6707
199	-23	\N	-2	NJO03	Sample group consisting of one specific shard of ceramic.	\N	4	1	-199	\N	C	2019-12-20 22:14:28.053842+00	6708
198	-23	\N	-2	NJO02	Sample group consisting of one specific shard of ceramic.	\N	4	1	-198	\N	C	2019-12-20 22:14:28.053842+00	6709
197	-23	\N	-2	NJO01	Sample group consisting of one specific shard of ceramic.	\N	4	1	-197	\N	C	2019-12-20 22:14:28.053842+00	6710
196	-6	\N	-2	IHR15	Sample group consisting of one specific shard of ceramic.	\N	4	1	-196	\N	C	2019-12-20 22:14:28.053842+00	6711
195	-6	\N	-2	IHR14	Sample group consisting of one specific shard of ceramic.	\N	4	1	-195	\N	C	2019-12-20 22:14:28.053842+00	6712
194	-6	\N	-2	IHR13	Sample group consisting of one specific shard of ceramic.	\N	4	1	-194	\N	C	2019-12-20 22:14:28.053842+00	6713
193	-6	\N	-2	IHR12	Sample group consisting of one specific shard of ceramic.	\N	4	1	-193	\N	C	2019-12-20 22:14:28.053842+00	6714
192	-6	\N	-2	IHR11	Sample group consisting of one specific shard of ceramic.	\N	4	1	-192	\N	C	2019-12-20 22:14:28.053842+00	6715
191	-6	\N	-2	IHR10	Sample group consisting of one specific shard of ceramic.	\N	4	1	-191	\N	C	2019-12-20 22:14:28.053842+00	6716
190	-6	\N	-2	IHR09	Sample group consisting of one specific shard of ceramic.	\N	4	1	-190	\N	C	2019-12-20 22:14:28.053842+00	6717
189	-6	\N	-2	IHR08	Sample group consisting of one specific shard of ceramic.	\N	4	1	-189	\N	C	2019-12-20 22:14:28.053842+00	6718
188	-6	\N	-2	IHR07	Sample group consisting of one specific shard of ceramic.	\N	4	1	-188	\N	C	2019-12-20 22:14:28.053842+00	6719
187	-6	\N	-2	IHR06	Sample group consisting of one specific shard of ceramic.	\N	4	1	-187	\N	C	2019-12-20 22:14:28.053842+00	6720
186	-6	\N	-2	IHR05	Sample group consisting of one specific shard of ceramic.	\N	4	1	-186	\N	C	2019-12-20 22:14:28.053842+00	6721
185	-6	\N	-2	IHR04	Sample group consisting of one specific shard of ceramic.	\N	4	1	-185	\N	C	2019-12-20 22:14:28.053842+00	6722
184	-6	\N	-2	IHR03	Sample group consisting of one specific shard of ceramic.	\N	4	1	-184	\N	C	2019-12-20 22:14:28.053842+00	6723
183	-6	\N	-2	IHR02	Sample group consisting of one specific shard of ceramic.	\N	4	1	-183	\N	C	2019-12-20 22:14:28.053842+00	6724
182	-6	\N	-2	IHR01	Sample group consisting of one specific shard of ceramic.	\N	4	1	-182	\N	C	2019-12-20 22:14:28.053842+00	6725
181	-12	\N	-2	EKK07	Sample group consisting of one specific shard of ceramic.	\N	4	1	-181	\N	C	2019-12-20 22:14:28.053842+00	6726
180	-12	\N	-2	EKK06	Sample group consisting of one specific shard of ceramic.	\N	4	1	-180	\N	C	2019-12-20 22:14:28.053842+00	6727
179	-12	\N	-2	EKK05	Sample group consisting of one specific shard of ceramic.	\N	4	1	-179	\N	C	2019-12-20 22:14:28.053842+00	6728
178	-12	\N	-2	EKK04	Sample group consisting of one specific shard of ceramic.	\N	4	1	-178	\N	C	2019-12-20 22:14:28.053842+00	6729
177	-12	\N	-2	EKK03	Sample group consisting of one specific shard of ceramic.	\N	4	1	-177	\N	C	2019-12-20 22:14:28.053842+00	6730
176	-12	\N	-2	EKK02	Sample group consisting of one specific shard of ceramic.	\N	4	1	-176	\N	C	2019-12-20 22:14:28.053842+00	6731
175	-12	\N	-2	EKK01	Sample group consisting of one specific shard of ceramic.	\N	4	1	-175	\N	C	2019-12-20 22:14:28.053842+00	6732
174	-42	\N	-2	TRK13	Sample group consisting of one specific shard of ceramic.	\N	4	1	-174	\N	C	2019-12-20 22:14:28.053842+00	6733
173	-42	\N	-2	TRK12	Sample group consisting of one specific shard of ceramic.	\N	4	1	-173	\N	C	2019-12-20 22:14:28.053842+00	6734
172	-42	\N	-2	TRK11	Sample group consisting of one specific shard of ceramic.	\N	4	1	-172	\N	C	2019-12-20 22:14:28.053842+00	6735
171	-42	\N	-2	TRK10	Sample group consisting of one specific shard of ceramic.	\N	4	1	-171	\N	C	2019-12-20 22:14:28.053842+00	6736
170	-42	\N	-2	TRK09	Sample group consisting of one specific shard of ceramic.	\N	4	1	-170	\N	C	2019-12-20 22:14:28.053842+00	6737
169	-42	\N	-2	TRK08	Sample group consisting of one specific shard of ceramic.	\N	4	1	-169	\N	C	2019-12-20 22:14:28.053842+00	6738
168	-42	\N	-2	TRK07	Sample group consisting of one specific shard of ceramic.	\N	4	1	-168	\N	C	2019-12-20 22:14:28.053842+00	6739
167	-42	\N	-2	TRK06	Sample group consisting of one specific shard of ceramic.	\N	4	1	-167	\N	C	2019-12-20 22:14:28.053842+00	6740
166	-42	\N	-2	TRK05	Sample group consisting of one specific shard of ceramic.	\N	4	1	-166	\N	C	2019-12-20 22:14:28.053842+00	6741
165	-42	\N	-2	TRK04	Sample group consisting of one specific shard of ceramic.	\N	4	1	-165	\N	C	2019-12-20 22:14:28.053842+00	6742
164	-42	\N	-2	TRK03	Sample group consisting of one specific shard of ceramic.	\N	4	1	-164	\N	C	2019-12-20 22:14:28.053842+00	6743
163	-42	\N	-2	TRK02	Sample group consisting of one specific shard of ceramic.	\N	4	1	-163	\N	C	2019-12-20 22:14:28.053842+00	6744
162	-42	\N	-2	TRK01	Sample group consisting of one specific shard of ceramic.	\N	4	1	-162	\N	C	2019-12-20 22:14:28.053842+00	6745
161	-49	\N	-2	YKC53	Sample group consisting of one specific shard of ceramic.	\N	4	1	-161	\N	C	2019-12-20 22:14:28.053842+00	6746
160	-49	\N	-2	YKC52	Sample group consisting of one specific shard of ceramic.	\N	4	1	-160	\N	C	2019-12-20 22:14:28.053842+00	6747
159	-49	\N	-2	YKC51	Sample group consisting of one specific shard of ceramic.	\N	4	1	-159	\N	C	2019-12-20 22:14:28.053842+00	6748
158	-49	\N	-2	YKC50	Sample group consisting of one specific shard of ceramic.	\N	4	1	-158	\N	C	2019-12-20 22:14:28.053842+00	6749
157	-49	\N	-2	YKC49	Sample group consisting of one specific shard of ceramic.	\N	4	1	-157	\N	C	2019-12-20 22:14:28.053842+00	6750
156	-49	\N	-2	YKC48	Sample group consisting of one specific shard of ceramic.	\N	4	1	-156	\N	C	2019-12-20 22:14:28.053842+00	6751
155	-49	\N	-2	YKC47	Sample group consisting of one specific shard of ceramic.	\N	4	1	-155	\N	C	2019-12-20 22:14:28.053842+00	6752
154	-49	\N	-2	YKC46	Sample group consisting of one specific shard of ceramic.	\N	4	1	-154	\N	C	2019-12-20 22:14:28.053842+00	6753
153	-49	\N	-2	YKC45	Sample group consisting of one specific shard of ceramic.	\N	4	1	-153	\N	C	2019-12-20 22:14:28.053842+00	6754
152	-49	\N	-2	YKC44	Sample group consisting of one specific shard of ceramic.	\N	4	1	-152	\N	C	2019-12-20 22:14:28.053842+00	6755
151	-49	\N	-2	YKC43	Sample group consisting of one specific shard of ceramic.	\N	4	1	-151	\N	C	2019-12-20 22:14:28.053842+00	6756
150	-49	\N	-2	YKC42	Sample group consisting of one specific shard of ceramic.	\N	4	1	-150	\N	C	2019-12-20 22:14:28.053842+00	6757
149	-49	\N	-2	YKC41	Sample group consisting of one specific shard of ceramic.	\N	4	1	-149	\N	C	2019-12-20 22:14:28.053842+00	6758
148	-49	\N	-2	YKC40	Sample group consisting of one specific shard of ceramic.	\N	4	1	-148	\N	C	2019-12-20 22:14:28.053842+00	6759
147	-49	\N	-2	YKC39	Sample group consisting of one specific shard of ceramic.	\N	4	1	-147	\N	C	2019-12-20 22:14:28.053842+00	6760
146	-49	\N	-2	YKC38	Sample group consisting of one specific shard of ceramic.	\N	4	1	-146	\N	C	2019-12-20 22:14:28.053842+00	6761
145	-49	\N	-2	YKC37	Sample group consisting of one specific shard of ceramic.	\N	4	1	-145	\N	C	2019-12-20 22:14:28.053842+00	6762
144	-49	\N	-2	YKC36	Sample group consisting of one specific shard of ceramic.	\N	4	1	-144	\N	C	2019-12-20 22:14:28.053842+00	6763
143	-49	\N	-2	YKC35	Sample group consisting of one specific shard of ceramic.	\N	4	1	-143	\N	C	2019-12-20 22:14:28.053842+00	6764
142	-49	\N	-2	YKC34	Sample group consisting of one specific shard of ceramic.	\N	4	1	-142	\N	C	2019-12-20 22:14:28.053842+00	6765
141	-49	\N	-2	YKC33	Sample group consisting of one specific shard of ceramic.	\N	4	1	-141	\N	C	2019-12-20 22:14:28.053842+00	6766
140	-49	\N	-2	YKC32	Sample group consisting of one specific shard of ceramic.	\N	4	1	-140	\N	C	2019-12-20 22:14:28.053842+00	6767
139	-49	\N	-2	YKC31	Sample group consisting of one specific shard of ceramic.	\N	4	1	-139	\N	C	2019-12-20 22:14:28.053842+00	6768
138	-49	\N	-2	YKC21	Sample group consisting of one specific shard of ceramic.	\N	4	1	-138	\N	C	2019-12-20 22:14:28.053842+00	6769
137	-49	\N	-2	YKC20	Sample group consisting of one specific shard of ceramic.	\N	4	1	-137	\N	C	2019-12-20 22:14:28.053842+00	6770
136	-49	\N	-2	YKC19	Sample group consisting of one specific shard of ceramic.	\N	4	1	-136	\N	C	2019-12-20 22:14:28.053842+00	6771
135	-49	\N	-2	YKC18	Sample group consisting of one specific shard of ceramic.	\N	4	1	-135	\N	C	2019-12-20 22:14:28.053842+00	6772
134	-49	\N	-2	YKC17	Sample group consisting of one specific shard of ceramic.	\N	4	1	-134	\N	C	2019-12-20 22:14:28.053842+00	6773
133	-49	\N	-2	YKC16	Sample group consisting of one specific shard of ceramic.	\N	4	1	-133	\N	C	2019-12-20 22:14:28.053842+00	6774
132	-49	\N	-2	YKC15	Sample group consisting of one specific shard of ceramic.	\N	4	1	-132	\N	C	2019-12-20 22:14:28.053842+00	6775
131	-49	\N	-2	YKC14	Sample group consisting of one specific shard of ceramic.	\N	4	1	-131	\N	C	2019-12-20 22:14:28.053842+00	6776
130	-49	\N	-2	YKC13	Sample group consisting of one specific shard of ceramic.	\N	4	1	-130	\N	C	2019-12-20 22:14:28.053842+00	6777
129	-49	\N	-2	YKC12	Sample group consisting of one specific shard of ceramic.	\N	4	1	-129	\N	C	2019-12-20 22:14:28.053842+00	6778
128	-49	\N	-2	YKC11	Sample group consisting of one specific shard of ceramic.	\N	4	1	-128	\N	C	2019-12-20 22:14:28.053842+00	6779
127	-49	\N	-2	YKC10	Sample group consisting of one specific shard of ceramic.	\N	4	1	-127	\N	C	2019-12-20 22:14:28.053842+00	6780
126	-49	\N	-2	YKC09	Sample group consisting of one specific shard of ceramic.	\N	4	1	-126	\N	C	2019-12-20 22:14:28.053842+00	6781
125	-49	\N	-2	YKC08	Sample group consisting of one specific shard of ceramic.	\N	4	1	-125	\N	C	2019-12-20 22:14:28.053842+00	6782
124	-49	\N	-2	YKC07	Sample group consisting of one specific shard of ceramic.	\N	4	1	-124	\N	C	2019-12-20 22:14:28.053842+00	6783
123	-49	\N	-2	YKC06	Sample group consisting of one specific shard of ceramic.	\N	4	1	-123	\N	C	2019-12-20 22:14:28.053842+00	6784
122	-49	\N	-2	YKC05	Sample group consisting of one specific shard of ceramic.	\N	4	1	-122	\N	C	2019-12-20 22:14:28.053842+00	6785
121	-49	\N	-2	YKC04	Sample group consisting of one specific shard of ceramic.	\N	4	1	-121	\N	C	2019-12-20 22:14:28.053842+00	6786
120	-49	\N	-2	YKC03	Sample group consisting of one specific shard of ceramic.	\N	4	1	-120	\N	C	2019-12-20 22:14:28.053842+00	6787
119	-49	\N	-2	YKC02	Sample group consisting of one specific shard of ceramic.	\N	4	1	-119	\N	C	2019-12-20 22:14:28.053842+00	6788
118	-49	\N	-2	YKC01	Sample group consisting of one specific shard of ceramic.	\N	4	1	-118	\N	C	2019-12-20 22:14:28.053842+00	6789
117	-13	\N	-2	KSJ-41E	Sample group consisting of one specific shard of ceramic.	\N	4	1	-117	\N	C	2019-12-20 22:14:28.053842+00	6790
116	-13	\N	-2	KSJ-53E	Sample group consisting of one specific shard of ceramic.	\N	4	1	-116	\N	C	2019-12-20 22:14:28.053842+00	6791
115	-13	\N	-2	KSJ-80	Sample group consisting of one specific shard of ceramic.	\N	4	1	-115	\N	C	2019-12-20 22:14:28.053842+00	6792
114	-13	\N	-2	KSJ-79	Sample group consisting of one specific shard of ceramic.	\N	4	1	-114	\N	C	2019-12-20 22:14:28.053842+00	6793
113	-13	\N	-2	KSJ-78	Sample group consisting of one specific shard of ceramic.	\N	4	1	-113	\N	C	2019-12-20 22:14:28.053842+00	6794
112	-13	\N	-2	KSJ-77	Sample group consisting of one specific shard of ceramic.	\N	4	1	-112	\N	C	2019-12-20 22:14:28.053842+00	6795
111	-13	\N	-2	KSJ-76	Sample group consisting of one specific shard of ceramic.	\N	4	1	-111	\N	C	2019-12-20 22:14:28.053842+00	6796
110	-13	\N	-2	KSJ-75	Sample group consisting of one specific shard of ceramic.	\N	4	1	-110	\N	C	2019-12-20 22:14:28.053842+00	6797
109	-13	\N	-2	KSJ-74	Sample group consisting of one specific shard of ceramic.	\N	4	1	-109	\N	C	2019-12-20 22:14:28.053842+00	6798
108	-13	\N	-2	KSJ-73	Sample group consisting of one specific shard of ceramic.	\N	4	1	-108	\N	C	2019-12-20 22:14:28.053842+00	6799
107	-13	\N	-2	KSJ-72	Sample group consisting of one specific shard of ceramic.	\N	4	1	-107	\N	C	2019-12-20 22:14:28.053842+00	6800
106	-13	\N	-2	KSJ-71	Sample group consisting of one specific shard of ceramic.	\N	4	1	-106	\N	C	2019-12-20 22:14:28.053842+00	6801
105	-13	\N	-2	KSJ-70	Sample group consisting of one specific shard of ceramic.	\N	4	1	-105	\N	C	2019-12-20 22:14:28.053842+00	6802
104	-13	\N	-2	KSJ-69	Sample group consisting of one specific shard of ceramic.	\N	4	1	-104	\N	C	2019-12-20 22:14:28.053842+00	6803
103	-13	\N	-2	KSJ-68	Sample group consisting of one specific shard of ceramic.	\N	4	1	-103	\N	C	2019-12-20 22:14:28.053842+00	6804
102	-13	\N	-2	KSJ-67	Sample group consisting of one specific shard of ceramic.	\N	4	1	-102	\N	C	2019-12-20 22:14:28.053842+00	6805
101	-13	\N	-2	KSJ-66	Sample group consisting of one specific shard of ceramic.	\N	4	1	-101	\N	C	2019-12-20 22:14:28.053842+00	6806
100	-13	\N	-2	KSJ-65	Sample group consisting of one specific shard of ceramic.	\N	4	1	-100	\N	C	2019-12-20 22:14:28.053842+00	6807
99	-13	\N	-2	KSJ-64	Sample group consisting of one specific shard of ceramic.	\N	4	1	-99	\N	C	2019-12-20 22:14:28.053842+00	6808
98	-13	\N	-2	KSJ-63	Sample group consisting of one specific shard of ceramic.	\N	4	1	-98	\N	C	2019-12-20 22:14:28.053842+00	6809
97	-13	\N	-2	KSJ-62	Sample group consisting of one specific shard of ceramic.	\N	4	1	-97	\N	C	2019-12-20 22:14:28.053842+00	6810
96	-13	\N	-2	KSJ-61	Sample group consisting of one specific shard of ceramic.	\N	4	1	-96	\N	C	2019-12-20 22:14:28.053842+00	6811
95	-13	\N	-2	KSJ-60	Sample group consisting of one specific shard of ceramic.	\N	4	1	-95	\N	C	2019-12-20 22:14:28.053842+00	6812
94	-13	\N	-2	KSJ-59	Sample group consisting of one specific shard of ceramic.	\N	4	1	-94	\N	C	2019-12-20 22:14:28.053842+00	6813
93	-13	\N	-2	KSJ-58	Sample group consisting of one specific shard of ceramic.	\N	4	1	-93	\N	C	2019-12-20 22:14:28.053842+00	6814
92	-13	\N	-2	KSJ-57	Sample group consisting of one specific shard of ceramic.	\N	4	1	-92	\N	C	2019-12-20 22:14:28.053842+00	6815
91	-13	\N	-2	KSJ-56	Sample group consisting of one specific shard of ceramic.	\N	4	1	-91	\N	C	2019-12-20 22:14:28.053842+00	6816
90	-13	\N	-2	KSJ-55	Sample group consisting of one specific shard of ceramic.	\N	4	1	-90	\N	C	2019-12-20 22:14:28.053842+00	6817
89	-13	\N	-2	KSJ-54	Sample group consisting of one specific shard of ceramic.	\N	4	1	-89	\N	C	2019-12-20 22:14:28.053842+00	6818
88	-13	\N	-2	KSJ-53	Sample group consisting of one specific shard of ceramic.	\N	4	1	-88	\N	C	2019-12-20 22:14:28.053842+00	6819
87	-13	\N	-2	KSJ-52	Sample group consisting of one specific shard of ceramic.	\N	4	1	-87	\N	C	2019-12-20 22:14:28.053842+00	6820
86	-13	\N	-2	KSJ-51	Sample group consisting of one specific shard of ceramic.	\N	4	1	-86	\N	C	2019-12-20 22:14:28.053842+00	6821
85	-13	\N	-2	KSJ-50	Sample group consisting of one specific shard of ceramic.	\N	4	1	-85	\N	C	2019-12-20 22:14:28.053842+00	6822
84	-13	\N	-2	KSJ-49	Sample group consisting of one specific shard of ceramic.	\N	4	1	-84	\N	C	2019-12-20 22:14:28.053842+00	6823
83	-13	\N	-2	KSJ-48	Sample group consisting of one specific shard of ceramic.	\N	4	1	-83	\N	C	2019-12-20 22:14:28.053842+00	6824
82	-13	\N	-2	KSJ-47	Sample group consisting of one specific shard of ceramic.	\N	4	1	-82	\N	C	2019-12-20 22:14:28.053842+00	6825
81	-13	\N	-2	KSJ-46	Sample group consisting of one specific shard of ceramic.	\N	4	1	-81	\N	C	2019-12-20 22:14:28.053842+00	6826
80	-13	\N	-2	KSJ-45	Sample group consisting of one specific shard of ceramic.	\N	4	1	-80	\N	C	2019-12-20 22:14:28.053842+00	6827
79	-13	\N	-2	KSJ-44	Sample group consisting of one specific shard of ceramic.	\N	4	1	-79	\N	C	2019-12-20 22:14:28.053842+00	6828
78	-13	\N	-2	KSJ-43	Sample group consisting of one specific shard of ceramic.	\N	4	1	-78	\N	C	2019-12-20 22:14:28.053842+00	6829
77	-13	\N	-2	KSJ-427	Sample group consisting of one specific shard of ceramic.	\N	4	1	-77	\N	C	2019-12-20 22:14:28.053842+00	6830
76	-13	\N	-2	KSJ-426	Sample group consisting of one specific shard of ceramic.	\N	4	1	-76	\N	C	2019-12-20 22:14:28.053842+00	6831
75	-13	\N	-2	KSJ-425	Sample group consisting of one specific shard of ceramic.	\N	4	1	-75	\N	C	2019-12-20 22:14:28.053842+00	6832
74	-13	\N	-2	KSJ-424	Sample group consisting of one specific shard of ceramic.	\N	4	1	-74	\N	C	2019-12-20 22:14:28.053842+00	6833
73	-13	\N	-2	KSJ-423	Sample group consisting of one specific shard of ceramic.	\N	4	1	-73	\N	C	2019-12-20 22:14:28.053842+00	6834
72	-13	\N	-2	KSJ-422	Sample group consisting of one specific shard of ceramic.	\N	4	1	-72	\N	C	2019-12-20 22:14:28.053842+00	6835
71	-13	\N	-2	KSJ-421	Sample group consisting of one specific shard of ceramic.	\N	4	1	-71	\N	C	2019-12-20 22:14:28.053842+00	6836
70	-13	\N	-2	KSJ-420	Sample group consisting of one specific shard of ceramic.	\N	4	1	-70	\N	C	2019-12-20 22:14:28.053842+00	6837
69	-13	\N	-2	KSJ-42	Sample group consisting of one specific shard of ceramic.	\N	4	1	-69	\N	C	2019-12-20 22:14:28.053842+00	6838
68	-13	\N	-2	KSJ-41	Sample group consisting of one specific shard of ceramic.	\N	4	1	-68	\N	C	2019-12-20 22:14:28.053842+00	6839
67	-13	\N	-2	KSJ-40	Sample group consisting of one specific shard of ceramic.	\N	4	1	-67	\N	C	2019-12-20 22:14:28.053842+00	6840
66	-13	\N	-2	KSJ-39	Sample group consisting of one specific shard of ceramic.	\N	4	1	-66	\N	C	2019-12-20 22:14:28.053842+00	6841
65	-13	\N	-2	KSJ-38	Sample group consisting of one specific shard of ceramic.	\N	4	1	-65	\N	C	2019-12-20 22:14:28.053842+00	6842
64	-13	\N	-2	KSJ-37	Sample group consisting of one specific shard of ceramic.	\N	4	1	-64	\N	C	2019-12-20 22:14:28.053842+00	6843
63	-13	\N	-2	KSJ-36	Sample group consisting of one specific shard of ceramic.	\N	4	1	-63	\N	C	2019-12-20 22:14:28.053842+00	6844
62	-13	\N	-2	KSJ-35	Sample group consisting of one specific shard of ceramic.	\N	4	1	-62	\N	C	2019-12-20 22:14:28.053842+00	6845
61	-13	\N	-2	KSJ-34	Sample group consisting of one specific shard of ceramic.	\N	4	1	-61	\N	C	2019-12-20 22:14:28.053842+00	6846
60	-13	\N	-2	KSJ-33	Sample group consisting of one specific shard of ceramic.	\N	4	1	-60	\N	C	2019-12-20 22:14:28.053842+00	6847
59	-13	\N	-2	KSJ-32	Sample group consisting of one specific shard of ceramic.	\N	4	1	-59	\N	C	2019-12-20 22:14:28.053842+00	6848
58	-13	\N	-2	KSJ-31	Sample group consisting of one specific shard of ceramic.	\N	4	1	-58	\N	C	2019-12-20 22:14:28.053842+00	6849
57	-13	\N	-2	KSJ-30	Sample group consisting of one specific shard of ceramic.	\N	4	1	-57	\N	C	2019-12-20 22:14:28.053842+00	6850
56	-13	\N	-2	KSJ-29	Sample group consisting of one specific shard of ceramic.	\N	4	1	-56	\N	C	2019-12-20 22:14:28.053842+00	6851
55	-13	\N	-2	KSJ-28	Sample group consisting of one specific shard of ceramic.	\N	4	1	-55	\N	C	2019-12-20 22:14:28.053842+00	6852
54	-13	\N	-2	KSJ-27	Sample group consisting of one specific shard of ceramic.	\N	4	1	-54	\N	C	2019-12-20 22:14:28.053842+00	6853
53	-13	\N	-2	KSJ-26	Sample group consisting of one specific shard of ceramic.	\N	4	1	-53	\N	C	2019-12-20 22:14:28.053842+00	6854
52	-13	\N	-2	KSJ-25	Sample group consisting of one specific shard of ceramic.	\N	4	1	-52	\N	C	2019-12-20 22:14:28.053842+00	6855
51	-13	\N	-2	KSJ-24	Sample group consisting of one specific shard of ceramic.	\N	4	1	-51	\N	C	2019-12-20 22:14:28.053842+00	6856
50	-13	\N	-2	KSJ-23	Sample group consisting of one specific shard of ceramic.	\N	4	1	-50	\N	C	2019-12-20 22:14:28.053842+00	6857
49	-13	\N	-2	KSJ-22	Sample group consisting of one specific shard of ceramic.	\N	4	1	-49	\N	C	2019-12-20 22:14:28.053842+00	6858
48	-13	\N	-2	KSJ-21	Sample group consisting of one specific shard of ceramic.	\N	4	1	-48	\N	C	2019-12-20 22:14:28.053842+00	6859
47	-13	\N	-2	KSJ-20	Sample group consisting of one specific shard of ceramic.	\N	4	1	-47	\N	C	2019-12-20 22:14:28.053842+00	6860
46	-13	\N	-2	KSJ-19	Sample group consisting of one specific shard of ceramic.	\N	4	1	-46	\N	C	2019-12-20 22:14:28.053842+00	6861
45	-13	\N	-2	KSJ-18	Sample group consisting of one specific shard of ceramic.	\N	4	1	-45	\N	C	2019-12-20 22:14:28.053842+00	6862
44	-13	\N	-2	KSJ-17	Sample group consisting of one specific shard of ceramic.	\N	4	1	-44	\N	C	2019-12-20 22:14:28.053842+00	6863
43	-13	\N	-2	KSJ-16	Sample group consisting of one specific shard of ceramic.	\N	4	1	-43	\N	C	2019-12-20 22:14:28.053842+00	6864
42	-13	\N	-2	KSJ-15	Sample group consisting of one specific shard of ceramic.	\N	4	1	-42	\N	C	2019-12-20 22:14:28.053842+00	6865
41	-13	\N	-2	KSJ-14	Sample group consisting of one specific shard of ceramic.	\N	4	1	-41	\N	C	2019-12-20 22:14:28.053842+00	6866
40	-13	\N	-2	KSJ-13	Sample group consisting of one specific shard of ceramic.	\N	4	1	-40	\N	C	2019-12-20 22:14:28.053842+00	6867
39	-13	\N	-2	KSJ-12	Sample group consisting of one specific shard of ceramic.	\N	4	1	-39	\N	C	2019-12-20 22:14:28.053842+00	6868
38	-13	\N	-2	KSJ-11	Sample group consisting of one specific shard of ceramic.	\N	4	1	-38	\N	C	2019-12-20 22:14:28.053842+00	6869
37	-13	\N	-2	KSJ-10	Sample group consisting of one specific shard of ceramic.	\N	4	1	-37	\N	C	2019-12-20 22:14:28.053842+00	6870
36	-13	\N	-2	KSJ-09	Sample group consisting of one specific shard of ceramic.	\N	4	1	-36	\N	C	2019-12-20 22:14:28.053842+00	6871
35	-13	\N	-2	KSJ-08	Sample group consisting of one specific shard of ceramic.	\N	4	1	-35	\N	C	2019-12-20 22:14:28.053842+00	6872
34	-13	\N	-2	KSJ-07	Sample group consisting of one specific shard of ceramic.	\N	4	1	-34	\N	C	2019-12-20 22:14:28.053842+00	6873
33	-13	\N	-2	KSJ-06	Sample group consisting of one specific shard of ceramic.	\N	4	1	-33	\N	C	2019-12-20 22:14:28.053842+00	6874
32	-13	\N	-2	KSJ-05	Sample group consisting of one specific shard of ceramic.	\N	4	1	-32	\N	C	2019-12-20 22:14:28.053842+00	6875
31	-13	\N	-2	KSJ-04	Sample group consisting of one specific shard of ceramic.	\N	4	1	-31	\N	C	2019-12-20 22:14:28.053842+00	6876
30	-13	\N	-2	KSJ-03	Sample group consisting of one specific shard of ceramic.	\N	4	1	-30	\N	C	2019-12-20 22:14:28.053842+00	6877
29	-13	\N	-2	KSJ-02	Sample group consisting of one specific shard of ceramic.	\N	4	1	-29	\N	C	2019-12-20 22:14:28.053842+00	6878
28	-13	\N	-2	KSJ-01	Sample group consisting of one specific shard of ceramic.	\N	4	1	-28	\N	C	2019-12-20 22:14:28.053842+00	6879
27	-13	\N	-2	KSJ-91 (81)	Sample group consisting of one specific shard of ceramic.	\N	4	1	-27	\N	C	2019-12-20 22:14:28.053842+00	6880
26	-13	\N	-2	KSJ-90	Sample group consisting of one specific shard of ceramic.	\N	4	1	-26	\N	C	2019-12-20 22:14:28.053842+00	6881
25	-13	\N	-2	KSJ-89	Sample group consisting of one specific shard of ceramic.	\N	4	1	-25	\N	C	2019-12-20 22:14:28.053842+00	6882
24	-13	\N	-2	KSJ-88	Sample group consisting of one specific shard of ceramic.	\N	4	1	-24	\N	C	2019-12-20 22:14:28.053842+00	6883
23	-13	\N	-2	KSJ-87	Sample group consisting of one specific shard of ceramic.	\N	4	1	-23	\N	C	2019-12-20 22:14:28.053842+00	6884
22	-13	\N	-2	KSJ-86	Sample group consisting of one specific shard of ceramic.	\N	4	1	-22	\N	C	2019-12-20 22:14:28.053842+00	6885
21	-13	\N	-2	KSJ-85	Sample group consisting of one specific shard of ceramic.	\N	4	1	-21	\N	C	2019-12-20 22:14:28.053842+00	6886
1	-35	17	10	1_64001 Ekonomibyggnad	\N	\N	2	1	-1	\N	C	2019-12-20 22:14:09.31687+00	5793
2	-7	17	10	58224 Kyrka	\N	\N	2	1	-2	\N	C	2019-12-20 22:14:09.31687+00	5792
3	-26	17	10	58231 Kyrka	\N	\N	2	1	-3	\N	C	2019-12-20 22:14:09.31687+00	5791
4	-6	17	10	61002 Bostadshus	\N	\N	2	1	-4	\N	C	2019-12-20 22:14:09.31687+00	5790
5	-16	17	10	61026 Ekonomibyggnad	\N	\N	2	1	-5	\N	C	2019-12-20 22:14:09.31687+00	5789
6	-41	17	10	61027 Ekonomibyggnad	\N	\N	2	1	-6	\N	C	2019-12-20 22:14:09.31687+00	5788
7	-35	17	10	61101 Bostadshus	\N	\N	2	1	-7	\N	C	2019-12-20 22:14:09.31687+00	5787
8	-38	17	10	61125 Bostadshus	\N	\N	2	1	-8	\N	C	2019-12-20 22:14:09.31687+00	5786
9	-40	17	10	61330 Bostadshus	\N	\N	2	1	-9	\N	C	2019-12-20 22:14:09.31687+00	5785
10	-34	17	10	61332 Ekonomibyggnad	\N	\N	2	1	-10	\N	C	2019-12-20 22:14:09.31687+00	5784
11	-34	17	10	61339 Ekonomibyggnad	\N	\N	2	1	-11	\N	C	2019-12-20 22:14:09.31687+00	5783
18	-42	17	10	61478 Dendro	\N	\N	2	1	-18	\N	C	2019-12-20 22:14:09.31687+00	5776
1	-7	18	10	61004 Rustbädd	\N	\N	3	1	-1	\N	C	2019-12-20 22:14:19.067462+00	5962
2	-7	18	10	61005 virkesförråd	\N	\N	3	1	-2	\N	C	2019-12-20 22:14:19.067462+00	5961
3	-7	18	10	61006 syll	\N	\N	3	1	-3	\N	C	2019-12-20 22:14:19.067462+00	5960
4	-7	18	10	61008 Stolpe	\N	\N	3	1	-4	\N	C	2019-12-20 22:14:19.067462+00	5959
5	-7	18	10	61009 planka i trägolv	\N	\N	3	1	-5	\N	C	2019-12-20 22:14:19.067462+00	5958
6	-7	18	10	61011 Rustbädd	\N	\N	3	1	-6	\N	C	2019-12-20 22:14:19.067462+00	5957
7	-7	18	10	61013 Jönköping 50:1	\N	\N	3	1	-7	\N	C	2019-12-20 22:14:19.067462+00	5956
8	-7	18	10	61014 stock, grundläggning	\N	\N	3	1	-8	\N	C	2019-12-20 22:14:19.067462+00	5955
9	-7	18	10	61053 utfyllnadslager	\N	\N	3	1	-9	\N	C	2019-12-20 22:14:19.067462+00	5954
10	-7	18	10	61055 Rustbädd	\N	\N	3	1	-10	\N	C	2019-12-20 22:14:19.067462+00	5953
106	-7	18	10	61311 Fundament	\N	\N	3	1	-106	\N	C	2019-12-20 22:14:19.067462+00	5857
20	-13	\N	-2	KSJ-84	Sample group consisting of one specific shard of ceramic.	\N	4	1	-20	\N	C	2019-12-20 22:14:28.053842+00	6887
19	-13	\N	-2	KSJ-83	Sample group consisting of one specific shard of ceramic.	\N	4	1	-19	\N	C	2019-12-20 22:14:28.053842+00	6888
18	-13	\N	-2	KSJ-82	Sample group consisting of one specific shard of ceramic.	\N	4	1	-18	\N	C	2019-12-20 22:14:28.053842+00	6889
17	-13	\N	-2	KSJ-438	Sample group consisting of one specific shard of ceramic.	\N	4	1	-17	\N	C	2019-12-20 22:14:28.053842+00	6890
16	-13	\N	-2	KSJ-437	Sample group consisting of one specific shard of ceramic.	\N	4	1	-16	\N	C	2019-12-20 22:14:28.053842+00	6891
15	-13	\N	-2	KSJ-436	Sample group consisting of one specific shard of ceramic.	\N	4	1	-15	\N	C	2019-12-20 22:14:28.053842+00	6892
14	-13	\N	-2	KSJ-435	Sample group consisting of one specific shard of ceramic.	\N	4	1	-14	\N	C	2019-12-20 22:14:28.053842+00	6893
13	-13	\N	-2	KSJ-434	Sample group consisting of one specific shard of ceramic.	\N	4	1	-13	\N	C	2019-12-20 22:14:28.053842+00	6894
12	-13	\N	-2	KSJ-433	Sample group consisting of one specific shard of ceramic.	\N	4	1	-12	\N	C	2019-12-20 22:14:28.053842+00	6895
11	-13	\N	-2	KSJ-432	Sample group consisting of one specific shard of ceramic.	\N	4	1	-11	\N	C	2019-12-20 22:14:28.053842+00	6896
10	-13	\N	-2	KSJ-431	Sample group consisting of one specific shard of ceramic.	\N	4	1	-10	\N	C	2019-12-20 22:14:28.053842+00	6897
9	-13	\N	-2	KSJ-430	Sample group consisting of one specific shard of ceramic.	\N	4	1	-9	\N	C	2019-12-20 22:14:28.053842+00	6898
8	-13	\N	-2	KSJ-429	Sample group consisting of one specific shard of ceramic.	\N	4	1	-8	\N	C	2019-12-20 22:14:28.053842+00	6899
7	-13	\N	-2	KSJ-428	Sample group consisting of one specific shard of ceramic.	\N	4	1	-7	\N	C	2019-12-20 22:14:28.053842+00	6900
6	-13	\N	-2	KSJ-256	Sample group consisting of one specific shard of ceramic.	\N	4	1	-6	\N	C	2019-12-20 22:14:28.053842+00	6901
5	-13	\N	-2	KSJ-255	Sample group consisting of one specific shard of ceramic.	\N	4	1	-5	\N	C	2019-12-20 22:14:28.053842+00	6902
4	-13	\N	-2	KSJ-254	Sample group consisting of one specific shard of ceramic.	\N	4	1	-4	\N	C	2019-12-20 22:14:28.053842+00	6903
3	-13	\N	-2	KSJ-253	Sample group consisting of one specific shard of ceramic.	\N	4	1	-3	\N	C	2019-12-20 22:14:28.053842+00	6904
2	-13	\N	-2	KSJ-252	Sample group consisting of one specific shard of ceramic.	\N	4	1	-2	\N	C	2019-12-20 22:14:28.053842+00	6905
1	-13	\N	-2	KSJ-251	Sample group consisting of one specific shard of ceramic.	\N	4	1	-1	\N	C	2019-12-20 22:14:28.053842+00	6906
7481	-3339	13	173	KFL 9998@Jordprov	\N	\N	1	1	-7481	\N	C	2019-12-20 22:13:53.799521+00	2224
7480	-3243	13	173	KFL 9997@Jordprov	\N	\N	1	1	-7480	\N	C	2019-12-20 22:13:53.799521+00	2225
7479	-3243	13	173	KFL 9996@Jordprov	\N	\N	1	1	-7479	\N	C	2019-12-20 22:13:53.799521+00	2226
7478	-2999	13	173	KFL 5101@Ugnsvägg	\N	\N	1	1	-7478	\N	C	2019-12-20 22:13:53.799521+00	2227
7477	-3307	13	173	KFL 5100@Kärl	\N	\N	1	1	-7477	\N	C	2019-12-20 22:13:53.799521+00	2228
7476	-3307	13	173	KFL 5099@Kärl	\N	\N	1	1	-7476	\N	C	2019-12-20 22:13:53.799521+00	2229
7475	-3307	13	173	KFL 5098@Kärl	\N	\N	1	1	-7475	\N	C	2019-12-20 22:13:53.799521+00	2230
7474	-3307	13	173	KFL 5097@Kärl	\N	\N	1	1	-7474	\N	C	2019-12-20 22:13:53.799521+00	2231
7473	-3307	13	173	KFL 5096@Kärl	\N	\N	1	1	-7473	\N	C	2019-12-20 22:13:53.799521+00	2232
7472	-3307	13	173	KFL 5095@Rålera	\N	\N	1	1	-7472	\N	C	2019-12-20 22:13:53.799521+00	2233
7471	-3307	13	173	KFL 5094@Rålera	\N	\N	1	1	-7471	\N	C	2019-12-20 22:13:53.799521+00	2234
7470	-3307	13	173	KFL 5093@Rålera	\N	\N	1	1	-7470	\N	C	2019-12-20 22:13:53.799521+00	2235
7469	-3066	13	173	KFL 5092@Kärl	\N	\N	1	1	-7469	\N	C	2019-12-20 22:13:53.799521+00	2236
7468	-3294	13	173	KFL 5091@Kärl	\N	\N	1	1	-7468	\N	C	2019-12-20 22:13:53.799521+00	2237
7467	-3294	13	173	KFL 5090@Kärl	\N	\N	1	1	-7467	\N	C	2019-12-20 22:13:53.799521+00	2238
7466	-2994	13	173	KFL 5089@Kärl	\N	\N	1	1	-7466	\N	C	2019-12-20 22:13:53.799521+00	2239
7465	-3363	13	173	KFL 5088@Kärl	\N	\N	1	1	-7465	\N	C	2019-12-20 22:13:53.799521+00	2240
7464	-3009	13	173	KFL 5087@Kärl	\N	\N	1	1	-7464	\N	C	2019-12-20 22:13:53.799521+00	2241
7463	-3009	13	173	KFL 5086@Kärl	\N	\N	1	1	-7463	\N	C	2019-12-20 22:13:53.799521+00	2242
7462	-3009	13	173	KFL 5085@Kärl	\N	\N	1	1	-7462	\N	C	2019-12-20 22:13:53.799521+00	2243
7461	-3009	13	173	KFL 5084@Kärl	\N	\N	1	1	-7461	\N	C	2019-12-20 22:13:53.799521+00	2244
7460	-3009	13	173	KFL 5083@Kärl	\N	\N	1	1	-7460	\N	C	2019-12-20 22:13:53.799521+00	2245
7459	-3103	13	173	KFL 5082@Kärl	\N	\N	1	1	-7459	\N	C	2019-12-20 22:13:53.799521+00	2246
7458	-3103	13	173	KFL 5081@Kärl	\N	\N	1	1	-7458	\N	C	2019-12-20 22:13:53.799521+00	2247
7457	-3103	13	173	KFL 5080@Kärl	\N	\N	1	1	-7457	\N	C	2019-12-20 22:13:53.799521+00	2248
7456	-3346	13	173	KFL 5079@Kärl	\N	\N	1	1	-7456	\N	C	2019-12-20 22:13:53.799521+00	2249
7455	-3352	13	173	KFL 5078@Kärl	\N	\N	1	1	-7455	\N	C	2019-12-20 22:13:53.799521+00	2250
7454	-3352	13	173	KFL 5077@Kärl	\N	\N	1	1	-7454	\N	C	2019-12-20 22:13:53.799521+00	2251
7453	-3248	13	173	KFL 5076@Kärl	\N	\N	1	1	-7453	\N	C	2019-12-20 22:13:53.799521+00	2252
7452	-3268	13	173	KFL 5075@Kärl	\N	\N	1	1	-7452	\N	C	2019-12-20 22:13:53.799521+00	2253
7451	-3268	13	173	KFL 5074@Kärl	\N	\N	1	1	-7451	\N	C	2019-12-20 22:13:53.799521+00	2254
7450	-3144	13	173	KFL 5073@Kärl	\N	\N	1	1	-7450	\N	C	2019-12-20 22:13:53.799521+00	2255
7449	-3140	13	173	KFL 5072@Kärl	\N	\N	1	1	-7449	\N	C	2019-12-20 22:13:53.799521+00	2256
7448	-3050	13	173	KFL 5071@Kärl	\N	\N	1	1	-7448	\N	C	2019-12-20 22:13:53.799521+00	2257
7447	-3125	13	173	KFL 5070@Kärl	\N	\N	1	1	-7447	\N	C	2019-12-20 22:13:53.799521+00	2258
7446	-3272	13	173	KFL 5059@Kärl	\N	\N	1	1	-7446	\N	C	2019-12-20 22:13:53.799521+00	2259
7445	-3131	13	173	KFL 5058@Kärl	\N	\N	1	1	-7445	\N	C	2019-12-20 22:13:53.799521+00	2260
7444	-3131	13	173	KFL 5057@Kärl	\N	\N	1	1	-7444	\N	C	2019-12-20 22:13:53.799521+00	2261
7443	-3258	13	173	KFL 5056@Kärl	\N	\N	1	1	-7443	\N	C	2019-12-20 22:13:53.799521+00	2262
7442	-3260	13	173	KFL 5055@Kärl	\N	\N	1	1	-7442	\N	C	2019-12-20 22:13:53.799521+00	2263
7441	-3124	13	173	KFL 5054@Kärl	\N	\N	1	1	-7441	\N	C	2019-12-20 22:13:53.799521+00	2264
7440	-3085	13	173	KFL 4936@Gjutform	\N	\N	1	1	-7440	\N	C	2019-12-20 22:13:53.799521+00	2265
7439	-3085	13	173	KFL 4935@Gjutform	\N	\N	1	1	-7439	\N	C	2019-12-20 22:13:53.799521+00	2266
7438	-3085	13	173	KFL 4934@Gjutform	\N	\N	1	1	-7438	\N	C	2019-12-20 22:13:53.799521+00	2267
7437	-3085	13	173	KFL 4933@Gjutform	\N	\N	1	1	-7437	\N	C	2019-12-20 22:13:53.799521+00	2268
7436	-3085	13	173	KFL 4932@Gjutform	\N	\N	1	1	-7436	\N	C	2019-12-20 22:13:53.799521+00	2269
7435	-3085	13	173	KFL 4931@Gjutform	\N	\N	1	1	-7435	\N	C	2019-12-20 22:13:53.799521+00	2270
7434	-3085	13	173	KFL 4930@Gjutform	\N	\N	1	1	-7434	\N	C	2019-12-20 22:13:53.799521+00	2271
7433	-3085	13	173	KFL 4929@Gjutform	\N	\N	1	1	-7433	\N	C	2019-12-20 22:13:53.799521+00	2272
7432	-3085	13	173	KFL 4928@Gjutform	\N	\N	1	1	-7432	\N	C	2019-12-20 22:13:53.799521+00	2273
7431	-3085	13	173	KFL 4927@Gjutform	\N	\N	1	1	-7431	\N	C	2019-12-20 22:13:53.799521+00	2274
7430	-3085	13	173	KFL 4926@Gjutform	\N	\N	1	1	-7430	\N	C	2019-12-20 22:13:53.799521+00	2275
7429	-3085	13	173	KFL 4925@Gjutform	\N	\N	1	1	-7429	\N	C	2019-12-20 22:13:53.799521+00	2276
7428	-3085	13	173	KFL 4924@Gjutform	\N	\N	1	1	-7428	\N	C	2019-12-20 22:13:53.799521+00	2277
7427	-3171	13	173	KFL 4923@Gjutform	\N	\N	1	1	-7427	\N	C	2019-12-20 22:13:53.799521+00	2278
7426	-3171	13	173	KFL 4922@Gjutform	\N	\N	1	1	-7426	\N	C	2019-12-20 22:13:53.799521+00	2279
7425	-3171	13	173	KFL 4921@Gjutform	\N	\N	1	1	-7425	\N	C	2019-12-20 22:13:53.799521+00	2280
7424	-3171	13	173	KFL 4920@Gjutform	\N	\N	1	1	-7424	\N	C	2019-12-20 22:13:53.799521+00	2281
7423	-3171	13	173	KFL 4919@Gjutform	\N	\N	1	1	-7423	\N	C	2019-12-20 22:13:53.799521+00	2282
7422	-3171	13	173	KFL 4918@Gjutform	\N	\N	1	1	-7422	\N	C	2019-12-20 22:13:53.799521+00	2283
7421	-3171	13	173	KFL 4917@Gjutform	\N	\N	1	1	-7421	\N	C	2019-12-20 22:13:53.799521+00	2284
7420	-3171	13	173	KFL 4916@Gjutform	\N	\N	1	1	-7420	\N	C	2019-12-20 22:13:53.799521+00	2285
7419	-3171	13	173	KFL 4915@Gjutform	\N	\N	1	1	-7419	\N	C	2019-12-20 22:13:53.799521+00	2286
7418	-3171	13	173	KFL 4914@Gjutform	\N	\N	1	1	-7418	\N	C	2019-12-20 22:13:53.799521+00	2287
7417	-3171	13	173	KFL 4913@Gjutform	\N	\N	1	1	-7417	\N	C	2019-12-20 22:13:53.799521+00	2288
7416	-3214	13	173	KFL 4912@Gjutform	\N	\N	1	1	-7416	\N	C	2019-12-20 22:13:53.799521+00	2289
7415	-3214	13	173	KFL 4911@Gjutform	\N	\N	1	1	-7415	\N	C	2019-12-20 22:13:53.799521+00	2290
7414	-3214	13	173	KFL 4910@Gjutform	\N	\N	1	1	-7414	\N	C	2019-12-20 22:13:53.799521+00	2291
7413	-3214	13	173	KFL 4909@Gjutform	\N	\N	1	1	-7413	\N	C	2019-12-20 22:13:53.799521+00	2292
7412	-3214	13	173	KFL 4908@Gjutform	\N	\N	1	1	-7412	\N	C	2019-12-20 22:13:53.799521+00	2293
7411	-3214	13	173	KFL 4907@Gjutform	\N	\N	1	1	-7411	\N	C	2019-12-20 22:13:53.799521+00	2294
7410	-3214	13	173	KFL 4906@Gjutform	\N	\N	1	1	-7410	\N	C	2019-12-20 22:13:53.799521+00	2295
7409	-3168	13	173	KFL 4905@Gjutform	\N	\N	1	1	-7409	\N	C	2019-12-20 22:13:53.799521+00	2296
7408	-3168	13	173	KFL 4904@Gjutform	\N	\N	1	1	-7408	\N	C	2019-12-20 22:13:53.799521+00	2297
7407	-3168	13	173	KFL 4903@Gjutform	\N	\N	1	1	-7407	\N	C	2019-12-20 22:13:53.799521+00	2298
7406	-3168	13	173	KFL 4902@Gjutform	\N	\N	1	1	-7406	\N	C	2019-12-20 22:13:53.799521+00	2299
7405	-3168	13	173	KFL 4901@Gjutform	\N	\N	1	1	-7405	\N	C	2019-12-20 22:13:53.799521+00	2300
7404	-3168	13	173	KFL 4900@Gjutform	\N	\N	1	1	-7404	\N	C	2019-12-20 22:13:53.799521+00	2301
7403	-3169	13	173	KFL 4899@Gjutform	\N	\N	1	1	-7403	\N	C	2019-12-20 22:13:53.799521+00	2302
7402	-3169	13	173	KFL 4898@Gjutform	\N	\N	1	1	-7402	\N	C	2019-12-20 22:13:53.799521+00	2303
7401	-3169	13	173	KFL 4897@Gjutform	\N	\N	1	1	-7401	\N	C	2019-12-20 22:13:53.799521+00	2304
7400	-3169	13	173	KFL 4896@Gjutform	\N	\N	1	1	-7400	\N	C	2019-12-20 22:13:53.799521+00	2305
7399	-3169	13	173	KFL 4895@Gjutform	\N	\N	1	1	-7399	\N	C	2019-12-20 22:13:53.799521+00	2306
7398	-3165	13	173	KFL 4894@kakel	\N	\N	1	1	-7398	\N	C	2019-12-20 22:13:53.799521+00	2307
7397	-3165	13	173	KFL 4893@kakel	\N	\N	1	1	-7397	\N	C	2019-12-20 22:13:53.799521+00	2308
7396	-3165	13	173	KFL 4892@kakel	\N	\N	1	1	-7396	\N	C	2019-12-20 22:13:53.799521+00	2309
7395	-3165	13	173	KFL 4891@kakel	\N	\N	1	1	-7395	\N	C	2019-12-20 22:13:53.799521+00	2310
7394	-3165	13	173	KFL 4890@kakel	\N	\N	1	1	-7394	\N	C	2019-12-20 22:13:53.799521+00	2311
7393	-3165	13	173	KFL 4889@kakel	\N	\N	1	1	-7393	\N	C	2019-12-20 22:13:53.799521+00	2312
7392	-3165	13	173	KFL 4888@Kärl	\N	\N	1	1	-7392	\N	C	2019-12-20 22:13:53.799521+00	2313
7391	-3165	13	173	KFL 4887@Kärl	\N	\N	1	1	-7391	\N	C	2019-12-20 22:13:53.799521+00	2314
7390	-3165	13	173	KFL 4886@Kärl	\N	\N	1	1	-7390	\N	C	2019-12-20 22:13:53.799521+00	2315
7389	-3165	13	173	KFL 4885@Kärl	\N	\N	1	1	-7389	\N	C	2019-12-20 22:13:53.799521+00	2316
7388	-3165	13	173	KFL 4884@Kärl	\N	\N	1	1	-7388	\N	C	2019-12-20 22:13:53.799521+00	2317
7387	-3165	13	173	KFL 4883@Kärl	\N	\N	1	1	-7387	\N	C	2019-12-20 22:13:53.799521+00	2318
7386	-3165	13	173	KFL 4882@Kärl	\N	\N	1	1	-7386	\N	C	2019-12-20 22:13:53.799521+00	2319
7385	-3165	13	173	KFL 4881@Kärl	\N	\N	1	1	-7385	\N	C	2019-12-20 22:13:53.799521+00	2320
7384	-3165	13	173	KFL 4880@Kärl	\N	\N	1	1	-7384	\N	C	2019-12-20 22:13:53.799521+00	2321
7383	-3165	13	173	KFL 4879@Kärl	\N	\N	1	1	-7383	\N	C	2019-12-20 22:13:53.799521+00	2322
7382	-3165	13	173	KFL 4878@Kärl	\N	\N	1	1	-7382	\N	C	2019-12-20 22:13:53.799521+00	2323
7381	-3165	13	173	KFL 4877@Kärl	\N	\N	1	1	-7381	\N	C	2019-12-20 22:13:53.799521+00	2324
7380	-3165	13	173	KFL 4876@Kärl	\N	\N	1	1	-7380	\N	C	2019-12-20 22:13:53.799521+00	2325
7379	-3165	13	173	KFL 4875@Kärl	\N	\N	1	1	-7379	\N	C	2019-12-20 22:13:53.799521+00	2326
7378	-3165	13	173	KFL 4874@Kärl	\N	\N	1	1	-7378	\N	C	2019-12-20 22:13:53.799521+00	2327
7377	-3165	13	173	KFL 4873@Kärl	\N	\N	1	1	-7377	\N	C	2019-12-20 22:13:53.799521+00	2328
7376	-3165	13	173	KFL 4872@Kärl	\N	\N	1	1	-7376	\N	C	2019-12-20 22:13:53.799521+00	2329
7375	-3165	13	173	KFL 4871@Kärl	\N	\N	1	1	-7375	\N	C	2019-12-20 22:13:53.799521+00	2330
7374	-3165	13	173	KFL 4870@Kärl	\N	\N	1	1	-7374	\N	C	2019-12-20 22:13:53.799521+00	2331
7373	-3165	13	173	KFL 4869@Kärl	\N	\N	1	1	-7373	\N	C	2019-12-20 22:13:53.799521+00	2332
7372	-3165	13	173	KFL 4868@Kärl	\N	\N	1	1	-7372	\N	C	2019-12-20 22:13:53.799521+00	2333
7371	-3165	13	173	KFL 4867@Kärl	\N	\N	1	1	-7371	\N	C	2019-12-20 22:13:53.799521+00	2334
7370	-3165	13	173	KFL 4866@Kärl	\N	\N	1	1	-7370	\N	C	2019-12-20 22:13:53.799521+00	2335
7369	-3165	13	173	KFL 4865@Kärl	\N	\N	1	1	-7369	\N	C	2019-12-20 22:13:53.799521+00	2336
7368	-3165	13	173	KFL 4864@Kärl	\N	\N	1	1	-7368	\N	C	2019-12-20 22:13:53.799521+00	2337
7367	-3165	13	173	KFL 4863@Kärl	\N	\N	1	1	-7367	\N	C	2019-12-20 22:13:53.799521+00	2338
7366	-3165	13	173	KFL 4862@Kärl	\N	\N	1	1	-7366	\N	C	2019-12-20 22:13:53.799521+00	2339
7365	-3165	13	173	KFL 4861@Kärl	\N	\N	1	1	-7365	\N	C	2019-12-20 22:13:53.799521+00	2340
7364	-3165	13	173	KFL 4860@Kärl	\N	\N	1	1	-7364	\N	C	2019-12-20 22:13:53.799521+00	2341
7363	-3165	13	173	KFL 4859@Kärl	\N	\N	1	1	-7363	\N	C	2019-12-20 22:13:53.799521+00	2342
7362	-3259	13	173	KFL 4858@Kärl	\N	\N	1	1	-7362	\N	C	2019-12-20 22:13:53.799521+00	2343
7361	-3259	13	173	KFL 4857@Kärl	\N	\N	1	1	-7361	\N	C	2019-12-20 22:13:53.799521+00	2344
7360	-3180	13	173	KFL 4856@Lerklining	\N	\N	1	1	-7360	\N	C	2019-12-20 22:13:53.799521+00	2345
7359	-3095	13	173	KFL 4855@Gjutform	\N	\N	1	1	-7359	\N	C	2019-12-20 22:13:53.799521+00	2346
7358	-3095	13	173	KFL 4854@Gjutform	\N	\N	1	1	-7358	\N	C	2019-12-20 22:13:53.799521+00	2347
7357	-3095	13	173	KFL 4853@Gjutform	\N	\N	1	1	-7357	\N	C	2019-12-20 22:13:53.799521+00	2348
7356	-3095	13	173	KFL 4852@Gjutform	\N	\N	1	1	-7356	\N	C	2019-12-20 22:13:53.799521+00	2349
7355	-3095	13	173	KFL 4851@Gjutform	\N	\N	1	1	-7355	\N	C	2019-12-20 22:13:53.799521+00	2350
7354	-3095	13	173	KFL 4850@Gjutform	\N	\N	1	1	-7354	\N	C	2019-12-20 22:13:53.799521+00	2351
7353	-3095	13	173	KFL 4849@Gjutform	\N	\N	1	1	-7353	\N	C	2019-12-20 22:13:53.799521+00	2352
7352	-3095	13	173	KFL 4848@Gjutform	\N	\N	1	1	-7352	\N	C	2019-12-20 22:13:53.799521+00	2353
7351	-3095	13	173	KFL 4847@Gjutform	\N	\N	1	1	-7351	\N	C	2019-12-20 22:13:53.799521+00	2354
7350	-3095	13	173	KFL 4846@Gjutform	\N	\N	1	1	-7350	\N	C	2019-12-20 22:13:53.799521+00	2355
7349	-3095	13	173	KFL 4845@Gjutform	\N	\N	1	1	-7349	\N	C	2019-12-20 22:13:53.799521+00	2356
7348	-3095	13	173	KFL 4844@Gjutform	\N	\N	1	1	-7348	\N	C	2019-12-20 22:13:53.799521+00	2357
7347	-3095	13	173	KFL 4843@Gjutform	\N	\N	1	1	-7347	\N	C	2019-12-20 22:13:53.799521+00	2358
7346	-3095	13	173	KFL 4842@Gjutform	\N	\N	1	1	-7346	\N	C	2019-12-20 22:13:53.799521+00	2359
7345	-3095	13	173	KFL 4841@Gjutform	\N	\N	1	1	-7345	\N	C	2019-12-20 22:13:53.799521+00	2360
7344	-3095	13	173	KFL 4840@Gjutform	\N	\N	1	1	-7344	\N	C	2019-12-20 22:13:53.799521+00	2361
7343	-3095	13	173	KFL 4839@Gjutform	\N	\N	1	1	-7343	\N	C	2019-12-20 22:13:53.799521+00	2362
7342	-3095	13	173	KFL 4838@Gjutform	\N	\N	1	1	-7342	\N	C	2019-12-20 22:13:53.799521+00	2363
7341	-3095	13	173	KFL 4837@Gjutform	\N	\N	1	1	-7341	\N	C	2019-12-20 22:13:53.799521+00	2364
7340	-3095	13	173	KFL 4836@Gjutform	\N	\N	1	1	-7340	\N	C	2019-12-20 22:13:53.799521+00	2365
7339	-3319	13	173	KFL 4835@Lerklining	\N	\N	1	1	-7339	\N	C	2019-12-20 22:13:53.799521+00	2366
7338	-3319	13	173	KFL 4834@Lerklining	\N	\N	1	1	-7338	\N	C	2019-12-20 22:13:53.799521+00	2367
7337	-3319	13	173	KFL 4833@Lerklining	\N	\N	1	1	-7337	\N	C	2019-12-20 22:13:53.799521+00	2368
7336	-3048	13	173	KFL 4832@Jordprov	\N	\N	1	1	-7336	\N	C	2019-12-20 22:13:53.799521+00	2369
7335	-2997	13	173	KFL 4831@Kärl	\N	\N	1	1	-7335	\N	C	2019-12-20 22:13:53.799521+00	2370
7334	-2997	13	173	KFL 4830@Kärl	\N	\N	1	1	-7334	\N	C	2019-12-20 22:13:53.799521+00	2371
7333	-3200	13	173	KFL 4829@Lerklining	\N	\N	1	1	-7333	\N	C	2019-12-20 22:13:53.799521+00	2372
7332	-3200	13	173	KFL 4828@Kärl	\N	\N	1	1	-7332	\N	C	2019-12-20 22:13:53.799521+00	2373
7331	-3176	13	173	KFL 4827@Kärl@2?	\N	\N	1	1	-7331	\N	C	2019-12-20 22:13:53.799521+00	2374
7330	-3176	13	173	KFL 4826@Kärl@1	\N	\N	1	1	-7330	\N	C	2019-12-20 22:13:53.799521+00	2375
7329	-3176	13	173	KFL 4825@Kärl@2?	\N	\N	1	1	-7329	\N	C	2019-12-20 22:13:53.799521+00	2376
7328	-3176	13	173	KFL 4824@Kärl@2	\N	\N	1	1	-7328	\N	C	2019-12-20 22:13:53.799521+00	2377
7327	-3073	13	173	KFL 4823@Lerklining	\N	\N	1	1	-7327	\N	C	2019-12-20 22:13:53.799521+00	2378
7326	-3003	13	173	KFL 4822@Lerklining	\N	\N	1	1	-7326	\N	C	2019-12-20 22:13:53.799521+00	2379
7325	-3314	13	173	KFL 4821@Lerklining	\N	\N	1	1	-7325	\N	C	2019-12-20 22:13:53.799521+00	2380
7324	-3314	13	173	KFL 4820@Lerklining	\N	\N	1	1	-7324	\N	C	2019-12-20 22:13:53.799521+00	2381
7323	-3314	13	173	KFL 4819@Lerklining	\N	\N	1	1	-7323	\N	C	2019-12-20 22:13:53.799521+00	2382
7322	-3314	13	173	KFL 4818@Lerklining	\N	\N	1	1	-7322	\N	C	2019-12-20 22:13:53.799521+00	2383
7321	-3314	13	173	KFL 4817@Lerklining	\N	\N	1	1	-7321	\N	C	2019-12-20 22:13:53.799521+00	2384
7320	-3314	13	173	KFL 4816@Lerblock	\N	\N	1	1	-7320	\N	C	2019-12-20 22:13:53.799521+00	2385
7319	-3360	13	173	KFL 4815@Lerklining	\N	\N	1	1	-7319	\N	C	2019-12-20 22:13:53.799521+00	2386
7318	-3360	13	173	KFL 4814@Lerklining	\N	\N	1	1	-7318	\N	C	2019-12-20 22:13:53.799521+00	2387
7317	-3360	13	173	KFL 4813@Lerklining	\N	\N	1	1	-7317	\N	C	2019-12-20 22:13:53.799521+00	2388
7316	-3205	13	173	KFL 4812@Kärl@IV?	\N	\N	1	1	-7316	\N	C	2019-12-20 22:13:53.799521+00	2389
7315	-3205	13	173	KFL 4811@Kärl@IV	\N	\N	1	1	-7315	\N	C	2019-12-20 22:13:53.799521+00	2390
7314	-3205	13	173	KFL 4810@Kärl@III	\N	\N	1	1	-7314	\N	C	2019-12-20 22:13:53.799521+00	2391
7313	-3205	13	173	KFL 4809@Kärl@II	\N	\N	1	1	-7313	\N	C	2019-12-20 22:13:53.799521+00	2392
7312	-3205	13	173	KFL 4808@Kärl@I	\N	\N	1	1	-7312	\N	C	2019-12-20 22:13:53.799521+00	2393
7311	-3368	13	173	KFL 4807@Kärl@4	\N	\N	1	1	-7311	\N	C	2019-12-20 22:13:53.799521+00	2394
7310	-3368	13	173	KFL 4806@Kärl@3	\N	\N	1	1	-7310	\N	C	2019-12-20 22:13:53.799521+00	2395
7309	-3368	13	173	KFL 4805@Kärl@1	\N	\N	1	1	-7309	\N	C	2019-12-20 22:13:53.799521+00	2396
7308	-3059	13	173	KFL 4804@Lerklining	\N	\N	1	1	-7308	\N	C	2019-12-20 22:13:53.799521+00	2397
7307	-3059	13	173	KFL 4803@Lerklining	\N	\N	1	1	-7307	\N	C	2019-12-20 22:13:53.799521+00	2398
7306	-3059	13	173	KFL 4802@Lerklining	\N	\N	1	1	-7306	\N	C	2019-12-20 22:13:53.799521+00	2399
7305	-3059	13	173	KFL 4801@Lerklining	\N	\N	1	1	-7305	\N	C	2019-12-20 22:13:53.799521+00	2400
7304	-3059	13	173	KFL 4800@Lerklining	\N	\N	1	1	-7304	\N	C	2019-12-20 22:13:53.799521+00	2401
7303	-3059	13	173	KFL 4799@Lerklining	\N	\N	1	1	-7303	\N	C	2019-12-20 22:13:53.799521+00	2402
7302	-3059	13	173	KFL 4798@Lerklining	\N	\N	1	1	-7302	\N	C	2019-12-20 22:13:53.799521+00	2403
7301	-3058	13	173	KFL 4797@Kärl	\N	\N	1	1	-7301	\N	C	2019-12-20 22:13:53.799521+00	2404
7300	-3058	13	173	KFL 4796@Jordprov	\N	\N	1	1	-7300	\N	C	2019-12-20 22:13:53.799521+00	2405
7299	-3058	13	173	KFL 4795@Jordprov	\N	\N	1	1	-7299	\N	C	2019-12-20 22:13:53.799521+00	2406
7298	-3058	13	173	KFL 4794@Lerklining	\N	\N	1	1	-7298	\N	C	2019-12-20 22:13:53.799521+00	2407
7297	-3058	13	173	KFL 4793@Lerklining	\N	\N	1	1	-7297	\N	C	2019-12-20 22:13:53.799521+00	2408
7296	-3058	13	173	KFL 4792@Lerklining	\N	\N	1	1	-7296	\N	C	2019-12-20 22:13:53.799521+00	2409
7295	-3058	13	173	KFL 4791@Lerklining	\N	\N	1	1	-7295	\N	C	2019-12-20 22:13:53.799521+00	2410
7294	-3058	13	173	KFL 4790@Lerklining	\N	\N	1	1	-7294	\N	C	2019-12-20 22:13:53.799521+00	2411
7293	-3058	13	173	KFL 4789@Lerklining	\N	\N	1	1	-7293	\N	C	2019-12-20 22:13:53.799521+00	2412
7292	-3331	13	173	KFL 4788@Lerklining	\N	\N	1	1	-7292	\N	C	2019-12-20 22:13:53.799521+00	2413
7291	-3331	13	173	KFL 4787@Lerklining	\N	\N	1	1	-7291	\N	C	2019-12-20 22:13:53.799521+00	2414
7290	-3331	13	173	KFL 4786@Lerklining	\N	\N	1	1	-7290	\N	C	2019-12-20 22:13:53.799521+00	2415
7289	-3209	13	173	KFL 4785@Lerklining	\N	\N	1	1	-7289	\N	C	2019-12-20 22:13:53.799521+00	2416
7288	-3209	13	173	KFL 4784@Lerklining	\N	\N	1	1	-7288	\N	C	2019-12-20 22:13:53.799521+00	2417
7287	-3209	13	173	KFL 4783@Lerklining	\N	\N	1	1	-7287	\N	C	2019-12-20 22:13:53.799521+00	2418
7286	-3229	13	173	KFL 4782@Lerklining	\N	\N	1	1	-7286	\N	C	2019-12-20 22:13:53.799521+00	2419
7285	-3229	13	173	KFL 4781@Lerklining	\N	\N	1	1	-7285	\N	C	2019-12-20 22:13:53.799521+00	2420
7284	-3229	13	173	KFL 4780@Jordprov	\N	\N	1	1	-7284	\N	C	2019-12-20 22:13:53.799521+00	2421
7283	-3023	13	173	KFL 4779@Jordprov	\N	\N	1	1	-7283	\N	C	2019-12-20 22:13:53.799521+00	2422
7282	-3023	13	173	KFL 4778@Lerklining	\N	\N	1	1	-7282	\N	C	2019-12-20 22:13:53.799521+00	2423
7281	-3023	13	173	KFL 4777@Lerklining	\N	\N	1	1	-7281	\N	C	2019-12-20 22:13:53.799521+00	2424
7280	-3022	13	173	KFL 4776@Lerklining	\N	\N	1	1	-7280	\N	C	2019-12-20 22:13:53.799521+00	2425
7279	-3226	13	173	KFL 4775@Lerblock?	\N	\N	1	1	-7279	\N	C	2019-12-20 22:13:53.799521+00	2426
7278	-3226	13	173	KFL 4774@Lerklining	\N	\N	1	1	-7278	\N	C	2019-12-20 22:13:53.799521+00	2427
7277	-3226	13	173	KFL 4773@Lerklining	\N	\N	1	1	-7277	\N	C	2019-12-20 22:13:53.799521+00	2428
7276	-3226	13	173	KFL 4772@Lerklining	\N	\N	1	1	-7276	\N	C	2019-12-20 22:13:53.799521+00	2429
7275	-3226	13	173	KFL 4771@Lerklining	\N	\N	1	1	-7275	\N	C	2019-12-20 22:13:53.799521+00	2430
7274	-3226	13	173	KFL 4770@Lerklining	\N	\N	1	1	-7274	\N	C	2019-12-20 22:13:53.799521+00	2431
7273	-3226	13	173	KFL 4769@Lerblock?	\N	\N	1	1	-7273	\N	C	2019-12-20 22:13:53.799521+00	2432
7272	-3226	13	173	KFL 4768@Lerblock?	\N	\N	1	1	-7272	\N	C	2019-12-20 22:13:53.799521+00	2433
7271	-3226	13	173	KFL 4767@Lerklining	\N	\N	1	1	-7271	\N	C	2019-12-20 22:13:53.799521+00	2434
7270	-3226	13	173	KFL 4766@Lerklining	\N	\N	1	1	-7270	\N	C	2019-12-20 22:13:53.799521+00	2435
7269	-3210	13	173	KFL 4765@Sländtrissa &amp; vävtyngd	\N	\N	1	1	-7269	\N	C	2019-12-20 22:13:53.799521+00	2436
7268	-3210	13	173	KFL 4764@Sländtrissa &amp; vävtyngd	\N	\N	1	1	-7268	\N	C	2019-12-20 22:13:53.799521+00	2437
7267	-3210	13	173	KFL 4763@Sländtrissa &amp; vävtyngd	\N	\N	1	1	-7267	\N	C	2019-12-20 22:13:53.799521+00	2438
7266	-3210	13	173	KFL 4762@Blästermunstycke	\N	\N	1	1	-7266	\N	C	2019-12-20 22:13:53.799521+00	2439
7265	-3210	13	173	KFL 4761@Blästermunstycke	\N	\N	1	1	-7265	\N	C	2019-12-20 22:13:53.799521+00	2440
7264	-3257	13	173	KFL 4760@Jordprov	\N	\N	1	1	-7264	\N	C	2019-12-20 22:13:53.799521+00	2441
7263	-3257	13	173	KFL 4759@Lerskiva	\N	\N	1	1	-7263	\N	C	2019-12-20 22:13:53.799521+00	2442
7262	-3257	13	173	KFL 4758@Kärl	\N	\N	1	1	-7262	\N	C	2019-12-20 22:13:53.799521+00	2443
7261	-3257	13	173	KFL 4757@Kärl	\N	\N	1	1	-7261	\N	C	2019-12-20 22:13:53.799521+00	2444
7260	-3257	13	173	KFL 4756@Kärl	\N	\N	1	1	-7260	\N	C	2019-12-20 22:13:53.799521+00	2445
7259	-3257	13	173	KFL 4755@Kärl	\N	\N	1	1	-7259	\N	C	2019-12-20 22:13:53.799521+00	2446
7258	-3257	13	173	KFL 4754@Kärl	\N	\N	1	1	-7258	\N	C	2019-12-20 22:13:53.799521+00	2447
7257	-3257	13	173	KFL 4753@Kärl	\N	\N	1	1	-7257	\N	C	2019-12-20 22:13:53.799521+00	2448
7256	-3257	13	173	KFL 4752@Kärl	\N	\N	1	1	-7256	\N	C	2019-12-20 22:13:53.799521+00	2449
7255	-3257	13	173	KFL 4751@Kärl	\N	\N	1	1	-7255	\N	C	2019-12-20 22:13:53.799521+00	2450
7254	-3247	13	173	KFL 4746@Lerklining	\N	\N	1	1	-7254	\N	C	2019-12-20 22:13:53.799521+00	2451
7253	-3247	13	173	KFL 4745@Lerklining	\N	\N	1	1	-7253	\N	C	2019-12-20 22:13:53.799521+00	2452
7252	-3247	13	173	KFL 4744@Gjutform	\N	\N	1	1	-7252	\N	C	2019-12-20 22:13:53.799521+00	2453
7251	-3288	13	173	KFL 4743@Kärl	\N	\N	1	1	-7251	\N	C	2019-12-20 22:13:53.799521+00	2454
7250	-3173	13	173	KFL 4742@Degel	\N	\N	1	1	-7250	\N	C	2019-12-20 22:13:53.799521+00	2455
7249	-3173	13	173	KFL 4741@Gjutform	\N	\N	1	1	-7249	\N	C	2019-12-20 22:13:53.799521+00	2456
7248	-3173	13	173	KFL 4740@Gjutform	\N	\N	1	1	-7248	\N	C	2019-12-20 22:13:53.799521+00	2457
7247	-3173	13	173	KFL 4739@Gjutform	\N	\N	1	1	-7247	\N	C	2019-12-20 22:13:53.799521+00	2458
7246	-3173	13	173	KFL 4738@Gjutform	\N	\N	1	1	-7246	\N	C	2019-12-20 22:13:53.799521+00	2459
7245	-3173	13	173	KFL 4737@Gjutform	\N	\N	1	1	-7245	\N	C	2019-12-20 22:13:53.799521+00	2460
7244	-3173	13	173	KFL 4736@Gjutform	\N	\N	1	1	-7244	\N	C	2019-12-20 22:13:53.799521+00	2461
7243	-3173	13	173	KFL 4735@Gjutform	\N	\N	1	1	-7243	\N	C	2019-12-20 22:13:53.799521+00	2462
7242	-3173	13	173	KFL 4734@Gjutform	\N	\N	1	1	-7242	\N	C	2019-12-20 22:13:53.799521+00	2463
7241	-3173	13	173	KFL 4733@Gjutform	\N	\N	1	1	-7241	\N	C	2019-12-20 22:13:53.799521+00	2464
7240	-3173	13	173	KFL 4732@Gjutform	\N	\N	1	1	-7240	\N	C	2019-12-20 22:13:53.799521+00	2465
7239	-3173	13	173	KFL 4731@Gjutform	\N	\N	1	1	-7239	\N	C	2019-12-20 22:13:53.799521+00	2466
7238	-3173	13	173	KFL 4730@Gjutform	\N	\N	1	1	-7238	\N	C	2019-12-20 22:13:53.799521+00	2467
7237	-3173	13	173	KFL 4729@Gjutform	\N	\N	1	1	-7237	\N	C	2019-12-20 22:13:53.799521+00	2468
7236	-3173	13	173	KFL 4728@Gjutform	\N	\N	1	1	-7236	\N	C	2019-12-20 22:13:53.799521+00	2469
7235	-3173	13	173	KFL 4727@Gjutform	\N	\N	1	1	-7235	\N	C	2019-12-20 22:13:53.799521+00	2470
7234	-3173	13	173	KFL 4726@Gjutform	\N	\N	1	1	-7234	\N	C	2019-12-20 22:13:53.799521+00	2471
7233	-3173	13	173	KFL 4725@Gjutform	\N	\N	1	1	-7233	\N	C	2019-12-20 22:13:53.799521+00	2472
7232	-3173	13	173	KFL 4724@Gjutform	\N	\N	1	1	-7232	\N	C	2019-12-20 22:13:53.799521+00	2473
7231	-3173	13	173	KFL 4723@Gjutform	\N	\N	1	1	-7231	\N	C	2019-12-20 22:13:53.799521+00	2474
7230	-3173	13	173	KFL 4722@Gjutform	\N	\N	1	1	-7230	\N	C	2019-12-20 22:13:53.799521+00	2475
7229	-3173	13	173	KFL 4721@Gjutform	\N	\N	1	1	-7229	\N	C	2019-12-20 22:13:53.799521+00	2476
7228	-3173	13	173	KFL 4720@Gjutform	\N	\N	1	1	-7228	\N	C	2019-12-20 22:13:53.799521+00	2477
7227	-3173	13	173	KFL 4719@Gjutform	\N	\N	1	1	-7227	\N	C	2019-12-20 22:13:53.799521+00	2478
7226	-3173	13	173	KFL 4718@Gjutform	\N	\N	1	1	-7226	\N	C	2019-12-20 22:13:53.799521+00	2479
7225	-3173	13	173	KFL 4717@Gjutform	\N	\N	1	1	-7225	\N	C	2019-12-20 22:13:53.799521+00	2480
7224	-3173	13	173	KFL 4716@Gjutform	\N	\N	1	1	-7224	\N	C	2019-12-20 22:13:53.799521+00	2481
7223	-3173	13	173	KFL 4715@Gjutform	\N	\N	1	1	-7223	\N	C	2019-12-20 22:13:53.799521+00	2482
7222	-3173	13	173	KFL 4714@Gjutform	\N	\N	1	1	-7222	\N	C	2019-12-20 22:13:53.799521+00	2483
7221	-3173	13	173	KFL 4713@Gjutform	\N	\N	1	1	-7221	\N	C	2019-12-20 22:13:53.799521+00	2484
7220	-3173	13	173	KFL 4712@Gjutform	\N	\N	1	1	-7220	\N	C	2019-12-20 22:13:53.799521+00	2485
7219	-3173	13	173	KFL 4711@Gjutform	\N	\N	1	1	-7219	\N	C	2019-12-20 22:13:53.799521+00	2486
7218	-3173	13	173	KFL 4710@Gjutform	\N	\N	1	1	-7218	\N	C	2019-12-20 22:13:53.799521+00	2487
7217	-3173	13	173	KFL 4709@Gjutform	\N	\N	1	1	-7217	\N	C	2019-12-20 22:13:53.799521+00	2488
7216	-3173	13	173	KFL 4708@Gjutform	\N	\N	1	1	-7216	\N	C	2019-12-20 22:13:53.799521+00	2489
7215	-3173	13	173	KFL 4707@Gjutform	\N	\N	1	1	-7215	\N	C	2019-12-20 22:13:53.799521+00	2490
7214	-3173	13	173	KFL 4706@Gjutform	\N	\N	1	1	-7214	\N	C	2019-12-20 22:13:53.799521+00	2491
7213	-3380	13	173	KFL 4704@Lerklining	\N	\N	1	1	-7213	\N	C	2019-12-20 22:13:53.799521+00	2492
7212	-3380	13	173	KFL 4703@Lerklining	\N	\N	1	1	-7212	\N	C	2019-12-20 22:13:53.799521+00	2493
7211	-3380	13	173	KFL 4702@Lerklining	\N	\N	1	1	-7211	\N	C	2019-12-20 22:13:53.799521+00	2494
7210	-3244	13	173	KFL 4701@Kärl	\N	\N	1	1	-7210	\N	C	2019-12-20 22:13:53.799521+00	2495
7209	-3244	13	173	KFL 4700@Kärl	\N	\N	1	1	-7209	\N	C	2019-12-20 22:13:53.799521+00	2496
7208	-3244	13	173	KFL 4699@Kärl	\N	\N	1	1	-7208	\N	C	2019-12-20 22:13:53.799521+00	2497
7207	-3244	13	173	KFL 4698@Kärl	\N	\N	1	1	-7207	\N	C	2019-12-20 22:13:53.799521+00	2498
7206	-3244	13	173	KFL 4697@Kärl	\N	\N	1	1	-7206	\N	C	2019-12-20 22:13:53.799521+00	2499
7205	-3129	13	173	KFL 4696@Lerskiva	\N	\N	1	1	-7205	\N	C	2019-12-20 22:13:53.799521+00	2500
7204	-3129	13	173	KFL 4695@Kärl	\N	\N	1	1	-7204	\N	C	2019-12-20 22:13:53.799521+00	2501
7203	-3129	13	173	KFL 4694@Kärl	\N	\N	1	1	-7203	\N	C	2019-12-20 22:13:53.799521+00	2502
7202	-3128	13	173	KFL 4693@Kärl	\N	\N	1	1	-7202	\N	C	2019-12-20 22:13:53.799521+00	2503
7201	-3128	13	173	KFL 4692@Kärl	\N	\N	1	1	-7201	\N	C	2019-12-20 22:13:53.799521+00	2504
7200	-3128	13	173	KFL 4691@Kärl	\N	\N	1	1	-7200	\N	C	2019-12-20 22:13:53.799521+00	2505
7199	-3129	13	173	KFL 4690@Kärl	\N	\N	1	1	-7199	\N	C	2019-12-20 22:13:53.799521+00	2506
7198	-3129	13	173	KFL 4689@Kärl	\N	\N	1	1	-7198	\N	C	2019-12-20 22:13:53.799521+00	2507
7197	-3129	13	173	KFL 4688@Kärl	\N	\N	1	1	-7197	\N	C	2019-12-20 22:13:53.799521+00	2508
7196	-3128	13	173	KFL 4687@Kärl	\N	\N	1	1	-7196	\N	C	2019-12-20 22:13:53.799521+00	2509
7195	-3128	13	173	KFL 4686@Lerskiva	\N	\N	1	1	-7195	\N	C	2019-12-20 22:13:53.799521+00	2510
7194	-3129	13	173	KFL 4685@Kärl	\N	\N	1	1	-7194	\N	C	2019-12-20 22:13:53.799521+00	2511
7193	-3129	13	173	KFL 4684@Kärl	\N	\N	1	1	-7193	\N	C	2019-12-20 22:13:53.799521+00	2512
7192	-3128	13	173	KFL 4683@Kärl	\N	\N	1	1	-7192	\N	C	2019-12-20 22:13:53.799521+00	2513
7191	-3129	13	173	KFL 4682@Kärl	\N	\N	1	1	-7191	\N	C	2019-12-20 22:13:53.799521+00	2514
7190	-3128	13	173	KFL 4681@Kärl	\N	\N	1	1	-7190	\N	C	2019-12-20 22:13:53.799521+00	2515
7189	-3128	13	173	KFL 4680@Kärl	\N	\N	1	1	-7189	\N	C	2019-12-20 22:13:53.799521+00	2516
7188	-3128	13	173	KFL 4679@Kärl	\N	\N	1	1	-7188	\N	C	2019-12-20 22:13:53.799521+00	2517
7187	-3128	13	173	KFL 4678@Kärl	\N	\N	1	1	-7187	\N	C	2019-12-20 22:13:53.799521+00	2518
7186	-3127	13	173	KFL 4677@Jordprov	\N	\N	1	1	-7186	\N	C	2019-12-20 22:13:53.799521+00	2519
7185	-3127	13	173	KFL 4676@Jordprov	\N	\N	1	1	-7185	\N	C	2019-12-20 22:13:53.799521+00	2520
7184	-3127	13	173	KFL 4675@Jordprov	\N	\N	1	1	-7184	\N	C	2019-12-20 22:13:53.799521+00	2521
7183	-3127	13	173	KFL 4674@Jordprov	\N	\N	1	1	-7183	\N	C	2019-12-20 22:13:53.799521+00	2522
7182	-3127	13	173	KFL 4673@Jordprov	\N	\N	1	1	-7182	\N	C	2019-12-20 22:13:53.799521+00	2523
7181	-3127	13	173	KFL 4672@Jordprov	\N	\N	1	1	-7181	\N	C	2019-12-20 22:13:53.799521+00	2524
7180	-3127	13	173	KFL 4671@Jordprov	\N	\N	1	1	-7180	\N	C	2019-12-20 22:13:53.799521+00	2525
7179	-3127	13	173	KFL 4670@Jordprov	\N	\N	1	1	-7179	\N	C	2019-12-20 22:13:53.799521+00	2526
7178	-3127	13	173	KFL 4669@Jordprov	\N	\N	1	1	-7178	\N	C	2019-12-20 22:13:53.799521+00	2527
7177	-3127	13	173	KFL 4668@Jordprov	\N	\N	1	1	-7177	\N	C	2019-12-20 22:13:53.799521+00	2528
7176	-3129	13	173	KFL 4667@Kärl	\N	\N	1	1	-7176	\N	C	2019-12-20 22:13:53.799521+00	2529
7175	-3152	13	173	KFL 4666@Lerklining	\N	\N	1	1	-7175	\N	C	2019-12-20 22:13:53.799521+00	2530
7174	-3152	13	173	KFL 4665@Lerklining	\N	\N	1	1	-7174	\N	C	2019-12-20 22:13:53.799521+00	2531
7173	-3152	13	173	KFL 4664@Lerklining	\N	\N	1	1	-7173	\N	C	2019-12-20 22:13:53.799521+00	2532
7172	-3152	13	173	KFL 4663@Lerklining	\N	\N	1	1	-7172	\N	C	2019-12-20 22:13:53.799521+00	2533
7171	-3152	13	173	KFL 4662@Lerklining	\N	\N	1	1	-7171	\N	C	2019-12-20 22:13:53.799521+00	2534
7170	-3027	13	173	KFL 4659@Kärl	\N	\N	1	1	-7170	\N	C	2019-12-20 22:13:53.799521+00	2535
7169	-3027	13	173	KFL 4658@Kärl	\N	\N	1	1	-7169	\N	C	2019-12-20 22:13:53.799521+00	2536
7168	-3027	13	173	KFL 4657@Kärl	\N	\N	1	1	-7168	\N	C	2019-12-20 22:13:53.799521+00	2537
7167	-3027	13	173	KFL 4656@Kärl	\N	\N	1	1	-7167	\N	C	2019-12-20 22:13:53.799521+00	2538
7166	-3027	13	173	KFL 4655@Kärl	\N	\N	1	1	-7166	\N	C	2019-12-20 22:13:53.799521+00	2539
7165	-3027	13	173	KFL 4654@Kärl	\N	\N	1	1	-7165	\N	C	2019-12-20 22:13:53.799521+00	2540
7164	-3027	13	173	KFL 4653@Kärl	\N	\N	1	1	-7164	\N	C	2019-12-20 22:13:53.799521+00	2541
7163	-3027	13	173	KFL 4652@Kärl	\N	\N	1	1	-7163	\N	C	2019-12-20 22:13:53.799521+00	2542
7162	-3027	13	173	KFL 4651@Kärl	\N	\N	1	1	-7162	\N	C	2019-12-20 22:13:53.799521+00	2543
7161	-3027	13	173	KFL 4650@Kärl	\N	\N	1	1	-7161	\N	C	2019-12-20 22:13:53.799521+00	2544
7160	-3027	13	173	KFL 4649@Kärl	\N	\N	1	1	-7160	\N	C	2019-12-20 22:13:53.799521+00	2545
7159	-3027	13	173	KFL 4648@Kärl	\N	\N	1	1	-7159	\N	C	2019-12-20 22:13:53.799521+00	2546
7158	-3027	13	173	KFL 4647@Kärl	\N	\N	1	1	-7158	\N	C	2019-12-20 22:13:53.799521+00	2547
7157	-3030	13	173	KFL 4646@Lerklining	\N	\N	1	1	-7157	\N	C	2019-12-20 22:13:53.799521+00	2548
7156	-3030	13	173	KFL 4645@Lerklining	\N	\N	1	1	-7156	\N	C	2019-12-20 22:13:53.799521+00	2549
7155	-3030	13	173	KFL 4644@Lerklining	\N	\N	1	1	-7155	\N	C	2019-12-20 22:13:53.799521+00	2550
7154	-3149	13	173	KFL 4643@Kärl	\N	\N	1	1	-7154	\N	C	2019-12-20 22:13:53.799521+00	2551
7153	-3149	13	173	KFL 4642@Kärl	\N	\N	1	1	-7153	\N	C	2019-12-20 22:13:53.799521+00	2552
7152	-3149	13	173	KFL 4641@Kärl	\N	\N	1	1	-7152	\N	C	2019-12-20 22:13:53.799521+00	2553
7151	-2989	13	173	KFL 4640@Kärl	\N	\N	1	1	-7151	\N	C	2019-12-20 22:13:53.799521+00	2554
7150	-2989	13	173	KFL 4639@Kärl	\N	\N	1	1	-7150	\N	C	2019-12-20 22:13:53.799521+00	2555
7149	-2989	13	173	KFL 4638@Kärl	\N	\N	1	1	-7149	\N	C	2019-12-20 22:13:53.799521+00	2556
7148	-2989	13	173	KFL 4637@Kärl	\N	\N	1	1	-7148	\N	C	2019-12-20 22:13:53.799521+00	2557
7147	-2989	13	173	KFL 4636@Kärl	\N	\N	1	1	-7147	\N	C	2019-12-20 22:13:53.799521+00	2558
7146	-2989	13	173	KFL 4635@Kärl	\N	\N	1	1	-7146	\N	C	2019-12-20 22:13:53.799521+00	2559
7145	-2989	13	173	KFL 4634@Kärl	\N	\N	1	1	-7145	\N	C	2019-12-20 22:13:53.799521+00	2560
7144	-2989	13	173	KFL 4633@Kärl	\N	\N	1	1	-7144	\N	C	2019-12-20 22:13:53.799521+00	2561
7143	-2989	13	173	KFL 4632@Kärl	\N	\N	1	1	-7143	\N	C	2019-12-20 22:13:53.799521+00	2562
7142	-2989	13	173	KFL 4631@Kärl	\N	\N	1	1	-7142	\N	C	2019-12-20 22:13:53.799521+00	2563
7141	-2989	13	173	KFL 4630@Kärl	\N	\N	1	1	-7141	\N	C	2019-12-20 22:13:53.799521+00	2564
7140	-2989	13	173	KFL 4629@Kärl	\N	\N	1	1	-7140	\N	C	2019-12-20 22:13:53.799521+00	2565
7139	-2989	13	173	KFL 4628@Kärl	\N	\N	1	1	-7139	\N	C	2019-12-20 22:13:53.799521+00	2566
7138	-2989	13	173	KFL 4627@Kärl	\N	\N	1	1	-7138	\N	C	2019-12-20 22:13:53.799521+00	2567
7137	-2989	13	173	KFL 4626@Kärl	\N	\N	1	1	-7137	\N	C	2019-12-20 22:13:53.799521+00	2568
7136	-2989	13	173	KFL 4625@Kärl	\N	\N	1	1	-7136	\N	C	2019-12-20 22:13:53.799521+00	2569
7135	-2989	13	173	KFL 4623@Kärl	\N	\N	1	1	-7135	\N	C	2019-12-20 22:13:53.799521+00	2570
7134	-2989	13	173	KFL 4622@Kärl	\N	\N	1	1	-7134	\N	C	2019-12-20 22:13:53.799521+00	2571
7133	-2989	13	173	KFL 4621@Kärl	\N	\N	1	1	-7133	\N	C	2019-12-20 22:13:53.799521+00	2572
7132	-2989	13	173	KFL 4620@Kärl	\N	\N	1	1	-7132	\N	C	2019-12-20 22:13:53.799521+00	2573
7131	-2989	13	173	KFL 4619@Kärl	\N	\N	1	1	-7131	\N	C	2019-12-20 22:13:53.799521+00	2574
7130	-2989	13	173	KFL 4618@Kärl	\N	\N	1	1	-7130	\N	C	2019-12-20 22:13:53.799521+00	2575
7129	-2989	13	173	KFL 4617@Kärl	\N	\N	1	1	-7129	\N	C	2019-12-20 22:13:53.799521+00	2576
7128	-2989	13	173	KFL 4616@Kärl	\N	\N	1	1	-7128	\N	C	2019-12-20 22:13:53.799521+00	2577
7127	-3099	13	173	KFL 4615@Kärl@C 24137	\N	\N	1	1	-7127	\N	C	2019-12-20 22:13:53.799521+00	2578
7126	-3099	13	173	KFL 4614@Kärl@C 26901	\N	\N	1	1	-7126	\N	C	2019-12-20 22:13:53.799521+00	2579
7125	-3099	13	173	KFL 4613@Kärl@C 1999	\N	\N	1	1	-7125	\N	C	2019-12-20 22:13:53.799521+00	2580
7124	-3099	13	173	KFL 4612@Kärl@C 24711	\N	\N	1	1	-7124	\N	C	2019-12-20 22:13:53.799521+00	2581
7123	-3099	13	173	KFL 4611@Kärl@C 24712	\N	\N	1	1	-7123	\N	C	2019-12-20 22:13:53.799521+00	2582
7122	-3099	13	173	KFL 4610@Kärl@HÖ 166	\N	\N	1	1	-7122	\N	C	2019-12-20 22:13:53.799521+00	2583
7121	-3099	13	173	KFL 4609@Kärl@1978-36-2	\N	\N	1	1	-7121	\N	C	2019-12-20 22:13:53.799521+00	2584
7120	-3099	13	173	KFL 4608@Kärl@C 3252	\N	\N	1	1	-7120	\N	C	2019-12-20 22:13:53.799521+00	2585
7119	-3309	13	173	KFL 4607@Kärl	\N	\N	1	1	-7119	\N	C	2019-12-20 22:13:53.799521+00	2586
7118	-3309	13	173	KFL 4606@Kärl	\N	\N	1	1	-7118	\N	C	2019-12-20 22:13:53.799521+00	2587
7117	-3309	13	173	KFL 4605@Kärl	\N	\N	1	1	-7117	\N	C	2019-12-20 22:13:53.799521+00	2588
7116	-3306	13	173	KFL 4604@Lerklining	\N	\N	1	1	-7116	\N	C	2019-12-20 22:13:53.799521+00	2589
7115	-3306	13	173	KFL 4603@Kärl	\N	\N	1	1	-7115	\N	C	2019-12-20 22:13:53.799521+00	2590
7114	-3306	13	173	KFL 4602@Kärl	\N	\N	1	1	-7114	\N	C	2019-12-20 22:13:53.799521+00	2591
7113	-3306	13	173	KFL 4601@Kärl	\N	\N	1	1	-7113	\N	C	2019-12-20 22:13:53.799521+00	2592
7112	-3306	13	173	KFL 4600@Kärl	\N	\N	1	1	-7112	\N	C	2019-12-20 22:13:53.799521+00	2593
7111	-3306	13	173	KFL 4599@Kärl	\N	\N	1	1	-7111	\N	C	2019-12-20 22:13:53.799521+00	2594
7110	-3306	13	173	KFL 4598@Kärl	\N	\N	1	1	-7110	\N	C	2019-12-20 22:13:53.799521+00	2595
7109	-3306	13	173	KFL 4597@Kärl	\N	\N	1	1	-7109	\N	C	2019-12-20 22:13:53.799521+00	2596
7108	-3306	13	173	KFL 4596@Kärl	\N	\N	1	1	-7108	\N	C	2019-12-20 22:13:53.799521+00	2597
7107	-3306	13	173	KFL 4595@Kärl	\N	\N	1	1	-7107	\N	C	2019-12-20 22:13:53.799521+00	2598
7106	-3306	13	173	KFL 4594@Kärl	\N	\N	1	1	-7106	\N	C	2019-12-20 22:13:53.799521+00	2599
7105	-3306	13	173	KFL 4593@Kärl	\N	\N	1	1	-7105	\N	C	2019-12-20 22:13:53.799521+00	2600
7104	-3306	13	173	KFL 4592@Kärl@153	\N	\N	1	1	-7104	\N	C	2019-12-20 22:13:53.799521+00	2601
7103	-3306	13	173	KFL 4591@Kärl	\N	\N	1	1	-7103	\N	C	2019-12-20 22:13:53.799521+00	2602
7102	-3306	13	173	KFL 4590@Kärl	\N	\N	1	1	-7102	\N	C	2019-12-20 22:13:53.799521+00	2603
7101	-3306	13	173	KFL 4589@Kärl	\N	\N	1	1	-7101	\N	C	2019-12-20 22:13:53.799521+00	2604
7100	-3306	13	173	KFL 4588@Kärl	\N	\N	1	1	-7100	\N	C	2019-12-20 22:13:53.799521+00	2605
7099	-3306	13	173	KFL 4587@Kärl	\N	\N	1	1	-7099	\N	C	2019-12-20 22:13:53.799521+00	2606
7098	-3306	13	173	KFL 4586@Kärl	\N	\N	1	1	-7098	\N	C	2019-12-20 22:13:53.799521+00	2607
7097	-3383	13	173	KFL 4585@Kärl	\N	\N	1	1	-7097	\N	C	2019-12-20 22:13:53.799521+00	2608
7096	-3383	13	173	KFL 4584@Kärl	\N	\N	1	1	-7096	\N	C	2019-12-20 22:13:53.799521+00	2609
7095	-3382	13	173	KFL 4583@Kärl	\N	\N	1	1	-7095	\N	C	2019-12-20 22:13:53.799521+00	2610
7094	-3382	13	173	KFL 4582@Kärl	\N	\N	1	1	-7094	\N	C	2019-12-20 22:13:53.799521+00	2611
7093	-3382	13	173	KFL 4581@Kärl	\N	\N	1	1	-7093	\N	C	2019-12-20 22:13:53.799521+00	2612
7092	-3377	13	173	KFL 4580@Kärl@13	\N	\N	1	1	-7092	\N	C	2019-12-20 22:13:53.799521+00	2613
7091	-3377	13	173	KFL 4579@Kärl	\N	\N	1	1	-7091	\N	C	2019-12-20 22:13:53.799521+00	2614
7090	-3377	13	173	KFL 4578@Kärl@5	\N	\N	1	1	-7090	\N	C	2019-12-20 22:13:53.799521+00	2615
7089	-3377	13	173	KFL 4577@Kärl@12	\N	\N	1	1	-7089	\N	C	2019-12-20 22:13:53.799521+00	2616
7088	-3377	13	173	KFL 4576@Kärl@11	\N	\N	1	1	-7088	\N	C	2019-12-20 22:13:53.799521+00	2617
7087	-3377	13	173	KFL 4575@Kärl@9?	\N	\N	1	1	-7087	\N	C	2019-12-20 22:13:53.799521+00	2618
7086	-3377	13	173	KFL 4574@Kärl@8	\N	\N	1	1	-7086	\N	C	2019-12-20 22:13:53.799521+00	2619
7085	-3377	13	173	KFL 4573@Kärl@7	\N	\N	1	1	-7085	\N	C	2019-12-20 22:13:53.799521+00	2620
7084	-3377	13	173	KFL 4572@Kärl@6	\N	\N	1	1	-7084	\N	C	2019-12-20 22:13:53.799521+00	2621
7083	-3377	13	173	KFL 4571@Kärl@4	\N	\N	1	1	-7083	\N	C	2019-12-20 22:13:53.799521+00	2622
7082	-3377	13	173	KFL 4570@Kärl@3	\N	\N	1	1	-7082	\N	C	2019-12-20 22:13:53.799521+00	2623
7081	-3377	13	173	KFL 4569@Kärl@2	\N	\N	1	1	-7081	\N	C	2019-12-20 22:13:53.799521+00	2624
7080	-3377	13	173	KFL 4568@Kärl@1	\N	\N	1	1	-7080	\N	C	2019-12-20 22:13:53.799521+00	2625
7079	-3237	13	173	KFL 4567@Kärl	\N	\N	1	1	-7079	\N	C	2019-12-20 22:13:53.799521+00	2626
7078	-3237	13	173	KFL 4566@Kärl	\N	\N	1	1	-7078	\N	C	2019-12-20 22:13:53.799521+00	2627
7077	-3237	13	173	KFL 4565@Kärl	\N	\N	1	1	-7077	\N	C	2019-12-20 22:13:53.799521+00	2628
7076	-3237	13	173	KFL 4564@Kärl	\N	\N	1	1	-7076	\N	C	2019-12-20 22:13:53.799521+00	2629
7075	-3206	13	173	KFL 4563@Kärl	\N	\N	1	1	-7075	\N	C	2019-12-20 22:13:53.799521+00	2630
7074	-3206	13	173	KFL 4562@Kärl	\N	\N	1	1	-7074	\N	C	2019-12-20 22:13:53.799521+00	2631
7073	-3084	13	173	KFL 4561@Kärl	\N	\N	1	1	-7073	\N	C	2019-12-20 22:13:53.799521+00	2632
7072	-3084	13	173	KFL 4560@Kärl	\N	\N	1	1	-7072	\N	C	2019-12-20 22:13:53.799521+00	2633
7071	-3084	13	173	KFL 4559@Kärl	\N	\N	1	1	-7071	\N	C	2019-12-20 22:13:53.799521+00	2634
7070	-3084	13	173	KFL 4558@Kärl	\N	\N	1	1	-7070	\N	C	2019-12-20 22:13:53.799521+00	2635
7069	-3084	13	173	KFL 4557@Kärl	\N	\N	1	1	-7069	\N	C	2019-12-20 22:13:53.799521+00	2636
7068	-3084	13	173	KFL 4556@Kärl	\N	\N	1	1	-7068	\N	C	2019-12-20 22:13:53.799521+00	2637
7067	-3084	13	173	KFL 4555@Kärl	\N	\N	1	1	-7067	\N	C	2019-12-20 22:13:53.799521+00	2638
7066	-3084	13	173	KFL 4554@Kärl	\N	\N	1	1	-7066	\N	C	2019-12-20 22:13:53.799521+00	2639
7065	-3084	13	173	KFL 4553@Kärl	\N	\N	1	1	-7065	\N	C	2019-12-20 22:13:53.799521+00	2640
7064	-3084	13	173	KFL 4552@Kärl	\N	\N	1	1	-7064	\N	C	2019-12-20 22:13:53.799521+00	2641
7063	-3084	13	173	KFL 4551@Kärl	\N	\N	1	1	-7063	\N	C	2019-12-20 22:13:53.799521+00	2642
7062	-3318	13	173	KFL 4550@Jordprov	\N	\N	1	1	-7062	\N	C	2019-12-20 22:13:53.799521+00	2643
7061	-3318	13	173	KFL 4549@Jordprov	\N	\N	1	1	-7061	\N	C	2019-12-20 22:13:53.799521+00	2644
7060	-3318	13	173	KFL 4548@Jordprov	\N	\N	1	1	-7060	\N	C	2019-12-20 22:13:53.799521+00	2645
7059	-3318	13	173	KFL 4547@Jordprov	\N	\N	1	1	-7059	\N	C	2019-12-20 22:13:53.799521+00	2646
7058	-3318	13	173	KFL 4546@Kärl@76	\N	\N	1	1	-7058	\N	C	2019-12-20 22:13:53.799521+00	2647
7057	-3318	13	173	KFL 4545@Kärl@6	\N	\N	1	1	-7057	\N	C	2019-12-20 22:13:53.799521+00	2648
7056	-3318	13	173	KFL 4544@Kärl@62	\N	\N	1	1	-7056	\N	C	2019-12-20 22:13:53.799521+00	2649
7055	-3318	13	173	KFL 4543@Kärl@32	\N	\N	1	1	-7055	\N	C	2019-12-20 22:13:53.799521+00	2650
7054	-3318	13	173	KFL 4542@Kärl	\N	\N	1	1	-7054	\N	C	2019-12-20 22:13:53.799521+00	2651
7053	-3318	13	173	KFL 4541@Kärl@33	\N	\N	1	1	-7053	\N	C	2019-12-20 22:13:53.799521+00	2652
7052	-3318	13	173	KFL 4540@Kärl@43	\N	\N	1	1	-7052	\N	C	2019-12-20 22:13:53.799521+00	2653
7051	-3318	13	173	KFL 4539@Kärl	\N	\N	1	1	-7051	\N	C	2019-12-20 22:13:53.799521+00	2654
7050	-3318	13	173	KFL 4538@Kärl@54	\N	\N	1	1	-7050	\N	C	2019-12-20 22:13:53.799521+00	2655
7049	-3318	13	173	KFL 4537@Kärl@41	\N	\N	1	1	-7049	\N	C	2019-12-20 22:13:53.799521+00	2656
7048	-3318	13	173	KFL 4536@Kärl@42	\N	\N	1	1	-7048	\N	C	2019-12-20 22:13:53.799521+00	2657
7047	-3318	13	173	KFL 4535@Kärl	\N	\N	1	1	-7047	\N	C	2019-12-20 22:13:53.799521+00	2658
7046	-3318	13	173	KFL 4534@Kärl@35	\N	\N	1	1	-7046	\N	C	2019-12-20 22:13:53.799521+00	2659
7045	-3318	13	173	KFL 4533@Kärl	\N	\N	1	1	-7045	\N	C	2019-12-20 22:13:53.799521+00	2660
7044	-3318	13	173	KFL 4532@Kärl	\N	\N	1	1	-7044	\N	C	2019-12-20 22:13:53.799521+00	2661
7043	-3318	13	173	KFL 4531@Kärl	\N	\N	1	1	-7043	\N	C	2019-12-20 22:13:53.799521+00	2662
7042	-3318	13	173	KFL 4530@Kärl	\N	\N	1	1	-7042	\N	C	2019-12-20 22:13:53.799521+00	2663
7041	-3318	13	173	KFL 4529@Kärl	\N	\N	1	1	-7041	\N	C	2019-12-20 22:13:53.799521+00	2664
7040	-3318	13	173	KFL 4528@Kärl	\N	\N	1	1	-7040	\N	C	2019-12-20 22:13:53.799521+00	2665
7039	-3289	13	173	KFL 4527@Lerklining	\N	\N	1	1	-7039	\N	C	2019-12-20 22:13:53.799521+00	2666
7038	-3289	13	173	KFL 4526@Jordprov	\N	\N	1	1	-7038	\N	C	2019-12-20 22:13:53.799521+00	2667
7037	-3289	13	173	KFL 4525@Kärl	\N	\N	1	1	-7037	\N	C	2019-12-20 22:13:53.799521+00	2668
7036	-3289	13	173	KFL 4524@Kärl	\N	\N	1	1	-7036	\N	C	2019-12-20 22:13:53.799521+00	2669
7035	-3289	13	173	KFL 4523@Kärl@107	\N	\N	1	1	-7035	\N	C	2019-12-20 22:13:53.799521+00	2670
7034	-3289	13	173	KFL 4522@Kärl	\N	\N	1	1	-7034	\N	C	2019-12-20 22:13:53.799521+00	2671
7033	-3289	13	173	KFL 4521@Kärl	\N	\N	1	1	-7033	\N	C	2019-12-20 22:13:53.799521+00	2672
7032	-3289	13	173	KFL 4520@Kärl	\N	\N	1	1	-7032	\N	C	2019-12-20 22:13:53.799521+00	2673
7031	-3289	13	173	KFL 4519@Kärl@61	\N	\N	1	1	-7031	\N	C	2019-12-20 22:13:53.799521+00	2674
7030	-3289	13	173	KFL 4518@Kärl	\N	\N	1	1	-7030	\N	C	2019-12-20 22:13:53.799521+00	2675
7029	-3289	13	173	KFL 4517@Kärl	\N	\N	1	1	-7029	\N	C	2019-12-20 22:13:53.799521+00	2676
7028	-3289	13	173	KFL 4516@Kärl@63	\N	\N	1	1	-7028	\N	C	2019-12-20 22:13:53.799521+00	2677
7027	-3289	13	173	KFL 4515@Kärl@93	\N	\N	1	1	-7027	\N	C	2019-12-20 22:13:53.799521+00	2678
7026	-3289	13	173	KFL 4514@Kärl@85	\N	\N	1	1	-7026	\N	C	2019-12-20 22:13:53.799521+00	2679
7025	-3289	13	173	KFL 4513@Kärl@58	\N	\N	1	1	-7025	\N	C	2019-12-20 22:13:53.799521+00	2680
7024	-3289	13	173	KFL 4512@Kärl	\N	\N	1	1	-7024	\N	C	2019-12-20 22:13:53.799521+00	2681
7023	-3289	13	173	KFL 4511@Kärl@55	\N	\N	1	1	-7023	\N	C	2019-12-20 22:13:53.799521+00	2682
7022	-3289	13	173	KFL 4510@Kärl@52	\N	\N	1	1	-7022	\N	C	2019-12-20 22:13:53.799521+00	2683
7021	-3289	13	173	KFL 4509@Kärl@33	\N	\N	1	1	-7021	\N	C	2019-12-20 22:13:53.799521+00	2684
7020	-3289	13	173	KFL 4508@Kärl@32	\N	\N	1	1	-7020	\N	C	2019-12-20 22:13:53.799521+00	2685
7019	-3289	13	173	KFL 4507@Kärl@16	\N	\N	1	1	-7019	\N	C	2019-12-20 22:13:53.799521+00	2686
7018	-3289	13	173	KFL 4506@Kärl@15	\N	\N	1	1	-7018	\N	C	2019-12-20 22:13:53.799521+00	2687
7017	-3289	13	173	KFL 4505@Kärl@14	\N	\N	1	1	-7017	\N	C	2019-12-20 22:13:53.799521+00	2688
7016	-3289	13	173	KFL 4504@Kärl@12	\N	\N	1	1	-7016	\N	C	2019-12-20 22:13:53.799521+00	2689
7015	-3289	13	173	KFL 4503@Kärl@11	\N	\N	1	1	-7015	\N	C	2019-12-20 22:13:53.799521+00	2690
7014	-3289	13	173	KFL 4502@Kärl@76	\N	\N	1	1	-7014	\N	C	2019-12-20 22:13:53.799521+00	2691
7013	-3289	13	173	KFL 4501@Kärl@8	\N	\N	1	1	-7013	\N	C	2019-12-20 22:13:53.799521+00	2692
7012	-3289	13	173	KFL 4500@Kärl@6	\N	\N	1	1	-7012	\N	C	2019-12-20 22:13:53.799521+00	2693
7011	-3289	13	173	KFL 4499@Kärl@2	\N	\N	1	1	-7011	\N	C	2019-12-20 22:13:53.799521+00	2694
7010	-3289	13	173	KFL 4498@Kärl@72	\N	\N	1	1	-7010	\N	C	2019-12-20 22:13:53.799521+00	2695
7009	-3289	13	173	KFL 4497@Kärl@78	\N	\N	1	1	-7009	\N	C	2019-12-20 22:13:53.799521+00	2696
7008	-3065	13	173	KFL 4496@Jordprov	\N	\N	1	1	-7008	\N	C	2019-12-20 22:13:53.799521+00	2697
7007	-3065	13	173	KFL 4495@Jordprov	\N	\N	1	1	-7007	\N	C	2019-12-20 22:13:53.799521+00	2698
7006	-3065	13	173	KFL 4494@Jordprov	\N	\N	1	1	-7006	\N	C	2019-12-20 22:13:53.799521+00	2699
7005	-3065	13	173	KFL 4493@Kärl@1	\N	\N	1	1	-7005	\N	C	2019-12-20 22:13:53.799521+00	2700
7004	-3065	13	173	KFL 4492@Kärl@2	\N	\N	1	1	-7004	\N	C	2019-12-20 22:13:53.799521+00	2701
7003	-3065	13	173	KFL 4491@Kärl@3	\N	\N	1	1	-7003	\N	C	2019-12-20 22:13:53.799521+00	2702
7002	-3065	13	173	KFL 4490@Kärl@5	\N	\N	1	1	-7002	\N	C	2019-12-20 22:13:53.799521+00	2703
7001	-3065	13	173	KFL 4489@Kärl	\N	\N	1	1	-7001	\N	C	2019-12-20 22:13:53.799521+00	2704
7000	-3065	13	173	KFL 4488@Kärl	\N	\N	1	1	-7000	\N	C	2019-12-20 22:13:53.799521+00	2705
6999	-3065	13	173	KFL 4487@Kärl	\N	\N	1	1	-6999	\N	C	2019-12-20 22:13:53.799521+00	2706
6998	-3065	13	173	KFL 4486@Kärl	\N	\N	1	1	-6998	\N	C	2019-12-20 22:13:53.799521+00	2707
6997	-3065	13	173	KFL 4485@Kärl	\N	\N	1	1	-6997	\N	C	2019-12-20 22:13:53.799521+00	2708
6996	-3041	13	173	KFL 4484@Kärl	\N	\N	1	1	-6996	\N	C	2019-12-20 22:13:53.799521+00	2709
6995	-3041	13	173	KFL 4483@Kärl	\N	\N	1	1	-6995	\N	C	2019-12-20 22:13:53.799521+00	2710
6994	-3041	13	173	KFL 4482@Kärl	\N	\N	1	1	-6994	\N	C	2019-12-20 22:13:53.799521+00	2711
6993	-3366	13	173	KFL 4481@Kärl	\N	\N	1	1	-6993	\N	C	2019-12-20 22:13:53.799521+00	2712
6992	-3366	13	173	KFL 4480@Kärl	\N	\N	1	1	-6992	\N	C	2019-12-20 22:13:53.799521+00	2713
6991	-3366	13	173	KFL 4479@Kärl	\N	\N	1	1	-6991	\N	C	2019-12-20 22:13:53.799521+00	2714
6990	-3366	13	173	KFL 4478@Kärl	\N	\N	1	1	-6990	\N	C	2019-12-20 22:13:53.799521+00	2715
6989	-3366	13	173	KFL 4477@Kärl	\N	\N	1	1	-6989	\N	C	2019-12-20 22:13:53.799521+00	2716
6988	-3366	13	173	KFL 4476@Kärl	\N	\N	1	1	-6988	\N	C	2019-12-20 22:13:53.799521+00	2717
6987	-3366	13	173	KFL 4475@Kärl	\N	\N	1	1	-6987	\N	C	2019-12-20 22:13:53.799521+00	2718
6986	-3008	13	173	KFL 4474@Kärl	\N	\N	1	1	-6986	\N	C	2019-12-20 22:13:53.799521+00	2719
6985	-3008	13	173	KFL 4473@Kärl	\N	\N	1	1	-6985	\N	C	2019-12-20 22:13:53.799521+00	2720
6984	-3008	13	173	KFL 4472@Kärl	\N	\N	1	1	-6984	\N	C	2019-12-20 22:13:53.799521+00	2721
6983	-3008	13	173	KFL 4471@Kärl	\N	\N	1	1	-6983	\N	C	2019-12-20 22:13:53.799521+00	2722
6982	-3008	13	173	KFL 4470@Kärl	\N	\N	1	1	-6982	\N	C	2019-12-20 22:13:53.799521+00	2723
6981	-3198	13	173	KFL 4469@Kärl	\N	\N	1	1	-6981	\N	C	2019-12-20 22:13:53.799521+00	2724
6980	-3198	13	173	KFL 4468@Kärl	\N	\N	1	1	-6980	\N	C	2019-12-20 22:13:53.799521+00	2725
6979	-3110	13	173	KFL 4467@Kärl	\N	\N	1	1	-6979	\N	C	2019-12-20 22:13:53.799521+00	2726
6978	-3110	13	173	KFL 4466@Kärl	\N	\N	1	1	-6978	\N	C	2019-12-20 22:13:53.799521+00	2727
6977	-3110	13	173	KFL 4465@Kärl	\N	\N	1	1	-6977	\N	C	2019-12-20 22:13:53.799521+00	2728
6976	-3110	13	173	KFL 4464@Kärl	\N	\N	1	1	-6976	\N	C	2019-12-20 22:13:53.799521+00	2729
6975	-3110	13	173	KFL 4463@Kärl	\N	\N	1	1	-6975	\N	C	2019-12-20 22:13:53.799521+00	2730
6974	-3110	13	173	KFL 4462@Kärl	\N	\N	1	1	-6974	\N	C	2019-12-20 22:13:53.799521+00	2731
6973	-3110	13	173	KFL 4461@Kärl	\N	\N	1	1	-6973	\N	C	2019-12-20 22:13:53.799521+00	2732
6972	-3110	13	173	KFL 4460@Kärl	\N	\N	1	1	-6972	\N	C	2019-12-20 22:13:53.799521+00	2733
6971	-3110	13	173	KFL 4459@Kärl	\N	\N	1	1	-6971	\N	C	2019-12-20 22:13:53.799521+00	2734
6970	-3110	13	173	KFL 4458@Kärl	\N	\N	1	1	-6970	\N	C	2019-12-20 22:13:53.799521+00	2735
6969	-3110	13	173	KFL 4457@Kärl	\N	\N	1	1	-6969	\N	C	2019-12-20 22:13:53.799521+00	2736
6968	-3110	13	173	KFL 4456@Kärl	\N	\N	1	1	-6968	\N	C	2019-12-20 22:13:53.799521+00	2737
6967	-3150	13	173	KFL 4455@Gjutform	\N	\N	1	1	-6967	\N	C	2019-12-20 22:13:53.799521+00	2738
6966	-3150	13	173	KFL 4454@Gjutform	\N	\N	1	1	-6966	\N	C	2019-12-20 22:13:53.799521+00	2739
6965	-3150	13	173	KFL 4453@Gjutform	\N	\N	1	1	-6965	\N	C	2019-12-20 22:13:53.799521+00	2740
6964	-3150	13	173	KFL 4452@Gjutform	\N	\N	1	1	-6964	\N	C	2019-12-20 22:13:53.799521+00	2741
6963	-3150	13	173	KFL 4451@Degel	\N	\N	1	1	-6963	\N	C	2019-12-20 22:13:53.799521+00	2742
6962	-3150	13	173	KFL 4450@Degel	\N	\N	1	1	-6962	\N	C	2019-12-20 22:13:53.799521+00	2743
6961	-3150	13	173	KFL 4449@Degel	\N	\N	1	1	-6961	\N	C	2019-12-20 22:13:53.799521+00	2744
6960	-3150	13	173	KFL 4448@Degel	\N	\N	1	1	-6960	\N	C	2019-12-20 22:13:53.799521+00	2745
6959	-3150	13	173	KFL 4447@Lerklining	\N	\N	1	1	-6959	\N	C	2019-12-20 22:13:53.799521+00	2746
6958	-3072	13	173	KFL 4446@Kärl	\N	\N	1	1	-6958	\N	C	2019-12-20 22:13:53.799521+00	2747
6957	-3072	13	173	KFL 4445@Kärl	\N	\N	1	1	-6957	\N	C	2019-12-20 22:13:53.799521+00	2748
6956	-3072	13	173	KFL 4444@Kärl	\N	\N	1	1	-6956	\N	C	2019-12-20 22:13:53.799521+00	2749
6955	-3072	13	173	KFL 4443@Kärl	\N	\N	1	1	-6955	\N	C	2019-12-20 22:13:53.799521+00	2750
6954	-3072	13	173	KFL 4442@Kärl	\N	\N	1	1	-6954	\N	C	2019-12-20 22:13:53.799521+00	2751
6953	-3072	13	173	KFL 4441@Kärl	\N	\N	1	1	-6953	\N	C	2019-12-20 22:13:53.799521+00	2752
6952	-3072	13	173	KFL 4440@Kärl	\N	\N	1	1	-6952	\N	C	2019-12-20 22:13:53.799521+00	2753
6951	-3072	13	173	KFL 4439@Kärl	\N	\N	1	1	-6951	\N	C	2019-12-20 22:13:53.799521+00	2754
6950	-3072	13	173	KFL 4438@Kärl	\N	\N	1	1	-6950	\N	C	2019-12-20 22:13:53.799521+00	2755
6949	-3072	13	173	KFL 4437@Kärl	\N	\N	1	1	-6949	\N	C	2019-12-20 22:13:53.799521+00	2756
6948	-3072	13	173	KFL 4436@Kärl	\N	\N	1	1	-6948	\N	C	2019-12-20 22:13:53.799521+00	2757
6947	-3072	13	173	KFL 4435@Kärl	\N	\N	1	1	-6947	\N	C	2019-12-20 22:13:53.799521+00	2758
6946	-3072	13	173	KFL 4434@Kärl	\N	\N	1	1	-6946	\N	C	2019-12-20 22:13:53.799521+00	2759
6945	-3072	13	173	KFL 4433@Kärl	\N	\N	1	1	-6945	\N	C	2019-12-20 22:13:53.799521+00	2760
6944	-3072	13	173	KFL 4432@Kärl	\N	\N	1	1	-6944	\N	C	2019-12-20 22:13:53.799521+00	2761
6943	-3072	13	173	KFL 4431@Kärl	\N	\N	1	1	-6943	\N	C	2019-12-20 22:13:53.799521+00	2762
6942	-3072	13	173	KFL 4430@Kärl	\N	\N	1	1	-6942	\N	C	2019-12-20 22:13:53.799521+00	2763
6941	-3072	13	173	KFL 4429@Kärl	\N	\N	1	1	-6941	\N	C	2019-12-20 22:13:53.799521+00	2764
6940	-3072	13	173	KFL 4428@Kärl	\N	\N	1	1	-6940	\N	C	2019-12-20 22:13:53.799521+00	2765
6939	-3072	13	173	KFL 4427@Kärl	\N	\N	1	1	-6939	\N	C	2019-12-20 22:13:53.799521+00	2766
6938	-3072	13	173	KFL 4426@Kärl	\N	\N	1	1	-6938	\N	C	2019-12-20 22:13:53.799521+00	2767
6937	-3072	13	173	KFL 4425@Kärl	\N	\N	1	1	-6937	\N	C	2019-12-20 22:13:53.799521+00	2768
6936	-3072	13	173	KFL 4424@Kärl	\N	\N	1	1	-6936	\N	C	2019-12-20 22:13:53.799521+00	2769
6935	-3072	13	173	KFL 4423@Kärl	\N	\N	1	1	-6935	\N	C	2019-12-20 22:13:53.799521+00	2770
6934	-3072	13	173	KFL 4422@Kärl	\N	\N	1	1	-6934	\N	C	2019-12-20 22:13:53.799521+00	2771
6933	-3072	13	173	KFL 4421@Kärl	\N	\N	1	1	-6933	\N	C	2019-12-20 22:13:53.799521+00	2772
6932	-3072	13	173	KFL 4420@Kärl	\N	\N	1	1	-6932	\N	C	2019-12-20 22:13:53.799521+00	2773
6931	-3072	13	173	KFL 4419@Kärl	\N	\N	1	1	-6931	\N	C	2019-12-20 22:13:53.799521+00	2774
6930	-3072	13	173	KFL 4418@Kärl	\N	\N	1	1	-6930	\N	C	2019-12-20 22:13:53.799521+00	2775
6929	-3072	13	173	KFL 4417@Kärl	\N	\N	1	1	-6929	\N	C	2019-12-20 22:13:53.799521+00	2776
6928	-3072	13	173	KFL 4416@Kärl	\N	\N	1	1	-6928	\N	C	2019-12-20 22:13:53.799521+00	2777
6927	-3072	13	173	KFL 4415@Kärl	\N	\N	1	1	-6927	\N	C	2019-12-20 22:13:53.799521+00	2778
6926	-3072	13	173	KFL 4414@Kärl	\N	\N	1	1	-6926	\N	C	2019-12-20 22:13:53.799521+00	2779
6925	-3072	13	173	KFL 4413@Kärl	\N	\N	1	1	-6925	\N	C	2019-12-20 22:13:53.799521+00	2780
6924	-3072	13	173	KFL 4412@Kärl	\N	\N	1	1	-6924	\N	C	2019-12-20 22:13:53.799521+00	2781
6923	-3072	13	173	KFL 4411@Kärl	\N	\N	1	1	-6923	\N	C	2019-12-20 22:13:53.799521+00	2782
6922	-3072	13	173	KFL 4410@Kärl	\N	\N	1	1	-6922	\N	C	2019-12-20 22:13:53.799521+00	2783
6921	-3072	13	173	KFL 4409@Kärl	\N	\N	1	1	-6921	\N	C	2019-12-20 22:13:53.799521+00	2784
6920	-3072	13	173	KFL 4408@Kärl	\N	\N	1	1	-6920	\N	C	2019-12-20 22:13:53.799521+00	2785
6919	-3072	13	173	KFL 4407@Kärl	\N	\N	1	1	-6919	\N	C	2019-12-20 22:13:53.799521+00	2786
6918	-3072	13	173	KFL 4406@Kärl	\N	\N	1	1	-6918	\N	C	2019-12-20 22:13:53.799521+00	2787
6917	-3072	13	173	KFL 4405@Kärl	\N	\N	1	1	-6917	\N	C	2019-12-20 22:13:53.799521+00	2788
6916	-3072	13	173	KFL 4404@Kärl	\N	\N	1	1	-6916	\N	C	2019-12-20 22:13:53.799521+00	2789
6915	-3072	13	173	KFL 4403@Kärl	\N	\N	1	1	-6915	\N	C	2019-12-20 22:13:53.799521+00	2790
6914	-3072	13	173	KFL 4402@Kärl	\N	\N	1	1	-6914	\N	C	2019-12-20 22:13:53.799521+00	2791
6913	-3072	13	173	KFL 4401@Kärl	\N	\N	1	1	-6913	\N	C	2019-12-20 22:13:53.799521+00	2792
6912	-3072	13	173	KFL 4400@Kärl	\N	\N	1	1	-6912	\N	C	2019-12-20 22:13:53.799521+00	2793
6911	-3072	13	173	KFL 4399@Kärl	\N	\N	1	1	-6911	\N	C	2019-12-20 22:13:53.799521+00	2794
6910	-3072	13	173	KFL 4398@Kärl	\N	\N	1	1	-6910	\N	C	2019-12-20 22:13:53.799521+00	2795
6909	-3072	13	173	KFL 4397@Kärl	\N	\N	1	1	-6909	\N	C	2019-12-20 22:13:53.799521+00	2796
6908	-3072	13	173	KFL 4396@Kärl	\N	\N	1	1	-6908	\N	C	2019-12-20 22:13:53.799521+00	2797
6907	-3072	13	173	KFL 4395@Kärl	\N	\N	1	1	-6907	\N	C	2019-12-20 22:13:53.799521+00	2798
6906	-3072	13	173	KFL 4394@Kärl	\N	\N	1	1	-6906	\N	C	2019-12-20 22:13:53.799521+00	2799
6905	-3072	13	173	KFL 4393@Kärl	\N	\N	1	1	-6905	\N	C	2019-12-20 22:13:53.799521+00	2800
6904	-3072	13	173	KFL 4392@Kärl	\N	\N	1	1	-6904	\N	C	2019-12-20 22:13:53.799521+00	2801
6903	-3072	13	173	KFL 4391@Kärl	\N	\N	1	1	-6903	\N	C	2019-12-20 22:13:53.799521+00	2802
6902	-3072	13	173	KFL 4390@Kärl	\N	\N	1	1	-6902	\N	C	2019-12-20 22:13:53.799521+00	2803
6901	-3072	13	173	KFL 4389@Kärl	\N	\N	1	1	-6901	\N	C	2019-12-20 22:13:53.799521+00	2804
6900	-3072	13	173	KFL 4388@Kärl	\N	\N	1	1	-6900	\N	C	2019-12-20 22:13:53.799521+00	2805
6899	-3072	13	173	KFL 4387@Kärl	\N	\N	1	1	-6899	\N	C	2019-12-20 22:13:53.799521+00	2806
6898	-3072	13	173	KFL 4386@Kärl	\N	\N	1	1	-6898	\N	C	2019-12-20 22:13:53.799521+00	2807
6897	-3072	13	173	KFL 4385@Kärl	\N	\N	1	1	-6897	\N	C	2019-12-20 22:13:53.799521+00	2808
6896	-3072	13	173	KFL 4384@Kärl	\N	\N	1	1	-6896	\N	C	2019-12-20 22:13:53.799521+00	2809
6895	-3072	13	173	KFL 4383@Kärl	\N	\N	1	1	-6895	\N	C	2019-12-20 22:13:53.799521+00	2810
6894	-3072	13	173	KFL 4382@Kärl	\N	\N	1	1	-6894	\N	C	2019-12-20 22:13:53.799521+00	2811
6893	-3072	13	173	KFL 4381@Kärl	\N	\N	1	1	-6893	\N	C	2019-12-20 22:13:53.799521+00	2812
6892	-3072	13	173	KFL 4380@Kärl	\N	\N	1	1	-6892	\N	C	2019-12-20 22:13:53.799521+00	2813
6891	-3072	13	173	KFL 4379@Kärl	\N	\N	1	1	-6891	\N	C	2019-12-20 22:13:53.799521+00	2814
6890	-3072	13	173	KFL 4378@Kärl	\N	\N	1	1	-6890	\N	C	2019-12-20 22:13:53.799521+00	2815
6889	-3072	13	173	KFL 4377@Kärl	\N	\N	1	1	-6889	\N	C	2019-12-20 22:13:53.799521+00	2816
6888	-3072	13	173	KFL 4376@Kärl	\N	\N	1	1	-6888	\N	C	2019-12-20 22:13:53.799521+00	2817
6887	-3072	13	173	KFL 4375@Kärl	\N	\N	1	1	-6887	\N	C	2019-12-20 22:13:53.799521+00	2818
6886	-3072	13	173	KFL 4374@Kärl	\N	\N	1	1	-6886	\N	C	2019-12-20 22:13:53.799521+00	2819
6885	-3072	13	173	KFL 4373@Kärl	\N	\N	1	1	-6885	\N	C	2019-12-20 22:13:53.799521+00	2820
6884	-3072	13	173	KFL 4372@Kärl	\N	\N	1	1	-6884	\N	C	2019-12-20 22:13:53.799521+00	2821
6883	-3072	13	173	KFL 4371@Kärl	\N	\N	1	1	-6883	\N	C	2019-12-20 22:13:53.799521+00	2822
6882	-3072	13	173	KFL 4370@Kärl	\N	\N	1	1	-6882	\N	C	2019-12-20 22:13:53.799521+00	2823
6881	-3072	13	173	KFL 4369@Kärl	\N	\N	1	1	-6881	\N	C	2019-12-20 22:13:53.799521+00	2824
6880	-3072	13	173	KFL 4368@Kärl	\N	\N	1	1	-6880	\N	C	2019-12-20 22:13:53.799521+00	2825
6879	-3072	13	173	KFL 4367@Kärl	\N	\N	1	1	-6879	\N	C	2019-12-20 22:13:53.799521+00	2826
6878	-3072	13	173	KFL 4366@Kärl	\N	\N	1	1	-6878	\N	C	2019-12-20 22:13:53.799521+00	2827
6877	-3072	13	173	KFL 4365@Kärl	\N	\N	1	1	-6877	\N	C	2019-12-20 22:13:53.799521+00	2828
6876	-3072	13	173	KFL 4364@Kärl	\N	\N	1	1	-6876	\N	C	2019-12-20 22:13:53.799521+00	2829
6875	-3072	13	173	KFL 4363@Kärl	\N	\N	1	1	-6875	\N	C	2019-12-20 22:13:53.799521+00	2830
6874	-3072	13	173	KFL 4362@Kärl	\N	\N	1	1	-6874	\N	C	2019-12-20 22:13:53.799521+00	2831
6873	-3072	13	173	KFL 4361@Kärl	\N	\N	1	1	-6873	\N	C	2019-12-20 22:13:53.799521+00	2832
6872	-3072	13	173	KFL 4360@Kärl	\N	\N	1	1	-6872	\N	C	2019-12-20 22:13:53.799521+00	2833
6871	-3072	13	173	KFL 4359@Kärl	\N	\N	1	1	-6871	\N	C	2019-12-20 22:13:53.799521+00	2834
6870	-3072	13	173	KFL 4358@Kärl	\N	\N	1	1	-6870	\N	C	2019-12-20 22:13:53.799521+00	2835
6869	-3072	13	173	KFL 4357@Kärl	\N	\N	1	1	-6869	\N	C	2019-12-20 22:13:53.799521+00	2836
6868	-3072	13	173	KFL 4356@Kärl	\N	\N	1	1	-6868	\N	C	2019-12-20 22:13:53.799521+00	2837
6867	-3072	13	173	KFL 4355@Kärl	\N	\N	1	1	-6867	\N	C	2019-12-20 22:13:53.799521+00	2838
6866	-3072	13	173	KFL 4354@Kärl	\N	\N	1	1	-6866	\N	C	2019-12-20 22:13:53.799521+00	2839
6865	-3072	13	173	KFL 4353@Kärl	\N	\N	1	1	-6865	\N	C	2019-12-20 22:13:53.799521+00	2840
6864	-3072	13	173	KFL 4352@Kärl	\N	\N	1	1	-6864	\N	C	2019-12-20 22:13:53.799521+00	2841
6863	-3072	13	173	KFL 4351@Kärl	\N	\N	1	1	-6863	\N	C	2019-12-20 22:13:53.799521+00	2842
6862	-3072	13	173	KFL 4350@Kärl	\N	\N	1	1	-6862	\N	C	2019-12-20 22:13:53.799521+00	2843
6861	-3072	13	173	KFL 4349@Kärl	\N	\N	1	1	-6861	\N	C	2019-12-20 22:13:53.799521+00	2844
6860	-3072	13	173	KFL 4348@Kärl	\N	\N	1	1	-6860	\N	C	2019-12-20 22:13:53.799521+00	2845
6859	-3072	13	173	KFL 4347@Kärl	\N	\N	1	1	-6859	\N	C	2019-12-20 22:13:53.799521+00	2846
6858	-3072	13	173	KFL 4346@Degel	\N	\N	1	1	-6858	\N	C	2019-12-20 22:13:53.799521+00	2847
6857	-3072	13	173	KFL 4345@Kärl	\N	\N	1	1	-6857	\N	C	2019-12-20 22:13:53.799521+00	2848
6856	-3072	13	173	KFL 4344@Kärl	\N	\N	1	1	-6856	\N	C	2019-12-20 22:13:53.799521+00	2849
6855	-3072	13	173	KFL 4343@Kärl	\N	\N	1	1	-6855	\N	C	2019-12-20 22:13:53.799521+00	2850
6854	-3072	13	173	KFL 4342@Kärl	\N	\N	1	1	-6854	\N	C	2019-12-20 22:13:53.799521+00	2851
6853	-3072	13	173	KFL 4340@Kärl	\N	\N	1	1	-6853	\N	C	2019-12-20 22:13:53.799521+00	2852
6852	-3072	13	173	KFL 4339@Kärl	\N	\N	1	1	-6852	\N	C	2019-12-20 22:13:53.799521+00	2853
6851	-3072	13	173	KFL 4338@Kärl	\N	\N	1	1	-6851	\N	C	2019-12-20 22:13:53.799521+00	2854
6850	-3072	13	173	KFL 4337@Kärl	\N	\N	1	1	-6850	\N	C	2019-12-20 22:13:53.799521+00	2855
6849	-3072	13	173	KFL 4336@Kärl	\N	\N	1	1	-6849	\N	C	2019-12-20 22:13:53.799521+00	2856
6848	-3072	13	173	KFL 4335@Kärl	\N	\N	1	1	-6848	\N	C	2019-12-20 22:13:53.799521+00	2857
6847	-3072	13	173	KFL 4334@Kärl	\N	\N	1	1	-6847	\N	C	2019-12-20 22:13:53.799521+00	2858
6846	-3072	13	173	KFL 4333@Kärl	\N	\N	1	1	-6846	\N	C	2019-12-20 22:13:53.799521+00	2859
6845	-3072	13	173	KFL 4332@Kärl	\N	\N	1	1	-6845	\N	C	2019-12-20 22:13:53.799521+00	2860
6844	-3072	13	173	KFL 4331@Kärl	\N	\N	1	1	-6844	\N	C	2019-12-20 22:13:53.799521+00	2861
6843	-3072	13	173	KFL 4330@Kärl	\N	\N	1	1	-6843	\N	C	2019-12-20 22:13:53.799521+00	2862
6842	-3072	13	173	KFL 4329@Kärl	\N	\N	1	1	-6842	\N	C	2019-12-20 22:13:53.799521+00	2863
6841	-3072	13	173	KFL 4328@Kärl	\N	\N	1	1	-6841	\N	C	2019-12-20 22:13:53.799521+00	2864
6840	-3072	13	173	KFL 4327@Kärl	\N	\N	1	1	-6840	\N	C	2019-12-20 22:13:53.799521+00	2865
6839	-3072	13	173	KFL 4326@Kärl	\N	\N	1	1	-6839	\N	C	2019-12-20 22:13:53.799521+00	2866
6838	-3072	13	173	KFL 4325@Kärl	\N	\N	1	1	-6838	\N	C	2019-12-20 22:13:53.799521+00	2867
6837	-3072	13	173	KFL 4324@Kärl	\N	\N	1	1	-6837	\N	C	2019-12-20 22:13:53.799521+00	2868
6836	-3072	13	173	KFL 4323@Kärl	\N	\N	1	1	-6836	\N	C	2019-12-20 22:13:53.799521+00	2869
6835	-3072	13	173	KFL 4322@Kärl	\N	\N	1	1	-6835	\N	C	2019-12-20 22:13:53.799521+00	2870
6834	-3072	13	173	KFL 4321@Kärl	\N	\N	1	1	-6834	\N	C	2019-12-20 22:13:53.799521+00	2871
6833	-3072	13	173	KFL 4320@Kärl	\N	\N	1	1	-6833	\N	C	2019-12-20 22:13:53.799521+00	2872
6832	-3072	13	173	KFL 4319@Kärl	\N	\N	1	1	-6832	\N	C	2019-12-20 22:13:53.799521+00	2873
6831	-3072	13	173	KFL 4318@Kärl	\N	\N	1	1	-6831	\N	C	2019-12-20 22:13:53.799521+00	2874
6830	-3072	13	173	KFL 4317@Kärl	\N	\N	1	1	-6830	\N	C	2019-12-20 22:13:53.799521+00	2875
6829	-3072	13	173	KFL 4316@Kärl	\N	\N	1	1	-6829	\N	C	2019-12-20 22:13:53.799521+00	2876
6828	-3072	13	173	KFL 4315@Kärl	\N	\N	1	1	-6828	\N	C	2019-12-20 22:13:53.799521+00	2877
6827	-3072	13	173	KFL 4314@Kärl	\N	\N	1	1	-6827	\N	C	2019-12-20 22:13:53.799521+00	2878
6826	-3072	13	173	KFL 4313@Kärl	\N	\N	1	1	-6826	\N	C	2019-12-20 22:13:53.799521+00	2879
6825	-3072	13	173	KFL 4312@Kärl	\N	\N	1	1	-6825	\N	C	2019-12-20 22:13:53.799521+00	2880
6824	-3072	13	173	KFL 4311@Kärl	\N	\N	1	1	-6824	\N	C	2019-12-20 22:13:53.799521+00	2881
6823	-3072	13	173	KFL 4310@Kärl	\N	\N	1	1	-6823	\N	C	2019-12-20 22:13:53.799521+00	2882
6822	-3072	13	173	KFL 4309@Kärl	\N	\N	1	1	-6822	\N	C	2019-12-20 22:13:53.799521+00	2883
6821	-3072	13	173	KFL 4308@Kärl	\N	\N	1	1	-6821	\N	C	2019-12-20 22:13:53.799521+00	2884
6820	-3072	13	173	KFL 4307@Kärl	\N	\N	1	1	-6820	\N	C	2019-12-20 22:13:53.799521+00	2885
6819	-3072	13	173	KFL 4306@Kärl	\N	\N	1	1	-6819	\N	C	2019-12-20 22:13:53.799521+00	2886
6818	-3072	13	173	KFL 4305@Kärl	\N	\N	1	1	-6818	\N	C	2019-12-20 22:13:53.799521+00	2887
6817	-3072	13	173	KFL 4304@Kärl	\N	\N	1	1	-6817	\N	C	2019-12-20 22:13:53.799521+00	2888
6816	-3072	13	173	KFL 4303@Kärl	\N	\N	1	1	-6816	\N	C	2019-12-20 22:13:53.799521+00	2889
6815	-3072	13	173	KFL 4302@Kärl	\N	\N	1	1	-6815	\N	C	2019-12-20 22:13:53.799521+00	2890
6814	-3072	13	173	KFL 4301@Kärl	\N	\N	1	1	-6814	\N	C	2019-12-20 22:13:53.799521+00	2891
6813	-3072	13	173	KFL 4300@Kärl	\N	\N	1	1	-6813	\N	C	2019-12-20 22:13:53.799521+00	2892
6812	-3072	13	173	KFL 4299@Kärl	\N	\N	1	1	-6812	\N	C	2019-12-20 22:13:53.799521+00	2893
6811	-3072	13	173	KFL 4298@Kärl	\N	\N	1	1	-6811	\N	C	2019-12-20 22:13:53.799521+00	2894
6810	-3072	13	173	KFL 4297@Kärl	\N	\N	1	1	-6810	\N	C	2019-12-20 22:13:53.799521+00	2895
6809	-3072	13	173	KFL 4296@Kärl	\N	\N	1	1	-6809	\N	C	2019-12-20 22:13:53.799521+00	2896
6808	-3072	13	173	KFL 4295@Kärl	\N	\N	1	1	-6808	\N	C	2019-12-20 22:13:53.799521+00	2897
6807	-3072	13	173	KFL 4294@Kärl	\N	\N	1	1	-6807	\N	C	2019-12-20 22:13:53.799521+00	2898
6806	-3072	13	173	KFL 4293@Kärl	\N	\N	1	1	-6806	\N	C	2019-12-20 22:13:53.799521+00	2899
6805	-3072	13	173	KFL 4292@Kärl	\N	\N	1	1	-6805	\N	C	2019-12-20 22:13:53.799521+00	2900
6804	-3072	13	173	KFL 4291@Kärl	\N	\N	1	1	-6804	\N	C	2019-12-20 22:13:53.799521+00	2901
6803	-3072	13	173	KFL 4290@Kärl	\N	\N	1	1	-6803	\N	C	2019-12-20 22:13:53.799521+00	2902
6802	-3072	13	173	KFL 4289@Kärl	\N	\N	1	1	-6802	\N	C	2019-12-20 22:13:53.799521+00	2903
6801	-3072	13	173	KFL 4288@Kärl	\N	\N	1	1	-6801	\N	C	2019-12-20 22:13:53.799521+00	2904
6800	-3072	13	173	KFL 4287@Kärl	\N	\N	1	1	-6800	\N	C	2019-12-20 22:13:53.799521+00	2905
6799	-3072	13	173	KFL 4286@Kärl	\N	\N	1	1	-6799	\N	C	2019-12-20 22:13:53.799521+00	2906
6798	-3072	13	173	KFL 4285@Kärl	\N	\N	1	1	-6798	\N	C	2019-12-20 22:13:53.799521+00	2907
6797	-3072	13	173	KFL 4284@Kärl	\N	\N	1	1	-6797	\N	C	2019-12-20 22:13:53.799521+00	2908
6796	-3072	13	173	KFL 4283@Kärl	\N	\N	1	1	-6796	\N	C	2019-12-20 22:13:53.799521+00	2909
6795	-3072	13	173	KFL 4282@Kärl	\N	\N	1	1	-6795	\N	C	2019-12-20 22:13:53.799521+00	2910
6794	-3072	13	173	KFL 4281@Kärl	\N	\N	1	1	-6794	\N	C	2019-12-20 22:13:53.799521+00	2911
6793	-3072	13	173	KFL 4280@Kärl	\N	\N	1	1	-6793	\N	C	2019-12-20 22:13:53.799521+00	2912
6792	-3072	13	173	KFL 4279@Kärl	\N	\N	1	1	-6792	\N	C	2019-12-20 22:13:53.799521+00	2913
6791	-3072	13	173	KFL 4278@Kärl	\N	\N	1	1	-6791	\N	C	2019-12-20 22:13:53.799521+00	2914
6790	-3072	13	173	KFL 4277@Kärl	\N	\N	1	1	-6790	\N	C	2019-12-20 22:13:53.799521+00	2915
6789	-3072	13	173	KFL 4276@Kärl	\N	\N	1	1	-6789	\N	C	2019-12-20 22:13:53.799521+00	2916
6788	-3072	13	173	KFL 4275@Kärl	\N	\N	1	1	-6788	\N	C	2019-12-20 22:13:53.799521+00	2917
6787	-3072	13	173	KFL 4274@Kärl	\N	\N	1	1	-6787	\N	C	2019-12-20 22:13:53.799521+00	2918
6786	-3072	13	173	KFL 4273@Kärl	\N	\N	1	1	-6786	\N	C	2019-12-20 22:13:53.799521+00	2919
6785	-3072	13	173	KFL 4272@Kärl	\N	\N	1	1	-6785	\N	C	2019-12-20 22:13:53.799521+00	2920
6784	-3072	13	173	KFL 4271@Kärl	\N	\N	1	1	-6784	\N	C	2019-12-20 22:13:53.799521+00	2921
6783	-3072	13	173	KFL 4270@Kärl	\N	\N	1	1	-6783	\N	C	2019-12-20 22:13:53.799521+00	2922
6782	-3072	13	173	KFL 4269@Kärl	\N	\N	1	1	-6782	\N	C	2019-12-20 22:13:53.799521+00	2923
6781	-3075	13	173	KFL 4264@Jordprov	\N	\N	1	1	-6781	\N	C	2019-12-20 22:13:53.799521+00	2924
6780	-3075	13	173	KFL 4263@Lerklining	\N	\N	1	1	-6780	\N	C	2019-12-20 22:13:53.799521+00	2925
6779	-3075	13	173	KFL 4262@Lerklining	\N	\N	1	1	-6779	\N	C	2019-12-20 22:13:53.799521+00	2926
6778	-3075	13	173	KFL 4261@Lerklining	\N	\N	1	1	-6778	\N	C	2019-12-20 22:13:53.799521+00	2927
6777	-3075	13	173	KFL 4260@Lerklining	\N	\N	1	1	-6777	\N	C	2019-12-20 22:13:53.799521+00	2928
6776	-3075	13	173	KFL 4259@Skiffer	\N	\N	1	1	-6776	\N	C	2019-12-20 22:13:53.799521+00	2929
6775	-3075	13	173	KFL 4258@Lerklining	\N	\N	1	1	-6775	\N	C	2019-12-20 22:13:53.799521+00	2930
6774	-3075	13	173	KFL 4257@Lerklining	\N	\N	1	1	-6774	\N	C	2019-12-20 22:13:53.799521+00	2931
6773	-3075	13	173	KFL 4256@Lerklining	\N	\N	1	1	-6773	\N	C	2019-12-20 22:13:53.799521+00	2932
6772	-3075	13	173	KFL 4255@Lerklining	\N	\N	1	1	-6772	\N	C	2019-12-20 22:13:53.799521+00	2933
6771	-3075	13	173	KFL 4254@Lerklining	\N	\N	1	1	-6771	\N	C	2019-12-20 22:13:53.799521+00	2934
6770	-3075	13	173	KFL 4253@Lerklining	\N	\N	1	1	-6770	\N	C	2019-12-20 22:13:53.799521+00	2935
6769	-3075	13	173	KFL 4252@Lerklining	\N	\N	1	1	-6769	\N	C	2019-12-20 22:13:53.799521+00	2936
6768	-3075	13	173	KFL 4251@Lerklining	\N	\N	1	1	-6768	\N	C	2019-12-20 22:13:53.799521+00	2937
6767	-3075	13	173	KFL 4250@Lerklining	\N	\N	1	1	-6767	\N	C	2019-12-20 22:13:53.799521+00	2938
6766	-3075	13	173	KFL 4249@Lerklining	\N	\N	1	1	-6766	\N	C	2019-12-20 22:13:53.799521+00	2939
6765	-3290	13	173	KFL 4248@Jordprov	\N	\N	1	1	-6765	\N	C	2019-12-20 22:13:53.799521+00	2940
6764	-3290	13	173	KFL 4247@Jordprov	\N	\N	1	1	-6764	\N	C	2019-12-20 22:13:53.799521+00	2941
6763	-3290	13	173	KFL 4246@Jordprov	\N	\N	1	1	-6763	\N	C	2019-12-20 22:13:53.799521+00	2942
6762	-3290	13	173	KFL 4245@Jordprov	\N	\N	1	1	-6762	\N	C	2019-12-20 22:13:53.799521+00	2943
6761	-3290	13	173	KFL 4244@Jordprov	\N	\N	1	1	-6761	\N	C	2019-12-20 22:13:53.799521+00	2944
6760	-3290	13	173	KFL 4243@Jordprov	\N	\N	1	1	-6760	\N	C	2019-12-20 22:13:53.799521+00	2945
6759	-3290	13	173	KFL 4242@Jordprov	\N	\N	1	1	-6759	\N	C	2019-12-20 22:13:53.799521+00	2946
6758	-3014	13	173	KFL 4241@Jordprov	\N	\N	1	1	-6758	\N	C	2019-12-20 22:13:53.799521+00	2947
6757	-3305	13	173	KFL 4240@Jordprov	\N	\N	1	1	-6757	\N	C	2019-12-20 22:13:53.799521+00	2948
6756	-3278	13	173	KFL 4239@Jordprov	\N	\N	1	1	-6756	\N	C	2019-12-20 22:13:53.799521+00	2949
6755	-3267	13	173	KFL 4238@Jordprov	\N	\N	1	1	-6755	\N	C	2019-12-20 22:13:53.799521+00	2950
6754	-3261	13	173	KFL 4237@Jordprov	\N	\N	1	1	-6754	\N	C	2019-12-20 22:13:53.799521+00	2951
6753	-3179	13	173	KFL 4236@Jordprov	\N	\N	1	1	-6753	\N	C	2019-12-20 22:13:53.799521+00	2952
6752	-3179	13	173	KFL 4235@Jordprov	\N	\N	1	1	-6752	\N	C	2019-12-20 22:13:53.799521+00	2953
6751	-3183	13	173	KFL 4234@Jordprov	\N	\N	1	1	-6751	\N	C	2019-12-20 22:13:53.799521+00	2954
6750	-3183	13	173	KFL 4233@Jordprov	\N	\N	1	1	-6750	\N	C	2019-12-20 22:13:53.799521+00	2955
6749	-3270	13	173	KFL 4232@Jordprov	\N	\N	1	1	-6749	\N	C	2019-12-20 22:13:53.799521+00	2956
6748	-3270	13	173	KFL 4231@Jordprov	\N	\N	1	1	-6748	\N	C	2019-12-20 22:13:53.799521+00	2957
6747	-3241	13	173	KFL 4230@Kärl	\N	\N	1	1	-6747	\N	C	2019-12-20 22:13:53.799521+00	2958
6746	-3241	13	173	KFL 4229@Kärl	\N	\N	1	1	-6746	\N	C	2019-12-20 22:13:53.799521+00	2959
6745	-2978	13	173	KFL 4228@Kärl	\N	\N	1	1	-6745	\N	C	2019-12-20 22:13:53.799521+00	2960
6744	-2978	13	173	KFL 4227@Kärl	\N	\N	1	1	-6744	\N	C	2019-12-20 22:13:53.799521+00	2961
6743	-2978	13	173	KFL 4226@Kärl	\N	\N	1	1	-6743	\N	C	2019-12-20 22:13:53.799521+00	2962
6742	-2978	13	173	KFL 4225@Kärl	\N	\N	1	1	-6742	\N	C	2019-12-20 22:13:53.799521+00	2963
6741	-3261	13	173	KFL 4224@Kärl	\N	\N	1	1	-6741	\N	C	2019-12-20 22:13:53.799521+00	2964
6740	-3261	13	173	KFL 4223@Kärl	\N	\N	1	1	-6740	\N	C	2019-12-20 22:13:53.799521+00	2965
6739	-3261	13	173	KFL 4222@Kärl	\N	\N	1	1	-6739	\N	C	2019-12-20 22:13:53.799521+00	2966
6738	-3261	13	173	KFL 4221@Kärl	\N	\N	1	1	-6738	\N	C	2019-12-20 22:13:53.799521+00	2967
6737	-3261	13	173	KFL 4220@Kärl	\N	\N	1	1	-6737	\N	C	2019-12-20 22:13:53.799521+00	2968
6736	-3261	13	173	KFL 4219@Kärl	\N	\N	1	1	-6736	\N	C	2019-12-20 22:13:53.799521+00	2969
6735	-3261	13	173	KFL 4218@Kärl	\N	\N	1	1	-6735	\N	C	2019-12-20 22:13:53.799521+00	2970
6734	-3261	13	173	KFL 4217@Kärl	\N	\N	1	1	-6734	\N	C	2019-12-20 22:13:53.799521+00	2971
6733	-3261	13	173	KFL 4216@Kärl	\N	\N	1	1	-6733	\N	C	2019-12-20 22:13:53.799521+00	2972
6732	-3261	13	173	KFL 4215@Kärl	\N	\N	1	1	-6732	\N	C	2019-12-20 22:13:53.799521+00	2973
6731	-3261	13	173	KFL 4214@Kärl	\N	\N	1	1	-6731	\N	C	2019-12-20 22:13:53.799521+00	2974
6730	-3261	13	173	KFL 4213@Kärl	\N	\N	1	1	-6730	\N	C	2019-12-20 22:13:53.799521+00	2975
6729	-3261	13	173	KFL 4212@Kärl	\N	\N	1	1	-6729	\N	C	2019-12-20 22:13:53.799521+00	2976
6728	-3261	13	173	KFL 4211@Kärl	\N	\N	1	1	-6728	\N	C	2019-12-20 22:13:53.799521+00	2977
6727	-3261	13	173	KFL 4210@Kärl	\N	\N	1	1	-6727	\N	C	2019-12-20 22:13:53.799521+00	2978
6726	-3261	13	173	KFL 4209@Kärl	\N	\N	1	1	-6726	\N	C	2019-12-20 22:13:53.799521+00	2979
6725	-3261	13	173	KFL 4208@Kärl	\N	\N	1	1	-6725	\N	C	2019-12-20 22:13:53.799521+00	2980
6724	-3261	13	173	KFL 4207@Kärl	\N	\N	1	1	-6724	\N	C	2019-12-20 22:13:53.799521+00	2981
6723	-3261	13	173	KFL 4206@Kärl	\N	\N	1	1	-6723	\N	C	2019-12-20 22:13:53.799521+00	2982
6722	-3261	13	173	KFL 4205@Kärl	\N	\N	1	1	-6722	\N	C	2019-12-20 22:13:53.799521+00	2983
6721	-3261	13	173	KFL 4204@Kärl	\N	\N	1	1	-6721	\N	C	2019-12-20 22:13:53.799521+00	2984
6720	-3261	13	173	KFL 4203@Kärl	\N	\N	1	1	-6720	\N	C	2019-12-20 22:13:53.799521+00	2985
6719	-3261	13	173	KFL 4202@Kärl	\N	\N	1	1	-6719	\N	C	2019-12-20 22:13:53.799521+00	2986
6718	-3261	13	173	KFL 4201@Kärl	\N	\N	1	1	-6718	\N	C	2019-12-20 22:13:53.799521+00	2987
6717	-3187	13	173	KFL 4200@Kärl	\N	\N	1	1	-6717	\N	C	2019-12-20 22:13:53.799521+00	2988
6716	-3187	13	173	KFL 4199@Kärl	\N	\N	1	1	-6716	\N	C	2019-12-20 22:13:53.799521+00	2989
6715	-3187	13	173	KFL 4198@Kärl	\N	\N	1	1	-6715	\N	C	2019-12-20 22:13:53.799521+00	2990
6714	-3187	13	173	KFL 4197@Kärl	\N	\N	1	1	-6714	\N	C	2019-12-20 22:13:53.799521+00	2991
6713	-3187	13	173	KFL 4196@Kärl	\N	\N	1	1	-6713	\N	C	2019-12-20 22:13:53.799521+00	2992
6712	-3187	13	173	KFL 4195@Kärl	\N	\N	1	1	-6712	\N	C	2019-12-20 22:13:53.799521+00	2993
6711	-3187	13	173	KFL 4194@Kärl	\N	\N	1	1	-6711	\N	C	2019-12-20 22:13:53.799521+00	2994
6710	-3187	13	173	KFL 4193@Kärl	\N	\N	1	1	-6710	\N	C	2019-12-20 22:13:53.799521+00	2995
6709	-3187	13	173	KFL 4192@Kärl	\N	\N	1	1	-6709	\N	C	2019-12-20 22:13:53.799521+00	2996
6708	-3187	13	173	KFL 4191@Kärl	\N	\N	1	1	-6708	\N	C	2019-12-20 22:13:53.799521+00	2997
6707	-3187	13	173	KFL 4190@Kärl	\N	\N	1	1	-6707	\N	C	2019-12-20 22:13:53.799521+00	2998
6706	-3187	13	173	KFL 4189@Kärl	\N	\N	1	1	-6706	\N	C	2019-12-20 22:13:53.799521+00	2999
6705	-3187	13	173	KFL 4188@Kärl	\N	\N	1	1	-6705	\N	C	2019-12-20 22:13:53.799521+00	3000
6704	-3187	13	173	KFL 4187@Kärl	\N	\N	1	1	-6704	\N	C	2019-12-20 22:13:53.799521+00	3001
6703	-3187	13	173	KFL 4186@Kärl	\N	\N	1	1	-6703	\N	C	2019-12-20 22:13:53.799521+00	3002
6702	-3187	13	173	KFL 4185@Kärl	\N	\N	1	1	-6702	\N	C	2019-12-20 22:13:53.799521+00	3003
6701	-3187	13	173	KFL 4184@Kärl	\N	\N	1	1	-6701	\N	C	2019-12-20 22:13:53.799521+00	3004
6700	-3187	13	173	KFL 4183@Kärl	\N	\N	1	1	-6700	\N	C	2019-12-20 22:13:53.799521+00	3005
6699	-3187	13	173	KFL 4182@Kärl	\N	\N	1	1	-6699	\N	C	2019-12-20 22:13:53.799521+00	3006
6698	-3007	13	173	KFL 4181@Kärl	\N	\N	1	1	-6698	\N	C	2019-12-20 22:13:53.799521+00	3007
6697	-3007	13	173	KFL 4180@Kärl	\N	\N	1	1	-6697	\N	C	2019-12-20 22:13:53.799521+00	3008
6696	-3007	13	173	KFL 4179@Kärl	\N	\N	1	1	-6696	\N	C	2019-12-20 22:13:53.799521+00	3009
6695	-3007	13	173	KFL 4178@Kärl	\N	\N	1	1	-6695	\N	C	2019-12-20 22:13:53.799521+00	3010
6694	-3007	13	173	KFL 4177@Kärl	\N	\N	1	1	-6694	\N	C	2019-12-20 22:13:53.799521+00	3011
6693	-3007	13	173	KFL 4176@Kärl	\N	\N	1	1	-6693	\N	C	2019-12-20 22:13:53.799521+00	3012
6692	-3007	13	173	KFL 4175@Kärl	\N	\N	1	1	-6692	\N	C	2019-12-20 22:13:53.799521+00	3013
6691	-3007	13	173	KFL 4174@Kärl	\N	\N	1	1	-6691	\N	C	2019-12-20 22:13:53.799521+00	3014
6690	-3007	13	173	KFL 4173@Kärl	\N	\N	1	1	-6690	\N	C	2019-12-20 22:13:53.799521+00	3015
6689	-3007	13	173	KFL 4172@Kärl	\N	\N	1	1	-6689	\N	C	2019-12-20 22:13:53.799521+00	3016
6688	-3166	13	173	KFL 4171@Kärl	\N	\N	1	1	-6688	\N	C	2019-12-20 22:13:53.799521+00	3017
6687	-3166	13	173	KFL 4170@Kärl	\N	\N	1	1	-6687	\N	C	2019-12-20 22:13:53.799521+00	3018
6686	-3166	13	173	KFL 4169@Kärl	\N	\N	1	1	-6686	\N	C	2019-12-20 22:13:53.799521+00	3019
6685	-3166	13	173	KFL 4168@Kärl	\N	\N	1	1	-6685	\N	C	2019-12-20 22:13:53.799521+00	3020
6684	-3166	13	173	KFL 4167@Kärl	\N	\N	1	1	-6684	\N	C	2019-12-20 22:13:53.799521+00	3021
6683	-3166	13	173	KFL 4166@Kärl	\N	\N	1	1	-6683	\N	C	2019-12-20 22:13:53.799521+00	3022
6682	-3166	13	173	KFL 4165@Kärl	\N	\N	1	1	-6682	\N	C	2019-12-20 22:13:53.799521+00	3023
6681	-3166	13	173	KFL 4164@Kärl	\N	\N	1	1	-6681	\N	C	2019-12-20 22:13:53.799521+00	3024
6680	-3166	13	173	KFL 4163@Kärl	\N	\N	1	1	-6680	\N	C	2019-12-20 22:13:53.799521+00	3025
6679	-3166	13	173	KFL 4162@Kärl	\N	\N	1	1	-6679	\N	C	2019-12-20 22:13:53.799521+00	3026
6678	-3166	13	173	KFL 4161@Kärl	\N	\N	1	1	-6678	\N	C	2019-12-20 22:13:53.799521+00	3027
6677	-3163	13	173	KFL 4160@Kärl	\N	\N	1	1	-6677	\N	C	2019-12-20 22:13:53.799521+00	3028
6676	-3163	13	173	KFL 4159@Kärl	\N	\N	1	1	-6676	\N	C	2019-12-20 22:13:53.799521+00	3029
6675	-3163	13	173	KFL 4158@Kärl	\N	\N	1	1	-6675	\N	C	2019-12-20 22:13:53.799521+00	3030
6674	-3163	13	173	KFL 4157@Kärl	\N	\N	1	1	-6674	\N	C	2019-12-20 22:13:53.799521+00	3031
6673	-3163	13	173	KFL 4156@Kärl	\N	\N	1	1	-6673	\N	C	2019-12-20 22:13:53.799521+00	3032
6672	-3163	13	173	KFL 4155@Kärl	\N	\N	1	1	-6672	\N	C	2019-12-20 22:13:53.799521+00	3033
6671	-3163	13	173	KFL 4154@Kärl	\N	\N	1	1	-6671	\N	C	2019-12-20 22:13:53.799521+00	3034
6670	-3163	13	173	KFL 4153@Kärl	\N	\N	1	1	-6670	\N	C	2019-12-20 22:13:53.799521+00	3035
6669	-3163	13	173	KFL 4152@Kärl	\N	\N	1	1	-6669	\N	C	2019-12-20 22:13:53.799521+00	3036
6668	-3163	13	173	KFL 4151@Kärl	\N	\N	1	1	-6668	\N	C	2019-12-20 22:13:53.799521+00	3037
6667	-3163	13	173	KFL 4150@Kärl	\N	\N	1	1	-6667	\N	C	2019-12-20 22:13:53.799521+00	3038
6666	-3163	13	173	KFL 4149@Kärl	\N	\N	1	1	-6666	\N	C	2019-12-20 22:13:53.799521+00	3039
6665	-3163	13	173	KFL 4148@Kärl	\N	\N	1	1	-6665	\N	C	2019-12-20 22:13:53.799521+00	3040
6664	-3163	13	173	KFL 4147@Kärl	\N	\N	1	1	-6664	\N	C	2019-12-20 22:13:53.799521+00	3041
6663	-3163	13	173	KFL 4146@Kärl	\N	\N	1	1	-6663	\N	C	2019-12-20 22:13:53.799521+00	3042
6662	-3163	13	173	KFL 4145@Kärl	\N	\N	1	1	-6662	\N	C	2019-12-20 22:13:53.799521+00	3043
6661	-3163	13	173	KFL 4144@Kärl	\N	\N	1	1	-6661	\N	C	2019-12-20 22:13:53.799521+00	3044
6660	-3163	13	173	KFL 4143@Kärl	\N	\N	1	1	-6660	\N	C	2019-12-20 22:13:53.799521+00	3045
6659	-3163	13	173	KFL 4142@Kärl	\N	\N	1	1	-6659	\N	C	2019-12-20 22:13:53.799521+00	3046
6658	-3163	13	173	KFL 4141@Kärl	\N	\N	1	1	-6658	\N	C	2019-12-20 22:13:53.799521+00	3047
6657	-3163	13	173	KFL 4140@Kärl	\N	\N	1	1	-6657	\N	C	2019-12-20 22:13:53.799521+00	3048
6656	-3163	13	173	KFL 4139@Kärl	\N	\N	1	1	-6656	\N	C	2019-12-20 22:13:53.799521+00	3049
6655	-3163	13	173	KFL 4138@Kärl	\N	\N	1	1	-6655	\N	C	2019-12-20 22:13:53.799521+00	3050
6654	-3163	13	173	KFL 4137@Kärl	\N	\N	1	1	-6654	\N	C	2019-12-20 22:13:53.799521+00	3051
6653	-3163	13	173	KFL 4136@Kärl	\N	\N	1	1	-6653	\N	C	2019-12-20 22:13:53.799521+00	3052
6652	-3163	13	173	KFL 4135@Kärl	\N	\N	1	1	-6652	\N	C	2019-12-20 22:13:53.799521+00	3053
6651	-3163	13	173	KFL 4134@Kärl	\N	\N	1	1	-6651	\N	C	2019-12-20 22:13:53.799521+00	3054
6650	-3163	13	173	KFL 4133@Kärl	\N	\N	1	1	-6650	\N	C	2019-12-20 22:13:53.799521+00	3055
6649	-3163	13	173	KFL 4132@Kärl	\N	\N	1	1	-6649	\N	C	2019-12-20 22:13:53.799521+00	3056
6648	-3163	13	173	KFL 4131@Kärl	\N	\N	1	1	-6648	\N	C	2019-12-20 22:13:53.799521+00	3057
6647	-3071	13	173	KFL 4130@Kärl	\N	\N	1	1	-6647	\N	C	2019-12-20 22:13:53.799521+00	3058
6646	-3071	13	173	KFL 4129@Kärl	\N	\N	1	1	-6646	\N	C	2019-12-20 22:13:53.799521+00	3059
6645	-3071	13	173	KFL 4128@Kärl	\N	\N	1	1	-6645	\N	C	2019-12-20 22:13:53.799521+00	3060
6644	-3071	13	173	KFL 4127@Kärl	\N	\N	1	1	-6644	\N	C	2019-12-20 22:13:53.799521+00	3061
6643	-3071	13	173	KFL 4126@Kärl	\N	\N	1	1	-6643	\N	C	2019-12-20 22:13:53.799521+00	3062
6642	-3071	13	173	KFL 4125@Kärl	\N	\N	1	1	-6642	\N	C	2019-12-20 22:13:53.799521+00	3063
6641	-3071	13	173	KFL 4124@Kärl	\N	\N	1	1	-6641	\N	C	2019-12-20 22:13:53.799521+00	3064
6640	-3071	13	173	KFL 4123@Kärl	\N	\N	1	1	-6640	\N	C	2019-12-20 22:13:53.799521+00	3065
6639	-3071	13	173	KFL 4122@Kärl	\N	\N	1	1	-6639	\N	C	2019-12-20 22:13:53.799521+00	3066
6638	-3071	13	173	KFL 4121@Kärl	\N	\N	1	1	-6638	\N	C	2019-12-20 22:13:53.799521+00	3067
6637	-3071	13	173	KFL 4120@Kärl	\N	\N	1	1	-6637	\N	C	2019-12-20 22:13:53.799521+00	3068
6636	-3071	13	173	KFL 4119@Kärl	\N	\N	1	1	-6636	\N	C	2019-12-20 22:13:53.799521+00	3069
6635	-3071	13	173	KFL 4118@Kärl	\N	\N	1	1	-6635	\N	C	2019-12-20 22:13:53.799521+00	3070
6634	-3071	13	173	KFL 4117@Kärl	\N	\N	1	1	-6634	\N	C	2019-12-20 22:13:53.799521+00	3071
6633	-3071	13	173	KFL 4116@Kärl	\N	\N	1	1	-6633	\N	C	2019-12-20 22:13:53.799521+00	3072
6632	-3071	13	173	KFL 4115@Kärl	\N	\N	1	1	-6632	\N	C	2019-12-20 22:13:53.799521+00	3073
6631	-3071	13	173	KFL 4114@Kärl	\N	\N	1	1	-6631	\N	C	2019-12-20 22:13:53.799521+00	3074
6630	-3071	13	173	KFL 4113@Kärl	\N	\N	1	1	-6630	\N	C	2019-12-20 22:13:53.799521+00	3075
6629	-2990	13	173	KFL 4112@Lerklining	\N	\N	1	1	-6629	\N	C	2019-12-20 22:13:53.799521+00	3076
6628	-2990	13	173	KFL 4111@Lerklining	\N	\N	1	1	-6628	\N	C	2019-12-20 22:13:53.799521+00	3077
6627	-2990	13	173	KFL 4110@Lerklining	\N	\N	1	1	-6627	\N	C	2019-12-20 22:13:53.799521+00	3078
6626	-2990	13	173	KFL 4109@Lerklining	\N	\N	1	1	-6626	\N	C	2019-12-20 22:13:53.799521+00	3079
6625	-2990	13	173	KFL 4108@Lerklining	\N	\N	1	1	-6625	\N	C	2019-12-20 22:13:53.799521+00	3080
6624	-2990	13	173	KFL 4107@Lerklining	\N	\N	1	1	-6624	\N	C	2019-12-20 22:13:53.799521+00	3081
6623	-3111	13	173	KFL 4106@Kärl	\N	\N	1	1	-6623	\N	C	2019-12-20 22:13:53.799521+00	3082
6622	-3111	13	173	KFL 4105@Kärl	\N	\N	1	1	-6622	\N	C	2019-12-20 22:13:53.799521+00	3083
6621	-3111	13	173	KFL 4104@Kärl	\N	\N	1	1	-6621	\N	C	2019-12-20 22:13:53.799521+00	3084
6620	-3111	13	173	KFL 4103@Kärl	\N	\N	1	1	-6620	\N	C	2019-12-20 22:13:53.799521+00	3085
6619	-3111	13	173	KFL 4102@Kärl	\N	\N	1	1	-6619	\N	C	2019-12-20 22:13:53.799521+00	3086
6618	-3111	13	173	KFL 4101@Kärl	\N	\N	1	1	-6618	\N	C	2019-12-20 22:13:53.799521+00	3087
6617	-3111	13	173	KFL 4100@Kärl	\N	\N	1	1	-6617	\N	C	2019-12-20 22:13:53.799521+00	3088
6616	-3111	13	173	KFL 4099@Kärl	\N	\N	1	1	-6616	\N	C	2019-12-20 22:13:53.799521+00	3089
6615	-3111	13	173	KFL 4098@Kärl	\N	\N	1	1	-6615	\N	C	2019-12-20 22:13:53.799521+00	3090
6614	-3111	13	173	KFL 4097@Kärl	\N	\N	1	1	-6614	\N	C	2019-12-20 22:13:53.799521+00	3091
6613	-3111	13	173	KFL 4096@Kärl	\N	\N	1	1	-6613	\N	C	2019-12-20 22:13:53.799521+00	3092
6612	-3111	13	173	KFL 4095@Kärl	\N	\N	1	1	-6612	\N	C	2019-12-20 22:13:53.799521+00	3093
6611	-3111	13	173	KFL 4094@Kärl	\N	\N	1	1	-6611	\N	C	2019-12-20 22:13:53.799521+00	3094
6610	-3111	13	173	KFL 4093@Kärl	\N	\N	1	1	-6610	\N	C	2019-12-20 22:13:53.799521+00	3095
6609	-3111	13	173	KFL 4092@Kärl	\N	\N	1	1	-6609	\N	C	2019-12-20 22:13:53.799521+00	3096
6608	-3111	13	173	KFL 4091@Kärl	\N	\N	1	1	-6608	\N	C	2019-12-20 22:13:53.799521+00	3097
6607	-3111	13	173	KFL 4090@Kärl	\N	\N	1	1	-6607	\N	C	2019-12-20 22:13:53.799521+00	3098
6606	-3111	13	173	KFL 4089@Kärl	\N	\N	1	1	-6606	\N	C	2019-12-20 22:13:53.799521+00	3099
6605	-3111	13	173	KFL 4088@Kärl	\N	\N	1	1	-6605	\N	C	2019-12-20 22:13:53.799521+00	3100
6604	-3111	13	173	KFL 4087@Kärl	\N	\N	1	1	-6604	\N	C	2019-12-20 22:13:53.799521+00	3101
6603	-3111	13	173	KFL 4086@Kärl	\N	\N	1	1	-6603	\N	C	2019-12-20 22:13:53.799521+00	3102
6602	-3111	13	173	KFL 4085@Kärl	\N	\N	1	1	-6602	\N	C	2019-12-20 22:13:53.799521+00	3103
6601	-3111	13	173	KFL 4084@Kärl	\N	\N	1	1	-6601	\N	C	2019-12-20 22:13:53.799521+00	3104
6600	-3111	13	173	KFL 4083@Kärl	\N	\N	1	1	-6600	\N	C	2019-12-20 22:13:53.799521+00	3105
6599	-3111	13	173	KFL 4082@Kärl	\N	\N	1	1	-6599	\N	C	2019-12-20 22:13:53.799521+00	3106
6598	-3111	13	173	KFL 4081@Kärl	\N	\N	1	1	-6598	\N	C	2019-12-20 22:13:53.799521+00	3107
6597	-3111	13	173	KFL 4080@Kärl	\N	\N	1	1	-6597	\N	C	2019-12-20 22:13:53.799521+00	3108
6596	-3111	13	173	KFL 4079@Kärl	\N	\N	1	1	-6596	\N	C	2019-12-20 22:13:53.799521+00	3109
6595	-3111	13	173	KFL 4078@Kärl	\N	\N	1	1	-6595	\N	C	2019-12-20 22:13:53.799521+00	3110
6594	-3111	13	173	KFL 4077@Kärl	\N	\N	1	1	-6594	\N	C	2019-12-20 22:13:53.799521+00	3111
6593	-3111	13	173	KFL 4076@Kärl	\N	\N	1	1	-6593	\N	C	2019-12-20 22:13:53.799521+00	3112
6592	-3111	13	173	KFL 4075@Kärl	\N	\N	1	1	-6592	\N	C	2019-12-20 22:13:53.799521+00	3113
6591	-3111	13	173	KFL 4074@Kärl	\N	\N	1	1	-6591	\N	C	2019-12-20 22:13:53.799521+00	3114
6590	-3111	13	173	KFL 4073@Kärl	\N	\N	1	1	-6590	\N	C	2019-12-20 22:13:53.799521+00	3115
6589	-3111	13	173	KFL 4072@Kärl	\N	\N	1	1	-6589	\N	C	2019-12-20 22:13:53.799521+00	3116
6588	-3111	13	173	KFL 4071@Kärl	\N	\N	1	1	-6588	\N	C	2019-12-20 22:13:53.799521+00	3117
6587	-3111	13	173	KFL 4070@Kärl	\N	\N	1	1	-6587	\N	C	2019-12-20 22:13:53.799521+00	3118
6586	-3111	13	173	KFL 4069@Kärl	\N	\N	1	1	-6586	\N	C	2019-12-20 22:13:53.799521+00	3119
6585	-3111	13	173	KFL 4068@Kärl	\N	\N	1	1	-6585	\N	C	2019-12-20 22:13:53.799521+00	3120
6584	-3111	13	173	KFL 4067@Kärl	\N	\N	1	1	-6584	\N	C	2019-12-20 22:13:53.799521+00	3121
6583	-3112	13	173	KFL 4066@Kärl@6	\N	\N	1	1	-6583	\N	C	2019-12-20 22:13:53.799521+00	3122
6582	-3112	13	173	KFL 4065@Kärl@5	\N	\N	1	1	-6582	\N	C	2019-12-20 22:13:53.799521+00	3123
6581	-3112	13	173	KFL 4064@Kärl@4	\N	\N	1	1	-6581	\N	C	2019-12-20 22:13:53.799521+00	3124
6580	-3112	13	173	KFL 4063@Kärl@2	\N	\N	1	1	-6580	\N	C	2019-12-20 22:13:53.799521+00	3125
6579	-3112	13	173	KFL 4062@Kärl@1	\N	\N	1	1	-6579	\N	C	2019-12-20 22:13:53.799521+00	3126
6578	-3182	13	173	KFL 4061@Kärl@2	\N	\N	1	1	-6578	\N	C	2019-12-20 22:13:53.799521+00	3127
6577	-3182	13	173	KFL 4060@Kärl@1	\N	\N	1	1	-6577	\N	C	2019-12-20 22:13:53.799521+00	3128
6576	-3367	13	173	KFL 4059@Kärl@21	\N	\N	1	1	-6576	\N	C	2019-12-20 22:13:53.799521+00	3129
6575	-3367	13	173	KFL 4058@Kärl@1	\N	\N	1	1	-6575	\N	C	2019-12-20 22:13:53.799521+00	3130
6574	-3043	13	173	KFL 4057@Kärl@42b	\N	\N	1	1	-6574	\N	C	2019-12-20 22:13:53.799521+00	3131
6573	-3043	13	173	KFL 4056@Kärl@42	\N	\N	1	1	-6573	\N	C	2019-12-20 22:13:53.799521+00	3132
6572	-3043	13	173	KFL 4055@Kärl@26	\N	\N	1	1	-6572	\N	C	2019-12-20 22:13:53.799521+00	3133
6571	-3043	13	173	KFL 4054@Kärl@58	\N	\N	1	1	-6571	\N	C	2019-12-20 22:13:53.799521+00	3134
6570	-3043	13	173	KFL 4053@Kärl@46	\N	\N	1	1	-6570	\N	C	2019-12-20 22:13:53.799521+00	3135
6569	-3043	13	173	KFL 4052@Kärl@37	\N	\N	1	1	-6569	\N	C	2019-12-20 22:13:53.799521+00	3136
6568	-3043	13	173	KFL 4051@Kärl@34	\N	\N	1	1	-6568	\N	C	2019-12-20 22:13:53.799521+00	3137
6567	-3043	13	173	KFL 4050@Kärl@32	\N	\N	1	1	-6567	\N	C	2019-12-20 22:13:53.799521+00	3138
6566	-3043	13	173	KFL 4049@Kärl@24	\N	\N	1	1	-6566	\N	C	2019-12-20 22:13:53.799521+00	3139
6565	-3043	13	173	KFL 4048@Kärl@8	\N	\N	1	1	-6565	\N	C	2019-12-20 22:13:53.799521+00	3140
6564	-3043	13	173	KFL 4047@Kärl@4	\N	\N	1	1	-6564	\N	C	2019-12-20 22:13:53.799521+00	3141
6563	-3043	13	173	KFL 4046@Kärl@1	\N	\N	1	1	-6563	\N	C	2019-12-20 22:13:53.799521+00	3142
6562	-3081	13	173	KFL 4045@Kärl@18	\N	\N	1	1	-6562	\N	C	2019-12-20 22:13:53.799521+00	3143
6561	-3081	13	173	KFL 4044@Kärl@4	\N	\N	1	1	-6561	\N	C	2019-12-20 22:13:53.799521+00	3144
6560	-3081	13	173	KFL 4043@Kärl@14	\N	\N	1	1	-6560	\N	C	2019-12-20 22:13:53.799521+00	3145
6559	-3081	13	173	KFL 4042@Kärl@9	\N	\N	1	1	-6559	\N	C	2019-12-20 22:13:53.799521+00	3146
6558	-3081	13	173	KFL 4041@Kärl@11	\N	\N	1	1	-6558	\N	C	2019-12-20 22:13:53.799521+00	3147
6557	-3081	13	173	KFL 4040@Kärl@10	\N	\N	1	1	-6557	\N	C	2019-12-20 22:13:53.799521+00	3148
6556	-3081	13	173	KFL 4039@Kärl@6	\N	\N	1	1	-6556	\N	C	2019-12-20 22:13:53.799521+00	3149
6555	-3081	13	173	KFL 4038@Kärl@7	\N	\N	1	1	-6555	\N	C	2019-12-20 22:13:53.799521+00	3150
6554	-3362	13	173	KFL 4037@Kärl	\N	\N	1	1	-6554	\N	C	2019-12-20 22:13:53.799521+00	3151
6553	-3362	13	173	KFL 4036@Kärl	\N	\N	1	1	-6553	\N	C	2019-12-20 22:13:53.799521+00	3152
6552	-3362	13	173	KFL 4035@Kärl	\N	\N	1	1	-6552	\N	C	2019-12-20 22:13:53.799521+00	3153
6551	-3362	13	173	KFL 4034@Kärl	\N	\N	1	1	-6551	\N	C	2019-12-20 22:13:53.799521+00	3154
6550	-3362	13	173	KFL 4033@Kärl	\N	\N	1	1	-6550	\N	C	2019-12-20 22:13:53.799521+00	3155
6549	-3362	13	173	KFL 4032@Kärl	\N	\N	1	1	-6549	\N	C	2019-12-20 22:13:53.799521+00	3156
6548	-3362	13	173	KFL 4031@Kärl	\N	\N	1	1	-6548	\N	C	2019-12-20 22:13:53.799521+00	3157
6547	-3362	13	173	KFL 4030@Kärl	\N	\N	1	1	-6547	\N	C	2019-12-20 22:13:53.799521+00	3158
6546	-3170	13	173	KFL 4029@Kärl	\N	\N	1	1	-6546	\N	C	2019-12-20 22:13:53.799521+00	3159
6545	-3170	13	173	KFL 4028@Kärl	\N	\N	1	1	-6545	\N	C	2019-12-20 22:13:53.799521+00	3160
6544	-3170	13	173	KFL 4027@Kärl	\N	\N	1	1	-6544	\N	C	2019-12-20 22:13:53.799521+00	3161
6543	-3170	13	173	KFL 4026@Kärl	\N	\N	1	1	-6543	\N	C	2019-12-20 22:13:53.799521+00	3162
6542	-3170	13	173	KFL 4025@Kärl	\N	\N	1	1	-6542	\N	C	2019-12-20 22:13:53.799521+00	3163
6541	-3170	13	173	KFL 4024@Kärl	\N	\N	1	1	-6541	\N	C	2019-12-20 22:13:53.799521+00	3164
6540	-3170	13	173	KFL 4023@Kärl	\N	\N	1	1	-6540	\N	C	2019-12-20 22:13:53.799521+00	3165
6539	-3170	13	173	KFL 4022@Kärl	\N	\N	1	1	-6539	\N	C	2019-12-20 22:13:53.799521+00	3166
6538	-3170	13	173	KFL 4021@Kärl	\N	\N	1	1	-6538	\N	C	2019-12-20 22:13:53.799521+00	3167
6537	-3170	13	173	KFL 4020@Kärl	\N	\N	1	1	-6537	\N	C	2019-12-20 22:13:53.799521+00	3168
6536	-2981	13	173	KFL 4019@Kärl	\N	\N	1	1	-6536	\N	C	2019-12-20 22:13:53.799521+00	3169
6535	-2981	13	173	KFL 4018@Kärl	\N	\N	1	1	-6535	\N	C	2019-12-20 22:13:53.799521+00	3170
6534	-2981	13	173	KFL 4017@Kärl	\N	\N	1	1	-6534	\N	C	2019-12-20 22:13:53.799521+00	3171
6533	-2981	13	173	KFL 4016@Kärl	\N	\N	1	1	-6533	\N	C	2019-12-20 22:13:53.799521+00	3172
6532	-2981	13	173	KFL 4015@Kärl	\N	\N	1	1	-6532	\N	C	2019-12-20 22:13:53.799521+00	3173
6531	-2981	13	173	KFL 4014@Kärl	\N	\N	1	1	-6531	\N	C	2019-12-20 22:13:53.799521+00	3174
6530	-2981	13	173	KFL 4013@Kärl	\N	\N	1	1	-6530	\N	C	2019-12-20 22:13:53.799521+00	3175
6529	-2981	13	173	KFL 4012@Kärl	\N	\N	1	1	-6529	\N	C	2019-12-20 22:13:53.799521+00	3176
6528	-2981	13	173	KFL 4011@Kärl	\N	\N	1	1	-6528	\N	C	2019-12-20 22:13:53.799521+00	3177
6527	-2981	13	173	KFL 4010@Kärl	\N	\N	1	1	-6527	\N	C	2019-12-20 22:13:53.799521+00	3178
6526	-3017	13	173	KFL 4009@Degel	\N	\N	1	1	-6526	\N	C	2019-12-20 22:13:53.799521+00	3179
6525	-3017	13	173	KFL 4008@Degel	\N	\N	1	1	-6525	\N	C	2019-12-20 22:13:53.799521+00	3180
6524	-3017	13	173	KFL 4007@Degel	\N	\N	1	1	-6524	\N	C	2019-12-20 22:13:53.799521+00	3181
6523	-3017	13	173	KFL 4006@Degel	\N	\N	1	1	-6523	\N	C	2019-12-20 22:13:53.799521+00	3182
6522	-3017	13	173	KFL 4005@Degel	\N	\N	1	1	-6522	\N	C	2019-12-20 22:13:53.799521+00	3183
6521	-3017	13	173	KFL 4004@Degel	\N	\N	1	1	-6521	\N	C	2019-12-20 22:13:53.799521+00	3184
6520	-3017	13	173	KFL 4003@Degel	\N	\N	1	1	-6520	\N	C	2019-12-20 22:13:53.799521+00	3185
6519	-3017	13	173	KFL 4002@Degel	\N	\N	1	1	-6519	\N	C	2019-12-20 22:13:53.799521+00	3186
6518	-3017	13	173	KFL 4001@Degel	\N	\N	1	1	-6518	\N	C	2019-12-20 22:13:53.799521+00	3187
6517	-3017	13	173	KFL 4000@Degel	\N	\N	1	1	-6517	\N	C	2019-12-20 22:13:53.799521+00	3188
6516	-3208	13	173	KFL 3623@Kärl	\N	\N	1	1	-6516	\N	C	2019-12-20 22:13:53.799521+00	3189
6515	-3208	13	173	KFL 3622@Kärl	\N	\N	1	1	-6515	\N	C	2019-12-20 22:13:53.799521+00	3190
6514	-3371	13	173	KFL 3621@Kärl	\N	\N	1	1	-6514	\N	C	2019-12-20 22:13:53.799521+00	3191
6513	-3371	13	173	KFL 3620@Kärl	\N	\N	1	1	-6513	\N	C	2019-12-20 22:13:53.799521+00	3192
6512	-3136	13	173	KFL 3619@Kakel	\N	\N	1	1	-6512	\N	C	2019-12-20 22:13:53.799521+00	3193
6511	-3190	13	173	KFL 3618@Kärl	\N	\N	1	1	-6511	\N	C	2019-12-20 22:13:53.799521+00	3194
6510	-3190	13	173	KFL 3617@Kärl	\N	\N	1	1	-6510	\N	C	2019-12-20 22:13:53.799521+00	3195
6509	-3190	13	173	KFL 3616@Kärl	\N	\N	1	1	-6509	\N	C	2019-12-20 22:13:53.799521+00	3196
6508	-3190	13	173	KFL 3615@Kärl	\N	\N	1	1	-6508	\N	C	2019-12-20 22:13:53.799521+00	3197
6507	-3190	13	173	KFL 3614@Kärl	\N	\N	1	1	-6507	\N	C	2019-12-20 22:13:53.799521+00	3198
6506	-3190	13	173	KFL 3613@Kärl	\N	\N	1	1	-6506	\N	C	2019-12-20 22:13:53.799521+00	3199
6505	-3190	13	173	KFL 3612@Kärl	\N	\N	1	1	-6505	\N	C	2019-12-20 22:13:53.799521+00	3200
6504	-3190	13	173	KFL 3611@Kärl	\N	\N	1	1	-6504	\N	C	2019-12-20 22:13:53.799521+00	3201
6503	-3190	13	173	KFL 3610@Kärl	\N	\N	1	1	-6503	\N	C	2019-12-20 22:13:53.799521+00	3202
6502	-3190	13	173	KFL 3609,2@Kärl	\N	\N	1	1	-6502	\N	C	2019-12-20 22:13:53.799521+00	3203
6501	-3190	13	173	KFL 3609,1@Kärl	\N	\N	1	1	-6501	\N	C	2019-12-20 22:13:53.799521+00	3204
6500	-3190	13	173	KFL 3608@Kärl	\N	\N	1	1	-6500	\N	C	2019-12-20 22:13:53.799521+00	3205
6499	-3025	13	173	KFL 3607@Degel	\N	\N	1	1	-6499	\N	C	2019-12-20 22:13:53.799521+00	3206
6498	-3025	13	173	KFL 3606@Degel	\N	\N	1	1	-6498	\N	C	2019-12-20 22:13:53.799521+00	3207
6497	-3025	13	173	KFL 3605@Degel	\N	\N	1	1	-6497	\N	C	2019-12-20 22:13:53.799521+00	3208
6496	-3025	13	173	KFL 3604@Degel	\N	\N	1	1	-6496	\N	C	2019-12-20 22:13:53.799521+00	3209
6495	-3095	13	173	KFL 3602@Degel	\N	\N	1	1	-6495	\N	C	2019-12-20 22:13:53.799521+00	3210
6494	-3095	13	173	KFL 3601@Degel	\N	\N	1	1	-6494	\N	C	2019-12-20 22:13:53.799521+00	3211
6493	-3095	13	173	KFL 3600@Degel	\N	\N	1	1	-6493	\N	C	2019-12-20 22:13:53.799521+00	3212
6492	-3095	13	173	KFL 3599@Degel	\N	\N	1	1	-6492	\N	C	2019-12-20 22:13:53.799521+00	3213
6491	-3095	13	173	KFL 3598@Degel	\N	\N	1	1	-6491	\N	C	2019-12-20 22:13:53.799521+00	3214
6490	-3095	13	173	KFL 3597@Degel	\N	\N	1	1	-6490	\N	C	2019-12-20 22:13:53.799521+00	3215
6489	-3095	13	173	KFL 3596@Degel	\N	\N	1	1	-6489	\N	C	2019-12-20 22:13:53.799521+00	3216
6488	-3095	13	173	KFL 3595@Degel	\N	\N	1	1	-6488	\N	C	2019-12-20 22:13:53.799521+00	3217
6487	-3095	13	173	KFL 3594@Degel	\N	\N	1	1	-6487	\N	C	2019-12-20 22:13:53.799521+00	3218
6486	-3042	13	173	KFL 3593@Kärl	\N	\N	1	1	-6486	\N	C	2019-12-20 22:13:53.799521+00	3219
6485	-3042	13	173	KFL 3592@Kärl	\N	\N	1	1	-6485	\N	C	2019-12-20 22:13:53.799521+00	3220
6484	-3042	13	173	KFL 3591@Kärl	\N	\N	1	1	-6484	\N	C	2019-12-20 22:13:53.799521+00	3221
6483	-3033	13	173	KFL 3590@Lerklining	\N	\N	1	1	-6483	\N	C	2019-12-20 22:13:53.799521+00	3222
6482	-3033	13	173	KFL 3589@Kärl	\N	\N	1	1	-6482	\N	C	2019-12-20 22:13:53.799521+00	3223
6481	-3033	13	173	KFL 3587@Kärl	\N	\N	1	1	-6481	\N	C	2019-12-20 22:13:53.799521+00	3224
6480	-3033	13	173	KFL 3586@Kärl	\N	\N	1	1	-6480	\N	C	2019-12-20 22:13:53.799521+00	3225
6479	-3033	13	173	KFL 3585@Kärl	\N	\N	1	1	-6479	\N	C	2019-12-20 22:13:53.799521+00	3226
6478	-3232	13	173	KFL 3584@Kakelugn	\N	\N	1	1	-6478	\N	C	2019-12-20 22:13:53.799521+00	3227
6477	-3296	13	173	KFL 3582@Kakelugn	\N	\N	1	1	-6477	\N	C	2019-12-20 22:13:53.799521+00	3228
6476	-3296	13	173	KFL 3581@Kakelugn	\N	\N	1	1	-6476	\N	C	2019-12-20 22:13:53.799521+00	3229
6475	-3185	13	173	KFL 3580@Kärl@24	\N	\N	1	1	-6475	\N	C	2019-12-20 22:13:53.799521+00	3230
6474	-3185	13	173	KFL 3579@Kärl@22	\N	\N	1	1	-6474	\N	C	2019-12-20 22:13:53.799521+00	3231
6473	-3185	13	173	KFL 3578@Kärl@139	\N	\N	1	1	-6473	\N	C	2019-12-20 22:13:53.799521+00	3232
6472	-3185	13	173	KFL 3577@Kärl@134	\N	\N	1	1	-6472	\N	C	2019-12-20 22:13:53.799521+00	3233
6471	-3185	13	173	KFL 3576@Kärl@50	\N	\N	1	1	-6471	\N	C	2019-12-20 22:13:53.799521+00	3234
6470	-3185	13	173	KFL 3575@Kärl@33	\N	\N	1	1	-6470	\N	C	2019-12-20 22:13:53.799521+00	3235
6469	-3185	13	173	KFL 3574@Kärl@149	\N	\N	1	1	-6469	\N	C	2019-12-20 22:13:53.799521+00	3236
6468	-3185	13	173	KFL 3573@Kärl@80	\N	\N	1	1	-6468	\N	C	2019-12-20 22:13:53.799521+00	3237
6467	-3185	13	173	KFL 3572@Kärl@78	\N	\N	1	1	-6467	\N	C	2019-12-20 22:13:53.799521+00	3238
6466	-3185	13	173	KFL 3571@Kärl@74	\N	\N	1	1	-6466	\N	C	2019-12-20 22:13:53.799521+00	3239
6465	-3185	13	173	KFL 3570@Kärl@151	\N	\N	1	1	-6465	\N	C	2019-12-20 22:13:53.799521+00	3240
6464	-3148	13	173	KFL 3565@Kärl	\N	\N	1	1	-6464	\N	C	2019-12-20 22:13:53.799521+00	3241
6463	-3148	13	173	KFL 3564@Kärl	\N	\N	1	1	-6463	\N	C	2019-12-20 22:13:53.799521+00	3242
6462	-3148	13	173	KFL 3563@Kärl	\N	\N	1	1	-6462	\N	C	2019-12-20 22:13:53.799521+00	3243
6461	-3148	13	173	KFL 3562@Gjutform	\N	\N	1	1	-6461	\N	C	2019-12-20 22:13:53.799521+00	3244
6460	-3148	13	173	KFL 3561@Gjutform	\N	\N	1	1	-6460	\N	C	2019-12-20 22:13:53.799521+00	3245
6459	-3148	13	173	KFL 3560@Gjutform	\N	\N	1	1	-6459	\N	C	2019-12-20 22:13:53.799521+00	3246
6458	-3148	13	173	KFL 3559@Gjutform	\N	\N	1	1	-6458	\N	C	2019-12-20 22:13:53.799521+00	3247
6457	-3148	13	173	KFL 3558@Gjutform	\N	\N	1	1	-6457	\N	C	2019-12-20 22:13:53.799521+00	3248
6456	-3148	13	173	KFL 3557@Gjutform	\N	\N	1	1	-6456	\N	C	2019-12-20 22:13:53.799521+00	3249
6455	-3148	13	173	KFL 3556@Gjutform	\N	\N	1	1	-6455	\N	C	2019-12-20 22:13:53.799521+00	3250
6454	-3148	13	173	KFL 3555@Gjutform	\N	\N	1	1	-6454	\N	C	2019-12-20 22:13:53.799521+00	3251
6453	-3148	13	173	KFL 3554@Gjutform	\N	\N	1	1	-6453	\N	C	2019-12-20 22:13:53.799521+00	3252
6452	-3148	13	173	KFL 3553@Gjutform	\N	\N	1	1	-6452	\N	C	2019-12-20 22:13:53.799521+00	3253
6451	-3148	13	173	KFL 3552@Gjutform	\N	\N	1	1	-6451	\N	C	2019-12-20 22:13:53.799521+00	3254
6450	-3148	13	173	KFL 3551@Gjutform	\N	\N	1	1	-6450	\N	C	2019-12-20 22:13:53.799521+00	3255
6449	-3148	13	173	KFL 3550@Degel	\N	\N	1	1	-6449	\N	C	2019-12-20 22:13:53.799521+00	3256
6448	-3386	13	173	KFL 3549@Lerklining	\N	\N	1	1	-6448	\N	C	2019-12-20 22:13:53.799521+00	3257
6447	-3386	13	173	KFL 3548@Lerklining	\N	\N	1	1	-6447	\N	C	2019-12-20 22:13:53.799521+00	3258
6446	-3386	13	173	KFL 3547@Lerklining	\N	\N	1	1	-6446	\N	C	2019-12-20 22:13:53.799521+00	3259
6445	-3386	13	173	KFL 3546@Lerklining	\N	\N	1	1	-6445	\N	C	2019-12-20 22:13:53.799521+00	3260
6444	-3386	13	173	KFL 3545@Lerklining	\N	\N	1	1	-6444	\N	C	2019-12-20 22:13:53.799521+00	3261
6443	-3310	13	173	KFL 3544@Lerklining	\N	\N	1	1	-6443	\N	C	2019-12-20 22:13:53.799521+00	3262
6442	-3310	13	173	KFL 3543@Lerklining	\N	\N	1	1	-6442	\N	C	2019-12-20 22:13:53.799521+00	3263
6441	-3310	13	173	KFL 3542@Lerklining	\N	\N	1	1	-6441	\N	C	2019-12-20 22:13:53.799521+00	3264
6440	-3324	13	173	KFL 3541@Tegel	\N	\N	1	1	-6440	\N	C	2019-12-20 22:13:53.799521+00	3265
6439	-3324	13	173	KFL 3540@Tegel	\N	\N	1	1	-6439	\N	C	2019-12-20 22:13:53.799521+00	3266
6438	-3324	13	173	KFL 3539@Tegel	\N	\N	1	1	-6438	\N	C	2019-12-20 22:13:53.799521+00	3267
6437	-3167	13	173	KFL 3538@Kärl	\N	\N	1	1	-6437	\N	C	2019-12-20 22:13:53.799521+00	3268
6436	-3167	13	173	KFL 3537@Kärl	\N	\N	1	1	-6436	\N	C	2019-12-20 22:13:53.799521+00	3269
6435	-3167	13	173	KFL 3536@Kärl	\N	\N	1	1	-6435	\N	C	2019-12-20 22:13:53.799521+00	3270
6434	-3167	13	173	KFL 3535@Kärl	\N	\N	1	1	-6434	\N	C	2019-12-20 22:13:53.799521+00	3271
6433	-3167	13	173	KFL 3534@Kärl	\N	\N	1	1	-6433	\N	C	2019-12-20 22:13:53.799521+00	3272
6432	-3167	13	173	KFL 3533@Kärl	\N	\N	1	1	-6432	\N	C	2019-12-20 22:13:53.799521+00	3273
6431	-3167	13	173	KFL 3532@Kärl	\N	\N	1	1	-6431	\N	C	2019-12-20 22:13:53.799521+00	3274
6430	-3385	13	173	KFL 3531@Lerklining	\N	\N	1	1	-6430	\N	C	2019-12-20 22:13:53.799521+00	3275
6429	-3385	13	173	KFL 3530@Lerklining	\N	\N	1	1	-6429	\N	C	2019-12-20 22:13:53.799521+00	3276
6428	-3385	13	173	KFL 3529@Kärl	\N	\N	1	1	-6428	\N	C	2019-12-20 22:13:53.799521+00	3277
6427	-3385	13	173	KFL 3528@Kärl	\N	\N	1	1	-6427	\N	C	2019-12-20 22:13:53.799521+00	3278
6426	-3385	13	173	KFL 3527@Kärl	\N	\N	1	1	-6426	\N	C	2019-12-20 22:13:53.799521+00	3279
6425	-3385	13	173	KFL 3526@Kärl	\N	\N	1	1	-6425	\N	C	2019-12-20 22:13:53.799521+00	3280
6424	-3385	13	173	KFL 3525@Kärl	\N	\N	1	1	-6424	\N	C	2019-12-20 22:13:53.799521+00	3281
6423	-3385	13	173	KFL 3524@Kärl	\N	\N	1	1	-6423	\N	C	2019-12-20 22:13:53.799521+00	3282
6422	-3385	13	173	KFL 3523@Kärl	\N	\N	1	1	-6422	\N	C	2019-12-20 22:13:53.799521+00	3283
6421	-3385	13	173	KFL 3522@Kärl	\N	\N	1	1	-6421	\N	C	2019-12-20 22:13:53.799521+00	3284
6420	-3385	13	173	KFL 3521@Kärl	\N	\N	1	1	-6420	\N	C	2019-12-20 22:13:53.799521+00	3285
6419	-3385	13	173	KFL 3520@Kärl	\N	\N	1	1	-6419	\N	C	2019-12-20 22:13:53.799521+00	3286
6418	-3385	13	173	KFL 3519@Kärl	\N	\N	1	1	-6418	\N	C	2019-12-20 22:13:53.799521+00	3287
6417	-3341	13	173	KFL 3512@Kärl	\N	\N	1	1	-6417	\N	C	2019-12-20 22:13:53.799521+00	3288
6416	-3341	13	173	KFL 3511@Kärl	\N	\N	1	1	-6416	\N	C	2019-12-20 22:13:53.799521+00	3289
6415	-3341	13	173	KFL 3510@Kärl	\N	\N	1	1	-6415	\N	C	2019-12-20 22:13:53.799521+00	3290
6414	-3341	13	173	KFL 3509@Kärl	\N	\N	1	1	-6414	\N	C	2019-12-20 22:13:53.799521+00	3291
6413	-3341	13	173	KFL 3508@Kärl	\N	\N	1	1	-6413	\N	C	2019-12-20 22:13:53.799521+00	3292
6412	-3341	13	173	KFL 3507@Kärl	\N	\N	1	1	-6412	\N	C	2019-12-20 22:13:53.799521+00	3293
6411	-3341	13	173	KFL 3506@Kärl	\N	\N	1	1	-6411	\N	C	2019-12-20 22:13:53.799521+00	3294
6410	-3341	13	173	KFL 3505@Kärl	\N	\N	1	1	-6410	\N	C	2019-12-20 22:13:53.799521+00	3295
6409	-3361	13	173	KFL 3504@Kärl@6	\N	\N	1	1	-6409	\N	C	2019-12-20 22:13:53.799521+00	3296
6408	-3361	13	173	KFL 3503@Kärl@4	\N	\N	1	1	-6408	\N	C	2019-12-20 22:13:53.799521+00	3297
6407	-3361	13	173	KFL 3502@Kärl@3	\N	\N	1	1	-6407	\N	C	2019-12-20 22:13:53.799521+00	3298
6406	-3361	13	173	KFL 3501@Kärl@2	\N	\N	1	1	-6406	\N	C	2019-12-20 22:13:53.799521+00	3299
6405	-3361	13	173	KFL 3500@Kärl@1	\N	\N	1	1	-6405	\N	C	2019-12-20 22:13:53.799521+00	3300
6404	-3199	13	173	KFL 3499@Kärl	\N	\N	1	1	-6404	\N	C	2019-12-20 22:13:53.799521+00	3301
6403	-3199	13	173	KFL 3498@Kärl	\N	\N	1	1	-6403	\N	C	2019-12-20 22:13:53.799521+00	3302
6402	-3199	13	173	KFL 3497@Kärl	\N	\N	1	1	-6402	\N	C	2019-12-20 22:13:53.799521+00	3303
6401	-3199	13	173	KFL 3496@Kärl	\N	\N	1	1	-6401	\N	C	2019-12-20 22:13:53.799521+00	3304
6400	-3199	13	173	KFL 3493@Kärl	\N	\N	1	1	-6400	\N	C	2019-12-20 22:13:53.799521+00	3305
6399	-3199	13	173	KFL 3492@Kärl	\N	\N	1	1	-6399	\N	C	2019-12-20 22:13:53.799521+00	3306
6398	-3358	13	173	KFL 3491@Degel	\N	\N	1	1	-6398	\N	C	2019-12-20 22:13:53.799521+00	3307
6397	-3358	13	173	KFL 3490@Gjutform	\N	\N	1	1	-6397	\N	C	2019-12-20 22:13:53.799521+00	3308
6396	-3358	13	173	KFL 3489@Degel	\N	\N	1	1	-6396	\N	C	2019-12-20 22:13:53.799521+00	3309
6395	-3358	13	173	KFL 3488@Degel	\N	\N	1	1	-6395	\N	C	2019-12-20 22:13:53.799521+00	3310
6394	-3358	13	173	KFL 3487@Degel	\N	\N	1	1	-6394	\N	C	2019-12-20 22:13:53.799521+00	3311
6393	-3358	13	173	KFL 3486@Degel	\N	\N	1	1	-6393	\N	C	2019-12-20 22:13:53.799521+00	3312
6392	-3358	13	173	KFL 3485@Degel	\N	\N	1	1	-6392	\N	C	2019-12-20 22:13:53.799521+00	3313
6391	-3358	13	173	KFL 3484@Degel	\N	\N	1	1	-6391	\N	C	2019-12-20 22:13:53.799521+00	3314
6390	-3358	13	173	KFL 3483@Gjutform	\N	\N	1	1	-6390	\N	C	2019-12-20 22:13:53.799521+00	3315
6389	-3358	13	173	KFL 3482@Gjutform	\N	\N	1	1	-6389	\N	C	2019-12-20 22:13:53.799521+00	3316
6388	-3358	13	173	KFL 3481@Gjutform	\N	\N	1	1	-6388	\N	C	2019-12-20 22:13:53.799521+00	3317
6387	-3358	13	173	KFL 3480@Gjutform	\N	\N	1	1	-6387	\N	C	2019-12-20 22:13:53.799521+00	3318
6386	-3358	13	173	KFL 3479@Gjutform	\N	\N	1	1	-6386	\N	C	2019-12-20 22:13:53.799521+00	3319
6385	-3358	13	173	KFL 3478@Gjutform	\N	\N	1	1	-6385	\N	C	2019-12-20 22:13:53.799521+00	3320
6384	-3088	13	173	KFL 3477@Lerklining	\N	\N	1	1	-6384	\N	C	2019-12-20 22:13:53.799521+00	3321
6383	-3088	13	173	KFL 3476@Kärl	\N	\N	1	1	-6383	\N	C	2019-12-20 22:13:53.799521+00	3322
6382	-3088	13	173	KFL 3475@Jordprov	\N	\N	1	1	-6382	\N	C	2019-12-20 22:13:53.799521+00	3323
6381	-3088	13	173	KFL 3474@Kärl	\N	\N	1	1	-6381	\N	C	2019-12-20 22:13:53.799521+00	3324
6380	-3088	13	173	KFL 3473@Kärl	\N	\N	1	1	-6380	\N	C	2019-12-20 22:13:53.799521+00	3325
6379	-3256	13	173	KFL 3472@Tegel	\N	\N	1	1	-6379	\N	C	2019-12-20 22:13:53.799521+00	3326
6378	-3256	13	173	KFL 3471@Tegel	\N	\N	1	1	-6378	\N	C	2019-12-20 22:13:53.799521+00	3327
6377	-3256	13	173	KFL 3470@Tegel	\N	\N	1	1	-6377	\N	C	2019-12-20 22:13:53.799521+00	3328
6376	-3256	13	173	KFL 3469@Lerklining	\N	\N	1	1	-6376	\N	C	2019-12-20 22:13:53.799521+00	3329
6375	-3256	13	173	KFL 3468@Lerklining	\N	\N	1	1	-6375	\N	C	2019-12-20 22:13:53.799521+00	3330
6374	-3256	13	173	KFL 3467@Lerklining	\N	\N	1	1	-6374	\N	C	2019-12-20 22:13:53.799521+00	3331
6373	-3256	13	173	KFL 3466@Lerklining	\N	\N	1	1	-6373	\N	C	2019-12-20 22:13:53.799521+00	3332
6372	-3256	13	173	KFL 3465@Lerklining	\N	\N	1	1	-6372	\N	C	2019-12-20 22:13:53.799521+00	3333
6371	-3256	13	173	KFL 3464@Tegel	\N	\N	1	1	-6371	\N	C	2019-12-20 22:13:53.799521+00	3334
6370	-3256	13	173	KFL 3463@Tegel	\N	\N	1	1	-6370	\N	C	2019-12-20 22:13:53.799521+00	3335
6369	-3256	13	173	KFL 3462@Tegel	\N	\N	1	1	-6369	\N	C	2019-12-20 22:13:53.799521+00	3336
6368	-3256	13	173	KFL 3461@Tegel	\N	\N	1	1	-6368	\N	C	2019-12-20 22:13:53.799521+00	3337
6367	-3184	13	173	KFL 3460@Kärl@C2	\N	\N	1	1	-6367	\N	C	2019-12-20 22:13:53.799521+00	3338
6366	-3184	13	173	KFL 3459@Kärl@A10	\N	\N	1	1	-6366	\N	C	2019-12-20 22:13:53.799521+00	3339
6365	-3184	13	173	KFL 3458@Kärl@A8	\N	\N	1	1	-6365	\N	C	2019-12-20 22:13:53.799521+00	3340
6364	-3184	13	173	KFL 3457@Kärl@N6	\N	\N	1	1	-6364	\N	C	2019-12-20 22:13:53.799521+00	3341
6363	-3184	13	173	KFL 3456@Kärl@N3	\N	\N	1	1	-6363	\N	C	2019-12-20 22:13:53.799521+00	3342
6362	-3184	13	173	KFL 3455@Kärl@M4	\N	\N	1	1	-6362	\N	C	2019-12-20 22:13:53.799521+00	3343
6361	-3184	13	173	KFL 3454@Kärl@L6	\N	\N	1	1	-6361	\N	C	2019-12-20 22:13:53.799521+00	3344
6360	-3184	13	173	KFL 3453@Kärl@H15	\N	\N	1	1	-6360	\N	C	2019-12-20 22:13:53.799521+00	3345
6359	-3184	13	173	KFL 3452@Kärl@H6	\N	\N	1	1	-6359	\N	C	2019-12-20 22:13:53.799521+00	3346
6358	-3184	13	173	KFL 3451@Kärl@G17a	\N	\N	1	1	-6358	\N	C	2019-12-20 22:13:53.799521+00	3347
6357	-3184	13	173	KFL 3450@Kärl@D30	\N	\N	1	1	-6357	\N	C	2019-12-20 22:13:53.799521+00	3348
6356	-3184	13	173	KFL 3449@Kärl@D17	\N	\N	1	1	-6356	\N	C	2019-12-20 22:13:53.799521+00	3349
6274	-3106	13	173	KFL 3344@Kärl	\N	\N	1	1	-6274	\N	C	2019-12-20 22:13:53.799521+00	3431
6355	-3184	13	173	KFL 3448@Kärl@D12	\N	\N	1	1	-6355	\N	C	2019-12-20 22:13:53.799521+00	3350
6354	-3184	13	173	KFL 3447@Kärl@D11	\N	\N	1	1	-6354	\N	C	2019-12-20 22:13:53.799521+00	3351
6353	-3184	13	173	KFL 3446@Kärl@D3b	\N	\N	1	1	-6353	\N	C	2019-12-20 22:13:53.799521+00	3352
6352	-3105	13	173	KFL 3445@Kärl	\N	\N	1	1	-6352	\N	C	2019-12-20 22:13:53.799521+00	3353
6351	-3105	13	173	KFL 3444@Kärl	\N	\N	1	1	-6351	\N	C	2019-12-20 22:13:53.799521+00	3354
6350	-3105	13	173	KFL 3443@Kärl	\N	\N	1	1	-6350	\N	C	2019-12-20 22:13:53.799521+00	3355
6349	-3105	13	173	KFL 3442@Kärl	\N	\N	1	1	-6349	\N	C	2019-12-20 22:13:53.799521+00	3356
6348	-3016	13	173	KFL 3441@Kärl	\N	\N	1	1	-6348	\N	C	2019-12-20 22:13:53.799521+00	3357
6347	-3016	13	173	KFL 3440@Kärl	\N	\N	1	1	-6347	\N	C	2019-12-20 22:13:53.799521+00	3358
6346	-3016	13	173	KFL 3439@Kärl	\N	\N	1	1	-6346	\N	C	2019-12-20 22:13:53.799521+00	3359
6345	-3016	13	173	KFL 3438@Kärl	\N	\N	1	1	-6345	\N	C	2019-12-20 22:13:53.799521+00	3360
6344	-3150	13	173	KFL 3437@Kärl	\N	\N	1	1	-6344	\N	C	2019-12-20 22:13:53.799521+00	3361
6343	-3150	13	173	KFL 3436@Kärl	\N	\N	1	1	-6343	\N	C	2019-12-20 22:13:53.799521+00	3362
6342	-3150	13	173	KFL 3435@Kärl	\N	\N	1	1	-6342	\N	C	2019-12-20 22:13:53.799521+00	3363
6341	-3150	13	173	KFL 3434@Kärl	\N	\N	1	1	-6341	\N	C	2019-12-20 22:13:53.799521+00	3364
6340	-3150	13	173	KFL 3433@Kärl	\N	\N	1	1	-6340	\N	C	2019-12-20 22:13:53.799521+00	3365
6339	-3150	13	173	KFL 3432@Kärl	\N	\N	1	1	-6339	\N	C	2019-12-20 22:13:53.799521+00	3366
6338	-3150	13	173	KFL 3429@Kärl	\N	\N	1	1	-6338	\N	C	2019-12-20 22:13:53.799521+00	3367
6337	-3150	13	173	KFL 3428@Kärl	\N	\N	1	1	-6337	\N	C	2019-12-20 22:13:53.799521+00	3368
6336	-3150	13	173	KFL 3427@Kärl	\N	\N	1	1	-6336	\N	C	2019-12-20 22:13:53.799521+00	3369
6335	-3150	13	173	KFL 3426@Kärl	\N	\N	1	1	-6335	\N	C	2019-12-20 22:13:53.799521+00	3370
6334	-3150	13	173	KFL 3425@Kärl	\N	\N	1	1	-6334	\N	C	2019-12-20 22:13:53.799521+00	3371
6333	-3150	13	173	KFL 3424@Kärl	\N	\N	1	1	-6333	\N	C	2019-12-20 22:13:53.799521+00	3372
6332	-3150	13	173	KFL 3423@Kärl	\N	\N	1	1	-6332	\N	C	2019-12-20 22:13:53.799521+00	3373
6331	-3150	13	173	KFL 3422@Kärl	\N	\N	1	1	-6331	\N	C	2019-12-20 22:13:53.799521+00	3374
6330	-3150	13	173	KFL 3421@Kärl	\N	\N	1	1	-6330	\N	C	2019-12-20 22:13:53.799521+00	3375
6329	-3150	13	173	KFL 3420@Kärl	\N	\N	1	1	-6329	\N	C	2019-12-20 22:13:53.799521+00	3376
6328	-3150	13	173	KFL 3419@Kärl	\N	\N	1	1	-6328	\N	C	2019-12-20 22:13:53.799521+00	3377
6327	-3150	13	173	KFL 3418@Kärl	\N	\N	1	1	-6327	\N	C	2019-12-20 22:13:53.799521+00	3378
6326	-3150	13	173	KFL 3417@Kärl	\N	\N	1	1	-6326	\N	C	2019-12-20 22:13:53.799521+00	3379
6325	-3150	13	173	KFL 3416@Kärl	\N	\N	1	1	-6325	\N	C	2019-12-20 22:13:53.799521+00	3380
6324	-3150	13	173	KFL 3415@Kärl	\N	\N	1	1	-6324	\N	C	2019-12-20 22:13:53.799521+00	3381
6323	-3150	13	173	KFL 3414@Kärl	\N	\N	1	1	-6323	\N	C	2019-12-20 22:13:53.799521+00	3382
6322	-3150	13	173	KFL 3413@Kärl	\N	\N	1	1	-6322	\N	C	2019-12-20 22:13:53.799521+00	3383
6321	-3150	13	173	KFL 3412@Kärl	\N	\N	1	1	-6321	\N	C	2019-12-20 22:13:53.799521+00	3384
6320	-3150	13	173	KFL 3411@Kärl	\N	\N	1	1	-6320	\N	C	2019-12-20 22:13:53.799521+00	3385
6319	-3150	13	173	KFL 3410@Kärl	\N	\N	1	1	-6319	\N	C	2019-12-20 22:13:53.799521+00	3386
6318	-3150	13	173	KFL 3409@Kärl	\N	\N	1	1	-6318	\N	C	2019-12-20 22:13:53.799521+00	3387
6317	-3150	13	173	KFL 3408@Kärl	\N	\N	1	1	-6317	\N	C	2019-12-20 22:13:53.799521+00	3388
6316	-3150	13	173	KFL 3407@Kärl	\N	\N	1	1	-6316	\N	C	2019-12-20 22:13:53.799521+00	3389
6315	-3150	13	173	KFL 3406@Kärl	\N	\N	1	1	-6315	\N	C	2019-12-20 22:13:53.799521+00	3390
6314	-2979	13	173	KFL 3405@Kärl	\N	\N	1	1	-6314	\N	C	2019-12-20 22:13:53.799521+00	3391
6313	-2979	13	173	KFL 3403@Kärl	\N	\N	1	1	-6313	\N	C	2019-12-20 22:13:53.799521+00	3392
6312	-2979	13	173	KFL 3402@Kärl	\N	\N	1	1	-6312	\N	C	2019-12-20 22:13:53.799521+00	3393
6311	-2979	13	173	KFL 3401@Kärl	\N	\N	1	1	-6311	\N	C	2019-12-20 22:13:53.799521+00	3394
6310	-2979	13	173	KFL 3400@Kärl	\N	\N	1	1	-6310	\N	C	2019-12-20 22:13:53.799521+00	3395
6309	-2979	13	173	KFL 3399@Kärl	\N	\N	1	1	-6309	\N	C	2019-12-20 22:13:53.799521+00	3396
6308	-2979	13	173	KFL 3398@Kärl	\N	\N	1	1	-6308	\N	C	2019-12-20 22:13:53.799521+00	3397
6307	-2979	13	173	KFL 3397@Kärl	\N	\N	1	1	-6307	\N	C	2019-12-20 22:13:53.799521+00	3398
6306	-2979	13	173	KFL 3396@Kärl	\N	\N	1	1	-6306	\N	C	2019-12-20 22:13:53.799521+00	3399
6305	-2979	13	173	KFL 3395@Kärl	\N	\N	1	1	-6305	\N	C	2019-12-20 22:13:53.799521+00	3400
6304	-3106	13	173	KFL 3374@Kärl	\N	\N	1	1	-6304	\N	C	2019-12-20 22:13:53.799521+00	3401
6303	-3106	13	173	KFL 3373@Kärl	\N	\N	1	1	-6303	\N	C	2019-12-20 22:13:53.799521+00	3402
6302	-3106	13	173	KFL 3372@Kärl	\N	\N	1	1	-6302	\N	C	2019-12-20 22:13:53.799521+00	3403
6301	-3106	13	173	KFL 3371@Kärl	\N	\N	1	1	-6301	\N	C	2019-12-20 22:13:53.799521+00	3404
6300	-3106	13	173	KFL 3370@Kärl	\N	\N	1	1	-6300	\N	C	2019-12-20 22:13:53.799521+00	3405
6299	-3106	13	173	KFL 3369@Kärl	\N	\N	1	1	-6299	\N	C	2019-12-20 22:13:53.799521+00	3406
6298	-3106	13	173	KFL 3368@Kärl	\N	\N	1	1	-6298	\N	C	2019-12-20 22:13:53.799521+00	3407
6297	-3106	13	173	KFL 3367@Kärl	\N	\N	1	1	-6297	\N	C	2019-12-20 22:13:53.799521+00	3408
6296	-3106	13	173	KFL 3366@Kärl	\N	\N	1	1	-6296	\N	C	2019-12-20 22:13:53.799521+00	3409
6295	-3106	13	173	KFL 3365@Kärl	\N	\N	1	1	-6295	\N	C	2019-12-20 22:13:53.799521+00	3410
6294	-3106	13	173	KFL 3364@Kärl	\N	\N	1	1	-6294	\N	C	2019-12-20 22:13:53.799521+00	3411
6293	-3106	13	173	KFL 3363@Kärl	\N	\N	1	1	-6293	\N	C	2019-12-20 22:13:53.799521+00	3412
6292	-3106	13	173	KFL 3362@Kärl	\N	\N	1	1	-6292	\N	C	2019-12-20 22:13:53.799521+00	3413
6291	-3106	13	173	KFL 3361@Kärl	\N	\N	1	1	-6291	\N	C	2019-12-20 22:13:53.799521+00	3414
6290	-3106	13	173	KFL 3360@Kärl	\N	\N	1	1	-6290	\N	C	2019-12-20 22:13:53.799521+00	3415
6289	-3106	13	173	KFL 3359@Kärl	\N	\N	1	1	-6289	\N	C	2019-12-20 22:13:53.799521+00	3416
6288	-3106	13	173	KFL 3358@Kärl	\N	\N	1	1	-6288	\N	C	2019-12-20 22:13:53.799521+00	3417
6287	-3106	13	173	KFL 3357@Kärl	\N	\N	1	1	-6287	\N	C	2019-12-20 22:13:53.799521+00	3418
6286	-3106	13	173	KFL 3356@Kärl	\N	\N	1	1	-6286	\N	C	2019-12-20 22:13:53.799521+00	3419
6285	-3106	13	173	KFL 3355@Kärl	\N	\N	1	1	-6285	\N	C	2019-12-20 22:13:53.799521+00	3420
6284	-3106	13	173	KFL 3354@Kärl	\N	\N	1	1	-6284	\N	C	2019-12-20 22:13:53.799521+00	3421
6283	-3106	13	173	KFL 3353@Kärl	\N	\N	1	1	-6283	\N	C	2019-12-20 22:13:53.799521+00	3422
6282	-3106	13	173	KFL 3352@Kärl	\N	\N	1	1	-6282	\N	C	2019-12-20 22:13:53.799521+00	3423
6281	-3106	13	173	KFL 3351@Kärl	\N	\N	1	1	-6281	\N	C	2019-12-20 22:13:53.799521+00	3424
6280	-3106	13	173	KFL 3350@Kärl	\N	\N	1	1	-6280	\N	C	2019-12-20 22:13:53.799521+00	3425
6279	-3106	13	173	KFL 3349@Kärl	\N	\N	1	1	-6279	\N	C	2019-12-20 22:13:53.799521+00	3426
6278	-3106	13	173	KFL 3348@Kärl	\N	\N	1	1	-6278	\N	C	2019-12-20 22:13:53.799521+00	3427
6277	-3106	13	173	KFL 3347@Lerskiva	\N	\N	1	1	-6277	\N	C	2019-12-20 22:13:53.799521+00	3428
6276	-3106	13	173	KFL 3346@Kärl	\N	\N	1	1	-6276	\N	C	2019-12-20 22:13:53.799521+00	3429
6275	-3106	13	173	KFL 3345@Kärl	\N	\N	1	1	-6275	\N	C	2019-12-20 22:13:53.799521+00	3430
6273	-3106	13	173	KFL 3343@Kärl	\N	\N	1	1	-6273	\N	C	2019-12-20 22:13:53.799521+00	3432
6272	-3106	13	173	KFL 3342@Kärl	\N	\N	1	1	-6272	\N	C	2019-12-20 22:13:53.799521+00	3433
6271	-3106	13	173	KFL 3341@Kärl	\N	\N	1	1	-6271	\N	C	2019-12-20 22:13:53.799521+00	3434
6270	-3106	13	173	KFL 3340@Kärl	\N	\N	1	1	-6270	\N	C	2019-12-20 22:13:53.799521+00	3435
6269	-3106	13	173	KFL 3339@Kärl	\N	\N	1	1	-6269	\N	C	2019-12-20 22:13:53.799521+00	3436
6268	-3106	13	173	KFL 3338@Kärl	\N	\N	1	1	-6268	\N	C	2019-12-20 22:13:53.799521+00	3437
6267	-3106	13	173	KFL 3337@Kärl	\N	\N	1	1	-6267	\N	C	2019-12-20 22:13:53.799521+00	3438
6266	-3320	13	173	KFL 3330@Kärl	\N	\N	1	1	-6266	\N	C	2019-12-20 22:13:53.799521+00	3439
6265	-3320	13	173	KFL 3329@Kärl	\N	\N	1	1	-6265	\N	C	2019-12-20 22:13:53.799521+00	3440
6264	-3320	13	173	KFL 3328@Kärl	\N	\N	1	1	-6264	\N	C	2019-12-20 22:13:53.799521+00	3441
6263	-3320	13	173	KFL 3327@Kärl	\N	\N	1	1	-6263	\N	C	2019-12-20 22:13:53.799521+00	3442
6262	-3320	13	173	KFL 3326@Kärl	\N	\N	1	1	-6262	\N	C	2019-12-20 22:13:53.799521+00	3443
6261	-3320	13	173	KFL 3325@Kärl	\N	\N	1	1	-6261	\N	C	2019-12-20 22:13:53.799521+00	3444
6260	-3320	13	173	KFL 3324@Kärl	\N	\N	1	1	-6260	\N	C	2019-12-20 22:13:53.799521+00	3445
6259	-3151	13	173	KFL 3323@Kärl	\N	\N	1	1	-6259	\N	C	2019-12-20 22:13:53.799521+00	3446
6258	-3151	13	173	KFL 3322@Kärl	\N	\N	1	1	-6258	\N	C	2019-12-20 22:13:53.799521+00	3447
6257	-3077	13	173	KFL 3321@Kärl	\N	\N	1	1	-6257	\N	C	2019-12-20 22:13:53.799521+00	3448
6256	-3077	13	173	KFL 3320@Kärl	\N	\N	1	1	-6256	\N	C	2019-12-20 22:13:53.799521+00	3449
6255	-3077	13	173	KFL 3319@Kärl	\N	\N	1	1	-6255	\N	C	2019-12-20 22:13:53.799521+00	3450
6254	-3077	13	173	KFL 3318@Kärl	\N	\N	1	1	-6254	\N	C	2019-12-20 22:13:53.799521+00	3451
6253	-3077	13	173	KFL 3317@Kärl	\N	\N	1	1	-6253	\N	C	2019-12-20 22:13:53.799521+00	3452
6252	-3077	13	173	KFL 3316@Kärl	\N	\N	1	1	-6252	\N	C	2019-12-20 22:13:53.799521+00	3453
6251	-3077	13	173	KFL 3315@Kärl	\N	\N	1	1	-6251	\N	C	2019-12-20 22:13:53.799521+00	3454
6250	-3077	13	173	KFL 3314@Kärl	\N	\N	1	1	-6250	\N	C	2019-12-20 22:13:53.799521+00	3455
6249	-3077	13	173	KFL 3313@Kärl	\N	\N	1	1	-6249	\N	C	2019-12-20 22:13:53.799521+00	3456
6248	-3077	13	173	KFL 3312@Kärl	\N	\N	1	1	-6248	\N	C	2019-12-20 22:13:53.799521+00	3457
6247	-3077	13	173	KFL 3311@Kärl	\N	\N	1	1	-6247	\N	C	2019-12-20 22:13:53.799521+00	3458
6246	-3077	13	173	KFL 3310@Kärl	\N	\N	1	1	-6246	\N	C	2019-12-20 22:13:53.799521+00	3459
6245	-3077	13	173	KFL 3309@Kärl	\N	\N	1	1	-6245	\N	C	2019-12-20 22:13:53.799521+00	3460
6244	-3077	13	173	KFL 3308@Kärl	\N	\N	1	1	-6244	\N	C	2019-12-20 22:13:53.799521+00	3461
6243	-3077	13	173	KFL 3307@Kärl	\N	\N	1	1	-6243	\N	C	2019-12-20 22:13:53.799521+00	3462
6242	-3077	13	173	KFL 3306@Kärl	\N	\N	1	1	-6242	\N	C	2019-12-20 22:13:53.799521+00	3463
6241	-3077	13	173	KFL 3305@Kärl	\N	\N	1	1	-6241	\N	C	2019-12-20 22:13:53.799521+00	3464
6240	-3077	13	173	KFL 3304@Kärl	\N	\N	1	1	-6240	\N	C	2019-12-20 22:13:53.799521+00	3465
6239	-3077	13	173	KFL 3303@Kärl	\N	\N	1	1	-6239	\N	C	2019-12-20 22:13:53.799521+00	3466
6238	-3077	13	173	KFL 3302@Kärl	\N	\N	1	1	-6238	\N	C	2019-12-20 22:13:53.799521+00	3467
6237	-3077	13	173	KFL 3300@Kärl	\N	\N	1	1	-6237	\N	C	2019-12-20 22:13:53.799521+00	3468
6236	-3077	13	173	KFL 3299@Kärl	\N	\N	1	1	-6236	\N	C	2019-12-20 22:13:53.799521+00	3469
6235	-3077	13	173	KFL 3298@Kärl	\N	\N	1	1	-6235	\N	C	2019-12-20 22:13:53.799521+00	3470
6234	-3077	13	173	KFL 3296@Kärl	\N	\N	1	1	-6234	\N	C	2019-12-20 22:13:53.799521+00	3471
6233	-3077	13	173	KFL 3295@Kärl	\N	\N	1	1	-6233	\N	C	2019-12-20 22:13:53.799521+00	3472
6232	-3077	13	173	KFL 3294@Kärl	\N	\N	1	1	-6232	\N	C	2019-12-20 22:13:53.799521+00	3473
6231	-3077	13	173	KFL 3293@Kärl	\N	\N	1	1	-6231	\N	C	2019-12-20 22:13:53.799521+00	3474
6230	-3077	13	173	KFL 3292@Kärl	\N	\N	1	1	-6230	\N	C	2019-12-20 22:13:53.799521+00	3475
6229	-3077	13	173	KFL 3290@Kärl	\N	\N	1	1	-6229	\N	C	2019-12-20 22:13:53.799521+00	3476
6228	-3077	13	173	KFL 3289@Kärl	\N	\N	1	1	-6228	\N	C	2019-12-20 22:13:53.799521+00	3477
6227	-3077	13	173	KFL 3288@Kärl	\N	\N	1	1	-6227	\N	C	2019-12-20 22:13:53.799521+00	3478
6226	-3077	13	173	KFL 3287@Kärl	\N	\N	1	1	-6226	\N	C	2019-12-20 22:13:53.799521+00	3479
6225	-3077	13	173	KFL 3286@Kärl	\N	\N	1	1	-6225	\N	C	2019-12-20 22:13:53.799521+00	3480
6224	-3344	13	173	KFL 3285@Kärl	\N	\N	1	1	-6224	\N	C	2019-12-20 22:13:53.799521+00	3481
6223	-3344	13	173	KFL 3284@Kärl	\N	\N	1	1	-6223	\N	C	2019-12-20 22:13:53.799521+00	3482
6222	-3344	13	173	KFL 3282@Kärl	\N	\N	1	1	-6222	\N	C	2019-12-20 22:13:53.799521+00	3483
6221	-3344	13	173	KFL 3281@Kärl	\N	\N	1	1	-6221	\N	C	2019-12-20 22:13:53.799521+00	3484
6220	-3344	13	173	KFL 3280@Kärl	\N	\N	1	1	-6220	\N	C	2019-12-20 22:13:53.799521+00	3485
6219	-3344	13	173	KFL 3279@Kärl	\N	\N	1	1	-6219	\N	C	2019-12-20 22:13:53.799521+00	3486
6218	-3344	13	173	KFL 3278@Kärl	\N	\N	1	1	-6218	\N	C	2019-12-20 22:13:53.799521+00	3487
6217	-3344	13	173	KFL 3277@Kärl	\N	\N	1	1	-6217	\N	C	2019-12-20 22:13:53.799521+00	3488
6216	-3344	13	173	KFL 3276@Kärl	\N	\N	1	1	-6216	\N	C	2019-12-20 22:13:53.799521+00	3489
6215	-3344	13	173	KFL 3275@Kärl	\N	\N	1	1	-6215	\N	C	2019-12-20 22:13:53.799521+00	3490
6214	-3335	13	173	KFL 3274@Kärl	\N	\N	1	1	-6214	\N	C	2019-12-20 22:13:53.799521+00	3491
6213	-3335	13	173	KFL 3272@Kärl	\N	\N	1	1	-6213	\N	C	2019-12-20 22:13:53.799521+00	3492
6212	-3335	13	173	KFL 3270@Kärl	\N	\N	1	1	-6212	\N	C	2019-12-20 22:13:53.799521+00	3493
6211	-3335	13	173	KFL 3269@Kärl	\N	\N	1	1	-6211	\N	C	2019-12-20 22:13:53.799521+00	3494
6210	-3335	13	173	KFL 3268@Kärl	\N	\N	1	1	-6210	\N	C	2019-12-20 22:13:53.799521+00	3495
6209	-3335	13	173	KFL 3266@Kärl	\N	\N	1	1	-6209	\N	C	2019-12-20 22:13:53.799521+00	3496
6208	-3335	13	173	KFL 3265@Kärl	\N	\N	1	1	-6208	\N	C	2019-12-20 22:13:53.799521+00	3497
6207	-3153	13	173	KFL 3254@Jordprov	\N	\N	1	1	-6207	\N	C	2019-12-20 22:13:53.799521+00	3498
6206	-3153	13	173	KFL 3253@Lerklining	\N	\N	1	1	-6206	\N	C	2019-12-20 22:13:53.799521+00	3499
6205	-3153	13	173	KFL 3252@Lerklining	\N	\N	1	1	-6205	\N	C	2019-12-20 22:13:53.799521+00	3500
6204	-3153	13	173	KFL 3251@Tegel	\N	\N	1	1	-6204	\N	C	2019-12-20 22:13:53.799521+00	3501
6203	-3215	13	173	KFL 3250@Kärl	\N	\N	1	1	-6203	\N	C	2019-12-20 22:13:53.799521+00	3502
6202	-3215	13	173	KFL 3249@Kärl	\N	\N	1	1	-6202	\N	C	2019-12-20 22:13:53.799521+00	3503
6201	-3215	13	173	KFL 3248@Kärl	\N	\N	1	1	-6201	\N	C	2019-12-20 22:13:53.799521+00	3504
6200	-3215	13	173	KFL 3247@Kärl	\N	\N	1	1	-6200	\N	C	2019-12-20 22:13:53.799521+00	3505
6199	-3215	13	173	KFL 3246@Kärl	\N	\N	1	1	-6199	\N	C	2019-12-20 22:13:53.799521+00	3506
6198	-3215	13	173	KFL 3245@Kärl	\N	\N	1	1	-6198	\N	C	2019-12-20 22:13:53.799521+00	3507
6197	-2983	13	173	KFL 3244@Kärl	\N	\N	1	1	-6197	\N	C	2019-12-20 22:13:53.799521+00	3508
6196	-2983	13	173	KFL 3240@Kärl	\N	\N	1	1	-6196	\N	C	2019-12-20 22:13:53.799521+00	3509
6195	-2983	13	173	KFL 3238@Kärl	\N	\N	1	1	-6195	\N	C	2019-12-20 22:13:53.799521+00	3510
6194	-2983	13	173	KFL 3237@Kärl	\N	\N	1	1	-6194	\N	C	2019-12-20 22:13:53.799521+00	3511
6193	-2983	13	173	KFL 3236@Kärl	\N	\N	1	1	-6193	\N	C	2019-12-20 22:13:53.799521+00	3512
6192	-3329	13	173	KFL 3235@Kärl	\N	\N	1	1	-6192	\N	C	2019-12-20 22:13:53.799521+00	3513
6191	-3329	13	173	KFL 3234@Kärl	\N	\N	1	1	-6191	\N	C	2019-12-20 22:13:53.799521+00	3514
6190	-3329	13	173	KFL 3233@Kärl	\N	\N	1	1	-6190	\N	C	2019-12-20 22:13:53.799521+00	3515
6189	-3329	13	173	KFL 3232@Kärl	\N	\N	1	1	-6189	\N	C	2019-12-20 22:13:53.799521+00	3516
6188	-3329	13	173	KFL 3231@Kärl	\N	\N	1	1	-6188	\N	C	2019-12-20 22:13:53.799521+00	3517
6187	-3329	13	173	KFL 3230@Kärl	\N	\N	1	1	-6187	\N	C	2019-12-20 22:13:53.799521+00	3518
6186	-3329	13	173	KFL 3229@Kärl	\N	\N	1	1	-6186	\N	C	2019-12-20 22:13:53.799521+00	3519
6185	-3329	13	173	KFL 3228@Kärl	\N	\N	1	1	-6185	\N	C	2019-12-20 22:13:53.799521+00	3520
6184	-3329	13	173	KFL 3227@Kärl	\N	\N	1	1	-6184	\N	C	2019-12-20 22:13:53.799521+00	3521
6183	-3329	13	173	KFL 3226@Kärl	\N	\N	1	1	-6183	\N	C	2019-12-20 22:13:53.799521+00	3522
6182	-3329	13	173	KFL 3225@Kärl	\N	\N	1	1	-6182	\N	C	2019-12-20 22:13:53.799521+00	3523
6181	-3045	13	173	KFL 3224@Kärl	\N	\N	1	1	-6181	\N	C	2019-12-20 22:13:53.799521+00	3524
6180	-3301	13	173	KFL 3223@Kärl	\N	\N	1	1	-6180	\N	C	2019-12-20 22:13:53.799521+00	3525
6179	-3301	13	173	KFL 3222@Kärl	\N	\N	1	1	-6179	\N	C	2019-12-20 22:13:53.799521+00	3526
6178	-3301	13	173	KFL 3221@Kärl	\N	\N	1	1	-6178	\N	C	2019-12-20 22:13:53.799521+00	3527
6177	-3301	13	173	KFL 3220@Kärl	\N	\N	1	1	-6177	\N	C	2019-12-20 22:13:53.799521+00	3528
6176	-3301	13	173	KFL 3219@Kärl	\N	\N	1	1	-6176	\N	C	2019-12-20 22:13:53.799521+00	3529
6175	-3301	13	173	KFL 3218@Kärl	\N	\N	1	1	-6175	\N	C	2019-12-20 22:13:53.799521+00	3530
6174	-3301	13	173	KFL 3217@Kärl	\N	\N	1	1	-6174	\N	C	2019-12-20 22:13:53.799521+00	3531
6173	-3301	13	173	KFL 3216@Kärl	\N	\N	1	1	-6173	\N	C	2019-12-20 22:13:53.799521+00	3532
6172	-3301	13	173	KFL 3215@Kärl	\N	\N	1	1	-6172	\N	C	2019-12-20 22:13:53.799521+00	3533
6171	-3036	13	173	KFL 3214@Kärl	\N	\N	1	1	-6171	\N	C	2019-12-20 22:13:53.799521+00	3534
6170	-3045	13	173	KFL 3213@Kärl	\N	\N	1	1	-6170	\N	C	2019-12-20 22:13:53.799521+00	3535
6169	-3045	13	173	KFL 3212@Kärl	\N	\N	1	1	-6169	\N	C	2019-12-20 22:13:53.799521+00	3536
6168	-3045	13	173	KFL 3211@Kärl	\N	\N	1	1	-6168	\N	C	2019-12-20 22:13:53.799521+00	3537
6167	-3036	13	173	KFL 3210@Kärl	\N	\N	1	1	-6167	\N	C	2019-12-20 22:13:53.799521+00	3538
6166	-3036	13	173	KFL 3209@Kärl	\N	\N	1	1	-6166	\N	C	2019-12-20 22:13:53.799521+00	3539
6165	-3045	13	173	KFL 3208@Kärl	\N	\N	1	1	-6165	\N	C	2019-12-20 22:13:53.799521+00	3540
6164	-3045	13	173	KFL 3207@Kärl	\N	\N	1	1	-6164	\N	C	2019-12-20 22:13:53.799521+00	3541
6163	-3045	13	173	KFL 3206@Kärl	\N	\N	1	1	-6163	\N	C	2019-12-20 22:13:53.799521+00	3542
6162	-3045	13	173	KFL 3205@Kärl	\N	\N	1	1	-6162	\N	C	2019-12-20 22:13:53.799521+00	3543
6161	-3037	13	173	KFL 3204@Kärl	\N	\N	1	1	-6161	\N	C	2019-12-20 22:13:53.799521+00	3544
6160	-3037	13	173	KFL 3203@Kärl	\N	\N	1	1	-6160	\N	C	2019-12-20 22:13:53.799521+00	3545
6159	-3037	13	173	KFL 3202@Kärl	\N	\N	1	1	-6159	\N	C	2019-12-20 22:13:53.799521+00	3546
6158	-3037	13	173	KFL 3201@Kärl	\N	\N	1	1	-6158	\N	C	2019-12-20 22:13:53.799521+00	3547
6157	-3037	13	173	KFL 3200@Kärl	\N	\N	1	1	-6157	\N	C	2019-12-20 22:13:53.799521+00	3548
6156	-3037	13	173	KFL 3199@Kärl	\N	\N	1	1	-6156	\N	C	2019-12-20 22:13:53.799521+00	3549
6155	-3037	13	173	KFL 3198@Kärl	\N	\N	1	1	-6155	\N	C	2019-12-20 22:13:53.799521+00	3550
6154	-3037	13	173	KFL 3197@Kärl	\N	\N	1	1	-6154	\N	C	2019-12-20 22:13:53.799521+00	3551
6153	-3037	13	173	KFL 3196@Kärl	\N	\N	1	1	-6153	\N	C	2019-12-20 22:13:53.799521+00	3552
6152	-3037	13	173	KFL 3195@Kärl	\N	\N	1	1	-6152	\N	C	2019-12-20 22:13:53.799521+00	3553
6151	-3037	13	173	KFL 3194@Kärl	\N	\N	1	1	-6151	\N	C	2019-12-20 22:13:53.799521+00	3554
6150	-3037	13	173	KFL 3193@Kärl	\N	\N	1	1	-6150	\N	C	2019-12-20 22:13:53.799521+00	3555
6149	-3037	13	173	KFL 3192@Kärl	\N	\N	1	1	-6149	\N	C	2019-12-20 22:13:53.799521+00	3556
6148	-3037	13	173	KFL 3191@Kärl	\N	\N	1	1	-6148	\N	C	2019-12-20 22:13:53.799521+00	3557
6147	-3037	13	173	KFL 3190@Kärl	\N	\N	1	1	-6147	\N	C	2019-12-20 22:13:53.799521+00	3558
6146	-3037	13	173	KFL 3189@Kärl	\N	\N	1	1	-6146	\N	C	2019-12-20 22:13:53.799521+00	3559
6145	-3037	13	173	KFL 3188@Kärl	\N	\N	1	1	-6145	\N	C	2019-12-20 22:13:53.799521+00	3560
6144	-3037	13	173	KFL 3187@Kärl	\N	\N	1	1	-6144	\N	C	2019-12-20 22:13:53.799521+00	3561
6143	-3037	13	173	KFL 3185@Kärl	\N	\N	1	1	-6143	\N	C	2019-12-20 22:13:53.799521+00	3562
6142	-3037	13	173	KFL 3184@Kärl	\N	\N	1	1	-6142	\N	C	2019-12-20 22:13:53.799521+00	3563
6141	-3037	13	173	KFL 3183@Kärl	\N	\N	1	1	-6141	\N	C	2019-12-20 22:13:53.799521+00	3564
6140	-3037	13	173	KFL 3182@Kärl	\N	\N	1	1	-6140	\N	C	2019-12-20 22:13:53.799521+00	3565
6139	-3037	13	173	KFL 3181@Kärl	\N	\N	1	1	-6139	\N	C	2019-12-20 22:13:53.799521+00	3566
6138	-3037	13	173	KFL 3180@Kärl	\N	\N	1	1	-6138	\N	C	2019-12-20 22:13:53.799521+00	3567
6137	-3037	13	173	KFL 3179@Kärl	\N	\N	1	1	-6137	\N	C	2019-12-20 22:13:53.799521+00	3568
6136	-3037	13	173	KFL 3178@Kärl	\N	\N	1	1	-6136	\N	C	2019-12-20 22:13:53.799521+00	3569
6135	-3037	13	173	KFL 3177@Kärl	\N	\N	1	1	-6135	\N	C	2019-12-20 22:13:53.799521+00	3570
6134	-3037	13	173	KFL 3176@Kärl	\N	\N	1	1	-6134	\N	C	2019-12-20 22:13:53.799521+00	3571
6133	-3037	13	173	KFL 3175@Kärl	\N	\N	1	1	-6133	\N	C	2019-12-20 22:13:53.799521+00	3572
6132	-3037	13	173	KFL 3174@Kärl	\N	\N	1	1	-6132	\N	C	2019-12-20 22:13:53.799521+00	3573
6131	-3037	13	173	KFL 3173@Kärl	\N	\N	1	1	-6131	\N	C	2019-12-20 22:13:53.799521+00	3574
6130	-3036	13	173	KFL 3172@Kärl	\N	\N	1	1	-6130	\N	C	2019-12-20 22:13:53.799521+00	3575
6129	-3037	13	173	KFL 3171@Kärl	\N	\N	1	1	-6129	\N	C	2019-12-20 22:13:53.799521+00	3576
6128	-3037	13	173	KFL 3170@Kärl	\N	\N	1	1	-6128	\N	C	2019-12-20 22:13:53.799521+00	3577
6127	-3037	13	173	KFL 3169@Kärl	\N	\N	1	1	-6127	\N	C	2019-12-20 22:13:53.799521+00	3578
6126	-3037	13	173	KFL 3168@Kärl	\N	\N	1	1	-6126	\N	C	2019-12-20 22:13:53.799521+00	3579
6125	-3037	13	173	KFL 3167@Kärl	\N	\N	1	1	-6125	\N	C	2019-12-20 22:13:53.799521+00	3580
6124	-3010	13	173	KFL 3165@Kärl	\N	\N	1	1	-6124	\N	C	2019-12-20 22:13:53.799521+00	3581
6123	-3010	13	173	KFL 3164@Kärl	\N	\N	1	1	-6123	\N	C	2019-12-20 22:13:53.799521+00	3582
6122	-3010	13	173	KFL 3163@Kärl	\N	\N	1	1	-6122	\N	C	2019-12-20 22:13:53.799521+00	3583
6121	-3114	13	173	KFL 3162@Kärl	\N	\N	1	1	-6121	\N	C	2019-12-20 22:13:53.799521+00	3584
6120	-3114	13	173	KFL 3161@Kärl	\N	\N	1	1	-6120	\N	C	2019-12-20 22:13:53.799521+00	3585
6119	-3114	13	173	KFL 3160@Kärl	\N	\N	1	1	-6119	\N	C	2019-12-20 22:13:53.799521+00	3586
6118	-3114	13	173	KFL 3159@Kärl	\N	\N	1	1	-6118	\N	C	2019-12-20 22:13:53.799521+00	3587
6117	-3037	13	173	KFL 3158@Kärl	\N	\N	1	1	-6117	\N	C	2019-12-20 22:13:53.799521+00	3588
6116	-3037	13	173	KFL 3157@Kärl	\N	\N	1	1	-6116	\N	C	2019-12-20 22:13:53.799521+00	3589
6115	-3037	13	173	KFL 3156@odef	\N	\N	1	1	-6115	\N	C	2019-12-20 22:13:53.799521+00	3590
6114	-3037	13	173	KFL 3155@odef	\N	\N	1	1	-6114	\N	C	2019-12-20 22:13:53.799521+00	3591
6113	-3037	13	173	KFL 3154@Kärl	\N	\N	1	1	-6113	\N	C	2019-12-20 22:13:53.799521+00	3592
6112	-3037	13	173	KFL 3153@Kärl	\N	\N	1	1	-6112	\N	C	2019-12-20 22:13:53.799521+00	3593
6111	-3037	13	173	KFL 3152@Degel	\N	\N	1	1	-6111	\N	C	2019-12-20 22:13:53.799521+00	3594
6110	-3037	13	173	KFL 3151@Degel	\N	\N	1	1	-6110	\N	C	2019-12-20 22:13:53.799521+00	3595
6109	-3037	13	173	KFL 3150@Degel	\N	\N	1	1	-6109	\N	C	2019-12-20 22:13:53.799521+00	3596
6108	-3037	13	173	KFL 3149@Gjutform	\N	\N	1	1	-6108	\N	C	2019-12-20 22:13:53.799521+00	3597
6107	-3037	13	173	KFL 3148@Gjutform	\N	\N	1	1	-6107	\N	C	2019-12-20 22:13:53.799521+00	3598
6106	-3025	13	173	KFL 3147@Blästermunstycke	\N	\N	1	1	-6106	\N	C	2019-12-20 22:13:53.799521+00	3599
6105	-3025	13	173	KFL 3146@Gjutform	\N	\N	1	1	-6105	\N	C	2019-12-20 22:13:53.799521+00	3600
6104	-3025	13	173	KFL 3145@Gjutform	\N	\N	1	1	-6104	\N	C	2019-12-20 22:13:53.799521+00	3601
6103	-3025	13	173	KFL 3144@Gjutform	\N	\N	1	1	-6103	\N	C	2019-12-20 22:13:53.799521+00	3602
6102	-3025	13	173	KFL 3143@Gjutform	\N	\N	1	1	-6102	\N	C	2019-12-20 22:13:53.799521+00	3603
6101	-3025	13	173	KFL 3142@Gjutform	\N	\N	1	1	-6101	\N	C	2019-12-20 22:13:53.799521+00	3604
6100	-3025	13	173	KFL 3141@Degel	\N	\N	1	1	-6100	\N	C	2019-12-20 22:13:53.799521+00	3605
6099	-3025	13	173	KFL 3140@Degel	\N	\N	1	1	-6099	\N	C	2019-12-20 22:13:53.799521+00	3606
6098	-3025	13	173	KFL 3139@Degel	\N	\N	1	1	-6098	\N	C	2019-12-20 22:13:53.799521+00	3607
6097	-3025	13	173	KFL 3138@Degel	\N	\N	1	1	-6097	\N	C	2019-12-20 22:13:53.799521+00	3608
6096	-3107	13	173	KFL 3137@Lerklining	\N	\N	1	1	-6096	\N	C	2019-12-20 22:13:53.799521+00	3609
6095	-3107	13	173	KFL 3136@Gjutform	\N	\N	1	1	-6095	\N	C	2019-12-20 22:13:53.799521+00	3610
6094	-3107	13	173	KFL 3135@Gjutform	\N	\N	1	1	-6094	\N	C	2019-12-20 22:13:53.799521+00	3611
6093	-3107	13	173	KFL 3134@Degel	\N	\N	1	1	-6093	\N	C	2019-12-20 22:13:53.799521+00	3612
6092	-3107	13	173	KFL 3133@Degel	\N	\N	1	1	-6092	\N	C	2019-12-20 22:13:53.799521+00	3613
6091	-3107	13	173	KFL 3132@Lerklining	\N	\N	1	1	-6091	\N	C	2019-12-20 22:13:53.799521+00	3614
6090	-3107	13	173	KFL 3131@Lerklining	\N	\N	1	1	-6090	\N	C	2019-12-20 22:13:53.799521+00	3615
6089	-3107	13	173	KFL 3129@Blästermunstycke	\N	\N	1	1	-6089	\N	C	2019-12-20 22:13:53.799521+00	3616
6088	-3005	13	173	KFL 3128@Kärl	\N	\N	1	1	-6088	\N	C	2019-12-20 22:13:53.799521+00	3617
6087	-3005	13	173	KFL 3127@Kärl	\N	\N	1	1	-6087	\N	C	2019-12-20 22:13:53.799521+00	3618
6086	-3005	13	173	KFL 3126@Kärl	\N	\N	1	1	-6086	\N	C	2019-12-20 22:13:53.799521+00	3619
6085	-3005	13	173	KFL 3125@Kärl	\N	\N	1	1	-6085	\N	C	2019-12-20 22:13:53.799521+00	3620
6084	-3005	13	173	KFL 3124@Kärl	\N	\N	1	1	-6084	\N	C	2019-12-20 22:13:53.799521+00	3621
6083	-3336	13	173	KFL 3123@Kärl	\N	\N	1	1	-6083	\N	C	2019-12-20 22:13:53.799521+00	3622
6082	-3336	13	173	KFL 3122@Kärl	\N	\N	1	1	-6082	\N	C	2019-12-20 22:13:53.799521+00	3623
6081	-3336	13	173	KFL 3121@Kärl	\N	\N	1	1	-6081	\N	C	2019-12-20 22:13:53.799521+00	3624
6080	-3336	13	173	KFL 3120@Kärl	\N	\N	1	1	-6080	\N	C	2019-12-20 22:13:53.799521+00	3625
6079	-3336	13	173	KFL 3119@Kärl	\N	\N	1	1	-6079	\N	C	2019-12-20 22:13:53.799521+00	3626
6078	-3336	13	173	KFL 3118@Kärl	\N	\N	1	1	-6078	\N	C	2019-12-20 22:13:53.799521+00	3627
6077	-3344	13	173	KFL 3117@Kärl	\N	\N	1	1	-6077	\N	C	2019-12-20 22:13:53.799521+00	3628
6076	-3344	13	173	KFL 3116@Kärl	\N	\N	1	1	-6076	\N	C	2019-12-20 22:13:53.799521+00	3629
6075	-3344	13	173	KFL 3115@Kärl	\N	\N	1	1	-6075	\N	C	2019-12-20 22:13:53.799521+00	3630
6074	-3344	13	173	KFL 3114@Kärl	\N	\N	1	1	-6074	\N	C	2019-12-20 22:13:53.799521+00	3631
6073	-3344	13	173	KFL 3113@Kärl	\N	\N	1	1	-6073	\N	C	2019-12-20 22:13:53.799521+00	3632
6072	-3291	13	173	KFL 3112@Kärl	\N	\N	1	1	-6072	\N	C	2019-12-20 22:13:53.799521+00	3633
6071	-3291	13	173	KFL 3111@Kärl	\N	\N	1	1	-6071	\N	C	2019-12-20 22:13:53.799521+00	3634
6070	-3291	13	173	KFL 3110@Kärl	\N	\N	1	1	-6070	\N	C	2019-12-20 22:13:53.799521+00	3635
6069	-3291	13	173	KFL 3109@Kärl	\N	\N	1	1	-6069	\N	C	2019-12-20 22:13:53.799521+00	3636
6068	-3291	13	173	KFL 3108@Kärl	\N	\N	1	1	-6068	\N	C	2019-12-20 22:13:53.799521+00	3637
6067	-3291	13	173	KFL 3107@Kärl	\N	\N	1	1	-6067	\N	C	2019-12-20 22:13:53.799521+00	3638
6066	-3291	13	173	KFL 3106@Kärl	\N	\N	1	1	-6066	\N	C	2019-12-20 22:13:53.799521+00	3639
6065	-3291	13	173	KFL 3105@Sländtrissa &amp; vävtyngd	\N	\N	1	1	-6065	\N	C	2019-12-20 22:13:53.799521+00	3640
6064	-3291	13	173	KFL 3104@Kärl	\N	\N	1	1	-6064	\N	C	2019-12-20 22:13:53.799521+00	3641
6063	-3291	13	173	KFL 3103@Kärl	\N	\N	1	1	-6063	\N	C	2019-12-20 22:13:53.799521+00	3642
6062	-3252	13	173	KFL 3102@Kärl	\N	\N	1	1	-6062	\N	C	2019-12-20 22:13:53.799521+00	3643
6061	-3252	13	173	KFL 3101@Kärl	\N	\N	1	1	-6061	\N	C	2019-12-20 22:13:53.799521+00	3644
6060	-3252	13	173	KFL 3100@Kärl	\N	\N	1	1	-6060	\N	C	2019-12-20 22:13:53.799521+00	3645
6059	-3263	13	173	KFL 3094@Kärl	\N	\N	1	1	-6059	\N	C	2019-12-20 22:13:53.799521+00	3646
6058	-3263	13	173	KFL 3093@Kärl	\N	\N	1	1	-6058	\N	C	2019-12-20 22:13:53.799521+00	3647
6057	-3263	13	173	KFL 3092@Kärl	\N	\N	1	1	-6057	\N	C	2019-12-20 22:13:53.799521+00	3648
6056	-3263	13	173	KFL 3091@Kärl	\N	\N	1	1	-6056	\N	C	2019-12-20 22:13:53.799521+00	3649
6055	-3263	13	173	KFL 3090@Kärl	\N	\N	1	1	-6055	\N	C	2019-12-20 22:13:53.799521+00	3650
6054	-3056	13	173	KFL 3087@Kärl	\N	\N	1	1	-6054	\N	C	2019-12-20 22:13:53.799521+00	3651
6053	-3056	13	173	KFL 3086@Kärl	\N	\N	1	1	-6053	\N	C	2019-12-20 22:13:53.799521+00	3652
6052	6	13	173	KFL 3084@Kärl	\N	\N	1	1	-6052	\N	C	2019-12-20 22:13:53.799521+00	3653
6051	6	13	173	KFL 3083@Kärl	\N	\N	1	1	-6051	\N	C	2019-12-20 22:13:53.799521+00	3654
6050	6	13	173	KFL 3082@Kärl	\N	\N	1	1	-6050	\N	C	2019-12-20 22:13:53.799521+00	3655
6049	6	13	173	KFL 3081@Kärl	\N	\N	1	1	-6049	\N	C	2019-12-20 22:13:53.799521+00	3656
6048	6	13	173	KFL 3080@Kärl	\N	\N	1	1	-6048	\N	C	2019-12-20 22:13:53.799521+00	3657
6047	6	13	173	KFL 3079@Kärl	\N	\N	1	1	-6047	\N	C	2019-12-20 22:13:53.799521+00	3658
6046	-3161	13	173	KFL 3078@Kärl	\N	\N	1	1	-6046	\N	C	2019-12-20 22:13:53.799521+00	3659
6045	-3161	13	173	KFL 3077@Kärl	\N	\N	1	1	-6045	\N	C	2019-12-20 22:13:53.799521+00	3660
6044	-3161	13	173	KFL 3076@Kärl	\N	\N	1	1	-6044	\N	C	2019-12-20 22:13:53.799521+00	3661
6043	-3161	13	173	KFL 3075@Kärl	\N	\N	1	1	-6043	\N	C	2019-12-20 22:13:53.799521+00	3662
6042	-3161	13	173	KFL 3074@Kärl	\N	\N	1	1	-6042	\N	C	2019-12-20 22:13:53.799521+00	3663
6041	-3161	13	173	KFL 3073@Kärl	\N	\N	1	1	-6041	\N	C	2019-12-20 22:13:53.799521+00	3664
6040	-3161	13	173	KFL 3072@Kärl	\N	\N	1	1	-6040	\N	C	2019-12-20 22:13:53.799521+00	3665
6039	-3161	13	173	KFL 3071@Kärl	\N	\N	1	1	-6039	\N	C	2019-12-20 22:13:53.799521+00	3666
6038	-3161	13	173	KFL 3070@Kärl	\N	\N	1	1	-6038	\N	C	2019-12-20 22:13:53.799521+00	3667
6037	-3161	13	173	KFL 3069@Kärl	\N	\N	1	1	-6037	\N	C	2019-12-20 22:13:53.799521+00	3668
6036	-3161	13	173	KFL 3068@Kärl	\N	\N	1	1	-6036	\N	C	2019-12-20 22:13:53.799521+00	3669
6035	-3161	13	173	KFL 3067@Kärl	\N	\N	1	1	-6035	\N	C	2019-12-20 22:13:53.799521+00	3670
6034	-3161	13	173	KFL 3066@Kärl	\N	\N	1	1	-6034	\N	C	2019-12-20 22:13:53.799521+00	3671
6033	-3161	13	173	KFL 3065@Kärl	\N	\N	1	1	-6033	\N	C	2019-12-20 22:13:53.799521+00	3672
6032	-3161	13	173	KFL 3064@Kärl	\N	\N	1	1	-6032	\N	C	2019-12-20 22:13:53.799521+00	3673
6031	-3273	13	173	KFL 3063@Figurin	\N	\N	1	1	-6031	\N	C	2019-12-20 22:13:53.799521+00	3674
6030	-3273	13	173	KFL 3062@Kärl	\N	\N	1	1	-6030	\N	C	2019-12-20 22:13:53.799521+00	3675
6029	-3273	13	173	KFL 3061@Kärl	\N	\N	1	1	-6029	\N	C	2019-12-20 22:13:53.799521+00	3676
6028	-3273	13	173	KFL 3060@Kärl	\N	\N	1	1	-6028	\N	C	2019-12-20 22:13:53.799521+00	3677
6027	-3273	13	173	KFL 3059@Kärl	\N	\N	1	1	-6027	\N	C	2019-12-20 22:13:53.799521+00	3678
6026	-3273	13	173	KFL 3058@Kärl	\N	\N	1	1	-6026	\N	C	2019-12-20 22:13:53.799521+00	3679
6025	-3273	13	173	KFL 3057@Kärl	\N	\N	1	1	-6025	\N	C	2019-12-20 22:13:53.799521+00	3680
6024	-3273	13	173	KFL 3056@Kärl	\N	\N	1	1	-6024	\N	C	2019-12-20 22:13:53.799521+00	3681
6023	-3273	13	173	KFL 3055@Kärl	\N	\N	1	1	-6023	\N	C	2019-12-20 22:13:53.799521+00	3682
6022	-3273	13	173	KFL 3054@Kärl	\N	\N	1	1	-6022	\N	C	2019-12-20 22:13:53.799521+00	3683
6021	-3273	13	173	KFL 3053@Figurin	\N	\N	1	1	-6021	\N	C	2019-12-20 22:13:53.799521+00	3684
6020	-3273	13	173	KFL 3052@Figurin	\N	\N	1	1	-6020	\N	C	2019-12-20 22:13:53.799521+00	3685
6019	-3181	13	173	KFL 3049@Kärl	\N	\N	1	1	-6019	\N	C	2019-12-20 22:13:53.799521+00	3686
6018	-3181	13	173	KFL 3047@Kärl	\N	\N	1	1	-6018	\N	C	2019-12-20 22:13:53.799521+00	3687
6017	-3181	13	173	KFL 3046@Kärl	\N	\N	1	1	-6017	\N	C	2019-12-20 22:13:53.799521+00	3688
6016	-3181	13	173	KFL 3045@Kärl	\N	\N	1	1	-6016	\N	C	2019-12-20 22:13:53.799521+00	3689
6015	-3181	13	173	KFL 3044@Kärl	\N	\N	1	1	-6015	\N	C	2019-12-20 22:13:53.799521+00	3690
6014	-3181	13	173	KFL 3043@Kärl	\N	\N	1	1	-6014	\N	C	2019-12-20 22:13:53.799521+00	3691
6013	-3181	13	173	KFL 3042@Kärl	\N	\N	1	1	-6013	\N	C	2019-12-20 22:13:53.799521+00	3692
6012	-3358	13	173	KFL 3041@Degel	\N	\N	1	1	-6012	\N	C	2019-12-20 22:13:53.799521+00	3693
6011	-3358	13	173	KFL 3040@Gjutform	\N	\N	1	1	-6011	\N	C	2019-12-20 22:13:53.799521+00	3694
6010	-3358	13	173	KFL 3039@Degel	\N	\N	1	1	-6010	\N	C	2019-12-20 22:13:53.799521+00	3695
6009	-3358	13	173	KFL 3038@Degel	\N	\N	1	1	-6009	\N	C	2019-12-20 22:13:53.799521+00	3696
6008	-3358	13	173	KFL 3037@Degel	\N	\N	1	1	-6008	\N	C	2019-12-20 22:13:53.799521+00	3697
6007	-3358	13	173	KFL 3036@Degel	\N	\N	1	1	-6007	\N	C	2019-12-20 22:13:53.799521+00	3698
6006	-3358	13	173	KFL 3035@Degel	\N	\N	1	1	-6006	\N	C	2019-12-20 22:13:53.799521+00	3699
6005	-3358	13	173	KFL 3034@Degel	\N	\N	1	1	-6005	\N	C	2019-12-20 22:13:53.799521+00	3700
6004	-3358	13	173	KFL 3033@Gjutform	\N	\N	1	1	-6004	\N	C	2019-12-20 22:13:53.799521+00	3701
6003	-3358	13	173	KFL 3032@Gjutform	\N	\N	1	1	-6003	\N	C	2019-12-20 22:13:53.799521+00	3702
6002	-3358	13	173	KFL 3031@Gjutform	\N	\N	1	1	-6002	\N	C	2019-12-20 22:13:53.799521+00	3703
6001	-3358	13	173	KFL 3030@Gjutform	\N	\N	1	1	-6001	\N	C	2019-12-20 22:13:53.799521+00	3704
6000	-3358	13	173	KFL 3029@Gjutform	\N	\N	1	1	-6000	\N	C	2019-12-20 22:13:53.799521+00	3705
5999	-3358	13	173	KFL 3028@Gjutform	\N	\N	1	1	-5999	\N	C	2019-12-20 22:13:53.799521+00	3706
5998	-3358	13	173	KFL 3017@Kärl	\N	\N	1	1	-5998	\N	C	2019-12-20 22:13:53.799521+00	3707
5997	-3358	13	173	KFL 3016@Kärl	\N	\N	1	1	-5997	\N	C	2019-12-20 22:13:53.799521+00	3708
5996	-3358	13	173	KFL 3015@Kärl	\N	\N	1	1	-5996	\N	C	2019-12-20 22:13:53.799521+00	3709
5995	-3358	13	173	KFL 3014@Kärl	\N	\N	1	1	-5995	\N	C	2019-12-20 22:13:53.799521+00	3710
5994	-3358	13	173	KFL 3013@Kärl	\N	\N	1	1	-5994	\N	C	2019-12-20 22:13:53.799521+00	3711
5993	-3358	13	173	KFL 3012@Kärl	\N	\N	1	1	-5993	\N	C	2019-12-20 22:13:53.799521+00	3712
5992	-3358	13	173	KFL 3011@Kärl	\N	\N	1	1	-5992	\N	C	2019-12-20 22:13:53.799521+00	3713
5991	-3358	13	173	KFL 3010@Kärl	\N	\N	1	1	-5991	\N	C	2019-12-20 22:13:53.799521+00	3714
5990	-3358	13	173	KFL 3009@Kärl	\N	\N	1	1	-5990	\N	C	2019-12-20 22:13:53.799521+00	3715
5989	-3358	13	173	KFL 3008@Kärl	\N	\N	1	1	-5989	\N	C	2019-12-20 22:13:53.799521+00	3716
5988	-3358	13	173	KFL 3007@Kärl	\N	\N	1	1	-5988	\N	C	2019-12-20 22:13:53.799521+00	3717
5987	-3358	13	173	KFL 3006@Kärl	\N	\N	1	1	-5987	\N	C	2019-12-20 22:13:53.799521+00	3718
5986	-3358	13	173	KFL 3005@Kärl	\N	\N	1	1	-5986	\N	C	2019-12-20 22:13:53.799521+00	3719
5985	-3358	13	173	KFL 3004@Kärl	\N	\N	1	1	-5985	\N	C	2019-12-20 22:13:53.799521+00	3720
5984	-3358	13	173	KFL 3003@Kärl	\N	\N	1	1	-5984	\N	C	2019-12-20 22:13:53.799521+00	3721
5983	-3358	13	173	KFL 3002@Kärl	\N	\N	1	1	-5983	\N	C	2019-12-20 22:13:53.799521+00	3722
5982	-3358	13	173	KFL 3001@Kärl	\N	\N	1	1	-5982	\N	C	2019-12-20 22:13:53.799521+00	3723
5981	-3358	13	173	KFL 3000@Kärl	\N	\N	1	1	-5981	\N	C	2019-12-20 22:13:53.799521+00	3724
5980	-3358	13	173	KFL 2999@Kärl	\N	\N	1	1	-5980	\N	C	2019-12-20 22:13:53.799521+00	3725
5979	-3358	13	173	KFL 2998@Kärl	\N	\N	1	1	-5979	\N	C	2019-12-20 22:13:53.799521+00	3726
5978	-3358	13	173	KFL 2997@Kärl	\N	\N	1	1	-5978	\N	C	2019-12-20 22:13:53.799521+00	3727
5977	-3358	13	173	KFL 2996@Kärl	\N	\N	1	1	-5977	\N	C	2019-12-20 22:13:53.799521+00	3728
5976	-3358	13	173	KFL 2995@Kärl	\N	\N	1	1	-5976	\N	C	2019-12-20 22:13:53.799521+00	3729
5975	-3358	13	173	KFL 2993@Kärl	\N	\N	1	1	-5975	\N	C	2019-12-20 22:13:53.799521+00	3730
5974	-3358	13	173	KFL 2991@Kärl	\N	\N	1	1	-5974	\N	C	2019-12-20 22:13:53.799521+00	3731
5973	-3358	13	173	KFL 2990@Kärl	\N	\N	1	1	-5973	\N	C	2019-12-20 22:13:53.799521+00	3732
5972	-3358	13	173	KFL 2988@Kärl	\N	\N	1	1	-5972	\N	C	2019-12-20 22:13:53.799521+00	3733
5971	-3358	13	173	KFL 2987@Kärl	\N	\N	1	1	-5971	\N	C	2019-12-20 22:13:53.799521+00	3734
5970	-3358	13	173	KFL 2986@Kärl	\N	\N	1	1	-5970	\N	C	2019-12-20 22:13:53.799521+00	3735
5969	-3358	13	173	KFL 2985@Kärl	\N	\N	1	1	-5969	\N	C	2019-12-20 22:13:53.799521+00	3736
5968	-3217	13	173	KFL 2981@Kärl	\N	\N	1	1	-5968	\N	C	2019-12-20 22:13:53.799521+00	3737
5967	-3217	13	173	KFL 2980@Kärl	\N	\N	1	1	-5967	\N	C	2019-12-20 22:13:53.799521+00	3738
5966	-3217	13	173	KFL 2979@Kärl	\N	\N	1	1	-5966	\N	C	2019-12-20 22:13:53.799521+00	3739
5965	-3217	13	173	KFL 2978@Kärl	\N	\N	1	1	-5965	\N	C	2019-12-20 22:13:53.799521+00	3740
5964	-3146	13	173	KFL 2958@Kärl	\N	\N	1	1	-5964	\N	C	2019-12-20 22:13:53.799521+00	3741
5963	-3146	13	173	KFL 2957@Kärl	\N	\N	1	1	-5963	\N	C	2019-12-20 22:13:53.799521+00	3742
5962	-3146	13	173	KFL 2956@Kärl	\N	\N	1	1	-5962	\N	C	2019-12-20 22:13:53.799521+00	3743
5961	-3146	13	173	KFL 2955@Kärl	\N	\N	1	1	-5961	\N	C	2019-12-20 22:13:53.799521+00	3744
5960	-3146	13	173	KFL 2954@Kärl	\N	\N	1	1	-5960	\N	C	2019-12-20 22:13:53.799521+00	3745
5959	-3146	13	173	KFL 2953@Kärl	\N	\N	1	1	-5959	\N	C	2019-12-20 22:13:53.799521+00	3746
5958	-3146	13	173	KFL 2952@Kärl	\N	\N	1	1	-5958	\N	C	2019-12-20 22:13:53.799521+00	3747
5957	-3146	13	173	KFL 2951@Kärl	\N	\N	1	1	-5957	\N	C	2019-12-20 22:13:53.799521+00	3748
5956	-3146	13	173	KFL 2950@Kärl	\N	\N	1	1	-5956	\N	C	2019-12-20 22:13:53.799521+00	3749
5955	-3146	13	173	KFL 2949@Kärl	\N	\N	1	1	-5955	\N	C	2019-12-20 22:13:53.799521+00	3750
5954	-3146	13	173	KFL 2948@Kärl	\N	\N	1	1	-5954	\N	C	2019-12-20 22:13:53.799521+00	3751
5953	-3146	13	173	KFL 2947@Kärl	\N	\N	1	1	-5953	\N	C	2019-12-20 22:13:53.799521+00	3752
5952	-3146	13	173	KFL 2946@Kärl	\N	\N	1	1	-5952	\N	C	2019-12-20 22:13:53.799521+00	3753
5951	-3146	13	173	KFL 2945@Kärl	\N	\N	1	1	-5951	\N	C	2019-12-20 22:13:53.799521+00	3754
5950	-3146	13	173	KFL 2944@Kärl	\N	\N	1	1	-5950	\N	C	2019-12-20 22:13:53.799521+00	3755
5949	-3322	13	173	KFL 2943@Kärl	\N	\N	1	1	-5949	\N	C	2019-12-20 22:13:53.799521+00	3756
5948	-3322	13	173	KFL 2942@Kärl	\N	\N	1	1	-5948	\N	C	2019-12-20 22:13:53.799521+00	3757
5947	-3322	13	173	KFL 2941@Kärl	\N	\N	1	1	-5947	\N	C	2019-12-20 22:13:53.799521+00	3758
5946	-3322	13	173	KFL 2940@Kärl	\N	\N	1	1	-5946	\N	C	2019-12-20 22:13:53.799521+00	3759
5945	-3322	13	173	KFL 2939@Kärl	\N	\N	1	1	-5945	\N	C	2019-12-20 22:13:53.799521+00	3760
5944	-3347	13	173	KFL 2937@Kärl	\N	\N	1	1	-5944	\N	C	2019-12-20 22:13:53.799521+00	3761
5943	-3347	13	173	KFL 2936@Kärl	\N	\N	1	1	-5943	\N	C	2019-12-20 22:13:53.799521+00	3762
5942	-3347	13	173	KFL 2935@Kärl	\N	\N	1	1	-5942	\N	C	2019-12-20 22:13:53.799521+00	3763
5941	-3347	13	173	KFL 2934@Kärl	\N	\N	1	1	-5941	\N	C	2019-12-20 22:13:53.799521+00	3764
5940	-3158	13	173	KFL 2933@Kärl	\N	\N	1	1	-5940	\N	C	2019-12-20 22:13:53.799521+00	3765
5939	-3158	13	173	KFL 2932@Kärl	\N	\N	1	1	-5939	\N	C	2019-12-20 22:13:53.799521+00	3766
5938	-3158	13	173	KFL 2931@Kärl	\N	\N	1	1	-5938	\N	C	2019-12-20 22:13:53.799521+00	3767
5937	-3158	13	173	KFL 2930@Kärl	\N	\N	1	1	-5937	\N	C	2019-12-20 22:13:53.799521+00	3768
5936	-3159	13	173	KFL 2929@Kärl	\N	\N	1	1	-5936	\N	C	2019-12-20 22:13:53.799521+00	3769
5935	-3159	13	173	KFL 2928@Kärl	\N	\N	1	1	-5935	\N	C	2019-12-20 22:13:53.799521+00	3770
5934	-3156	13	173	KFL 2927@Kärl	\N	\N	1	1	-5934	\N	C	2019-12-20 22:13:53.799521+00	3771
5933	-3156	13	173	KFL 2926@Kärl	\N	\N	1	1	-5933	\N	C	2019-12-20 22:13:53.799521+00	3772
5932	-3156	13	173	KFL 2925@Kärl	\N	\N	1	1	-5932	\N	C	2019-12-20 22:13:53.799521+00	3773
5931	-3156	13	173	KFL 2924@Kärl	\N	\N	1	1	-5931	\N	C	2019-12-20 22:13:53.799521+00	3774
5930	-3158	13	173	KFL 2923@Kärl	\N	\N	1	1	-5930	\N	C	2019-12-20 22:13:53.799521+00	3775
5929	-3158	13	173	KFL 2922@Kärl	\N	\N	1	1	-5929	\N	C	2019-12-20 22:13:53.799521+00	3776
5928	-3061	13	173	KFL 2921@Kärl	\N	\N	1	1	-5928	\N	C	2019-12-20 22:13:53.799521+00	3777
5927	-3243	13	173	KFL 2908@Kärl	\N	\N	1	1	-5927	\N	C	2019-12-20 22:13:53.799521+00	3778
5926	-3243	13	173	KFL 2907@Kärl	\N	\N	1	1	-5926	\N	C	2019-12-20 22:13:53.799521+00	3779
5925	-3243	13	173	KFL 2906@Kärl	\N	\N	1	1	-5925	\N	C	2019-12-20 22:13:53.799521+00	3780
5924	-3339	13	173	KFL 2905@Kärl	\N	\N	1	1	-5924	\N	C	2019-12-20 22:13:53.799521+00	3781
5923	-3339	13	173	KFL 2904@Kärl	\N	\N	1	1	-5923	\N	C	2019-12-20 22:13:53.799521+00	3782
5922	-3339	13	173	KFL 2903@Kärl	\N	\N	1	1	-5922	\N	C	2019-12-20 22:13:53.799521+00	3783
5921	-3339	13	173	KFL 2902@Kärl	\N	\N	1	1	-5921	\N	C	2019-12-20 22:13:53.799521+00	3784
5920	-3339	13	173	KFL 2901@Kärl	\N	\N	1	1	-5920	\N	C	2019-12-20 22:13:53.799521+00	3785
5919	-3032	13	173	KFL 2892@Kärl	\N	\N	1	1	-5919	\N	C	2019-12-20 22:13:53.799521+00	3786
5918	-3202	13	173	KFL 2882@Kärl	\N	\N	1	1	-5918	\N	C	2019-12-20 22:13:53.799521+00	3787
5917	-3202	13	173	KFL 2881@Kärl	\N	\N	1	1	-5917	\N	C	2019-12-20 22:13:53.799521+00	3788
5916	-3202	13	173	KFL 2880@Kärl	\N	\N	1	1	-5916	\N	C	2019-12-20 22:13:53.799521+00	3789
5915	-3287	13	173	KFL 2846@Kärl	\N	\N	1	1	-5915	\N	C	2019-12-20 22:13:53.799521+00	3790
5914	-3287	13	173	KFL 2845@Kärl	\N	\N	1	1	-5914	\N	C	2019-12-20 22:13:53.799521+00	3791
5913	-3287	13	173	KFL 2844@Kärl	\N	\N	1	1	-5913	\N	C	2019-12-20 22:13:53.799521+00	3792
5912	-3287	13	173	KFL 2843@Kärl	\N	\N	1	1	-5912	\N	C	2019-12-20 22:13:53.799521+00	3793
5911	-3287	13	173	KFL 2842@Kärl	\N	\N	1	1	-5911	\N	C	2019-12-20 22:13:53.799521+00	3794
5910	-3287	13	173	KFL 2841@Kärl	\N	\N	1	1	-5910	\N	C	2019-12-20 22:13:53.799521+00	3795
5909	-3287	13	173	KFL 2840@Kärl	\N	\N	1	1	-5909	\N	C	2019-12-20 22:13:53.799521+00	3796
5908	-3287	13	173	KFL 2839@Kärl	\N	\N	1	1	-5908	\N	C	2019-12-20 22:13:53.799521+00	3797
5907	-3287	13	173	KFL 2838@Kärl	\N	\N	1	1	-5907	\N	C	2019-12-20 22:13:53.799521+00	3798
5906	-3287	13	173	KFL 2837@Kärl	\N	\N	1	1	-5906	\N	C	2019-12-20 22:13:53.799521+00	3799
5905	-3287	13	173	KFL 2836@Kärl	\N	\N	1	1	-5905	\N	C	2019-12-20 22:13:53.799521+00	3800
5904	-3287	13	173	KFL 2835@Kärl	\N	\N	1	1	-5904	\N	C	2019-12-20 22:13:53.799521+00	3801
5903	-3287	13	173	KFL 2834@Kärl	\N	\N	1	1	-5903	\N	C	2019-12-20 22:13:53.799521+00	3802
5902	-3287	13	173	KFL 2833@Kärl	\N	\N	1	1	-5902	\N	C	2019-12-20 22:13:53.799521+00	3803
5901	-3287	13	173	KFL 2832@Kärl	\N	\N	1	1	-5901	\N	C	2019-12-20 22:13:53.799521+00	3804
5900	-3287	13	173	KFL 2831@Kärl	\N	\N	1	1	-5900	\N	C	2019-12-20 22:13:53.799521+00	3805
5899	-3287	13	173	KFL 2830@Kärl	\N	\N	1	1	-5899	\N	C	2019-12-20 22:13:53.799521+00	3806
5898	-3287	13	173	KFL 2829@Kärl	\N	\N	1	1	-5898	\N	C	2019-12-20 22:13:53.799521+00	3807
5897	-3287	13	173	KFL 2828@Kärl	\N	\N	1	1	-5897	\N	C	2019-12-20 22:13:53.799521+00	3808
5896	-3287	13	173	KFL 2827@Kärl	\N	\N	1	1	-5896	\N	C	2019-12-20 22:13:53.799521+00	3809
5895	-3287	13	173	KFL 2826@Kärl	\N	\N	1	1	-5895	\N	C	2019-12-20 22:13:53.799521+00	3810
5894	-3174	13	173	KFL 2763@Kärl	\N	\N	1	1	-5894	\N	C	2019-12-20 22:13:53.799521+00	3811
5893	-3174	13	173	KFL 2762@Kärl	\N	\N	1	1	-5893	\N	C	2019-12-20 22:13:53.799521+00	3812
5892	-3174	13	173	KFL 2761@Kärl	\N	\N	1	1	-5892	\N	C	2019-12-20 22:13:53.799521+00	3813
5891	-3174	13	173	KFL 2760@Kärl	\N	\N	1	1	-5891	\N	C	2019-12-20 22:13:53.799521+00	3814
5890	-3174	13	173	KFL 2759@Kärl	\N	\N	1	1	-5890	\N	C	2019-12-20 22:13:53.799521+00	3815
5889	-3302	13	173	KFL 2758@Kärl	\N	\N	1	1	-5889	\N	C	2019-12-20 22:13:53.799521+00	3816
5888	-3302	13	173	KFL 2757@Kärl	\N	\N	1	1	-5888	\N	C	2019-12-20 22:13:53.799521+00	3817
5887	-3139	13	173	KFL 2756@Kärl	\N	\N	1	1	-5887	\N	C	2019-12-20 22:13:53.799521+00	3818
5886	-3300	13	173	KFL 2755@Kärl	\N	\N	1	1	-5886	\N	C	2019-12-20 22:13:53.799521+00	3819
5885	-3300	13	173	KFL 2754@Kärl	\N	\N	1	1	-5885	\N	C	2019-12-20 22:13:53.799521+00	3820
5884	-3162	13	173	KFL 2753@Kärl	\N	\N	1	1	-5884	\N	C	2019-12-20 22:13:53.799521+00	3821
5883	-3162	13	173	KFL 2752@Kärl	\N	\N	1	1	-5883	\N	C	2019-12-20 22:13:53.799521+00	3822
5882	-3162	13	173	KFL 2751@Kärl	\N	\N	1	1	-5882	\N	C	2019-12-20 22:13:53.799521+00	3823
5881	-3162	13	173	KFL 2750@Kärl	\N	\N	1	1	-5881	\N	C	2019-12-20 22:13:53.799521+00	3824
5880	-3162	13	173	KFL 2749@Kärl	\N	\N	1	1	-5880	\N	C	2019-12-20 22:13:53.799521+00	3825
5879	-3162	13	173	KFL 2748@Kärl	\N	\N	1	1	-5879	\N	C	2019-12-20 22:13:53.799521+00	3826
5878	-3162	13	173	KFL 2747@Kärl	\N	\N	1	1	-5878	\N	C	2019-12-20 22:13:53.799521+00	3827
5877	-3162	13	173	KFL 2746@Kärl	\N	\N	1	1	-5877	\N	C	2019-12-20 22:13:53.799521+00	3828
5876	-3162	13	173	KFL 2745@Kärl	\N	\N	1	1	-5876	\N	C	2019-12-20 22:13:53.799521+00	3829
5875	-3162	13	173	KFL 2744@Kärl	\N	\N	1	1	-5875	\N	C	2019-12-20 22:13:53.799521+00	3830
5874	-3162	13	173	KFL 2743@Kärl	\N	\N	1	1	-5874	\N	C	2019-12-20 22:13:53.799521+00	3831
5873	-3162	13	173	KFL 2742@Kärl	\N	\N	1	1	-5873	\N	C	2019-12-20 22:13:53.799521+00	3832
5872	-3162	13	173	KFL 2741@Kärl	\N	\N	1	1	-5872	\N	C	2019-12-20 22:13:53.799521+00	3833
5871	-3162	13	173	KFL 2740@Kärl	\N	\N	1	1	-5871	\N	C	2019-12-20 22:13:53.799521+00	3834
5870	-3162	13	173	KFL 2739@Kärl	\N	\N	1	1	-5870	\N	C	2019-12-20 22:13:53.799521+00	3835
5869	-3162	13	173	KFL 2738@Kärl	\N	\N	1	1	-5869	\N	C	2019-12-20 22:13:53.799521+00	3836
5868	-3162	13	173	KFL 2737@Kärl	\N	\N	1	1	-5868	\N	C	2019-12-20 22:13:53.799521+00	3837
5867	-3162	13	173	KFL 2736@Kärl	\N	\N	1	1	-5867	\N	C	2019-12-20 22:13:53.799521+00	3838
5866	-3162	13	173	KFL 2735@Kärl	\N	\N	1	1	-5866	\N	C	2019-12-20 22:13:53.799521+00	3839
5865	-3162	13	173	KFL 2734@Kärl	\N	\N	1	1	-5865	\N	C	2019-12-20 22:13:53.799521+00	3840
5864	-3162	13	173	KFL 2733@Kärl	\N	\N	1	1	-5864	\N	C	2019-12-20 22:13:53.799521+00	3841
5863	-3162	13	173	KFL 2732@Kärl	\N	\N	1	1	-5863	\N	C	2019-12-20 22:13:53.799521+00	3842
5862	-3162	13	173	KFL 2731@Kärl	\N	\N	1	1	-5862	\N	C	2019-12-20 22:13:53.799521+00	3843
5861	-3162	13	173	KFL 2730@Kärl	\N	\N	1	1	-5861	\N	C	2019-12-20 22:13:53.799521+00	3844
5860	-3162	13	173	KFL 2729@Kärl	\N	\N	1	1	-5860	\N	C	2019-12-20 22:13:53.799521+00	3845
5859	-3162	13	173	KFL 2728@Kärl	\N	\N	1	1	-5859	\N	C	2019-12-20 22:13:53.799521+00	3846
5858	-3162	13	173	KFL 2727@Kärl	\N	\N	1	1	-5858	\N	C	2019-12-20 22:13:53.799521+00	3847
5857	-3162	13	173	KFL 2726@Kärl	\N	\N	1	1	-5857	\N	C	2019-12-20 22:13:53.799521+00	3848
5856	-3162	13	173	KFL 2725@Kärl	\N	\N	1	1	-5856	\N	C	2019-12-20 22:13:53.799521+00	3849
5855	-3162	13	173	KFL 2724@Kärl	\N	\N	1	1	-5855	\N	C	2019-12-20 22:13:53.799521+00	3850
5854	-3162	13	173	KFL 2723@Kärl	\N	\N	1	1	-5854	\N	C	2019-12-20 22:13:53.799521+00	3851
5853	-3162	13	173	KFL 2722@Kärl	\N	\N	1	1	-5853	\N	C	2019-12-20 22:13:53.799521+00	3852
5852	-3162	13	173	KFL 2721@Kärl	\N	\N	1	1	-5852	\N	C	2019-12-20 22:13:53.799521+00	3853
5851	-3162	13	173	KFL 2720@Kärl	\N	\N	1	1	-5851	\N	C	2019-12-20 22:13:53.799521+00	3854
5850	-3162	13	173	KFL 2719@Kärl	\N	\N	1	1	-5850	\N	C	2019-12-20 22:13:53.799521+00	3855
5849	-3162	13	173	KFL 2718@Kärl	\N	\N	1	1	-5849	\N	C	2019-12-20 22:13:53.799521+00	3856
5848	-3162	13	173	KFL 2717@Kärl	\N	\N	1	1	-5848	\N	C	2019-12-20 22:13:53.799521+00	3857
5847	-3162	13	173	KFL 2716@Kärl	\N	\N	1	1	-5847	\N	C	2019-12-20 22:13:53.799521+00	3858
5846	-3162	13	173	KFL 2715@Kärl	\N	\N	1	1	-5846	\N	C	2019-12-20 22:13:53.799521+00	3859
5845	-3162	13	173	KFL 2714@Kärl	\N	\N	1	1	-5845	\N	C	2019-12-20 22:13:53.799521+00	3860
5844	-3340	13	173	KFL 2652@Lerklining	\N	\N	1	1	-5844	\N	C	2019-12-20 22:13:53.799521+00	3861
5843	-3340	13	173	KFL 2650@Lerklining	\N	\N	1	1	-5843	\N	C	2019-12-20 22:13:53.799521+00	3862
5842	-3340	13	173	KFL 2648@Lerklining	\N	\N	1	1	-5842	\N	C	2019-12-20 22:13:53.799521+00	3863
5841	-3340	13	173	KFL 2647@rålera	\N	\N	1	1	-5841	\N	C	2019-12-20 22:13:53.799521+00	3864
5840	-3340	13	173	KFL 2646@Lerklining	\N	\N	1	1	-5840	\N	C	2019-12-20 22:13:53.799521+00	3865
5839	-2982	13	173	KFL 2528@Kärl	\N	\N	1	1	-5839	\N	C	2019-12-20 22:13:53.799521+00	3866
5838	-3372	13	173	KFL 2524@Kärl	\N	\N	1	1	-5838	\N	C	2019-12-20 22:13:53.799521+00	3867
5837	-3372	13	173	KFL 2523@Kärl	\N	\N	1	1	-5837	\N	C	2019-12-20 22:13:53.799521+00	3868
5836	-3372	13	173	KFL 2522@Kärl	\N	\N	1	1	-5836	\N	C	2019-12-20 22:13:53.799521+00	3869
5835	-3372	13	173	KFL 2521@Kärl	\N	\N	1	1	-5835	\N	C	2019-12-20 22:13:53.799521+00	3870
5834	-3372	13	173	KFL 2520@Kärl	\N	\N	1	1	-5834	\N	C	2019-12-20 22:13:53.799521+00	3871
5833	-3372	13	173	KFL 2519@Kärl	\N	\N	1	1	-5833	\N	C	2019-12-20 22:13:53.799521+00	3872
5832	-3372	13	173	KFL 2518@Kärl	\N	\N	1	1	-5832	\N	C	2019-12-20 22:13:53.799521+00	3873
5831	-3372	13	173	KFL 2517@Kärl	\N	\N	1	1	-5831	\N	C	2019-12-20 22:13:53.799521+00	3874
5830	-3372	13	173	KFL 2516@Kärl	\N	\N	1	1	-5830	\N	C	2019-12-20 22:13:53.799521+00	3875
5829	-3142	13	173	KFL 2515@Kärl	\N	\N	1	1	-5829	\N	C	2019-12-20 22:13:53.799521+00	3876
5828	-3068	13	173	KFL 2514@Kärl	\N	\N	1	1	-5828	\N	C	2019-12-20 22:13:53.799521+00	3877
5827	-3068	13	173	KFL 2513@Kärl	\N	\N	1	1	-5827	\N	C	2019-12-20 22:13:53.799521+00	3878
5826	-3068	13	173	KFL 2512@Kärl	\N	\N	1	1	-5826	\N	C	2019-12-20 22:13:53.799521+00	3879
5825	-3068	13	173	KFL 2511@Kärl	\N	\N	1	1	-5825	\N	C	2019-12-20 22:13:53.799521+00	3880
5824	-3203	13	173	KFL 2510@Kärl	\N	\N	1	1	-5824	\N	C	2019-12-20 22:13:53.799521+00	3881
5823	-3069	13	173	KFL 2509@Jordprov	\N	\N	1	1	-5823	\N	C	2019-12-20 22:13:53.799521+00	3882
5822	-3069	13	173	KFL 2508@Kärl	\N	\N	1	1	-5822	\N	C	2019-12-20 22:13:53.799521+00	3883
5821	-3069	13	173	KFL 2507@Kärl	\N	\N	1	1	-5821	\N	C	2019-12-20 22:13:53.799521+00	3884
5820	-3069	13	173	KFL 2506@Kärl	\N	\N	1	1	-5820	\N	C	2019-12-20 22:13:53.799521+00	3885
5819	-3069	13	173	KFL 2505@Kärl	\N	\N	1	1	-5819	\N	C	2019-12-20 22:13:53.799521+00	3886
5818	-3069	13	173	KFL 2504@Kärl	\N	\N	1	1	-5818	\N	C	2019-12-20 22:13:53.799521+00	3887
5817	-3069	13	173	KFL 2503@Kärl	\N	\N	1	1	-5817	\N	C	2019-12-20 22:13:53.799521+00	3888
5816	-3069	13	173	KFL 2502@Kärl	\N	\N	1	1	-5816	\N	C	2019-12-20 22:13:53.799521+00	3889
5815	-3069	13	173	KFL 2501@Kärl	\N	\N	1	1	-5815	\N	C	2019-12-20 22:13:53.799521+00	3890
5814	-3069	13	173	KFL 2500@Kärl	\N	\N	1	1	-5814	\N	C	2019-12-20 22:13:53.799521+00	3891
5813	-3069	13	173	KFL 2499@Kärl	\N	\N	1	1	-5813	\N	C	2019-12-20 22:13:53.799521+00	3892
5812	-3069	13	173	KFL 2498@Kärl	\N	\N	1	1	-5812	\N	C	2019-12-20 22:13:53.799521+00	3893
5811	-3069	13	173	KFL 2497@Kärl	\N	\N	1	1	-5811	\N	C	2019-12-20 22:13:53.799521+00	3894
5810	-3069	13	173	KFL 2496@Kärl	\N	\N	1	1	-5810	\N	C	2019-12-20 22:13:53.799521+00	3895
5809	-3069	13	173	KFL 2495@Kärl	\N	\N	1	1	-5809	\N	C	2019-12-20 22:13:53.799521+00	3896
5808	-3069	13	173	KFL 2494@Kärl	\N	\N	1	1	-5808	\N	C	2019-12-20 22:13:53.799521+00	3897
5807	-3069	13	173	KFL 2493@Kärl	\N	\N	1	1	-5807	\N	C	2019-12-20 22:13:53.799521+00	3898
5806	-3262	13	173	KFL 2488@Kärl	\N	\N	1	1	-5806	\N	C	2019-12-20 22:13:53.799521+00	3899
5805	-3262	13	173	KFL 2487@Kärl	\N	\N	1	1	-5805	\N	C	2019-12-20 22:13:53.799521+00	3900
5804	-3262	13	173	KFL 2486@Kärl	\N	\N	1	1	-5804	\N	C	2019-12-20 22:13:53.799521+00	3901
5803	-3262	13	173	KFL 2485@Kärl	\N	\N	1	1	-5803	\N	C	2019-12-20 22:13:53.799521+00	3902
5802	-3262	13	173	KFL 2484@Kärl	\N	\N	1	1	-5802	\N	C	2019-12-20 22:13:53.799521+00	3903
5801	-3262	13	173	KFL 2483@Kärl	\N	\N	1	1	-5801	\N	C	2019-12-20 22:13:53.799521+00	3904
5800	-3262	13	173	KFL 2482@Kärl	\N	\N	1	1	-5800	\N	C	2019-12-20 22:13:53.799521+00	3905
5799	-3262	13	173	KFL 2481@Kärl	\N	\N	1	1	-5799	\N	C	2019-12-20 22:13:53.799521+00	3906
5798	-3262	13	173	KFL 2480@Kärl	\N	\N	1	1	-5798	\N	C	2019-12-20 22:13:53.799521+00	3907
5797	-3262	13	173	KFL 2479@Kärl	\N	\N	1	1	-5797	\N	C	2019-12-20 22:13:53.799521+00	3908
5796	-3262	13	173	KFL 2478@Kärl	\N	\N	1	1	-5796	\N	C	2019-12-20 22:13:53.799521+00	3909
5795	-3262	13	173	KFL 2477@Kärl	\N	\N	1	1	-5795	\N	C	2019-12-20 22:13:53.799521+00	3910
5794	-3262	13	173	KFL 2476@Kärl	\N	\N	1	1	-5794	\N	C	2019-12-20 22:13:53.799521+00	3911
5793	-3262	13	173	KFL 2475@Kärl	\N	\N	1	1	-5793	\N	C	2019-12-20 22:13:53.799521+00	3912
5792	-3262	13	173	KFL 2474@Kärl	\N	\N	1	1	-5792	\N	C	2019-12-20 22:13:53.799521+00	3913
5791	-3262	13	173	KFL 2473@Kärl	\N	\N	1	1	-5791	\N	C	2019-12-20 22:13:53.799521+00	3914
5790	-3262	13	173	KFL 2472@Kärl	\N	\N	1	1	-5790	\N	C	2019-12-20 22:13:53.799521+00	3915
5789	-3262	13	173	KFL 2471@Kärl	\N	\N	1	1	-5789	\N	C	2019-12-20 22:13:53.799521+00	3916
5788	-3262	13	173	KFL 2470@Kärl	\N	\N	1	1	-5788	\N	C	2019-12-20 22:13:53.799521+00	3917
5787	-3262	13	173	KFL 2469@Kärl	\N	\N	1	1	-5787	\N	C	2019-12-20 22:13:53.799521+00	3918
5786	-3262	13	173	KFL 2468@Kärl	\N	\N	1	1	-5786	\N	C	2019-12-20 22:13:53.799521+00	3919
5785	-3262	13	173	KFL 2467@Kärl	\N	\N	1	1	-5785	\N	C	2019-12-20 22:13:53.799521+00	3920
5784	-3262	13	173	KFL 2466@Kärl	\N	\N	1	1	-5784	\N	C	2019-12-20 22:13:53.799521+00	3921
5783	-3262	13	173	KFL 2465@Kärl	\N	\N	1	1	-5783	\N	C	2019-12-20 22:13:53.799521+00	3922
5782	-3262	13	173	KFL 2464@Kärl	\N	\N	1	1	-5782	\N	C	2019-12-20 22:13:53.799521+00	3923
5781	-3262	13	173	KFL 2463@Kärl	\N	\N	1	1	-5781	\N	C	2019-12-20 22:13:53.799521+00	3924
5780	-3333	13	173	KFL 2462@Kärl	\N	\N	1	1	-5780	\N	C	2019-12-20 22:13:53.799521+00	3925
5779	-3343	13	173	KFL 2461@Kärl	\N	\N	1	1	-5779	\N	C	2019-12-20 22:13:53.799521+00	3926
5778	-3343	13	173	KFL 2460@Kärl	\N	\N	1	1	-5778	\N	C	2019-12-20 22:13:53.799521+00	3927
5777	-3343	13	173	KFL 2459@Kärl	\N	\N	1	1	-5777	\N	C	2019-12-20 22:13:53.799521+00	3928
5776	-3269	13	173	KFL 2446@Kärl	\N	\N	1	1	-5776	\N	C	2019-12-20 22:13:53.799521+00	3929
5775	-3269	13	173	KFL 2445@Kärl	\N	\N	1	1	-5775	\N	C	2019-12-20 22:13:53.799521+00	3930
5774	-3323	13	173	KFL 2444@Kärl	\N	\N	1	1	-5774	\N	C	2019-12-20 22:13:53.799521+00	3931
5773	-3323	13	173	KFL 2443@Kärl	\N	\N	1	1	-5773	\N	C	2019-12-20 22:13:53.799521+00	3932
5772	-3303	13	173	KFL 2436@Kärl	\N	\N	1	1	-5772	\N	C	2019-12-20 22:13:53.799521+00	3933
5771	-3303	13	173	KFL 2435@Kärl	\N	\N	1	1	-5771	\N	C	2019-12-20 22:13:53.799521+00	3934
5770	-3303	13	173	KFL 2434@Kärl	\N	\N	1	1	-5770	\N	C	2019-12-20 22:13:53.799521+00	3935
5769	-3303	13	173	KFL 2433@Kärl	\N	\N	1	1	-5769	\N	C	2019-12-20 22:13:53.799521+00	3936
5768	-3303	13	173	KFL 2432@Kärl	\N	\N	1	1	-5768	\N	C	2019-12-20 22:13:53.799521+00	3937
5767	-3303	13	173	KFL 2431@Kärl	\N	\N	1	1	-5767	\N	C	2019-12-20 22:13:53.799521+00	3938
5766	-3303	13	173	KFL 2430@Kärl	\N	\N	1	1	-5766	\N	C	2019-12-20 22:13:53.799521+00	3939
5765	-3253	13	173	KFL 2399@Kärl	\N	\N	1	1	-5765	\N	C	2019-12-20 22:13:53.799521+00	3940
5764	-3375	13	173	KFL 2387@Kärl	\N	\N	1	1	-5764	\N	C	2019-12-20 22:13:53.799521+00	3941
5763	-3375	13	173	KFL 2386@Kärl	\N	\N	1	1	-5763	\N	C	2019-12-20 22:13:53.799521+00	3942
5762	-3375	13	173	KFL 2385@Kärl	\N	\N	1	1	-5762	\N	C	2019-12-20 22:13:53.799521+00	3943
5761	-3375	13	173	KFL 2384@Kärl	\N	\N	1	1	-5761	\N	C	2019-12-20 22:13:53.799521+00	3944
5760	-3375	13	173	KFL 2383@Kärl	\N	\N	1	1	-5760	\N	C	2019-12-20 22:13:53.799521+00	3945
5759	-3375	13	173	KFL 2382@Kärl	\N	\N	1	1	-5759	\N	C	2019-12-20 22:13:53.799521+00	3946
5758	-3375	13	173	KFL 2381@Kärl	\N	\N	1	1	-5758	\N	C	2019-12-20 22:13:53.799521+00	3947
5757	-3375	13	173	KFL 2380@Kärl	\N	\N	1	1	-5757	\N	C	2019-12-20 22:13:53.799521+00	3948
5756	-3375	13	173	KFL 2379@Kärl	\N	\N	1	1	-5756	\N	C	2019-12-20 22:13:53.799521+00	3949
5755	-3375	13	173	KFL 2378@Kärl	\N	\N	1	1	-5755	\N	C	2019-12-20 22:13:53.799521+00	3950
5754	-3375	13	173	KFL 2377@Kärl	\N	\N	1	1	-5754	\N	C	2019-12-20 22:13:53.799521+00	3951
5753	-3375	13	173	KFL 2376@Kärl	\N	\N	1	1	-5753	\N	C	2019-12-20 22:13:53.799521+00	3952
5752	-3375	13	173	KFL 2375@Kärl	\N	\N	1	1	-5752	\N	C	2019-12-20 22:13:53.799521+00	3953
5751	-3375	13	173	KFL 2374@Kärl	\N	\N	1	1	-5751	\N	C	2019-12-20 22:13:53.799521+00	3954
5750	-3375	13	173	KFL 2373@Kärl	\N	\N	1	1	-5750	\N	C	2019-12-20 22:13:53.799521+00	3955
5749	-3375	13	173	KFL 2372@Kärl	\N	\N	1	1	-5749	\N	C	2019-12-20 22:13:53.799521+00	3956
5748	-3375	13	173	KFL 2370@Kärl	\N	\N	1	1	-5748	\N	C	2019-12-20 22:13:53.799521+00	3957
5747	-3375	13	173	KFL 2369@Kärl	\N	\N	1	1	-5747	\N	C	2019-12-20 22:13:53.799521+00	3958
5746	-3375	13	173	KFL 2368@Kärl	\N	\N	1	1	-5746	\N	C	2019-12-20 22:13:53.799521+00	3959
5745	-3349	13	173	KFL 2309@Kärl	\N	\N	1	1	-5745	\N	C	2019-12-20 22:13:53.799521+00	3960
5744	-3349	13	173	KFL 2308@Kärl	\N	\N	1	1	-5744	\N	C	2019-12-20 22:13:53.799521+00	3961
5743	-3349	13	173	KFL 2307@Kärl	\N	\N	1	1	-5743	\N	C	2019-12-20 22:13:53.799521+00	3962
5742	-3349	13	173	KFL 2306@Kärl	\N	\N	1	1	-5742	\N	C	2019-12-20 22:13:53.799521+00	3963
5741	-3349	13	173	KFL 2305@Kärl	\N	\N	1	1	-5741	\N	C	2019-12-20 22:13:53.799521+00	3964
5740	-3349	13	173	KFL 2304@Kärl	\N	\N	1	1	-5740	\N	C	2019-12-20 22:13:53.799521+00	3965
5739	-3349	13	173	KFL 2298@Kärl	\N	\N	1	1	-5739	\N	C	2019-12-20 22:13:53.799521+00	3966
5738	-3349	13	173	KFL 2297@Kärl	\N	\N	1	1	-5738	\N	C	2019-12-20 22:13:53.799521+00	3967
5737	-3349	13	173	KFL 2296@Kärl	\N	\N	1	1	-5737	\N	C	2019-12-20 22:13:53.799521+00	3968
5736	-3349	13	173	KFL 2295@Kärl	\N	\N	1	1	-5736	\N	C	2019-12-20 22:13:53.799521+00	3969
5735	-3349	13	173	KFL 2294@Kärl	\N	\N	1	1	-5735	\N	C	2019-12-20 22:13:53.799521+00	3970
5734	-3349	13	173	KFL 2293@Kärl	\N	\N	1	1	-5734	\N	C	2019-12-20 22:13:53.799521+00	3971
5733	-3349	13	173	KFL 2292@Kärl	\N	\N	1	1	-5733	\N	C	2019-12-20 22:13:53.799521+00	3972
5732	-3349	13	173	KFL 2291@Kärl	\N	\N	1	1	-5732	\N	C	2019-12-20 22:13:53.799521+00	3973
5731	-3349	13	173	KFL 2290@Kärl	\N	\N	1	1	-5731	\N	C	2019-12-20 22:13:53.799521+00	3974
5730	-3349	13	173	KFL 2289@Kärl	\N	\N	1	1	-5730	\N	C	2019-12-20 22:13:53.799521+00	3975
5729	-3349	13	173	KFL 2288@Kärl	\N	\N	1	1	-5729	\N	C	2019-12-20 22:13:53.799521+00	3976
5728	-3349	13	173	KFL 2287@Kärl	\N	\N	1	1	-5728	\N	C	2019-12-20 22:13:53.799521+00	3977
5727	-3349	13	173	KFL 2286@Kärl	\N	\N	1	1	-5727	\N	C	2019-12-20 22:13:53.799521+00	3978
5726	-3349	13	173	KFL 2285@Kärl	\N	\N	1	1	-5726	\N	C	2019-12-20 22:13:53.799521+00	3979
5725	-3290	13	173	KFL 2281@Sländtrissa &amp; vävtyngd	\N	\N	1	1	-5725	\N	C	2019-12-20 22:13:53.799521+00	3980
5724	-3290	13	173	KFL 2280@Sländtrissa &amp; vävtyngd	\N	\N	1	1	-5724	\N	C	2019-12-20 22:13:53.799521+00	3981
5723	-3290	13	173	KFL 2279@Kärl	\N	\N	1	1	-5723	\N	C	2019-12-20 22:13:53.799521+00	3982
5722	-3290	13	173	KFL 2278@Kärl	\N	\N	1	1	-5722	\N	C	2019-12-20 22:13:53.799521+00	3983
5721	-3290	13	173	KFL 2277@Kärl	\N	\N	1	1	-5721	\N	C	2019-12-20 22:13:53.799521+00	3984
5720	-3290	13	173	KFL 2276@Kärl	\N	\N	1	1	-5720	\N	C	2019-12-20 22:13:53.799521+00	3985
5719	-3290	13	173	KFL 2275@Kärl	\N	\N	1	1	-5719	\N	C	2019-12-20 22:13:53.799521+00	3986
5718	-3290	13	173	KFL 2274@Kärl	\N	\N	1	1	-5718	\N	C	2019-12-20 22:13:53.799521+00	3987
5717	-3290	13	173	KFL 2273@Kärl	\N	\N	1	1	-5717	\N	C	2019-12-20 22:13:53.799521+00	3988
5716	-3290	13	173	KFL 2272@Kärl	\N	\N	1	1	-5716	\N	C	2019-12-20 22:13:53.799521+00	3989
5715	-3290	13	173	KFL 2271@Kärl	\N	\N	1	1	-5715	\N	C	2019-12-20 22:13:53.799521+00	3990
5714	-3290	13	173	KFL 2270@Kärl	\N	\N	1	1	-5714	\N	C	2019-12-20 22:13:53.799521+00	3991
5713	-3290	13	173	KFL 2269@Kärl	\N	\N	1	1	-5713	\N	C	2019-12-20 22:13:53.799521+00	3992
5712	-3290	13	173	KFL 2268@Kärl	\N	\N	1	1	-5712	\N	C	2019-12-20 22:13:53.799521+00	3993
5711	-3290	13	173	KFL 2267@Kärl	\N	\N	1	1	-5711	\N	C	2019-12-20 22:13:53.799521+00	3994
5710	-3290	13	173	KFL 2266@Kärl	\N	\N	1	1	-5710	\N	C	2019-12-20 22:13:53.799521+00	3995
5709	-3290	13	173	KFL 2265@Kärl	\N	\N	1	1	-5709	\N	C	2019-12-20 22:13:53.799521+00	3996
5708	-3290	13	173	KFL 2264@Kärl	\N	\N	1	1	-5708	\N	C	2019-12-20 22:13:53.799521+00	3997
5707	-3290	13	173	KFL 2263@Kärl	\N	\N	1	1	-5707	\N	C	2019-12-20 22:13:53.799521+00	3998
5706	-3290	13	173	KFL 2262@Kärl	\N	\N	1	1	-5706	\N	C	2019-12-20 22:13:53.799521+00	3999
5705	-3290	13	173	KFL 2261@Kärl	\N	\N	1	1	-5705	\N	C	2019-12-20 22:13:53.799521+00	4000
5704	-3290	13	173	KFL 2260@Kärl	\N	\N	1	1	-5704	\N	C	2019-12-20 22:13:53.799521+00	4001
5703	-3290	13	173	KFL 2259@Kärl	\N	\N	1	1	-5703	\N	C	2019-12-20 22:13:53.799521+00	4002
5702	-3062	13	173	KFL 2258@Kärl	\N	\N	1	1	-5702	\N	C	2019-12-20 22:13:53.799521+00	4003
5701	-3062	13	173	KFL 2257@Kärl	\N	\N	1	1	-5701	\N	C	2019-12-20 22:13:53.799521+00	4004
5700	-3387	13	173	KFL 2215@Kärl	\N	\N	1	1	-5700	\N	C	2019-12-20 22:13:53.799521+00	4005
5699	-3193	13	173	KFL 2214@Kärl	\N	\N	1	1	-5699	\N	C	2019-12-20 22:13:53.799521+00	4006
5698	-2991	13	173	KFL 2213@Kärl	\N	\N	1	1	-5698	\N	C	2019-12-20 22:13:53.799521+00	4007
5697	-2991	13	173	KFL 2212@Kärl	\N	\N	1	1	-5697	\N	C	2019-12-20 22:13:53.799521+00	4008
5696	-2991	13	173	KFL 2211@Kärl	\N	\N	1	1	-5696	\N	C	2019-12-20 22:13:53.799521+00	4009
5695	-2991	13	173	KFL 2210@Kärl	\N	\N	1	1	-5695	\N	C	2019-12-20 22:13:53.799521+00	4010
5694	-2991	13	173	KFL 2209@Kärl	\N	\N	1	1	-5694	\N	C	2019-12-20 22:13:53.799521+00	4011
5693	-3006	13	173	KFL 2197@Lerklining	\N	\N	1	1	-5693	\N	C	2019-12-20 22:13:53.799521+00	4012
5692	-3006	13	173	KFL 2196@Kärl?	\N	\N	1	1	-5692	\N	C	2019-12-20 22:13:53.799521+00	4013
5691	-3006	13	173	KFL 2195@Kärl?	\N	\N	1	1	-5691	\N	C	2019-12-20 22:13:53.799521+00	4014
5690	-3298	13	173	KFL 2192@Kärl	\N	\N	1	1	-5690	\N	C	2019-12-20 22:13:53.799521+00	4015
5689	-3080	13	173	KFL 2167@Kärl	\N	\N	1	1	-5689	\N	C	2019-12-20 22:13:53.799521+00	4016
5688	-3080	13	173	KFL 2166@Kärl	\N	\N	1	1	-5688	\N	C	2019-12-20 22:13:53.799521+00	4017
5687	-3080	13	173	KFL 2165@Kärl	\N	\N	1	1	-5687	\N	C	2019-12-20 22:13:53.799521+00	4018
5686	-3018	13	173	KFL 2164@Kärl	\N	\N	1	1	-5686	\N	C	2019-12-20 22:13:53.799521+00	4019
5685	-3018	13	173	KFL 2163@Kärl	\N	\N	1	1	-5685	\N	C	2019-12-20 22:13:53.799521+00	4020
5684	-3018	13	173	KFL 2162@Kärl	\N	\N	1	1	-5684	\N	C	2019-12-20 22:13:53.799521+00	4021
5683	-3074	13	173	KFL 2161@Kärl	\N	\N	1	1	-5683	\N	C	2019-12-20 22:13:53.799521+00	4022
5682	-3074	13	173	KFL 2160@Kärl	\N	\N	1	1	-5682	\N	C	2019-12-20 22:13:53.799521+00	4023
5681	-3074	13	173	KFL 2159@Kärl	\N	\N	1	1	-5681	\N	C	2019-12-20 22:13:53.799521+00	4024
5680	-3074	13	173	KFL 2158@Kärl	\N	\N	1	1	-5680	\N	C	2019-12-20 22:13:53.799521+00	4025
5679	-3074	13	173	KFL 2157@Kärl	\N	\N	1	1	-5679	\N	C	2019-12-20 22:13:53.799521+00	4026
5678	-3074	13	173	KFL 2156@Kärl	\N	\N	1	1	-5678	\N	C	2019-12-20 22:13:53.799521+00	4027
5677	-3019	13	173	KFL 2155@Kärl	\N	\N	1	1	-5677	\N	C	2019-12-20 22:13:53.799521+00	4028
5676	-3019	13	173	KFL 2154@Lerklining	\N	\N	1	1	-5676	\N	C	2019-12-20 22:13:53.799521+00	4029
5675	-3018	13	173	KFL 2153@Kärl	\N	\N	1	1	-5675	\N	C	2019-12-20 22:13:53.799521+00	4030
5674	-3018	13	173	KFL 2152@Kärl	\N	\N	1	1	-5674	\N	C	2019-12-20 22:13:53.799521+00	4031
5673	-3018	13	173	KFL 2151@Kärl	\N	\N	1	1	-5673	\N	C	2019-12-20 22:13:53.799521+00	4032
5672	-3018	13	173	KFL 2150@Kärl	\N	\N	1	1	-5672	\N	C	2019-12-20 22:13:53.799521+00	4033
5671	-3018	13	173	KFL 2149@Kärl	\N	\N	1	1	-5671	\N	C	2019-12-20 22:13:53.799521+00	4034
5670	-3018	13	173	KFL 2148@Kärl	\N	\N	1	1	-5670	\N	C	2019-12-20 22:13:53.799521+00	4035
5669	-3018	13	173	KFL 2147@Kärl	\N	\N	1	1	-5669	\N	C	2019-12-20 22:13:53.799521+00	4036
5668	-3018	13	173	KFL 2146@Kärl	\N	\N	1	1	-5668	\N	C	2019-12-20 22:13:53.799521+00	4037
5667	-3018	13	173	KFL 2145@Kärl	\N	\N	1	1	-5667	\N	C	2019-12-20 22:13:53.799521+00	4038
5666	-3018	13	173	KFL 2144@Kärl	\N	\N	1	1	-5666	\N	C	2019-12-20 22:13:53.799521+00	4039
5665	-3018	13	173	KFL 2143@Kärl	\N	\N	1	1	-5665	\N	C	2019-12-20 22:13:53.799521+00	4040
5664	-3018	13	173	KFL 2142@Kärl	\N	\N	1	1	-5664	\N	C	2019-12-20 22:13:53.799521+00	4041
5663	-3018	13	173	KFL 2141@Kärl	\N	\N	1	1	-5663	\N	C	2019-12-20 22:13:53.799521+00	4042
5662	-3018	13	173	KFL 2140@Kärl	\N	\N	1	1	-5662	\N	C	2019-12-20 22:13:53.799521+00	4043
5661	-3018	13	173	KFL 2139@Kärl	\N	\N	1	1	-5661	\N	C	2019-12-20 22:13:53.799521+00	4044
5660	-3211	13	173	KFL 2138@Lerklining	\N	\N	1	1	-5660	\N	C	2019-12-20 22:13:53.799521+00	4045
5659	-3211	13	173	KFL 2137@Kärl	\N	\N	1	1	-5659	\N	C	2019-12-20 22:13:53.799521+00	4046
5658	-3211	13	173	KFL 2136@Kärl	\N	\N	1	1	-5658	\N	C	2019-12-20 22:13:53.799521+00	4047
5657	-3211	13	173	KFL 2135@Kärl	\N	\N	1	1	-5657	\N	C	2019-12-20 22:13:53.799521+00	4048
5656	-3211	13	173	KFL 2134@Kärl	\N	\N	1	1	-5656	\N	C	2019-12-20 22:13:53.799521+00	4049
5655	-3211	13	173	KFL 2133@Kärl	\N	\N	1	1	-5655	\N	C	2019-12-20 22:13:53.799521+00	4050
5654	-3211	13	173	KFL 2132@Kärl	\N	\N	1	1	-5654	\N	C	2019-12-20 22:13:53.799521+00	4051
5653	-3211	13	173	KFL 2131@Kärl	\N	\N	1	1	-5653	\N	C	2019-12-20 22:13:53.799521+00	4052
5652	-3074	13	173	KFL 2130@Kärl	\N	\N	1	1	-5652	\N	C	2019-12-20 22:13:53.799521+00	4053
5651	-3074	13	173	KFL 2129@Kärl	\N	\N	1	1	-5651	\N	C	2019-12-20 22:13:53.799521+00	4054
5650	-3019	13	173	KFL 2128@Kärl	\N	\N	1	1	-5650	\N	C	2019-12-20 22:13:53.799521+00	4055
5649	-3019	13	173	KFL 2127@Kärl	\N	\N	1	1	-5649	\N	C	2019-12-20 22:13:53.799521+00	4056
5648	-3019	13	173	KFL 2126@Kärl	\N	\N	1	1	-5648	\N	C	2019-12-20 22:13:53.799521+00	4057
5647	-3019	13	173	KFL 2125@Kärl	\N	\N	1	1	-5647	\N	C	2019-12-20 22:13:53.799521+00	4058
5646	-3019	13	173	KFL 2124@Kärl	\N	\N	1	1	-5646	\N	C	2019-12-20 22:13:53.799521+00	4059
5645	-3019	13	173	KFL 2123@Kärl	\N	\N	1	1	-5645	\N	C	2019-12-20 22:13:53.799521+00	4060
5644	-3019	13	173	KFL 2122@Kärl	\N	\N	1	1	-5644	\N	C	2019-12-20 22:13:53.799521+00	4061
5643	-3019	13	173	KFL 2121@Kärl	\N	\N	1	1	-5643	\N	C	2019-12-20 22:13:53.799521+00	4062
5642	-3019	13	173	KFL 2120@Kärl	\N	\N	1	1	-5642	\N	C	2019-12-20 22:13:53.799521+00	4063
5641	-3019	13	173	KFL 2119@Kärl	\N	\N	1	1	-5641	\N	C	2019-12-20 22:13:53.799521+00	4064
5640	-3019	13	173	KFL 2118@Kärl	\N	\N	1	1	-5640	\N	C	2019-12-20 22:13:53.799521+00	4065
5639	-3019	13	173	KFL 2117@Kärl	\N	\N	1	1	-5639	\N	C	2019-12-20 22:13:53.799521+00	4066
5638	-3019	13	173	KFL 2116@Kärl	\N	\N	1	1	-5638	\N	C	2019-12-20 22:13:53.799521+00	4067
5637	-3019	13	173	KFL 2115@Kärl	\N	\N	1	1	-5637	\N	C	2019-12-20 22:13:53.799521+00	4068
5636	-3019	13	173	KFL 2114@Kärl	\N	\N	1	1	-5636	\N	C	2019-12-20 22:13:53.799521+00	4069
5635	-3019	13	173	KFL 2113@Kärl	\N	\N	1	1	-5635	\N	C	2019-12-20 22:13:53.799521+00	4070
5634	-3019	13	173	KFL 2112@Kärl	\N	\N	1	1	-5634	\N	C	2019-12-20 22:13:53.799521+00	4071
5633	-3019	13	173	KFL 2111@Kärl	\N	\N	1	1	-5633	\N	C	2019-12-20 22:13:53.799521+00	4072
5632	-3019	13	173	KFL 2110@Kärl	\N	\N	1	1	-5632	\N	C	2019-12-20 22:13:53.799521+00	4073
5631	-3019	13	173	KFL 2109@Kärl	\N	\N	1	1	-5631	\N	C	2019-12-20 22:13:53.799521+00	4074
5630	-3019	13	173	KFL 2108@Kärl	\N	\N	1	1	-5630	\N	C	2019-12-20 22:13:53.799521+00	4075
5629	-3019	13	173	KFL 2107@Kärl	\N	\N	1	1	-5629	\N	C	2019-12-20 22:13:53.799521+00	4076
5628	-3019	13	173	KFL 2106@Kärl	\N	\N	1	1	-5628	\N	C	2019-12-20 22:13:53.799521+00	4077
5627	-3019	13	173	KFL 2105@Kärl	\N	\N	1	1	-5627	\N	C	2019-12-20 22:13:53.799521+00	4078
5626	-3019	13	173	KFL 2104@Kärl	\N	\N	1	1	-5626	\N	C	2019-12-20 22:13:53.799521+00	4079
5625	-3019	13	173	KFL 2103@Kärl	\N	\N	1	1	-5625	\N	C	2019-12-20 22:13:53.799521+00	4080
5624	-3019	13	173	KFL 2102@Kärl	\N	\N	1	1	-5624	\N	C	2019-12-20 22:13:53.799521+00	4081
5623	-3019	13	173	KFL 2101@Kärl	\N	\N	1	1	-5623	\N	C	2019-12-20 22:13:53.799521+00	4082
5622	-3019	13	173	KFL 2100@Kärl	\N	\N	1	1	-5622	\N	C	2019-12-20 22:13:53.799521+00	4083
5621	-3019	13	173	KFL 2099@Kärl	\N	\N	1	1	-5621	\N	C	2019-12-20 22:13:53.799521+00	4084
5620	-3019	13	173	KFL 2098@Kärl	\N	\N	1	1	-5620	\N	C	2019-12-20 22:13:53.799521+00	4085
5619	-3019	13	173	KFL 2097@Kärl	\N	\N	1	1	-5619	\N	C	2019-12-20 22:13:53.799521+00	4086
5618	-3019	13	173	KFL 2096@Lerklining	\N	\N	1	1	-5618	\N	C	2019-12-20 22:13:53.799521+00	4087
5617	-3225	13	173	KFL 2095@Kärl	\N	\N	1	1	-5617	\N	C	2019-12-20 22:13:53.799521+00	4088
5616	-3225	13	173	KFL 2094@Lerklining	\N	\N	1	1	-5616	\N	C	2019-12-20 22:13:53.799521+00	4089
5615	-3225	13	173	KFL 2093@Kärl	\N	\N	1	1	-5615	\N	C	2019-12-20 22:13:53.799521+00	4090
5614	-3225	13	173	KFL 2092@Kärl	\N	\N	1	1	-5614	\N	C	2019-12-20 22:13:53.799521+00	4091
5613	-3225	13	173	KFL 2091@Kärl	\N	\N	1	1	-5613	\N	C	2019-12-20 22:13:53.799521+00	4092
5612	-3225	13	173	KFL 2090@Kärl	\N	\N	1	1	-5612	\N	C	2019-12-20 22:13:53.799521+00	4093
5611	-3225	13	173	KFL 2089@Kärl	\N	\N	1	1	-5611	\N	C	2019-12-20 22:13:53.799521+00	4094
5610	-3225	13	173	KFL 2088@Kärl	\N	\N	1	1	-5610	\N	C	2019-12-20 22:13:53.799521+00	4095
5609	-3225	13	173	KFL 2087@Kärl	\N	\N	1	1	-5609	\N	C	2019-12-20 22:13:53.799521+00	4096
5608	-3225	13	173	KFL 2086@Kärl	\N	\N	1	1	-5608	\N	C	2019-12-20 22:13:53.799521+00	4097
5607	-3225	13	173	KFL 2085@Kärl	\N	\N	1	1	-5607	\N	C	2019-12-20 22:13:53.799521+00	4098
5606	-3225	13	173	KFL 2084@Kärl	\N	\N	1	1	-5606	\N	C	2019-12-20 22:13:53.799521+00	4099
5605	-3225	13	173	KFL 2083@Kärl	\N	\N	1	1	-5605	\N	C	2019-12-20 22:13:53.799521+00	4100
5604	-3225	13	173	KFL 2082@Kärl	\N	\N	1	1	-5604	\N	C	2019-12-20 22:13:53.799521+00	4101
5603	-3225	13	173	KFL 2081@Kärl	\N	\N	1	1	-5603	\N	C	2019-12-20 22:13:53.799521+00	4102
5602	-3225	13	173	KFL 2080@Kärl	\N	\N	1	1	-5602	\N	C	2019-12-20 22:13:53.799521+00	4103
5601	-3225	13	173	KFL 2079@Kärl	\N	\N	1	1	-5601	\N	C	2019-12-20 22:13:53.799521+00	4104
5600	-3225	13	173	KFL 2078@Kärl	\N	\N	1	1	-5600	\N	C	2019-12-20 22:13:53.799521+00	4105
5599	-3225	13	173	KFL 2077@Kärl	\N	\N	1	1	-5599	\N	C	2019-12-20 22:13:53.799521+00	4106
5598	-3225	13	173	KFL 2076@Kärl	\N	\N	1	1	-5598	\N	C	2019-12-20 22:13:53.799521+00	4107
5597	-3225	13	173	KFL 2075@Kärl	\N	\N	1	1	-5597	\N	C	2019-12-20 22:13:53.799521+00	4108
5596	-3225	13	173	KFL 2074@Kärl	\N	\N	1	1	-5596	\N	C	2019-12-20 22:13:53.799521+00	4109
5595	-3225	13	173	KFL 2073@Kärl	\N	\N	1	1	-5595	\N	C	2019-12-20 22:13:53.799521+00	4110
5594	-3225	13	173	KFL 2072@Kärl	\N	\N	1	1	-5594	\N	C	2019-12-20 22:13:53.799521+00	4111
5593	-3225	13	173	KFL 2071@Kärl	\N	\N	1	1	-5593	\N	C	2019-12-20 22:13:53.799521+00	4112
5592	-3225	13	173	KFL 2070@Kärl	\N	\N	1	1	-5592	\N	C	2019-12-20 22:13:53.799521+00	4113
5591	-3225	13	173	KFL 2069@Kärl	\N	\N	1	1	-5591	\N	C	2019-12-20 22:13:53.799521+00	4114
5590	-3225	13	173	KFL 2068@Kärl	\N	\N	1	1	-5590	\N	C	2019-12-20 22:13:53.799521+00	4115
5589	-3225	13	173	KFL 2067@Kärl	\N	\N	1	1	-5589	\N	C	2019-12-20 22:13:53.799521+00	4116
5588	-3225	13	173	KFL 2066@Kärl	\N	\N	1	1	-5588	\N	C	2019-12-20 22:13:53.799521+00	4117
5587	-3225	13	173	KFL 2065@Kärl	\N	\N	1	1	-5587	\N	C	2019-12-20 22:13:53.799521+00	4118
5586	-3225	13	173	KFL 2064@Kärl	\N	\N	1	1	-5586	\N	C	2019-12-20 22:13:53.799521+00	4119
5585	-3225	13	173	KFL 2063@Kärl	\N	\N	1	1	-5585	\N	C	2019-12-20 22:13:53.799521+00	4120
5584	-3225	13	173	KFL 2062@Kärl	\N	\N	1	1	-5584	\N	C	2019-12-20 22:13:53.799521+00	4121
5583	-3225	13	173	KFL 2061@Kärl	\N	\N	1	1	-5583	\N	C	2019-12-20 22:13:53.799521+00	4122
5582	-3225	13	173	KFL 2060@Kärl	\N	\N	1	1	-5582	\N	C	2019-12-20 22:13:53.799521+00	4123
5581	-3225	13	173	KFL 2059@Kärl	\N	\N	1	1	-5581	\N	C	2019-12-20 22:13:53.799521+00	4124
5580	-3225	13	173	KFL 2058@Kärl	\N	\N	1	1	-5580	\N	C	2019-12-20 22:13:53.799521+00	4125
5579	-3225	13	173	KFL 2057@Kärl	\N	\N	1	1	-5579	\N	C	2019-12-20 22:13:53.799521+00	4126
5578	-3225	13	173	KFL 2056@Kärl	\N	\N	1	1	-5578	\N	C	2019-12-20 22:13:53.799521+00	4127
5577	-3225	13	173	KFL 2055@Kärl	\N	\N	1	1	-5577	\N	C	2019-12-20 22:13:53.799521+00	4128
5576	-3225	13	173	KFL 2054@Kärl	\N	\N	1	1	-5576	\N	C	2019-12-20 22:13:53.799521+00	4129
5575	-3018	13	173	KFL 2053@Kärl	\N	\N	1	1	-5575	\N	C	2019-12-20 22:13:53.799521+00	4130
5574	-3018	13	173	KFL 2052@Kärl	\N	\N	1	1	-5574	\N	C	2019-12-20 22:13:53.799521+00	4131
5573	-3018	13	173	KFL 2051@Kärl	\N	\N	1	1	-5573	\N	C	2019-12-20 22:13:53.799521+00	4132
5572	-3018	13	173	KFL 2050@Kärl	\N	\N	1	1	-5572	\N	C	2019-12-20 22:13:53.799521+00	4133
5571	-3018	13	173	KFL 2049@Kärl	\N	\N	1	1	-5571	\N	C	2019-12-20 22:13:53.799521+00	4134
5570	-3018	13	173	KFL 2048@Kärl	\N	\N	1	1	-5570	\N	C	2019-12-20 22:13:53.799521+00	4135
5569	-3046	13	173	KFL 2047@Kärl	\N	\N	1	1	-5569	\N	C	2019-12-20 22:13:53.799521+00	4136
5568	-3046	13	173	KFL 2046@Kärl	\N	\N	1	1	-5568	\N	C	2019-12-20 22:13:53.799521+00	4137
5567	-3046	13	173	KFL 2045@Kärl	\N	\N	1	1	-5567	\N	C	2019-12-20 22:13:53.799521+00	4138
5566	-3046	13	173	KFL 2044@Kärl	\N	\N	1	1	-5566	\N	C	2019-12-20 22:13:53.799521+00	4139
5565	-3046	13	173	KFL 2043@Kärl	\N	\N	1	1	-5565	\N	C	2019-12-20 22:13:53.799521+00	4140
5564	-3046	13	173	KFL 2042@Kärl	\N	\N	1	1	-5564	\N	C	2019-12-20 22:13:53.799521+00	4141
5563	-3255	13	173	KFL 2041@Kärl	\N	\N	1	1	-5563	\N	C	2019-12-20 22:13:53.799521+00	4142
5562	-3213	13	173	KFL 2040@Kärl	\N	\N	1	1	-5562	\N	C	2019-12-20 22:13:53.799521+00	4143
5561	-3242	13	173	KFL 2039@Kärl	\N	\N	1	1	-5561	\N	C	2019-12-20 22:13:53.799521+00	4144
5560	-3242	13	173	KFL 2038@Kärl	\N	\N	1	1	-5560	\N	C	2019-12-20 22:13:53.799521+00	4145
5559	-3242	13	173	KFL 2037@Kärl	\N	\N	1	1	-5559	\N	C	2019-12-20 22:13:53.799521+00	4146
5558	-3242	13	173	KFL 2036@Kärl	\N	\N	1	1	-5558	\N	C	2019-12-20 22:13:53.799521+00	4147
5557	-3242	13	173	KFL 2035@Kärl	\N	\N	1	1	-5557	\N	C	2019-12-20 22:13:53.799521+00	4148
5556	-3242	13	173	KFL 2034@Kärl	\N	\N	1	1	-5556	\N	C	2019-12-20 22:13:53.799521+00	4149
5555	-3242	13	173	KFL 2033@Kärl	\N	\N	1	1	-5555	\N	C	2019-12-20 22:13:53.799521+00	4150
5554	-3242	13	173	KFL 2032@Kärl	\N	\N	1	1	-5554	\N	C	2019-12-20 22:13:53.799521+00	4151
5553	-3242	13	173	KFL 2031@Kärl	\N	\N	1	1	-5553	\N	C	2019-12-20 22:13:53.799521+00	4152
5552	-3242	13	173	KFL 2030@Kärl	\N	\N	1	1	-5552	\N	C	2019-12-20 22:13:53.799521+00	4153
5551	-3242	13	173	KFL 2029@Kärl	\N	\N	1	1	-5551	\N	C	2019-12-20 22:13:53.799521+00	4154
5550	-3242	13	173	KFL 2028@Kärl	\N	\N	1	1	-5550	\N	C	2019-12-20 22:13:53.799521+00	4155
5549	-3242	13	173	KFL 2027@Kärl	\N	\N	1	1	-5549	\N	C	2019-12-20 22:13:53.799521+00	4156
5548	-3242	13	173	KFL 2026@Kärl	\N	\N	1	1	-5548	\N	C	2019-12-20 22:13:53.799521+00	4157
5547	-3242	13	173	KFL 2025@Kärl	\N	\N	1	1	-5547	\N	C	2019-12-20 22:13:53.799521+00	4158
5546	-3242	13	173	KFL 2024@Kärl	\N	\N	1	1	-5546	\N	C	2019-12-20 22:13:53.799521+00	4159
5545	-3242	13	173	KFL 2023@Kärl	\N	\N	1	1	-5545	\N	C	2019-12-20 22:13:53.799521+00	4160
5544	-3242	13	173	KFL 2022@Kärl	\N	\N	1	1	-5544	\N	C	2019-12-20 22:13:53.799521+00	4161
5543	-3242	13	173	KFL 2021@Kärl	\N	\N	1	1	-5543	\N	C	2019-12-20 22:13:53.799521+00	4162
5542	-3242	13	173	KFL 2020@Kärl	\N	\N	1	1	-5542	\N	C	2019-12-20 22:13:53.799521+00	4163
5541	-3242	13	173	KFL 2019@Kärl	\N	\N	1	1	-5541	\N	C	2019-12-20 22:13:53.799521+00	4164
5540	-3242	13	173	KFL 2018@Kärl	\N	\N	1	1	-5540	\N	C	2019-12-20 22:13:53.799521+00	4165
5539	-3242	13	173	KFL 2017@Kärl	\N	\N	1	1	-5539	\N	C	2019-12-20 22:13:53.799521+00	4166
5538	-3242	13	173	KFL 2016@Kärl	\N	\N	1	1	-5538	\N	C	2019-12-20 22:13:53.799521+00	4167
5537	-3242	13	173	KFL 2015@Kärl	\N	\N	1	1	-5537	\N	C	2019-12-20 22:13:53.799521+00	4168
5536	-3242	13	173	KFL 2014@Kärl	\N	\N	1	1	-5536	\N	C	2019-12-20 22:13:53.799521+00	4169
5535	-3242	13	173	KFL 2013@Kärl	\N	\N	1	1	-5535	\N	C	2019-12-20 22:13:53.799521+00	4170
5534	-3242	13	173	KFL 2012@Kärl	\N	\N	1	1	-5534	\N	C	2019-12-20 22:13:53.799521+00	4171
5533	-3242	13	173	KFL 2011@Kärl	\N	\N	1	1	-5533	\N	C	2019-12-20 22:13:53.799521+00	4172
5532	-3242	13	173	KFL 2010@Kärl	\N	\N	1	1	-5532	\N	C	2019-12-20 22:13:53.799521+00	4173
5531	-3242	13	173	KFL 2009@Kärl	\N	\N	1	1	-5531	\N	C	2019-12-20 22:13:53.799521+00	4174
5530	-3242	13	173	KFL 2008@Kärl	\N	\N	1	1	-5530	\N	C	2019-12-20 22:13:53.799521+00	4175
5529	-3242	13	173	KFL 2007@Kärl	\N	\N	1	1	-5529	\N	C	2019-12-20 22:13:53.799521+00	4176
5528	-3242	13	173	KFL 2006@Kärl	\N	\N	1	1	-5528	\N	C	2019-12-20 22:13:53.799521+00	4177
5527	-3242	13	173	KFL 2005@Kärl	\N	\N	1	1	-5527	\N	C	2019-12-20 22:13:53.799521+00	4178
5526	-3242	13	173	KFL 2004@Kärl	\N	\N	1	1	-5526	\N	C	2019-12-20 22:13:53.799521+00	4179
5525	-3242	13	173	KFL 2003@Kärl	\N	\N	1	1	-5525	\N	C	2019-12-20 22:13:53.799521+00	4180
5524	-3242	13	173	KFL 2002@Kärl	\N	\N	1	1	-5524	\N	C	2019-12-20 22:13:53.799521+00	4181
5523	-3242	13	173	KFL 2001@Kärl	\N	\N	1	1	-5523	\N	C	2019-12-20 22:13:53.799521+00	4182
5522	-3242	13	173	KFL 2000@Kärl	\N	\N	1	1	-5522	\N	C	2019-12-20 22:13:53.799521+00	4183
5521	-3242	13	173	KFL 1999@Kärl	\N	\N	1	1	-5521	\N	C	2019-12-20 22:13:53.799521+00	4184
5520	-3242	13	173	KFL 1998@Kärl	\N	\N	1	1	-5520	\N	C	2019-12-20 22:13:53.799521+00	4185
5519	-3242	13	173	KFL 1997@Kärl	\N	\N	1	1	-5519	\N	C	2019-12-20 22:13:53.799521+00	4186
5518	-3242	13	173	KFL 1996@Kärl	\N	\N	1	1	-5518	\N	C	2019-12-20 22:13:53.799521+00	4187
5517	-3242	13	173	KFL 1995@Kärl	\N	\N	1	1	-5517	\N	C	2019-12-20 22:13:53.799521+00	4188
5516	-3242	13	173	KFL 1994@Kärl	\N	\N	1	1	-5516	\N	C	2019-12-20 22:13:53.799521+00	4189
5515	-3242	13	173	KFL 1993@Kärl	\N	\N	1	1	-5515	\N	C	2019-12-20 22:13:53.799521+00	4190
5514	-3242	13	173	KFL 1992@Kärl	\N	\N	1	1	-5514	\N	C	2019-12-20 22:13:53.799521+00	4191
5513	-3242	13	173	KFL 1991@Kärl	\N	\N	1	1	-5513	\N	C	2019-12-20 22:13:53.799521+00	4192
5512	-3242	13	173	KFL 1990@Kärl	\N	\N	1	1	-5512	\N	C	2019-12-20 22:13:53.799521+00	4193
5511	-3242	13	173	KFL 1989@Kärl	\N	\N	1	1	-5511	\N	C	2019-12-20 22:13:53.799521+00	4194
5510	-3242	13	173	KFL 1988@Kärl	\N	\N	1	1	-5510	\N	C	2019-12-20 22:13:53.799521+00	4195
5509	-3242	13	173	KFL 1987@Kärl	\N	\N	1	1	-5509	\N	C	2019-12-20 22:13:53.799521+00	4196
5508	-3242	13	173	KFL 1986@Kärl	\N	\N	1	1	-5508	\N	C	2019-12-20 22:13:53.799521+00	4197
5507	-3242	13	173	KFL 1985@Kärl	\N	\N	1	1	-5507	\N	C	2019-12-20 22:13:53.799521+00	4198
5506	-3242	13	173	KFL 1984@Kärl	\N	\N	1	1	-5506	\N	C	2019-12-20 22:13:53.799521+00	4199
5505	-3242	13	173	KFL 1983@Kärl	\N	\N	1	1	-5505	\N	C	2019-12-20 22:13:53.799521+00	4200
5504	-3242	13	173	KFL 1982@Kärl	\N	\N	1	1	-5504	\N	C	2019-12-20 22:13:53.799521+00	4201
5503	-3242	13	173	KFL 1981@Kärl	\N	\N	1	1	-5503	\N	C	2019-12-20 22:13:53.799521+00	4202
5502	-3242	13	173	KFL 1980@Kärl	\N	\N	1	1	-5502	\N	C	2019-12-20 22:13:53.799521+00	4203
5501	-3242	13	173	KFL 1979@Kärl	\N	\N	1	1	-5501	\N	C	2019-12-20 22:13:53.799521+00	4204
5500	-3242	13	173	KFL 1978@Kärl	\N	\N	1	1	-5500	\N	C	2019-12-20 22:13:53.799521+00	4205
5499	-3242	13	173	KFL 1977@Kärl	\N	\N	1	1	-5499	\N	C	2019-12-20 22:13:53.799521+00	4206
5498	-3242	13	173	KFL 1976@Kärl	\N	\N	1	1	-5498	\N	C	2019-12-20 22:13:53.799521+00	4207
5497	-3242	13	173	KFL 1975@Kärl	\N	\N	1	1	-5497	\N	C	2019-12-20 22:13:53.799521+00	4208
5496	-3242	13	173	KFL 1974@Kärl	\N	\N	1	1	-5496	\N	C	2019-12-20 22:13:53.799521+00	4209
5495	-3242	13	173	KFL 1973@Kärl	\N	\N	1	1	-5495	\N	C	2019-12-20 22:13:53.799521+00	4210
5494	-3242	13	173	KFL 1972@Kärl	\N	\N	1	1	-5494	\N	C	2019-12-20 22:13:53.799521+00	4211
5493	-3242	13	173	KFL 1971@Kärl	\N	\N	1	1	-5493	\N	C	2019-12-20 22:13:53.799521+00	4212
5492	-3242	13	173	KFL 1970@Kärl	\N	\N	1	1	-5492	\N	C	2019-12-20 22:13:53.799521+00	4213
5491	-3242	13	173	KFL 1969@Kärl	\N	\N	1	1	-5491	\N	C	2019-12-20 22:13:53.799521+00	4214
5490	-3242	13	173	KFL 1968@Kärl	\N	\N	1	1	-5490	\N	C	2019-12-20 22:13:53.799521+00	4215
5489	-3242	13	173	KFL 1967@Kärl	\N	\N	1	1	-5489	\N	C	2019-12-20 22:13:53.799521+00	4216
5488	-3242	13	173	KFL 1966@Kärl	\N	\N	1	1	-5488	\N	C	2019-12-20 22:13:53.799521+00	4217
5487	-3242	13	173	KFL 1965@Kärl	\N	\N	1	1	-5487	\N	C	2019-12-20 22:13:53.799521+00	4218
5486	-3242	13	173	KFL 1964@Kärl	\N	\N	1	1	-5486	\N	C	2019-12-20 22:13:53.799521+00	4219
5485	-3074	13	173	KFL 1963@Kärl	\N	\N	1	1	-5485	\N	C	2019-12-20 22:13:53.799521+00	4220
5484	-3079	13	173	KFL 1962@Kärl	\N	\N	1	1	-5484	\N	C	2019-12-20 22:13:53.799521+00	4221
5483	-3079	13	173	KFL 1961@Lerklining	\N	\N	1	1	-5483	\N	C	2019-12-20 22:13:53.799521+00	4222
5482	-3079	13	173	KFL 1960@Kärl	\N	\N	1	1	-5482	\N	C	2019-12-20 22:13:53.799521+00	4223
5481	-3079	13	173	KFL 1959@Kärl	\N	\N	1	1	-5481	\N	C	2019-12-20 22:13:53.799521+00	4224
5480	-3079	13	173	KFL 1958@Kärl	\N	\N	1	1	-5480	\N	C	2019-12-20 22:13:53.799521+00	4225
5479	-3079	13	173	KFL 1957@Kärl	\N	\N	1	1	-5479	\N	C	2019-12-20 22:13:53.799521+00	4226
5478	-3079	13	173	KFL 1956@Kärl	\N	\N	1	1	-5478	\N	C	2019-12-20 22:13:53.799521+00	4227
5477	-3079	13	173	KFL 1955@Kärl	\N	\N	1	1	-5477	\N	C	2019-12-20 22:13:53.799521+00	4228
5476	-3079	13	173	KFL 1954@Kärl	\N	\N	1	1	-5476	\N	C	2019-12-20 22:13:53.799521+00	4229
5475	-3079	13	173	KFL 1953@Kärl	\N	\N	1	1	-5475	\N	C	2019-12-20 22:13:53.799521+00	4230
5474	-3079	13	173	KFL 1952@Kärl	\N	\N	1	1	-5474	\N	C	2019-12-20 22:13:53.799521+00	4231
5473	-3079	13	173	KFL 1951@Kärl	\N	\N	1	1	-5473	\N	C	2019-12-20 22:13:53.799521+00	4232
5472	-3079	13	173	KFL 1950@Kärl	\N	\N	1	1	-5472	\N	C	2019-12-20 22:13:53.799521+00	4233
5471	-3079	13	173	KFL 1949@Kärl	\N	\N	1	1	-5471	\N	C	2019-12-20 22:13:53.799521+00	4234
5470	-3079	13	173	KFL 1948@Kärl	\N	\N	1	1	-5470	\N	C	2019-12-20 22:13:53.799521+00	4235
5469	-3079	13	173	KFL 1947@Kärl	\N	\N	1	1	-5469	\N	C	2019-12-20 22:13:53.799521+00	4236
5468	-3079	13	173	KFL 1946@Kärl	\N	\N	1	1	-5468	\N	C	2019-12-20 22:13:53.799521+00	4237
5467	-3079	13	173	KFL 1945@Kärl	\N	\N	1	1	-5467	\N	C	2019-12-20 22:13:53.799521+00	4238
5466	-3079	13	173	KFL 1944@Kärl	\N	\N	1	1	-5466	\N	C	2019-12-20 22:13:53.799521+00	4239
5465	-3079	13	173	KFL 1943@Kärl	\N	\N	1	1	-5465	\N	C	2019-12-20 22:13:53.799521+00	4240
5464	-3079	13	173	KFL 1942@Kärl	\N	\N	1	1	-5464	\N	C	2019-12-20 22:13:53.799521+00	4241
5463	-3079	13	173	KFL 1941@Kärl	\N	\N	1	1	-5463	\N	C	2019-12-20 22:13:53.799521+00	4242
5462	-3079	13	173	KFL 1940@Kärl	\N	\N	1	1	-5462	\N	C	2019-12-20 22:13:53.799521+00	4243
5461	-3079	13	173	KFL 1939@Kärl	\N	\N	1	1	-5461	\N	C	2019-12-20 22:13:53.799521+00	4244
5460	-3079	13	173	KFL 1938@Kärl	\N	\N	1	1	-5460	\N	C	2019-12-20 22:13:53.799521+00	4245
5459	-3079	13	173	KFL 1937@Kärl	\N	\N	1	1	-5459	\N	C	2019-12-20 22:13:53.799521+00	4246
5458	-3079	13	173	KFL 1936@Kärl	\N	\N	1	1	-5458	\N	C	2019-12-20 22:13:53.799521+00	4247
5457	-3079	13	173	KFL 1935@Kärl	\N	\N	1	1	-5457	\N	C	2019-12-20 22:13:53.799521+00	4248
5456	-3079	13	173	KFL 1934@Kärl	\N	\N	1	1	-5456	\N	C	2019-12-20 22:13:53.799521+00	4249
5455	-3079	13	173	KFL 1933@Kärl	\N	\N	1	1	-5455	\N	C	2019-12-20 22:13:53.799521+00	4250
5454	-3079	13	173	KFL 1932@Kärl	\N	\N	1	1	-5454	\N	C	2019-12-20 22:13:53.799521+00	4251
5453	-3079	13	173	KFL 1931@Kärl	\N	\N	1	1	-5453	\N	C	2019-12-20 22:13:53.799521+00	4252
5452	-3079	13	173	KFL 1930@Kärl	\N	\N	1	1	-5452	\N	C	2019-12-20 22:13:53.799521+00	4253
5451	-3079	13	173	KFL 1929@Kärl	\N	\N	1	1	-5451	\N	C	2019-12-20 22:13:53.799521+00	4254
5450	-3079	13	173	KFL 1928@Kärl	\N	\N	1	1	-5450	\N	C	2019-12-20 22:13:53.799521+00	4255
5449	-3079	13	173	KFL 1927@Kärl	\N	\N	1	1	-5449	\N	C	2019-12-20 22:13:53.799521+00	4256
5448	-3079	13	173	KFL 1926@Kärl	\N	\N	1	1	-5448	\N	C	2019-12-20 22:13:53.799521+00	4257
5447	-3079	13	173	KFL 1925@Kärl	\N	\N	1	1	-5447	\N	C	2019-12-20 22:13:53.799521+00	4258
5446	-3079	13	173	KFL 1924@Kärl	\N	\N	1	1	-5446	\N	C	2019-12-20 22:13:53.799521+00	4259
5445	-3079	13	173	KFL 1923@Kärl	\N	\N	1	1	-5445	\N	C	2019-12-20 22:13:53.799521+00	4260
5444	-3079	13	173	KFL 1922@Kärl	\N	\N	1	1	-5444	\N	C	2019-12-20 22:13:53.799521+00	4261
5443	-3079	13	173	KFL 1921@Kärl	\N	\N	1	1	-5443	\N	C	2019-12-20 22:13:53.799521+00	4262
5442	-3079	13	173	KFL 1920@Kärl	\N	\N	1	1	-5442	\N	C	2019-12-20 22:13:53.799521+00	4263
5441	-3079	13	173	KFL 1919@Kärl	\N	\N	1	1	-5441	\N	C	2019-12-20 22:13:53.799521+00	4264
5440	-3079	13	173	KFL 1918@Kärl	\N	\N	1	1	-5440	\N	C	2019-12-20 22:13:53.799521+00	4265
5439	-3079	13	173	KFL 1917@Kärl	\N	\N	1	1	-5439	\N	C	2019-12-20 22:13:53.799521+00	4266
5438	-3079	13	173	KFL 1916@Kärl	\N	\N	1	1	-5438	\N	C	2019-12-20 22:13:53.799521+00	4267
5437	-3079	13	173	KFL 1915@Kärl	\N	\N	1	1	-5437	\N	C	2019-12-20 22:13:53.799521+00	4268
5436	-3079	13	173	KFL 1914@Kärl	\N	\N	1	1	-5436	\N	C	2019-12-20 22:13:53.799521+00	4269
5435	-3079	13	173	KFL 1913@Kärl	\N	\N	1	1	-5435	\N	C	2019-12-20 22:13:53.799521+00	4270
5434	-3079	13	173	KFL 1912@Kärl	\N	\N	1	1	-5434	\N	C	2019-12-20 22:13:53.799521+00	4271
5433	-3079	13	173	KFL 1911@Kärl	\N	\N	1	1	-5433	\N	C	2019-12-20 22:13:53.799521+00	4272
5432	-3079	13	173	KFL 1910@Kärl	\N	\N	1	1	-5432	\N	C	2019-12-20 22:13:53.799521+00	4273
5431	-3079	13	173	KFL 1909@Kärl	\N	\N	1	1	-5431	\N	C	2019-12-20 22:13:53.799521+00	4274
5430	-3079	13	173	KFL 1908@Kärl	\N	\N	1	1	-5430	\N	C	2019-12-20 22:13:53.799521+00	4275
5429	-3212	13	173	KFL 1907@Kärl	\N	\N	1	1	-5429	\N	C	2019-12-20 22:13:53.799521+00	4276
5428	-3079	13	173	KFL 1906@Kärl	\N	\N	1	1	-5428	\N	C	2019-12-20 22:13:53.799521+00	4277
5427	-3212	13	173	KFL 1905@Kärl	\N	\N	1	1	-5427	\N	C	2019-12-20 22:13:53.799521+00	4278
5426	-3212	13	173	KFL 1904@Kärl	\N	\N	1	1	-5426	\N	C	2019-12-20 22:13:53.799521+00	4279
5425	-3212	13	173	KFL 1903@Kärl	\N	\N	1	1	-5425	\N	C	2019-12-20 22:13:53.799521+00	4280
5424	-3212	13	173	KFL 1902@Kärl	\N	\N	1	1	-5424	\N	C	2019-12-20 22:13:53.799521+00	4281
5423	-3212	13	173	KFL 1901@Kärl	\N	\N	1	1	-5423	\N	C	2019-12-20 22:13:53.799521+00	4282
5422	-3212	13	173	KFL 1900@Kärl	\N	\N	1	1	-5422	\N	C	2019-12-20 22:13:53.799521+00	4283
5421	-3212	13	173	KFL 1899@Kärl	\N	\N	1	1	-5421	\N	C	2019-12-20 22:13:53.799521+00	4284
5420	-3212	13	173	KFL 1898@Kärl	\N	\N	1	1	-5420	\N	C	2019-12-20 22:13:53.799521+00	4285
5419	-3212	13	173	KFL 1897@Kärl	\N	\N	1	1	-5419	\N	C	2019-12-20 22:13:53.799521+00	4286
5418	-3212	13	173	KFL 1896@Kärl	\N	\N	1	1	-5418	\N	C	2019-12-20 22:13:53.799521+00	4287
5417	-3212	13	173	KFL 1895@Kärl	\N	\N	1	1	-5417	\N	C	2019-12-20 22:13:53.799521+00	4288
5416	-3212	13	173	KFL 1894@Kärl	\N	\N	1	1	-5416	\N	C	2019-12-20 22:13:53.799521+00	4289
5415	-3212	13	173	KFL 1893@Kärl	\N	\N	1	1	-5415	\N	C	2019-12-20 22:13:53.799521+00	4290
5414	-3212	13	173	KFL 1892@Kärl	\N	\N	1	1	-5414	\N	C	2019-12-20 22:13:53.799521+00	4291
5413	-3212	13	173	KFL 1891@Kärl	\N	\N	1	1	-5413	\N	C	2019-12-20 22:13:53.799521+00	4292
5412	-3212	13	173	KFL 1890@Kärl	\N	\N	1	1	-5412	\N	C	2019-12-20 22:13:53.799521+00	4293
5411	-3212	13	173	KFL 1889@Kärl	\N	\N	1	1	-5411	\N	C	2019-12-20 22:13:53.799521+00	4294
5410	-3212	13	173	KFL 1888@Kärl	\N	\N	1	1	-5410	\N	C	2019-12-20 22:13:53.799521+00	4295
5409	-3212	13	173	KFL 1887@Kärl	\N	\N	1	1	-5409	\N	C	2019-12-20 22:13:53.799521+00	4296
5408	-3212	13	173	KFL 1886@Kärl	\N	\N	1	1	-5408	\N	C	2019-12-20 22:13:53.799521+00	4297
5407	-3212	13	173	KFL 1885@Kärl	\N	\N	1	1	-5407	\N	C	2019-12-20 22:13:53.799521+00	4298
5406	-3212	13	173	KFL 1884@Kärl	\N	\N	1	1	-5406	\N	C	2019-12-20 22:13:53.799521+00	4299
5405	-3212	13	173	KFL 1883@Kärl	\N	\N	1	1	-5405	\N	C	2019-12-20 22:13:53.799521+00	4300
5404	-3212	13	173	KFL 1882@Kärl	\N	\N	1	1	-5404	\N	C	2019-12-20 22:13:53.799521+00	4301
5403	-3212	13	173	KFL 1881@Kärl	\N	\N	1	1	-5403	\N	C	2019-12-20 22:13:53.799521+00	4302
5402	-3212	13	173	KFL 1880@Kärl	\N	\N	1	1	-5402	\N	C	2019-12-20 22:13:53.799521+00	4303
5401	-3212	13	173	KFL 1879@Kärl	\N	\N	1	1	-5401	\N	C	2019-12-20 22:13:53.799521+00	4304
5400	-3212	13	173	KFL 1878@Kärl	\N	\N	1	1	-5400	\N	C	2019-12-20 22:13:53.799521+00	4305
5399	-3212	13	173	KFL 1877@Kärl	\N	\N	1	1	-5399	\N	C	2019-12-20 22:13:53.799521+00	4306
5398	-3212	13	173	KFL 1876@Kärl	\N	\N	1	1	-5398	\N	C	2019-12-20 22:13:53.799521+00	4307
5397	-3212	13	173	KFL 1875@Kärl	\N	\N	1	1	-5397	\N	C	2019-12-20 22:13:53.799521+00	4308
5396	-3212	13	173	KFL 1874@Kärl	\N	\N	1	1	-5396	\N	C	2019-12-20 22:13:53.799521+00	4309
5395	-3212	13	173	KFL 1873@Kärl	\N	\N	1	1	-5395	\N	C	2019-12-20 22:13:53.799521+00	4310
5394	-3212	13	173	KFL 1872@Kärl	\N	\N	1	1	-5394	\N	C	2019-12-20 22:13:53.799521+00	4311
5393	-3212	13	173	KFL 1871@Kärl	\N	\N	1	1	-5393	\N	C	2019-12-20 22:13:53.799521+00	4312
5392	-3212	13	173	KFL 1870@Kärl	\N	\N	1	1	-5392	\N	C	2019-12-20 22:13:53.799521+00	4313
5391	-3212	13	173	KFL 1869@Kärl	\N	\N	1	1	-5391	\N	C	2019-12-20 22:13:53.799521+00	4314
5390	-3212	13	173	KFL 1868@Kärl	\N	\N	1	1	-5390	\N	C	2019-12-20 22:13:53.799521+00	4315
5389	-3212	13	173	KFL 1867@Kärl	\N	\N	1	1	-5389	\N	C	2019-12-20 22:13:53.799521+00	4316
5388	-3211	13	173	KFL 1866@Kärl	\N	\N	1	1	-5388	\N	C	2019-12-20 22:13:53.799521+00	4317
5387	-3211	13	173	KFL 1865@Kärl	\N	\N	1	1	-5387	\N	C	2019-12-20 22:13:53.799521+00	4318
5386	-3211	13	173	KFL 1864@Kärl	\N	\N	1	1	-5386	\N	C	2019-12-20 22:13:53.799521+00	4319
5385	-3211	13	173	KFL 1863@Kärl	\N	\N	1	1	-5385	\N	C	2019-12-20 22:13:53.799521+00	4320
5384	-3211	13	173	KFL 1862@Kärl	\N	\N	1	1	-5384	\N	C	2019-12-20 22:13:53.799521+00	4321
5383	-3211	13	173	KFL 1861@Kärl	\N	\N	1	1	-5383	\N	C	2019-12-20 22:13:53.799521+00	4322
5382	-3211	13	173	KFL 1860@Kärl	\N	\N	1	1	-5382	\N	C	2019-12-20 22:13:53.799521+00	4323
5381	-3211	13	173	KFL 1859@Kärl	\N	\N	1	1	-5381	\N	C	2019-12-20 22:13:53.799521+00	4324
5380	-3211	13	173	KFL 1858@Kärl	\N	\N	1	1	-5380	\N	C	2019-12-20 22:13:53.799521+00	4325
5379	-3211	13	173	KFL 1857@Kärl	\N	\N	1	1	-5379	\N	C	2019-12-20 22:13:53.799521+00	4326
5378	-3211	13	173	KFL 1856@Kärl	\N	\N	1	1	-5378	\N	C	2019-12-20 22:13:53.799521+00	4327
5377	-3211	13	173	KFL 1855@Kärl	\N	\N	1	1	-5377	\N	C	2019-12-20 22:13:53.799521+00	4328
5376	-3211	13	173	KFL 1854@Kärl	\N	\N	1	1	-5376	\N	C	2019-12-20 22:13:53.799521+00	4329
5375	-3211	13	173	KFL 1853@Kärl	\N	\N	1	1	-5375	\N	C	2019-12-20 22:13:53.799521+00	4330
5374	-3211	13	173	KFL 1852@Kärl	\N	\N	1	1	-5374	\N	C	2019-12-20 22:13:53.799521+00	4331
5373	-3211	13	173	KFL 1851@Kärl	\N	\N	1	1	-5373	\N	C	2019-12-20 22:13:53.799521+00	4332
5372	-3211	13	173	KFL 1850@Kärl	\N	\N	1	1	-5372	\N	C	2019-12-20 22:13:53.799521+00	4333
5371	-3211	13	173	KFL 1849@Kärl	\N	\N	1	1	-5371	\N	C	2019-12-20 22:13:53.799521+00	4334
5370	-3211	13	173	KFL 1848@Kärl	\N	\N	1	1	-5370	\N	C	2019-12-20 22:13:53.799521+00	4335
5369	-3211	13	173	KFL 1847@Kärl	\N	\N	1	1	-5369	\N	C	2019-12-20 22:13:53.799521+00	4336
5368	-3211	13	173	KFL 1846@Kärl	\N	\N	1	1	-5368	\N	C	2019-12-20 22:13:53.799521+00	4337
5367	-3211	13	173	KFL 1845@Kärl	\N	\N	1	1	-5367	\N	C	2019-12-20 22:13:53.799521+00	4338
5366	-3211	13	173	KFL 1844@Kärl	\N	\N	1	1	-5366	\N	C	2019-12-20 22:13:53.799521+00	4339
5365	-3211	13	173	KFL 1843@Kärl	\N	\N	1	1	-5365	\N	C	2019-12-20 22:13:53.799521+00	4340
5364	-3211	13	173	KFL 1842@Kärl	\N	\N	1	1	-5364	\N	C	2019-12-20 22:13:53.799521+00	4341
5363	-3211	13	173	KFL 1841@Kärl	\N	\N	1	1	-5363	\N	C	2019-12-20 22:13:53.799521+00	4342
5362	-3211	13	173	KFL 1840@Kärl	\N	\N	1	1	-5362	\N	C	2019-12-20 22:13:53.799521+00	4343
5361	-3211	13	173	KFL 1839@Kärl	\N	\N	1	1	-5361	\N	C	2019-12-20 22:13:53.799521+00	4344
5360	-3211	13	173	KFL 1838@Kärl	\N	\N	1	1	-5360	\N	C	2019-12-20 22:13:53.799521+00	4345
5359	-3211	13	173	KFL 1837@Kärl	\N	\N	1	1	-5359	\N	C	2019-12-20 22:13:53.799521+00	4346
5358	-3211	13	173	KFL 1836@Kärl	\N	\N	1	1	-5358	\N	C	2019-12-20 22:13:53.799521+00	4347
5357	-3211	13	173	KFL 1835@Kärl	\N	\N	1	1	-5357	\N	C	2019-12-20 22:13:53.799521+00	4348
5356	-3211	13	173	KFL 1834@Kärl	\N	\N	1	1	-5356	\N	C	2019-12-20 22:13:53.799521+00	4349
5355	-3211	13	173	KFL 1833@Kärl	\N	\N	1	1	-5355	\N	C	2019-12-20 22:13:53.799521+00	4350
5354	-3211	13	173	KFL 1832@Kärl	\N	\N	1	1	-5354	\N	C	2019-12-20 22:13:53.799521+00	4351
5353	-3211	13	173	KFL 1831@Kärl	\N	\N	1	1	-5353	\N	C	2019-12-20 22:13:53.799521+00	4352
5352	-3211	13	173	KFL 1830@Kärl	\N	\N	1	1	-5352	\N	C	2019-12-20 22:13:53.799521+00	4353
5351	-3211	13	173	KFL 1829@Kärl	\N	\N	1	1	-5351	\N	C	2019-12-20 22:13:53.799521+00	4354
5350	-3211	13	173	KFL 1828@Kärl	\N	\N	1	1	-5350	\N	C	2019-12-20 22:13:53.799521+00	4355
5349	-3211	13	173	KFL 1827@Kärl	\N	\N	1	1	-5349	\N	C	2019-12-20 22:13:53.799521+00	4356
5348	-3211	13	173	KFL 1826@Kärl	\N	\N	1	1	-5348	\N	C	2019-12-20 22:13:53.799521+00	4357
5347	-3211	13	173	KFL 1825@Kärl	\N	\N	1	1	-5347	\N	C	2019-12-20 22:13:53.799521+00	4358
5346	-3211	13	173	KFL 1824@Kärl	\N	\N	1	1	-5346	\N	C	2019-12-20 22:13:53.799521+00	4359
5345	-3211	13	173	KFL 1823@Kärl	\N	\N	1	1	-5345	\N	C	2019-12-20 22:13:53.799521+00	4360
5344	-3211	13	173	KFL 1822@Kärl	\N	\N	1	1	-5344	\N	C	2019-12-20 22:13:53.799521+00	4361
5343	-3211	13	173	KFL 1821@Kärl	\N	\N	1	1	-5343	\N	C	2019-12-20 22:13:53.799521+00	4362
5342	-3211	13	173	KFL 1820@Kärl	\N	\N	1	1	-5342	\N	C	2019-12-20 22:13:53.799521+00	4363
5341	-3211	13	173	KFL 1819@Kärl	\N	\N	1	1	-5341	\N	C	2019-12-20 22:13:53.799521+00	4364
5340	-3211	13	173	KFL 1818@Kärl	\N	\N	1	1	-5340	\N	C	2019-12-20 22:13:53.799521+00	4365
5339	-3211	13	173	KFL 1817@Kärl	\N	\N	1	1	-5339	\N	C	2019-12-20 22:13:53.799521+00	4366
5338	-3211	13	173	KFL 1816@Kärl	\N	\N	1	1	-5338	\N	C	2019-12-20 22:13:53.799521+00	4367
5337	-3211	13	173	KFL 1815@Kärl	\N	\N	1	1	-5337	\N	C	2019-12-20 22:13:53.799521+00	4368
5336	-3211	13	173	KFL 1814@Kärl	\N	\N	1	1	-5336	\N	C	2019-12-20 22:13:53.799521+00	4369
5335	-3211	13	173	KFL 1813@Kärl	\N	\N	1	1	-5335	\N	C	2019-12-20 22:13:53.799521+00	4370
5334	-3211	13	173	KFL 1812@Kärl	\N	\N	1	1	-5334	\N	C	2019-12-20 22:13:53.799521+00	4371
5333	-3211	13	173	KFL 1811@Kärl	\N	\N	1	1	-5333	\N	C	2019-12-20 22:13:53.799521+00	4372
5332	-3211	13	173	KFL 1810@Kärl	\N	\N	1	1	-5332	\N	C	2019-12-20 22:13:53.799521+00	4373
5331	-3211	13	173	KFL 1809@Kärl	\N	\N	1	1	-5331	\N	C	2019-12-20 22:13:53.799521+00	4374
5330	-3211	13	173	KFL 1808@Kärl	\N	\N	1	1	-5330	\N	C	2019-12-20 22:13:53.799521+00	4375
5329	-3211	13	173	KFL 1807@Kärl	\N	\N	1	1	-5329	\N	C	2019-12-20 22:13:53.799521+00	4376
5328	-3211	13	173	KFL 1806@Kärl	\N	\N	1	1	-5328	\N	C	2019-12-20 22:13:53.799521+00	4377
5327	-3211	13	173	KFL 1805@Kärl	\N	\N	1	1	-5327	\N	C	2019-12-20 22:13:53.799521+00	4378
5326	-3211	13	173	KFL 1804@Kärl	\N	\N	1	1	-5326	\N	C	2019-12-20 22:13:53.799521+00	4379
5325	-3211	13	173	KFL 1803@Kärl	\N	\N	1	1	-5325	\N	C	2019-12-20 22:13:53.799521+00	4380
5324	-3211	13	173	KFL 1802@Kärl	\N	\N	1	1	-5324	\N	C	2019-12-20 22:13:53.799521+00	4381
5323	-3211	13	173	KFL 1801@Kärl	\N	\N	1	1	-5323	\N	C	2019-12-20 22:13:53.799521+00	4382
5322	-3211	13	173	KFL 1800@Kärl	\N	\N	1	1	-5322	\N	C	2019-12-20 22:13:53.799521+00	4383
5321	-3211	13	173	KFL 1799@Kärl	\N	\N	1	1	-5321	\N	C	2019-12-20 22:13:53.799521+00	4384
5320	-3211	13	173	KFL 1798@Kärl	\N	\N	1	1	-5320	\N	C	2019-12-20 22:13:53.799521+00	4385
5319	-3211	13	173	KFL 1797@Kärl	\N	\N	1	1	-5319	\N	C	2019-12-20 22:13:53.799521+00	4386
5318	-3211	13	173	KFL 1796@Kärl	\N	\N	1	1	-5318	\N	C	2019-12-20 22:13:53.799521+00	4387
5317	-3211	13	173	KFL 1795@Kärl	\N	\N	1	1	-5317	\N	C	2019-12-20 22:13:53.799521+00	4388
5316	-3211	13	173	KFL 1794@Kärl	\N	\N	1	1	-5316	\N	C	2019-12-20 22:13:53.799521+00	4389
5315	-3211	13	173	KFL 1793@Kärl	\N	\N	1	1	-5315	\N	C	2019-12-20 22:13:53.799521+00	4390
5314	-3211	13	173	KFL 1792@Kärl	\N	\N	1	1	-5314	\N	C	2019-12-20 22:13:53.799521+00	4391
5313	-3211	13	173	KFL 1791@Kärl	\N	\N	1	1	-5313	\N	C	2019-12-20 22:13:53.799521+00	4392
5312	-3211	13	173	KFL 1790@Kärl	\N	\N	1	1	-5312	\N	C	2019-12-20 22:13:53.799521+00	4393
5311	-3211	13	173	KFL 1789@Kärl	\N	\N	1	1	-5311	\N	C	2019-12-20 22:13:53.799521+00	4394
5310	-3211	13	173	KFL 1788@Kärl	\N	\N	1	1	-5310	\N	C	2019-12-20 22:13:53.799521+00	4395
5309	-3211	13	173	KFL 1787@Kärl	\N	\N	1	1	-5309	\N	C	2019-12-20 22:13:53.799521+00	4396
5308	-3211	13	173	KFL 1786@Kärl	\N	\N	1	1	-5308	\N	C	2019-12-20 22:13:53.799521+00	4397
5307	-3211	13	173	KFL 1785@Kärl	\N	\N	1	1	-5307	\N	C	2019-12-20 22:13:53.799521+00	4398
5306	-3211	13	173	KFL 1784@Kärl	\N	\N	1	1	-5306	\N	C	2019-12-20 22:13:53.799521+00	4399
5305	-3211	13	173	KFL 1783@Kärl	\N	\N	1	1	-5305	\N	C	2019-12-20 22:13:53.799521+00	4400
5304	-3211	13	173	KFL 1782@Kärl	\N	\N	1	1	-5304	\N	C	2019-12-20 22:13:53.799521+00	4401
5303	-3211	13	173	KFL 1781@Kärl	\N	\N	1	1	-5303	\N	C	2019-12-20 22:13:53.799521+00	4402
5302	-3211	13	173	KFL 1780@Kärl	\N	\N	1	1	-5302	\N	C	2019-12-20 22:13:53.799521+00	4403
5301	-3211	13	173	KFL 1779@Kärl	\N	\N	1	1	-5301	\N	C	2019-12-20 22:13:53.799521+00	4404
5300	-3211	13	173	KFL 1778@Kärl	\N	\N	1	1	-5300	\N	C	2019-12-20 22:13:53.799521+00	4405
5299	-3211	13	173	KFL 1777@Kärl	\N	\N	1	1	-5299	\N	C	2019-12-20 22:13:53.799521+00	4406
5298	-3211	13	173	KFL 1776@Kärl	\N	\N	1	1	-5298	\N	C	2019-12-20 22:13:53.799521+00	4407
5297	-3211	13	173	KFL 1775@Kärl	\N	\N	1	1	-5297	\N	C	2019-12-20 22:13:53.799521+00	4408
5296	-3211	13	173	KFL 1774@Kärl	\N	\N	1	1	-5296	\N	C	2019-12-20 22:13:53.799521+00	4409
5295	-3211	13	173	KFL 1773@Kärl	\N	\N	1	1	-5295	\N	C	2019-12-20 22:13:53.799521+00	4410
5294	-3211	13	173	KFL 1772@Kärl	\N	\N	1	1	-5294	\N	C	2019-12-20 22:13:53.799521+00	4411
5293	-3211	13	173	KFL 1771@Kärl	\N	\N	1	1	-5293	\N	C	2019-12-20 22:13:53.799521+00	4412
5292	-3211	13	173	KFL 1770@Kärl	\N	\N	1	1	-5292	\N	C	2019-12-20 22:13:53.799521+00	4413
5291	-3211	13	173	KFL 1769@Kärl	\N	\N	1	1	-5291	\N	C	2019-12-20 22:13:53.799521+00	4414
5290	-3211	13	173	KFL 1768@Kärl	\N	\N	1	1	-5290	\N	C	2019-12-20 22:13:53.799521+00	4415
5289	-3211	13	173	KFL 1767@Kärl	\N	\N	1	1	-5289	\N	C	2019-12-20 22:13:53.799521+00	4416
5288	-3211	13	173	KFL 1766@Kärl	\N	\N	1	1	-5288	\N	C	2019-12-20 22:13:53.799521+00	4417
5287	-3211	13	173	KFL 1765@Kärl	\N	\N	1	1	-5287	\N	C	2019-12-20 22:13:53.799521+00	4418
5286	-3211	13	173	KFL 1764@Kärl	\N	\N	1	1	-5286	\N	C	2019-12-20 22:13:53.799521+00	4419
5285	-3211	13	173	KFL 1763@Kärl	\N	\N	1	1	-5285	\N	C	2019-12-20 22:13:53.799521+00	4420
5284	-3211	13	173	KFL 1762@Kärl	\N	\N	1	1	-5284	\N	C	2019-12-20 22:13:53.799521+00	4421
5283	-3211	13	173	KFL 1761@Kärl	\N	\N	1	1	-5283	\N	C	2019-12-20 22:13:53.799521+00	4422
5282	-3211	13	173	KFL 1760@Kärl	\N	\N	1	1	-5282	\N	C	2019-12-20 22:13:53.799521+00	4423
5281	-3211	13	173	KFL 1759@Kärl	\N	\N	1	1	-5281	\N	C	2019-12-20 22:13:53.799521+00	4424
5280	-3211	13	173	KFL 1758@Kärl	\N	\N	1	1	-5280	\N	C	2019-12-20 22:13:53.799521+00	4425
5279	-3211	13	173	KFL 1757@Kärl	\N	\N	1	1	-5279	\N	C	2019-12-20 22:13:53.799521+00	4426
5278	-3211	13	173	KFL 1756@Kärl	\N	\N	1	1	-5278	\N	C	2019-12-20 22:13:53.799521+00	4427
5277	-3281	13	173	KFL 1755@Jordprov	\N	\N	1	1	-5277	\N	C	2019-12-20 22:13:53.799521+00	4428
5276	-3281	13	173	KFL 1754@Kärl	\N	\N	1	1	-5276	\N	C	2019-12-20 22:13:53.799521+00	4429
5275	-3281	13	173	KFL 1753@Kärl	\N	\N	1	1	-5275	\N	C	2019-12-20 22:13:53.799521+00	4430
5274	-3281	13	173	KFL 1752@Kärl	\N	\N	1	1	-5274	\N	C	2019-12-20 22:13:53.799521+00	4431
5273	-3281	13	173	KFL 1751@Kärl	\N	\N	1	1	-5273	\N	C	2019-12-20 22:13:53.799521+00	4432
5272	-3281	13	173	KFL 1750@Kärl	\N	\N	1	1	-5272	\N	C	2019-12-20 22:13:53.799521+00	4433
5271	-3281	13	173	KFL 1749@Kärl	\N	\N	1	1	-5271	\N	C	2019-12-20 22:13:53.799521+00	4434
5270	-1053	13	173	KFL 1748@Kärl	\N	\N	1	1	-5270	\N	C	2019-12-20 22:13:53.799521+00	4435
5269	-1053	13	173	KFL 1747@Kärl	\N	\N	1	1	-5269	\N	C	2019-12-20 22:13:53.799521+00	4436
5268	-1053	13	173	KFL 1746@Kärl	\N	\N	1	1	-5268	\N	C	2019-12-20 22:13:53.799521+00	4437
5267	-1053	13	173	KFL 1745@Degel	\N	\N	1	1	-5267	\N	C	2019-12-20 22:13:53.799521+00	4438
5266	-1053	13	173	KFL 1744@Jordprov	\N	\N	1	1	-5266	\N	C	2019-12-20 22:13:53.799521+00	4439
5265	-1053	13	173	KFL 1743@Jordprov	\N	\N	1	1	-5265	\N	C	2019-12-20 22:13:53.799521+00	4440
5264	-1053	13	173	KFL 1742@Jordprov	\N	\N	1	1	-5264	\N	C	2019-12-20 22:13:53.799521+00	4441
5263	-1053	13	173	KFL 1741@Kärl	\N	\N	1	1	-5263	\N	C	2019-12-20 22:13:53.799521+00	4442
5262	-1053	13	173	KFL 1740@Kärl	\N	\N	1	1	-5262	\N	C	2019-12-20 22:13:53.799521+00	4443
5261	-1053	13	173	KFL 1739@Kärl	\N	\N	1	1	-5261	\N	C	2019-12-20 22:13:53.799521+00	4444
5260	-3219	13	173	KFL 1726@Kärl	\N	\N	1	1	-5260	\N	C	2019-12-20 22:13:53.799521+00	4445
5259	-2985	13	173	KFL 1725@Jordprov	\N	\N	1	1	-5259	\N	C	2019-12-20 22:13:53.799521+00	4446
5258	-2985	13	173	KFL 1724@Kärl	\N	\N	1	1	-5258	\N	C	2019-12-20 22:13:53.799521+00	4447
5257	-2985	13	173	KFL 1723@Lerklining	\N	\N	1	1	-5257	\N	C	2019-12-20 22:13:53.799521+00	4448
5256	-2985	13	173	KFL 1722@Kärl	\N	\N	1	1	-5256	\N	C	2019-12-20 22:13:53.799521+00	4449
5255	-2985	13	173	KFL 1721@Kärl	\N	\N	1	1	-5255	\N	C	2019-12-20 22:13:53.799521+00	4450
5254	-2985	13	173	KFL 1720@Kärl	\N	\N	1	1	-5254	\N	C	2019-12-20 22:13:53.799521+00	4451
5253	-2985	13	173	KFL 1719@Kärl	\N	\N	1	1	-5253	\N	C	2019-12-20 22:13:53.799521+00	4452
5252	-2985	13	173	KFL 1718@Kärl	\N	\N	1	1	-5252	\N	C	2019-12-20 22:13:53.799521+00	4453
5251	-2985	13	173	KFL 1717@Kärl	\N	\N	1	1	-5251	\N	C	2019-12-20 22:13:53.799521+00	4454
5250	-2985	13	173	KFL 1716@Kärl	\N	\N	1	1	-5250	\N	C	2019-12-20 22:13:53.799521+00	4455
5249	-2985	13	173	KFL 1715@Kärl	\N	\N	1	1	-5249	\N	C	2019-12-20 22:13:53.799521+00	4456
5248	-2985	13	173	KFL 1714@Kärl	\N	\N	1	1	-5248	\N	C	2019-12-20 22:13:53.799521+00	4457
5247	-2985	13	173	KFL 1713@Kärl	\N	\N	1	1	-5247	\N	C	2019-12-20 22:13:53.799521+00	4458
5246	-2985	13	173	KFL 1712@Kärl	\N	\N	1	1	-5246	\N	C	2019-12-20 22:13:53.799521+00	4459
5245	-2985	13	173	KFL 1711@Kärl	\N	\N	1	1	-5245	\N	C	2019-12-20 22:13:53.799521+00	4460
5244	-2985	13	173	KFL 1710@Kärl	\N	\N	1	1	-5244	\N	C	2019-12-20 22:13:53.799521+00	4461
5243	-2985	13	173	KFL 1709@Kärl	\N	\N	1	1	-5243	\N	C	2019-12-20 22:13:53.799521+00	4462
5242	-2985	13	173	KFL 1708@Kärl	\N	\N	1	1	-5242	\N	C	2019-12-20 22:13:53.799521+00	4463
5241	-2985	13	173	KFL 1707@Kärl	\N	\N	1	1	-5241	\N	C	2019-12-20 22:13:53.799521+00	4464
5240	-2985	13	173	KFL 1706@Kärl	\N	\N	1	1	-5240	\N	C	2019-12-20 22:13:53.799521+00	4465
5239	-2985	13	173	KFL 1705@Kärl	\N	\N	1	1	-5239	\N	C	2019-12-20 22:13:53.799521+00	4466
5238	-2985	13	173	KFL 1704@Kärl	\N	\N	1	1	-5238	\N	C	2019-12-20 22:13:53.799521+00	4467
5237	-2985	13	173	KFL 1703@Kärl	\N	\N	1	1	-5237	\N	C	2019-12-20 22:13:53.799521+00	4468
5236	-2985	13	173	KFL 1702@Kärl	\N	\N	1	1	-5236	\N	C	2019-12-20 22:13:53.799521+00	4469
5235	-2985	13	173	KFL 1701@Kärl	\N	\N	1	1	-5235	\N	C	2019-12-20 22:13:53.799521+00	4470
5234	-2985	13	173	KFL 1700@Kärl	\N	\N	1	1	-5234	\N	C	2019-12-20 22:13:53.799521+00	4471
5233	-2985	13	173	KFL 1699@Kärl	\N	\N	1	1	-5233	\N	C	2019-12-20 22:13:53.799521+00	4472
5232	-2985	13	173	KFL 1698@Kärl	\N	\N	1	1	-5232	\N	C	2019-12-20 22:13:53.799521+00	4473
5231	-2985	13	173	KFL 1697@Kärl	\N	\N	1	1	-5231	\N	C	2019-12-20 22:13:53.799521+00	4474
5230	-2985	13	173	KFL 1696@Kärl	\N	\N	1	1	-5230	\N	C	2019-12-20 22:13:53.799521+00	4475
5229	-2985	13	173	KFL 1695@Kärl	\N	\N	1	1	-5229	\N	C	2019-12-20 22:13:53.799521+00	4476
5228	-2985	13	173	KFL 1694@Kärl	\N	\N	1	1	-5228	\N	C	2019-12-20 22:13:53.799521+00	4477
5227	-2985	13	173	KFL 1693@Kärl	\N	\N	1	1	-5227	\N	C	2019-12-20 22:13:53.799521+00	4478
5226	-2985	13	173	KFL 1692@Kärl	\N	\N	1	1	-5226	\N	C	2019-12-20 22:13:53.799521+00	4479
5225	-2985	13	173	KFL 1691@Kärl	\N	\N	1	1	-5225	\N	C	2019-12-20 22:13:53.799521+00	4480
5224	-2985	13	173	KFL 1690@Kärl	\N	\N	1	1	-5224	\N	C	2019-12-20 22:13:53.799521+00	4481
5223	-2985	13	173	KFL 1689@Kärl	\N	\N	1	1	-5223	\N	C	2019-12-20 22:13:53.799521+00	4482
5222	-3338	13	173	KFL 1658@Lerklining	\N	\N	1	1	-5222	\N	C	2019-12-20 22:13:53.799521+00	4483
5221	-3338	13	173	KFL 1657@Kärl	\N	\N	1	1	-5221	\N	C	2019-12-20 22:13:53.799521+00	4484
5220	-3338	13	173	KFL 1656@Kärl	\N	\N	1	1	-5220	\N	C	2019-12-20 22:13:53.799521+00	4485
5219	-3338	13	173	KFL 1655@Kärl	\N	\N	1	1	-5219	\N	C	2019-12-20 22:13:53.799521+00	4486
5218	-3338	13	173	KFL 1654@Kärl	\N	\N	1	1	-5218	\N	C	2019-12-20 22:13:53.799521+00	4487
5217	-3338	13	173	KFL 1653@Kärl	\N	\N	1	1	-5217	\N	C	2019-12-20 22:13:53.799521+00	4488
5216	-3252	13	173	KFL 1613@Kärl	\N	\N	1	1	-5216	\N	C	2019-12-20 22:13:53.799521+00	4489
5215	-3252	13	173	KFL 1612@Kärl	\N	\N	1	1	-5215	\N	C	2019-12-20 22:13:53.799521+00	4490
5214	-3252	13	173	KFL 1611@Kärl	\N	\N	1	1	-5214	\N	C	2019-12-20 22:13:53.799521+00	4491
5213	-3252	13	173	KFL 1610@Kärl	\N	\N	1	1	-5213	\N	C	2019-12-20 22:13:53.799521+00	4492
5212	-3252	13	173	KFL 1609@Kärl	\N	\N	1	1	-5212	\N	C	2019-12-20 22:13:53.799521+00	4493
5211	-3299	13	173	KFL 1608@Kärl	\N	\N	1	1	-5211	\N	C	2019-12-20 22:13:53.799521+00	4494
5210	-3217	13	173	KFL 1607@Kärl	\N	\N	1	1	-5210	\N	C	2019-12-20 22:13:53.799521+00	4495
5209	-3217	13	173	KFL 1606@Kärl	\N	\N	1	1	-5209	\N	C	2019-12-20 22:13:53.799521+00	4496
5208	-3217	13	173	KFL 1605@Kärl	\N	\N	1	1	-5208	\N	C	2019-12-20 22:13:53.799521+00	4497
5207	-3217	13	173	KFL 1604@Kärl	\N	\N	1	1	-5207	\N	C	2019-12-20 22:13:53.799521+00	4498
5206	-3217	13	173	KFL 1603@Kärl	\N	\N	1	1	-5206	\N	C	2019-12-20 22:13:53.799521+00	4499
5205	-3217	13	173	KFL 1602@Jordprov	\N	\N	1	1	-5205	\N	C	2019-12-20 22:13:53.799521+00	4500
5204	-3217	13	173	KFL 1601@Jordprov	\N	\N	1	1	-5204	\N	C	2019-12-20 22:13:53.799521+00	4501
5203	-3217	13	173	KFL 1600@Kärl	\N	\N	1	1	-5203	\N	C	2019-12-20 22:13:53.799521+00	4502
5202	-3217	13	173	KFL 1599@Lerklining	\N	\N	1	1	-5202	\N	C	2019-12-20 22:13:53.799521+00	4503
5201	-3217	13	173	KFL 1598@Kärl	\N	\N	1	1	-5201	\N	C	2019-12-20 22:13:53.799521+00	4504
5200	-3217	13	173	KFL 1597@Kärl	\N	\N	1	1	-5200	\N	C	2019-12-20 22:13:53.799521+00	4505
5199	-3217	13	173	KFL 1596@Lerklining	\N	\N	1	1	-5199	\N	C	2019-12-20 22:13:53.799521+00	4506
5198	-3217	13	173	KFL 1595@Kärl	\N	\N	1	1	-5198	\N	C	2019-12-20 22:13:53.799521+00	4507
5197	-3217	13	173	KFL 1594@Kärl	\N	\N	1	1	-5197	\N	C	2019-12-20 22:13:53.799521+00	4508
5196	-3217	13	173	KFL 1593@Kärl	\N	\N	1	1	-5196	\N	C	2019-12-20 22:13:53.799521+00	4509
5195	-3217	13	173	KFL 1592@Kärl	\N	\N	1	1	-5195	\N	C	2019-12-20 22:13:53.799521+00	4510
5194	-3217	13	173	KFL 1591@Kärl	\N	\N	1	1	-5194	\N	C	2019-12-20 22:13:53.799521+00	4511
5193	-3217	13	173	KFL 1590@Kärl	\N	\N	1	1	-5193	\N	C	2019-12-20 22:13:53.799521+00	4512
5192	-3217	13	173	KFL 1589@Kärl	\N	\N	1	1	-5192	\N	C	2019-12-20 22:13:53.799521+00	4513
5191	-3217	13	173	KFL 1588@Kärl	\N	\N	1	1	-5191	\N	C	2019-12-20 22:13:53.799521+00	4514
5190	-3217	13	173	KFL 1587@Kärl	\N	\N	1	1	-5190	\N	C	2019-12-20 22:13:53.799521+00	4515
5189	-3217	13	173	KFL 1586@Kärl	\N	\N	1	1	-5189	\N	C	2019-12-20 22:13:53.799521+00	4516
5188	-3217	13	173	KFL 1585@Kärl	\N	\N	1	1	-5188	\N	C	2019-12-20 22:13:53.799521+00	4517
5187	-3217	13	173	KFL 1584@Kärl	\N	\N	1	1	-5187	\N	C	2019-12-20 22:13:53.799521+00	4518
5186	-3013	13	173	KFL 1583@odef	\N	\N	1	1	-5186	\N	C	2019-12-20 22:13:53.799521+00	4519
5185	-3013	13	173	KFL 1582@odef	\N	\N	1	1	-5185	\N	C	2019-12-20 22:13:53.799521+00	4520
5184	-3013	13	173	KFL 1581@Kärl	\N	\N	1	1	-5184	\N	C	2019-12-20 22:13:53.799521+00	4521
5183	-3013	13	173	KFL 1580@Kärl	\N	\N	1	1	-5183	\N	C	2019-12-20 22:13:53.799521+00	4522
5182	-3013	13	173	KFL 1579@Kärl	\N	\N	1	1	-5182	\N	C	2019-12-20 22:13:53.799521+00	4523
5181	-3013	13	173	KFL 1578@Gjutform	\N	\N	1	1	-5181	\N	C	2019-12-20 22:13:53.799521+00	4524
5180	-3013	13	173	KFL 1577@Kärl	\N	\N	1	1	-5180	\N	C	2019-12-20 22:13:53.799521+00	4525
5179	-3250	13	173	KFL 1576@Jordprov	\N	\N	1	1	-5179	\N	C	2019-12-20 22:13:53.799521+00	4526
5178	-3250	13	173	KFL 1575@Lerskiva	\N	\N	1	1	-5178	\N	C	2019-12-20 22:13:53.799521+00	4527
5177	-3250	13	173	KFL 1574@Kärl	\N	\N	1	1	-5177	\N	C	2019-12-20 22:13:53.799521+00	4528
5176	-3250	13	173	KFL 1573@Kärl	\N	\N	1	1	-5176	\N	C	2019-12-20 22:13:53.799521+00	4529
5175	-3250	13	173	KFL 1572@Kärl	\N	\N	1	1	-5175	\N	C	2019-12-20 22:13:53.799521+00	4530
5174	-3250	13	173	KFL 1571@Kärl	\N	\N	1	1	-5174	\N	C	2019-12-20 22:13:53.799521+00	4531
5173	-3250	13	173	KFL 1570@Kärl	\N	\N	1	1	-5173	\N	C	2019-12-20 22:13:53.799521+00	4532
5172	-3250	13	173	KFL 1569@Kärl	\N	\N	1	1	-5172	\N	C	2019-12-20 22:13:53.799521+00	4533
5171	-3250	13	173	KFL 1568@Kärl	\N	\N	1	1	-5171	\N	C	2019-12-20 22:13:53.799521+00	4534
5170	-3250	13	173	KFL 1567@Kärl	\N	\N	1	1	-5170	\N	C	2019-12-20 22:13:53.799521+00	4535
5169	-3012	13	173	KFL 1566@Jordprov	\N	\N	1	1	-5169	\N	C	2019-12-20 22:13:53.799521+00	4536
5168	-3012	13	173	KFL 1565@Jordprov	\N	\N	1	1	-5168	\N	C	2019-12-20 22:13:53.799521+00	4537
5167	-3012	13	173	KFL 1564@Kärl	\N	\N	1	1	-5167	\N	C	2019-12-20 22:13:53.799521+00	4538
5166	-3012	13	173	KFL 1563@Kärl	\N	\N	1	1	-5166	\N	C	2019-12-20 22:13:53.799521+00	4539
5165	-3012	13	173	KFL 1562@Kärl	\N	\N	1	1	-5165	\N	C	2019-12-20 22:13:53.799521+00	4540
5164	-3012	13	173	KFL 1561@Kärl	\N	\N	1	1	-5164	\N	C	2019-12-20 22:13:53.799521+00	4541
5163	-3012	13	173	KFL 1560@Kärl	\N	\N	1	1	-5163	\N	C	2019-12-20 22:13:53.799521+00	4542
5162	-3012	13	173	KFL 1559@Kärl	\N	\N	1	1	-5162	\N	C	2019-12-20 22:13:53.799521+00	4543
5161	-3012	13	173	KFL 1558@Kärl	\N	\N	1	1	-5161	\N	C	2019-12-20 22:13:53.799521+00	4544
5160	-3012	13	173	KFL 1557@Kärl	\N	\N	1	1	-5160	\N	C	2019-12-20 22:13:53.799521+00	4545
5159	-3012	13	173	KFL 1556@Kärl	\N	\N	1	1	-5159	\N	C	2019-12-20 22:13:53.799521+00	4546
5158	-3012	13	173	KFL 1555@Kärl	\N	\N	1	1	-5158	\N	C	2019-12-20 22:13:53.799521+00	4547
5157	-3012	13	173	KFL 1554@Kärl	\N	\N	1	1	-5157	\N	C	2019-12-20 22:13:53.799521+00	4548
5156	-3012	13	173	KFL 1553@Kärl	\N	\N	1	1	-5156	\N	C	2019-12-20 22:13:53.799521+00	4549
5155	-3012	13	173	KFL 1552@Kärl	\N	\N	1	1	-5155	\N	C	2019-12-20 22:13:53.799521+00	4550
5154	-3012	13	173	KFL 1551@Kärl	\N	\N	1	1	-5154	\N	C	2019-12-20 22:13:53.799521+00	4551
5153	-3012	13	173	KFL 1550@Kärl	\N	\N	1	1	-5153	\N	C	2019-12-20 22:13:53.799521+00	4552
5152	-3012	13	173	KFL 1549@Kärl	\N	\N	1	1	-5152	\N	C	2019-12-20 22:13:53.799521+00	4553
5151	-3012	13	173	KFL 1548@Kärl	\N	\N	1	1	-5151	\N	C	2019-12-20 22:13:53.799521+00	4554
5150	-3012	13	173	KFL 1547@Kärl	\N	\N	1	1	-5150	\N	C	2019-12-20 22:13:53.799521+00	4555
5149	-3012	13	173	KFL 1546@Kärl	\N	\N	1	1	-5149	\N	C	2019-12-20 22:13:53.799521+00	4556
5148	-3012	13	173	KFL 1545@Kärl	\N	\N	1	1	-5148	\N	C	2019-12-20 22:13:53.799521+00	4557
5147	-3012	13	173	KFL 1544@Kärl	\N	\N	1	1	-5147	\N	C	2019-12-20 22:13:53.799521+00	4558
5146	-3012	13	173	KFL 1543@Kärl	\N	\N	1	1	-5146	\N	C	2019-12-20 22:13:53.799521+00	4559
5145	-3012	13	173	KFL 1542@Kärl	\N	\N	1	1	-5145	\N	C	2019-12-20 22:13:53.799521+00	4560
5144	-3012	13	173	KFL 1541@Kärl	\N	\N	1	1	-5144	\N	C	2019-12-20 22:13:53.799521+00	4561
5143	-3012	13	173	KFL 1540@Kärl	\N	\N	1	1	-5143	\N	C	2019-12-20 22:13:53.799521+00	4562
5142	-3012	13	173	KFL 1539@Kärl	\N	\N	1	1	-5142	\N	C	2019-12-20 22:13:53.799521+00	4563
5141	-3012	13	173	KFL 1538@Kärl	\N	\N	1	1	-5141	\N	C	2019-12-20 22:13:53.799521+00	4564
5140	-3012	13	173	KFL 1537@Kärl	\N	\N	1	1	-5140	\N	C	2019-12-20 22:13:53.799521+00	4565
5139	-3012	13	173	KFL 1536@Kärl	\N	\N	1	1	-5139	\N	C	2019-12-20 22:13:53.799521+00	4566
5138	-3012	13	173	KFL 1535@Kärl	\N	\N	1	1	-5138	\N	C	2019-12-20 22:13:53.799521+00	4567
5137	-3012	13	173	KFL 1534@Kärl	\N	\N	1	1	-5137	\N	C	2019-12-20 22:13:53.799521+00	4568
5136	-3012	13	173	KFL 1533@Kärl	\N	\N	1	1	-5136	\N	C	2019-12-20 22:13:53.799521+00	4569
5135	-3012	13	173	KFL 1532@Kärl	\N	\N	1	1	-5135	\N	C	2019-12-20 22:13:53.799521+00	4570
5134	-3012	13	173	KFL 1531@Kärl	\N	\N	1	1	-5134	\N	C	2019-12-20 22:13:53.799521+00	4571
5133	-3012	13	173	KFL 1530@Kärl	\N	\N	1	1	-5133	\N	C	2019-12-20 22:13:53.799521+00	4572
5132	-3012	13	173	KFL 1529@Kärl	\N	\N	1	1	-5132	\N	C	2019-12-20 22:13:53.799521+00	4573
5131	-3217	13	173	KFL 1526@Sländtrissa &amp; vävtyngd	\N	\N	1	1	-5131	\N	C	2019-12-20 22:13:53.799521+00	4574
5130	-3217	13	173	KFL 1525@Sländtrissa &amp; vävtyngd	\N	\N	1	1	-5130	\N	C	2019-12-20 22:13:53.799521+00	4575
5129	-3217	13	173	KFL 1524@Sländtrissa &amp; vävtyngd	\N	\N	1	1	-5129	\N	C	2019-12-20 22:13:53.799521+00	4576
5128	-3217	13	173	KFL 1523@Sländtrissa &amp; vävtyngd	\N	\N	1	1	-5128	\N	C	2019-12-20 22:13:53.799521+00	4577
5127	-3217	13	173	KFL 1522@Kärl	\N	\N	1	1	-5127	\N	C	2019-12-20 22:13:53.799521+00	4578
5126	-3217	13	173	KFL 1521@Kärl	\N	\N	1	1	-5126	\N	C	2019-12-20 22:13:53.799521+00	4579
5125	-3217	13	173	KFL 1520@Kärl	\N	\N	1	1	-5125	\N	C	2019-12-20 22:13:53.799521+00	4580
5124	-3217	13	173	KFL 1519@Kärl	\N	\N	1	1	-5124	\N	C	2019-12-20 22:13:53.799521+00	4581
5123	-3217	13	173	KFL 1518@Kärl	\N	\N	1	1	-5123	\N	C	2019-12-20 22:13:53.799521+00	4582
5122	-3217	13	173	KFL 1517@Kärl	\N	\N	1	1	-5122	\N	C	2019-12-20 22:13:53.799521+00	4583
5121	-3217	13	173	KFL 1516@Kärl	\N	\N	1	1	-5121	\N	C	2019-12-20 22:13:53.799521+00	4584
5120	-3217	13	173	KFL 1515@Kärl	\N	\N	1	1	-5120	\N	C	2019-12-20 22:13:53.799521+00	4585
5119	-3217	13	173	KFL 1514@Kärl	\N	\N	1	1	-5119	\N	C	2019-12-20 22:13:53.799521+00	4586
5118	-3217	13	173	KFL 1513@Kärl	\N	\N	1	1	-5118	\N	C	2019-12-20 22:13:53.799521+00	4587
5117	-3217	13	173	KFL 1512@Kärl	\N	\N	1	1	-5117	\N	C	2019-12-20 22:13:53.799521+00	4588
5116	-3155	13	173	KFL 1511@Kärl	\N	\N	1	1	-5116	\N	C	2019-12-20 22:13:53.799521+00	4589
5115	-3147	13	173	KFL 1469@Lerklining	\N	\N	1	1	-5115	\N	C	2019-12-20 22:13:53.799521+00	4590
5114	-3147	13	173	KFL 1468@Lerklining	\N	\N	1	1	-5114	\N	C	2019-12-20 22:13:53.799521+00	4591
5113	-3147	13	173	KFL 1467@Lerklining	\N	\N	1	1	-5113	\N	C	2019-12-20 22:13:53.799521+00	4592
5112	-3097	13	173	KFL 1466@Lerklining	\N	\N	1	1	-5112	\N	C	2019-12-20 22:13:53.799521+00	4593
5111	-3097	13	173	KFL 1465@Lerklining	\N	\N	1	1	-5111	\N	C	2019-12-20 22:13:53.799521+00	4594
5110	-3097	13	173	KFL 1464@Lerklining	\N	\N	1	1	-5110	\N	C	2019-12-20 22:13:53.799521+00	4595
5109	-2993	13	173	KFL 1463@Lerklining	\N	\N	1	1	-5109	\N	C	2019-12-20 22:13:53.799521+00	4596
5108	-2993	13	173	KFL 1462@Lerklining	\N	\N	1	1	-5108	\N	C	2019-12-20 22:13:53.799521+00	4597
5107	-2993	13	173	KFL 1461@Lerklining	\N	\N	1	1	-5107	\N	C	2019-12-20 22:13:53.799521+00	4598
5106	-3091	13	173	KFL 1460@Kärl	\N	\N	1	1	-5106	\N	C	2019-12-20 22:13:53.799521+00	4599
5105	-3325	13	173	KFL 1455@Kärl	\N	\N	1	1	-5105	\N	C	2019-12-20 22:13:53.799521+00	4600
5104	-2996	13	173	KFL 1454@Kärl	\N	\N	1	1	-5104	\N	C	2019-12-20 22:13:53.799521+00	4601
5103	-2996	13	173	KFL 1453@Kärl	\N	\N	1	1	-5103	\N	C	2019-12-20 22:13:53.799521+00	4602
5102	-3274	13	173	KFL 1439@Jordprov	\N	\N	1	1	-5102	\N	C	2019-12-20 22:13:53.799521+00	4603
5101	-3274	13	173	KFL 1438@Jordprov	\N	\N	1	1	-5101	\N	C	2019-12-20 22:13:53.799521+00	4604
5100	-3009	13	173	KFL 1437@Jordprov	\N	\N	1	1	-5100	\N	C	2019-12-20 22:13:53.799521+00	4605
5099	-3009	13	173	KFL 1436@Jordprov	\N	\N	1	1	-5099	\N	C	2019-12-20 22:13:53.799521+00	4606
5098	-3113	13	173	KFL 1435@Jordprov	\N	\N	1	1	-5098	\N	C	2019-12-20 22:13:53.799521+00	4607
5097	-3204	13	173	KFL 1434@Lerklining	\N	\N	1	1	-5097	\N	C	2019-12-20 22:13:53.799521+00	4608
5096	-3126	13	173	KFL 1433@Lerklining	\N	\N	1	1	-5096	\N	C	2019-12-20 22:13:53.799521+00	4609
5095	-3216	13	173	KFL 1432@Lerklining	\N	\N	1	1	-5095	\N	C	2019-12-20 22:13:53.799521+00	4610
5094	-3274	13	173	KFL 1431@Kärl	\N	\N	1	1	-5094	\N	C	2019-12-20 22:13:53.799521+00	4611
5093	-3274	13	173	KFL 1430@Kärl	\N	\N	1	1	-5093	\N	C	2019-12-20 22:13:53.799521+00	4612
5092	-3274	13	173	KFL 1429@Kärl	\N	\N	1	1	-5092	\N	C	2019-12-20 22:13:53.799521+00	4613
5091	-3009	13	173	KFL 1428@Kärl	\N	\N	1	1	-5091	\N	C	2019-12-20 22:13:53.799521+00	4614
5090	-3009	13	173	KFL 1427@Kärl	\N	\N	1	1	-5090	\N	C	2019-12-20 22:13:53.799521+00	4615
5089	-3009	13	173	KFL 1426@Kärl	\N	\N	1	1	-5089	\N	C	2019-12-20 22:13:53.799521+00	4616
5088	-3009	13	173	KFL 1425@Kärl	\N	\N	1	1	-5088	\N	C	2019-12-20 22:13:53.799521+00	4617
5087	-3113	13	173	KFL 1424@Kärl	\N	\N	1	1	-5087	\N	C	2019-12-20 22:13:53.799521+00	4618
5086	-3113	13	173	KFL 1423@Lerklining	\N	\N	1	1	-5086	\N	C	2019-12-20 22:13:53.799521+00	4619
5085	-3113	13	173	KFL 1422@Lerklining	\N	\N	1	1	-5085	\N	C	2019-12-20 22:13:53.799521+00	4620
5084	-3113	13	173	KFL 1421@Lerklining	\N	\N	1	1	-5084	\N	C	2019-12-20 22:13:53.799521+00	4621
5083	-3326	13	173	KFL 1418@Kärl	\N	\N	1	1	-5083	\N	C	2019-12-20 22:13:53.799521+00	4622
5082	-3326	13	173	KFL 1417@Kärl	\N	\N	1	1	-5082	\N	C	2019-12-20 22:13:53.799521+00	4623
5081	-3326	13	173	KFL 1416@Kärl	\N	\N	1	1	-5081	\N	C	2019-12-20 22:13:53.799521+00	4624
5080	-3264	13	173	KFL 1413@Kärl	\N	\N	1	1	-5080	\N	C	2019-12-20 22:13:53.799521+00	4625
5079	-3264	13	173	KFL 1412@Kärl	\N	\N	1	1	-5079	\N	C	2019-12-20 22:13:53.799521+00	4626
5078	-3264	13	173	KFL 1411@Kärl	\N	\N	1	1	-5078	\N	C	2019-12-20 22:13:53.799521+00	4627
5077	-3264	13	173	KFL 1410@Kärl	\N	\N	1	1	-5077	\N	C	2019-12-20 22:13:53.799521+00	4628
5076	-3264	13	173	KFL 1409@Kärl	\N	\N	1	1	-5076	\N	C	2019-12-20 22:13:53.799521+00	4629
5075	-3264	13	173	KFL 1408@Kärl	\N	\N	1	1	-5075	\N	C	2019-12-20 22:13:53.799521+00	4630
5074	-3264	13	173	KFL 1407@Kärl	\N	\N	1	1	-5074	\N	C	2019-12-20 22:13:53.799521+00	4631
5073	-3264	13	173	KFL 1406@Kärl	\N	\N	1	1	-5073	\N	C	2019-12-20 22:13:53.799521+00	4632
5072	-3264	13	173	KFL 1405@Kärl	\N	\N	1	1	-5072	\N	C	2019-12-20 22:13:53.799521+00	4633
5071	-3264	13	173	KFL 1404@Kärl	\N	\N	1	1	-5071	\N	C	2019-12-20 22:13:53.799521+00	4634
5070	-3240	13	173	KFL 1390@Kärl	\N	\N	1	1	-5070	\N	C	2019-12-20 22:13:53.799521+00	4635
5069	-3240	13	173	KFL 1389@Kärl	\N	\N	1	1	-5069	\N	C	2019-12-20 22:13:53.799521+00	4636
5068	-3240	13	173	KFL 1388@Kärl	\N	\N	1	1	-5068	\N	C	2019-12-20 22:13:53.799521+00	4637
5067	-3240	13	173	KFL 1387@Kärl	\N	\N	1	1	-5067	\N	C	2019-12-20 22:13:53.799521+00	4638
5066	-3235	13	173	KFL 1386@Kärl	\N	\N	1	1	-5066	\N	C	2019-12-20 22:13:53.799521+00	4639
5065	-3235	13	173	KFL 1385@Kärl	\N	\N	1	1	-5065	\N	C	2019-12-20 22:13:53.799521+00	4640
5064	-3235	13	173	KFL 1384@Kärl	\N	\N	1	1	-5064	\N	C	2019-12-20 22:13:53.799521+00	4641
5063	-3235	13	173	KFL 1383@Kärl?	\N	\N	1	1	-5063	\N	C	2019-12-20 22:13:53.799521+00	4642
5062	-3235	13	173	KFL 1382@Kärl?	\N	\N	1	1	-5062	\N	C	2019-12-20 22:13:53.799521+00	4643
5061	-3143	13	173	KFL 1381@Kärl	\N	\N	1	1	-5061	\N	C	2019-12-20 22:13:53.799521+00	4644
5060	-3143	13	173	KFL 1380@Kärl	\N	\N	1	1	-5060	\N	C	2019-12-20 22:13:53.799521+00	4645
5059	-3143	13	173	KFL 1379@Kärl?	\N	\N	1	1	-5059	\N	C	2019-12-20 22:13:53.799521+00	4646
5058	-3143	13	173	KFL 1378@Kärl?	\N	\N	1	1	-5058	\N	C	2019-12-20 22:13:53.799521+00	4647
5057	-3143	13	173	KFL 1377@Kärl?	\N	\N	1	1	-5057	\N	C	2019-12-20 22:13:53.799521+00	4648
5056	-3133	13	173	KFL 1376@Kärl	\N	\N	1	1	-5056	\N	C	2019-12-20 22:13:53.799521+00	4649
5055	-3133	13	173	KFL 1375@Kärl?	\N	\N	1	1	-5055	\N	C	2019-12-20 22:13:53.799521+00	4650
5054	-3133	13	173	KFL 1374@Kärl	\N	\N	1	1	-5054	\N	C	2019-12-20 22:13:53.799521+00	4651
5053	-3133	13	173	KFL 1373@Kärl	\N	\N	1	1	-5053	\N	C	2019-12-20 22:13:53.799521+00	4652
5052	-3201	13	173	KFL 1372@Kärl?	\N	\N	1	1	-5052	\N	C	2019-12-20 22:13:53.799521+00	4653
5051	-3201	13	173	KFL 1371@Kärl	\N	\N	1	1	-5051	\N	C	2019-12-20 22:13:53.799521+00	4654
5050	-3201	13	173	KFL 1370@Kärl	\N	\N	1	1	-5050	\N	C	2019-12-20 22:13:53.799521+00	4655
5049	-3238	13	173	KFL 1369@Kärl	\N	\N	1	1	-5049	\N	C	2019-12-20 22:13:53.799521+00	4656
5048	-3238	13	173	KFL 1368@Kärl	\N	\N	1	1	-5048	\N	C	2019-12-20 22:13:53.799521+00	4657
5047	-3238	13	173	KFL 1367@Kärl?	\N	\N	1	1	-5047	\N	C	2019-12-20 22:13:53.799521+00	4658
5046	-3238	13	173	KFL 1366@Kärl	\N	\N	1	1	-5046	\N	C	2019-12-20 22:13:53.799521+00	4659
5045	-3238	13	173	KFL 1365@Kärl?	\N	\N	1	1	-5045	\N	C	2019-12-20 22:13:53.799521+00	4660
5044	-3040	13	173	KFL 1364@Kärl	\N	\N	1	1	-5044	\N	C	2019-12-20 22:13:53.799521+00	4661
5043	-3040	13	173	KFL 1363@Kärl	\N	\N	1	1	-5043	\N	C	2019-12-20 22:13:53.799521+00	4662
5042	-3040	13	173	KFL 1362@Kärl	\N	\N	1	1	-5042	\N	C	2019-12-20 22:13:53.799521+00	4663
5041	-3040	13	173	KFL 1361@Kärl	\N	\N	1	1	-5041	\N	C	2019-12-20 22:13:53.799521+00	4664
5040	-3040	13	173	KFL 1360@Kärl	\N	\N	1	1	-5040	\N	C	2019-12-20 22:13:53.799521+00	4665
5039	-3040	13	173	KFL 1359@Kärl	\N	\N	1	1	-5039	\N	C	2019-12-20 22:13:53.799521+00	4666
5038	-3004	13	173	KFL 1358@Kärl	\N	\N	1	1	-5038	\N	C	2019-12-20 22:13:53.799521+00	4667
5037	-3004	13	173	KFL 1357@Kärl	\N	\N	1	1	-5037	\N	C	2019-12-20 22:13:53.799521+00	4668
5036	-3004	13	173	KFL 1356@Kärl	\N	\N	1	1	-5036	\N	C	2019-12-20 22:13:53.799521+00	4669
5035	-3004	13	173	KFL 1355@Kärl	\N	\N	1	1	-5035	\N	C	2019-12-20 22:13:53.799521+00	4670
5034	-3004	13	173	KFL 1354@Kärl	\N	\N	1	1	-5034	\N	C	2019-12-20 22:13:53.799521+00	4671
5033	-3004	13	173	KFL 1353@Kärl	\N	\N	1	1	-5033	\N	C	2019-12-20 22:13:53.799521+00	4672
5032	-3004	13	173	KFL 1352@Kärl	\N	\N	1	1	-5032	\N	C	2019-12-20 22:13:53.799521+00	4673
5031	-3004	13	173	KFL 1351@Kärl	\N	\N	1	1	-5031	\N	C	2019-12-20 22:13:53.799521+00	4674
5030	-3004	13	173	KFL 1350@Kärl	\N	\N	1	1	-5030	\N	C	2019-12-20 22:13:53.799521+00	4675
5029	-3004	13	173	KFL 1349@Kärl	\N	\N	1	1	-5029	\N	C	2019-12-20 22:13:53.799521+00	4676
5028	-3316	13	173	KFL 1347@Kärl	\N	\N	1	1	-5028	\N	C	2019-12-20 22:13:53.799521+00	4677
5027	-1150	13	173	KFL 1345@Kärl	\N	\N	1	1	-5027	\N	C	2019-12-20 22:13:53.799521+00	4678
5026	-1150	13	173	KFL 1344@Kärl	\N	\N	1	1	-5026	\N	C	2019-12-20 22:13:53.799521+00	4679
5025	-1150	13	173	KFL 1343@Kärl	\N	\N	1	1	-5025	\N	C	2019-12-20 22:13:53.799521+00	4680
5024	-1150	13	173	KFL 1342@Kärl	\N	\N	1	1	-5024	\N	C	2019-12-20 22:13:53.799521+00	4681
5023	-1150	13	173	KFL 1341@Kärl	\N	\N	1	1	-5023	\N	C	2019-12-20 22:13:53.799521+00	4682
5022	-1150	13	173	KFL 1340@Kärl	\N	\N	1	1	-5022	\N	C	2019-12-20 22:13:53.799521+00	4683
5021	-1150	13	173	KFL 1339@Kärl	\N	\N	1	1	-5021	\N	C	2019-12-20 22:13:53.799521+00	4684
5020	-1150	13	173	KFL 1338@Kärl	\N	\N	1	1	-5020	\N	C	2019-12-20 22:13:53.799521+00	4685
5019	-1150	13	173	KFL 1337@Kärl	\N	\N	1	1	-5019	\N	C	2019-12-20 22:13:53.799521+00	4686
5018	-1150	13	173	KFL 1336@Kärl	\N	\N	1	1	-5018	\N	C	2019-12-20 22:13:53.799521+00	4687
5017	-1150	13	173	KFL 1335@Kärl	\N	\N	1	1	-5017	\N	C	2019-12-20 22:13:53.799521+00	4688
5016	-1150	13	173	KFL 1334@Kärl	\N	\N	1	1	-5016	\N	C	2019-12-20 22:13:53.799521+00	4689
5015	-1150	13	173	KFL 1333@Kärl	\N	\N	1	1	-5015	\N	C	2019-12-20 22:13:53.799521+00	4690
5014	-1150	13	173	KFL 1332@Kärl	\N	\N	1	1	-5014	\N	C	2019-12-20 22:13:53.799521+00	4691
5013	-1150	13	173	KFL 1331@Kärl	\N	\N	1	1	-5013	\N	C	2019-12-20 22:13:53.799521+00	4692
5012	-1150	13	173	KFL 1330@Kärl	\N	\N	1	1	-5012	\N	C	2019-12-20 22:13:53.799521+00	4693
5011	-1150	13	173	KFL 1329@Kärl	\N	\N	1	1	-5011	\N	C	2019-12-20 22:13:53.799521+00	4694
5010	-1150	13	173	KFL 1328@Kärl	\N	\N	1	1	-5010	\N	C	2019-12-20 22:13:53.799521+00	4695
5009	-1150	13	173	KFL 1327@Kärl	\N	\N	1	1	-5009	\N	C	2019-12-20 22:13:53.799521+00	4696
5008	-1150	13	173	KFL 1326@Kärl	\N	\N	1	1	-5008	\N	C	2019-12-20 22:13:53.799521+00	4697
5007	-3053	13	173	KFL 1325@Kärl	\N	\N	1	1	-5007	\N	C	2019-12-20 22:13:53.799521+00	4698
5006	-3053	13	173	KFL 1324@Kärl	\N	\N	1	1	-5006	\N	C	2019-12-20 22:13:53.799521+00	4699
5005	-3053	13	173	KFL 1323@Kärl	\N	\N	1	1	-5005	\N	C	2019-12-20 22:13:53.799521+00	4700
5004	-3053	13	173	KFL 1322@Kärl	\N	\N	1	1	-5004	\N	C	2019-12-20 22:13:53.799521+00	4701
5003	-3053	13	173	KFL 1321@Kärl	\N	\N	1	1	-5003	\N	C	2019-12-20 22:13:53.799521+00	4702
5002	-3053	13	173	KFL 1320@Kärl	\N	\N	1	1	-5002	\N	C	2019-12-20 22:13:53.799521+00	4703
5001	-3053	13	173	KFL 1319@Kärl	\N	\N	1	1	-5001	\N	C	2019-12-20 22:13:53.799521+00	4704
5000	-3053	13	173	KFL 1318@Kärl	\N	\N	1	1	-5000	\N	C	2019-12-20 22:13:53.799521+00	4705
4999	-3053	13	173	KFL 1317@Kärl	\N	\N	1	1	-4999	\N	C	2019-12-20 22:13:53.799521+00	4706
4998	-3053	13	173	KFL 1316@Kärl	\N	\N	1	1	-4998	\N	C	2019-12-20 22:13:53.799521+00	4707
4997	-3053	13	173	KFL 1315@Kärl	\N	\N	1	1	-4997	\N	C	2019-12-20 22:13:53.799521+00	4708
4996	-3053	13	173	KFL 1311@Kärl	\N	\N	1	1	-4996	\N	C	2019-12-20 22:13:53.799521+00	4709
4995	-3053	13	173	KFL 1310@Kärl	\N	\N	1	1	-4995	\N	C	2019-12-20 22:13:53.799521+00	4710
4994	-3053	13	173	KFL 1309@Kärl	\N	\N	1	1	-4994	\N	C	2019-12-20 22:13:53.799521+00	4711
4993	-3053	13	173	KFL 1308@Kärl	\N	\N	1	1	-4993	\N	C	2019-12-20 22:13:53.799521+00	4712
4992	-3379	13	173	KFL 1307@Kärl	\N	\N	1	1	-4992	\N	C	2019-12-20 22:13:53.799521+00	4713
4991	-3379	13	173	KFL 1306@Kärl	\N	\N	1	1	-4991	\N	C	2019-12-20 22:13:53.799521+00	4714
4990	-3379	13	173	KFL 1305@Kärl	\N	\N	1	1	-4990	\N	C	2019-12-20 22:13:53.799521+00	4715
4989	-3379	13	173	KFL 1304@Kärl	\N	\N	1	1	-4989	\N	C	2019-12-20 22:13:53.799521+00	4716
4988	-3337	13	173	KFL 1303@Kärl	\N	\N	1	1	-4988	\N	C	2019-12-20 22:13:53.799521+00	4717
4987	-3337	13	173	KFL 1302@Kärl	\N	\N	1	1	-4987	\N	C	2019-12-20 22:13:53.799521+00	4718
4986	-3337	13	173	KFL 1301@Kärl	\N	\N	1	1	-4986	\N	C	2019-12-20 22:13:53.799521+00	4719
4985	-2980	13	173	KFL 1300@Kärl	\N	\N	1	1	-4985	\N	C	2019-12-20 22:13:53.799521+00	4720
4984	-2980	13	173	KFL 1299@Kärl	\N	\N	1	1	-4984	\N	C	2019-12-20 22:13:53.799521+00	4721
4983	-3096	13	173	KFL 1285@Jordprov	\N	\N	1	1	-4983	\N	C	2019-12-20 22:13:53.799521+00	4722
4982	-3096	13	173	KFL 1284@Jordprov	\N	\N	1	1	-4982	\N	C	2019-12-20 22:13:53.799521+00	4723
4981	-3096	13	173	KFL 1283@Jordprov	\N	\N	1	1	-4981	\N	C	2019-12-20 22:13:53.799521+00	4724
4980	-3135	13	173	KFL 1282@Jordprov	\N	\N	1	1	-4980	\N	C	2019-12-20 22:13:53.799521+00	4725
4979	-3051	13	173	KFL 1281@Kärl	\N	\N	1	1	-4979	\N	C	2019-12-20 22:13:53.799521+00	4726
4978	-3051	13	173	KFL 1280@Kärl	\N	\N	1	1	-4978	\N	C	2019-12-20 22:13:53.799521+00	4727
4977	-3051	13	173	KFL 1279@Kärl	\N	\N	1	1	-4977	\N	C	2019-12-20 22:13:53.799521+00	4728
4976	-3051	13	173	KFL 1278@Kärl	\N	\N	1	1	-4976	\N	C	2019-12-20 22:13:53.799521+00	4729
4975	-3051	13	173	KFL 1277@Kärl	\N	\N	1	1	-4975	\N	C	2019-12-20 22:13:53.799521+00	4730
4974	-3051	13	173	KFL 1276@Kärl	\N	\N	1	1	-4974	\N	C	2019-12-20 22:13:53.799521+00	4731
4973	-3034	13	173	KFL 1275@Kärl	\N	\N	1	1	-4973	\N	C	2019-12-20 22:13:53.799521+00	4732
4972	-3275	13	173	KFL 1274@Kärl	\N	\N	1	1	-4972	\N	C	2019-12-20 22:13:53.799521+00	4733
4971	-3275	13	173	KFL 1273@Kärl	\N	\N	1	1	-4971	\N	C	2019-12-20 22:13:53.799521+00	4734
4970	-3104	13	173	KFL 1272@Kärl	\N	\N	1	1	-4970	\N	C	2019-12-20 22:13:53.799521+00	4735
4969	-3104	13	173	KFL 1271@Kärl	\N	\N	1	1	-4969	\N	C	2019-12-20 22:13:53.799521+00	4736
4968	-3104	13	173	KFL 1270@Kärl	\N	\N	1	1	-4968	\N	C	2019-12-20 22:13:53.799521+00	4737
4967	-3104	13	173	KFL 1269@Kärl	\N	\N	1	1	-4967	\N	C	2019-12-20 22:13:53.799521+00	4738
4966	-3034	13	173	KFL 1268@Kärl	\N	\N	1	1	-4966	\N	C	2019-12-20 22:13:53.799521+00	4739
4965	-2987	13	173	KFL 1267@Kärl	\N	\N	1	1	-4965	\N	C	2019-12-20 22:13:53.799521+00	4740
4964	-2987	13	173	KFL 1266@Kärl	\N	\N	1	1	-4964	\N	C	2019-12-20 22:13:53.799521+00	4741
4963	-2987	13	173	KFL 1265@Kärl	\N	\N	1	1	-4963	\N	C	2019-12-20 22:13:53.799521+00	4742
4962	-2987	13	173	KFL 1264@Kärl	\N	\N	1	1	-4962	\N	C	2019-12-20 22:13:53.799521+00	4743
4961	-3265	13	173	KFL 1263@Kärl	\N	\N	1	1	-4961	\N	C	2019-12-20 22:13:53.799521+00	4744
4960	-3265	13	173	KFL 1262@Kärl	\N	\N	1	1	-4960	\N	C	2019-12-20 22:13:53.799521+00	4745
4959	-3265	13	173	KFL 1261@Kärl	\N	\N	1	1	-4959	\N	C	2019-12-20 22:13:53.799521+00	4746
4958	-3265	13	173	KFL 1260@Kärl	\N	\N	1	1	-4958	\N	C	2019-12-20 22:13:53.799521+00	4747
4957	-3031	13	173	KFL 1259@Kärl	\N	\N	1	1	-4957	\N	C	2019-12-20 22:13:53.799521+00	4748
4956	-3031	13	173	KFL 1258@Kärl	\N	\N	1	1	-4956	\N	C	2019-12-20 22:13:53.799521+00	4749
4955	-3231	13	173	KFL 1257@Kärl	\N	\N	1	1	-4955	\N	C	2019-12-20 22:13:53.799521+00	4750
4954	-3231	13	173	KFL 1256@Kärl	\N	\N	1	1	-4954	\N	C	2019-12-20 22:13:53.799521+00	4751
4953	-3231	13	173	KFL 1255@Kärl	\N	\N	1	1	-4953	\N	C	2019-12-20 22:13:53.799521+00	4752
4952	-3044	13	173	KFL 1254@Kärl	\N	\N	1	1	-4952	\N	C	2019-12-20 22:13:53.799521+00	4753
4951	-3102	13	173	KFL 1253@Kärl	\N	\N	1	1	-4951	\N	C	2019-12-20 22:13:53.799521+00	4754
4950	-3102	13	173	KFL 1252@Kärl	\N	\N	1	1	-4950	\N	C	2019-12-20 22:13:53.799521+00	4755
4949	-3246	13	173	KFL 1251@Kärl	\N	\N	1	1	-4949	\N	C	2019-12-20 22:13:53.799521+00	4756
4948	-3246	13	173	KFL 1250@Kärl	\N	\N	1	1	-4948	\N	C	2019-12-20 22:13:53.799521+00	4757
4947	-3236	13	173	KFL 1249@Kärl	\N	\N	1	1	-4947	\N	C	2019-12-20 22:13:53.799521+00	4758
4946	-3236	13	173	KFL 1248@Kärl	\N	\N	1	1	-4946	\N	C	2019-12-20 22:13:53.799521+00	4759
4945	-3271	13	173	KFL 1220@Lerklining	\N	\N	1	1	-4945	\N	C	2019-12-20 22:13:53.799521+00	4760
4944	-3271	13	173	KFL 1219@?	\N	\N	1	1	-4944	\N	C	2019-12-20 22:13:53.799521+00	4761
4943	-3271	13	173	KFL 1218@Tegel	\N	\N	1	1	-4943	\N	C	2019-12-20 22:13:53.799521+00	4762
4942	-3271	13	173	KFL 1217@Kärl	\N	\N	1	1	-4942	\N	C	2019-12-20 22:13:53.799521+00	4763
4941	-3308	13	173	KFL 1201@Lerklining	\N	\N	1	1	-4941	\N	C	2019-12-20 22:13:53.799521+00	4764
4940	-3308	13	173	KFL 1200@Lerklining	\N	\N	1	1	-4940	\N	C	2019-12-20 22:13:53.799521+00	4765
4939	-3308	13	173	KFL 1199@Kärl	\N	\N	1	1	-4939	\N	C	2019-12-20 22:13:53.799521+00	4766
4938	-3263	13	173	KFL 1198@Kärl	\N	\N	1	1	-4938	\N	C	2019-12-20 22:13:53.799521+00	4767
4937	-3263	13	173	KFL 1197@Lerklining	\N	\N	1	1	-4937	\N	C	2019-12-20 22:13:53.799521+00	4768
4936	-3263	13	173	KFL 1196@Lerklining	\N	\N	1	1	-4936	\N	C	2019-12-20 22:13:53.799521+00	4769
4935	-3263	13	173	KFL 1195@Sländtrissa &amp; vävtyngd	\N	\N	1	1	-4935	\N	C	2019-12-20 22:13:53.799521+00	4770
4934	-3263	13	173	KFL 1194@Sländtrissa &amp; vävtyngd	\N	\N	1	1	-4934	\N	C	2019-12-20 22:13:53.799521+00	4771
4933	-3263	13	173	KFL 1193@Kärl	\N	\N	1	1	-4933	\N	C	2019-12-20 22:13:53.799521+00	4772
4932	-3263	13	173	KFL 1192@Kärl	\N	\N	1	1	-4932	\N	C	2019-12-20 22:13:53.799521+00	4773
4931	-3263	13	173	KFL 1191@Kärl	\N	\N	1	1	-4931	\N	C	2019-12-20 22:13:53.799521+00	4774
4930	-3263	13	173	KFL 1190@Kärl	\N	\N	1	1	-4930	\N	C	2019-12-20 22:13:53.799521+00	4775
4929	-3263	13	173	KFL 1189@Kärl	\N	\N	1	1	-4929	\N	C	2019-12-20 22:13:53.799521+00	4776
4928	-3263	13	173	KFL 1188@Kärl	\N	\N	1	1	-4928	\N	C	2019-12-20 22:13:53.799521+00	4777
4927	-3263	13	173	KFL 1187@Kärl	\N	\N	1	1	-4927	\N	C	2019-12-20 22:13:53.799521+00	4778
4926	-3263	13	173	KFL 1186@Kärl	\N	\N	1	1	-4926	\N	C	2019-12-20 22:13:53.799521+00	4779
4925	-3263	13	173	KFL 1185@Kärl	\N	\N	1	1	-4925	\N	C	2019-12-20 22:13:53.799521+00	4780
4924	-3263	13	173	KFL 1184@Kärl	\N	\N	1	1	-4924	\N	C	2019-12-20 22:13:53.799521+00	4781
4923	-3263	13	173	KFL 1183@Kärl	\N	\N	1	1	-4923	\N	C	2019-12-20 22:13:53.799521+00	4782
4922	-3353	13	173	KFL 1181@Tegel	\N	\N	1	1	-4922	\N	C	2019-12-20 22:13:53.799521+00	4783
4921	-3354	13	173	KFL 1179@Tegel	\N	\N	1	1	-4921	\N	C	2019-12-20 22:13:53.799521+00	4784
4920	-3355	13	173	KFL 1178@Tegel	\N	\N	1	1	-4920	\N	C	2019-12-20 22:13:53.799521+00	4785
4919	-3355	13	173	KFL 1177@Tegel	\N	\N	1	1	-4919	\N	C	2019-12-20 22:13:53.799521+00	4786
4918	-3355	13	173	KFL 1176@Tegel	\N	\N	1	1	-4918	\N	C	2019-12-20 22:13:53.799521+00	4787
4917	-3355	13	173	KFL 1175@Tegel	\N	\N	1	1	-4917	\N	C	2019-12-20 22:13:53.799521+00	4788
4916	-3355	13	173	KFL 1174@Tegel	\N	\N	1	1	-4916	\N	C	2019-12-20 22:13:53.799521+00	4789
4915	-3172	13	173	KFL 1173@Kärl	\N	\N	1	1	-4915	\N	C	2019-12-20 22:13:53.799521+00	4790
4914	-3172	13	173	KFL 1172@Kärl	\N	\N	1	1	-4914	\N	C	2019-12-20 22:13:53.799521+00	4791
4913	-3172	13	173	KFL 1171@Kärl	\N	\N	1	1	-4913	\N	C	2019-12-20 22:13:53.799521+00	4792
4912	-3172	13	173	KFL 1170@Kärl	\N	\N	1	1	-4912	\N	C	2019-12-20 22:13:53.799521+00	4793
4911	-3172	13	173	KFL 1169@Kärl	\N	\N	1	1	-4911	\N	C	2019-12-20 22:13:53.799521+00	4794
4910	-3172	13	173	KFL 1168@Kärl	\N	\N	1	1	-4910	\N	C	2019-12-20 22:13:53.799521+00	4795
4909	-3172	13	173	KFL 1167@Kärl	\N	\N	1	1	-4909	\N	C	2019-12-20 22:13:53.799521+00	4796
4908	-3172	13	173	KFL 1166@Kärl	\N	\N	1	1	-4908	\N	C	2019-12-20 22:13:53.799521+00	4797
4907	-3172	13	173	KFL 1165@Kärl	\N	\N	1	1	-4907	\N	C	2019-12-20 22:13:53.799521+00	4798
4906	-3172	13	173	KFL 1164@Kärl	\N	\N	1	1	-4906	\N	C	2019-12-20 22:13:53.799521+00	4799
4905	-3172	13	173	KFL 1163@Kärl	\N	\N	1	1	-4905	\N	C	2019-12-20 22:13:53.799521+00	4800
4904	-3172	13	173	KFL 1162@Kärl	\N	\N	1	1	-4904	\N	C	2019-12-20 22:13:53.799521+00	4801
4903	-3172	13	173	KFL 1161@Kärl	\N	\N	1	1	-4903	\N	C	2019-12-20 22:13:53.799521+00	4802
4902	-3172	13	173	KFL 1160@Kärl	\N	\N	1	1	-4902	\N	C	2019-12-20 22:13:53.799521+00	4803
4901	-3172	13	173	KFL 1159@Kärl	\N	\N	1	1	-4901	\N	C	2019-12-20 22:13:53.799521+00	4804
4900	-3172	13	173	KFL 1158@Kärl	\N	\N	1	1	-4900	\N	C	2019-12-20 22:13:53.799521+00	4805
4899	-3172	13	173	KFL 1157@Kärl	\N	\N	1	1	-4899	\N	C	2019-12-20 22:13:53.799521+00	4806
4898	-3172	13	173	KFL 1156@Kärl	\N	\N	1	1	-4898	\N	C	2019-12-20 22:13:53.799521+00	4807
4897	-3172	13	173	KFL 1155@Kärl	\N	\N	1	1	-4897	\N	C	2019-12-20 22:13:53.799521+00	4808
4896	-3172	13	173	KFL 1154@Kärl	\N	\N	1	1	-4896	\N	C	2019-12-20 22:13:53.799521+00	4809
4895	-3172	13	173	KFL 1153@Kärl	\N	\N	1	1	-4895	\N	C	2019-12-20 22:13:53.799521+00	4810
4894	-3172	13	173	KFL 1152@Kärl	\N	\N	1	1	-4894	\N	C	2019-12-20 22:13:53.799521+00	4811
4893	-3021	13	173	KFL 1151@Kärl	\N	\N	1	1	-4893	\N	C	2019-12-20 22:13:53.799521+00	4812
4892	-3021	13	173	KFL 1150@Kärl	\N	\N	1	1	-4892	\N	C	2019-12-20 22:13:53.799521+00	4813
4891	-3021	13	173	KFL 1149@Kärl	\N	\N	1	1	-4891	\N	C	2019-12-20 22:13:53.799521+00	4814
4890	-3021	13	173	KFL 1148@Kärl	\N	\N	1	1	-4890	\N	C	2019-12-20 22:13:53.799521+00	4815
4889	-3021	13	173	KFL 1147@Kärl	\N	\N	1	1	-4889	\N	C	2019-12-20 22:13:53.799521+00	4816
4888	-3021	13	173	KFL 1146@Kärl	\N	\N	1	1	-4888	\N	C	2019-12-20 22:13:53.799521+00	4817
4887	-3021	13	173	KFL 1145@Kärl	\N	\N	1	1	-4887	\N	C	2019-12-20 22:13:53.799521+00	4818
4886	-3021	13	173	KFL 1144@Kärl	\N	\N	1	1	-4886	\N	C	2019-12-20 22:13:53.799521+00	4819
4885	-3021	13	173	KFL 1143@Kärl	\N	\N	1	1	-4885	\N	C	2019-12-20 22:13:53.799521+00	4820
4884	-3021	13	173	KFL 1142@Kärl	\N	\N	1	1	-4884	\N	C	2019-12-20 22:13:53.799521+00	4821
4883	-3021	13	173	KFL 1141@Kärl	\N	\N	1	1	-4883	\N	C	2019-12-20 22:13:53.799521+00	4822
4882	-3021	13	173	KFL 1140@Kärl	\N	\N	1	1	-4882	\N	C	2019-12-20 22:13:53.799521+00	4823
4881	-3021	13	173	KFL 1139@Kärl	\N	\N	1	1	-4881	\N	C	2019-12-20 22:13:53.799521+00	4824
4880	-3021	13	173	KFL 1138@Kärl	\N	\N	1	1	-4880	\N	C	2019-12-20 22:13:53.799521+00	4825
4879	-3021	13	173	KFL 1137@Kärl	\N	\N	1	1	-4879	\N	C	2019-12-20 22:13:53.799521+00	4826
4878	-3021	13	173	KFL 1136@Kärl	\N	\N	1	1	-4878	\N	C	2019-12-20 22:13:53.799521+00	4827
4877	-3021	13	173	KFL 1135@Kärl	\N	\N	1	1	-4877	\N	C	2019-12-20 22:13:53.799521+00	4828
4876	-3021	13	173	KFL 1134@Kärl	\N	\N	1	1	-4876	\N	C	2019-12-20 22:13:53.799521+00	4829
4875	-3021	13	173	KFL 1133@Kärl	\N	\N	1	1	-4875	\N	C	2019-12-20 22:13:53.799521+00	4830
4874	-3021	13	173	KFL 1132@Kärl	\N	\N	1	1	-4874	\N	C	2019-12-20 22:13:53.799521+00	4831
4873	-3021	13	173	KFL 1131@Kärl	\N	\N	1	1	-4873	\N	C	2019-12-20 22:13:53.799521+00	4832
4872	-3021	13	173	KFL 1130@Kärl	\N	\N	1	1	-4872	\N	C	2019-12-20 22:13:53.799521+00	4833
4871	-3021	13	173	KFL 1129@Kärl	\N	\N	1	1	-4871	\N	C	2019-12-20 22:13:53.799521+00	4834
4870	-3021	13	173	KFL 1128@Kärl	\N	\N	1	1	-4870	\N	C	2019-12-20 22:13:53.799521+00	4835
4869	-3021	13	173	KFL 1127@Kärl	\N	\N	1	1	-4869	\N	C	2019-12-20 22:13:53.799521+00	4836
4868	-3021	13	173	KFL 1126@Kärl	\N	\N	1	1	-4868	\N	C	2019-12-20 22:13:53.799521+00	4837
4867	-3021	13	173	KFL 1125@Kärl	\N	\N	1	1	-4867	\N	C	2019-12-20 22:13:53.799521+00	4838
4866	-3021	13	173	KFL 1124@Kärl	\N	\N	1	1	-4866	\N	C	2019-12-20 22:13:53.799521+00	4839
4865	-3021	13	173	KFL 1123@Kärl	\N	\N	1	1	-4865	\N	C	2019-12-20 22:13:53.799521+00	4840
4864	-3021	13	173	KFL 1122@Kärl	\N	\N	1	1	-4864	\N	C	2019-12-20 22:13:53.799521+00	4841
4863	-3021	13	173	KFL 1121@Kärl	\N	\N	1	1	-4863	\N	C	2019-12-20 22:13:53.799521+00	4842
4862	-3021	13	173	KFL 1120@Kärl	\N	\N	1	1	-4862	\N	C	2019-12-20 22:13:53.799521+00	4843
4861	-3280	13	173	KFL 1119@Kärl	\N	\N	1	1	-4861	\N	C	2019-12-20 22:13:53.799521+00	4844
4860	-3280	13	173	KFL 1118@Kärl	\N	\N	1	1	-4860	\N	C	2019-12-20 22:13:53.799521+00	4845
4859	-3280	13	173	KFL 1117@Kärl	\N	\N	1	1	-4859	\N	C	2019-12-20 22:13:53.799521+00	4846
4858	-3280	13	173	KFL 1116@Kärl	\N	\N	1	1	-4858	\N	C	2019-12-20 22:13:53.799521+00	4847
4857	-3280	13	173	KFL 1115@Kärl	\N	\N	1	1	-4857	\N	C	2019-12-20 22:13:53.799521+00	4848
4856	-3280	13	173	KFL 1114@Kärl	\N	\N	1	1	-4856	\N	C	2019-12-20 22:13:53.799521+00	4849
4855	-3280	13	173	KFL 1113@Kärl	\N	\N	1	1	-4855	\N	C	2019-12-20 22:13:53.799521+00	4850
4854	-3020	13	173	KFL 1112@Kärl	\N	\N	1	1	-4854	\N	C	2019-12-20 22:13:53.799521+00	4851
4853	-3020	13	173	KFL 1111@Kärl	\N	\N	1	1	-4853	\N	C	2019-12-20 22:13:53.799521+00	4852
4852	-3020	13	173	KFL 1110@Kärl	\N	\N	1	1	-4852	\N	C	2019-12-20 22:13:53.799521+00	4853
4851	-3020	13	173	KFL 1109@Kärl	\N	\N	1	1	-4851	\N	C	2019-12-20 22:13:53.799521+00	4854
4850	-3087	13	173	KFL 1108@Kärl	\N	\N	1	1	-4850	\N	C	2019-12-20 22:13:53.799521+00	4855
4849	-3087	13	173	KFL 1107@Kärl	\N	\N	1	1	-4849	\N	C	2019-12-20 22:13:53.799521+00	4856
4848	-3087	13	173	KFL 1106@Kärl	\N	\N	1	1	-4848	\N	C	2019-12-20 22:13:53.799521+00	4857
4847	-3087	13	173	KFL 1105@Kärl	\N	\N	1	1	-4847	\N	C	2019-12-20 22:13:53.799521+00	4858
4846	-3087	13	173	KFL 1104@Kärl	\N	\N	1	1	-4846	\N	C	2019-12-20 22:13:53.799521+00	4859
4845	-3087	13	173	KFL 1103@Kärl	\N	\N	1	1	-4845	\N	C	2019-12-20 22:13:53.799521+00	4860
4844	-3087	13	173	KFL 1102@Kärl	\N	\N	1	1	-4844	\N	C	2019-12-20 22:13:53.799521+00	4861
4843	-3094	13	173	KFL 1079@Tegel	\N	\N	1	1	-4843	\N	C	2019-12-20 22:13:53.799521+00	4862
4842	-3094	13	173	KFL 1078@Tegel	\N	\N	1	1	-4842	\N	C	2019-12-20 22:13:53.799521+00	4863
4841	-3094	13	173	KFL 1077@Tegel	\N	\N	1	1	-4841	\N	C	2019-12-20 22:13:53.799521+00	4864
4840	-3094	13	173	KFL 1076@Tegel	\N	\N	1	1	-4840	\N	C	2019-12-20 22:13:53.799521+00	4865
4839	-3094	13	173	KFL 1075@Tegel	\N	\N	1	1	-4839	\N	C	2019-12-20 22:13:53.799521+00	4866
4838	-3094	13	173	KFL 1074@Tegel	\N	\N	1	1	-4838	\N	C	2019-12-20 22:13:53.799521+00	4867
4837	-3094	13	173	KFL 1073@Tegel	\N	\N	1	1	-4837	\N	C	2019-12-20 22:13:53.799521+00	4868
4836	-3094	13	173	KFL 1072@Tegel	\N	\N	1	1	-4836	\N	C	2019-12-20 22:13:53.799521+00	4869
4835	-3094	13	173	KFL 1071@Tegel	\N	\N	1	1	-4835	\N	C	2019-12-20 22:13:53.799521+00	4870
4834	-3094	13	173	KFL 1070@Tegel	\N	\N	1	1	-4834	\N	C	2019-12-20 22:13:53.799521+00	4871
4833	-3094	13	173	KFL 1069@Tegel	\N	\N	1	1	-4833	\N	C	2019-12-20 22:13:53.799521+00	4872
4832	-3094	13	173	KFL 1068@Tegel	\N	\N	1	1	-4832	\N	C	2019-12-20 22:13:53.799521+00	4873
4831	-3094	13	173	KFL 1067@Tegel	\N	\N	1	1	-4831	\N	C	2019-12-20 22:13:53.799521+00	4874
4830	-3094	13	173	KFL 1066@Tegel	\N	\N	1	1	-4830	\N	C	2019-12-20 22:13:53.799521+00	4875
4829	-3138	13	173	KFL 1065@Kärl?	\N	\N	1	1	-4829	\N	C	2019-12-20 22:13:53.799521+00	4876
4828	-3138	13	173	KFL 1064@Kärl?	\N	\N	1	1	-4828	\N	C	2019-12-20 22:13:53.799521+00	4877
4827	-3138	13	173	KFL 1063@Kärl?	\N	\N	1	1	-4827	\N	C	2019-12-20 22:13:53.799521+00	4878
4826	-3138	13	173	KFL 1062@Kärl?	\N	\N	1	1	-4826	\N	C	2019-12-20 22:13:53.799521+00	4879
4825	-3138	13	173	KFL 1061@Kärl?	\N	\N	1	1	-4825	\N	C	2019-12-20 22:13:53.799521+00	4880
4824	-3138	13	173	KFL 1060@Kärl?	\N	\N	1	1	-4824	\N	C	2019-12-20 22:13:53.799521+00	4881
4823	-3138	13	173	KFL 1059@Kärl?	\N	\N	1	1	-4823	\N	C	2019-12-20 22:13:53.799521+00	4882
4822	-3138	13	173	KFL 1058@Kärl?	\N	\N	1	1	-4822	\N	C	2019-12-20 22:13:53.799521+00	4883
4821	-3138	13	173	KFL 1057@Kärl?	\N	\N	1	1	-4821	\N	C	2019-12-20 22:13:53.799521+00	4884
4820	-3138	13	173	KFL 1056@Kärl?	\N	\N	1	1	-4820	\N	C	2019-12-20 22:13:53.799521+00	4885
4819	-3138	13	173	KFL 1055@Kärl?	\N	\N	1	1	-4819	\N	C	2019-12-20 22:13:53.799521+00	4886
4818	-3138	13	173	KFL 1054@Kärl?	\N	\N	1	1	-4818	\N	C	2019-12-20 22:13:53.799521+00	4887
4817	-3138	13	173	KFL 1053@Kärl?	\N	\N	1	1	-4817	\N	C	2019-12-20 22:13:53.799521+00	4888
4816	-3138	13	173	KFL 1052@Kärl?	\N	\N	1	1	-4816	\N	C	2019-12-20 22:13:53.799521+00	4889
4815	-3138	13	173	KFL 1051@Kärl?	\N	\N	1	1	-4815	\N	C	2019-12-20 22:13:53.799521+00	4890
4814	-3138	13	173	KFL 1050@Kärl?	\N	\N	1	1	-4814	\N	C	2019-12-20 22:13:53.799521+00	4891
4813	-3038	13	173	KFL 1049@Kärl	\N	\N	1	1	-4813	\N	C	2019-12-20 22:13:53.799521+00	4892
4812	-3038	13	173	KFL 1048@Kärl	\N	\N	1	1	-4812	\N	C	2019-12-20 22:13:53.799521+00	4893
4811	-3038	13	173	KFL 1047@Kärl	\N	\N	1	1	-4811	\N	C	2019-12-20 22:13:53.799521+00	4894
4810	-3038	13	173	KFL 1046@Kärl	\N	\N	1	1	-4810	\N	C	2019-12-20 22:13:53.799521+00	4895
4809	-3038	13	173	KFL 1045@Kärl	\N	\N	1	1	-4809	\N	C	2019-12-20 22:13:53.799521+00	4896
4808	-3038	13	173	KFL 1044@Kärl	\N	\N	1	1	-4808	\N	C	2019-12-20 22:13:53.799521+00	4897
4807	-3038	13	173	KFL 1043@Kärl	\N	\N	1	1	-4807	\N	C	2019-12-20 22:13:53.799521+00	4898
4806	-3038	13	173	KFL 1042@Kärl	\N	\N	1	1	-4806	\N	C	2019-12-20 22:13:53.799521+00	4899
4805	-3038	13	173	KFL 1041@Kärl	\N	\N	1	1	-4805	\N	C	2019-12-20 22:13:53.799521+00	4900
4804	-3038	13	173	KFL 1040@Kärl	\N	\N	1	1	-4804	\N	C	2019-12-20 22:13:53.799521+00	4901
4803	-3038	13	173	KFL 1039@Kärl	\N	\N	1	1	-4803	\N	C	2019-12-20 22:13:53.799521+00	4902
4802	-3038	13	173	KFL 1038@Kärl	\N	\N	1	1	-4802	\N	C	2019-12-20 22:13:53.799521+00	4903
4801	-3038	13	173	KFL 1037@Kärl	\N	\N	1	1	-4801	\N	C	2019-12-20 22:13:53.799521+00	4904
4800	-3038	13	173	KFL 1036@Kärl	\N	\N	1	1	-4800	\N	C	2019-12-20 22:13:53.799521+00	4905
4799	-3038	13	173	KFL 1035@Kärl	\N	\N	1	1	-4799	\N	C	2019-12-20 22:13:53.799521+00	4906
4798	-3038	13	173	KFL 1034@Kärl	\N	\N	1	1	-4798	\N	C	2019-12-20 22:13:53.799521+00	4907
4797	-3038	13	173	KFL 1033@Kärl	\N	\N	1	1	-4797	\N	C	2019-12-20 22:13:53.799521+00	4908
4796	-3038	13	173	KFL 1032@Kärl	\N	\N	1	1	-4796	\N	C	2019-12-20 22:13:53.799521+00	4909
4795	-3038	13	173	KFL 1031@Kärl	\N	\N	1	1	-4795	\N	C	2019-12-20 22:13:53.799521+00	4910
4794	-3038	13	173	KFL 1030@Kärl	\N	\N	1	1	-4794	\N	C	2019-12-20 22:13:53.799521+00	4911
4793	-3038	13	173	KFL 1029@Kärl	\N	\N	1	1	-4793	\N	C	2019-12-20 22:13:53.799521+00	4912
4792	-3038	13	173	KFL 1028@Kärl	\N	\N	1	1	-4792	\N	C	2019-12-20 22:13:53.799521+00	4913
4791	-3038	13	173	KFL 1027@Kärl	\N	\N	1	1	-4791	\N	C	2019-12-20 22:13:53.799521+00	4914
4790	-3038	13	173	KFL 1026@Kärl	\N	\N	1	1	-4790	\N	C	2019-12-20 22:13:53.799521+00	4915
4789	-3038	13	173	KFL 1025@Kärl	\N	\N	1	1	-4789	\N	C	2019-12-20 22:13:53.799521+00	4916
4788	-3038	13	173	KFL 1024@Kärl	\N	\N	1	1	-4788	\N	C	2019-12-20 22:13:53.799521+00	4917
4787	-3038	13	173	KFL 1023@Kärl	\N	\N	1	1	-4787	\N	C	2019-12-20 22:13:53.799521+00	4918
4786	-3038	13	173	KFL 1022@Kärl	\N	\N	1	1	-4786	\N	C	2019-12-20 22:13:53.799521+00	4919
4785	-3038	13	173	KFL 1021@Kärl	\N	\N	1	1	-4785	\N	C	2019-12-20 22:13:53.799521+00	4920
4784	-3038	13	173	KFL 1020@Kärl	\N	\N	1	1	-4784	\N	C	2019-12-20 22:13:53.799521+00	4921
4783	-3038	13	173	KFL 1019@Kärl	\N	\N	1	1	-4783	\N	C	2019-12-20 22:13:53.799521+00	4922
4782	-3038	13	173	KFL 1018@Kärl	\N	\N	1	1	-4782	\N	C	2019-12-20 22:13:53.799521+00	4923
4781	-3038	13	173	KFL 1017@Kärl	\N	\N	1	1	-4781	\N	C	2019-12-20 22:13:53.799521+00	4924
4780	-3038	13	173	KFL 1016@Kärl	\N	\N	1	1	-4780	\N	C	2019-12-20 22:13:53.799521+00	4925
4779	-3038	13	173	KFL 1015@Kärl	\N	\N	1	1	-4779	\N	C	2019-12-20 22:13:53.799521+00	4926
4778	-3038	13	173	KFL 1014@Kärl	\N	\N	1	1	-4778	\N	C	2019-12-20 22:13:53.799521+00	4927
4777	-3038	13	173	KFL 1013@Kärl	\N	\N	1	1	-4777	\N	C	2019-12-20 22:13:53.799521+00	4928
4776	-3038	13	173	KFL 1012@Kärl	\N	\N	1	1	-4776	\N	C	2019-12-20 22:13:53.799521+00	4929
4775	-3038	13	173	KFL 1011@Kärl	\N	\N	1	1	-4775	\N	C	2019-12-20 22:13:53.799521+00	4930
4774	-3038	13	173	KFL 1010@Kärl	\N	\N	1	1	-4774	\N	C	2019-12-20 22:13:53.799521+00	4931
4773	-3038	13	173	KFL 1009@Kärl	\N	\N	1	1	-4773	\N	C	2019-12-20 22:13:53.799521+00	4932
4772	-3038	13	173	KFL 1008@Kärl	\N	\N	1	1	-4772	\N	C	2019-12-20 22:13:53.799521+00	4933
4771	-3038	13	173	KFL 1007@Kärl	\N	\N	1	1	-4771	\N	C	2019-12-20 22:13:53.799521+00	4934
4770	-3038	13	173	KFL 1006@Kärl	\N	\N	1	1	-4770	\N	C	2019-12-20 22:13:53.799521+00	4935
4769	-3038	13	173	KFL 1005@Kärl	\N	\N	1	1	-4769	\N	C	2019-12-20 22:13:53.799521+00	4936
4768	-3038	13	173	KFL 1004@Kärl	\N	\N	1	1	-4768	\N	C	2019-12-20 22:13:53.799521+00	4937
4767	-3038	13	173	KFL 1003@Kärl	\N	\N	1	1	-4767	\N	C	2019-12-20 22:13:53.799521+00	4938
4766	-3038	13	173	KFL 1002@Kärl	\N	\N	1	1	-4766	\N	C	2019-12-20 22:13:53.799521+00	4939
4765	-3038	13	173	KFL 1001@Kärl	\N	\N	1	1	-4765	\N	C	2019-12-20 22:13:53.799521+00	4940
4764	-3038	13	173	KFL 1000@Kärl	\N	\N	1	1	-4764	\N	C	2019-12-20 22:13:53.799521+00	4941
4763	-3038	13	173	KFL 999@Kärl	\N	\N	1	1	-4763	\N	C	2019-12-20 22:13:53.799521+00	4942
4762	-3038	13	173	KFL 998@Kärl	\N	\N	1	1	-4762	\N	C	2019-12-20 22:13:53.799521+00	4943
4761	-3038	13	173	KFL 997@Kärl	\N	\N	1	1	-4761	\N	C	2019-12-20 22:13:53.799521+00	4944
4760	-3038	13	173	KFL 996@Kärl	\N	\N	1	1	-4760	\N	C	2019-12-20 22:13:53.799521+00	4945
4759	-3038	13	173	KFL 995@Kärl	\N	\N	1	1	-4759	\N	C	2019-12-20 22:13:53.799521+00	4946
4758	-3038	13	173	KFL 994@Kärl	\N	\N	1	1	-4758	\N	C	2019-12-20 22:13:53.799521+00	4947
4757	-3038	13	173	KFL 993@Kärl	\N	\N	1	1	-4757	\N	C	2019-12-20 22:13:53.799521+00	4948
4756	-3038	13	173	KFL 992@Kärl	\N	\N	1	1	-4756	\N	C	2019-12-20 22:13:53.799521+00	4949
4755	-3038	13	173	KFL 991@Kärl	\N	\N	1	1	-4755	\N	C	2019-12-20 22:13:53.799521+00	4950
4754	-3038	13	173	KFL 990@Kärl	\N	\N	1	1	-4754	\N	C	2019-12-20 22:13:53.799521+00	4951
4753	-3038	13	173	KFL 989@Kärl	\N	\N	1	1	-4753	\N	C	2019-12-20 22:13:53.799521+00	4952
4752	-3038	13	173	KFL 988@Kärl	\N	\N	1	1	-4752	\N	C	2019-12-20 22:13:53.799521+00	4953
4751	-3038	13	173	KFL 987@Kärl	\N	\N	1	1	-4751	\N	C	2019-12-20 22:13:53.799521+00	4954
4750	-3038	13	173	KFL 986@Kärl	\N	\N	1	1	-4750	\N	C	2019-12-20 22:13:53.799521+00	4955
4749	-3038	13	173	KFL 985@Kärl	\N	\N	1	1	-4749	\N	C	2019-12-20 22:13:53.799521+00	4956
4748	-3038	13	173	KFL 984@Kärl	\N	\N	1	1	-4748	\N	C	2019-12-20 22:13:53.799521+00	4957
4747	-3038	13	173	KFL 983@Kärl	\N	\N	1	1	-4747	\N	C	2019-12-20 22:13:53.799521+00	4958
4746	-3038	13	173	KFL 982@Kärl	\N	\N	1	1	-4746	\N	C	2019-12-20 22:13:53.799521+00	4959
4745	-3038	13	173	KFL 981@Kärl	\N	\N	1	1	-4745	\N	C	2019-12-20 22:13:53.799521+00	4960
4744	-3038	13	173	KFL 980@Kärl	\N	\N	1	1	-4744	\N	C	2019-12-20 22:13:53.799521+00	4961
4743	-3038	13	173	KFL 979@Kärl	\N	\N	1	1	-4743	\N	C	2019-12-20 22:13:53.799521+00	4962
4742	-3038	13	173	KFL 978@Kärl	\N	\N	1	1	-4742	\N	C	2019-12-20 22:13:53.799521+00	4963
4741	-3038	13	173	KFL 977@Kärl	\N	\N	1	1	-4741	\N	C	2019-12-20 22:13:53.799521+00	4964
4740	-3038	13	173	KFL 976@Kärl	\N	\N	1	1	-4740	\N	C	2019-12-20 22:13:53.799521+00	4965
4739	-3038	13	173	KFL 975@Kärl	\N	\N	1	1	-4739	\N	C	2019-12-20 22:13:53.799521+00	4966
4738	-3038	13	173	KFL 974@Kärl	\N	\N	1	1	-4738	\N	C	2019-12-20 22:13:53.799521+00	4967
4737	-3038	13	173	KFL 973@Kärl	\N	\N	1	1	-4737	\N	C	2019-12-20 22:13:53.799521+00	4968
4736	-3038	13	173	KFL 972@Kärl	\N	\N	1	1	-4736	\N	C	2019-12-20 22:13:53.799521+00	4969
4735	-3038	13	173	KFL 971@Kärl	\N	\N	1	1	-4735	\N	C	2019-12-20 22:13:53.799521+00	4970
4734	-3038	13	173	KFL 970@Kärl	\N	\N	1	1	-4734	\N	C	2019-12-20 22:13:53.799521+00	4971
4733	-3038	13	173	KFL 969@Kärl	\N	\N	1	1	-4733	\N	C	2019-12-20 22:13:53.799521+00	4972
4732	-3038	13	173	KFL 968@Kärl	\N	\N	1	1	-4732	\N	C	2019-12-20 22:13:53.799521+00	4973
4731	-3038	13	173	KFL 967@Kärl	\N	\N	1	1	-4731	\N	C	2019-12-20 22:13:53.799521+00	4974
4730	-3038	13	173	KFL 966@Kärl	\N	\N	1	1	-4730	\N	C	2019-12-20 22:13:53.799521+00	4975
4729	-3038	13	173	KFL 965@Kärl	\N	\N	1	1	-4729	\N	C	2019-12-20 22:13:53.799521+00	4976
4728	-3038	13	173	KFL 964@Kärl	\N	\N	1	1	-4728	\N	C	2019-12-20 22:13:53.799521+00	4977
4727	-3038	13	173	KFL 963@Kärl	\N	\N	1	1	-4727	\N	C	2019-12-20 22:13:53.799521+00	4978
4726	-3038	13	173	KFL 962@Kärl	\N	\N	1	1	-4726	\N	C	2019-12-20 22:13:53.799521+00	4979
4725	-3038	13	173	KFL 961@Kärl	\N	\N	1	1	-4725	\N	C	2019-12-20 22:13:53.799521+00	4980
4724	-3038	13	173	KFL 960@Kärl	\N	\N	1	1	-4724	\N	C	2019-12-20 22:13:53.799521+00	4981
4723	-3038	13	173	KFL 959@Kärl	\N	\N	1	1	-4723	\N	C	2019-12-20 22:13:53.799521+00	4982
4722	-3038	13	173	KFL 958@Kärl	\N	\N	1	1	-4722	\N	C	2019-12-20 22:13:53.799521+00	4983
4721	-3038	13	173	KFL 957@Kärl	\N	\N	1	1	-4721	\N	C	2019-12-20 22:13:53.799521+00	4984
4720	-3038	13	173	KFL 956@Kärl	\N	\N	1	1	-4720	\N	C	2019-12-20 22:13:53.799521+00	4985
4719	-3038	13	173	KFL 955@Kärl	\N	\N	1	1	-4719	\N	C	2019-12-20 22:13:53.799521+00	4986
4718	-3038	13	173	KFL 954@Kärl	\N	\N	1	1	-4718	\N	C	2019-12-20 22:13:53.799521+00	4987
4717	-3038	13	173	KFL 953@Kärl	\N	\N	1	1	-4717	\N	C	2019-12-20 22:13:53.799521+00	4988
4716	-3038	13	173	KFL 952@Kärl	\N	\N	1	1	-4716	\N	C	2019-12-20 22:13:53.799521+00	4989
4715	-3038	13	173	KFL 951@Kärl	\N	\N	1	1	-4715	\N	C	2019-12-20 22:13:53.799521+00	4990
4714	-3038	13	173	KFL 950@Kärl	\N	\N	1	1	-4714	\N	C	2019-12-20 22:13:53.799521+00	4991
4713	-3038	13	173	KFL 949@Kärl	\N	\N	1	1	-4713	\N	C	2019-12-20 22:13:53.799521+00	4992
4712	-3038	13	173	KFL 948@Kärl	\N	\N	1	1	-4712	\N	C	2019-12-20 22:13:53.799521+00	4993
4711	-3038	13	173	KFL 947@Kärl	\N	\N	1	1	-4711	\N	C	2019-12-20 22:13:53.799521+00	4994
4710	-3038	13	173	KFL 946@Kärl	\N	\N	1	1	-4710	\N	C	2019-12-20 22:13:53.799521+00	4995
4709	-3038	13	173	KFL 945@Kärl	\N	\N	1	1	-4709	\N	C	2019-12-20 22:13:53.799521+00	4996
4708	-3038	13	173	KFL 944@Kärl	\N	\N	1	1	-4708	\N	C	2019-12-20 22:13:53.799521+00	4997
4707	-3038	13	173	KFL 943@Kärl	\N	\N	1	1	-4707	\N	C	2019-12-20 22:13:53.799521+00	4998
4706	-3038	13	173	KFL 942@Kärl	\N	\N	1	1	-4706	\N	C	2019-12-20 22:13:53.799521+00	4999
4705	-3038	13	173	KFL 941@Kärl	\N	\N	1	1	-4705	\N	C	2019-12-20 22:13:53.799521+00	5000
4704	-3038	13	173	KFL 940@Kärl	\N	\N	1	1	-4704	\N	C	2019-12-20 22:13:53.799521+00	5001
4703	-3038	13	173	KFL 939@Kärl	\N	\N	1	1	-4703	\N	C	2019-12-20 22:13:53.799521+00	5002
4702	-3038	13	173	KFL 938@Kärl	\N	\N	1	1	-4702	\N	C	2019-12-20 22:13:53.799521+00	5003
4701	-3038	13	173	KFL 937@Kärl	\N	\N	1	1	-4701	\N	C	2019-12-20 22:13:53.799521+00	5004
4700	-3160	13	173	KFL 934@Kärl	\N	\N	1	1	-4700	\N	C	2019-12-20 22:13:53.799521+00	5005
4699	-3160	13	173	KFL 933@Kärl	\N	\N	1	1	-4699	\N	C	2019-12-20 22:13:53.799521+00	5006
4698	-3160	13	173	KFL 932@Sländtrissa &amp; vävtyngd	\N	\N	1	1	-4698	\N	C	2019-12-20 22:13:53.799521+00	5007
4697	-3160	13	173	KFL 931@Kärl	\N	\N	1	1	-4697	\N	C	2019-12-20 22:13:53.799521+00	5008
4696	-3160	13	173	KFL 930@Kärl	\N	\N	1	1	-4696	\N	C	2019-12-20 22:13:53.799521+00	5009
4695	-3160	13	173	KFL 929@Kärl	\N	\N	1	1	-4695	\N	C	2019-12-20 22:13:53.799521+00	5010
4694	-3160	13	173	KFL 928@Kärl	\N	\N	1	1	-4694	\N	C	2019-12-20 22:13:53.799521+00	5011
4693	-3160	13	173	KFL 927@Kärl	\N	\N	1	1	-4693	\N	C	2019-12-20 22:13:53.799521+00	5012
4692	-3000	13	173	KFL 926@Kärl	\N	\N	1	1	-4692	\N	C	2019-12-20 22:13:53.799521+00	5013
4691	-3000	13	173	KFL 925@Kärl	\N	\N	1	1	-4691	\N	C	2019-12-20 22:13:53.799521+00	5014
4690	-3000	13	173	KFL 924@Kärl	\N	\N	1	1	-4690	\N	C	2019-12-20 22:13:53.799521+00	5015
4689	-3000	13	173	KFL 923@Kärl	\N	\N	1	1	-4689	\N	C	2019-12-20 22:13:53.799521+00	5016
4688	-3000	13	173	KFL 922@Kärl	\N	\N	1	1	-4688	\N	C	2019-12-20 22:13:53.799521+00	5017
4687	-3000	13	173	KFL 921@Kärl	\N	\N	1	1	-4687	\N	C	2019-12-20 22:13:53.799521+00	5018
4686	-3000	13	173	KFL 920@Kärl	\N	\N	1	1	-4686	\N	C	2019-12-20 22:13:53.799521+00	5019
4685	-3000	13	173	KFL 919@Kärl	\N	\N	1	1	-4685	\N	C	2019-12-20 22:13:53.799521+00	5020
4684	-3000	13	173	KFL 918@Kärl	\N	\N	1	1	-4684	\N	C	2019-12-20 22:13:53.799521+00	5021
4683	-3000	13	173	KFL 917@Kärl	\N	\N	1	1	-4683	\N	C	2019-12-20 22:13:53.799521+00	5022
4682	-3000	13	173	KFL 915@Kärl	\N	\N	1	1	-4682	\N	C	2019-12-20 22:13:53.799521+00	5023
4681	-3000	13	173	KFL 914@Kärl	\N	\N	1	1	-4681	\N	C	2019-12-20 22:13:53.799521+00	5024
4680	-3108	13	173	KFL 892@Kärl	\N	\N	1	1	-4680	\N	C	2019-12-20 22:13:53.799521+00	5025
4679	-2995	13	173	KFL 889@Kärl	\N	\N	1	1	-4679	\N	C	2019-12-20 22:13:53.799521+00	5026
4678	-3057	13	173	KFL 885@Kärl	\N	\N	1	1	-4678	\N	C	2019-12-20 22:13:53.799521+00	5027
4677	-3130	13	173	KFL 884@Kärl	\N	\N	1	1	-4677	\N	C	2019-12-20 22:13:53.799521+00	5028
4676	-3276	13	173	KFL 882@Kärl	\N	\N	1	1	-4676	\N	C	2019-12-20 22:13:53.799521+00	5029
4675	-3186	13	173	KFL 881@Kärl	\N	\N	1	1	-4675	\N	C	2019-12-20 22:13:53.799521+00	5030
4674	-3000	13	173	KFL 879@Kärl	\N	\N	1	1	-4674	\N	C	2019-12-20 22:13:53.799521+00	5031
4673	-3342	13	173	KFL 878@Kärl	\N	\N	1	1	-4673	\N	C	2019-12-20 22:13:53.799521+00	5032
4672	-3000	13	173	KFL 877@Kärl	\N	\N	1	1	-4672	\N	C	2019-12-20 22:13:53.799521+00	5033
4671	-3197	13	173	KFL 876@Kärl	\N	\N	1	1	-4671	\N	C	2019-12-20 22:13:53.799521+00	5034
4670	-3000	13	173	KFL 872@odef	\N	\N	1	1	-4670	\N	C	2019-12-20 22:13:53.799521+00	5035
4669	-3000	13	173	KFL 871@Kärl	\N	\N	1	1	-4669	\N	C	2019-12-20 22:13:53.799521+00	5036
4668	-3000	13	173	KFL 870@Kärl	\N	\N	1	1	-4668	\N	C	2019-12-20 22:13:53.799521+00	5037
4667	-3375	13	173	KFL 867@Kärl	\N	\N	1	1	-4667	\N	C	2019-12-20 22:13:53.799521+00	5038
4666	-3000	13	173	KFL 866@Kärl	\N	\N	1	1	-4666	\N	C	2019-12-20 22:13:53.799521+00	5039
4665	-3109	13	173	KFL 865@Kärl	\N	\N	1	1	-4665	\N	C	2019-12-20 22:13:53.799521+00	5040
4664	-3000	13	173	KFL 864@Kärl	\N	\N	1	1	-4664	\N	C	2019-12-20 22:13:53.799521+00	5041
4663	-3000	13	173	KFL 863@Kärl	\N	\N	1	1	-4663	\N	C	2019-12-20 22:13:53.799521+00	5042
4662	-3000	13	173	KFL 862@Kärl	\N	\N	1	1	-4662	\N	C	2019-12-20 22:13:53.799521+00	5043
4661	-3000	13	173	KFL 861@Kärl	\N	\N	1	1	-4661	\N	C	2019-12-20 22:13:53.799521+00	5044
4660	-3132	13	173	KFL 860@Kärl	\N	\N	1	1	-4660	\N	C	2019-12-20 22:13:53.799521+00	5045
4659	-3052	13	173	KFL 859@Kärl	\N	\N	1	1	-4659	\N	C	2019-12-20 22:13:53.799521+00	5046
4658	-3266	13	173	KFL 858@Kärl	\N	\N	1	1	-4658	\N	C	2019-12-20 22:13:53.799521+00	5047
4657	-2998	13	173	KFL 857@Kärl	\N	\N	1	1	-4657	\N	C	2019-12-20 22:13:53.799521+00	5048
4656	-3145	13	173	KFL 856@Kärl	\N	\N	1	1	-4656	\N	C	2019-12-20 22:13:53.799521+00	5049
4655	-3000	13	173	KFL 855@Kärl	\N	\N	1	1	-4655	\N	C	2019-12-20 22:13:53.799521+00	5050
4654	-3378	13	173	KFL 854@Kärl	\N	\N	1	1	-4654	\N	C	2019-12-20 22:13:53.799521+00	5051
4653	-3000	13	173	KFL 853@Kärl	\N	\N	1	1	-4653	\N	C	2019-12-20 22:13:53.799521+00	5052
4652	-3000	13	173	KFL 852@Kärl	\N	\N	1	1	-4652	\N	C	2019-12-20 22:13:53.799521+00	5053
4651	-3000	13	173	KFL 851@Kärl	\N	\N	1	1	-4651	\N	C	2019-12-20 22:13:53.799521+00	5054
4650	-3000	13	173	KFL 850@Kärl	\N	\N	1	1	-4650	\N	C	2019-12-20 22:13:53.799521+00	5055
4649	-3000	13	173	KFL 849@Kärl	\N	\N	1	1	-4649	\N	C	2019-12-20 22:13:53.799521+00	5056
4648	-3384	13	173	KFL 848@Kärl	\N	\N	1	1	-4648	\N	C	2019-12-20 22:13:53.799521+00	5057
4647	-3154	13	173	KFL 847@Kärl	\N	\N	1	1	-4647	\N	C	2019-12-20 22:13:53.799521+00	5058
4646	-3230	13	173	KFL 846@Kärl	\N	\N	1	1	-4646	\N	C	2019-12-20 22:13:53.799521+00	5059
4645	-3348	13	173	KFL 845@Kärl	\N	\N	1	1	-4645	\N	C	2019-12-20 22:13:53.799521+00	5060
4644	-3093	13	173	KFL 844@Kärl	\N	\N	1	1	-4644	\N	C	2019-12-20 22:13:53.799521+00	5061
4643	-3375	13	173	KFL 843@Kärl	\N	\N	1	1	-4643	\N	C	2019-12-20 22:13:53.799521+00	5062
4642	-3381	13	173	KFL 838@Kärl	\N	\N	1	1	-4642	\N	C	2019-12-20 22:13:53.799521+00	5063
4641	-3369	13	173	KFL 837@Kärl	\N	\N	1	1	-4641	\N	C	2019-12-20 22:13:53.799521+00	5064
4640	-3060	13	173	KFL 836@Kärl	\N	\N	1	1	-4640	\N	C	2019-12-20 22:13:53.799521+00	5065
4639	-3233	13	173	KFL 835@Kärl	\N	\N	1	1	-4639	\N	C	2019-12-20 22:13:53.799521+00	5066
4638	-3376	13	173	KFL 834@Kärl	\N	\N	1	1	-4638	\N	C	2019-12-20 22:13:53.799521+00	5067
4637	-3327	13	173	KFL 832@Kärl	\N	\N	1	1	-4637	\N	C	2019-12-20 22:13:53.799521+00	5068
4636	-3321	13	173	KFL 831@Kärl	\N	\N	1	1	-4636	\N	C	2019-12-20 22:13:53.799521+00	5069
4635	-3175	13	173	KFL 830@Kärl	\N	\N	1	1	-4635	\N	C	2019-12-20 22:13:53.799521+00	5070
4634	-3067	13	173	KFL 828@Kärl	\N	\N	1	1	-4634	\N	C	2019-12-20 22:13:53.799521+00	5071
4633	-3315	13	173	KFL 827@Kärl	\N	\N	1	1	-4633	\N	C	2019-12-20 22:13:53.799521+00	5072
4632	-3178	13	173	KFL 826@Kärl	\N	\N	1	1	-4632	\N	C	2019-12-20 22:13:53.799521+00	5073
4631	-3070	13	173	KFL 825@Kärl	\N	\N	1	1	-4631	\N	C	2019-12-20 22:13:53.799521+00	5074
4630	-3064	13	173	KFL 824@Kärl	\N	\N	1	1	-4630	\N	C	2019-12-20 22:13:53.799521+00	5075
4629	-2988	13	173	KFL 820@Kärl	\N	\N	1	1	-4629	\N	C	2019-12-20 22:13:53.799521+00	5076
4628	-3054	13	173	KFL 819@Kärl	\N	\N	1	1	-4628	\N	C	2019-12-20 22:13:53.799521+00	5077
4627	-3000	13	173	KFL 817@Kärl	\N	\N	1	1	-4627	\N	C	2019-12-20 22:13:53.799521+00	5078
4626	-3000	13	173	KFL 816@Kärl	\N	\N	1	1	-4626	\N	C	2019-12-20 22:13:53.799521+00	5079
4625	-3000	13	173	KFL 815@Kärl	\N	\N	1	1	-4625	\N	C	2019-12-20 22:13:53.799521+00	5080
4624	-3000	13	173	KFL 814@Kärl	\N	\N	1	1	-4624	\N	C	2019-12-20 22:13:53.799521+00	5081
4623	-3000	13	173	KFL 813@Kärl	\N	\N	1	1	-4623	\N	C	2019-12-20 22:13:53.799521+00	5082
4622	-3000	13	173	KFL 812@Kärl	\N	\N	1	1	-4622	\N	C	2019-12-20 22:13:53.799521+00	5083
4621	-3000	13	173	KFL 811@Kärl	\N	\N	1	1	-4621	\N	C	2019-12-20 22:13:53.799521+00	5084
4620	-3000	13	173	KFL 810@Kärl	\N	\N	1	1	-4620	\N	C	2019-12-20 22:13:53.799521+00	5085
4619	-3000	13	173	KFL 809@Kärl	\N	\N	1	1	-4619	\N	C	2019-12-20 22:13:53.799521+00	5086
4618	-3000	13	173	KFL 808@Kärl	\N	\N	1	1	-4618	\N	C	2019-12-20 22:13:53.799521+00	5087
4617	-3000	13	173	KFL 807@Kärl	\N	\N	1	1	-4617	\N	C	2019-12-20 22:13:53.799521+00	5088
4616	-3000	13	173	KFL 806@Kärl	\N	\N	1	1	-4616	\N	C	2019-12-20 22:13:53.799521+00	5089
4615	-3000	13	173	KFL 805@Kärl	\N	\N	1	1	-4615	\N	C	2019-12-20 22:13:53.799521+00	5090
4614	-3000	13	173	KFL 804@Kärl	\N	\N	1	1	-4614	\N	C	2019-12-20 22:13:53.799521+00	5091
4613	-3000	13	173	KFL 803@Kärl	\N	\N	1	1	-4613	\N	C	2019-12-20 22:13:53.799521+00	5092
4612	-3000	13	173	KFL 802@Kärl	\N	\N	1	1	-4612	\N	C	2019-12-20 22:13:53.799521+00	5093
4611	-3000	13	173	KFL 801@Kärl	\N	\N	1	1	-4611	\N	C	2019-12-20 22:13:53.799521+00	5094
4610	-3000	13	173	KFL 800@Kärl	\N	\N	1	1	-4610	\N	C	2019-12-20 22:13:53.799521+00	5095
4609	-3000	13	173	KFL 799@Kärl	\N	\N	1	1	-4609	\N	C	2019-12-20 22:13:53.799521+00	5096
4608	-3000	13	173	KFL 798@Kärl	\N	\N	1	1	-4608	\N	C	2019-12-20 22:13:53.799521+00	5097
4607	-3000	13	173	KFL 797@Kärl	\N	\N	1	1	-4607	\N	C	2019-12-20 22:13:53.799521+00	5098
4606	-3000	13	173	KFL 796@Kärl	\N	\N	1	1	-4606	\N	C	2019-12-20 22:13:53.799521+00	5099
4605	-3000	13	173	KFL 795@Kärl	\N	\N	1	1	-4605	\N	C	2019-12-20 22:13:53.799521+00	5100
4604	-3000	13	173	KFL 794@Kärl	\N	\N	1	1	-4604	\N	C	2019-12-20 22:13:53.799521+00	5101
4603	-3000	13	173	KFL 793@Kärl	\N	\N	1	1	-4603	\N	C	2019-12-20 22:13:53.799521+00	5102
4602	-3000	13	173	KFL 792@Kärl	\N	\N	1	1	-4602	\N	C	2019-12-20 22:13:53.799521+00	5103
4601	-3000	13	173	KFL 791@Kärl	\N	\N	1	1	-4601	\N	C	2019-12-20 22:13:53.799521+00	5104
4600	-3000	13	173	KFL 790@Kärl	\N	\N	1	1	-4600	\N	C	2019-12-20 22:13:53.799521+00	5105
4599	-3000	13	173	KFL 789@Kärl	\N	\N	1	1	-4599	\N	C	2019-12-20 22:13:53.799521+00	5106
4598	-2995	13	173	KFL 788@Kärl	\N	\N	1	1	-4598	\N	C	2019-12-20 22:13:53.799521+00	5107
4597	-3174	13	173	KFL 787@Kärl	\N	\N	1	1	-4597	\N	C	2019-12-20 22:13:53.799521+00	5108
4596	-3283	13	173	KFL 786@Kärl	\N	\N	1	1	-4596	\N	C	2019-12-20 22:13:53.799521+00	5109
4595	-2984	13	173	KFL 785@Kärl	\N	\N	1	1	-4595	\N	C	2019-12-20 22:13:53.799521+00	5110
4594	-3091	13	173	KFL 784@Kärl	\N	\N	1	1	-4594	\N	C	2019-12-20 22:13:53.799521+00	5111
4593	-3315	13	173	KFL 783@Kärl	\N	\N	1	1	-4593	\N	C	2019-12-20 22:13:53.799521+00	5112
4592	-2995	13	173	KFL 782@Kärl	\N	\N	1	1	-4592	\N	C	2019-12-20 22:13:53.799521+00	5113
4591	-2995	13	173	KFL 781@Kärl	\N	\N	1	1	-4591	\N	C	2019-12-20 22:13:53.799521+00	5114
4590	-3283	13	173	KFL 780@Kärl	\N	\N	1	1	-4590	\N	C	2019-12-20 22:13:53.799521+00	5115
4589	-3356	13	173	KFL 779@Kärl	\N	\N	1	1	-4589	\N	C	2019-12-20 22:13:53.799521+00	5116
4588	-3283	13	173	KFL 778@Kärl	\N	\N	1	1	-4588	\N	C	2019-12-20 22:13:53.799521+00	5117
4587	-2995	13	173	KFL 777@Kärl	\N	\N	1	1	-4587	\N	C	2019-12-20 22:13:53.799521+00	5118
4586	-2995	13	173	KFL 776@Kärl	\N	\N	1	1	-4586	\N	C	2019-12-20 22:13:53.799521+00	5119
4585	-3251	13	173	KFL 775@Kärl	\N	\N	1	1	-4585	\N	C	2019-12-20 22:13:53.799521+00	5120
4584	-2995	13	173	KFL 774@Kärl	\N	\N	1	1	-4584	\N	C	2019-12-20 22:13:53.799521+00	5121
4583	-2995	13	173	KFL 773@Kärl	\N	\N	1	1	-4583	\N	C	2019-12-20 22:13:53.799521+00	5122
4582	-2984	13	173	KFL 772@Kärl	\N	\N	1	1	-4582	\N	C	2019-12-20 22:13:53.799521+00	5123
4581	-2995	13	173	KFL 771@Kärl	\N	\N	1	1	-4581	\N	C	2019-12-20 22:13:53.799521+00	5124
4580	-2995	13	173	KFL 770@Kärl	\N	\N	1	1	-4580	\N	C	2019-12-20 22:13:53.799521+00	5125
4579	-3283	13	173	KFL 769@Kärl	\N	\N	1	1	-4579	\N	C	2019-12-20 22:13:53.799521+00	5126
4578	-3356	13	173	KFL 768@Kärl	\N	\N	1	1	-4578	\N	C	2019-12-20 22:13:53.799521+00	5127
4577	-3283	13	173	KFL 767@Kärl	\N	\N	1	1	-4577	\N	C	2019-12-20 22:13:53.799521+00	5128
4576	-3115	13	173	KFL 766@Kärl	\N	\N	1	1	-4576	\N	C	2019-12-20 22:13:53.799521+00	5129
4575	-3115	13	173	KFL 736@Kärl	\N	\N	1	1	-4575	\N	C	2019-12-20 22:13:53.799521+00	5130
4574	-3115	13	173	KFL 735@Kärl	\N	\N	1	1	-4574	\N	C	2019-12-20 22:13:53.799521+00	5131
4573	-3115	13	173	KFL 734@Kärl	\N	\N	1	1	-4573	\N	C	2019-12-20 22:13:53.799521+00	5132
4572	-3115	13	173	KFL 733@Lerklining	\N	\N	1	1	-4572	\N	C	2019-12-20 22:13:53.799521+00	5133
4571	-3115	13	173	KFL 732@Sländtrissa &amp; vävtyngd	\N	\N	1	1	-4571	\N	C	2019-12-20 22:13:53.799521+00	5134
4570	-3115	13	173	KFL 731@Blästermunstycke	\N	\N	1	1	-4570	\N	C	2019-12-20 22:13:53.799521+00	5135
4569	-3115	13	173	KFL 730@odef	\N	\N	1	1	-4569	\N	C	2019-12-20 22:13:53.799521+00	5136
4568	-3115	13	173	KFL 729@odef	\N	\N	1	1	-4568	\N	C	2019-12-20 22:13:53.799521+00	5137
4567	-3115	13	173	KFL 728@odef	\N	\N	1	1	-4567	\N	C	2019-12-20 22:13:53.799521+00	5138
4566	-3115	13	173	KFL 727@Kärl	\N	\N	1	1	-4566	\N	C	2019-12-20 22:13:53.799521+00	5139
4565	-3115	13	173	KFL 726@Degel	\N	\N	1	1	-4565	\N	C	2019-12-20 22:13:53.799521+00	5140
4564	-3115	13	173	KFL 725@Kärl	\N	\N	1	1	-4564	\N	C	2019-12-20 22:13:53.799521+00	5141
4563	-3115	13	173	KFL 724@Sländtrissa &amp; vävtyngd	\N	\N	1	1	-4563	\N	C	2019-12-20 22:13:53.799521+00	5142
4562	-3115	13	173	KFL 723@Degel	\N	\N	1	1	-4562	\N	C	2019-12-20 22:13:53.799521+00	5143
4561	-3086	13	173	KFL 722@Kärl	\N	\N	1	1	-4561	\N	C	2019-12-20 22:13:53.799521+00	5144
4560	-3086	13	173	KFL 721@Kärl	\N	\N	1	1	-4560	\N	C	2019-12-20 22:13:53.799521+00	5145
4559	-3086	13	173	KFL 720@Kärl	\N	\N	1	1	-4559	\N	C	2019-12-20 22:13:53.799521+00	5146
4558	-3086	13	173	KFL 719@Kärl	\N	\N	1	1	-4558	\N	C	2019-12-20 22:13:53.799521+00	5147
4557	-3086	13	173	KFL 718@Kärl	\N	\N	1	1	-4557	\N	C	2019-12-20 22:13:53.799521+00	5148
4556	-3086	13	173	KFL 717@Kärl	\N	\N	1	1	-4556	\N	C	2019-12-20 22:13:53.799521+00	5149
4555	-3086	13	173	KFL 716@Kärl	\N	\N	1	1	-4555	\N	C	2019-12-20 22:13:53.799521+00	5150
4554	-3086	13	173	KFL 715@Kärl	\N	\N	1	1	-4554	\N	C	2019-12-20 22:13:53.799521+00	5151
4553	-3086	13	173	KFL 714@Kärl	\N	\N	1	1	-4553	\N	C	2019-12-20 22:13:53.799521+00	5152
4552	-3086	13	173	KFL 713@Kärl	\N	\N	1	1	-4552	\N	C	2019-12-20 22:13:53.799521+00	5153
4551	-3086	13	173	KFL 712@Kärl	\N	\N	1	1	-4551	\N	C	2019-12-20 22:13:53.799521+00	5154
4550	-3086	13	173	KFL 711@Kärl	\N	\N	1	1	-4550	\N	C	2019-12-20 22:13:53.799521+00	5155
4549	-3091	13	173	KFL 710@Kärl	\N	\N	1	1	-4549	\N	C	2019-12-20 22:13:53.799521+00	5156
4548	-3091	13	173	KFL 709@Kärl	\N	\N	1	1	-4548	\N	C	2019-12-20 22:13:53.799521+00	5157
4547	-3091	13	173	KFL 708@Kärl	\N	\N	1	1	-4547	\N	C	2019-12-20 22:13:53.799521+00	5158
4546	-3091	13	173	KFL 706@Kärl	\N	\N	1	1	-4546	\N	C	2019-12-20 22:13:53.799521+00	5159
4545	-3091	13	173	KFL 705@Kärl	\N	\N	1	1	-4545	\N	C	2019-12-20 22:13:53.799521+00	5160
4544	-3091	13	173	KFL 704@Kärl	\N	\N	1	1	-4544	\N	C	2019-12-20 22:13:53.799521+00	5161
4543	-3091	13	173	KFL 703@Kärl	\N	\N	1	1	-4543	\N	C	2019-12-20 22:13:53.799521+00	5162
4542	-3091	13	173	KFL 702@Kärl	\N	\N	1	1	-4542	\N	C	2019-12-20 22:13:53.799521+00	5163
4541	-3091	13	173	KFL 701@Kärl	\N	\N	1	1	-4541	\N	C	2019-12-20 22:13:53.799521+00	5164
4540	-3091	13	173	KFL 700@Kärl	\N	\N	1	1	-4540	\N	C	2019-12-20 22:13:53.799521+00	5165
4539	-3091	13	173	KFL 699@Kärl	\N	\N	1	1	-4539	\N	C	2019-12-20 22:13:53.799521+00	5166
4538	-3091	13	173	KFL 698@Kärl	\N	\N	1	1	-4538	\N	C	2019-12-20 22:13:53.799521+00	5167
4537	-3091	13	173	KFL 697@Kärl	\N	\N	1	1	-4537	\N	C	2019-12-20 22:13:53.799521+00	5168
4536	-3091	13	173	KFL 696@Kärl	\N	\N	1	1	-4536	\N	C	2019-12-20 22:13:53.799521+00	5169
4535	-3091	13	173	KFL 695@Kärl	\N	\N	1	1	-4535	\N	C	2019-12-20 22:13:53.799521+00	5170
4534	-3091	13	173	KFL 694@Kärl	\N	\N	1	1	-4534	\N	C	2019-12-20 22:13:53.799521+00	5171
4533	-3091	13	173	KFL 693@Kärl	\N	\N	1	1	-4533	\N	C	2019-12-20 22:13:53.799521+00	5172
4532	-3091	13	173	KFL 692@Kärl	\N	\N	1	1	-4532	\N	C	2019-12-20 22:13:53.799521+00	5173
4531	-3091	13	173	KFL 691@Kärl	\N	\N	1	1	-4531	\N	C	2019-12-20 22:13:53.799521+00	5174
4530	-3091	13	173	KFL 690@Kärl	\N	\N	1	1	-4530	\N	C	2019-12-20 22:13:53.799521+00	5175
4529	-3063	13	173	KFL 689@Kärl	\N	\N	1	1	-4529	\N	C	2019-12-20 22:13:53.799521+00	5176
4528	-3063	13	173	KFL 688@Kärl	\N	\N	1	1	-4528	\N	C	2019-12-20 22:13:53.799521+00	5177
4527	-3063	13	173	KFL 687@Degel	\N	\N	1	1	-4527	\N	C	2019-12-20 22:13:53.799521+00	5178
4526	-3063	13	173	KFL 686@Degel	\N	\N	1	1	-4526	\N	C	2019-12-20 22:13:53.799521+00	5179
4525	-3063	13	173	KFL 685@Lerklining	\N	\N	1	1	-4525	\N	C	2019-12-20 22:13:53.799521+00	5180
4524	-3063	13	173	KFL 684@Gjutform	\N	\N	1	1	-4524	\N	C	2019-12-20 22:13:53.799521+00	5181
4523	-3063	13	173	KFL 683@Kärl	\N	\N	1	1	-4523	\N	C	2019-12-20 22:13:53.799521+00	5182
4522	-3063	13	173	KFL 682@Kärl	\N	\N	1	1	-4522	\N	C	2019-12-20 22:13:53.799521+00	5183
4521	-3063	13	173	KFL 681@Kärl	\N	\N	1	1	-4521	\N	C	2019-12-20 22:13:53.799521+00	5184
4520	-3063	13	173	KFL 680@Lerklining	\N	\N	1	1	-4520	\N	C	2019-12-20 22:13:53.799521+00	5185
4519	-3090	13	173	KFL 671@Kärl	\N	\N	1	1	-4519	\N	C	2019-12-20 22:13:53.799521+00	5186
4518	-3090	13	173	KFL 670@Kärl	\N	\N	1	1	-4518	\N	C	2019-12-20 22:13:53.799521+00	5187
4517	-3090	13	173	KFL 669@Kärl	\N	\N	1	1	-4517	\N	C	2019-12-20 22:13:53.799521+00	5188
4516	-3090	13	173	KFL 668@Kärl	\N	\N	1	1	-4516	\N	C	2019-12-20 22:13:53.799521+00	5189
4515	-3090	13	173	KFL 667@Kärl	\N	\N	1	1	-4515	\N	C	2019-12-20 22:13:53.799521+00	5190
4514	-3090	13	173	KFL 666@Kärl	\N	\N	1	1	-4514	\N	C	2019-12-20 22:13:53.799521+00	5191
4513	-3090	13	173	KFL 665@Kärl	\N	\N	1	1	-4513	\N	C	2019-12-20 22:13:53.799521+00	5192
4512	-3090	13	173	KFL 664@Kärl	\N	\N	1	1	-4512	\N	C	2019-12-20 22:13:53.799521+00	5193
4511	-3118	13	173	KFL 663@Kärl	\N	\N	1	1	-4511	\N	C	2019-12-20 22:13:53.799521+00	5194
4510	-3219	13	173	KFL 662@Kärl	\N	\N	1	1	-4510	\N	C	2019-12-20 22:13:53.799521+00	5195
4509	-3219	13	173	KFL 661@Kärl	\N	\N	1	1	-4509	\N	C	2019-12-20 22:13:53.799521+00	5196
4508	-3194	13	173	KFL 660@Kärl	\N	\N	1	1	-4508	\N	C	2019-12-20 22:13:53.799521+00	5197
4507	-3194	13	173	KFL 659@Kärl	\N	\N	1	1	-4507	\N	C	2019-12-20 22:13:53.799521+00	5198
4506	-3047	13	173	KFL 657@Kärl	\N	\N	1	1	-4506	\N	C	2019-12-20 22:13:53.799521+00	5199
4505	-3295	13	173	KFL 656@Kärl	\N	\N	1	1	-4505	\N	C	2019-12-20 22:13:53.799521+00	5200
4504	-3015	13	173	KFL 655@Kärl	\N	\N	1	1	-4504	\N	C	2019-12-20 22:13:53.799521+00	5201
4503	-2989	13	173	KFL 654@Kärl	\N	\N	1	1	-4503	\N	C	2019-12-20 22:13:53.799521+00	5202
4502	-2989	13	173	KFL 653@Kärl	\N	\N	1	1	-4502	\N	C	2019-12-20 22:13:53.799521+00	5203
4501	-2989	13	173	KFL 652@Kärl	\N	\N	1	1	-4501	\N	C	2019-12-20 22:13:53.799521+00	5204
4500	-2989	13	173	KFL 651@Kärl	\N	\N	1	1	-4500	\N	C	2019-12-20 22:13:53.799521+00	5205
4499	-2989	13	173	KFL 650@Kärl	\N	\N	1	1	-4499	\N	C	2019-12-20 22:13:53.799521+00	5206
4498	-2989	13	173	KFL 649@Kärl	\N	\N	1	1	-4498	\N	C	2019-12-20 22:13:53.799521+00	5207
4497	-2989	13	173	KFL 648@Kärl	\N	\N	1	1	-4497	\N	C	2019-12-20 22:13:53.799521+00	5208
4496	-2989	13	173	KFL 647@Kärl	\N	\N	1	1	-4496	\N	C	2019-12-20 22:13:53.799521+00	5209
4495	-2989	13	173	KFL 646@Kärl	\N	\N	1	1	-4495	\N	C	2019-12-20 22:13:53.799521+00	5210
4494	-2989	13	173	KFL 645@Kärl	\N	\N	1	1	-4494	\N	C	2019-12-20 22:13:53.799521+00	5211
4493	-2989	13	173	KFL 644@Kärl	\N	\N	1	1	-4493	\N	C	2019-12-20 22:13:53.799521+00	5212
4492	-2989	13	173	KFL 643@Kärl	\N	\N	1	1	-4492	\N	C	2019-12-20 22:13:53.799521+00	5213
4491	-2989	13	173	KFL 642@Kärl	\N	\N	1	1	-4491	\N	C	2019-12-20 22:13:53.799521+00	5214
4490	-2989	13	173	KFL 641@Kärl	\N	\N	1	1	-4490	\N	C	2019-12-20 22:13:53.799521+00	5215
4489	-2989	13	173	KFL 640@Kärl	\N	\N	1	1	-4489	\N	C	2019-12-20 22:13:53.799521+00	5216
4488	-2989	13	173	KFL 639@Kärl	\N	\N	1	1	-4488	\N	C	2019-12-20 22:13:53.799521+00	5217
4487	-2989	13	173	KFL 638@Kärl	\N	\N	1	1	-4487	\N	C	2019-12-20 22:13:53.799521+00	5218
4486	-2989	13	173	KFL 637@Kärl	\N	\N	1	1	-4486	\N	C	2019-12-20 22:13:53.799521+00	5219
4485	-2989	13	173	KFL 636@Kärl	\N	\N	1	1	-4485	\N	C	2019-12-20 22:13:53.799521+00	5220
4484	-3191	13	173	KFL 634@Kärl	\N	\N	1	1	-4484	\N	C	2019-12-20 22:13:53.799521+00	5221
4483	-3364	13	173	KFL 633@Kärl	\N	\N	1	1	-4483	\N	C	2019-12-20 22:13:53.799521+00	5222
4482	-3374	13	173	KFL 627@Kärl	\N	\N	1	1	-4482	\N	C	2019-12-20 22:13:53.799521+00	5223
4481	-3373	13	173	KFL 626@Kärl	\N	\N	1	1	-4481	\N	C	2019-12-20 22:13:53.799521+00	5224
4480	-3357	13	173	KFL 625@Kärl	\N	\N	1	1	-4480	\N	C	2019-12-20 22:13:53.799521+00	5225
4479	-3328	13	173	KFL 624@Kärl	\N	\N	1	1	-4479	\N	C	2019-12-20 22:13:53.799521+00	5226
4478	-3292	13	173	KFL 623@Kärl	\N	\N	1	1	-4478	\N	C	2019-12-20 22:13:53.799521+00	5227
4477	-3086	13	173	KFL 615@Kärl	\N	\N	1	1	-4477	\N	C	2019-12-20 22:13:53.799521+00	5228
4476	-3196	13	173	KFL 614@Kärl	\N	\N	1	1	-4476	\N	C	2019-12-20 22:13:53.799521+00	5229
4475	-3196	13	173	KFL 613@Kärl	\N	\N	1	1	-4475	\N	C	2019-12-20 22:13:53.799521+00	5230
4474	-3116	13	173	KFL 612@Lerblock	\N	\N	1	1	-4474	\N	C	2019-12-20 22:13:53.799521+00	5231
4473	-3116	13	173	KFL 611@Lerblock	\N	\N	1	1	-4473	\N	C	2019-12-20 22:13:53.799521+00	5232
4472	-2986	13	173	KFL 610@Kärl	\N	\N	1	1	-4472	\N	C	2019-12-20 22:13:53.799521+00	5233
4471	-3049	13	173	KFL 608@Kärl	\N	\N	1	1	-4471	\N	C	2019-12-20 22:13:53.799521+00	5234
4470	-3049	13	173	KFL 605@Kärl	\N	\N	1	1	-4470	\N	C	2019-12-20 22:13:53.799521+00	5235
4469	-3365	13	173	KFL 604@Kärl	\N	\N	1	1	-4469	\N	C	2019-12-20 22:13:53.799521+00	5236
4468	-3365	13	173	KFL 603@Kärl	\N	\N	1	1	-4468	\N	C	2019-12-20 22:13:53.799521+00	5237
4467	-3365	13	173	KFL 602@Kärl	\N	\N	1	1	-4467	\N	C	2019-12-20 22:13:53.799521+00	5238
4466	-3365	13	173	KFL 601@Kärl	\N	\N	1	1	-4466	\N	C	2019-12-20 22:13:53.799521+00	5239
4465	-3365	13	173	KFL 600@Kärl	\N	\N	1	1	-4465	\N	C	2019-12-20 22:13:53.799521+00	5240
4464	-3365	13	173	KFL 599@Kärl	\N	\N	1	1	-4464	\N	C	2019-12-20 22:13:53.799521+00	5241
4463	-3365	13	173	KFL 598@Kärl	\N	\N	1	1	-4463	\N	C	2019-12-20 22:13:53.799521+00	5242
4462	-3365	13	173	KFL 597@Kärl	\N	\N	1	1	-4462	\N	C	2019-12-20 22:13:53.799521+00	5243
4461	-3365	13	173	KFL 596@Kärl	\N	\N	1	1	-4461	\N	C	2019-12-20 22:13:53.799521+00	5244
4460	-3365	13	173	KFL 595@Kärl	\N	\N	1	1	-4460	\N	C	2019-12-20 22:13:53.799521+00	5245
4459	-3365	13	173	KFL 590@Kärl	\N	\N	1	1	-4459	\N	C	2019-12-20 22:13:53.799521+00	5246
4458	-2986	13	173	KFL 589@Kärl?	\N	\N	1	1	-4458	\N	C	2019-12-20 22:13:53.799521+00	5247
4457	-2986	13	173	KFL 588@Kärl?	\N	\N	1	1	-4457	\N	C	2019-12-20 22:13:53.799521+00	5248
4456	-2986	13	173	KFL 587@Kärl?	\N	\N	1	1	-4456	\N	C	2019-12-20 22:13:53.799521+00	5249
4455	-2986	13	173	KFL 586@Kärl?	\N	\N	1	1	-4455	\N	C	2019-12-20 22:13:53.799521+00	5250
4454	-2986	13	173	KFL 585@Kärl?	\N	\N	1	1	-4454	\N	C	2019-12-20 22:13:53.799521+00	5251
4453	-2986	13	173	KFL 584@Kärl	\N	\N	1	1	-4453	\N	C	2019-12-20 22:13:53.799521+00	5252
4452	-2986	13	173	KFL 583@Kärl?	\N	\N	1	1	-4452	\N	C	2019-12-20 22:13:53.799521+00	5253
4451	-2986	13	173	KFL 582@Kärl	\N	\N	1	1	-4451	\N	C	2019-12-20 22:13:53.799521+00	5254
4450	-2986	13	173	KFL 581@Kärl?	\N	\N	1	1	-4450	\N	C	2019-12-20 22:13:53.799521+00	5255
4449	-2986	13	173	KFL 578@Kärl?	\N	\N	1	1	-4449	\N	C	2019-12-20 22:13:53.799521+00	5256
4448	-2986	13	173	KFL 577@Kärl?	\N	\N	1	1	-4448	\N	C	2019-12-20 22:13:53.799521+00	5257
4447	-2986	13	173	KFL 576@Kärl?	\N	\N	1	1	-4447	\N	C	2019-12-20 22:13:53.799521+00	5258
4446	-2986	13	173	KFL 575@Kärl?	\N	\N	1	1	-4446	\N	C	2019-12-20 22:13:53.799521+00	5259
4445	-2986	13	173	KFL 574@Kärl?	\N	\N	1	1	-4445	\N	C	2019-12-20 22:13:53.799521+00	5260
4444	-2986	13	173	KFL 573@Kärl	\N	\N	1	1	-4444	\N	C	2019-12-20 22:13:53.799521+00	5261
4443	-2986	13	173	KFL 572@Kärl	\N	\N	1	1	-4443	\N	C	2019-12-20 22:13:53.799521+00	5262
4442	-2986	13	173	KFL 571@Kärl	\N	\N	1	1	-4442	\N	C	2019-12-20 22:13:53.799521+00	5263
4441	-2986	13	173	KFL 570@Kärl	\N	\N	1	1	-4441	\N	C	2019-12-20 22:13:53.799521+00	5264
4440	-2986	13	173	KFL 569@Kärl	\N	\N	1	1	-4440	\N	C	2019-12-20 22:13:53.799521+00	5265
4439	-2986	13	173	KFL 568@Kärl	\N	\N	1	1	-4439	\N	C	2019-12-20 22:13:53.799521+00	5266
4438	-2986	13	173	KFL 567@Kärl	\N	\N	1	1	-4438	\N	C	2019-12-20 22:13:53.799521+00	5267
4437	-2986	13	173	KFL 566@Kärl	\N	\N	1	1	-4437	\N	C	2019-12-20 22:13:53.799521+00	5268
4436	-2986	13	173	KFL 565@Kärl	\N	\N	1	1	-4436	\N	C	2019-12-20 22:13:53.799521+00	5269
4435	-2986	13	173	KFL 564@Kärl	\N	\N	1	1	-4435	\N	C	2019-12-20 22:13:53.799521+00	5270
4434	-2986	13	173	KFL 563@Kärl	\N	\N	1	1	-4434	\N	C	2019-12-20 22:13:53.799521+00	5271
4433	-2986	13	173	KFL 562@Kärl	\N	\N	1	1	-4433	\N	C	2019-12-20 22:13:53.799521+00	5272
4432	-3249	13	173	KFL 558@Kärl	\N	\N	1	1	-4432	\N	C	2019-12-20 22:13:53.799521+00	5273
4431	-3249	13	173	KFL 557@Kärl	\N	\N	1	1	-4431	\N	C	2019-12-20 22:13:53.799521+00	5274
4430	-3313	13	173	KFL 556@Degel	\N	\N	1	1	-4430	\N	C	2019-12-20 22:13:53.799521+00	5275
4429	-3317	13	173	KFL 555@Degel	\N	\N	1	1	-4429	\N	C	2019-12-20 22:13:53.799521+00	5276
4428	-3359	13	173	KFL 554@Degel	\N	\N	1	1	-4428	\N	C	2019-12-20 22:13:53.799521+00	5277
4427	-3292	13	173	KFL 553@Degel	\N	\N	1	1	-4427	\N	C	2019-12-20 22:13:53.799521+00	5278
4426	-3239	13	173	KFL 549@Kärl	\N	\N	1	1	-4426	\N	C	2019-12-20 22:13:53.799521+00	5279
4425	-3239	13	173	KFL 548@Kärl	\N	\N	1	1	-4425	\N	C	2019-12-20 22:13:53.799521+00	5280
4424	-3239	13	173	KFL 547@Kärl	\N	\N	1	1	-4424	\N	C	2019-12-20 22:13:53.799521+00	5281
4423	-3328	13	173	KFL 546@Kärl	\N	\N	1	1	-4423	\N	C	2019-12-20 22:13:53.799521+00	5282
4422	-3328	13	173	KFL 545@Kärl	\N	\N	1	1	-4422	\N	C	2019-12-20 22:13:53.799521+00	5283
4421	-3328	13	173	KFL 544@Kärl	\N	\N	1	1	-4421	\N	C	2019-12-20 22:13:53.799521+00	5284
4420	-3328	13	173	KFL 543@Kärl	\N	\N	1	1	-4420	\N	C	2019-12-20 22:13:53.799521+00	5285
4419	-3328	13	173	KFL 542@Kärl	\N	\N	1	1	-4419	\N	C	2019-12-20 22:13:53.799521+00	5286
4418	-3328	13	173	KFL 541@Kärl	\N	\N	1	1	-4418	\N	C	2019-12-20 22:13:53.799521+00	5287
4417	-3328	13	173	KFL 540@Kärl	\N	\N	1	1	-4417	\N	C	2019-12-20 22:13:53.799521+00	5288
4416	-3292	13	173	KFL 539@Kärl	\N	\N	1	1	-4416	\N	C	2019-12-20 22:13:53.799521+00	5289
4415	-3292	13	173	KFL 538@Kärl	\N	\N	1	1	-4415	\N	C	2019-12-20 22:13:53.799521+00	5290
4414	-3292	13	173	KFL 537@Kärl	\N	\N	1	1	-4414	\N	C	2019-12-20 22:13:53.799521+00	5291
4413	-3292	13	173	KFL 536@Kärl	\N	\N	1	1	-4413	\N	C	2019-12-20 22:13:53.799521+00	5292
4412	-3292	13	173	KFL 535@Kärl	\N	\N	1	1	-4412	\N	C	2019-12-20 22:13:53.799521+00	5293
4411	-3292	13	173	KFL 534@Kärl	\N	\N	1	1	-4411	\N	C	2019-12-20 22:13:53.799521+00	5294
4410	-3292	13	173	KFL 533@Kärl	\N	\N	1	1	-4410	\N	C	2019-12-20 22:13:53.799521+00	5295
4409	-3292	13	173	KFL 532@Kärl	\N	\N	1	1	-4409	\N	C	2019-12-20 22:13:53.799521+00	5296
4408	-3359	13	173	KFL 529@Kärl	\N	\N	1	1	-4408	\N	C	2019-12-20 22:13:53.799521+00	5297
4407	-3359	13	173	KFL 528@Kärl	\N	\N	1	1	-4407	\N	C	2019-12-20 22:13:53.799521+00	5298
4406	-3192	13	173	KFL 527@Kärl	\N	\N	1	1	-4406	\N	C	2019-12-20 22:13:53.799521+00	5299
4405	-3279	13	173	KFL 526@Kärl	\N	\N	1	1	-4405	\N	C	2019-12-20 22:13:53.799521+00	5300
4404	-3279	13	173	KFL 525@Kärl	\N	\N	1	1	-4404	\N	C	2019-12-20 22:13:53.799521+00	5301
4403	-3227	13	173	KFL 524@Kärl	\N	\N	1	1	-4403	\N	C	2019-12-20 22:13:53.799521+00	5302
4402	-2992	13	173	KFL 523@Kärl	\N	\N	1	1	-4402	\N	C	2019-12-20 22:13:53.799521+00	5303
4401	-3195	13	173	KFL 522@Kärl	\N	\N	1	1	-4401	\N	C	2019-12-20 22:13:53.799521+00	5304
4400	-3195	13	173	KFL 521@Kärl	\N	\N	1	1	-4400	\N	C	2019-12-20 22:13:53.799521+00	5305
4399	-3292	13	173	KFL 520@Kärl	\N	\N	1	1	-4399	\N	C	2019-12-20 22:13:53.799521+00	5306
4398	-3292	13	173	KFL 519@Kärl	\N	\N	1	1	-4398	\N	C	2019-12-20 22:13:53.799521+00	5307
4397	-3292	13	173	KFL 518@Kärl	\N	\N	1	1	-4397	\N	C	2019-12-20 22:13:53.799521+00	5308
4396	-3311	13	173	KFL 517@Degel	\N	\N	1	1	-4396	\N	C	2019-12-20 22:13:53.799521+00	5309
4395	-3011	13	173	KFL 516@Degel	\N	\N	1	1	-4395	\N	C	2019-12-20 22:13:53.799521+00	5310
4394	-3121	13	173	KFL 495@Kärl	\N	\N	1	1	-4394	\N	C	2019-12-20 22:13:53.799521+00	5311
4393	-3121	13	173	KFL 494@Kärl	\N	\N	1	1	-4393	\N	C	2019-12-20 22:13:53.799521+00	5312
4392	-3121	13	173	KFL 493@Kärl	\N	\N	1	1	-4392	\N	C	2019-12-20 22:13:53.799521+00	5313
4391	-3121	13	173	KFL 492@Kärl	\N	\N	1	1	-4391	\N	C	2019-12-20 22:13:53.799521+00	5314
4390	-3121	13	173	KFL 491@Kärl	\N	\N	1	1	-4390	\N	C	2019-12-20 22:13:53.799521+00	5315
4389	-3117	13	173	KFL 490@Kärl	\N	\N	1	1	-4389	\N	C	2019-12-20 22:13:53.799521+00	5316
4388	-3117	13	173	KFL 489@Kärl	\N	\N	1	1	-4388	\N	C	2019-12-20 22:13:53.799521+00	5317
4387	-3117	13	173	KFL 488@Kärl	\N	\N	1	1	-4387	\N	C	2019-12-20 22:13:53.799521+00	5318
4386	-3117	13	173	KFL 487@Kärl	\N	\N	1	1	-4386	\N	C	2019-12-20 22:13:53.799521+00	5319
4385	-3120	13	173	KFL 486@Kärl	\N	\N	1	1	-4385	\N	C	2019-12-20 22:13:53.799521+00	5320
4384	-3120	13	173	KFL 485@Kärl	\N	\N	1	1	-4384	\N	C	2019-12-20 22:13:53.799521+00	5321
4383	-3120	13	173	KFL 484@Kärl	\N	\N	1	1	-4383	\N	C	2019-12-20 22:13:53.799521+00	5322
4382	-3120	13	173	KFL 483@Kärl	\N	\N	1	1	-4382	\N	C	2019-12-20 22:13:53.799521+00	5323
4381	-3119	13	173	KFL 482@Kärl	\N	\N	1	1	-4381	\N	C	2019-12-20 22:13:53.799521+00	5324
4380	-3120	13	173	KFL 481@Kärl	\N	\N	1	1	-4380	\N	C	2019-12-20 22:13:53.799521+00	5325
4379	-3120	13	173	KFL 480@Kärl	\N	\N	1	1	-4379	\N	C	2019-12-20 22:13:53.799521+00	5326
4378	-3096	13	173	KFL 479@Kärl	\N	\N	1	1	-4378	\N	C	2019-12-20 22:13:53.799521+00	5327
4377	-3096	13	173	KFL 478@Kärl	\N	\N	1	1	-4377	\N	C	2019-12-20 22:13:53.799521+00	5328
4376	-3096	13	173	KFL 474@Kärl	\N	\N	1	1	-4376	\N	C	2019-12-20 22:13:53.799521+00	5329
4375	-3096	13	173	KFL 473@Kärl	\N	\N	1	1	-4375	\N	C	2019-12-20 22:13:53.799521+00	5330
4374	-3096	13	173	KFL 472@Kärl	\N	\N	1	1	-4374	\N	C	2019-12-20 22:13:53.799521+00	5331
4373	-3096	13	173	KFL 471@Kärl	\N	\N	1	1	-4373	\N	C	2019-12-20 22:13:53.799521+00	5332
4372	-3096	13	173	KFL 470@Kärl	\N	\N	1	1	-4372	\N	C	2019-12-20 22:13:53.799521+00	5333
4371	-3096	13	173	KFL 469@Kärl	\N	\N	1	1	-4371	\N	C	2019-12-20 22:13:53.799521+00	5334
4370	-3096	13	173	KFL 468@Kärl	\N	\N	1	1	-4370	\N	C	2019-12-20 22:13:53.799521+00	5335
4369	-3096	13	173	KFL 467@Kärl	\N	\N	1	1	-4369	\N	C	2019-12-20 22:13:53.799521+00	5336
4368	-3096	13	173	KFL 466@Kärl	\N	\N	1	1	-4368	\N	C	2019-12-20 22:13:53.799521+00	5337
4367	-3096	13	173	KFL 465@Kärl	\N	\N	1	1	-4367	\N	C	2019-12-20 22:13:53.799521+00	5338
4366	-3096	13	173	KFL 464@Kärl	\N	\N	1	1	-4366	\N	C	2019-12-20 22:13:53.799521+00	5339
4365	-3096	13	173	KFL 463@Kärl	\N	\N	1	1	-4365	\N	C	2019-12-20 22:13:53.799521+00	5340
4364	-3096	13	173	KFL 462@Kärl	\N	\N	1	1	-4364	\N	C	2019-12-20 22:13:53.799521+00	5341
4363	-3096	13	173	KFL 461@Kärl	\N	\N	1	1	-4363	\N	C	2019-12-20 22:13:53.799521+00	5342
4362	-3096	13	173	KFL 460@Kärl	\N	\N	1	1	-4362	\N	C	2019-12-20 22:13:53.799521+00	5343
4361	-3096	13	173	KFL 459@Kärl	\N	\N	1	1	-4361	\N	C	2019-12-20 22:13:53.799521+00	5344
4360	-3096	13	173	KFL 458@Kärl	\N	\N	1	1	-4360	\N	C	2019-12-20 22:13:53.799521+00	5345
4359	-3157	13	173	KFL 457@Kärl	\N	\N	1	1	-4359	\N	C	2019-12-20 22:13:53.799521+00	5346
4358	-3157	13	173	KFL 456@Kärl	\N	\N	1	1	-4358	\N	C	2019-12-20 22:13:53.799521+00	5347
4357	-3157	13	173	KFL 455@Kärl	\N	\N	1	1	-4357	\N	C	2019-12-20 22:13:53.799521+00	5348
4356	-3219	13	173	KFL 454@Kärl	\N	\N	1	1	-4356	\N	C	2019-12-20 22:13:53.799521+00	5349
4355	-3219	13	173	KFL 453@Kärl	\N	\N	1	1	-4355	\N	C	2019-12-20 22:13:53.799521+00	5350
4354	-3219	13	173	KFL 452@Kärl	\N	\N	1	1	-4354	\N	C	2019-12-20 22:13:53.799521+00	5351
4353	-3219	13	173	KFL 451@Kärl	\N	\N	1	1	-4353	\N	C	2019-12-20 22:13:53.799521+00	5352
4352	-3219	13	173	KFL 450@Kärl	\N	\N	1	1	-4352	\N	C	2019-12-20 22:13:53.799521+00	5353
4351	-3219	13	173	KFL 449@Kärl	\N	\N	1	1	-4351	\N	C	2019-12-20 22:13:53.799521+00	5354
4350	-3219	13	173	KFL 448@Kärl	\N	\N	1	1	-4350	\N	C	2019-12-20 22:13:53.799521+00	5355
4349	-3219	13	173	KFL 447@Kärl	\N	\N	1	1	-4349	\N	C	2019-12-20 22:13:53.799521+00	5356
4348	-3219	13	173	KFL 446@Kärl	\N	\N	1	1	-4348	\N	C	2019-12-20 22:13:53.799521+00	5357
4347	-3219	13	173	KFL 445@Kärl	\N	\N	1	1	-4347	\N	C	2019-12-20 22:13:53.799521+00	5358
4346	-3219	13	173	KFL 444@Kärl	\N	\N	1	1	-4346	\N	C	2019-12-20 22:13:53.799521+00	5359
4345	-3219	13	173	KFL 443@Kärl	\N	\N	1	1	-4345	\N	C	2019-12-20 22:13:53.799521+00	5360
4344	-3219	13	173	KFL 442@Kärl	\N	\N	1	1	-4344	\N	C	2019-12-20 22:13:53.799521+00	5361
4343	-3219	13	173	KFL 441@Kärl	\N	\N	1	1	-4343	\N	C	2019-12-20 22:13:53.799521+00	5362
4342	-3219	13	173	KFL 440@Kärl	\N	\N	1	1	-4342	\N	C	2019-12-20 22:13:53.799521+00	5363
4341	-3219	13	173	KFL 439@Kärl	\N	\N	1	1	-4341	\N	C	2019-12-20 22:13:53.799521+00	5364
4340	-3219	13	173	KFL 438@Kärl	\N	\N	1	1	-4340	\N	C	2019-12-20 22:13:53.799521+00	5365
4339	-3219	13	173	KFL 437@Kärl	\N	\N	1	1	-4339	\N	C	2019-12-20 22:13:53.799521+00	5366
4338	-3219	13	173	KFL 436@Kärl	\N	\N	1	1	-4338	\N	C	2019-12-20 22:13:53.799521+00	5367
4337	-3219	13	173	KFL 435@Kärl	\N	\N	1	1	-4337	\N	C	2019-12-20 22:13:53.799521+00	5368
4336	-3219	13	173	KFL 434@Kärl	\N	\N	1	1	-4336	\N	C	2019-12-20 22:13:53.799521+00	5369
4335	-3098	13	173	KFL 433@Kärl	\N	\N	1	1	-4335	\N	C	2019-12-20 22:13:53.799521+00	5370
4334	-3221	13	173	KFL 431@Kärl	\N	\N	1	1	-4334	\N	C	2019-12-20 22:13:53.799521+00	5371
4333	-3219	13	173	KFL 430@Kärl	\N	\N	1	1	-4333	\N	C	2019-12-20 22:13:53.799521+00	5372
4332	-3219	13	173	KFL 429@Kärl	\N	\N	1	1	-4332	\N	C	2019-12-20 22:13:53.799521+00	5373
4331	-3157	13	173	KFL 427@Kärl	\N	\N	1	1	-4331	\N	C	2019-12-20 22:13:53.799521+00	5374
4330	-3157	13	173	KFL 426@Kärl	\N	\N	1	1	-4330	\N	C	2019-12-20 22:13:53.799521+00	5375
4329	-3224	13	173	KFL 425@Kärl	\N	\N	1	1	-4329	\N	C	2019-12-20 22:13:53.799521+00	5376
4328	-3351	13	173	KFL 424@Kärl	\N	\N	1	1	-4328	\N	C	2019-12-20 22:13:53.799521+00	5377
4327	-3220	13	173	KFL 423@Kärl	\N	\N	1	1	-4327	\N	C	2019-12-20 22:13:53.799521+00	5378
4326	-3220	13	173	KFL 422@Kärl	\N	\N	1	1	-4326	\N	C	2019-12-20 22:13:53.799521+00	5379
4325	-3220	13	173	KFL 421@Kärl	\N	\N	1	1	-4325	\N	C	2019-12-20 22:13:53.799521+00	5380
4324	-3220	13	173	KFL 420@Kärl	\N	\N	1	1	-4324	\N	C	2019-12-20 22:13:53.799521+00	5381
4323	-3220	13	173	KFL 419@Kärl	\N	\N	1	1	-4323	\N	C	2019-12-20 22:13:53.799521+00	5382
4322	-3222	13	173	KFL 418@Kärl	\N	\N	1	1	-4322	\N	C	2019-12-20 22:13:53.799521+00	5383
4321	-3118	13	173	KFL 417@Kärl	\N	\N	1	1	-4321	\N	C	2019-12-20 22:13:53.799521+00	5384
4320	-3118	13	173	KFL 416@Kärl	\N	\N	1	1	-4320	\N	C	2019-12-20 22:13:53.799521+00	5385
4319	-3219	13	173	KFL 415@Kärl	\N	\N	1	1	-4319	\N	C	2019-12-20 22:13:53.799521+00	5386
4318	-3219	13	173	KFL 414@Kärl	\N	\N	1	1	-4318	\N	C	2019-12-20 22:13:53.799521+00	5387
4317	-3137	13	173	KFL 413@Kärl	\N	\N	1	1	-4317	\N	C	2019-12-20 22:13:53.799521+00	5388
4316	-3293	13	173	KFL 412@Kärl	\N	\N	1	1	-4316	\N	C	2019-12-20 22:13:53.799521+00	5389
4315	-3312	13	173	KFL 411@Kärl	\N	\N	1	1	-4315	\N	C	2019-12-20 22:13:53.799521+00	5390
4314	-3284	13	173	KFL 410@Kärl	\N	\N	1	1	-4314	\N	C	2019-12-20 22:13:53.799521+00	5391
4313	-3164	13	173	KFL 409@Kärl	\N	\N	1	1	-4313	\N	C	2019-12-20 22:13:53.799521+00	5392
4312	-3164	13	173	KFL 408@Kärl	\N	\N	1	1	-4312	\N	C	2019-12-20 22:13:53.799521+00	5393
4311	-3164	13	173	KFL 407@Kärl	\N	\N	1	1	-4311	\N	C	2019-12-20 22:13:53.799521+00	5394
4310	-3078	13	173	KFL 406@Kärl	\N	\N	1	1	-4310	\N	C	2019-12-20 22:13:53.799521+00	5395
4309	-3304	13	173	KFL 405@Kärl	\N	\N	1	1	-4309	\N	C	2019-12-20 22:13:53.799521+00	5396
4308	-3350	13	173	KFL 404@Kärl	\N	\N	1	1	-4308	\N	C	2019-12-20 22:13:53.799521+00	5397
4307	-3223	13	173	KFL 403@Kärl	\N	\N	1	1	-4307	\N	C	2019-12-20 22:13:53.799521+00	5398
4306	-3223	13	173	KFL 402@Kärl	\N	\N	1	1	-4306	\N	C	2019-12-20 22:13:53.799521+00	5399
4305	-3223	13	173	KFL 401@Kärl	\N	\N	1	1	-4305	\N	C	2019-12-20 22:13:53.799521+00	5400
4304	-3223	13	173	KFL 400@Kärl	\N	\N	1	1	-4304	\N	C	2019-12-20 22:13:53.799521+00	5401
4303	-3223	13	173	KFL 399@Kärl	\N	\N	1	1	-4303	\N	C	2019-12-20 22:13:53.799521+00	5402
4302	-3223	13	173	KFL 398@Kärl	\N	\N	1	1	-4302	\N	C	2019-12-20 22:13:53.799521+00	5403
4301	-3223	13	173	KFL 397@Kärl	\N	\N	1	1	-4301	\N	C	2019-12-20 22:13:53.799521+00	5404
4300	-3223	13	173	KFL 396@Kärl	\N	\N	1	1	-4300	\N	C	2019-12-20 22:13:53.799521+00	5405
4299	-3223	13	173	KFL 395@Kärl	\N	\N	1	1	-4299	\N	C	2019-12-20 22:13:53.799521+00	5406
4298	-3026	13	173	KFL 394@Kärl	\N	\N	1	1	-4298	\N	C	2019-12-20 22:13:53.799521+00	5407
4297	-3316	13	173	KFL 393@Kärl	\N	\N	1	1	-4297	\N	C	2019-12-20 22:13:53.799521+00	5408
4296	-3177	13	173	KFL 392@Kärl	\N	\N	1	1	-4296	\N	C	2019-12-20 22:13:53.799521+00	5409
4295	-3316	13	173	KFL 390@Kärl	\N	\N	1	1	-4295	\N	C	2019-12-20 22:13:53.799521+00	5410
4294	-3177	13	173	KFL 386@Kärl	\N	\N	1	1	-4294	\N	C	2019-12-20 22:13:53.799521+00	5411
4293	-3316	13	173	KFL 385@Kärl	\N	\N	1	1	-4293	\N	C	2019-12-20 22:13:53.799521+00	5412
4292	-3177	13	173	KFL 384@Kärl	\N	\N	1	1	-4292	\N	C	2019-12-20 22:13:53.799521+00	5413
4291	-3316	13	173	KFL 383@Kärl	\N	\N	1	1	-4291	\N	C	2019-12-20 22:13:53.799521+00	5414
4290	-3177	13	173	KFL 382@Kärl	\N	\N	1	1	-4290	\N	C	2019-12-20 22:13:53.799521+00	5415
4289	-3316	13	173	KFL 381@Kärl	\N	\N	1	1	-4289	\N	C	2019-12-20 22:13:53.799521+00	5416
4288	-3316	13	173	KFL 379@Kärl	\N	\N	1	1	-4288	\N	C	2019-12-20 22:13:53.799521+00	5417
4287	-3316	13	173	KFL 378@Kärl	\N	\N	1	1	-4287	\N	C	2019-12-20 22:13:53.799521+00	5418
4286	-3234	13	173	KFL 349@Kärl	\N	\N	1	1	-4286	\N	C	2019-12-20 22:13:53.799521+00	5419
4285	-3234	13	173	KFL 348@Kärl	\N	\N	1	1	-4285	\N	C	2019-12-20 22:13:53.799521+00	5420
4284	-3234	13	173	KFL 347@Kärl	\N	\N	1	1	-4284	\N	C	2019-12-20 22:13:53.799521+00	5421
4283	-3234	13	173	KFL 346@Kärl	\N	\N	1	1	-4283	\N	C	2019-12-20 22:13:53.799521+00	5422
4282	-3234	13	173	KFL 345@Kärl	\N	\N	1	1	-4282	\N	C	2019-12-20 22:13:53.799521+00	5423
4281	-3234	13	173	KFL 344@Kärl	\N	\N	1	1	-4281	\N	C	2019-12-20 22:13:53.799521+00	5424
4280	-3234	13	173	KFL 343@Kärl	\N	\N	1	1	-4280	\N	C	2019-12-20 22:13:53.799521+00	5425
4279	-3234	13	173	KFL 342@Kärl	\N	\N	1	1	-4279	\N	C	2019-12-20 22:13:53.799521+00	5426
4278	-3234	13	173	KFL 341@Kärl	\N	\N	1	1	-4278	\N	C	2019-12-20 22:13:53.799521+00	5427
4277	-3234	13	173	KFL 340@Kärl	\N	\N	1	1	-4277	\N	C	2019-12-20 22:13:53.799521+00	5428
4276	-3234	13	173	KFL 339@Kärl	\N	\N	1	1	-4276	\N	C	2019-12-20 22:13:53.799521+00	5429
4275	-3234	13	173	KFL 338@Kärl	\N	\N	1	1	-4275	\N	C	2019-12-20 22:13:53.799521+00	5430
4274	-3234	13	173	KFL 337@Kärl	\N	\N	1	1	-4274	\N	C	2019-12-20 22:13:53.799521+00	5431
4273	-3234	13	173	KFL 336@Kärl	\N	\N	1	1	-4273	\N	C	2019-12-20 22:13:53.799521+00	5432
4272	-3234	13	173	KFL 335@Kärl	\N	\N	1	1	-4272	\N	C	2019-12-20 22:13:53.799521+00	5433
4271	-3234	13	173	KFL 334@Kärl	\N	\N	1	1	-4271	\N	C	2019-12-20 22:13:53.799521+00	5434
4270	-3234	13	173	KFL 333@Kärl	\N	\N	1	1	-4270	\N	C	2019-12-20 22:13:53.799521+00	5435
4269	-3234	13	173	KFL 332@Kärl	\N	\N	1	1	-4269	\N	C	2019-12-20 22:13:53.799521+00	5436
4268	-3234	13	173	KFL 331@Kärl	\N	\N	1	1	-4268	\N	C	2019-12-20 22:13:53.799521+00	5437
4267	-3234	13	173	KFL 330@Kärl	\N	\N	1	1	-4267	\N	C	2019-12-20 22:13:53.799521+00	5438
4266	-3234	13	173	KFL 329@Kärl	\N	\N	1	1	-4266	\N	C	2019-12-20 22:13:53.799521+00	5439
4265	-3234	13	173	KFL 328@Kärl	\N	\N	1	1	-4265	\N	C	2019-12-20 22:13:53.799521+00	5440
4264	-3234	13	173	KFL 327@Kärl	\N	\N	1	1	-4264	\N	C	2019-12-20 22:13:53.799521+00	5441
4263	-3234	13	173	KFL 326@Kärl	\N	\N	1	1	-4263	\N	C	2019-12-20 22:13:53.799521+00	5442
4262	-3234	13	173	KFL 325@Kärl	\N	\N	1	1	-4262	\N	C	2019-12-20 22:13:53.799521+00	5443
4261	-3234	13	173	KFL 324@Kärl	\N	\N	1	1	-4261	\N	C	2019-12-20 22:13:53.799521+00	5444
4260	-3234	13	173	KFL 323@Kärl	\N	\N	1	1	-4260	\N	C	2019-12-20 22:13:53.799521+00	5445
4259	-3234	13	173	KFL 322@Kärl	\N	\N	1	1	-4259	\N	C	2019-12-20 22:13:53.799521+00	5446
4258	-3234	13	173	KFL 321@Kärl	\N	\N	1	1	-4258	\N	C	2019-12-20 22:13:53.799521+00	5447
4257	-3234	13	173	KFL 320@Kärl	\N	\N	1	1	-4257	\N	C	2019-12-20 22:13:53.799521+00	5448
4256	-3234	13	173	KFL 319@Kärl	\N	\N	1	1	-4256	\N	C	2019-12-20 22:13:53.799521+00	5449
4255	-3234	13	173	KFL 318@Kärl	\N	\N	1	1	-4255	\N	C	2019-12-20 22:13:53.799521+00	5450
4254	-3234	13	173	KFL 317@Kärl	\N	\N	1	1	-4254	\N	C	2019-12-20 22:13:53.799521+00	5451
4253	-3234	13	173	KFL 316@Kärl	\N	\N	1	1	-4253	\N	C	2019-12-20 22:13:53.799521+00	5452
4252	-3234	13	173	KFL 315@Kärl	\N	\N	1	1	-4252	\N	C	2019-12-20 22:13:53.799521+00	5453
4251	-3234	13	173	KFL 314@Kärl	\N	\N	1	1	-4251	\N	C	2019-12-20 22:13:53.799521+00	5454
4250	-3234	13	173	KFL 313@Kärl	\N	\N	1	1	-4250	\N	C	2019-12-20 22:13:53.799521+00	5455
4249	-3234	13	173	KFL 312@Kärl	\N	\N	1	1	-4249	\N	C	2019-12-20 22:13:53.799521+00	5456
4248	-3234	13	173	KFL 311@Kärl	\N	\N	1	1	-4248	\N	C	2019-12-20 22:13:53.799521+00	5457
4247	-3234	13	173	KFL 310@Kärl	\N	\N	1	1	-4247	\N	C	2019-12-20 22:13:53.799521+00	5458
4246	-3234	13	173	KFL 309@Kärl	\N	\N	1	1	-4246	\N	C	2019-12-20 22:13:53.799521+00	5459
4245	-3234	13	173	KFL 308@Kärl	\N	\N	1	1	-4245	\N	C	2019-12-20 22:13:53.799521+00	5460
4244	-3078	13	173	KFL 307@Kärl	\N	\N	1	1	-4244	\N	C	2019-12-20 22:13:53.799521+00	5461
4243	-3078	13	173	KFL 306@Kärl	\N	\N	1	1	-4243	\N	C	2019-12-20 22:13:53.799521+00	5462
4242	-3078	13	173	KFL 305@Kärl	\N	\N	1	1	-4242	\N	C	2019-12-20 22:13:53.799521+00	5463
4241	-3122	13	173	KFL 304@Kärl	\N	\N	1	1	-4241	\N	C	2019-12-20 22:13:53.799521+00	5464
4240	-3122	13	173	KFL 303@Kärl	\N	\N	1	1	-4240	\N	C	2019-12-20 22:13:53.799521+00	5465
4239	-3122	13	173	KFL 302@Kärl	\N	\N	1	1	-4239	\N	C	2019-12-20 22:13:53.799521+00	5466
4238	-3122	13	173	KFL 301@Kärl	\N	\N	1	1	-4238	\N	C	2019-12-20 22:13:53.799521+00	5467
4237	-3122	13	173	KFL 300@Kärl	\N	\N	1	1	-4237	\N	C	2019-12-20 22:13:53.799521+00	5468
4236	-3122	13	173	KFL 299@Kärl	\N	\N	1	1	-4236	\N	C	2019-12-20 22:13:53.799521+00	5469
4235	-3122	13	173	KFL 298@Kärl	\N	\N	1	1	-4235	\N	C	2019-12-20 22:13:53.799521+00	5470
4234	-3122	13	173	KFL 297@Kärl	\N	\N	1	1	-4234	\N	C	2019-12-20 22:13:53.799521+00	5471
4233	-3122	13	173	KFL 296@Kärl	\N	\N	1	1	-4233	\N	C	2019-12-20 22:13:53.799521+00	5472
4232	-3122	13	173	KFL 295@Kärl	\N	\N	1	1	-4232	\N	C	2019-12-20 22:13:53.799521+00	5473
4231	-3122	13	173	KFL 294@Kärl	\N	\N	1	1	-4231	\N	C	2019-12-20 22:13:53.799521+00	5474
4230	-3122	13	173	KFL 293@Kärl	\N	\N	1	1	-4230	\N	C	2019-12-20 22:13:53.799521+00	5475
4229	-3122	13	173	KFL 292@Kärl	\N	\N	1	1	-4229	\N	C	2019-12-20 22:13:53.799521+00	5476
4228	-3122	13	173	KFL 291@Kärl	\N	\N	1	1	-4228	\N	C	2019-12-20 22:13:53.799521+00	5477
4227	-3122	13	173	KFL 290@Kärl	\N	\N	1	1	-4227	\N	C	2019-12-20 22:13:53.799521+00	5478
4226	-3304	13	173	KFL 289@Kärl	\N	\N	1	1	-4226	\N	C	2019-12-20 22:13:53.799521+00	5479
4225	-3223	13	173	KFL 287@Kärl	\N	\N	1	1	-4225	\N	C	2019-12-20 22:13:53.799521+00	5480
4224	-3223	13	173	KFL 286@Kärl	\N	\N	1	1	-4224	\N	C	2019-12-20 22:13:53.799521+00	5481
4223	-3223	13	173	KFL 285@Kärl	\N	\N	1	1	-4223	\N	C	2019-12-20 22:13:53.799521+00	5482
4222	-3223	13	173	KFL 284@Kärl	\N	\N	1	1	-4222	\N	C	2019-12-20 22:13:53.799521+00	5483
4221	-3223	13	173	KFL 283@Kärl	\N	\N	1	1	-4221	\N	C	2019-12-20 22:13:53.799521+00	5484
4220	-3223	13	173	KFL 282@Kärl	\N	\N	1	1	-4220	\N	C	2019-12-20 22:13:53.799521+00	5485
4219	-3223	13	173	KFL 281@Kärl	\N	\N	1	1	-4219	\N	C	2019-12-20 22:13:53.799521+00	5486
4218	-3223	13	173	KFL 280@Kärl	\N	\N	1	1	-4218	\N	C	2019-12-20 22:13:53.799521+00	5487
4217	-3223	13	173	KFL 279@Kärl	\N	\N	1	1	-4217	\N	C	2019-12-20 22:13:53.799521+00	5488
4216	-3221	13	173	KFL 278@Kärl	\N	\N	1	1	-4216	\N	C	2019-12-20 22:13:53.799521+00	5489
4215	-3221	13	173	KFL 277@Kärl	\N	\N	1	1	-4215	\N	C	2019-12-20 22:13:53.799521+00	5490
4214	-3221	13	173	KFL 276@Kärl	\N	\N	1	1	-4214	\N	C	2019-12-20 22:13:53.799521+00	5491
4213	-3134	13	173	KFL 267@Kärl	\N	\N	1	1	-4213	\N	C	2019-12-20 22:13:53.799521+00	5492
4212	-3134	13	173	KFL 266@Kärl	\N	\N	1	1	-4212	\N	C	2019-12-20 22:13:53.799521+00	5493
4211	-3134	13	173	KFL 265@Kärl	\N	\N	1	1	-4211	\N	C	2019-12-20 22:13:53.799521+00	5494
4210	-3134	13	173	KFL 264@Kärl	\N	\N	1	1	-4210	\N	C	2019-12-20 22:13:53.799521+00	5495
4209	-3134	13	173	KFL 263@Kärl	\N	\N	1	1	-4209	\N	C	2019-12-20 22:13:53.799521+00	5496
4208	-3134	13	173	KFL 262@Kärl	\N	\N	1	1	-4208	\N	C	2019-12-20 22:13:53.799521+00	5497
4207	-3083	13	173	KFL 261@Kärl	\N	\N	1	1	-4207	\N	C	2019-12-20 22:13:53.799521+00	5498
4206	-3083	13	173	KFL 260@Kärl	\N	\N	1	1	-4206	\N	C	2019-12-20 22:13:53.799521+00	5499
4205	-3083	13	173	KFL 259@Kärl	\N	\N	1	1	-4205	\N	C	2019-12-20 22:13:53.799521+00	5500
4204	-3083	13	173	KFL 258@Kärl	\N	\N	1	1	-4204	\N	C	2019-12-20 22:13:53.799521+00	5501
4203	-3082	13	173	KFL 257@Kärl	\N	\N	1	1	-4203	\N	C	2019-12-20 22:13:53.799521+00	5502
4202	-3082	13	173	KFL 256@Kärl	\N	\N	1	1	-4202	\N	C	2019-12-20 22:13:53.799521+00	5503
4201	-3082	13	173	KFL 255@Kärl	\N	\N	1	1	-4201	\N	C	2019-12-20 22:13:53.799521+00	5504
4200	-3082	13	173	KFL 254@Kärl	\N	\N	1	1	-4200	\N	C	2019-12-20 22:13:53.799521+00	5505
4199	-3082	13	173	KFL 253@Kärl	\N	\N	1	1	-4199	\N	C	2019-12-20 22:13:53.799521+00	5506
4198	-3082	13	173	KFL 252@Kärl	\N	\N	1	1	-4198	\N	C	2019-12-20 22:13:53.799521+00	5507
4197	-3082	13	173	KFL 251@Kärl	\N	\N	1	1	-4197	\N	C	2019-12-20 22:13:53.799521+00	5508
4196	-3332	13	173	KFL 248@Kärl	\N	\N	1	1	-4196	\N	C	2019-12-20 22:13:53.799521+00	5509
4195	-3332	13	173	KFL 247@Kärl	\N	\N	1	1	-4195	\N	C	2019-12-20 22:13:53.799521+00	5510
4194	-3332	13	173	KFL 246@Kärl	\N	\N	1	1	-4194	\N	C	2019-12-20 22:13:53.799521+00	5511
4193	-3332	13	173	KFL 245@Kärl	\N	\N	1	1	-4193	\N	C	2019-12-20 22:13:53.799521+00	5512
4192	-3332	13	173	KFL 244@Kärl	\N	\N	1	1	-4192	\N	C	2019-12-20 22:13:53.799521+00	5513
4191	-3332	13	173	KFL 243@Kärl	\N	\N	1	1	-4191	\N	C	2019-12-20 22:13:53.799521+00	5514
4190	-3332	13	173	KFL 242@Kärl	\N	\N	1	1	-4190	\N	C	2019-12-20 22:13:53.799521+00	5515
4189	-3332	13	173	KFL 241@Kärl	\N	\N	1	1	-4189	\N	C	2019-12-20 22:13:53.799521+00	5516
4188	-3297	13	173	KFL 240@Kärl	\N	\N	1	1	-4188	\N	C	2019-12-20 22:13:53.799521+00	5517
4187	-3297	13	173	KFL 239@Kärl	\N	\N	1	1	-4187	\N	C	2019-12-20 22:13:53.799521+00	5518
4186	-3297	13	173	KFL 238@Kärl	\N	\N	1	1	-4186	\N	C	2019-12-20 22:13:53.799521+00	5519
4185	-2980	13	173	KFL 237@Kärl	\N	\N	1	1	-4185	\N	C	2019-12-20 22:13:53.799521+00	5520
4184	-2980	13	173	KFL 236@Kärl	\N	\N	1	1	-4184	\N	C	2019-12-20 22:13:53.799521+00	5521
4183	-2980	13	173	KFL 235@Lerskiva	\N	\N	1	1	-4183	\N	C	2019-12-20 22:13:53.799521+00	5522
4182	-2980	13	173	KFL 234@Kärl	\N	\N	1	1	-4182	\N	C	2019-12-20 22:13:53.799521+00	5523
4181	-2980	13	173	KFL 233@Lerskiva	\N	\N	1	1	-4181	\N	C	2019-12-20 22:13:53.799521+00	5524
4180	-2980	13	173	KFL 232@Kärl	\N	\N	1	1	-4180	\N	C	2019-12-20 22:13:53.799521+00	5525
4179	-2980	13	173	KFL 231@Kärl	\N	\N	1	1	-4179	\N	C	2019-12-20 22:13:53.799521+00	5526
4178	-2980	13	173	KFL 230@Kärl	\N	\N	1	1	-4178	\N	C	2019-12-20 22:13:53.799521+00	5527
4177	-2980	13	173	KFL 229@Kärl	\N	\N	1	1	-4177	\N	C	2019-12-20 22:13:53.799521+00	5528
4176	-2980	13	173	KFL 228@Kärl	\N	\N	1	1	-4176	\N	C	2019-12-20 22:13:53.799521+00	5529
4175	-2980	13	173	KFL 227@Kärl	\N	\N	1	1	-4175	\N	C	2019-12-20 22:13:53.799521+00	5530
4174	-2980	13	173	KFL 226@Kärl	\N	\N	1	1	-4174	\N	C	2019-12-20 22:13:53.799521+00	5531
4173	-3135	13	173	KFL 225@Lerskiva	\N	\N	1	1	-4173	\N	C	2019-12-20 22:13:53.799521+00	5532
4172	-3135	13	173	KFL 224@Lerskiva	\N	\N	1	1	-4172	\N	C	2019-12-20 22:13:53.799521+00	5533
4171	-3135	13	173	KFL 223@Kärl	\N	\N	1	1	-4171	\N	C	2019-12-20 22:13:53.799521+00	5534
4170	-3135	13	173	KFL 222@Kärl	\N	\N	1	1	-4170	\N	C	2019-12-20 22:13:53.799521+00	5535
4169	-3135	13	173	KFL 221@Lerskiva	\N	\N	1	1	-4169	\N	C	2019-12-20 22:13:53.799521+00	5536
4168	-3135	13	173	KFL 220@Kärl	\N	\N	1	1	-4168	\N	C	2019-12-20 22:13:53.799521+00	5537
4167	-3135	13	173	KFL 219@Kärl	\N	\N	1	1	-4167	\N	C	2019-12-20 22:13:53.799521+00	5538
4166	-3135	13	173	KFL 218@Lerskiva	\N	\N	1	1	-4166	\N	C	2019-12-20 22:13:53.799521+00	5539
4165	-3135	13	173	KFL 217@Kärl	\N	\N	1	1	-4165	\N	C	2019-12-20 22:13:53.799521+00	5540
4164	-3135	13	173	KFL 216@Kärl	\N	\N	1	1	-4164	\N	C	2019-12-20 22:13:53.799521+00	5541
4163	-3135	13	173	KFL 215@Kärl	\N	\N	1	1	-4163	\N	C	2019-12-20 22:13:53.799521+00	5542
4162	-3135	13	173	KFL 214@Lerskiva	\N	\N	1	1	-4162	\N	C	2019-12-20 22:13:53.799521+00	5543
4161	-3135	13	173	KFL 213@Kärl	\N	\N	1	1	-4161	\N	C	2019-12-20 22:13:53.799521+00	5544
4160	-3135	13	173	KFL 212@Lerskiva	\N	\N	1	1	-4160	\N	C	2019-12-20 22:13:53.799521+00	5545
4159	-3135	13	173	KFL 211@Kärl	\N	\N	1	1	-4159	\N	C	2019-12-20 22:13:53.799521+00	5546
4158	-3135	13	173	KFL 210@Kärl	\N	\N	1	1	-4158	\N	C	2019-12-20 22:13:53.799521+00	5547
4157	-3035	13	173	KFL 209@Kärl	\N	\N	1	1	-4157	\N	C	2019-12-20 22:13:53.799521+00	5548
4156	-3035	13	173	KFL 208@Kärl	\N	\N	1	1	-4156	\N	C	2019-12-20 22:13:53.799521+00	5549
4155	-3028	13	173	KFL 207@Kärl	\N	\N	1	1	-4155	\N	C	2019-12-20 22:13:53.799521+00	5550
4154	-3029	13	173	KFL 206@Kärl	\N	\N	1	1	-4154	\N	C	2019-12-20 22:13:53.799521+00	5551
4153	-3245	13	173	KFL 203@Kärl	\N	\N	1	1	-4153	\N	C	2019-12-20 22:13:53.799521+00	5552
4152	-3245	13	173	KFL 202@Kärl	\N	\N	1	1	-4152	\N	C	2019-12-20 22:13:53.799521+00	5553
4151	-3245	13	173	KFL 201@Kärl	\N	\N	1	1	-4151	\N	C	2019-12-20 22:13:53.799521+00	5554
4150	-3245	13	173	KFL 200@Lerskiva	\N	\N	1	1	-4150	\N	C	2019-12-20 22:13:53.799521+00	5555
4149	-3245	13	173	KFL 199@Kärl	\N	\N	1	1	-4149	\N	C	2019-12-20 22:13:53.799521+00	5556
4148	-3245	13	173	KFL 198@Kärl	\N	\N	1	1	-4148	\N	C	2019-12-20 22:13:53.799521+00	5557
4147	-3245	13	173	KFL 197@Lerskiva	\N	\N	1	1	-4147	\N	C	2019-12-20 22:13:53.799521+00	5558
4146	-3245	13	173	KFL 196@Lerskiva	\N	\N	1	1	-4146	\N	C	2019-12-20 22:13:53.799521+00	5559
4145	-3245	13	173	KFL 195@Lerskiva	\N	\N	1	1	-4145	\N	C	2019-12-20 22:13:53.799521+00	5560
4144	-3245	13	173	KFL 194@Lerskiva	\N	\N	1	1	-4144	\N	C	2019-12-20 22:13:53.799521+00	5561
4143	-3245	13	173	KFL 193@Kärl	\N	\N	1	1	-4143	\N	C	2019-12-20 22:13:53.799521+00	5562
4142	-3245	13	173	KFL 192@Lerskiva	\N	\N	1	1	-4142	\N	C	2019-12-20 22:13:53.799521+00	5563
4141	-3245	13	173	KFL 191@Kärl	\N	\N	1	1	-4141	\N	C	2019-12-20 22:13:53.799521+00	5564
4140	-3245	13	173	KFL 190@Kärl	\N	\N	1	1	-4140	\N	C	2019-12-20 22:13:53.799521+00	5565
4139	-3245	13	173	KFL 189@Kärl	\N	\N	1	1	-4139	\N	C	2019-12-20 22:13:53.799521+00	5566
4138	-3245	13	173	KFL 188@Kärl	\N	\N	1	1	-4138	\N	C	2019-12-20 22:13:53.799521+00	5567
4137	-3245	13	173	KFL 187@Kärl	\N	\N	1	1	-4137	\N	C	2019-12-20 22:13:53.799521+00	5568
4136	-3245	13	173	KFL 186@Kärl	\N	\N	1	1	-4136	\N	C	2019-12-20 22:13:53.799521+00	5569
4135	-3245	13	173	KFL 185@Kärl	\N	\N	1	1	-4135	\N	C	2019-12-20 22:13:53.799521+00	5570
4134	-3245	13	173	KFL 184@Kärl	\N	\N	1	1	-4134	\N	C	2019-12-20 22:13:53.799521+00	5571
4133	-3245	13	173	KFL 183@Kärl	\N	\N	1	1	-4133	\N	C	2019-12-20 22:13:53.799521+00	5572
4132	-3245	13	173	KFL 182@Kärl	\N	\N	1	1	-4132	\N	C	2019-12-20 22:13:53.799521+00	5573
4131	-3245	13	173	KFL 181@Kärl	\N	\N	1	1	-4131	\N	C	2019-12-20 22:13:53.799521+00	5574
4130	-3245	13	173	KFL 180@Kärl	\N	\N	1	1	-4130	\N	C	2019-12-20 22:13:53.799521+00	5575
4129	-3245	13	173	KFL 179@Kärl	\N	\N	1	1	-4129	\N	C	2019-12-20 22:13:53.799521+00	5576
4128	-3157	13	173	KFL 178@Kärl	\N	\N	1	1	-4128	\N	C	2019-12-20 22:13:53.799521+00	5577
4127	-3078	13	173	KFL 177@Kärl	\N	\N	1	1	-4127	\N	C	2019-12-20 22:13:53.799521+00	5578
4126	-3078	13	173	KFL 176@Kärl	\N	\N	1	1	-4126	\N	C	2019-12-20 22:13:53.799521+00	5579
4125	-3078	13	173	KFL 175@Kärl	\N	\N	1	1	-4125	\N	C	2019-12-20 22:13:53.799521+00	5580
4124	-3078	13	173	KFL 174@Kärl	\N	\N	1	1	-4124	\N	C	2019-12-20 22:13:53.799521+00	5581
4123	-3078	13	173	KFL 173@Kärl	\N	\N	1	1	-4123	\N	C	2019-12-20 22:13:53.799521+00	5582
4122	-3078	13	173	KFL 172@Kärl	\N	\N	1	1	-4122	\N	C	2019-12-20 22:13:53.799521+00	5583
4121	-3078	13	173	KFL 171@Kärl	\N	\N	1	1	-4121	\N	C	2019-12-20 22:13:53.799521+00	5584
4120	-3078	13	173	KFL 170@Kärl	\N	\N	1	1	-4120	\N	C	2019-12-20 22:13:53.799521+00	5585
4119	-3078	13	173	KFL 169@Kärl	\N	\N	1	1	-4119	\N	C	2019-12-20 22:13:53.799521+00	5586
4118	-3078	13	173	KFL 168@Kärl	\N	\N	1	1	-4118	\N	C	2019-12-20 22:13:53.799521+00	5587
4117	-3078	13	173	KFL 167@Kärl	\N	\N	1	1	-4117	\N	C	2019-12-20 22:13:53.799521+00	5588
4116	-3304	13	173	KFL 166@Kärl	\N	\N	1	1	-4116	\N	C	2019-12-20 22:13:53.799521+00	5589
4115	-3277	13	173	KFL 165@Kärl	\N	\N	1	1	-4115	\N	C	2019-12-20 22:13:53.799521+00	5590
4114	-3277	13	173	KFL 164@Kärl	\N	\N	1	1	-4114	\N	C	2019-12-20 22:13:53.799521+00	5591
4113	-3277	13	173	KFL 163@Kärl	\N	\N	1	1	-4113	\N	C	2019-12-20 22:13:53.799521+00	5592
4112	-3277	13	173	KFL 162@Kärl	\N	\N	1	1	-4112	\N	C	2019-12-20 22:13:53.799521+00	5593
4111	-2977	13	173	KFL 161@Kärl	\N	\N	1	1	-4111	\N	C	2019-12-20 22:13:53.799521+00	5594
4110	-2977	13	173	KFL 160@Kärl	\N	\N	1	1	-4110	\N	C	2019-12-20 22:13:53.799521+00	5595
4109	-3026	13	173	KFL 159@Kärl	\N	\N	1	1	-4109	\N	C	2019-12-20 22:13:53.799521+00	5596
4108	-3026	13	173	KFL 158@Kärl	\N	\N	1	1	-4108	\N	C	2019-12-20 22:13:53.799521+00	5597
4107	-3026	13	173	KFL 157@Kärl	\N	\N	1	1	-4107	\N	C	2019-12-20 22:13:53.799521+00	5598
4106	-3076	13	173	KFL 149@Kärl	\N	\N	1	1	-4106	\N	C	2019-12-20 22:13:53.799521+00	5599
4105	-3076	13	173	KFL 148@Kärl	\N	\N	1	1	-4105	\N	C	2019-12-20 22:13:53.799521+00	5600
4104	-3223	13	173	KFL 143@Kärl	\N	\N	1	1	-4104	\N	C	2019-12-20 22:13:53.799521+00	5601
4103	-3223	13	173	KFL 142@Kärl	\N	\N	1	1	-4103	\N	C	2019-12-20 22:13:53.799521+00	5602
4102	-3223	13	173	KFL 141@Kärl	\N	\N	1	1	-4102	\N	C	2019-12-20 22:13:53.799521+00	5603
4101	-3223	13	173	KFL 140@Kärl	\N	\N	1	1	-4101	\N	C	2019-12-20 22:13:53.799521+00	5604
4100	-3223	13	173	KFL 139@Kärl	\N	\N	1	1	-4100	\N	C	2019-12-20 22:13:53.799521+00	5605
4099	-3223	13	173	KFL 138@Lerskiva	\N	\N	1	1	-4099	\N	C	2019-12-20 22:13:53.799521+00	5606
4098	-3223	13	173	KFL 137@Kärl	\N	\N	1	1	-4098	\N	C	2019-12-20 22:13:53.799521+00	5607
4097	-3195	13	173	KFL 136@Kärl	\N	\N	1	1	-4097	\N	C	2019-12-20 22:13:53.799521+00	5608
4096	-3002	13	173	KFL 135@Kärl	\N	\N	1	1	-4096	\N	C	2019-12-20 22:13:53.799521+00	5609
4095	-3002	13	173	KFL 134@Kärl	\N	\N	1	1	-4095	\N	C	2019-12-20 22:13:53.799521+00	5610
4094	-3239	13	173	KFL 133@Kärl	\N	\N	1	1	-4094	\N	C	2019-12-20 22:13:53.799521+00	5611
4093	-3239	13	173	KFL 132@Kärl	\N	\N	1	1	-4093	\N	C	2019-12-20 22:13:53.799521+00	5612
4092	-3239	13	173	KFL 131@Kärl	\N	\N	1	1	-4092	\N	C	2019-12-20 22:13:53.799521+00	5613
4091	-3239	13	173	KFL 130@Kärl	\N	\N	1	1	-4091	\N	C	2019-12-20 22:13:53.799521+00	5614
4090	-3239	13	173	KFL 129@Kärl	\N	\N	1	1	-4090	\N	C	2019-12-20 22:13:53.799521+00	5615
4089	-3239	13	173	KFL 128@Kärl	\N	\N	1	1	-4089	\N	C	2019-12-20 22:13:53.799521+00	5616
4088	-3239	13	173	KFL 127@Kärl	\N	\N	1	1	-4088	\N	C	2019-12-20 22:13:53.799521+00	5617
4087	-3328	13	173	KFL 126@Kärl	\N	\N	1	1	-4087	\N	C	2019-12-20 22:13:53.799521+00	5618
4086	-3188	13	173	KFL 125@Kärl	\N	\N	1	1	-4086	\N	C	2019-12-20 22:13:53.799521+00	5619
4085	-3188	13	173	KFL 124@Kärl	\N	\N	1	1	-4085	\N	C	2019-12-20 22:13:53.799521+00	5620
4084	-3188	13	173	KFL 123@Kärl	\N	\N	1	1	-4084	\N	C	2019-12-20 22:13:53.799521+00	5621
4083	-3188	13	173	KFL 122@Kärl	\N	\N	1	1	-4083	\N	C	2019-12-20 22:13:53.799521+00	5622
4082	-3141	13	173	KFL 121@Kärl	\N	\N	1	1	-4082	\N	C	2019-12-20 22:13:53.799521+00	5623
4081	-3189	13	173	KFL 117@Kärl	\N	\N	1	1	-4081	\N	C	2019-12-20 22:13:53.799521+00	5624
4080	-3189	13	173	KFL 116@Kärl	\N	\N	1	1	-4080	\N	C	2019-12-20 22:13:53.799521+00	5625
4079	-3189	13	173	KFL 115@Kärl	\N	\N	1	1	-4079	\N	C	2019-12-20 22:13:53.799521+00	5626
4078	-3189	13	173	KFL 114@Kärl	\N	\N	1	1	-4078	\N	C	2019-12-20 22:13:53.799521+00	5627
4077	-3024	13	173	KFL 113@Kärl	\N	\N	1	1	-4077	\N	C	2019-12-20 22:13:53.799521+00	5628
4076	-3049	13	173	KFL 112@Kärl	\N	\N	1	1	-4076	\N	C	2019-12-20 22:13:53.799521+00	5629
4075	-3049	13	173	KFL 111@Kärl	\N	\N	1	1	-4075	\N	C	2019-12-20 22:13:53.799521+00	5630
4074	-3316	13	173	KFL 110@Kärl	\N	\N	1	1	-4074	\N	C	2019-12-20 22:13:53.799521+00	5631
4073	-3316	13	173	KFL 109@Kärl	\N	\N	1	1	-4073	\N	C	2019-12-20 22:13:53.799521+00	5632
4072	-3049	13	173	KFL 108@Kärl	\N	\N	1	1	-4072	\N	C	2019-12-20 22:13:53.799521+00	5633
4071	-3316	13	173	KFL 107@Kärl	\N	\N	1	1	-4071	\N	C	2019-12-20 22:13:53.799521+00	5634
4070	-3363	13	173	KFL 106@Kärl	\N	\N	1	1	-4070	\N	C	2019-12-20 22:13:53.799521+00	5635
4069	-3100	13	173	KFL 105@Kärl	\N	\N	1	1	-4069	\N	C	2019-12-20 22:13:53.799521+00	5636
4068	-3100	13	173	KFL 104@Kärl	\N	\N	1	1	-4068	\N	C	2019-12-20 22:13:53.799521+00	5637
4067	-3100	13	173	KFL 103@Kärl	\N	\N	1	1	-4067	\N	C	2019-12-20 22:13:53.799521+00	5638
4066	-3100	13	173	KFL 102@Kärl	\N	\N	1	1	-4066	\N	C	2019-12-20 22:13:53.799521+00	5639
4065	-3101	13	173	KFL 101@Kärl	\N	\N	1	1	-4065	\N	C	2019-12-20 22:13:53.799521+00	5640
4064	-3101	13	173	KFL 100@Kärl	\N	\N	1	1	-4064	\N	C	2019-12-20 22:13:53.799521+00	5641
4063	-3101	13	173	KFL 99@Kärl	\N	\N	1	1	-4063	\N	C	2019-12-20 22:13:53.799521+00	5642
4062	-3101	13	173	KFL 98@Kärl	\N	\N	1	1	-4062	\N	C	2019-12-20 22:13:53.799521+00	5643
4061	-3101	13	173	KFL 97@Kärl	\N	\N	1	1	-4061	\N	C	2019-12-20 22:13:53.799521+00	5644
4060	-3135	13	173	KFL 96@Kärl	\N	\N	1	1	-4060	\N	C	2019-12-20 22:13:53.799521+00	5645
4059	-3135	13	173	KFL 95@Kärl	\N	\N	1	1	-4059	\N	C	2019-12-20 22:13:53.799521+00	5646
4058	-3228	13	173	KFL 93@Kärl	\N	\N	1	1	-4058	\N	C	2019-12-20 22:13:53.799521+00	5647
4057	-3228	13	173	KFL 92@Kärl	\N	\N	1	1	-4057	\N	C	2019-12-20 22:13:53.799521+00	5648
4056	-3228	13	173	KFL 91@Kärl	\N	\N	1	1	-4056	\N	C	2019-12-20 22:13:53.799521+00	5649
4055	-3228	13	173	KFL 90@Kärl	\N	\N	1	1	-4055	\N	C	2019-12-20 22:13:53.799521+00	5650
4054	-3228	13	173	KFL 89@Kärl	\N	\N	1	1	-4054	\N	C	2019-12-20 22:13:53.799521+00	5651
4053	-3228	13	173	KFL 88@Kärl	\N	\N	1	1	-4053	\N	C	2019-12-20 22:13:53.799521+00	5652
4052	-3228	13	173	KFL 87@Kärl	\N	\N	1	1	-4052	\N	C	2019-12-20 22:13:53.799521+00	5653
4051	-3228	13	173	KFL 86@Kärl	\N	\N	1	1	-4051	\N	C	2019-12-20 22:13:53.799521+00	5654
4050	-3228	13	173	KFL 85@Kärl	\N	\N	1	1	-4050	\N	C	2019-12-20 22:13:53.799521+00	5655
4049	-3228	13	173	KFL 84@Kärl	\N	\N	1	1	-4049	\N	C	2019-12-20 22:13:53.799521+00	5656
4048	-3228	13	173	KFL 83@Kärl	\N	\N	1	1	-4048	\N	C	2019-12-20 22:13:53.799521+00	5657
4047	-3285	13	173	KFL 82@Kärl	\N	\N	1	1	-4047	\N	C	2019-12-20 22:13:53.799521+00	5658
4046	-3303	13	173	KFL 81@Kärl	\N	\N	1	1	-4046	\N	C	2019-12-20 22:13:53.799521+00	5659
4045	-3303	13	173	KFL 80@Kärl	\N	\N	1	1	-4045	\N	C	2019-12-20 22:13:53.799521+00	5660
4044	-3303	13	173	KFL 79@Lampa	\N	\N	1	1	-4044	\N	C	2019-12-20 22:13:53.799521+00	5661
4043	-3351	13	173	KFL 69@Kärl	\N	\N	1	1	-4043	\N	C	2019-12-20 22:13:53.799521+00	5662
4042	-3351	13	173	KFL 68@Kärl	\N	\N	1	1	-4042	\N	C	2019-12-20 22:13:53.799521+00	5663
4041	-3351	13	173	KFL 67@Kärl	\N	\N	1	1	-4041	\N	C	2019-12-20 22:13:53.799521+00	5664
4040	-3351	13	173	KFL 66@Kärl	\N	\N	1	1	-4040	\N	C	2019-12-20 22:13:53.799521+00	5665
4039	-3351	13	173	KFL 65@Kärl	\N	\N	1	1	-4039	\N	C	2019-12-20 22:13:53.799521+00	5666
4038	-3351	13	173	KFL 64@Kärl	\N	\N	1	1	-4038	\N	C	2019-12-20 22:13:53.799521+00	5667
4037	-3351	13	173	KFL 63@Kärl	\N	\N	1	1	-4037	\N	C	2019-12-20 22:13:53.799521+00	5668
4036	-3351	13	173	KFL 62@Kärl	\N	\N	1	1	-4036	\N	C	2019-12-20 22:13:53.799521+00	5669
4035	-3351	13	173	KFL 61@Kärl	\N	\N	1	1	-4035	\N	C	2019-12-20 22:13:53.799521+00	5670
4034	-3039	13	173	KFL 60@Kärl	\N	\N	1	1	-4034	\N	C	2019-12-20 22:13:53.799521+00	5671
4033	-3304	13	173	KFL 59@Kärl	\N	\N	1	1	-4033	\N	C	2019-12-20 22:13:53.799521+00	5672
4032	-3218	13	173	KFL 58@Kärl	\N	\N	1	1	-4032	\N	C	2019-12-20 22:13:53.799521+00	5673
4031	-3218	13	173	KFL 57@Kärl	\N	\N	1	1	-4031	\N	C	2019-12-20 22:13:53.799521+00	5674
4030	-3218	13	173	KFL 56@Kärl	\N	\N	1	1	-4030	\N	C	2019-12-20 22:13:53.799521+00	5675
4029	-3218	13	173	KFL 55@Kärl	\N	\N	1	1	-4029	\N	C	2019-12-20 22:13:53.799521+00	5676
4028	-3078	13	173	KFL 53@Kärl	\N	\N	1	1	-4028	\N	C	2019-12-20 22:13:53.799521+00	5677
4027	-3330	13	173	KFL 52@Kärl	\N	\N	1	1	-4027	\N	C	2019-12-20 22:13:53.799521+00	5678
4026	-3330	13	173	KFL 51@Kärl	\N	\N	1	1	-4026	\N	C	2019-12-20 22:13:53.799521+00	5679
4025	-3330	13	173	KFL 50@Kärl	\N	\N	1	1	-4025	\N	C	2019-12-20 22:13:53.799521+00	5680
4024	-3330	13	173	KFL 49@Kärl	\N	\N	1	1	-4024	\N	C	2019-12-20 22:13:53.799521+00	5681
4023	-3286	13	173	KFL 47@Kärl	\N	\N	1	1	-4023	\N	C	2019-12-20 22:13:53.799521+00	5682
4022	-3286	13	173	KFL 46@Kärl	\N	\N	1	1	-4022	\N	C	2019-12-20 22:13:53.799521+00	5683
4021	-3286	13	173	KFL 45@Kärl	\N	\N	1	1	-4021	\N	C	2019-12-20 22:13:53.799521+00	5684
4020	-3286	13	173	KFL 44@Kärl	\N	\N	1	1	-4020	\N	C	2019-12-20 22:13:53.799521+00	5685
4019	-3055	13	173	KFL 39@Kärl	\N	\N	1	1	-4019	\N	C	2019-12-20 22:13:53.799521+00	5686
4018	-3055	13	173	KFL 38@Kärl	\N	\N	1	1	-4018	\N	C	2019-12-20 22:13:53.799521+00	5687
4017	-3055	13	173	KFL 37@Kärl	\N	\N	1	1	-4017	\N	C	2019-12-20 22:13:53.799521+00	5688
4016	-3055	13	173	KFL 36@Kärl	\N	\N	1	1	-4016	\N	C	2019-12-20 22:13:53.799521+00	5689
4015	-3055	13	173	KFL 35@Kärl	\N	\N	1	1	-4015	\N	C	2019-12-20 22:13:53.799521+00	5690
4014	-3055	13	173	KFL 34@Lampa	\N	\N	1	1	-4014	\N	C	2019-12-20 22:13:53.799521+00	5691
4013	-3282	13	173	KFL 33@Kärl	\N	\N	1	1	-4013	\N	C	2019-12-20 22:13:53.799521+00	5692
4012	-3282	13	173	KFL 32@Kärl	\N	\N	1	1	-4012	\N	C	2019-12-20 22:13:53.799521+00	5693
4011	-3282	13	173	KFL 31@Kärl	\N	\N	1	1	-4011	\N	C	2019-12-20 22:13:53.799521+00	5694
4010	-3282	13	173	KFL 30@Lampa	\N	\N	1	1	-4010	\N	C	2019-12-20 22:13:53.799521+00	5695
4009	-3282	13	173	KFL 29@Kärl	\N	\N	1	1	-4009	\N	C	2019-12-20 22:13:53.799521+00	5696
4008	-3282	13	173	KFL 28@Kärl	\N	\N	1	1	-4008	\N	C	2019-12-20 22:13:53.799521+00	5697
4007	-3282	13	173	KFL 27@Lampa	\N	\N	1	1	-4007	\N	C	2019-12-20 22:13:53.799521+00	5698
4006	-3282	13	173	KFL 26@Kärl	\N	\N	1	1	-4006	\N	C	2019-12-20 22:13:53.799521+00	5699
4005	-3282	13	173	KFL 25@Kärl	\N	\N	1	1	-4005	\N	C	2019-12-20 22:13:53.799521+00	5700
4004	-3282	13	173	KFL 24@Kärl	\N	\N	1	1	-4004	\N	C	2019-12-20 22:13:53.799521+00	5701
4003	-3282	13	173	KFL 23@Kärl	\N	\N	1	1	-4003	\N	C	2019-12-20 22:13:53.799521+00	5702
4002	-3254	13	173	KFL 22@Kärl	\N	\N	1	1	-4002	\N	C	2019-12-20 22:13:53.799521+00	5703
4001	-3254	13	173	KFL 21@Lampa	\N	\N	1	1	-4001	\N	C	2019-12-20 22:13:53.799521+00	5704
4000	-3254	13	173	KFL 20@Kärl	\N	\N	1	1	-4000	\N	C	2019-12-20 22:13:53.799521+00	5705
3999	-3254	13	173	KFL 19@Lampa	\N	\N	1	1	-3999	\N	C	2019-12-20 22:13:53.799521+00	5706
3998	-3254	13	173	KFL 18@Kärl	\N	\N	1	1	-3998	\N	C	2019-12-20 22:13:53.799521+00	5707
3997	-3254	13	173	KFL 17@Kärl	\N	\N	1	1	-3997	\N	C	2019-12-20 22:13:53.799521+00	5708
3996	-3123	13	173	KFL 14@Kärl	\N	\N	1	1	-3996	\N	C	2019-12-20 22:13:53.799521+00	5709
3995	-3123	13	173	KFL 13@Kärl	\N	\N	1	1	-3995	\N	C	2019-12-20 22:13:53.799521+00	5710
3994	-3123	13	173	KFL 12@Kärl	\N	\N	1	1	-3994	\N	C	2019-12-20 22:13:53.799521+00	5711
3993	-3218	13	173	KFL 11@Lampa	\N	\N	1	1	-3993	\N	C	2019-12-20 22:13:53.799521+00	5712
3992	-3218	13	173	KFL 10@Kärl	\N	\N	1	1	-3992	\N	C	2019-12-20 22:13:53.799521+00	5713
3991	-3218	13	173	KFL 9@Kärl	\N	\N	1	1	-3991	\N	C	2019-12-20 22:13:53.799521+00	5714
3990	-3218	13	173	KFL 8@Kärl	\N	\N	1	1	-3990	\N	C	2019-12-20 22:13:53.799521+00	5715
3989	-3218	13	173	KFL 7@Kärl	\N	\N	1	1	-3989	\N	C	2019-12-20 22:13:53.799521+00	5716
3988	-3218	13	173	KFL 6@Kärl	\N	\N	1	1	-3988	\N	C	2019-12-20 22:13:53.799521+00	5717
3987	-3304	13	173	KFL 5@Kärl	\N	\N	1	1	-3987	\N	C	2019-12-20 22:13:53.799521+00	5718
3986	-3370	13	173	KFL 4@Lampa	\N	\N	1	1	-3986	\N	C	2019-12-20 22:13:53.799521+00	5719
3985	-3370	13	173	KFL 3@Kärl	\N	\N	1	1	-3985	\N	C	2019-12-20 22:13:53.799521+00	5720
3984	-3370	13	173	KFL 2@Kärl	\N	\N	1	1	-3984	\N	C	2019-12-20 22:13:53.799521+00	5721
3983	-3223	13	173	KFL 1@Lampa	\N	\N	1	1	-3983	\N	C	2019-12-20 22:13:53.799521+00	5722
