0	0	Not specified
127	134	Biblio
131	44	Dendro
133	126	Geochronology
134	81	Lithology
137	30	Rdb
1	19	Abundance Elements
2	87	Abundance Ident Levels
3	49	Abundance Modifications
4	32	Abundances
5	42	Activity Types
6	7	Age Types
7	24	Aggregate Datasets
8	116	Aggregate Order Types
9	115	Aggregate Sample Ages
10	56	Aggregate Samples
11	46	Alt Ref Types
12	118	Analysis Entities
13	120	Analysis Entity Ages
14	16	Analysis Entity Dimensions
15	97	Analysis Entity Prep Methods
16	83	Ceramics
17	91	Ceramics Measurements
18	75	Chron Controls
19	26	Chron Control Types
20	64	Chronologies
21	143	Colours
22	139	Contacts
23	34	Contact Types
24	124	Coordinate Method Dimensions
25	114	Dataset Contacts
26	67	Dataset Masters
27	51	Dataset Methods
28	93	Datasets
29	8	Dataset Submissions
30	23	Dataset Submission Types
31	21	Data Type Groups
32	128	Data Types
33	61	Dating Labs
34	11	Dendro Date Notes
35	106	Dendro Dates
36	52	Dendro Measurements
37	110	Dimensions
38	9	Ecocode Definitions
39	113	Ecocode Groups
40	99	Ecocodes
41	37	Ecocode Systems
42	2	Error Uncertainties
43	40	Features
44	95	Feature Types
45	108	Geochron Refs
46	80	Horizons
47	33	Identification Levels
48	73	Image Types
49	31	Imported Taxa Replacements
50	71	Isotope Measurements
51	47	Isotopes
52	96	Isotope Standards
53	112	Isotope Types
54	82	Isotope Value Specifiers
55	89	Languages
56	10	Locations
57	146	Location Types
58	45	Mcr Names
59	85	Measured Value Dimensions
60	125	Measured Values
61	48	Method Groups
62	50	Methods
63	54	Modification Types
64	5	Physical Sample Features
65	79	Physical Samples
66	43	Projects
67	88	Project Stages
68	141	Project Types
69	74	Rdb Codes
70	76	Rdb Systems
71	6	Record Types
72	136	Relative Age Refs
73	131	Relative Ages
74	119	Relative Age Types
75	138	Relative Dates
76	121	Sample Alt Refs
77	129	Sample Colours
78	70	Sample Coordinates
79	107	Sample Descriptions
80	109	Sample Description Sample Group Contexts
81	20	Sample Description Types
82	103	Sample Dimensions
83	63	Sample Group Coordinates
84	122	Sample Group Descriptions
85	25	Sample Group Description Types
86	72	Sample Group Description Type Sampling Contexts
87	18	Sample Group Dimensions
88	137	Sample Group Images
89	90	Sample Group Notes
90	3	Sample Group References
91	123	Sample Groups
92	68	Sample Group Sampling Contexts
93	94	Sample Horizons
94	65	Sample Images
95	69	Sample Locations
96	27	Sample Location Types
97	86	Sample Location Type Sampling Contexts
98	17	Sample Notes
99	1	Sample Types
100	144	Seasons
101	117	Season Types
102	36	Site Images
103	57	Site Locations
104	104	Site Natgridrefs
105	62	Site Other Records
106	66	Site Preservation Status
107	127	Site References
108	140	Sites
109	133	Species Associations
110	84	Species Association Types
111	58	Taxa Common Names
112	39	Taxa Images
113	29	Taxa Measured Attributes
114	55	Taxa Reference Specimens
115	60	Taxa Synonyms
116	98	Taxa Tree Authors
117	78	Taxa Tree Families
118	145	Taxa Tree Orders
119	102	Taxonomic Order Systems
120	4	Taxonomy Notes
121	41	Tephra Dates
122	38	Tephra Refs
123	77	Tephras
124	132	Text Identification Keys
125	22	Units
126	53	Years Types
128	12	Ceramics Lookup
129	28	Dating Material
130	105	Dating Uncertainty
132	100	Dendro Lookup
135	101	Mcrdata Birmbeetledat
136	92	Mcr Summary Data
138	111	Season Or Qualifier
139	130	Taxa Seasonality
140	59	Taxa Tree Genera
141	135	Taxa Tree Master
142	35	Taxonomic Order
143	13	Taxonomic Order Biblio
144	14	Text Biology
145	15	Text Distribution
146	142	Updates Log
