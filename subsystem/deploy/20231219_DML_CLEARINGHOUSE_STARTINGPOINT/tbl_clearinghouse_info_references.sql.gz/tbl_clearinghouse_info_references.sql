1	link	SEAD overview article	http://bugscep.com/phil/publications/Buckland2010_jns.pdf
2	link	Popular science description of SEAD aims	http://bugscep.com/phil/publications/buckland2011_international_innovation.pdf
