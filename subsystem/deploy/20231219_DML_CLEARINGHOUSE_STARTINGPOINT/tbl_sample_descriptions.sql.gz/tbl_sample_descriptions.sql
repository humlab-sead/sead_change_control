323	2	-323	rim of initial Jomon pottery of type SIV	\N	4	1	-323	\N	C	2019-12-20 22:14:28.053842+00	4102
322	2	-322	rim of initial Jomon pottery of type SIV	\N	4	1	-322	\N	C	2019-12-20 22:14:28.053842+00	4103
321	2	-321	rim of initial Jomon pottery of type SIV	\N	4	1	-321	\N	C	2019-12-20 22:14:28.053842+00	4104
320	2	-320	rim of initial Jomon pottery of type SIV	\N	4	1	-320	\N	C	2019-12-20 22:14:28.053842+00	4105
319	2	-319	rim of initial Jomon pottery of type SIV	\N	4	1	-319	\N	C	2019-12-20 22:14:28.053842+00	4106
318	2	-318	body of initial Jomon pottery of type SIV	\N	4	1	-318	\N	C	2019-12-20 22:14:28.053842+00	4107
317	2	-317	rim of initial Jomon pottery of type SIV	\N	4	1	-317	\N	C	2019-12-20 22:14:28.053842+00	4108
316	2	-316	rim of initial Jomon pottery of type SIV	\N	4	1	-316	\N	C	2019-12-20 22:14:28.053842+00	4109
315	2	-315	rim of initial Jomon pottery of type SIV	\N	4	1	-315	\N	C	2019-12-20 22:14:28.053842+00	4110
314	2	-314	rim of initial Jomon pottery of type SIV	\N	4	1	-314	\N	C	2019-12-20 22:14:28.053842+00	4111
313	2	-313	rim of initial Jomon pottery of type SIV	\N	4	1	-313	\N	C	2019-12-20 22:14:28.053842+00	4112
312	2	-312	rim of initial Jomon pottery of type SIV	\N	4	1	-312	\N	C	2019-12-20 22:14:28.053842+00	4113
311	2	-311	rim of initial Jomon pottery of type SIV	\N	4	1	-311	\N	C	2019-12-20 22:14:28.053842+00	4114
310	2	-310	rim of initial Jomon pottery of type SIV	\N	4	1	-310	\N	C	2019-12-20 22:14:28.053842+00	4115
309	2	-309	rim of initial Jomon pottery of type SIV	\N	4	1	-309	\N	C	2019-12-20 22:14:28.053842+00	4116
308	2	-308	body of initial Jomon pottery of type SIV	\N	4	1	-308	\N	C	2019-12-20 22:14:28.053842+00	4117
307	2	-307	body of initial Jomon pottery of type SIV	\N	4	1	-307	\N	C	2019-12-20 22:14:28.053842+00	4118
944	2	-944	unknown part of initial Jomon pottery of type SIV	\N	4	1	-944	\N	C	2019-12-20 22:14:28.053842+00	3481
943	2	-943	unknown part of initial Jomon pottery of type SIV	\N	4	1	-943	\N	C	2019-12-20 22:14:28.053842+00	3482
942	2	-942	unknown part of initial Jomon pottery of type SIV	\N	4	1	-942	\N	C	2019-12-20 22:14:28.053842+00	3483
941	2	-941	unknown part of initial Jomon pottery of type SIV	\N	4	1	-941	\N	C	2019-12-20 22:14:28.053842+00	3484
940	2	-940	unknown part of initial Jomon pottery of type SIV	\N	4	1	-940	\N	C	2019-12-20 22:14:28.053842+00	3485
939	2	-939	unknown part of initial Jomon pottery of type SIV	\N	4	1	-939	\N	C	2019-12-20 22:14:28.053842+00	3486
938	2	-938	body of initial Jomon pottery of type SIV	\N	4	1	-938	\N	C	2019-12-20 22:14:28.053842+00	3487
937	2	-937	body of initial Jomon pottery of type SIV	\N	4	1	-937	\N	C	2019-12-20 22:14:28.053842+00	3488
936	2	-936	body of initial Jomon pottery of type SIV	\N	4	1	-936	\N	C	2019-12-20 22:14:28.053842+00	3489
935	2	-935	body of initial Jomon pottery of type SIV	\N	4	1	-935	\N	C	2019-12-20 22:14:28.053842+00	3490
934	2	-934	unknown part of initial Jomon pottery of type SIV	\N	4	1	-934	\N	C	2019-12-20 22:14:28.053842+00	3491
933	2	-933	body of initial Jomon pottery of type SIV	\N	4	1	-933	\N	C	2019-12-20 22:14:28.053842+00	3492
932	2	-932	body of initial Jomon pottery of type SIV	\N	4	1	-932	\N	C	2019-12-20 22:14:28.053842+00	3493
931	2	-931	unknown part of initial Jomon pottery of type SIV	\N	4	1	-931	\N	C	2019-12-20 22:14:28.053842+00	3494
930	2	-930	rim of initial Jomon pottery of type SIV	\N	4	1	-930	\N	C	2019-12-20 22:14:28.053842+00	3495
929	2	-929	rim of initial Jomon pottery of type SIV	\N	4	1	-929	\N	C	2019-12-20 22:14:28.053842+00	3496
928	2	-928	rim of initial Jomon pottery of type SIV	\N	4	1	-928	\N	C	2019-12-20 22:14:28.053842+00	3497
927	2	-927	body of initial Jomon pottery of type SIV	\N	4	1	-927	\N	C	2019-12-20 22:14:28.053842+00	3498
926	2	-926	body of initial Jomon pottery of type SIV	\N	4	1	-926	\N	C	2019-12-20 22:14:28.053842+00	3499
925	2	-925	rim of initial Jomon pottery of type SIV	\N	4	1	-925	\N	C	2019-12-20 22:14:28.053842+00	3500
924	2	-924	rim of initial Jomon pottery of type SIV	\N	4	1	-924	\N	C	2019-12-20 22:14:28.053842+00	3501
923	2	-923	rim of initial Jomon pottery of type SIV	\N	4	1	-923	\N	C	2019-12-20 22:14:28.053842+00	3502
922	2	-922	body of initial Jomon pottery of type SIV	\N	4	1	-922	\N	C	2019-12-20 22:14:28.053842+00	3503
921	2	-921	body of initial Jomon pottery of type SIV	\N	4	1	-921	\N	C	2019-12-20 22:14:28.053842+00	3504
920	2	-920	body of initial Jomon pottery of type SIV	\N	4	1	-920	\N	C	2019-12-20 22:14:28.053842+00	3505
919	2	-919	body of initial Jomon pottery of type SIV	\N	4	1	-919	\N	C	2019-12-20 22:14:28.053842+00	3506
918	2	-918	body of initial Jomon pottery of type SIV	\N	4	1	-918	\N	C	2019-12-20 22:14:28.053842+00	3507
917	2	-917	body of initial Jomon pottery of type SIV	\N	4	1	-917	\N	C	2019-12-20 22:14:28.053842+00	3508
916	2	-916	body of initial Jomon pottery of type SIV	\N	4	1	-916	\N	C	2019-12-20 22:14:28.053842+00	3509
915	2	-915	body of initial Jomon pottery of type SIV	\N	4	1	-915	\N	C	2019-12-20 22:14:28.053842+00	3510
914	2	-914	body of initial Jomon pottery of type SIV	\N	4	1	-914	\N	C	2019-12-20 22:14:28.053842+00	3511
913	2	-913	rim of initial Jomon pottery of type SIV	\N	4	1	-913	\N	C	2019-12-20 22:14:28.053842+00	3512
912	2	-912	body of initial Jomon pottery of type SIV	\N	4	1	-912	\N	C	2019-12-20 22:14:28.053842+00	3513
911	2	-911	body of initial Jomon pottery of type SIV	\N	4	1	-911	\N	C	2019-12-20 22:14:28.053842+00	3514
910	2	-910	body of initial Jomon pottery of type SIV	\N	4	1	-910	\N	C	2019-12-20 22:14:28.053842+00	3515
909	2	-909	body of initial Jomon pottery of type SIV	\N	4	1	-909	\N	C	2019-12-20 22:14:28.053842+00	3516
908	2	-908	body of initial Jomon pottery of type SIV	\N	4	1	-908	\N	C	2019-12-20 22:14:28.053842+00	3517
907	2	-907	body of initial Jomon pottery of type SIV	\N	4	1	-907	\N	C	2019-12-20 22:14:28.053842+00	3518
906	2	-906	body of initial Jomon pottery of type SIV	\N	4	1	-906	\N	C	2019-12-20 22:14:28.053842+00	3519
905	2	-905	body of initial Jomon pottery of type SIV	\N	4	1	-905	\N	C	2019-12-20 22:14:28.053842+00	3520
904	2	-904	body of initial Jomon pottery of type SIV	\N	4	1	-904	\N	C	2019-12-20 22:14:28.053842+00	3521
903	2	-903	body of initial Jomon pottery of type SIV	\N	4	1	-903	\N	C	2019-12-20 22:14:28.053842+00	3522
902	2	-902	body of initial Jomon pottery of type SIV	\N	4	1	-902	\N	C	2019-12-20 22:14:28.053842+00	3523
901	2	-901	unknown part of initial Jomon pottery of type SIV	\N	4	1	-901	\N	C	2019-12-20 22:14:28.053842+00	3524
900	2	-900	unknown part of initial Jomon pottery of type SIV	\N	4	1	-900	\N	C	2019-12-20 22:14:28.053842+00	3525
899	2	-899	unknown part of incipient Jomon pottery of type SIII	\N	4	1	-899	\N	C	2019-12-20 22:14:28.053842+00	3526
898	2	-898	unknown part of incipient Jomon pottery of type SIII	\N	4	1	-898	\N	C	2019-12-20 22:14:28.053842+00	3527
897	2	-897	body of initial Jomon pottery of type SIV	\N	4	1	-897	\N	C	2019-12-20 22:14:28.053842+00	3528
896	2	-896	body of initial Jomon pottery of type SIV	\N	4	1	-896	\N	C	2019-12-20 22:14:28.053842+00	3529
895	2	-895	body of initial Jomon pottery of type SIV	\N	4	1	-895	\N	C	2019-12-20 22:14:28.053842+00	3530
894	2	-894	body of initial Jomon pottery of type SIV	\N	4	1	-894	\N	C	2019-12-20 22:14:28.053842+00	3531
893	2	-893	body of initial Jomon pottery of type SIV	\N	4	1	-893	\N	C	2019-12-20 22:14:28.053842+00	3532
892	2	-892	body of initial Jomon pottery of type SIV	\N	4	1	-892	\N	C	2019-12-20 22:14:28.053842+00	3533
891	2	-891	body of initial Jomon pottery of type SIV	\N	4	1	-891	\N	C	2019-12-20 22:14:28.053842+00	3534
890	2	-890	body of initial Jomon pottery of type SIV	\N	4	1	-890	\N	C	2019-12-20 22:14:28.053842+00	3535
889	2	-889	rim-upper body of initial Jomon pottery of type SIV	\N	4	1	-889	\N	C	2019-12-20 22:14:28.053842+00	3536
888	2	-888	rim of initial Jomon pottery of type SIV	\N	4	1	-888	\N	C	2019-12-20 22:14:28.053842+00	3537
887	2	-887	base of initial Jomon pottery of type SIV	\N	4	1	-887	\N	C	2019-12-20 22:14:28.053842+00	3538
886	2	-886	body of initial Jomon pottery of type SIV	\N	4	1	-886	\N	C	2019-12-20 22:14:28.053842+00	3539
885	2	-885	rim of initial Jomon pottery of type SIV	\N	4	1	-885	\N	C	2019-12-20 22:14:28.053842+00	3540
884	2	-884	rim-upper body of initial Jomon pottery of type SIV	\N	4	1	-884	\N	C	2019-12-20 22:14:28.053842+00	3541
883	2	-883	base of initial Jomon pottery of type SIV	\N	4	1	-883	\N	C	2019-12-20 22:14:28.053842+00	3542
882	2	-882	rim of initial Jomon pottery of type SIV	\N	4	1	-882	\N	C	2019-12-20 22:14:28.053842+00	3543
881	2	-881	rim of initial Jomon pottery of type SIV	\N	4	1	-881	\N	C	2019-12-20 22:14:28.053842+00	3544
880	2	-880	body of initial Jomon pottery of type SIV	\N	4	1	-880	\N	C	2019-12-20 22:14:28.053842+00	3545
879	2	-879	base of initial Jomon pottery of type SIV	\N	4	1	-879	\N	C	2019-12-20 22:14:28.053842+00	3546
878	2	-878	body of initial Jomon pottery of type SIV	\N	4	1	-878	\N	C	2019-12-20 22:14:28.053842+00	3547
877	2	-877	body of initial Jomon pottery of type SIV	\N	4	1	-877	\N	C	2019-12-20 22:14:28.053842+00	3548
876	2	-876	rim of initial Jomon pottery of type SIV	\N	4	1	-876	\N	C	2019-12-20 22:14:28.053842+00	3549
875	2	-875	body of initial Jomon pottery of type SIV	\N	4	1	-875	\N	C	2019-12-20 22:14:28.053842+00	3550
874	2	-874	rim of initial Jomon pottery of type SIV	\N	4	1	-874	\N	C	2019-12-20 22:14:28.053842+00	3551
873	2	-873	body of initial Jomon pottery of type SIV	\N	4	1	-873	\N	C	2019-12-20 22:14:28.053842+00	3552
872	2	-872	body of initial Jomon pottery of type SIV	\N	4	1	-872	\N	C	2019-12-20 22:14:28.053842+00	3553
871	2	-871	body of initial Jomon pottery of type SIV	\N	4	1	-871	\N	C	2019-12-20 22:14:28.053842+00	3554
870	2	-870	body of initial Jomon pottery of type SIV	\N	4	1	-870	\N	C	2019-12-20 22:14:28.053842+00	3555
869	2	-869	body of initial Jomon pottery of type SIV	\N	4	1	-869	\N	C	2019-12-20 22:14:28.053842+00	3556
868	2	-868	body of initial Jomon pottery of type SIV	\N	4	1	-868	\N	C	2019-12-20 22:14:28.053842+00	3557
867	2	-867	body of initial Jomon pottery of type SIV	\N	4	1	-867	\N	C	2019-12-20 22:14:28.053842+00	3558
866	2	-866	body of initial Jomon pottery of type SIV	\N	4	1	-866	\N	C	2019-12-20 22:14:28.053842+00	3559
865	2	-865	body of initial Jomon pottery of type SIV	\N	4	1	-865	\N	C	2019-12-20 22:14:28.053842+00	3560
864	2	-864	body of initial Jomon pottery of type SIV	\N	4	1	-864	\N	C	2019-12-20 22:14:28.053842+00	3561
863	2	-863	body of initial Jomon pottery of type SIV	\N	4	1	-863	\N	C	2019-12-20 22:14:28.053842+00	3562
862	2	-862	unknown part of incipient Jomon pottery of type SII	\N	4	1	-862	\N	C	2019-12-20 22:14:28.053842+00	3563
861	2	-861	body of early Jomon pottery of type ZI-ZVI	\N	4	1	-861	\N	C	2019-12-20 22:14:28.053842+00	3564
860	2	-860	body of early Jomon pottery of type ZI-ZVI	\N	4	1	-860	\N	C	2019-12-20 22:14:28.053842+00	3565
859	2	-859	body of early Jomon pottery of type ZV	\N	4	1	-859	\N	C	2019-12-20 22:14:28.053842+00	3566
858	2	-858	body of early Jomon pottery of type ZV	\N	4	1	-858	\N	C	2019-12-20 22:14:28.053842+00	3567
857	2	-857	body of early Jomon pottery of type ZV	\N	4	1	-857	\N	C	2019-12-20 22:14:28.053842+00	3568
856	2	-856	body of early Jomon pottery of type ZV	\N	4	1	-856	\N	C	2019-12-20 22:14:28.053842+00	3569
855	2	-855	body of early Jomon pottery of type ZV	\N	4	1	-855	\N	C	2019-12-20 22:14:28.053842+00	3570
854	2	-854	body of early Jomon pottery of type ZIV	\N	4	1	-854	\N	C	2019-12-20 22:14:28.053842+00	3571
853	2	-853	body of early Jomon pottery of type ZIV	\N	4	1	-853	\N	C	2019-12-20 22:14:28.053842+00	3572
852	2	-852	body of early Jomon pottery of type ZIV	\N	4	1	-852	\N	C	2019-12-20 22:14:28.053842+00	3573
851	2	-851	body of early Jomon pottery of type ZIV	\N	4	1	-851	\N	C	2019-12-20 22:14:28.053842+00	3574
850	2	-850	body of early Jomon pottery of type ZIV	\N	4	1	-850	\N	C	2019-12-20 22:14:28.053842+00	3575
849	2	-849	body of early Jomon pottery of type ZIV	\N	4	1	-849	\N	C	2019-12-20 22:14:28.053842+00	3576
848	2	-848	body of early Jomon pottery of type ZIV	\N	4	1	-848	\N	C	2019-12-20 22:14:28.053842+00	3577
847	2	-847	body of early Jomon pottery of type ZIV	\N	4	1	-847	\N	C	2019-12-20 22:14:28.053842+00	3578
846	2	-846	body of early Jomon pottery of type ZIII	\N	4	1	-846	\N	C	2019-12-20 22:14:28.053842+00	3579
845	2	-845	body of early Jomon pottery of type ZIII	\N	4	1	-845	\N	C	2019-12-20 22:14:28.053842+00	3580
844	2	-844	body of early Jomon pottery of type ZIII	\N	4	1	-844	\N	C	2019-12-20 22:14:28.053842+00	3581
843	2	-843	rim of early Jomon pottery of type ZIII	\N	4	1	-843	\N	C	2019-12-20 22:14:28.053842+00	3582
842	2	-842	body of early Jomon pottery of type ZIII	\N	4	1	-842	\N	C	2019-12-20 22:14:28.053842+00	3583
841	2	-841	body of early Jomon pottery of type ZIII	\N	4	1	-841	\N	C	2019-12-20 22:14:28.053842+00	3584
840	2	-840	body of early Jomon pottery of type ZIII	\N	4	1	-840	\N	C	2019-12-20 22:14:28.053842+00	3585
839	2	-839	body of early Jomon pottery of type ZIII	\N	4	1	-839	\N	C	2019-12-20 22:14:28.053842+00	3586
838	2	-838	body of early Jomon pottery of type ZIII	\N	4	1	-838	\N	C	2019-12-20 22:14:28.053842+00	3587
837	2	-837	body of early Jomon pottery of type ZIII	\N	4	1	-837	\N	C	2019-12-20 22:14:28.053842+00	3588
836	2	-836	body of early Jomon pottery of type ZII	\N	4	1	-836	\N	C	2019-12-20 22:14:28.053842+00	3589
835	2	-835	body of early Jomon pottery of type ZII	\N	4	1	-835	\N	C	2019-12-20 22:14:28.053842+00	3590
834	2	-834	body of early Jomon pottery of type ZII	\N	4	1	-834	\N	C	2019-12-20 22:14:28.053842+00	3591
833	2	-833	body of early Jomon pottery of type ZII	\N	4	1	-833	\N	C	2019-12-20 22:14:28.053842+00	3592
832	2	-832	rim of early Jomon pottery of type ZII	\N	4	1	-832	\N	C	2019-12-20 22:14:28.053842+00	3593
831	2	-831	body of early Jomon pottery of type ZII	\N	4	1	-831	\N	C	2019-12-20 22:14:28.053842+00	3594
830	2	-830	body of early Jomon pottery of type ZII	\N	4	1	-830	\N	C	2019-12-20 22:14:28.053842+00	3595
829	2	-829	body of early Jomon pottery of type ZII	\N	4	1	-829	\N	C	2019-12-20 22:14:28.053842+00	3596
828	2	-828	body of early Jomon pottery of type ZII	\N	4	1	-828	\N	C	2019-12-20 22:14:28.053842+00	3597
827	2	-827	body of early Jomon pottery of type ZII	\N	4	1	-827	\N	C	2019-12-20 22:14:28.053842+00	3598
826	2	-826	rim of early Jomon pottery of type ZII	\N	4	1	-826	\N	C	2019-12-20 22:14:28.053842+00	3599
825	2	-825	rim of early Jomon pottery of type ZII	\N	4	1	-825	\N	C	2019-12-20 22:14:28.053842+00	3600
824	2	-824	body of early Jomon pottery of type ZII	\N	4	1	-824	\N	C	2019-12-20 22:14:28.053842+00	3601
823	2	-823	body of early Jomon pottery of type ZII	\N	4	1	-823	\N	C	2019-12-20 22:14:28.053842+00	3602
822	2	-822	rim of early Jomon pottery of type ZII	\N	4	1	-822	\N	C	2019-12-20 22:14:28.053842+00	3603
821	2	-821	body of early Jomon pottery of type ZII	\N	4	1	-821	\N	C	2019-12-20 22:14:28.053842+00	3604
820	2	-820	body of early Jomon pottery of type ZII	\N	4	1	-820	\N	C	2019-12-20 22:14:28.053842+00	3605
819	2	-819	body of early Jomon pottery of type ZII	\N	4	1	-819	\N	C	2019-12-20 22:14:28.053842+00	3606
818	2	-818	body of early Jomon pottery of type ZII	\N	4	1	-818	\N	C	2019-12-20 22:14:28.053842+00	3607
817	2	-817	rim of early Jomon pottery of type ZII	\N	4	1	-817	\N	C	2019-12-20 22:14:28.053842+00	3608
816	2	-816	body of early Jomon pottery of type ZII	\N	4	1	-816	\N	C	2019-12-20 22:14:28.053842+00	3609
815	2	-815	body of early Jomon pottery of type ZII	\N	4	1	-815	\N	C	2019-12-20 22:14:28.053842+00	3610
814	2	-814	body of early Jomon pottery of type ZII	\N	4	1	-814	\N	C	2019-12-20 22:14:28.053842+00	3611
813	2	-813	body of early Jomon pottery of type ZII	\N	4	1	-813	\N	C	2019-12-20 22:14:28.053842+00	3612
812	2	-812	unknown part of early Jomon pottery of type ZI - ZVI	\N	4	1	-812	\N	C	2019-12-20 22:14:28.053842+00	3613
811	2	-811	unknown part of early Jomon pottery of type ZI - ZVI	\N	4	1	-811	\N	C	2019-12-20 22:14:28.053842+00	3614
810	2	-810	unknown part of early Jomon pottery of type ZI - ZVI	\N	4	1	-810	\N	C	2019-12-20 22:14:28.053842+00	3615
809	2	-809	unknown part of early Jomon pottery of type ZI - ZVI	\N	4	1	-809	\N	C	2019-12-20 22:14:28.053842+00	3616
808	2	-808	unknown part of early Jomon pottery of type ZI - ZVI	\N	4	1	-808	\N	C	2019-12-20 22:14:28.053842+00	3617
807	2	-807	unknown part of early Jomon pottery of type ZI - ZVI	\N	4	1	-807	\N	C	2019-12-20 22:14:28.053842+00	3618
806	2	-806	unknown part of early Jomon pottery of type ZI - ZVI	\N	4	1	-806	\N	C	2019-12-20 22:14:28.053842+00	3619
805	2	-805	unknown part of early Jomon pottery of type ZI - ZVI	\N	4	1	-805	\N	C	2019-12-20 22:14:28.053842+00	3620
804	2	-804	unknown part of early Jomon pottery of type ZI - ZVI	\N	4	1	-804	\N	C	2019-12-20 22:14:28.053842+00	3621
803	2	-803	unknown part of early Jomon pottery of type ZI - ZVI	\N	4	1	-803	\N	C	2019-12-20 22:14:28.053842+00	3622
802	2	-802	unknown part of early Jomon pottery of type ZI - ZVI	\N	4	1	-802	\N	C	2019-12-20 22:14:28.053842+00	3623
801	2	-801	unknown part of early Jomon pottery of type ZI - ZVI	\N	4	1	-801	\N	C	2019-12-20 22:14:28.053842+00	3624
800	2	-800	unknown part of early Jomon pottery of type ZI - ZVI	\N	4	1	-800	\N	C	2019-12-20 22:14:28.053842+00	3625
799	2	-799	unknown part of early Jomon pottery of type ZI - ZVI	\N	4	1	-799	\N	C	2019-12-20 22:14:28.053842+00	3626
798	2	-798	unknown part of early Jomon pottery of type ZI - ZVI	\N	4	1	-798	\N	C	2019-12-20 22:14:28.053842+00	3627
797	2	-797	unknown part of early Jomon pottery of type ZI - ZVI	\N	4	1	-797	\N	C	2019-12-20 22:14:28.053842+00	3628
796	2	-796	unknown part of early Jomon pottery of type ZI - ZVI	\N	4	1	-796	\N	C	2019-12-20 22:14:28.053842+00	3629
795	2	-795	unknown part of early Jomon pottery of type ZI - ZVI	\N	4	1	-795	\N	C	2019-12-20 22:14:28.053842+00	3630
794	2	-794	unknown part of early Jomon pottery of type ZI - ZVI	\N	4	1	-794	\N	C	2019-12-20 22:14:28.053842+00	3631
793	2	-793	unknown part of early Jomon pottery of type ZI - ZVI	\N	4	1	-793	\N	C	2019-12-20 22:14:28.053842+00	3632
792	2	-792	unknown part of early Jomon pottery of type ZI - ZVI	\N	4	1	-792	\N	C	2019-12-20 22:14:28.053842+00	3633
791	2	-791	body of early Jomon pottery of type ZI	\N	4	1	-791	\N	C	2019-12-20 22:14:28.053842+00	3634
790	2	-790	body of early Jomon pottery of type ZI	\N	4	1	-790	\N	C	2019-12-20 22:14:28.053842+00	3635
789	2	-789	body of early Jomon pottery of type ZI	\N	4	1	-789	\N	C	2019-12-20 22:14:28.053842+00	3636
788	2	-788	body of early Jomon pottery of type ZI	\N	4	1	-788	\N	C	2019-12-20 22:14:28.053842+00	3637
787	2	-787	body of early Jomon pottery of type ZI	\N	4	1	-787	\N	C	2019-12-20 22:14:28.053842+00	3638
786	2	-786	body of early Jomon pottery of type ZI	\N	4	1	-786	\N	C	2019-12-20 22:14:28.053842+00	3639
785	2	-785	body of early Jomon pottery of type ZI	\N	4	1	-785	\N	C	2019-12-20 22:14:28.053842+00	3640
784	2	-784	body of early Jomon pottery of type ZI	\N	4	1	-784	\N	C	2019-12-20 22:14:28.053842+00	3641
783	2	-783	body of early Jomon pottery of type ZI	\N	4	1	-783	\N	C	2019-12-20 22:14:28.053842+00	3642
782	2	-782	body of early Jomon pottery of type ZI	\N	4	1	-782	\N	C	2019-12-20 22:14:28.053842+00	3643
781	2	-781	body of initial Jomon pottery of type SIV - SV	\N	4	1	-781	\N	C	2019-12-20 22:14:28.053842+00	3644
780	2	-780	rim of initial Jomon pottery of type SIV - SV	\N	4	1	-780	\N	C	2019-12-20 22:14:28.053842+00	3645
779	2	-779	unknown part of initial Jomon pottery of type SIV	\N	4	1	-779	\N	C	2019-12-20 22:14:28.053842+00	3646
778	2	-778	unknown part of initial Jomon pottery of type SIV	\N	4	1	-778	\N	C	2019-12-20 22:14:28.053842+00	3647
777	2	-777	unknown part of initial Jomon pottery of type SIV	\N	4	1	-777	\N	C	2019-12-20 22:14:28.053842+00	3648
776	2	-776	body of initial Jomon pottery of type SIV	\N	4	1	-776	\N	C	2019-12-20 22:14:28.053842+00	3649
775	2	-775	body of initial Jomon pottery of type SIV	\N	4	1	-775	\N	C	2019-12-20 22:14:28.053842+00	3650
774	2	-774	body of initial Jomon pottery of type SIV	\N	4	1	-774	\N	C	2019-12-20 22:14:28.053842+00	3651
773	2	-773	body of initial Jomon pottery of type SIV	\N	4	1	-773	\N	C	2019-12-20 22:14:28.053842+00	3652
772	2	-772	body of initial Jomon pottery of type SIV	\N	4	1	-772	\N	C	2019-12-20 22:14:28.053842+00	3653
771	2	-771	body of initial Jomon pottery of type SIV	\N	4	1	-771	\N	C	2019-12-20 22:14:28.053842+00	3654
770	2	-770	body of initial Jomon pottery of type SIV	\N	4	1	-770	\N	C	2019-12-20 22:14:28.053842+00	3655
769	2	-769	body of initial Jomon pottery of type SIV	\N	4	1	-769	\N	C	2019-12-20 22:14:28.053842+00	3656
768	2	-768	body of initial Jomon pottery of type SIII - ZI	\N	4	1	-768	\N	C	2019-12-20 22:14:28.053842+00	3657
767	2	-767	rim of initial Jomon pottery of type SIII - ZI	\N	4	1	-767	\N	C	2019-12-20 22:14:28.053842+00	3658
766	2	-766	unknown part of incipient Jomon pottery of type SIII	\N	4	1	-766	\N	C	2019-12-20 22:14:28.053842+00	3659
765	2	-765	unknown part of incipient Jomon pottery of type SIII	\N	4	1	-765	\N	C	2019-12-20 22:14:28.053842+00	3660
764	2	-764	unknown part of incipient Jomon pottery of type SIII	\N	4	1	-764	\N	C	2019-12-20 22:14:28.053842+00	3661
763	2	-763	body of incipient Jomon pottery of type SIII	\N	4	1	-763	\N	C	2019-12-20 22:14:28.053842+00	3662
762	2	-762	body of incipient Jomon pottery of type SIII	\N	4	1	-762	\N	C	2019-12-20 22:14:28.053842+00	3663
761	2	-761	rim of incipient Jomon pottery of type SIII	\N	4	1	-761	\N	C	2019-12-20 22:14:28.053842+00	3664
760	2	-760	rim of incipient Jomon pottery of type SIII	\N	4	1	-760	\N	C	2019-12-20 22:14:28.053842+00	3665
759	2	-759	rim of incipient Jomon pottery of type SIII	\N	4	1	-759	\N	C	2019-12-20 22:14:28.053842+00	3666
758	2	-758	rim of incipient Jomon pottery of type SIII	\N	4	1	-758	\N	C	2019-12-20 22:14:28.053842+00	3667
757	2	-757	rim of incipient Jomon pottery of type SIII	\N	4	1	-757	\N	C	2019-12-20 22:14:28.053842+00	3668
756	2	-756	rim of incipient Jomon pottery of type SIII	\N	4	1	-756	\N	C	2019-12-20 22:14:28.053842+00	3669
755	2	-755	rim of incipient Jomon pottery of type SIII	\N	4	1	-755	\N	C	2019-12-20 22:14:28.053842+00	3670
754	2	-754	rim of incipient Jomon pottery of type SIII	\N	4	1	-754	\N	C	2019-12-20 22:14:28.053842+00	3671
753	2	-753	unknown part of incipient Jomon pottery of type SIII	\N	4	1	-753	\N	C	2019-12-20 22:14:28.053842+00	3672
752	2	-752	rim of incipient Jomon pottery of type SIII	\N	4	1	-752	\N	C	2019-12-20 22:14:28.053842+00	3673
751	2	-751	body of incipient Jomon pottery of type SIII	\N	4	1	-751	\N	C	2019-12-20 22:14:28.053842+00	3674
750	2	-750	body of incipient Jomon pottery of type SIII	\N	4	1	-750	\N	C	2019-12-20 22:14:28.053842+00	3675
749	2	-749	body of incipient Jomon pottery of type SIII	\N	4	1	-749	\N	C	2019-12-20 22:14:28.053842+00	3676
748	2	-748	rim of incipient Jomon pottery of type SIII	\N	4	1	-748	\N	C	2019-12-20 22:14:28.053842+00	3677
747	2	-747	body of incipient Jomon pottery of type SIII	\N	4	1	-747	\N	C	2019-12-20 22:14:28.053842+00	3678
746	2	-746	rim of incipient Jomon pottery of type SIII	\N	4	1	-746	\N	C	2019-12-20 22:14:28.053842+00	3679
745	2	-745	body of incipient Jomon pottery of type SIII	\N	4	1	-745	\N	C	2019-12-20 22:14:28.053842+00	3680
744	2	-744	body of incipient Jomon pottery of type SIII	\N	4	1	-744	\N	C	2019-12-20 22:14:28.053842+00	3681
743	2	-743	body of incipient Jomon pottery of type SIII	\N	4	1	-743	\N	C	2019-12-20 22:14:28.053842+00	3682
742	2	-742	body of incipient Jomon pottery of type SIII	\N	4	1	-742	\N	C	2019-12-20 22:14:28.053842+00	3683
741	2	-741	body of incipient Jomon pottery of type SIII	\N	4	1	-741	\N	C	2019-12-20 22:14:28.053842+00	3684
740	2	-740	body of incipient Jomon pottery of type SIII	\N	4	1	-740	\N	C	2019-12-20 22:14:28.053842+00	3685
739	2	-739	body of incipient Jomon pottery of type SIII	\N	4	1	-739	\N	C	2019-12-20 22:14:28.053842+00	3686
738	2	-738	rim of incipient Jomon pottery of type SIII	\N	4	1	-738	\N	C	2019-12-20 22:14:28.053842+00	3687
737	2	-737	rim of incipient Jomon pottery of type SIII	\N	4	1	-737	\N	C	2019-12-20 22:14:28.053842+00	3688
736	2	-736	body of incipient Jomon pottery of type SIII	\N	4	1	-736	\N	C	2019-12-20 22:14:28.053842+00	3689
735	2	-735	body of incipient Jomon pottery of type SIII	\N	4	1	-735	\N	C	2019-12-20 22:14:28.053842+00	3690
734	2	-734	body of incipient Jomon pottery of type SIII	\N	4	1	-734	\N	C	2019-12-20 22:14:28.053842+00	3691
733	2	-733	rim of incipient Jomon pottery of type SIII	\N	4	1	-733	\N	C	2019-12-20 22:14:28.053842+00	3692
732	2	-732	rim of incipient Jomon pottery of type SIII	\N	4	1	-732	\N	C	2019-12-20 22:14:28.053842+00	3693
731	2	-731	rim of incipient Jomon pottery of type SIII	\N	4	1	-731	\N	C	2019-12-20 22:14:28.053842+00	3694
730	2	-730	body of incipient Jomon pottery of type SIII	\N	4	1	-730	\N	C	2019-12-20 22:14:28.053842+00	3695
729	2	-729	body of incipient Jomon pottery of type SIII	\N	4	1	-729	\N	C	2019-12-20 22:14:28.053842+00	3696
728	2	-728	body of incipient Jomon pottery of type SIII	\N	4	1	-728	\N	C	2019-12-20 22:14:28.053842+00	3697
727	2	-727	body of incipient Jomon pottery of type SIII	\N	4	1	-727	\N	C	2019-12-20 22:14:28.053842+00	3698
726	2	-726	body of incipient Jomon pottery of type SIII	\N	4	1	-726	\N	C	2019-12-20 22:14:28.053842+00	3699
725	2	-725	body of incipient Jomon pottery of type SIII	\N	4	1	-725	\N	C	2019-12-20 22:14:28.053842+00	3700
724	2	-724	body of incipient Jomon pottery of type SIII	\N	4	1	-724	\N	C	2019-12-20 22:14:28.053842+00	3701
723	2	-723	body of incipient Jomon pottery of type SIII	\N	4	1	-723	\N	C	2019-12-20 22:14:28.053842+00	3702
722	2	-722	body of incipient Jomon pottery of type SIII	\N	4	1	-722	\N	C	2019-12-20 22:14:28.053842+00	3703
721	2	-721	body of incipient Jomon pottery of type SIII	\N	4	1	-721	\N	C	2019-12-20 22:14:28.053842+00	3704
720	2	-720	rim of incipient Jomon pottery of type SIII	\N	4	1	-720	\N	C	2019-12-20 22:14:28.053842+00	3705
719	2	-719	body of incipient Jomon pottery of type SIII	\N	4	1	-719	\N	C	2019-12-20 22:14:28.053842+00	3706
718	2	-718	body of incipient Jomon pottery of type SIII	\N	4	1	-718	\N	C	2019-12-20 22:14:28.053842+00	3707
717	2	-717	body of incipient Jomon pottery of type SIII	\N	4	1	-717	\N	C	2019-12-20 22:14:28.053842+00	3708
716	2	-716	body of incipient Jomon pottery of type SIII	\N	4	1	-716	\N	C	2019-12-20 22:14:28.053842+00	3709
715	2	-715	rim of incipient Jomon pottery of type SIII	\N	4	1	-715	\N	C	2019-12-20 22:14:28.053842+00	3710
714	2	-714	rim of incipient Jomon pottery of type SIII	\N	4	1	-714	\N	C	2019-12-20 22:14:28.053842+00	3711
713	2	-713	body of incipient Jomon pottery of type SIII	\N	4	1	-713	\N	C	2019-12-20 22:14:28.053842+00	3712
712	2	-712	body of incipient Jomon pottery of type SIII	\N	4	1	-712	\N	C	2019-12-20 22:14:28.053842+00	3713
711	2	-711	body of incipient Jomon pottery of type SIII	\N	4	1	-711	\N	C	2019-12-20 22:14:28.053842+00	3714
710	2	-710	body of incipient Jomon pottery of type SIII	\N	4	1	-710	\N	C	2019-12-20 22:14:28.053842+00	3715
709	2	-709	rim of incipient Jomon pottery of type SIII	\N	4	1	-709	\N	C	2019-12-20 22:14:28.053842+00	3716
708	2	-708	rim of incipient Jomon pottery of type SIII	\N	4	1	-708	\N	C	2019-12-20 22:14:28.053842+00	3717
707	2	-707	rim of incipient Jomon pottery of type SIII	\N	4	1	-707	\N	C	2019-12-20 22:14:28.053842+00	3718
706	2	-706	body of incipient Jomon pottery of type SIII	\N	4	1	-706	\N	C	2019-12-20 22:14:28.053842+00	3719
705	2	-705	rim of incipient Jomon pottery of type SIII	\N	4	1	-705	\N	C	2019-12-20 22:14:28.053842+00	3720
704	2	-704	rim of incipient Jomon pottery of type SIII	\N	4	1	-704	\N	C	2019-12-20 22:14:28.053842+00	3721
703	2	-703	body of incipient Jomon pottery of type SII	\N	4	1	-703	\N	C	2019-12-20 22:14:28.053842+00	3722
702	2	-702	body of incipient Jomon pottery of type SII	\N	4	1	-702	\N	C	2019-12-20 22:14:28.053842+00	3723
701	2	-701	body of incipient Jomon pottery of type SI	\N	4	1	-701	\N	C	2019-12-20 22:14:28.053842+00	3724
700	2	-700	body of incipient Jomon pottery of type SI	\N	4	1	-700	\N	C	2019-12-20 22:14:28.053842+00	3725
699	2	-699	unknown part of incipient Jomon pottery of type SII	\N	4	1	-699	\N	C	2019-12-20 22:14:28.053842+00	3726
698	2	-698	unknown part of incipient Jomon pottery of type SII	\N	4	1	-698	\N	C	2019-12-20 22:14:28.053842+00	3727
697	2	-697	unknown part of incipient Jomon pottery of type SII	\N	4	1	-697	\N	C	2019-12-20 22:14:28.053842+00	3728
696	2	-696	unknown part of incipient Jomon pottery of type SII	\N	4	1	-696	\N	C	2019-12-20 22:14:28.053842+00	3729
695	2	-695	unknown part of incipient Jomon pottery of type SII	\N	4	1	-695	\N	C	2019-12-20 22:14:28.053842+00	3730
694	2	-694	unknown part of incipient Jomon pottery of type SII	\N	4	1	-694	\N	C	2019-12-20 22:14:28.053842+00	3731
693	2	-693	unknown part of incipient Jomon pottery of type SII	\N	4	1	-693	\N	C	2019-12-20 22:14:28.053842+00	3732
692	2	-692	unknown part of incipient Jomon pottery of type SII	\N	4	1	-692	\N	C	2019-12-20 22:14:28.053842+00	3733
691	2	-691	unknown part of incipient Jomon pottery of type SII	\N	4	1	-691	\N	C	2019-12-20 22:14:28.053842+00	3734
690	2	-690	unknown part of incipient Jomon pottery of type SII	\N	4	1	-690	\N	C	2019-12-20 22:14:28.053842+00	3735
689	2	-689	unknown part of incipient Jomon pottery of type SII	\N	4	1	-689	\N	C	2019-12-20 22:14:28.053842+00	3736
688	2	-688	unknown part of incipient Jomon pottery of type SII	\N	4	1	-688	\N	C	2019-12-20 22:14:28.053842+00	3737
687	2	-687	unknown part of incipient Jomon pottery of type SII	\N	4	1	-687	\N	C	2019-12-20 22:14:28.053842+00	3738
686	2	-686	unknown part of incipient Jomon pottery of type SII	\N	4	1	-686	\N	C	2019-12-20 22:14:28.053842+00	3739
685	2	-685	unknown part of incipient Jomon pottery of type SII	\N	4	1	-685	\N	C	2019-12-20 22:14:28.053842+00	3740
684	2	-684	unknown part of incipient Jomon pottery of type SII	\N	4	1	-684	\N	C	2019-12-20 22:14:28.053842+00	3741
683	2	-683	unknown part of incipient Jomon pottery of type SII	\N	4	1	-683	\N	C	2019-12-20 22:14:28.053842+00	3742
682	2	-682	unknown part of incipient Jomon pottery of type SII	\N	4	1	-682	\N	C	2019-12-20 22:14:28.053842+00	3743
681	2	-681	unknown part of incipient Jomon pottery of type SII	\N	4	1	-681	\N	C	2019-12-20 22:14:28.053842+00	3744
680	2	-680	unknown part of incipient Jomon pottery of type SII	\N	4	1	-680	\N	C	2019-12-20 22:14:28.053842+00	3745
679	2	-679	unknown part of incipient Jomon pottery of type SII	\N	4	1	-679	\N	C	2019-12-20 22:14:28.053842+00	3746
678	2	-678	unknown part of incipient Jomon pottery of type SII	\N	4	1	-678	\N	C	2019-12-20 22:14:28.053842+00	3747
677	2	-677	unknown part of incipient Jomon pottery of type SII	\N	4	1	-677	\N	C	2019-12-20 22:14:28.053842+00	3748
676	2	-676	body of initial Jomon pottery of type SIV	\N	4	1	-676	\N	C	2019-12-20 22:14:28.053842+00	3749
675	2	-675	body of initial Jomon pottery of type SIV	\N	4	1	-675	\N	C	2019-12-20 22:14:28.053842+00	3750
674	2	-674	body of initial Jomon pottery of type SIV	\N	4	1	-674	\N	C	2019-12-20 22:14:28.053842+00	3751
673	2	-673	body of initial Jomon pottery of type SIV	\N	4	1	-673	\N	C	2019-12-20 22:14:28.053842+00	3752
672	2	-672	body of initial Jomon pottery of type SIV	\N	4	1	-672	\N	C	2019-12-20 22:14:28.053842+00	3753
671	2	-671	body of initial Jomon pottery of type SIV	\N	4	1	-671	\N	C	2019-12-20 22:14:28.053842+00	3754
670	2	-670	body of initial Jomon pottery of type SIV	\N	4	1	-670	\N	C	2019-12-20 22:14:28.053842+00	3755
669	2	-669	body of initial Jomon pottery of type SIV	\N	4	1	-669	\N	C	2019-12-20 22:14:28.053842+00	3756
668	2	-668	base of initial Jomon pottery of type SIV	\N	4	1	-668	\N	C	2019-12-20 22:14:28.053842+00	3757
667	2	-667	body of initial Jomon pottery of type SIV	\N	4	1	-667	\N	C	2019-12-20 22:14:28.053842+00	3758
666	2	-666	rim of initial Jomon pottery of type SIV	\N	4	1	-666	\N	C	2019-12-20 22:14:28.053842+00	3759
665	2	-665	body of initial Jomon pottery of type SIV	\N	4	1	-665	\N	C	2019-12-20 22:14:28.053842+00	3760
664	2	-664	body of initial Jomon pottery of type SIV	\N	4	1	-664	\N	C	2019-12-20 22:14:28.053842+00	3761
663	2	-663	body of initial Jomon pottery of type SIV	\N	4	1	-663	\N	C	2019-12-20 22:14:28.053842+00	3762
662	2	-662	rim of initial Jomon pottery of type SIV	\N	4	1	-662	\N	C	2019-12-20 22:14:28.053842+00	3763
661	2	-661	body of initial Jomon pottery of type SIV	\N	4	1	-661	\N	C	2019-12-20 22:14:28.053842+00	3764
660	2	-660	body of initial Jomon pottery of type SIV	\N	4	1	-660	\N	C	2019-12-20 22:14:28.053842+00	3765
659	2	-659	body of initial Jomon pottery of type SIV	\N	4	1	-659	\N	C	2019-12-20 22:14:28.053842+00	3766
658	2	-658	rim of initial Jomon pottery of type SIV	\N	4	1	-658	\N	C	2019-12-20 22:14:28.053842+00	3767
657	2	-657	body of initial Jomon pottery of type SIV	\N	4	1	-657	\N	C	2019-12-20 22:14:28.053842+00	3768
656	2	-656	rim of initial Jomon pottery of type SIV	\N	4	1	-656	\N	C	2019-12-20 22:14:28.053842+00	3769
655	2	-655	body of initial Jomon pottery of type SIV	\N	4	1	-655	\N	C	2019-12-20 22:14:28.053842+00	3770
654	2	-654	body of initial Jomon pottery of type SIV	\N	4	1	-654	\N	C	2019-12-20 22:14:28.053842+00	3771
653	2	-653	body of initial Jomon pottery of type SIV	\N	4	1	-653	\N	C	2019-12-20 22:14:28.053842+00	3772
652	2	-652	body of initial Jomon pottery of type SIV	\N	4	1	-652	\N	C	2019-12-20 22:14:28.053842+00	3773
651	2	-651	body of initial Jomon pottery of type SIV	\N	4	1	-651	\N	C	2019-12-20 22:14:28.053842+00	3774
650	2	-650	body of initial Jomon pottery of type SIV	\N	4	1	-650	\N	C	2019-12-20 22:14:28.053842+00	3775
649	2	-649	body of initial Jomon pottery of type SIV	\N	4	1	-649	\N	C	2019-12-20 22:14:28.053842+00	3776
648	2	-648	body of initial Jomon pottery of type SIV	\N	4	1	-648	\N	C	2019-12-20 22:14:28.053842+00	3777
647	2	-647	body of initial Jomon pottery of type SIV	\N	4	1	-647	\N	C	2019-12-20 22:14:28.053842+00	3778
646	2	-646	rim of initial Jomon pottery of type SIV	\N	4	1	-646	\N	C	2019-12-20 22:14:28.053842+00	3779
645	2	-645	rim of initial Jomon pottery of type SIV	\N	4	1	-645	\N	C	2019-12-20 22:14:28.053842+00	3780
644	2	-644	rim of initial Jomon pottery of type SIV	\N	4	1	-644	\N	C	2019-12-20 22:14:28.053842+00	3781
643	2	-643	body of initial Jomon pottery of type SIV	\N	4	1	-643	\N	C	2019-12-20 22:14:28.053842+00	3782
642	2	-642	body of initial Jomon pottery of type SIV	\N	4	1	-642	\N	C	2019-12-20 22:14:28.053842+00	3783
641	2	-641	body of initial Jomon pottery of type SIV	\N	4	1	-641	\N	C	2019-12-20 22:14:28.053842+00	3784
640	2	-640	body of initial Jomon pottery of type SIV	\N	4	1	-640	\N	C	2019-12-20 22:14:28.053842+00	3785
639	2	-639	body of initial Jomon pottery of type SIV	\N	4	1	-639	\N	C	2019-12-20 22:14:28.053842+00	3786
638	2	-638	body of initial Jomon pottery of type SIV	\N	4	1	-638	\N	C	2019-12-20 22:14:28.053842+00	3787
637	2	-637	body of initial Jomon pottery of type SIV	\N	4	1	-637	\N	C	2019-12-20 22:14:28.053842+00	3788
636	2	-636	body of initial Jomon pottery of type SIV	\N	4	1	-636	\N	C	2019-12-20 22:14:28.053842+00	3789
635	2	-635	body of initial Jomon pottery of type SIV	\N	4	1	-635	\N	C	2019-12-20 22:14:28.053842+00	3790
634	2	-634	body of initial Jomon pottery of type SIV	\N	4	1	-634	\N	C	2019-12-20 22:14:28.053842+00	3791
633	2	-633	body of initial Jomon pottery of type SIV	\N	4	1	-633	\N	C	2019-12-20 22:14:28.053842+00	3792
632	2	-632	body of initial Jomon pottery of type SIV	\N	4	1	-632	\N	C	2019-12-20 22:14:28.053842+00	3793
631	2	-631	body of initial Jomon pottery of type SIV	\N	4	1	-631	\N	C	2019-12-20 22:14:28.053842+00	3794
630	2	-630	body of initial Jomon pottery of type SIV	\N	4	1	-630	\N	C	2019-12-20 22:14:28.053842+00	3795
629	2	-629	body of initial Jomon pottery of type SIV	\N	4	1	-629	\N	C	2019-12-20 22:14:28.053842+00	3796
628	2	-628	base of initial Jomon pottery of type SIV	\N	4	1	-628	\N	C	2019-12-20 22:14:28.053842+00	3797
627	2	-627	body of initial Jomon pottery of type SIV	\N	4	1	-627	\N	C	2019-12-20 22:14:28.053842+00	3798
626	2	-626	rim of initial Jomon pottery of type SIV	\N	4	1	-626	\N	C	2019-12-20 22:14:28.053842+00	3799
625	2	-625	body of initial Jomon pottery of type SIV	\N	4	1	-625	\N	C	2019-12-20 22:14:28.053842+00	3800
624	2	-624	body of initial Jomon pottery of type SIV	\N	4	1	-624	\N	C	2019-12-20 22:14:28.053842+00	3801
623	2	-623	body of initial Jomon pottery of type SIV	\N	4	1	-623	\N	C	2019-12-20 22:14:28.053842+00	3802
622	2	-622	rim of initial Jomon pottery of type SIV	\N	4	1	-622	\N	C	2019-12-20 22:14:28.053842+00	3803
621	2	-621	base of initial Jomon pottery of type SIV	\N	4	1	-621	\N	C	2019-12-20 22:14:28.053842+00	3804
620	2	-620	rim-upper body of initial Jomon pottery of type SIV	\N	4	1	-620	\N	C	2019-12-20 22:14:28.053842+00	3805
619	2	-619	rim-upper body of initial Jomon pottery of type SIV	\N	4	1	-619	\N	C	2019-12-20 22:14:28.053842+00	3806
618	2	-618	body of initial Jomon pottery of type SIV	\N	4	1	-618	\N	C	2019-12-20 22:14:28.053842+00	3807
617	2	-617	rim of initial Jomon pottery of type SIV	\N	4	1	-617	\N	C	2019-12-20 22:14:28.053842+00	3808
616	2	-616	rim-upper body of initial Jomon pottery of type SIV	\N	4	1	-616	\N	C	2019-12-20 22:14:28.053842+00	3809
615	2	-615	rim-upper body of initial Jomon pottery of type SIV	\N	4	1	-615	\N	C	2019-12-20 22:14:28.053842+00	3810
614	2	-614	body of initial Jomon pottery of type SIV	\N	4	1	-614	\N	C	2019-12-20 22:14:28.053842+00	3811
613	2	-613	body of initial Jomon pottery of type SIV	\N	4	1	-613	\N	C	2019-12-20 22:14:28.053842+00	3812
612	2	-612	body of initial Jomon pottery of type SIV	\N	4	1	-612	\N	C	2019-12-20 22:14:28.053842+00	3813
611	2	-611	body of initial Jomon pottery of type SIV	\N	4	1	-611	\N	C	2019-12-20 22:14:28.053842+00	3814
610	2	-610	body of initial Jomon pottery of type SIV	\N	4	1	-610	\N	C	2019-12-20 22:14:28.053842+00	3815
609	2	-609	body of initial Jomon pottery of type SIV	\N	4	1	-609	\N	C	2019-12-20 22:14:28.053842+00	3816
608	2	-608	body of initial Jomon pottery of type SIV	\N	4	1	-608	\N	C	2019-12-20 22:14:28.053842+00	3817
607	2	-607	body of initial Jomon pottery of type SIV	\N	4	1	-607	\N	C	2019-12-20 22:14:28.053842+00	3818
606	2	-606	body of initial Jomon pottery of type SIV	\N	4	1	-606	\N	C	2019-12-20 22:14:28.053842+00	3819
605	2	-605	rim of initial Jomon pottery of type SIV	\N	4	1	-605	\N	C	2019-12-20 22:14:28.053842+00	3820
604	2	-604	body of initial Jomon pottery of type SIV	\N	4	1	-604	\N	C	2019-12-20 22:14:28.053842+00	3821
603	2	-603	body of initial Jomon pottery of type SIV	\N	4	1	-603	\N	C	2019-12-20 22:14:28.053842+00	3822
602	2	-602	base of initial Jomon pottery of type SIV	\N	4	1	-602	\N	C	2019-12-20 22:14:28.053842+00	3823
601	2	-601	body of initial Jomon pottery of type SIV	\N	4	1	-601	\N	C	2019-12-20 22:14:28.053842+00	3824
600	2	-600	body of initial Jomon pottery of type SIV	\N	4	1	-600	\N	C	2019-12-20 22:14:28.053842+00	3825
599	2	-599	rim of initial Jomon pottery of type SIV	\N	4	1	-599	\N	C	2019-12-20 22:14:28.053842+00	3826
598	2	-598	body of initial Jomon pottery of type SIV	\N	4	1	-598	\N	C	2019-12-20 22:14:28.053842+00	3827
597	2	-597	body of initial Jomon pottery of type SIV	\N	4	1	-597	\N	C	2019-12-20 22:14:28.053842+00	3828
596	2	-596	body of initial Jomon pottery of type SIV	\N	4	1	-596	\N	C	2019-12-20 22:14:28.053842+00	3829
595	2	-595	body of initial Jomon pottery of type SIV	\N	4	1	-595	\N	C	2019-12-20 22:14:28.053842+00	3830
594	2	-594	rim of initial Jomon pottery of type SIV	\N	4	1	-594	\N	C	2019-12-20 22:14:28.053842+00	3831
593	2	-593	body of initial Jomon pottery of type SIV	\N	4	1	-593	\N	C	2019-12-20 22:14:28.053842+00	3832
592	2	-592	body of initial Jomon pottery of type SIV	\N	4	1	-592	\N	C	2019-12-20 22:14:28.053842+00	3833
591	2	-591	rim of initial Jomon pottery of type SIV	\N	4	1	-591	\N	C	2019-12-20 22:14:28.053842+00	3834
590	2	-590	rim of initial Jomon pottery of type SIV	\N	4	1	-590	\N	C	2019-12-20 22:14:28.053842+00	3835
589	2	-589	rim of initial Jomon pottery of type SIV	\N	4	1	-589	\N	C	2019-12-20 22:14:28.053842+00	3836
588	2	-588	body of initial Jomon pottery of type SIV	\N	4	1	-588	\N	C	2019-12-20 22:14:28.053842+00	3837
587	2	-587	body of initial Jomon pottery of type SIV	\N	4	1	-587	\N	C	2019-12-20 22:14:28.053842+00	3838
586	2	-586	rim-upper body of initial Jomon pottery of type SIV	\N	4	1	-586	\N	C	2019-12-20 22:14:28.053842+00	3839
585	2	-585	rim-upper body of initial Jomon pottery of type SIV	\N	4	1	-585	\N	C	2019-12-20 22:14:28.053842+00	3840
584	2	-584	rim-upper body of initial Jomon pottery of type SIV	\N	4	1	-584	\N	C	2019-12-20 22:14:28.053842+00	3841
583	2	-583	upper body of initial Jomon pottery of type SIV	\N	4	1	-583	\N	C	2019-12-20 22:14:28.053842+00	3842
582	2	-582	rim-upper body of initial Jomon pottery of type SIV	\N	4	1	-582	\N	C	2019-12-20 22:14:28.053842+00	3843
581	2	-581	body of initial Jomon pottery of type SIV	\N	4	1	-581	\N	C	2019-12-20 22:14:28.053842+00	3844
580	2	-580	rim-upper body of initial Jomon pottery of type SIV	\N	4	1	-580	\N	C	2019-12-20 22:14:28.053842+00	3845
579	2	-579	upper body of initial Jomon pottery of type SIV	\N	4	1	-579	\N	C	2019-12-20 22:14:28.053842+00	3846
578	2	-578	upper body of initial Jomon pottery of type SIV	\N	4	1	-578	\N	C	2019-12-20 22:14:28.053842+00	3847
577	2	-577	body of initial Jomon pottery of type SIV	\N	4	1	-577	\N	C	2019-12-20 22:14:28.053842+00	3848
576	2	-576	body of initial Jomon pottery of type SIV	\N	4	1	-576	\N	C	2019-12-20 22:14:28.053842+00	3849
575	2	-575	upper body of initial Jomon pottery of type SIV	\N	4	1	-575	\N	C	2019-12-20 22:14:28.053842+00	3850
574	2	-574	upper body of initial Jomon pottery of type SIV	\N	4	1	-574	\N	C	2019-12-20 22:14:28.053842+00	3851
573	2	-573	rim-upper body of initial Jomon pottery of type SIV	\N	4	1	-573	\N	C	2019-12-20 22:14:28.053842+00	3852
572	2	-572	body of initial Jomon pottery of type SIV	\N	4	1	-572	\N	C	2019-12-20 22:14:28.053842+00	3853
571	2	-571	body of initial Jomon pottery of type SIV	\N	4	1	-571	\N	C	2019-12-20 22:14:28.053842+00	3854
570	2	-570	body of initial Jomon pottery of type SIV	\N	4	1	-570	\N	C	2019-12-20 22:14:28.053842+00	3855
569	2	-569	upper body of initial Jomon pottery of type SIV	\N	4	1	-569	\N	C	2019-12-20 22:14:28.053842+00	3856
568	2	-568	body of initial Jomon pottery of type SIV	\N	4	1	-568	\N	C	2019-12-20 22:14:28.053842+00	3857
567	2	-567	body of initial Jomon pottery of type SIV	\N	4	1	-567	\N	C	2019-12-20 22:14:28.053842+00	3858
566	2	-566	body of initial Jomon pottery of type SIV	\N	4	1	-566	\N	C	2019-12-20 22:14:28.053842+00	3859
565	2	-565	body of initial Jomon pottery of type SIV	\N	4	1	-565	\N	C	2019-12-20 22:14:28.053842+00	3860
564	2	-564	rim-upper body of initial Jomon pottery of type SIV	\N	4	1	-564	\N	C	2019-12-20 22:14:28.053842+00	3861
563	2	-563	body of initial Jomon pottery of type SIV	\N	4	1	-563	\N	C	2019-12-20 22:14:28.053842+00	3862
562	2	-562	body of initial Jomon pottery of type SIV	\N	4	1	-562	\N	C	2019-12-20 22:14:28.053842+00	3863
561	2	-561	body of initial Jomon pottery of type SIV	\N	4	1	-561	\N	C	2019-12-20 22:14:28.053842+00	3864
560	2	-560	body of initial Jomon pottery of type SIV	\N	4	1	-560	\N	C	2019-12-20 22:14:28.053842+00	3865
559	2	-559	body of initial Jomon pottery of type SIV	\N	4	1	-559	\N	C	2019-12-20 22:14:28.053842+00	3866
558	2	-558	rim of initial Jomon pottery of type SIV	\N	4	1	-558	\N	C	2019-12-20 22:14:28.053842+00	3867
557	2	-557	rim of initial Jomon pottery of type SIV	\N	4	1	-557	\N	C	2019-12-20 22:14:28.053842+00	3868
556	2	-556	body of initial Jomon pottery of type SIV	\N	4	1	-556	\N	C	2019-12-20 22:14:28.053842+00	3869
555	2	-555	rim of initial Jomon pottery of type SIV	\N	4	1	-555	\N	C	2019-12-20 22:14:28.053842+00	3870
554	2	-554	body of initial Jomon pottery of type SIV	\N	4	1	-554	\N	C	2019-12-20 22:14:28.053842+00	3871
553	2	-553	body of initial Jomon pottery of type SIV	\N	4	1	-553	\N	C	2019-12-20 22:14:28.053842+00	3872
552	2	-552	body of initial Jomon pottery of type SIV	\N	4	1	-552	\N	C	2019-12-20 22:14:28.053842+00	3873
551	2	-551	body of initial Jomon pottery of type SIV	\N	4	1	-551	\N	C	2019-12-20 22:14:28.053842+00	3874
550	2	-550	body of initial Jomon pottery of type SIV	\N	4	1	-550	\N	C	2019-12-20 22:14:28.053842+00	3875
549	2	-549	body of initial Jomon pottery of type SIV	\N	4	1	-549	\N	C	2019-12-20 22:14:28.053842+00	3876
548	2	-548	body of initial Jomon pottery of type SIV	\N	4	1	-548	\N	C	2019-12-20 22:14:28.053842+00	3877
547	2	-547	body of initial Jomon pottery of type SIV	\N	4	1	-547	\N	C	2019-12-20 22:14:28.053842+00	3878
546	2	-546	body of initial Jomon pottery of type SIV	\N	4	1	-546	\N	C	2019-12-20 22:14:28.053842+00	3879
545	2	-545	body of initial Jomon pottery of type SIV	\N	4	1	-545	\N	C	2019-12-20 22:14:28.053842+00	3880
544	2	-544	body of initial Jomon pottery of type SIV	\N	4	1	-544	\N	C	2019-12-20 22:14:28.053842+00	3881
543	2	-543	body of initial Jomon pottery of type SIV	\N	4	1	-543	\N	C	2019-12-20 22:14:28.053842+00	3882
542	2	-542	body of initial Jomon pottery of type SIV	\N	4	1	-542	\N	C	2019-12-20 22:14:28.053842+00	3883
541	2	-541	body of initial Jomon pottery of type SIV	\N	4	1	-541	\N	C	2019-12-20 22:14:28.053842+00	3884
540	2	-540	body of initial Jomon pottery of type SIV	\N	4	1	-540	\N	C	2019-12-20 22:14:28.053842+00	3885
539	2	-539	body of initial Jomon pottery of type SIV	\N	4	1	-539	\N	C	2019-12-20 22:14:28.053842+00	3886
538	2	-538	body of initial Jomon pottery of type SIV	\N	4	1	-538	\N	C	2019-12-20 22:14:28.053842+00	3887
537	2	-537	body of initial Jomon pottery of type SIV	\N	4	1	-537	\N	C	2019-12-20 22:14:28.053842+00	3888
536	2	-536	body of initial Jomon pottery of type SIV	\N	4	1	-536	\N	C	2019-12-20 22:14:28.053842+00	3889
535	2	-535	body of initial Jomon pottery of type SIV	\N	4	1	-535	\N	C	2019-12-20 22:14:28.053842+00	3890
534	2	-534	body of initial Jomon pottery of type SIV	\N	4	1	-534	\N	C	2019-12-20 22:14:28.053842+00	3891
533	2	-533	rim of initial Jomon pottery of type SIV	\N	4	1	-533	\N	C	2019-12-20 22:14:28.053842+00	3892
532	2	-532	body of initial Jomon pottery of type SIV	\N	4	1	-532	\N	C	2019-12-20 22:14:28.053842+00	3893
531	2	-531	rim of initial Jomon pottery of type SIV	\N	4	1	-531	\N	C	2019-12-20 22:14:28.053842+00	3894
530	2	-530	body of initial Jomon pottery of type SIV	\N	4	1	-530	\N	C	2019-12-20 22:14:28.053842+00	3895
529	2	-529	body of initial Jomon pottery of type SIV	\N	4	1	-529	\N	C	2019-12-20 22:14:28.053842+00	3896
528	2	-528	rim of initial Jomon pottery of type SIV	\N	4	1	-528	\N	C	2019-12-20 22:14:28.053842+00	3897
527	2	-527	body of initial Jomon pottery of type SIV	\N	4	1	-527	\N	C	2019-12-20 22:14:28.053842+00	3898
526	2	-526	body of initial Jomon pottery of type SIV	\N	4	1	-526	\N	C	2019-12-20 22:14:28.053842+00	3899
525	2	-525	body of initial Jomon pottery of type SIV	\N	4	1	-525	\N	C	2019-12-20 22:14:28.053842+00	3900
524	2	-524	body of initial Jomon pottery of type SIV	\N	4	1	-524	\N	C	2019-12-20 22:14:28.053842+00	3901
523	2	-523	body of initial Jomon pottery of type SIV	\N	4	1	-523	\N	C	2019-12-20 22:14:28.053842+00	3902
522	2	-522	rim of initial Jomon pottery of type SIV	\N	4	1	-522	\N	C	2019-12-20 22:14:28.053842+00	3903
521	2	-521	body of initial Jomon pottery of type SIV	\N	4	1	-521	\N	C	2019-12-20 22:14:28.053842+00	3904
520	2	-520	body of initial Jomon pottery of type SIV	\N	4	1	-520	\N	C	2019-12-20 22:14:28.053842+00	3905
519	2	-519	body of initial Jomon pottery of type SIV	\N	4	1	-519	\N	C	2019-12-20 22:14:28.053842+00	3906
518	2	-518	body of initial Jomon pottery of type SIV	\N	4	1	-518	\N	C	2019-12-20 22:14:28.053842+00	3907
517	2	-517	rim of initial Jomon pottery of type SIV	\N	4	1	-517	\N	C	2019-12-20 22:14:28.053842+00	3908
516	2	-516	rim of initial Jomon pottery of type SIV	\N	4	1	-516	\N	C	2019-12-20 22:14:28.053842+00	3909
515	2	-515	body of initial Jomon pottery of type SIV	\N	4	1	-515	\N	C	2019-12-20 22:14:28.053842+00	3910
514	2	-514	rim of initial Jomon pottery of type SIV	\N	4	1	-514	\N	C	2019-12-20 22:14:28.053842+00	3911
513	2	-513	body of initial Jomon pottery of type SIV	\N	4	1	-513	\N	C	2019-12-20 22:14:28.053842+00	3912
512	2	-512	body of initial Jomon pottery of type SIV	\N	4	1	-512	\N	C	2019-12-20 22:14:28.053842+00	3913
511	2	-511	body of initial Jomon pottery of type SIV	\N	4	1	-511	\N	C	2019-12-20 22:14:28.053842+00	3914
510	2	-510	body of initial Jomon pottery of type SIV	\N	4	1	-510	\N	C	2019-12-20 22:14:28.053842+00	3915
509	2	-509	body of initial Jomon pottery of type SIV	\N	4	1	-509	\N	C	2019-12-20 22:14:28.053842+00	3916
508	2	-508	body of initial Jomon pottery of type SIV	\N	4	1	-508	\N	C	2019-12-20 22:14:28.053842+00	3917
507	2	-507	body of initial Jomon pottery of type SIV	\N	4	1	-507	\N	C	2019-12-20 22:14:28.053842+00	3918
506	2	-506	body of initial Jomon pottery of type SIV	\N	4	1	-506	\N	C	2019-12-20 22:14:28.053842+00	3919
505	2	-505	body of initial Jomon pottery of type SIV	\N	4	1	-505	\N	C	2019-12-20 22:14:28.053842+00	3920
504	2	-504	body of initial Jomon pottery of type SIV	\N	4	1	-504	\N	C	2019-12-20 22:14:28.053842+00	3921
503	2	-503	body of initial Jomon pottery of type SIV	\N	4	1	-503	\N	C	2019-12-20 22:14:28.053842+00	3922
502	2	-502	body of initial Jomon pottery of type SIV	\N	4	1	-502	\N	C	2019-12-20 22:14:28.053842+00	3923
501	2	-501	body of initial Jomon pottery of type SIV	\N	4	1	-501	\N	C	2019-12-20 22:14:28.053842+00	3924
500	2	-500	body of initial Jomon pottery of type SIV	\N	4	1	-500	\N	C	2019-12-20 22:14:28.053842+00	3925
499	2	-499	body of initial Jomon pottery of type SIV	\N	4	1	-499	\N	C	2019-12-20 22:14:28.053842+00	3926
498	2	-498	body of initial Jomon pottery of type SIV	\N	4	1	-498	\N	C	2019-12-20 22:14:28.053842+00	3927
497	2	-497	body of initial Jomon pottery of type SIV	\N	4	1	-497	\N	C	2019-12-20 22:14:28.053842+00	3928
496	2	-496	body of initial Jomon pottery of type SIV	\N	4	1	-496	\N	C	2019-12-20 22:14:28.053842+00	3929
495	2	-495	body of initial Jomon pottery of type SIV	\N	4	1	-495	\N	C	2019-12-20 22:14:28.053842+00	3930
494	2	-494	body of initial Jomon pottery of type SIV	\N	4	1	-494	\N	C	2019-12-20 22:14:28.053842+00	3931
493	2	-493	body of initial Jomon pottery of type SIV	\N	4	1	-493	\N	C	2019-12-20 22:14:28.053842+00	3932
492	2	-492	unknown part of incipient Jomon pottery of type SIII	\N	4	1	-492	\N	C	2019-12-20 22:14:28.053842+00	3933
491	2	-491	unknown part of incipient Jomon pottery of type SIII	\N	4	1	-491	\N	C	2019-12-20 22:14:28.053842+00	3934
490	2	-490	unknown part of incipient Jomon pottery of type SIII	\N	4	1	-490	\N	C	2019-12-20 22:14:28.053842+00	3935
489	2	-489	rim of incipient Jomon pottery of type SIII	\N	4	1	-489	\N	C	2019-12-20 22:14:28.053842+00	3936
488	2	-488	unknown part of incipient Jomon pottery of type SIII	\N	4	1	-488	\N	C	2019-12-20 22:14:28.053842+00	3937
487	2	-487	unknown part of incipient Jomon pottery of type SIII	\N	4	1	-487	\N	C	2019-12-20 22:14:28.053842+00	3938
486	2	-486	unknown part of incipient Jomon pottery of type SII	\N	4	1	-486	\N	C	2019-12-20 22:14:28.053842+00	3939
485	2	-485	unknown part of incipient Jomon pottery of type SII	\N	4	1	-485	\N	C	2019-12-20 22:14:28.053842+00	3940
484	2	-484	unknown part of incipient Jomon pottery of type SII	\N	4	1	-484	\N	C	2019-12-20 22:14:28.053842+00	3941
483	2	-483	unknown part of incipient Jomon pottery of type SII	\N	4	1	-483	\N	C	2019-12-20 22:14:28.053842+00	3942
482	2	-482	unknown part of incipient Jomon pottery of type SII	\N	4	1	-482	\N	C	2019-12-20 22:14:28.053842+00	3943
481	2	-481	unknown part of incipient Jomon pottery of type SII	\N	4	1	-481	\N	C	2019-12-20 22:14:28.053842+00	3944
480	2	-480	unknown part of incipient Jomon pottery of type SII	\N	4	1	-480	\N	C	2019-12-20 22:14:28.053842+00	3945
479	2	-479	unknown part of incipient Jomon pottery of type SII	\N	4	1	-479	\N	C	2019-12-20 22:14:28.053842+00	3946
478	2	-478	unknown part of incipient Jomon pottery of type SII	\N	4	1	-478	\N	C	2019-12-20 22:14:28.053842+00	3947
477	2	-477	unknown part of incipient Jomon pottery of type SII	\N	4	1	-477	\N	C	2019-12-20 22:14:28.053842+00	3948
476	2	-476	unknown part of incipient Jomon pottery of type SIII	\N	4	1	-476	\N	C	2019-12-20 22:14:28.053842+00	3949
475	2	-475	unknown part of incipient Jomon pottery of type SIII	\N	4	1	-475	\N	C	2019-12-20 22:14:28.053842+00	3950
474	2	-474	unknown part of incipient Jomon pottery of type SIII	\N	4	1	-474	\N	C	2019-12-20 22:14:28.053842+00	3951
473	2	-473	unknown part of incipient Jomon pottery of type SIII	\N	4	1	-473	\N	C	2019-12-20 22:14:28.053842+00	3952
472	2	-472	unknown part of incipient Jomon pottery of type SIII	\N	4	1	-472	\N	C	2019-12-20 22:14:28.053842+00	3953
471	2	-471	unknown part of incipient Jomon pottery of type SIII	\N	4	1	-471	\N	C	2019-12-20 22:14:28.053842+00	3954
470	2	-470	unknown part of incipient Jomon pottery of type SIII	\N	4	1	-470	\N	C	2019-12-20 22:14:28.053842+00	3955
469	2	-469	unknown part of incipient Jomon pottery of type SIII	\N	4	1	-469	\N	C	2019-12-20 22:14:28.053842+00	3956
468	2	-468	unknown part of incipient Jomon pottery of type SIII	\N	4	1	-468	\N	C	2019-12-20 22:14:28.053842+00	3957
467	2	-467	unknown part of incipient Jomon pottery of type SIII	\N	4	1	-467	\N	C	2019-12-20 22:14:28.053842+00	3958
466	2	-466	unknown part of incipient Jomon pottery of type SIII	\N	4	1	-466	\N	C	2019-12-20 22:14:28.053842+00	3959
465	2	-465	unknown part of incipient Jomon pottery of type SIII	\N	4	1	-465	\N	C	2019-12-20 22:14:28.053842+00	3960
464	2	-464	unknown part of incipient Jomon pottery of type SIII	\N	4	1	-464	\N	C	2019-12-20 22:14:28.053842+00	3961
463	2	-463	unknown part of incipient Jomon pottery of type SIII	\N	4	1	-463	\N	C	2019-12-20 22:14:28.053842+00	3962
462	2	-462	unknown part of incipient Jomon pottery of type SIII	\N	4	1	-462	\N	C	2019-12-20 22:14:28.053842+00	3963
461	2	-461	unknown part of incipient Jomon pottery of type SIII	\N	4	1	-461	\N	C	2019-12-20 22:14:28.053842+00	3964
460	2	-460	unknown part of incipient Jomon pottery of type SIII	\N	4	1	-460	\N	C	2019-12-20 22:14:28.053842+00	3965
459	2	-459	unknown part of incipient Jomon pottery of type SIII	\N	4	1	-459	\N	C	2019-12-20 22:14:28.053842+00	3966
458	2	-458	unknown part of incipient Jomon pottery of type SIII	\N	4	1	-458	\N	C	2019-12-20 22:14:28.053842+00	3967
457	2	-457	unknown part of incipient Jomon pottery of type SIII	\N	4	1	-457	\N	C	2019-12-20 22:14:28.053842+00	3968
456	2	-456	unknown part of incipient Jomon pottery of type SIII	\N	4	1	-456	\N	C	2019-12-20 22:14:28.053842+00	3969
455	2	-455	unknown part of incipient Jomon pottery of type SII	\N	4	1	-455	\N	C	2019-12-20 22:14:28.053842+00	3970
454	2	-454	unknown part of incipient Jomon pottery of type SII	\N	4	1	-454	\N	C	2019-12-20 22:14:28.053842+00	3971
453	2	-453	unknown part of incipient Jomon pottery of type SII	\N	4	1	-453	\N	C	2019-12-20 22:14:28.053842+00	3972
452	2	-452	unknown part of incipient Jomon pottery of type SII	\N	4	1	-452	\N	C	2019-12-20 22:14:28.053842+00	3973
451	2	-451	unknown part of incipient Jomon pottery of type SII	\N	4	1	-451	\N	C	2019-12-20 22:14:28.053842+00	3974
450	2	-450	upper body of incipient Jomon pottery of type SIII	\N	4	1	-450	\N	C	2019-12-20 22:14:28.053842+00	3975
449	2	-449	unknown part of initial Jomon pottery of type SIV	\N	4	1	-449	\N	C	2019-12-20 22:14:28.053842+00	3976
448	2	-448	unknown part of initial Jomon pottery of type SIV	\N	4	1	-448	\N	C	2019-12-20 22:14:28.053842+00	3977
447	2	-447	unknown part of initial Jomon pottery of type SIV	\N	4	1	-447	\N	C	2019-12-20 22:14:28.053842+00	3978
446	2	-446	unknown part of initial Jomon pottery of type SIV	\N	4	1	-446	\N	C	2019-12-20 22:14:28.053842+00	3979
445	2	-445	unknown part of initial Jomon pottery of type SIV	\N	4	1	-445	\N	C	2019-12-20 22:14:28.053842+00	3980
444	2	-444	unknown part of initial Jomon pottery of type SIV	\N	4	1	-444	\N	C	2019-12-20 22:14:28.053842+00	3981
443	2	-443	body of incipient Jomon pottery of type SIII	\N	4	1	-443	\N	C	2019-12-20 22:14:28.053842+00	3982
442	2	-442	rim of incipient Jomon pottery of type SIII	\N	4	1	-442	\N	C	2019-12-20 22:14:28.053842+00	3983
441	2	-441	rim of incipient Jomon pottery of type SIII	\N	4	1	-441	\N	C	2019-12-20 22:14:28.053842+00	3984
440	2	-440	unknown part of initial Jomon pottery of type SIV	\N	4	1	-440	\N	C	2019-12-20 22:14:28.053842+00	3985
439	2	-439	unknown part of initial Jomon pottery of type SIV	\N	4	1	-439	\N	C	2019-12-20 22:14:28.053842+00	3986
438	2	-438	unknown part of initial Jomon pottery of type SIV	\N	4	1	-438	\N	C	2019-12-20 22:14:28.053842+00	3987
437	2	-437	body of initial Jomon pottery of type SIV	\N	4	1	-437	\N	C	2019-12-20 22:14:28.053842+00	3988
436	2	-436	body of initial Jomon pottery of type SIV	\N	4	1	-436	\N	C	2019-12-20 22:14:28.053842+00	3989
435	2	-435	body of initial Jomon pottery of type SIV	\N	4	1	-435	\N	C	2019-12-20 22:14:28.053842+00	3990
434	2	-434	body of initial Jomon pottery of type SIV	\N	4	1	-434	\N	C	2019-12-20 22:14:28.053842+00	3991
433	2	-433	body of initial Jomon pottery of type SIV	\N	4	1	-433	\N	C	2019-12-20 22:14:28.053842+00	3992
432	2	-432	body of initial Jomon pottery of type SIV	\N	4	1	-432	\N	C	2019-12-20 22:14:28.053842+00	3993
431	2	-431	body of initial Jomon pottery of type SIV	\N	4	1	-431	\N	C	2019-12-20 22:14:28.053842+00	3994
430	2	-430	body of initial Jomon pottery of type SIV	\N	4	1	-430	\N	C	2019-12-20 22:14:28.053842+00	3995
429	2	-429	body of initial Jomon pottery of type SIV	\N	4	1	-429	\N	C	2019-12-20 22:14:28.053842+00	3996
428	2	-428	body of initial Jomon pottery of type SIV	\N	4	1	-428	\N	C	2019-12-20 22:14:28.053842+00	3997
427	2	-427	body of initial Jomon pottery of type SIV	\N	4	1	-427	\N	C	2019-12-20 22:14:28.053842+00	3998
426	2	-426	body of initial Jomon pottery of type SIV	\N	4	1	-426	\N	C	2019-12-20 22:14:28.053842+00	3999
425	2	-425	body of initial Jomon pottery of type SIV	\N	4	1	-425	\N	C	2019-12-20 22:14:28.053842+00	4000
424	2	-424	body of initial Jomon pottery of type SIV	\N	4	1	-424	\N	C	2019-12-20 22:14:28.053842+00	4001
423	2	-423	body of initial Jomon pottery of type SIV	\N	4	1	-423	\N	C	2019-12-20 22:14:28.053842+00	4002
422	2	-422	body of initial Jomon pottery of type SIV	\N	4	1	-422	\N	C	2019-12-20 22:14:28.053842+00	4003
421	2	-421	body of initial Jomon pottery of type SIV	\N	4	1	-421	\N	C	2019-12-20 22:14:28.053842+00	4004
420	2	-420	body of initial Jomon pottery of type SIV	\N	4	1	-420	\N	C	2019-12-20 22:14:28.053842+00	4005
419	2	-419	body of initial Jomon pottery of type SIV	\N	4	1	-419	\N	C	2019-12-20 22:14:28.053842+00	4006
418	2	-418	body of initial Jomon pottery of type SIV	\N	4	1	-418	\N	C	2019-12-20 22:14:28.053842+00	4007
417	2	-417	body of initial Jomon pottery of type SIV	\N	4	1	-417	\N	C	2019-12-20 22:14:28.053842+00	4008
416	2	-416	body of initial Jomon pottery of type SIV	\N	4	1	-416	\N	C	2019-12-20 22:14:28.053842+00	4009
415	2	-415	body of initial Jomon pottery of type SIV	\N	4	1	-415	\N	C	2019-12-20 22:14:28.053842+00	4010
414	2	-414	body of initial Jomon pottery of type SIV	\N	4	1	-414	\N	C	2019-12-20 22:14:28.053842+00	4011
413	2	-413	body of initial Jomon pottery of type SIV	\N	4	1	-413	\N	C	2019-12-20 22:14:28.053842+00	4012
412	2	-412	body of initial Jomon pottery of type SIV	\N	4	1	-412	\N	C	2019-12-20 22:14:28.053842+00	4013
411	2	-411	body of initial Jomon pottery of type SIV	\N	4	1	-411	\N	C	2019-12-20 22:14:28.053842+00	4014
410	2	-410	body of initial Jomon pottery of type SIV	\N	4	1	-410	\N	C	2019-12-20 22:14:28.053842+00	4015
409	2	-409	body of initial Jomon pottery of type SIV	\N	4	1	-409	\N	C	2019-12-20 22:14:28.053842+00	4016
408	2	-408	body of initial Jomon pottery of type SIV	\N	4	1	-408	\N	C	2019-12-20 22:14:28.053842+00	4017
407	2	-407	body of initial Jomon pottery of type SIV	\N	4	1	-407	\N	C	2019-12-20 22:14:28.053842+00	4018
406	2	-406	body of initial Jomon pottery of type SIV	\N	4	1	-406	\N	C	2019-12-20 22:14:28.053842+00	4019
405	2	-405	body of initial Jomon pottery of type SIV	\N	4	1	-405	\N	C	2019-12-20 22:14:28.053842+00	4020
404	2	-404	body of initial Jomon pottery of type SIV	\N	4	1	-404	\N	C	2019-12-20 22:14:28.053842+00	4021
403	2	-403	body of initial Jomon pottery of type SIV	\N	4	1	-403	\N	C	2019-12-20 22:14:28.053842+00	4022
402	2	-402	body of initial Jomon pottery of type SIV	\N	4	1	-402	\N	C	2019-12-20 22:14:28.053842+00	4023
401	2	-401	body of initial Jomon pottery of type SIV	\N	4	1	-401	\N	C	2019-12-20 22:14:28.053842+00	4024
400	2	-400	body of initial Jomon pottery of type SIV	\N	4	1	-400	\N	C	2019-12-20 22:14:28.053842+00	4025
399	2	-399	body of initial Jomon pottery of type SIV	\N	4	1	-399	\N	C	2019-12-20 22:14:28.053842+00	4026
398	2	-398	body of initial Jomon pottery of type SIV	\N	4	1	-398	\N	C	2019-12-20 22:14:28.053842+00	4027
397	2	-397	rim of initial Jomon pottery of type SIV	\N	4	1	-397	\N	C	2019-12-20 22:14:28.053842+00	4028
396	2	-396	rim of initial Jomon pottery of type SIV	\N	4	1	-396	\N	C	2019-12-20 22:14:28.053842+00	4029
395	2	-395	base of initial Jomon pottery of type SIV	\N	4	1	-395	\N	C	2019-12-20 22:14:28.053842+00	4030
394	2	-394	Lower body of initial Jomon pottery of type SIV	\N	4	1	-394	\N	C	2019-12-20 22:14:28.053842+00	4031
393	2	-393	body of initial Jomon pottery of type SIV	\N	4	1	-393	\N	C	2019-12-20 22:14:28.053842+00	4032
392	2	-392	rim of initial Jomon pottery of type SIV	\N	4	1	-392	\N	C	2019-12-20 22:14:28.053842+00	4033
391	2	-391	rim of initial Jomon pottery of type SIV	\N	4	1	-391	\N	C	2019-12-20 22:14:28.053842+00	4034
390	2	-390	rim of initial Jomon pottery of type SIV	\N	4	1	-390	\N	C	2019-12-20 22:14:28.053842+00	4035
389	2	-389	Lower body of initial Jomon pottery of type SIV	\N	4	1	-389	\N	C	2019-12-20 22:14:28.053842+00	4036
388	2	-388	rim of initial Jomon pottery of type SIV	\N	4	1	-388	\N	C	2019-12-20 22:14:28.053842+00	4037
387	2	-387	body of initial Jomon pottery of type SIV	\N	4	1	-387	\N	C	2019-12-20 22:14:28.053842+00	4038
386	2	-386	body of initial Jomon pottery of type SIV	\N	4	1	-386	\N	C	2019-12-20 22:14:28.053842+00	4039
385	2	-385	rim of initial Jomon pottery of type SIV	\N	4	1	-385	\N	C	2019-12-20 22:14:28.053842+00	4040
384	2	-384	rim of initial Jomon pottery of type SIV	\N	4	1	-384	\N	C	2019-12-20 22:14:28.053842+00	4041
383	2	-383	body of initial Jomon pottery of type SIV	\N	4	1	-383	\N	C	2019-12-20 22:14:28.053842+00	4042
382	2	-382	Lower body of initial Jomon pottery of type SIV	\N	4	1	-382	\N	C	2019-12-20 22:14:28.053842+00	4043
381	2	-381	rim of initial Jomon pottery of type SIV	\N	4	1	-381	\N	C	2019-12-20 22:14:28.053842+00	4044
380	2	-380	rim of initial Jomon pottery of type SIV	\N	4	1	-380	\N	C	2019-12-20 22:14:28.053842+00	4045
379	2	-379	body of initial Jomon pottery of type SIV	\N	4	1	-379	\N	C	2019-12-20 22:14:28.053842+00	4046
378	2	-378	rim of initial Jomon pottery of type SIV	\N	4	1	-378	\N	C	2019-12-20 22:14:28.053842+00	4047
377	2	-377	Lower body of initial Jomon pottery of type SIV	\N	4	1	-377	\N	C	2019-12-20 22:14:28.053842+00	4048
376	2	-376	Lower body of initial Jomon pottery of type SIV	\N	4	1	-376	\N	C	2019-12-20 22:14:28.053842+00	4049
375	2	-375	body of initial Jomon pottery of type SIV	\N	4	1	-375	\N	C	2019-12-20 22:14:28.053842+00	4050
374	2	-374	body of initial Jomon pottery of type SIV	\N	4	1	-374	\N	C	2019-12-20 22:14:28.053842+00	4051
373	2	-373	body of initial Jomon pottery of type SIV	\N	4	1	-373	\N	C	2019-12-20 22:14:28.053842+00	4052
372	2	-372	base of initial Jomon pottery of type SIV	\N	4	1	-372	\N	C	2019-12-20 22:14:28.053842+00	4053
371	2	-371	body of initial Jomon pottery of type SIV	\N	4	1	-371	\N	C	2019-12-20 22:14:28.053842+00	4054
370	2	-370	body of initial Jomon pottery of type SIV	\N	4	1	-370	\N	C	2019-12-20 22:14:28.053842+00	4055
369	2	-369	body of initial Jomon pottery of type SIV	\N	4	1	-369	\N	C	2019-12-20 22:14:28.053842+00	4056
368	2	-368	body of initial Jomon pottery of type SIV	\N	4	1	-368	\N	C	2019-12-20 22:14:28.053842+00	4057
367	2	-367	neck of initial Jomon pottery of type SIV	\N	4	1	-367	\N	C	2019-12-20 22:14:28.053842+00	4058
366	2	-366	neck of initial Jomon pottery of type SIV	\N	4	1	-366	\N	C	2019-12-20 22:14:28.053842+00	4059
365	2	-365	body of initial Jomon pottery of type SIV	\N	4	1	-365	\N	C	2019-12-20 22:14:28.053842+00	4060
364	2	-364	body of initial Jomon pottery of type SIV	\N	4	1	-364	\N	C	2019-12-20 22:14:28.053842+00	4061
363	2	-363	neck of initial Jomon pottery of type SIV	\N	4	1	-363	\N	C	2019-12-20 22:14:28.053842+00	4062
362	2	-362	rim of initial Jomon pottery of type SIV	\N	4	1	-362	\N	C	2019-12-20 22:14:28.053842+00	4063
361	2	-361	neck of initial Jomon pottery of type SIV	\N	4	1	-361	\N	C	2019-12-20 22:14:28.053842+00	4064
360	2	-360	neck of initial Jomon pottery of type SIV	\N	4	1	-360	\N	C	2019-12-20 22:14:28.053842+00	4065
359	2	-359	rim of initial Jomon pottery of type SIV	\N	4	1	-359	\N	C	2019-12-20 22:14:28.053842+00	4066
358	2	-358	neck of initial Jomon pottery of type SIV	\N	4	1	-358	\N	C	2019-12-20 22:14:28.053842+00	4067
357	2	-357	base of initial Jomon pottery of type SIV	\N	4	1	-357	\N	C	2019-12-20 22:14:28.053842+00	4068
356	2	-356	body of initial Jomon pottery of type SIV	\N	4	1	-356	\N	C	2019-12-20 22:14:28.053842+00	4069
355	2	-355	body of initial Jomon pottery of type SIV	\N	4	1	-355	\N	C	2019-12-20 22:14:28.053842+00	4070
354	2	-354	body of initial Jomon pottery of type SIV	\N	4	1	-354	\N	C	2019-12-20 22:14:28.053842+00	4071
353	2	-353	body of initial Jomon pottery of type SIV	\N	4	1	-353	\N	C	2019-12-20 22:14:28.053842+00	4072
352	2	-352	body of initial Jomon pottery of type SIV	\N	4	1	-352	\N	C	2019-12-20 22:14:28.053842+00	4073
351	2	-351	body of initial Jomon pottery of type SIV	\N	4	1	-351	\N	C	2019-12-20 22:14:28.053842+00	4074
47	2	-47	body of initial Jomon pottery of type SIV	\N	4	1	-47	\N	C	2019-12-20 22:14:28.053842+00	4378
46	2	-46	rim of initial Jomon pottery of type SIV	\N	4	1	-46	\N	C	2019-12-20 22:14:28.053842+00	4379
45	2	-45	rim of initial Jomon pottery of type SIV	\N	4	1	-45	\N	C	2019-12-20 22:14:28.053842+00	4380
44	2	-44	rim of initial Jomon pottery of type SIV	\N	4	1	-44	\N	C	2019-12-20 22:14:28.053842+00	4381
43	2	-43	rim of initial Jomon pottery of type SIV	\N	4	1	-43	\N	C	2019-12-20 22:14:28.053842+00	4382
42	2	-42	rim of initial Jomon pottery of type SIV	\N	4	1	-42	\N	C	2019-12-20 22:14:28.053842+00	4383
41	2	-41	rim of initial Jomon pottery of type SIV	\N	4	1	-41	\N	C	2019-12-20 22:14:28.053842+00	4384
40	2	-40	rim of initial Jomon pottery of type SIV	\N	4	1	-40	\N	C	2019-12-20 22:14:28.053842+00	4385
39	2	-39	rim of initial Jomon pottery of type SIV	\N	4	1	-39	\N	C	2019-12-20 22:14:28.053842+00	4386
38	2	-38	rim of initial Jomon pottery of type SIV	\N	4	1	-38	\N	C	2019-12-20 22:14:28.053842+00	4387
37	2	-37	rim of initial Jomon pottery of type SIV	\N	4	1	-37	\N	C	2019-12-20 22:14:28.053842+00	4388
36	2	-36	body of initial Jomon pottery of type SIV	\N	4	1	-36	\N	C	2019-12-20 22:14:28.053842+00	4389
35	2	-35	rim of initial Jomon pottery of type SIV	\N	4	1	-35	\N	C	2019-12-20 22:14:28.053842+00	4390
34	2	-34	rim of initial Jomon pottery of type SIV	\N	4	1	-34	\N	C	2019-12-20 22:14:28.053842+00	4391
33	2	-33	body of initial Jomon pottery of type SIV	\N	4	1	-33	\N	C	2019-12-20 22:14:28.053842+00	4392
32	2	-32	rim of initial Jomon pottery of type SIV	\N	4	1	-32	\N	C	2019-12-20 22:14:28.053842+00	4393
31	2	-31	rim of initial Jomon pottery of type SIV	\N	4	1	-31	\N	C	2019-12-20 22:14:28.053842+00	4394
30	2	-30	rim of initial Jomon pottery of type SIV	\N	4	1	-30	\N	C	2019-12-20 22:14:28.053842+00	4395
29	2	-29	body of initial Jomon pottery of type SIV	\N	4	1	-29	\N	C	2019-12-20 22:14:28.053842+00	4396
28	2	-28	body of initial Jomon pottery of type SIV	\N	4	1	-28	\N	C	2019-12-20 22:14:28.053842+00	4397
27	2	-27	body of incipient Jomon pottery of type SIII	\N	4	1	-27	\N	C	2019-12-20 22:14:28.053842+00	4398
26	2	-26	body of incipient Jomon pottery of type SIII	\N	4	1	-26	\N	C	2019-12-20 22:14:28.053842+00	4399
25	2	-25	body of incipient Jomon pottery of type SIII	\N	4	1	-25	\N	C	2019-12-20 22:14:28.053842+00	4400
2503	1	-45698	nej	\N	1	1	-2503	\N	C	2019-12-20 22:13:53.799521+00	1
2502	4	-45698	vittrad	\N	1	1	-2502	\N	C	2019-12-20 22:13:53.799521+00	2
2501	2	-45698	hals	\N	1	1	-2501	\N	C	2019-12-20 22:13:53.799521+00	3
2500	1	-45697	nej	\N	1	1	-2500	\N	C	2019-12-20 22:13:53.799521+00	4
2499	4	-45697	glättad	\N	1	1	-2499	\N	C	2019-12-20 22:13:53.799521+00	5
2498	2	-45697	hals	\N	1	1	-2498	\N	C	2019-12-20 22:13:53.799521+00	6
2497	1	-45696	ja	\N	1	1	-2497	\N	C	2019-12-20 22:13:53.799521+00	7
2496	4	-45696	glättad	\N	1	1	-2496	\N	C	2019-12-20 22:13:53.799521+00	8
2495	2	-45696	buk	\N	1	1	-2495	\N	C	2019-12-20 22:13:53.799521+00	9
2494	1	-45695	nej	\N	1	1	-2494	\N	C	2019-12-20 22:13:53.799521+00	10
2493	4	-45695	glättad	\N	1	1	-2493	\N	C	2019-12-20 22:13:53.799521+00	11
2492	2	-45695	hals	\N	1	1	-2492	\N	C	2019-12-20 22:13:53.799521+00	12
2491	1	-45694	nej	\N	1	1	-2491	\N	C	2019-12-20 22:13:53.799521+00	13
2490	4	-45694	glättad	\N	1	1	-2490	\N	C	2019-12-20 22:13:53.799521+00	14
2489	2	-45694	buk	\N	1	1	-2489	\N	C	2019-12-20 22:13:53.799521+00	15
2488	1	-45674	Dekor	\N	1	1	-2488	\N	C	2019-12-20 22:13:53.799521+00	16
2487	1	-45673	Dekor	\N	1	1	-2487	\N	C	2019-12-20 22:13:53.799521+00	17
2486	1	-45672	Dekor	\N	1	1	-2486	\N	C	2019-12-20 22:13:53.799521+00	18
2485	1	-45671	Dekor	\N	1	1	-2485	\N	C	2019-12-20 22:13:53.799521+00	19
2484	1	-45670	Dekor	\N	1	1	-2484	\N	C	2019-12-20 22:13:53.799521+00	20
2483	1	-45669	nej	\N	1	1	-2483	\N	C	2019-12-20 22:13:53.799521+00	21
2482	4	-45669	Strierad/strimmig	\N	1	1	-2482	\N	C	2019-12-20 22:13:53.799521+00	22
2481	1	-45668	Dekor	\N	1	1	-2481	\N	C	2019-12-20 22:13:53.799521+00	23
2480	1	-45667	nej	\N	1	1	-2480	\N	C	2019-12-20 22:13:53.799521+00	24
2479	4	-45667	Polerad	\N	1	1	-2479	\N	C	2019-12-20 22:13:53.799521+00	25
2478	1	-45666	nej	\N	1	1	-2478	\N	C	2019-12-20 22:13:53.799521+00	26
2477	4	-45666	Rabbad	\N	1	1	-2477	\N	C	2019-12-20 22:13:53.799521+00	27
2476	1	-45665	nej	\N	1	1	-2476	\N	C	2019-12-20 22:13:53.799521+00	28
2475	4	-45665	Rabbad	\N	1	1	-2475	\N	C	2019-12-20 22:13:53.799521+00	29
2474	1	-45664	nej	\N	1	1	-2474	\N	C	2019-12-20 22:13:53.799521+00	30
2473	4	-45664	Rabbad	\N	1	1	-2473	\N	C	2019-12-20 22:13:53.799521+00	31
2472	1	-45663	nej	\N	1	1	-2472	\N	C	2019-12-20 22:13:53.799521+00	32
2471	4	-45663	Rabbad	\N	1	1	-2471	\N	C	2019-12-20 22:13:53.799521+00	33
2470	1	-45662	nej	\N	1	1	-2470	\N	C	2019-12-20 22:13:53.799521+00	34
2469	4	-45662	Rabbad	\N	1	1	-2469	\N	C	2019-12-20 22:13:53.799521+00	35
2468	2	-45661	inner	\N	1	1	-2468	\N	C	2019-12-20 22:13:53.799521+00	36
2467	2	-45660	inner	\N	1	1	-2467	\N	C	2019-12-20 22:13:53.799521+00	37
2466	2	-45659	ytter	\N	1	1	-2466	\N	C	2019-12-20 22:13:53.799521+00	38
2465	2	-45658	inner	\N	1	1	-2465	\N	C	2019-12-20 22:13:53.799521+00	39
2464	2	-45657	inner	\N	1	1	-2464	\N	C	2019-12-20 22:13:53.799521+00	40
2463	2	-45656	ytter	\N	1	1	-2463	\N	C	2019-12-20 22:13:53.799521+00	41
2462	2	-45655	ytter	\N	1	1	-2462	\N	C	2019-12-20 22:13:53.799521+00	42
2461	2	-45654	inner	\N	1	1	-2461	\N	C	2019-12-20 22:13:53.799521+00	43
2460	2	-45653	inner	\N	1	1	-2460	\N	C	2019-12-20 22:13:53.799521+00	44
2459	2	-45652	ben	\N	1	1	-2459	\N	C	2019-12-20 22:13:53.799521+00	45
2458	2	-45651	ben	\N	1	1	-2458	\N	C	2019-12-20 22:13:53.799521+00	46
2457	2	-45650	ytter	\N	1	1	-2457	\N	C	2019-12-20 22:13:53.799521+00	47
2456	2	-45649	inner	\N	1	1	-2456	\N	C	2019-12-20 22:13:53.799521+00	48
2455	2	-45648	inner	\N	1	1	-2455	\N	C	2019-12-20 22:13:53.799521+00	49
2454	2	-45647	inner	\N	1	1	-2454	\N	C	2019-12-20 22:13:53.799521+00	50
2453	2	-45646	ben	\N	1	1	-2453	\N	C	2019-12-20 22:13:53.799521+00	51
2452	2	-45645	ytter	\N	1	1	-2452	\N	C	2019-12-20 22:13:53.799521+00	52
2451	2	-45644	ytter	\N	1	1	-2451	\N	C	2019-12-20 22:13:53.799521+00	53
2450	2	-45643	ytter	\N	1	1	-2450	\N	C	2019-12-20 22:13:53.799521+00	54
2449	2	-45642	ytter	\N	1	1	-2449	\N	C	2019-12-20 22:13:53.799521+00	55
2448	2	-45641	ytter	\N	1	1	-2448	\N	C	2019-12-20 22:13:53.799521+00	56
2447	2	-45640	inner	\N	1	1	-2447	\N	C	2019-12-20 22:13:53.799521+00	57
2446	2	-45639	ben	\N	1	1	-2446	\N	C	2019-12-20 22:13:53.799521+00	58
2445	2	-45638	ytter	\N	1	1	-2445	\N	C	2019-12-20 22:13:53.799521+00	59
2444	2	-45637	inner	\N	1	1	-2444	\N	C	2019-12-20 22:13:53.799521+00	60
2443	2	-45636	ytter	\N	1	1	-2443	\N	C	2019-12-20 22:13:53.799521+00	61
2442	2	-45635	inner	\N	1	1	-2442	\N	C	2019-12-20 22:13:53.799521+00	62
2441	2	-45634	ytter	\N	1	1	-2441	\N	C	2019-12-20 22:13:53.799521+00	63
2440	2	-45633	ben	\N	1	1	-2440	\N	C	2019-12-20 22:13:53.799521+00	64
2439	2	-45632	u	\N	1	1	-2439	\N	C	2019-12-20 22:13:53.799521+00	65
2438	2	-45631	ytter	\N	1	1	-2438	\N	C	2019-12-20 22:13:53.799521+00	66
2437	2	-45630	inner	\N	1	1	-2437	\N	C	2019-12-20 22:13:53.799521+00	67
2436	2	-45629	inner	\N	1	1	-2436	\N	C	2019-12-20 22:13:53.799521+00	68
2435	2	-45628	inner	\N	1	1	-2435	\N	C	2019-12-20 22:13:53.799521+00	69
2434	2	-45627	inner	\N	1	1	-2434	\N	C	2019-12-20 22:13:53.799521+00	70
2433	2	-45626	inner	\N	1	1	-2433	\N	C	2019-12-20 22:13:53.799521+00	71
2432	2	-45625	inner	\N	1	1	-2432	\N	C	2019-12-20 22:13:53.799521+00	72
2431	2	-45624	ytter	\N	1	1	-2431	\N	C	2019-12-20 22:13:53.799521+00	73
2430	2	-45623	inner	\N	1	1	-2430	\N	C	2019-12-20 22:13:53.799521+00	74
2429	2	-45622	ytter	\N	1	1	-2429	\N	C	2019-12-20 22:13:53.799521+00	75
2428	2	-45621	ytter	\N	1	1	-2428	\N	C	2019-12-20 22:13:53.799521+00	76
2427	2	-45620	ben	\N	1	1	-2427	\N	C	2019-12-20 22:13:53.799521+00	77
2426	1	-45612	glasyr	\N	1	1	-2426	\N	C	2019-12-20 22:13:53.799521+00	78
2425	1	-45611	glasyr	\N	1	1	-2425	\N	C	2019-12-20 22:13:53.799521+00	79
2424	1	-45610	glasyr	\N	1	1	-2424	\N	C	2019-12-20 22:13:53.799521+00	80
2423	1	-45609	glasyr	\N	1	1	-2423	\N	C	2019-12-20 22:13:53.799521+00	81
2422	1	-45608	glasyr	\N	1	1	-2422	\N	C	2019-12-20 22:13:53.799521+00	82
2421	1	-45606	glasyr	\N	1	1	-2421	\N	C	2019-12-20 22:13:53.799521+00	83
2420	1	-45605	glasyr	\N	1	1	-2420	\N	C	2019-12-20 22:13:53.799521+00	84
2419	1	-45604	glasyr	\N	1	1	-2419	\N	C	2019-12-20 22:13:53.799521+00	85
2418	1	-45602	glasyr	\N	1	1	-2418	\N	C	2019-12-20 22:13:53.799521+00	86
2417	1	-45601	glasyr	\N	1	1	-2417	\N	C	2019-12-20 22:13:53.799521+00	87
2416	1	-45600	glasyr	\N	1	1	-2416	\N	C	2019-12-20 22:13:53.799521+00	88
2415	1	-45599	glasyr	\N	1	1	-2415	\N	C	2019-12-20 22:13:53.799521+00	89
2414	1	-45589	glasyr	\N	1	1	-2414	\N	C	2019-12-20 22:13:53.799521+00	90
2413	1	-45583	nej	\N	1	1	-2413	\N	C	2019-12-20 22:13:53.799521+00	91
2412	1	-45582	nej	\N	1	1	-2412	\N	C	2019-12-20 22:13:53.799521+00	92
2411	1	-45556	nej	\N	1	1	-2411	\N	C	2019-12-20 22:13:53.799521+00	93
2410	4	-45556	vittrad	\N	1	1	-2410	\N	C	2019-12-20 22:13:53.799521+00	94
2409	1	-45555	nej	\N	1	1	-2409	\N	C	2019-12-20 22:13:53.799521+00	95
2408	4	-45555	fingerränder	\N	1	1	-2408	\N	C	2019-12-20 22:13:53.799521+00	96
2407	1	-45554	nej	\N	1	1	-2407	\N	C	2019-12-20 22:13:53.799521+00	97
2406	1	-45553	nej	\N	1	1	-2406	\N	C	2019-12-20 22:13:53.799521+00	98
2405	1	-45552	nej	\N	1	1	-2405	\N	C	2019-12-20 22:13:53.799521+00	99
2404	1	-45551	nej	\N	1	1	-2404	\N	C	2019-12-20 22:13:53.799521+00	100
2403	1	-45550	nej	\N	1	1	-2403	\N	C	2019-12-20 22:13:53.799521+00	101
2402	1	-45549	nej	\N	1	1	-2402	\N	C	2019-12-20 22:13:53.799521+00	102
2401	1	-45546	nej	\N	1	1	-2401	\N	C	2019-12-20 22:13:53.799521+00	103
2400	1	-45545	nej	\N	1	1	-2400	\N	C	2019-12-20 22:13:53.799521+00	104
2399	1	-45544	nej	\N	1	1	-2399	\N	C	2019-12-20 22:13:53.799521+00	105
2398	1	-45543	nej	\N	1	1	-2398	\N	C	2019-12-20 22:13:53.799521+00	106
2397	1	-45542	nej	\N	1	1	-2397	\N	C	2019-12-20 22:13:53.799521+00	107
2396	1	-45541	nej	\N	1	1	-2396	\N	C	2019-12-20 22:13:53.799521+00	108
2395	1	-45540	nej	\N	1	1	-2395	\N	C	2019-12-20 22:13:53.799521+00	109
2394	1	-45539	nej	\N	1	1	-2394	\N	C	2019-12-20 22:13:53.799521+00	110
2393	1	-45538	nej	\N	1	1	-2393	\N	C	2019-12-20 22:13:53.799521+00	111
2392	1	-45537	Dekor	\N	1	1	-2392	\N	C	2019-12-20 22:13:53.799521+00	112
2391	1	-45536	Dekor	\N	1	1	-2391	\N	C	2019-12-20 22:13:53.799521+00	113
2390	1	-45535	Dekor	\N	1	1	-2390	\N	C	2019-12-20 22:13:53.799521+00	114
2389	1	-45534	Dekor	\N	1	1	-2389	\N	C	2019-12-20 22:13:53.799521+00	115
2388	1	-45533	Dekor	\N	1	1	-2388	\N	C	2019-12-20 22:13:53.799521+00	116
2387	1	-45532	Dekor	\N	1	1	-2387	\N	C	2019-12-20 22:13:53.799521+00	117
2386	1	-45531	Dekor	\N	1	1	-2386	\N	C	2019-12-20 22:13:53.799521+00	118
2385	1	-45530	Dekor	\N	1	1	-2385	\N	C	2019-12-20 22:13:53.799521+00	119
2384	1	-45484	nej	\N	1	1	-2384	\N	C	2019-12-20 22:13:53.799521+00	120
2383	1	-45483	nej	\N	1	1	-2383	\N	C	2019-12-20 22:13:53.799521+00	121
2382	1	-45482	nej	\N	1	1	-2382	\N	C	2019-12-20 22:13:53.799521+00	122
2381	1	-45481	nej	\N	1	1	-2381	\N	C	2019-12-20 22:13:53.799521+00	123
2380	1	-45480	Dekor	\N	1	1	-2380	\N	C	2019-12-20 22:13:53.799521+00	124
2379	1	-45479	Dekor	\N	1	1	-2379	\N	C	2019-12-20 22:13:53.799521+00	125
2378	1	-45478	Dekor	\N	1	1	-2378	\N	C	2019-12-20 22:13:53.799521+00	126
2377	1	-45477	Dekor	\N	1	1	-2377	\N	C	2019-12-20 22:13:53.799521+00	127
2376	1	-45476	Dekor	\N	1	1	-2376	\N	C	2019-12-20 22:13:53.799521+00	128
2375	1	-45472	nej	\N	1	1	-2375	\N	C	2019-12-20 22:13:53.799521+00	129
2374	4	-45472	Rabbad med fingerdragningar	\N	1	1	-2374	\N	C	2019-12-20 22:13:53.799521+00	130
2373	1	-45431	Dekor	\N	1	1	-2373	\N	C	2019-12-20 22:13:53.799521+00	131
2372	4	-45431	glättad	\N	1	1	-2372	\N	C	2019-12-20 22:13:53.799521+00	132
2371	4	-45430	textil?	\N	1	1	-2371	\N	C	2019-12-20 22:13:53.799521+00	133
2370	1	-45428	Dekor	\N	1	1	-2370	\N	C	2019-12-20 22:13:53.799521+00	134
2369	4	-45427	textil?	\N	1	1	-2369	\N	C	2019-12-20 22:13:53.799521+00	135
2368	1	-45411	Dekor	\N	1	1	-2368	\N	C	2019-12-20 22:13:53.799521+00	136
2367	1	-45410	Dekor	\N	1	1	-2367	\N	C	2019-12-20 22:13:53.799521+00	137
2366	1	-45409	Dekor	\N	1	1	-2366	\N	C	2019-12-20 22:13:53.799521+00	138
2365	1	-45408	nej	\N	1	1	-2365	\N	C	2019-12-20 22:13:53.799521+00	139
2364	1	-45407	nej	\N	1	1	-2364	\N	C	2019-12-20 22:13:53.799521+00	140
2363	1	-45406	nej	\N	1	1	-2363	\N	C	2019-12-20 22:13:53.799521+00	141
2362	1	-45405	nej	\N	1	1	-2362	\N	C	2019-12-20 22:13:53.799521+00	142
2361	1	-45404	nej	\N	1	1	-2361	\N	C	2019-12-20 22:13:53.799521+00	143
2360	1	-45403	nej	\N	1	1	-2360	\N	C	2019-12-20 22:13:53.799521+00	144
2359	1	-45402	nej	\N	1	1	-2359	\N	C	2019-12-20 22:13:53.799521+00	145
2358	1	-45401	nej	\N	1	1	-2358	\N	C	2019-12-20 22:13:53.799521+00	146
2357	1	-45400	nej	\N	1	1	-2357	\N	C	2019-12-20 22:13:53.799521+00	147
2356	1	-45399	nej	\N	1	1	-2356	\N	C	2019-12-20 22:13:53.799521+00	148
2355	1	-45398	nej	\N	1	1	-2355	\N	C	2019-12-20 22:13:53.799521+00	149
2354	1	-45375	nej	\N	1	1	-2354	\N	C	2019-12-20 22:13:53.799521+00	150
2353	1	-45374	nej	\N	1	1	-2353	\N	C	2019-12-20 22:13:53.799521+00	151
2352	4	-45374	Rabbad	\N	1	1	-2352	\N	C	2019-12-20 22:13:53.799521+00	152
2351	1	-45373	nej	\N	1	1	-2351	\N	C	2019-12-20 22:13:53.799521+00	153
2350	4	-45373	glättad	\N	1	1	-2350	\N	C	2019-12-20 22:13:53.799521+00	154
2349	1	-45372	Dekor	\N	1	1	-2349	\N	C	2019-12-20 22:13:53.799521+00	155
2348	4	-45372	glättad	\N	1	1	-2348	\N	C	2019-12-20 22:13:53.799521+00	156
2347	1	-45371	Dekor	\N	1	1	-2347	\N	C	2019-12-20 22:13:53.799521+00	157
2346	4	-45371	Polerad	\N	1	1	-2346	\N	C	2019-12-20 22:13:53.799521+00	158
2345	1	-45370	Dekor	\N	1	1	-2345	\N	C	2019-12-20 22:13:53.799521+00	159
2344	4	-45370	glättad	\N	1	1	-2344	\N	C	2019-12-20 22:13:53.799521+00	160
2343	1	-45369	nej	\N	1	1	-2343	\N	C	2019-12-20 22:13:53.799521+00	161
2342	4	-45369	Polerad	\N	1	1	-2342	\N	C	2019-12-20 22:13:53.799521+00	162
2341	1	-45368	nej	\N	1	1	-2341	\N	C	2019-12-20 22:13:53.799521+00	163
2340	4	-45368	glättad	\N	1	1	-2340	\N	C	2019-12-20 22:13:53.799521+00	164
2339	1	-45367	Dekor	\N	1	1	-2339	\N	C	2019-12-20 22:13:53.799521+00	165
2338	4	-45367	glättad	\N	1	1	-2338	\N	C	2019-12-20 22:13:53.799521+00	166
2337	1	-45366	nej	\N	1	1	-2337	\N	C	2019-12-20 22:13:53.799521+00	167
2336	4	-45366	Rabbad	\N	1	1	-2336	\N	C	2019-12-20 22:13:53.799521+00	168
2335	1	-45365	nej	\N	1	1	-2335	\N	C	2019-12-20 22:13:53.799521+00	169
2334	4	-45365	glättad	\N	1	1	-2334	\N	C	2019-12-20 22:13:53.799521+00	170
2333	1	-45364	Dekor	\N	1	1	-2333	\N	C	2019-12-20 22:13:53.799521+00	171
2332	4	-45364	Polerad	\N	1	1	-2332	\N	C	2019-12-20 22:13:53.799521+00	172
2331	1	-45363	nej	\N	1	1	-2331	\N	C	2019-12-20 22:13:53.799521+00	173
2330	4	-45363	Rabbad	\N	1	1	-2330	\N	C	2019-12-20 22:13:53.799521+00	174
2329	1	-45362	Dekor	\N	1	1	-2329	\N	C	2019-12-20 22:13:53.799521+00	175
2328	4	-45362	Polerad	\N	1	1	-2328	\N	C	2019-12-20 22:13:53.799521+00	176
2327	1	-45361	Dekor	\N	1	1	-2327	\N	C	2019-12-20 22:13:53.799521+00	177
2326	4	-45361	glättad	\N	1	1	-2326	\N	C	2019-12-20 22:13:53.799521+00	178
2325	1	-45360	nej	\N	1	1	-2325	\N	C	2019-12-20 22:13:53.799521+00	179
2324	4	-45360	glättad	\N	1	1	-2324	\N	C	2019-12-20 22:13:53.799521+00	180
2323	1	-45359	Dekor	\N	1	1	-2323	\N	C	2019-12-20 22:13:53.799521+00	181
2322	4	-45359	glättad	\N	1	1	-2322	\N	C	2019-12-20 22:13:53.799521+00	182
2321	1	-45358	Dekor	\N	1	1	-2321	\N	C	2019-12-20 22:13:53.799521+00	183
2320	4	-45358	glättad	\N	1	1	-2320	\N	C	2019-12-20 22:13:53.799521+00	184
2319	1	-45357	Dekor	\N	1	1	-2319	\N	C	2019-12-20 22:13:53.799521+00	185
2318	4	-45357	glättad	\N	1	1	-2318	\N	C	2019-12-20 22:13:53.799521+00	186
2317	1	-45356	nej	\N	1	1	-2317	\N	C	2019-12-20 22:13:53.799521+00	187
2316	4	-45356	Rabbad	\N	1	1	-2316	\N	C	2019-12-20 22:13:53.799521+00	188
2315	1	-45355	Dekor	\N	1	1	-2315	\N	C	2019-12-20 22:13:53.799521+00	189
2314	4	-45355	glättad	\N	1	1	-2314	\N	C	2019-12-20 22:13:53.799521+00	190
2313	1	-45354	Dekor	\N	1	1	-2313	\N	C	2019-12-20 22:13:53.799521+00	191
2312	4	-45354	Polerad	\N	1	1	-2312	\N	C	2019-12-20 22:13:53.799521+00	192
2311	1	-45353	nej	\N	1	1	-2311	\N	C	2019-12-20 22:13:53.799521+00	193
2310	4	-45353	Rabbad	\N	1	1	-2310	\N	C	2019-12-20 22:13:53.799521+00	194
2309	1	-45352	nej	\N	1	1	-2309	\N	C	2019-12-20 22:13:53.799521+00	195
2308	4	-45352	Rabbad	\N	1	1	-2308	\N	C	2019-12-20 22:13:53.799521+00	196
2307	1	-45351	nej	\N	1	1	-2307	\N	C	2019-12-20 22:13:53.799521+00	197
2306	4	-45351	Polerad	\N	1	1	-2306	\N	C	2019-12-20 22:13:53.799521+00	198
2305	1	-45350	Dekor	\N	1	1	-2305	\N	C	2019-12-20 22:13:53.799521+00	199
2304	4	-45350	Polerad	\N	1	1	-2304	\N	C	2019-12-20 22:13:53.799521+00	200
2303	1	-45349	Dekor	\N	1	1	-2303	\N	C	2019-12-20 22:13:53.799521+00	201
2302	4	-45349	glättad	\N	1	1	-2302	\N	C	2019-12-20 22:13:53.799521+00	202
2301	4	-45348	Polerad	\N	1	1	-2301	\N	C	2019-12-20 22:13:53.799521+00	203
2300	1	-45347	Dekor	\N	1	1	-2300	\N	C	2019-12-20 22:13:53.799521+00	204
2299	4	-45347	Polerad	\N	1	1	-2299	\N	C	2019-12-20 22:13:53.799521+00	205
2298	1	-45346	Dekor	\N	1	1	-2298	\N	C	2019-12-20 22:13:53.799521+00	206
2297	4	-45346	Polerad	\N	1	1	-2297	\N	C	2019-12-20 22:13:53.799521+00	207
2296	1	-45345	Dekor	\N	1	1	-2296	\N	C	2019-12-20 22:13:53.799521+00	208
2295	4	-45345	Polerad	\N	1	1	-2295	\N	C	2019-12-20 22:13:53.799521+00	209
2294	1	-45344	Dekor	\N	1	1	-2294	\N	C	2019-12-20 22:13:53.799521+00	210
2293	4	-45344	glättad	\N	1	1	-2293	\N	C	2019-12-20 22:13:53.799521+00	211
2292	4	-45343	glättad	\N	1	1	-2292	\N	C	2019-12-20 22:13:53.799521+00	212
2291	1	-45342	Dekor	\N	1	1	-2291	\N	C	2019-12-20 22:13:53.799521+00	213
2290	4	-45342	Polerad	\N	1	1	-2290	\N	C	2019-12-20 22:13:53.799521+00	214
2289	4	-45341	Polerad	\N	1	1	-2289	\N	C	2019-12-20 22:13:53.799521+00	215
2288	1	-45340	nej	\N	1	1	-2288	\N	C	2019-12-20 22:13:53.799521+00	216
2287	1	-45339	nej	\N	1	1	-2287	\N	C	2019-12-20 22:13:53.799521+00	217
2286	1	-45338	Dekor	\N	1	1	-2286	\N	C	2019-12-20 22:13:53.799521+00	218
2285	1	-45336	Dekor	\N	1	1	-2285	\N	C	2019-12-20 22:13:53.799521+00	219
2284	1	-45334	Dekor	\N	1	1	-2284	\N	C	2019-12-20 22:13:53.799521+00	220
2283	1	-45333	Dekor	\N	1	1	-2283	\N	C	2019-12-20 22:13:53.799521+00	221
2282	1	-45331	Dekor	\N	1	1	-2282	\N	C	2019-12-20 22:13:53.799521+00	222
2281	1	-45330	Dekor	\N	1	1	-2281	\N	C	2019-12-20 22:13:53.799521+00	223
2280	1	-45328	Dekor	\N	1	1	-2280	\N	C	2019-12-20 22:13:53.799521+00	224
2279	1	-45326	Dekor	\N	1	1	-2279	\N	C	2019-12-20 22:13:53.799521+00	225
2278	1	-45324	Dekor	\N	1	1	-2278	\N	C	2019-12-20 22:13:53.799521+00	226
2277	1	-45322	Dekor	\N	1	1	-2277	\N	C	2019-12-20 22:13:53.799521+00	227
2276	1	-45321	Dekor	\N	1	1	-2276	\N	C	2019-12-20 22:13:53.799521+00	228
2275	1	-45320	Dekor	\N	1	1	-2275	\N	C	2019-12-20 22:13:53.799521+00	229
2274	4	-45318	odef	\N	1	1	-2274	\N	C	2019-12-20 22:13:53.799521+00	230
2273	4	-45317	odef	\N	1	1	-2273	\N	C	2019-12-20 22:13:53.799521+00	231
2272	4	-45316	odef	\N	1	1	-2272	\N	C	2019-12-20 22:13:53.799521+00	232
2271	4	-45315	odef	\N	1	1	-2271	\N	C	2019-12-20 22:13:53.799521+00	233
2270	4	-45314	odef	\N	1	1	-2270	\N	C	2019-12-20 22:13:53.799521+00	234
2269	4	-45313	odef	\N	1	1	-2269	\N	C	2019-12-20 22:13:53.799521+00	235
2268	4	-45312	odef	\N	1	1	-2268	\N	C	2019-12-20 22:13:53.799521+00	236
2267	4	-45311	odef	\N	1	1	-2267	\N	C	2019-12-20 22:13:53.799521+00	237
2266	4	-45310	odef	\N	1	1	-2266	\N	C	2019-12-20 22:13:53.799521+00	238
2265	4	-45309	odef	\N	1	1	-2265	\N	C	2019-12-20 22:13:53.799521+00	239
2264	4	-45308	odef	\N	1	1	-2264	\N	C	2019-12-20 22:13:53.799521+00	240
2263	4	-45307	odef	\N	1	1	-2263	\N	C	2019-12-20 22:13:53.799521+00	241
2262	4	-45306	odef	\N	1	1	-2262	\N	C	2019-12-20 22:13:53.799521+00	242
2261	1	-45305	nej	\N	1	1	-2261	\N	C	2019-12-20 22:13:53.799521+00	243
2260	4	-45305	odef	\N	1	1	-2260	\N	C	2019-12-20 22:13:53.799521+00	244
2259	4	-45304	odef	\N	1	1	-2259	\N	C	2019-12-20 22:13:53.799521+00	245
2258	1	-45303	nej	\N	1	1	-2258	\N	C	2019-12-20 22:13:53.799521+00	246
2257	4	-45303	odef	\N	1	1	-2257	\N	C	2019-12-20 22:13:53.799521+00	247
2256	1	-45302	nej	\N	1	1	-2256	\N	C	2019-12-20 22:13:53.799521+00	248
2255	4	-45302	odef	\N	1	1	-2255	\N	C	2019-12-20 22:13:53.799521+00	249
2254	1	-45301	nej	\N	1	1	-2254	\N	C	2019-12-20 22:13:53.799521+00	250
2253	4	-45301	odef	\N	1	1	-2253	\N	C	2019-12-20 22:13:53.799521+00	251
2252	1	-45300	nej	\N	1	1	-2252	\N	C	2019-12-20 22:13:53.799521+00	252
2251	4	-45300	odef	\N	1	1	-2251	\N	C	2019-12-20 22:13:53.799521+00	253
2250	1	-45299	nej	\N	1	1	-2250	\N	C	2019-12-20 22:13:53.799521+00	254
2249	4	-45299	odef	\N	1	1	-2249	\N	C	2019-12-20 22:13:53.799521+00	255
2248	1	-45298	nej	\N	1	1	-2248	\N	C	2019-12-20 22:13:53.799521+00	256
2247	4	-45298	odef	\N	1	1	-2247	\N	C	2019-12-20 22:13:53.799521+00	257
2246	1	-45297	nej	\N	1	1	-2246	\N	C	2019-12-20 22:13:53.799521+00	258
2245	4	-45297	odef	\N	1	1	-2245	\N	C	2019-12-20 22:13:53.799521+00	259
2244	1	-45296	nej	\N	1	1	-2244	\N	C	2019-12-20 22:13:53.799521+00	260
2243	4	-45296	odef	\N	1	1	-2243	\N	C	2019-12-20 22:13:53.799521+00	261
2242	1	-45295	nej	\N	1	1	-2242	\N	C	2019-12-20 22:13:53.799521+00	262
2241	4	-45295	odef	\N	1	1	-2241	\N	C	2019-12-20 22:13:53.799521+00	263
2240	1	-45294	Textil	\N	1	1	-2240	\N	C	2019-12-20 22:13:53.799521+00	264
2239	4	-45294	Textil	\N	1	1	-2239	\N	C	2019-12-20 22:13:53.799521+00	265
2238	1	-45293	Öra	\N	1	1	-2238	\N	C	2019-12-20 22:13:53.799521+00	266
2237	4	-45293	Polerad	\N	1	1	-2237	\N	C	2019-12-20 22:13:53.799521+00	267
2236	1	-45292	nej	\N	1	1	-2236	\N	C	2019-12-20 22:13:53.799521+00	268
2235	4	-45292	glättad	\N	1	1	-2235	\N	C	2019-12-20 22:13:53.799521+00	269
2234	1	-45291	nej	\N	1	1	-2234	\N	C	2019-12-20 22:13:53.799521+00	270
2233	4	-45291	glättad	\N	1	1	-2233	\N	C	2019-12-20 22:13:53.799521+00	271
2232	1	-45290	nej	\N	1	1	-2232	\N	C	2019-12-20 22:13:53.799521+00	272
2231	4	-45290	Grov	\N	1	1	-2231	\N	C	2019-12-20 22:13:53.799521+00	273
2230	1	-45289	Otterböte	\N	1	1	-2230	\N	C	2019-12-20 22:13:53.799521+00	274
2229	4	-45289	Rabbad	\N	1	1	-2229	\N	C	2019-12-20 22:13:53.799521+00	275
2228	1	-45288	nej	\N	1	1	-2228	\N	C	2019-12-20 22:13:53.799521+00	276
2227	4	-45288	Rabbad	\N	1	1	-2227	\N	C	2019-12-20 22:13:53.799521+00	277
2226	1	-45287	nej	\N	1	1	-2226	\N	C	2019-12-20 22:13:53.799521+00	278
2225	4	-45287	Rabbad	\N	1	1	-2225	\N	C	2019-12-20 22:13:53.799521+00	279
2224	1	-45286	nej	\N	1	1	-2224	\N	C	2019-12-20 22:13:53.799521+00	280
2223	4	-45286	glättad	\N	1	1	-2223	\N	C	2019-12-20 22:13:53.799521+00	281
2222	1	-45285	nej	\N	1	1	-2222	\N	C	2019-12-20 22:13:53.799521+00	282
2221	4	-45285	Polerad	\N	1	1	-2221	\N	C	2019-12-20 22:13:53.799521+00	283
2220	1	-45284	nej	\N	1	1	-2220	\N	C	2019-12-20 22:13:53.799521+00	284
2219	4	-45284	Rabbad	\N	1	1	-2219	\N	C	2019-12-20 22:13:53.799521+00	285
2218	1	-45279	nej	\N	1	1	-2218	\N	C	2019-12-20 22:13:53.799521+00	286
2217	4	-45279	Strierad/strimmig	\N	1	1	-2217	\N	C	2019-12-20 22:13:53.799521+00	287
2216	1	-45278	nej	\N	1	1	-2216	\N	C	2019-12-20 22:13:53.799521+00	288
2215	4	-45278	Strierad/strimmig	\N	1	1	-2215	\N	C	2019-12-20 22:13:53.799521+00	289
2214	1	-45277	Otterböte	\N	1	1	-2214	\N	C	2019-12-20 22:13:53.799521+00	290
2213	4	-45277	Rabbad	\N	1	1	-2213	\N	C	2019-12-20 22:13:53.799521+00	291
2212	1	-45276	Otterböte	\N	1	1	-2212	\N	C	2019-12-20 22:13:53.799521+00	292
2211	4	-45276	Rabbad	\N	1	1	-2211	\N	C	2019-12-20 22:13:53.799521+00	293
2210	1	-45275	nej	\N	1	1	-2210	\N	C	2019-12-20 22:13:53.799521+00	294
2209	4	-45275	Polerad	\N	1	1	-2209	\N	C	2019-12-20 22:13:53.799521+00	295
2208	1	-45274	Textil	\N	1	1	-2208	\N	C	2019-12-20 22:13:53.799521+00	296
2207	4	-45274	Textil	\N	1	1	-2207	\N	C	2019-12-20 22:13:53.799521+00	297
2206	1	-45273	nej	\N	1	1	-2206	\N	C	2019-12-20 22:13:53.799521+00	298
2205	4	-45273	Grov	\N	1	1	-2205	\N	C	2019-12-20 22:13:53.799521+00	299
2204	1	-45272	nej	\N	1	1	-2204	\N	C	2019-12-20 22:13:53.799521+00	300
2203	4	-45272	glättad	\N	1	1	-2203	\N	C	2019-12-20 22:13:53.799521+00	301
2202	1	-45271	nej	\N	1	1	-2202	\N	C	2019-12-20 22:13:53.799521+00	302
2201	4	-45271	glättad	\N	1	1	-2201	\N	C	2019-12-20 22:13:53.799521+00	303
2200	1	-45270	nej	\N	1	1	-2200	\N	C	2019-12-20 22:13:53.799521+00	304
2199	4	-45270	Rabbad	\N	1	1	-2199	\N	C	2019-12-20 22:13:53.799521+00	305
2198	1	-45269	nej	\N	1	1	-2198	\N	C	2019-12-20 22:13:53.799521+00	306
2197	4	-45269	Rabbad	\N	1	1	-2197	\N	C	2019-12-20 22:13:53.799521+00	307
2196	1	-45268	nej	\N	1	1	-2196	\N	C	2019-12-20 22:13:53.799521+00	308
2195	4	-45268	Grov	\N	1	1	-2195	\N	C	2019-12-20 22:13:53.799521+00	309
2194	1	-45267	nej	\N	1	1	-2194	\N	C	2019-12-20 22:13:53.799521+00	310
2193	4	-45267	Rabbad	\N	1	1	-2193	\N	C	2019-12-20 22:13:53.799521+00	311
2192	1	-45266	nej	\N	1	1	-2192	\N	C	2019-12-20 22:13:53.799521+00	312
2191	4	-45266	odef	\N	1	1	-2191	\N	C	2019-12-20 22:13:53.799521+00	313
2190	1	-45265	Dekor	\N	1	1	-2190	\N	C	2019-12-20 22:13:53.799521+00	314
2189	4	-45265	odef	\N	1	1	-2189	\N	C	2019-12-20 22:13:53.799521+00	315
2188	1	-45264	nej	\N	1	1	-2188	\N	C	2019-12-20 22:13:53.799521+00	316
2187	4	-45264	odef	\N	1	1	-2187	\N	C	2019-12-20 22:13:53.799521+00	317
2186	1	-45263	nej	\N	1	1	-2186	\N	C	2019-12-20 22:13:53.799521+00	318
2185	4	-45263	odef	\N	1	1	-2185	\N	C	2019-12-20 22:13:53.799521+00	319
2184	1	-45262	Dekor	\N	1	1	-2184	\N	C	2019-12-20 22:13:53.799521+00	320
2183	4	-45262	odef	\N	1	1	-2183	\N	C	2019-12-20 22:13:53.799521+00	321
2182	1	-45261	Dekor	\N	1	1	-2182	\N	C	2019-12-20 22:13:53.799521+00	322
2181	4	-45261	odef	\N	1	1	-2181	\N	C	2019-12-20 22:13:53.799521+00	323
2180	1	-45258	nej	\N	1	1	-2180	\N	C	2019-12-20 22:13:53.799521+00	324
2179	4	-45258	Rabbad	\N	1	1	-2179	\N	C	2019-12-20 22:13:53.799521+00	325
2178	1	-45257	nej	\N	1	1	-2178	\N	C	2019-12-20 22:13:53.799521+00	326
2177	4	-45257	Rabbad	\N	1	1	-2177	\N	C	2019-12-20 22:13:53.799521+00	327
2176	1	-45256	nej	\N	1	1	-2176	\N	C	2019-12-20 22:13:53.799521+00	328
2175	4	-45256	Polerad	\N	1	1	-2175	\N	C	2019-12-20 22:13:53.799521+00	329
2174	1	-45255	nej	\N	1	1	-2174	\N	C	2019-12-20 22:13:53.799521+00	330
2173	4	-45255	Polerad	\N	1	1	-2173	\N	C	2019-12-20 22:13:53.799521+00	331
2172	1	-45254	nej	\N	1	1	-2172	\N	C	2019-12-20 22:13:53.799521+00	332
2171	4	-45254	Rabbad	\N	1	1	-2171	\N	C	2019-12-20 22:13:53.799521+00	333
2170	1	-45253	nej	\N	1	1	-2170	\N	C	2019-12-20 22:13:53.799521+00	334
2169	4	-45253	Rabbad	\N	1	1	-2169	\N	C	2019-12-20 22:13:53.799521+00	335
2168	1	-45252	nej	\N	1	1	-2168	\N	C	2019-12-20 22:13:53.799521+00	336
2167	4	-45252	glättad	\N	1	1	-2167	\N	C	2019-12-20 22:13:53.799521+00	337
2166	1	-45251	nej	\N	1	1	-2166	\N	C	2019-12-20 22:13:53.799521+00	338
2165	4	-45251	Rabbad	\N	1	1	-2165	\N	C	2019-12-20 22:13:53.799521+00	339
2164	1	-45250	nej	\N	1	1	-2164	\N	C	2019-12-20 22:13:53.799521+00	340
2163	4	-45250	glättad	\N	1	1	-2163	\N	C	2019-12-20 22:13:53.799521+00	341
2162	1	-45249	nej	\N	1	1	-2162	\N	C	2019-12-20 22:13:53.799521+00	342
2161	4	-45249	Rabbad	\N	1	1	-2161	\N	C	2019-12-20 22:13:53.799521+00	343
2160	1	-45248	nej	\N	1	1	-2160	\N	C	2019-12-20 22:13:53.799521+00	344
2159	4	-45248	Rabbad	\N	1	1	-2159	\N	C	2019-12-20 22:13:53.799521+00	345
2158	1	-45247	nej	\N	1	1	-2158	\N	C	2019-12-20 22:13:53.799521+00	346
2157	4	-45247	Rabbad	\N	1	1	-2157	\N	C	2019-12-20 22:13:53.799521+00	347
2156	1	-45246	nej	\N	1	1	-2156	\N	C	2019-12-20 22:13:53.799521+00	348
2155	4	-45246	Rabbad	\N	1	1	-2155	\N	C	2019-12-20 22:13:53.799521+00	349
2154	1	-45245	nej	\N	1	1	-2154	\N	C	2019-12-20 22:13:53.799521+00	350
2153	4	-45245	Rabbad	\N	1	1	-2153	\N	C	2019-12-20 22:13:53.799521+00	351
2152	1	-45244	nej	\N	1	1	-2152	\N	C	2019-12-20 22:13:53.799521+00	352
2151	4	-45244	Rabbad	\N	1	1	-2151	\N	C	2019-12-20 22:13:53.799521+00	353
2150	1	-45243	nej	\N	1	1	-2150	\N	C	2019-12-20 22:13:53.799521+00	354
2149	4	-45243	Rabbad	\N	1	1	-2149	\N	C	2019-12-20 22:13:53.799521+00	355
2148	1	-45242	nej	\N	1	1	-2148	\N	C	2019-12-20 22:13:53.799521+00	356
2147	4	-45242	Rabbad	\N	1	1	-2147	\N	C	2019-12-20 22:13:53.799521+00	357
2146	1	-45241	nej	\N	1	1	-2146	\N	C	2019-12-20 22:13:53.799521+00	358
2145	4	-45241	Rabbad	\N	1	1	-2145	\N	C	2019-12-20 22:13:53.799521+00	359
2144	1	-45240	nej	\N	1	1	-2144	\N	C	2019-12-20 22:13:53.799521+00	360
2143	4	-45240	Polerad	\N	1	1	-2143	\N	C	2019-12-20 22:13:53.799521+00	361
2142	1	-45239	nej	\N	1	1	-2142	\N	C	2019-12-20 22:13:53.799521+00	362
2141	4	-45239	Rabbad	\N	1	1	-2141	\N	C	2019-12-20 22:13:53.799521+00	363
2140	1	-45238	nej	\N	1	1	-2140	\N	C	2019-12-20 22:13:53.799521+00	364
2139	4	-45238	glättad	\N	1	1	-2139	\N	C	2019-12-20 22:13:53.799521+00	365
2138	1	-45237	nej	\N	1	1	-2138	\N	C	2019-12-20 22:13:53.799521+00	366
2137	4	-45237	Polerad	\N	1	1	-2137	\N	C	2019-12-20 22:13:53.799521+00	367
2136	1	-45236	nej	\N	1	1	-2136	\N	C	2019-12-20 22:13:53.799521+00	368
2135	4	-45236	Rabbad	\N	1	1	-2135	\N	C	2019-12-20 22:13:53.799521+00	369
2134	1	-45235	nej	\N	1	1	-2134	\N	C	2019-12-20 22:13:53.799521+00	370
2133	4	-45235	Rabbad	\N	1	1	-2133	\N	C	2019-12-20 22:13:53.799521+00	371
2132	1	-45234	nej	\N	1	1	-2132	\N	C	2019-12-20 22:13:53.799521+00	372
2131	4	-45234	glättad	\N	1	1	-2131	\N	C	2019-12-20 22:13:53.799521+00	373
2130	1	-45233	nej	\N	1	1	-2130	\N	C	2019-12-20 22:13:53.799521+00	374
2129	4	-45233	Polerad	\N	1	1	-2129	\N	C	2019-12-20 22:13:53.799521+00	375
2128	1	-45232	nej	\N	1	1	-2128	\N	C	2019-12-20 22:13:53.799521+00	376
2127	4	-45232	Polerad	\N	1	1	-2127	\N	C	2019-12-20 22:13:53.799521+00	377
2126	1	-45231	nej	\N	1	1	-2126	\N	C	2019-12-20 22:13:53.799521+00	378
2125	4	-45231	Rabbad	\N	1	1	-2125	\N	C	2019-12-20 22:13:53.799521+00	379
2124	1	-45230	nej	\N	1	1	-2124	\N	C	2019-12-20 22:13:53.799521+00	380
2123	4	-45230	Rabbad	\N	1	1	-2123	\N	C	2019-12-20 22:13:53.799521+00	381
2122	1	-45226	nej	\N	1	1	-2122	\N	C	2019-12-20 22:13:53.799521+00	382
2121	4	-45226	Rabbad	\N	1	1	-2121	\N	C	2019-12-20 22:13:53.799521+00	383
2120	1	-45225	Otterböte	\N	1	1	-2120	\N	C	2019-12-20 22:13:53.799521+00	384
2119	4	-45225	Rabbad	\N	1	1	-2119	\N	C	2019-12-20 22:13:53.799521+00	385
2118	1	-45224	nej	\N	1	1	-2118	\N	C	2019-12-20 22:13:53.799521+00	386
2117	4	-45224	Rabbad	\N	1	1	-2117	\N	C	2019-12-20 22:13:53.799521+00	387
2116	1	-45223	Otterböte	\N	1	1	-2116	\N	C	2019-12-20 22:13:53.799521+00	388
2115	4	-45223	Rabbad	\N	1	1	-2115	\N	C	2019-12-20 22:13:53.799521+00	389
2114	1	-45222	nej	\N	1	1	-2114	\N	C	2019-12-20 22:13:53.799521+00	390
2113	4	-45222	glättad	\N	1	1	-2113	\N	C	2019-12-20 22:13:53.799521+00	391
2112	1	-45221	dekor	\N	1	1	-2112	\N	C	2019-12-20 22:13:53.799521+00	392
2111	4	-45221	glättad	\N	1	1	-2111	\N	C	2019-12-20 22:13:53.799521+00	393
2110	1	-45220	Dekor	\N	1	1	-2110	\N	C	2019-12-20 22:13:53.799521+00	394
2109	4	-45220	glättad	\N	1	1	-2109	\N	C	2019-12-20 22:13:53.799521+00	395
2108	1	-45219	Dekor	\N	1	1	-2108	\N	C	2019-12-20 22:13:53.799521+00	396
2107	4	-45219	glättad	\N	1	1	-2107	\N	C	2019-12-20 22:13:53.799521+00	397
2106	1	-45218	Dekor	\N	1	1	-2106	\N	C	2019-12-20 22:13:53.799521+00	398
2105	4	-45218	glättad	\N	1	1	-2105	\N	C	2019-12-20 22:13:53.799521+00	399
2104	1	-45217	Textil	\N	1	1	-2104	\N	C	2019-12-20 22:13:53.799521+00	400
2103	4	-45217	Textil	\N	1	1	-2103	\N	C	2019-12-20 22:13:53.799521+00	401
2102	1	-45216	Textil	\N	1	1	-2102	\N	C	2019-12-20 22:13:53.799521+00	402
2101	4	-45216	Textil	\N	1	1	-2101	\N	C	2019-12-20 22:13:53.799521+00	403
2100	1	-45215	nej	\N	1	1	-2100	\N	C	2019-12-20 22:13:53.799521+00	404
2099	4	-45215	Strierad/strimmig	\N	1	1	-2099	\N	C	2019-12-20 22:13:53.799521+00	405
2098	1	-45214	Dekor	\N	1	1	-2098	\N	C	2019-12-20 22:13:53.799521+00	406
2097	2	-45214	Mynning	\N	1	1	-2097	\N	C	2019-12-20 22:13:53.799521+00	407
2096	1	-45213	Dekor	\N	1	1	-2096	\N	C	2019-12-20 22:13:53.799521+00	408
2095	2	-45213	Mynning	\N	1	1	-2095	\N	C	2019-12-20 22:13:53.799521+00	409
2094	1	-45212	Dekor	\N	1	1	-2094	\N	C	2019-12-20 22:13:53.799521+00	410
2093	2	-45212	buk	\N	1	1	-2093	\N	C	2019-12-20 22:13:53.799521+00	411
2092	1	-45211	Dekor	\N	1	1	-2092	\N	C	2019-12-20 22:13:53.799521+00	412
2091	2	-45211	buk	\N	1	1	-2091	\N	C	2019-12-20 22:13:53.799521+00	413
2090	1	-45210	Dekor	\N	1	1	-2090	\N	C	2019-12-20 22:13:53.799521+00	414
2089	2	-45210	buk	\N	1	1	-2089	\N	C	2019-12-20 22:13:53.799521+00	415
2088	1	-45209	Dekor	\N	1	1	-2088	\N	C	2019-12-20 22:13:53.799521+00	416
2087	2	-45209	Mynning	\N	1	1	-2087	\N	C	2019-12-20 22:13:53.799521+00	417
2086	1	-45208	Dekor	\N	1	1	-2086	\N	C	2019-12-20 22:13:53.799521+00	418
2085	2	-45208	buk	\N	1	1	-2085	\N	C	2019-12-20 22:13:53.799521+00	419
2084	1	-45207	Dekor	\N	1	1	-2084	\N	C	2019-12-20 22:13:53.799521+00	420
2083	2	-45207	buk	\N	1	1	-2083	\N	C	2019-12-20 22:13:53.799521+00	421
2082	1	-45206	Dekor	\N	1	1	-2082	\N	C	2019-12-20 22:13:53.799521+00	422
2081	2	-45206	buk	\N	1	1	-2081	\N	C	2019-12-20 22:13:53.799521+00	423
2080	1	-45205	Dekor	\N	1	1	-2080	\N	C	2019-12-20 22:13:53.799521+00	424
2079	2	-45205	buk	\N	1	1	-2079	\N	C	2019-12-20 22:13:53.799521+00	425
2078	1	-45204	Dekor	\N	1	1	-2078	\N	C	2019-12-20 22:13:53.799521+00	426
2077	2	-45204	buk	\N	1	1	-2077	\N	C	2019-12-20 22:13:53.799521+00	427
2076	1	-45203	Dekor	\N	1	1	-2076	\N	C	2019-12-20 22:13:53.799521+00	428
2075	2	-45203	buk	\N	1	1	-2075	\N	C	2019-12-20 22:13:53.799521+00	429
2074	1	-44919	Dekor	\N	1	1	-2074	\N	C	2019-12-20 22:13:53.799521+00	430
2073	1	-44918	Dekor	\N	1	1	-2073	\N	C	2019-12-20 22:13:53.799521+00	431
2072	1	-44917	Dekor	\N	1	1	-2072	\N	C	2019-12-20 22:13:53.799521+00	432
2071	1	-44916	Dekor	\N	1	1	-2071	\N	C	2019-12-20 22:13:53.799521+00	433
2070	1	-44915	Dekor	\N	1	1	-2070	\N	C	2019-12-20 22:13:53.799521+00	434
2069	1	-44914	Dekor	\N	1	1	-2069	\N	C	2019-12-20 22:13:53.799521+00	435
2068	1	-44913	Dekor	\N	1	1	-2068	\N	C	2019-12-20 22:13:53.799521+00	436
2067	1	-44912	nej	\N	1	1	-2067	\N	C	2019-12-20 22:13:53.799521+00	437
2066	1	-44911	Dekor	\N	1	1	-2066	\N	C	2019-12-20 22:13:53.799521+00	438
2065	1	-44910	Dekor	\N	1	1	-2065	\N	C	2019-12-20 22:13:53.799521+00	439
2064	4	-44904	glasyr	\N	1	1	-2064	\N	C	2019-12-20 22:13:53.799521+00	440
2063	4	-44903	glasyr	\N	1	1	-2063	\N	C	2019-12-20 22:13:53.799521+00	441
2062	4	-44902	glasyr	\N	1	1	-2062	\N	C	2019-12-20 22:13:53.799521+00	442
2061	4	-44896	glasyr	\N	1	1	-2061	\N	C	2019-12-20 22:13:53.799521+00	443
2060	4	-44894	glasyr	\N	1	1	-2060	\N	C	2019-12-20 22:13:53.799521+00	444
2059	4	-44893	glasyr	\N	1	1	-2059	\N	C	2019-12-20 22:13:53.799521+00	445
2058	4	-44892	glasyr	\N	1	1	-2058	\N	C	2019-12-20 22:13:53.799521+00	446
2057	4	-44888	glasyr	\N	1	1	-2057	\N	C	2019-12-20 22:13:53.799521+00	447
2056	4	-44887	glasyr	\N	1	1	-2056	\N	C	2019-12-20 22:13:53.799521+00	448
2055	4	-44886	glasyr	\N	1	1	-2055	\N	C	2019-12-20 22:13:53.799521+00	449
2054	4	-44882	glasyr	\N	1	1	-2054	\N	C	2019-12-20 22:13:53.799521+00	450
2053	4	-44881	glasyr	\N	1	1	-2053	\N	C	2019-12-20 22:13:53.799521+00	451
2052	4	-44879	glasyr	\N	1	1	-2052	\N	C	2019-12-20 22:13:53.799521+00	452
2051	4	-44874	glasyr	\N	1	1	-2051	\N	C	2019-12-20 22:13:53.799521+00	453
2050	4	-44873	glasyr	\N	1	1	-2050	\N	C	2019-12-20 22:13:53.799521+00	454
2049	4	-44871	glasyr	\N	1	1	-2049	\N	C	2019-12-20 22:13:53.799521+00	455
2048	2	-44868	skuldra	\N	1	1	-2048	\N	C	2019-12-20 22:13:53.799521+00	456
2047	2	-44867	skuldra	\N	1	1	-2047	\N	C	2019-12-20 22:13:53.799521+00	457
2046	2	-44866	skuldra	\N	1	1	-2046	\N	C	2019-12-20 22:13:53.799521+00	458
2045	2	-44865	odef	\N	1	1	-2045	\N	C	2019-12-20 22:13:53.799521+00	459
2044	2	-44864	skuldra	\N	1	1	-2044	\N	C	2019-12-20 22:13:53.799521+00	460
2043	2	-44863	skuldra	\N	1	1	-2043	\N	C	2019-12-20 22:13:53.799521+00	461
2042	2	-44862	odef	\N	1	1	-2042	\N	C	2019-12-20 22:13:53.799521+00	462
2041	2	-44861	skuldra	\N	1	1	-2041	\N	C	2019-12-20 22:13:53.799521+00	463
2040	2	-44860	skuldra	\N	1	1	-2040	\N	C	2019-12-20 22:13:53.799521+00	464
2039	2	-44859	odef	\N	1	1	-2039	\N	C	2019-12-20 22:13:53.799521+00	465
2038	2	-44858	odef	\N	1	1	-2038	\N	C	2019-12-20 22:13:53.799521+00	466
2037	2	-44857	odef	\N	1	1	-2037	\N	C	2019-12-20 22:13:53.799521+00	467
2036	2	-44856	skuldra	\N	1	1	-2036	\N	C	2019-12-20 22:13:53.799521+00	468
2035	2	-44855	odef	\N	1	1	-2035	\N	C	2019-12-20 22:13:53.799521+00	469
2034	2	-44854	odef	\N	1	1	-2034	\N	C	2019-12-20 22:13:53.799521+00	470
2033	2	-44853	odef	\N	1	1	-2033	\N	C	2019-12-20 22:13:53.799521+00	471
2032	2	-44852	odef	\N	1	1	-2032	\N	C	2019-12-20 22:13:53.799521+00	472
2031	2	-44851	skuldra	\N	1	1	-2031	\N	C	2019-12-20 22:13:53.799521+00	473
2030	1	-44804	nej	\N	1	1	-2030	\N	C	2019-12-20 22:13:53.799521+00	474
2029	4	-44804	Rabbad	\N	1	1	-2029	\N	C	2019-12-20 22:13:53.799521+00	475
2028	1	-44803	nej	\N	1	1	-2028	\N	C	2019-12-20 22:13:53.799521+00	476
2027	4	-44803	Rabbad	\N	1	1	-2027	\N	C	2019-12-20 22:13:53.799521+00	477
2026	1	-44802	nej	\N	1	1	-2026	\N	C	2019-12-20 22:13:53.799521+00	478
2025	4	-44802	Polerad	\N	1	1	-2025	\N	C	2019-12-20 22:13:53.799521+00	479
2024	1	-44801	nej	\N	1	1	-2024	\N	C	2019-12-20 22:13:53.799521+00	480
2023	4	-44801	Strierad/strimmig	\N	1	1	-2023	\N	C	2019-12-20 22:13:53.799521+00	481
2022	1	-44800	nej	\N	1	1	-2022	\N	C	2019-12-20 22:13:53.799521+00	482
2021	4	-44800	glättad	\N	1	1	-2021	\N	C	2019-12-20 22:13:53.799521+00	483
2020	1	-44799	Dekor	\N	1	1	-2020	\N	C	2019-12-20 22:13:53.799521+00	484
2019	4	-44799	Strierad/strimmig	\N	1	1	-2019	\N	C	2019-12-20 22:13:53.799521+00	485
2018	1	-44798	nej	\N	1	1	-2018	\N	C	2019-12-20 22:13:53.799521+00	486
2017	4	-44798	glättad	\N	1	1	-2017	\N	C	2019-12-20 22:13:53.799521+00	487
2016	1	-44797	nej	\N	1	1	-2016	\N	C	2019-12-20 22:13:53.799521+00	488
2015	4	-44797	glättad	\N	1	1	-2015	\N	C	2019-12-20 22:13:53.799521+00	489
2014	1	-44796	nej	\N	1	1	-2014	\N	C	2019-12-20 22:13:53.799521+00	490
2013	4	-44796	glättad	\N	1	1	-2013	\N	C	2019-12-20 22:13:53.799521+00	491
2012	1	-44795	nej	\N	1	1	-2012	\N	C	2019-12-20 22:13:53.799521+00	492
2011	4	-44795	Avstruken	\N	1	1	-2011	\N	C	2019-12-20 22:13:53.799521+00	493
2010	1	-44794	nej	\N	1	1	-2010	\N	C	2019-12-20 22:13:53.799521+00	494
2009	4	-44794	Avstruken	\N	1	1	-2009	\N	C	2019-12-20 22:13:53.799521+00	495
2008	1	-44793	nej	\N	1	1	-2008	\N	C	2019-12-20 22:13:53.799521+00	496
2007	4	-44793	Rabbad	\N	1	1	-2007	\N	C	2019-12-20 22:13:53.799521+00	497
2006	1	-44792	nej	\N	1	1	-2006	\N	C	2019-12-20 22:13:53.799521+00	498
2005	4	-44792	Rabbad	\N	1	1	-2005	\N	C	2019-12-20 22:13:53.799521+00	499
2004	1	-44791	dekor	\N	1	1	-2004	\N	C	2019-12-20 22:13:53.799521+00	500
2003	4	-44791	Polerad	\N	1	1	-2003	\N	C	2019-12-20 22:13:53.799521+00	501
2002	1	-44790	dekor	\N	1	1	-2002	\N	C	2019-12-20 22:13:53.799521+00	502
2001	4	-44790	Avstruken	\N	1	1	-2001	\N	C	2019-12-20 22:13:53.799521+00	503
2000	1	-44789	nej	\N	1	1	-2000	\N	C	2019-12-20 22:13:53.799521+00	504
1999	4	-44789	Slammad	\N	1	1	-1999	\N	C	2019-12-20 22:13:53.799521+00	505
1998	1	-44788	nej	\N	1	1	-1998	\N	C	2019-12-20 22:13:53.799521+00	506
1997	4	-44788	Slammad	\N	1	1	-1997	\N	C	2019-12-20 22:13:53.799521+00	507
1996	1	-44787	dekor	\N	1	1	-1996	\N	C	2019-12-20 22:13:53.799521+00	508
1995	4	-44787	glättad	\N	1	1	-1995	\N	C	2019-12-20 22:13:53.799521+00	509
1994	1	-44786	nej	\N	1	1	-1994	\N	C	2019-12-20 22:13:53.799521+00	510
1993	4	-44786	Avstruken	\N	1	1	-1993	\N	C	2019-12-20 22:13:53.799521+00	511
1992	1	-44785	nej	\N	1	1	-1992	\N	C	2019-12-20 22:13:53.799521+00	512
1991	4	-44785	Rabbad	\N	1	1	-1991	\N	C	2019-12-20 22:13:53.799521+00	513
1990	1	-44784	nej	\N	1	1	-1990	\N	C	2019-12-20 22:13:53.799521+00	514
1989	4	-44784	glättad	\N	1	1	-1989	\N	C	2019-12-20 22:13:53.799521+00	515
1988	1	-44783	nej	\N	1	1	-1988	\N	C	2019-12-20 22:13:53.799521+00	516
1987	4	-44783	vittrad	\N	1	1	-1987	\N	C	2019-12-20 22:13:53.799521+00	517
1986	1	-44782	nej	\N	1	1	-1986	\N	C	2019-12-20 22:13:53.799521+00	518
1985	4	-44782	glättad	\N	1	1	-1985	\N	C	2019-12-20 22:13:53.799521+00	519
1984	1	-44781	nej	\N	1	1	-1984	\N	C	2019-12-20 22:13:53.799521+00	520
1983	4	-44781	vittrad	\N	1	1	-1983	\N	C	2019-12-20 22:13:53.799521+00	521
1982	1	-44780	dekor	\N	1	1	-1982	\N	C	2019-12-20 22:13:53.799521+00	522
1981	4	-44780	Polerad	\N	1	1	-1981	\N	C	2019-12-20 22:13:53.799521+00	523
1980	1	-44779	dekor	\N	1	1	-1980	\N	C	2019-12-20 22:13:53.799521+00	524
1979	4	-44779	Polerad	\N	1	1	-1979	\N	C	2019-12-20 22:13:53.799521+00	525
1978	1	-44778	nej	\N	1	1	-1978	\N	C	2019-12-20 22:13:53.799521+00	526
1977	4	-44778	glättad	\N	1	1	-1977	\N	C	2019-12-20 22:13:53.799521+00	527
1976	1	-44777	dekor	\N	1	1	-1976	\N	C	2019-12-20 22:13:53.799521+00	528
1975	4	-44777	Polerad	\N	1	1	-1975	\N	C	2019-12-20 22:13:53.799521+00	529
1974	1	-44776	nej	\N	1	1	-1974	\N	C	2019-12-20 22:13:53.799521+00	530
1973	4	-44776	glättad	\N	1	1	-1973	\N	C	2019-12-20 22:13:53.799521+00	531
1972	1	-44775	Dekor	\N	1	1	-1972	\N	C	2019-12-20 22:13:53.799521+00	532
1971	2	-44775	buk	\N	1	1	-1971	\N	C	2019-12-20 22:13:53.799521+00	533
1970	1	-44774	Dekor	\N	1	1	-1970	\N	C	2019-12-20 22:13:53.799521+00	534
1969	2	-44774	Mynning	\N	1	1	-1969	\N	C	2019-12-20 22:13:53.799521+00	535
1968	1	-44773	Dekor	\N	1	1	-1968	\N	C	2019-12-20 22:13:53.799521+00	536
1967	2	-44773	buk	\N	1	1	-1967	\N	C	2019-12-20 22:13:53.799521+00	537
1966	1	-44772	Dekor	\N	1	1	-1966	\N	C	2019-12-20 22:13:53.799521+00	538
1965	2	-44772	buk	\N	1	1	-1965	\N	C	2019-12-20 22:13:53.799521+00	539
1964	1	-44771	Dekor	\N	1	1	-1964	\N	C	2019-12-20 22:13:53.799521+00	540
1963	2	-44771	Mynning	\N	1	1	-1963	\N	C	2019-12-20 22:13:53.799521+00	541
1962	1	-44770	Dekor	\N	1	1	-1962	\N	C	2019-12-20 22:13:53.799521+00	542
1961	2	-44770	buk	\N	1	1	-1961	\N	C	2019-12-20 22:13:53.799521+00	543
1960	1	-44769	Dekor	\N	1	1	-1960	\N	C	2019-12-20 22:13:53.799521+00	544
1959	2	-44769	buk	\N	1	1	-1959	\N	C	2019-12-20 22:13:53.799521+00	545
1958	1	-44768	Dekor	\N	1	1	-1958	\N	C	2019-12-20 22:13:53.799521+00	546
1957	2	-44768	Mynning	\N	1	1	-1957	\N	C	2019-12-20 22:13:53.799521+00	547
1956	1	-44767	Dekor	\N	1	1	-1956	\N	C	2019-12-20 22:13:53.799521+00	548
1955	1	-44766	Dekor	\N	1	1	-1955	\N	C	2019-12-20 22:13:53.799521+00	549
1954	1	-44765	Dekor	\N	1	1	-1954	\N	C	2019-12-20 22:13:53.799521+00	550
1953	1	-44764	Dekor	\N	1	1	-1953	\N	C	2019-12-20 22:13:53.799521+00	551
1952	1	-44763	Dekor	\N	1	1	-1952	\N	C	2019-12-20 22:13:53.799521+00	552
1951	1	-44762	Dekor	\N	1	1	-1951	\N	C	2019-12-20 22:13:53.799521+00	553
1950	1	-44761	nej	\N	1	1	-1950	\N	C	2019-12-20 22:13:53.799521+00	554
1949	1	-44760	Dekor	\N	1	1	-1949	\N	C	2019-12-20 22:13:53.799521+00	555
1948	1	-44759	Dekor	\N	1	1	-1948	\N	C	2019-12-20 22:13:53.799521+00	556
1947	1	-44758	Dekor	\N	1	1	-1947	\N	C	2019-12-20 22:13:53.799521+00	557
1946	1	-44747	omskiktad	\N	1	1	-1946	\N	C	2019-12-20 22:13:53.799521+00	558
1945	1	-44746	omskiktad	\N	1	1	-1945	\N	C	2019-12-20 22:13:53.799521+00	559
1944	1	-44745	omskiktad	\N	1	1	-1944	\N	C	2019-12-20 22:13:53.799521+00	560
1943	1	-44744	omskiktad	\N	1	1	-1943	\N	C	2019-12-20 22:13:53.799521+00	561
1942	1	-44743	omskiktad	\N	1	1	-1942	\N	C	2019-12-20 22:13:53.799521+00	562
1941	1	-44742	omskiktad	\N	1	1	-1941	\N	C	2019-12-20 22:13:53.799521+00	563
1940	1	-44741	omskiktad	\N	1	1	-1940	\N	C	2019-12-20 22:13:53.799521+00	564
1939	1	-44740	omskiktad	\N	1	1	-1939	\N	C	2019-12-20 22:13:53.799521+00	565
1938	1	-44739	omskiktad	\N	1	1	-1938	\N	C	2019-12-20 22:13:53.799521+00	566
1937	1	-44738	nej	\N	1	1	-1937	\N	C	2019-12-20 22:13:53.799521+00	567
1936	1	-44737	Dekor	\N	1	1	-1936	\N	C	2019-12-20 22:13:53.799521+00	568
1935	1	-44736	Dekor	\N	1	1	-1935	\N	C	2019-12-20 22:13:53.799521+00	569
1934	1	-44735	bottenmärke	\N	1	1	-1934	\N	C	2019-12-20 22:13:53.799521+00	570
1933	2	-44735	Botten	\N	1	1	-1933	\N	C	2019-12-20 22:13:53.799521+00	571
1932	1	-44734	bottenmärke	\N	1	1	-1932	\N	C	2019-12-20 22:13:53.799521+00	572
1931	2	-44734	Botten	\N	1	1	-1931	\N	C	2019-12-20 22:13:53.799521+00	573
1930	1	-44696	nej	\N	1	1	-1930	\N	C	2019-12-20 22:13:53.799521+00	574
1929	4	-44696	Strierad/strimmig	\N	1	1	-1929	\N	C	2019-12-20 22:13:53.799521+00	575
1928	1	-44695	nej	\N	1	1	-1928	\N	C	2019-12-20 22:13:53.799521+00	576
1927	4	-44695	Polerad	\N	1	1	-1927	\N	C	2019-12-20 22:13:53.799521+00	577
1926	1	-44694	nej	\N	1	1	-1926	\N	C	2019-12-20 22:13:53.799521+00	578
1925	4	-44694	Strierad/strimmig	\N	1	1	-1925	\N	C	2019-12-20 22:13:53.799521+00	579
1924	1	-44693	nej	\N	1	1	-1924	\N	C	2019-12-20 22:13:53.799521+00	580
1923	4	-44693	Rabbad	\N	1	1	-1923	\N	C	2019-12-20 22:13:53.799521+00	581
1922	1	-44692	Dekor	\N	1	1	-1922	\N	C	2019-12-20 22:13:53.799521+00	582
1921	4	-44692	glättad	\N	1	1	-1921	\N	C	2019-12-20 22:13:53.799521+00	583
1920	1	-44691	nej	\N	1	1	-1920	\N	C	2019-12-20 22:13:53.799521+00	584
1919	4	-44691	glättad	\N	1	1	-1919	\N	C	2019-12-20 22:13:53.799521+00	585
1918	1	-44690	Textil	\N	1	1	-1918	\N	C	2019-12-20 22:13:53.799521+00	586
1917	4	-44690	Textil	\N	1	1	-1917	\N	C	2019-12-20 22:13:53.799521+00	587
1916	1	-44689	nej	\N	1	1	-1916	\N	C	2019-12-20 22:13:53.799521+00	588
1915	4	-44689	Avstruken	\N	1	1	-1915	\N	C	2019-12-20 22:13:53.799521+00	589
1914	1	-44688	dekor	\N	1	1	-1914	\N	C	2019-12-20 22:13:53.799521+00	590
1913	4	-44688	glättad	\N	1	1	-1913	\N	C	2019-12-20 22:13:53.799521+00	591
1912	1	-44687	Ränder i strimmigheten	\N	1	1	-1912	\N	C	2019-12-20 22:13:53.799521+00	592
1911	4	-44687	Strierad/strimmig	\N	1	1	-1911	\N	C	2019-12-20 22:13:53.799521+00	593
1910	1	-44686	nej	\N	1	1	-1910	\N	C	2019-12-20 22:13:53.799521+00	594
1909	4	-44686	glättad	\N	1	1	-1909	\N	C	2019-12-20 22:13:53.799521+00	595
1908	1	-44685	Dekor	\N	1	1	-1908	\N	C	2019-12-20 22:13:53.799521+00	596
1907	1	-44684	Dekor	\N	1	1	-1907	\N	C	2019-12-20 22:13:53.799521+00	597
1906	1	-44683	Dekor	\N	1	1	-1906	\N	C	2019-12-20 22:13:53.799521+00	598
1905	1	-44638	nej	\N	1	1	-1905	\N	C	2019-12-20 22:13:53.799521+00	599
1904	1	-44637	nej	\N	1	1	-1904	\N	C	2019-12-20 22:13:53.799521+00	600
1903	1	-44636	Dekor	\N	1	1	-1903	\N	C	2019-12-20 22:13:53.799521+00	601
1902	1	-44635	nej	\N	1	1	-1902	\N	C	2019-12-20 22:13:53.799521+00	602
1901	1	-44634	nej	\N	1	1	-1901	\N	C	2019-12-20 22:13:53.799521+00	603
1900	1	-44633	nej	\N	1	1	-1900	\N	C	2019-12-20 22:13:53.799521+00	604
1899	1	-44632	Perforerat kärl	\N	1	1	-1899	\N	C	2019-12-20 22:13:53.799521+00	605
1898	1	-44631	Perforerat kärl	\N	1	1	-1898	\N	C	2019-12-20 22:13:53.799521+00	606
1897	1	-44630	nej	\N	1	1	-1897	\N	C	2019-12-20 22:13:53.799521+00	607
1896	1	-44629	nej	\N	1	1	-1896	\N	C	2019-12-20 22:13:53.799521+00	608
1895	1	-44628	nej	\N	1	1	-1895	\N	C	2019-12-20 22:13:53.799521+00	609
1894	1	-44627	nej	\N	1	1	-1894	\N	C	2019-12-20 22:13:53.799521+00	610
1893	1	-44626	nej	\N	1	1	-1893	\N	C	2019-12-20 22:13:53.799521+00	611
1892	2	-44600	Tegel	\N	1	1	-1892	\N	C	2019-12-20 22:13:53.799521+00	612
1891	2	-44599	Tegel	\N	1	1	-1891	\N	C	2019-12-20 22:13:53.799521+00	613
1890	2	-44598	Tegel	\N	1	1	-1890	\N	C	2019-12-20 22:13:53.799521+00	614
1889	2	-44597	Bränd lera. Raseringslager	\N	1	1	-1889	\N	C	2019-12-20 22:13:53.799521+00	615
1888	2	-44596	Bränd lera. Raseringslager	\N	1	1	-1888	\N	C	2019-12-20 22:13:53.799521+00	616
1887	2	-44595	Spis	\N	1	1	-1887	\N	C	2019-12-20 22:13:53.799521+00	617
1886	2	-44594	Spis	\N	1	1	-1886	\N	C	2019-12-20 22:13:53.799521+00	618
1885	2	-44593	Spis	\N	1	1	-1885	\N	C	2019-12-20 22:13:53.799521+00	619
1884	2	-44592	Tegel-Droppränna	\N	1	1	-1884	\N	C	2019-12-20 22:13:53.799521+00	620
1883	2	-44591	Tegel	\N	1	1	-1883	\N	C	2019-12-20 22:13:53.799521+00	621
1882	2	-44590	Tegel	\N	1	1	-1882	\N	C	2019-12-20 22:13:53.799521+00	622
1881	2	-44589	Tegel	\N	1	1	-1881	\N	C	2019-12-20 22:13:53.799521+00	623
1880	4	-44588	obehandlad	\N	1	1	-1880	\N	C	2019-12-20 22:13:53.799521+00	624
1879	4	-44587	glättad	\N	1	1	-1879	\N	C	2019-12-20 22:13:53.799521+00	625
1878	4	-44586	vittrad	\N	1	1	-1878	\N	C	2019-12-20 22:13:53.799521+00	626
1877	4	-44585	glättad	\N	1	1	-1877	\N	C	2019-12-20 22:13:53.799521+00	627
1876	4	-44584	obehandlad	\N	1	1	-1876	\N	C	2019-12-20 22:13:53.799521+00	628
1875	4	-44583	vittrad	\N	1	1	-1875	\N	C	2019-12-20 22:13:53.799521+00	629
1874	4	-44582	vittrad	\N	1	1	-1874	\N	C	2019-12-20 22:13:53.799521+00	630
1873	4	-44581	glättad	\N	1	1	-1873	\N	C	2019-12-20 22:13:53.799521+00	631
1872	4	-44580	Polerad	\N	1	1	-1872	\N	C	2019-12-20 22:13:53.799521+00	632
1871	4	-44579	glättad	\N	1	1	-1871	\N	C	2019-12-20 22:13:53.799521+00	633
1870	4	-44578	obehandlad	\N	1	1	-1870	\N	C	2019-12-20 22:13:53.799521+00	634
1869	4	-44576	obehandlad	\N	1	1	-1869	\N	C	2019-12-20 22:13:53.799521+00	635
1868	4	-44575	obehandlad	\N	1	1	-1868	\N	C	2019-12-20 22:13:53.799521+00	636
1867	4	-44574	obehandlad	\N	1	1	-1867	\N	C	2019-12-20 22:13:53.799521+00	637
1866	4	-44565	Rabbad	\N	1	1	-1866	\N	C	2019-12-20 22:13:53.799521+00	638
1865	4	-44564	Rabbad	\N	1	1	-1865	\N	C	2019-12-20 22:13:53.799521+00	639
1864	1	-44563	hål	\N	1	1	-1864	\N	C	2019-12-20 22:13:53.799521+00	640
1863	1	-44562	hål	\N	1	1	-1863	\N	C	2019-12-20 22:13:53.799521+00	641
1862	4	-44560	Rabbad	\N	1	1	-1862	\N	C	2019-12-20 22:13:53.799521+00	642
1861	4	-44559	Rabbad	\N	1	1	-1861	\N	C	2019-12-20 22:13:53.799521+00	643
1860	4	-44558	Rabbad	\N	1	1	-1860	\N	C	2019-12-20 22:13:53.799521+00	644
1859	4	-44557	Rabbad	\N	1	1	-1859	\N	C	2019-12-20 22:13:53.799521+00	645
1858	4	-44556	Rabbad	\N	1	1	-1858	\N	C	2019-12-20 22:13:53.799521+00	646
1857	4	-44555	Rabbad	\N	1	1	-1857	\N	C	2019-12-20 22:13:53.799521+00	647
1856	4	-44554	Rabbad	\N	1	1	-1856	\N	C	2019-12-20 22:13:53.799521+00	648
1855	4	-44553	Rabbad	\N	1	1	-1855	\N	C	2019-12-20 22:13:53.799521+00	649
1854	4	-44552	Rabbad	\N	1	1	-1854	\N	C	2019-12-20 22:13:53.799521+00	650
1853	4	-44551	Rabbad	\N	1	1	-1853	\N	C	2019-12-20 22:13:53.799521+00	651
1852	4	-44550	Rabbad	\N	1	1	-1852	\N	C	2019-12-20 22:13:53.799521+00	652
1851	4	-44549	Rabbad	\N	1	1	-1851	\N	C	2019-12-20 22:13:53.799521+00	653
1850	1	-44548	vulst	\N	1	1	-1850	\N	C	2019-12-20 22:13:53.799521+00	654
1849	4	-44548	Rabbad	\N	1	1	-1849	\N	C	2019-12-20 22:13:53.799521+00	655
1848	4	-44546	Rabbad	\N	1	1	-1848	\N	C	2019-12-20 22:13:53.799521+00	656
1847	4	-44545	Rabbad	\N	1	1	-1847	\N	C	2019-12-20 22:13:53.799521+00	657
1846	4	-44543	Rabbad	\N	1	1	-1846	\N	C	2019-12-20 22:13:53.799521+00	658
1845	4	-44540	Rabbad	\N	1	1	-1845	\N	C	2019-12-20 22:13:53.799521+00	659
1844	4	-44538	Rabbad	\N	1	1	-1844	\N	C	2019-12-20 22:13:53.799521+00	660
1843	4	-44537	Rabbad	\N	1	1	-1843	\N	C	2019-12-20 22:13:53.799521+00	661
1842	1	-44535	Dekor	\N	1	1	-1842	\N	C	2019-12-20 22:13:53.799521+00	662
1841	1	-44534	nej	\N	1	1	-1841	\N	C	2019-12-20 22:13:53.799521+00	663
1840	1	-44533	Dekor	\N	1	1	-1840	\N	C	2019-12-20 22:13:53.799521+00	664
1839	1	-44532	nej	\N	1	1	-1839	\N	C	2019-12-20 22:13:53.799521+00	665
1838	1	-44531	Dekor	\N	1	1	-1838	\N	C	2019-12-20 22:13:53.799521+00	666
1837	1	-44530	nej	\N	1	1	-1837	\N	C	2019-12-20 22:13:53.799521+00	667
1836	1	-44529	Dekor	\N	1	1	-1836	\N	C	2019-12-20 22:13:53.799521+00	668
1835	1	-44527	nej	\N	1	1	-1835	\N	C	2019-12-20 22:13:53.799521+00	669
1834	1	-44526	Dekor	\N	1	1	-1834	\N	C	2019-12-20 22:13:53.799521+00	670
1833	1	-44478	Öra	\N	1	1	-1833	\N	C	2019-12-20 22:13:53.799521+00	671
1832	4	-44478	glättad	\N	1	1	-1832	\N	C	2019-12-20 22:13:53.799521+00	672
1831	2	-44478	Botten	\N	1	1	-1831	\N	C	2019-12-20 22:13:53.799521+00	673
1830	4	-44477	Rabbad	\N	1	1	-1830	\N	C	2019-12-20 22:13:53.799521+00	674
1829	2	-44477	Hel	\N	1	1	-1829	\N	C	2019-12-20 22:13:53.799521+00	675
1828	4	-44476	glättad	\N	1	1	-1828	\N	C	2019-12-20 22:13:53.799521+00	676
1827	2	-44476	Hel	\N	1	1	-1827	\N	C	2019-12-20 22:13:53.799521+00	677
1826	4	-44475	Rabbad	\N	1	1	-1826	\N	C	2019-12-20 22:13:53.799521+00	678
1825	2	-44475	Hel	\N	1	1	-1825	\N	C	2019-12-20 22:13:53.799521+00	679
1824	4	-44474	glättad	\N	1	1	-1824	\N	C	2019-12-20 22:13:53.799521+00	680
1823	2	-44474	Mynning	\N	1	1	-1823	\N	C	2019-12-20 22:13:53.799521+00	681
1822	4	-44473	glättad	\N	1	1	-1822	\N	C	2019-12-20 22:13:53.799521+00	682
1821	2	-44473	Hel	\N	1	1	-1821	\N	C	2019-12-20 22:13:53.799521+00	683
1820	1	-44472	Knopp	\N	1	1	-1820	\N	C	2019-12-20 22:13:53.799521+00	684
1819	4	-44472	Rabbad	\N	1	1	-1819	\N	C	2019-12-20 22:13:53.799521+00	685
1818	2	-44472	Hel	\N	1	1	-1818	\N	C	2019-12-20 22:13:53.799521+00	686
1817	4	-44471	glättad	\N	1	1	-1817	\N	C	2019-12-20 22:13:53.799521+00	687
1816	2	-44471	Hel	\N	1	1	-1816	\N	C	2019-12-20 22:13:53.799521+00	688
1815	4	-44470	Rabbad	\N	1	1	-1815	\N	C	2019-12-20 22:13:53.799521+00	689
1814	2	-44470	Intakt	\N	1	1	-1814	\N	C	2019-12-20 22:13:53.799521+00	690
1813	4	-44469	Rabbad	\N	1	1	-1813	\N	C	2019-12-20 22:13:53.799521+00	691
1812	2	-44469	Hel	\N	1	1	-1812	\N	C	2019-12-20 22:13:53.799521+00	692
1811	4	-44468	Rabbad	\N	1	1	-1811	\N	C	2019-12-20 22:13:53.799521+00	693
1810	2	-44468	Intakt	\N	1	1	-1810	\N	C	2019-12-20 22:13:53.799521+00	694
1809	4	-44467	glättad	\N	1	1	-1809	\N	C	2019-12-20 22:13:53.799521+00	695
1808	2	-44467	Hel	\N	1	1	-1808	\N	C	2019-12-20 22:13:53.799521+00	696
1807	4	-44466	glättad	\N	1	1	-1807	\N	C	2019-12-20 22:13:53.799521+00	697
1806	2	-44466	Hel	\N	1	1	-1806	\N	C	2019-12-20 22:13:53.799521+00	698
1805	1	-44465	Knopp	\N	1	1	-1805	\N	C	2019-12-20 22:13:53.799521+00	699
1804	4	-44465	Rabbad	\N	1	1	-1804	\N	C	2019-12-20 22:13:53.799521+00	700
1803	2	-44465	Intakt	\N	1	1	-1803	\N	C	2019-12-20 22:13:53.799521+00	701
1802	4	-44464	glättad	\N	1	1	-1802	\N	C	2019-12-20 22:13:53.799521+00	702
1801	2	-44464	Mynning	\N	1	1	-1801	\N	C	2019-12-20 22:13:53.799521+00	703
1800	4	-44463	glättad	\N	1	1	-1800	\N	C	2019-12-20 22:13:53.799521+00	704
1799	2	-44463	Mynning	\N	1	1	-1799	\N	C	2019-12-20 22:13:53.799521+00	705
1798	4	-44462	glättad	\N	1	1	-1798	\N	C	2019-12-20 22:13:53.799521+00	706
1797	2	-44462	Intakt	\N	1	1	-1797	\N	C	2019-12-20 22:13:53.799521+00	707
1796	4	-44461	glättad	\N	1	1	-1796	\N	C	2019-12-20 22:13:53.799521+00	708
1795	2	-44461	Hel	\N	1	1	-1795	\N	C	2019-12-20 22:13:53.799521+00	709
1794	4	-44460	Polerad	\N	1	1	-1794	\N	C	2019-12-20 22:13:53.799521+00	710
1793	2	-44460	Hel	\N	1	1	-1793	\N	C	2019-12-20 22:13:53.799521+00	711
1792	4	-44459	Polerad	\N	1	1	-1792	\N	C	2019-12-20 22:13:53.799521+00	712
1791	2	-44459	Intakt	\N	1	1	-1791	\N	C	2019-12-20 22:13:53.799521+00	713
1790	4	-44458	glättad	\N	1	1	-1790	\N	C	2019-12-20 22:13:53.799521+00	714
1789	2	-44458	Intakt	\N	1	1	-1789	\N	C	2019-12-20 22:13:53.799521+00	715
1788	4	-44457	glättad	\N	1	1	-1788	\N	C	2019-12-20 22:13:53.799521+00	716
1787	2	-44457	Hel	\N	1	1	-1787	\N	C	2019-12-20 22:13:53.799521+00	717
1786	1	-44456	Öra	\N	1	1	-1786	\N	C	2019-12-20 22:13:53.799521+00	718
1785	4	-44456	glättad	\N	1	1	-1785	\N	C	2019-12-20 22:13:53.799521+00	719
1784	2	-44456	Intakt	\N	1	1	-1784	\N	C	2019-12-20 22:13:53.799521+00	720
1783	4	-44455	Polerad	\N	1	1	-1783	\N	C	2019-12-20 22:13:53.799521+00	721
1782	2	-44455	Hel	\N	1	1	-1782	\N	C	2019-12-20 22:13:53.799521+00	722
1781	1	-44454	Knopp	\N	1	1	-1781	\N	C	2019-12-20 22:13:53.799521+00	723
1780	4	-44454	Rabbad	\N	1	1	-1780	\N	C	2019-12-20 22:13:53.799521+00	724
1779	2	-44454	Hel	\N	1	1	-1779	\N	C	2019-12-20 22:13:53.799521+00	725
1778	4	-44453	Rabbad	\N	1	1	-1778	\N	C	2019-12-20 22:13:53.799521+00	726
1777	2	-44453	Hel	\N	1	1	-1777	\N	C	2019-12-20 22:13:53.799521+00	727
1776	2	-44452	Botten	\N	1	1	-1776	\N	C	2019-12-20 22:13:53.799521+00	728
1775	4	-44451	glättad	\N	1	1	-1775	\N	C	2019-12-20 22:13:53.799521+00	729
1774	2	-44451	Hel	\N	1	1	-1774	\N	C	2019-12-20 22:13:53.799521+00	730
1773	4	-44450	Rabbad	\N	1	1	-1773	\N	C	2019-12-20 22:13:53.799521+00	731
1772	2	-44450	Hel	\N	1	1	-1772	\N	C	2019-12-20 22:13:53.799521+00	732
1771	4	-44449	glättad	\N	1	1	-1771	\N	C	2019-12-20 22:13:53.799521+00	733
1770	2	-44449	Botten	\N	1	1	-1770	\N	C	2019-12-20 22:13:53.799521+00	734
1769	4	-44448	Rabbad	\N	1	1	-1769	\N	C	2019-12-20 22:13:53.799521+00	735
1768	2	-44448	Botten	\N	1	1	-1768	\N	C	2019-12-20 22:13:53.799521+00	736
1767	4	-44447	Rabbad	\N	1	1	-1767	\N	C	2019-12-20 22:13:53.799521+00	737
1766	2	-44447	Hel	\N	1	1	-1766	\N	C	2019-12-20 22:13:53.799521+00	738
1765	4	-44446	glättad	\N	1	1	-1765	\N	C	2019-12-20 22:13:53.799521+00	739
1764	2	-44446	Hel	\N	1	1	-1764	\N	C	2019-12-20 22:13:53.799521+00	740
1763	2	-44445	buk	\N	1	1	-1763	\N	C	2019-12-20 22:13:53.799521+00	741
1762	2	-44444	buk	\N	1	1	-1762	\N	C	2019-12-20 22:13:53.799521+00	742
1761	2	-44443	buk	\N	1	1	-1761	\N	C	2019-12-20 22:13:53.799521+00	743
1760	2	-44442	buk	\N	1	1	-1760	\N	C	2019-12-20 22:13:53.799521+00	744
1759	2	-44441	buk	\N	1	1	-1759	\N	C	2019-12-20 22:13:53.799521+00	745
1758	2	-44440	buk	\N	1	1	-1758	\N	C	2019-12-20 22:13:53.799521+00	746
1757	2	-44439	mynning	\N	1	1	-1757	\N	C	2019-12-20 22:13:53.799521+00	747
1756	2	-44438	buk	\N	1	1	-1756	\N	C	2019-12-20 22:13:53.799521+00	748
1755	2	-44437	buk	\N	1	1	-1755	\N	C	2019-12-20 22:13:53.799521+00	749
1754	2	-44436	buk	\N	1	1	-1754	\N	C	2019-12-20 22:13:53.799521+00	750
1753	2	-44435	buk	\N	1	1	-1753	\N	C	2019-12-20 22:13:53.799521+00	751
1752	2	-44434	buk	\N	1	1	-1752	\N	C	2019-12-20 22:13:53.799521+00	752
1751	2	-44433	mynning	\N	1	1	-1751	\N	C	2019-12-20 22:13:53.799521+00	753
1750	2	-44432	buk	\N	1	1	-1750	\N	C	2019-12-20 22:13:53.799521+00	754
1749	2	-44431	hals	\N	1	1	-1749	\N	C	2019-12-20 22:13:53.799521+00	755
1748	2	-44430	buk	\N	1	1	-1748	\N	C	2019-12-20 22:13:53.799521+00	756
1747	2	-44429	buk	\N	1	1	-1747	\N	C	2019-12-20 22:13:53.799521+00	757
1746	1	-44424	nej	\N	1	1	-1746	\N	C	2019-12-20 22:13:53.799521+00	758
1745	1	-44423	nej	\N	1	1	-1745	\N	C	2019-12-20 22:13:53.799521+00	759
1744	4	-44423	Rabbad	\N	1	1	-1744	\N	C	2019-12-20 22:13:53.799521+00	760
1743	1	-44422	nej	\N	1	1	-1743	\N	C	2019-12-20 22:13:53.799521+00	761
1742	1	-44421	nej	\N	1	1	-1742	\N	C	2019-12-20 22:13:53.799521+00	762
1741	1	-44420	nej	\N	1	1	-1741	\N	C	2019-12-20 22:13:53.799521+00	763
1740	4	-44420	Rabbad	\N	1	1	-1740	\N	C	2019-12-20 22:13:53.799521+00	764
1739	1	-44419	nej	\N	1	1	-1739	\N	C	2019-12-20 22:13:53.799521+00	765
1738	4	-44419	Rabbad	\N	1	1	-1738	\N	C	2019-12-20 22:13:53.799521+00	766
1737	1	-44418	nej	\N	1	1	-1737	\N	C	2019-12-20 22:13:53.799521+00	767
1736	4	-44418	Rabbad	\N	1	1	-1736	\N	C	2019-12-20 22:13:53.799521+00	768
1735	1	-44417	nej	\N	1	1	-1735	\N	C	2019-12-20 22:13:53.799521+00	769
1734	4	-44417	Rabbad	\N	1	1	-1734	\N	C	2019-12-20 22:13:53.799521+00	770
1733	1	-44416	nej	\N	1	1	-1733	\N	C	2019-12-20 22:13:53.799521+00	771
1732	4	-44416	Rabbad	\N	1	1	-1732	\N	C	2019-12-20 22:13:53.799521+00	772
1731	1	-44415	nej	\N	1	1	-1731	\N	C	2019-12-20 22:13:53.799521+00	773
1730	4	-44415	Rabbad	\N	1	1	-1730	\N	C	2019-12-20 22:13:53.799521+00	774
1729	1	-44414	nej	\N	1	1	-1729	\N	C	2019-12-20 22:13:53.799521+00	775
1728	4	-44414	Rabbad	\N	1	1	-1728	\N	C	2019-12-20 22:13:53.799521+00	776
1727	4	-44327	Blästermunstycke	\N	1	1	-1727	\N	C	2019-12-20 22:13:53.799521+00	777
1726	4	-44310	Blästermunstycke	\N	1	1	-1726	\N	C	2019-12-20 22:13:53.799521+00	778
1725	2	-44279	Menkendorf	\N	1	1	-1725	\N	C	2019-12-20 22:13:53.799521+00	779
1724	2	-44277	Hängkärl	\N	1	1	-1724	\N	C	2019-12-20 22:13:53.799521+00	780
1723	1	-44273	nej	\N	1	1	-1723	\N	C	2019-12-20 22:13:53.799521+00	781
1722	4	-44273	Rabbad	\N	1	1	-1722	\N	C	2019-12-20 22:13:53.799521+00	782
1721	1	-44272	nej	\N	1	1	-1721	\N	C	2019-12-20 22:13:53.799521+00	783
1720	4	-44272	Rabbad	\N	1	1	-1720	\N	C	2019-12-20 22:13:53.799521+00	784
1719	1	-44271	nej	\N	1	1	-1719	\N	C	2019-12-20 22:13:53.799521+00	785
1718	4	-44271	glättad	\N	1	1	-1718	\N	C	2019-12-20 22:13:53.799521+00	786
1717	1	-44270	nej	\N	1	1	-1717	\N	C	2019-12-20 22:13:53.799521+00	787
1716	4	-44270	glättad	\N	1	1	-1716	\N	C	2019-12-20 22:13:53.799521+00	788
1715	1	-44269	nej	\N	1	1	-1715	\N	C	2019-12-20 22:13:53.799521+00	789
1714	4	-44269	glättad	\N	1	1	-1714	\N	C	2019-12-20 22:13:53.799521+00	790
1713	1	-44268	nej	\N	1	1	-1713	\N	C	2019-12-20 22:13:53.799521+00	791
1712	4	-44268	glättad	\N	1	1	-1712	\N	C	2019-12-20 22:13:53.799521+00	792
1711	1	-44252	dekor	\N	1	1	-1711	\N	C	2019-12-20 22:13:53.799521+00	793
1710	2	-44252	kärlbotten,, idol	\N	1	1	-1710	\N	C	2019-12-20 22:13:53.799521+00	794
1709	1	-44251	nej	\N	1	1	-1709	\N	C	2019-12-20 22:13:53.799521+00	795
1708	4	-44251	odef	\N	1	1	-1708	\N	C	2019-12-20 22:13:53.799521+00	796
1707	2	-44251	lerremsa	\N	1	1	-1707	\N	C	2019-12-20 22:13:53.799521+00	797
1706	1	-44250	nej	\N	1	1	-1706	\N	C	2019-12-20 22:13:53.799521+00	798
1705	4	-44250	Rabbad	\N	1	1	-1705	\N	C	2019-12-20 22:13:53.799521+00	799
1704	2	-44250	kruka	\N	1	1	-1704	\N	C	2019-12-20 22:13:53.799521+00	800
1703	1	-44249	nej	\N	1	1	-1703	\N	C	2019-12-20 22:13:53.799521+00	801
1702	4	-44249	Grov	\N	1	1	-1702	\N	C	2019-12-20 22:13:53.799521+00	802
1701	2	-44249	kokkärl	\N	1	1	-1701	\N	C	2019-12-20 22:13:53.799521+00	803
1700	1	-44248	nej	\N	1	1	-1700	\N	C	2019-12-20 22:13:53.799521+00	804
1699	4	-44248	Grov	\N	1	1	-1699	\N	C	2019-12-20 22:13:53.799521+00	805
1698	2	-44248	skål	\N	1	1	-1698	\N	C	2019-12-20 22:13:53.799521+00	806
1697	1	-44247	nej	\N	1	1	-1697	\N	C	2019-12-20 22:13:53.799521+00	807
1696	4	-44247	Rabbad	\N	1	1	-1696	\N	C	2019-12-20 22:13:53.799521+00	808
1695	2	-44247	skål	\N	1	1	-1695	\N	C	2019-12-20 22:13:53.799521+00	809
1694	1	-44246	nej	\N	1	1	-1694	\N	C	2019-12-20 22:13:53.799521+00	810
1693	4	-44246	odef	\N	1	1	-1693	\N	C	2019-12-20 22:13:53.799521+00	811
1692	2	-44246	profilerat kärl	\N	1	1	-1692	\N	C	2019-12-20 22:13:53.799521+00	812
1691	1	-44245	nej	\N	1	1	-1691	\N	C	2019-12-20 22:13:53.799521+00	813
1690	4	-44245	odef	\N	1	1	-1690	\N	C	2019-12-20 22:13:53.799521+00	814
1689	1	-44244	nej	\N	1	1	-1689	\N	C	2019-12-20 22:13:53.799521+00	815
1688	4	-44244	Rabbad	\N	1	1	-1688	\N	C	2019-12-20 22:13:53.799521+00	816
1687	2	-44244	kruka	\N	1	1	-1687	\N	C	2019-12-20 22:13:53.799521+00	817
1686	1	-44243	nej	\N	1	1	-1686	\N	C	2019-12-20 22:13:53.799521+00	818
1685	4	-44243	odef	\N	1	1	-1685	\N	C	2019-12-20 22:13:53.799521+00	819
1684	2	-44243	kruka A	\N	1	1	-1684	\N	C	2019-12-20 22:13:53.799521+00	820
1683	1	-44242	dekor	\N	1	1	-1683	\N	C	2019-12-20 22:13:53.799521+00	821
1682	2	-44242	Figurin?	\N	1	1	-1682	\N	C	2019-12-20 22:13:53.799521+00	822
1681	1	-44241	dekor	\N	1	1	-1681	\N	C	2019-12-20 22:13:53.799521+00	823
1680	2	-44241	Figurin	\N	1	1	-1680	\N	C	2019-12-20 22:13:53.799521+00	824
1679	4	-44219	obehandlad	\N	1	1	-1679	\N	C	2019-12-20 22:13:53.799521+00	825
1678	4	-44218	Avstruken	\N	1	1	-1678	\N	C	2019-12-20 22:13:53.799521+00	826
1677	4	-44217	glättad	\N	1	1	-1677	\N	C	2019-12-20 22:13:53.799521+00	827
1676	4	-44216	glättad	\N	1	1	-1676	\N	C	2019-12-20 22:13:53.799521+00	828
1675	4	-44215	glättad	\N	1	1	-1675	\N	C	2019-12-20 22:13:53.799521+00	829
1674	4	-44214	glättad	\N	1	1	-1674	\N	C	2019-12-20 22:13:53.799521+00	830
1673	4	-44213	glättad	\N	1	1	-1673	\N	C	2019-12-20 22:13:53.799521+00	831
1672	4	-44212	glättad	\N	1	1	-1672	\N	C	2019-12-20 22:13:53.799521+00	832
1671	4	-44211	glättad	\N	1	1	-1671	\N	C	2019-12-20 22:13:53.799521+00	833
1670	4	-44210	glättad	\N	1	1	-1670	\N	C	2019-12-20 22:13:53.799521+00	834
1669	4	-44209	Polerad	\N	1	1	-1669	\N	C	2019-12-20 22:13:53.799521+00	835
1668	4	-44208	Polerad	\N	1	1	-1668	\N	C	2019-12-20 22:13:53.799521+00	836
1667	4	-44207	glättad	\N	1	1	-1667	\N	C	2019-12-20 22:13:53.799521+00	837
1666	4	-44206	glättad	\N	1	1	-1666	\N	C	2019-12-20 22:13:53.799521+00	838
1665	4	-44205	glättad	\N	1	1	-1665	\N	C	2019-12-20 22:13:53.799521+00	839
1664	4	-44203	glättad	\N	1	1	-1664	\N	C	2019-12-20 22:13:53.799521+00	840
1663	4	-44202	Polerad	\N	1	1	-1663	\N	C	2019-12-20 22:13:53.799521+00	841
1662	4	-44201	glättad	\N	1	1	-1662	\N	C	2019-12-20 22:13:53.799521+00	842
1661	4	-44200	Polerad	\N	1	1	-1661	\N	C	2019-12-20 22:13:53.799521+00	843
1660	4	-44199	obehandlad	\N	1	1	-1660	\N	C	2019-12-20 22:13:53.799521+00	844
1659	4	-44198	glättad	\N	1	1	-1659	\N	C	2019-12-20 22:13:53.799521+00	845
1658	4	-44197	glättad	\N	1	1	-1658	\N	C	2019-12-20 22:13:53.799521+00	846
1657	4	-44196	glättad	\N	1	1	-1657	\N	C	2019-12-20 22:13:53.799521+00	847
1656	4	-44195	Avstruken	\N	1	1	-1656	\N	C	2019-12-20 22:13:53.799521+00	848
1655	4	-44194	Polerad	\N	1	1	-1655	\N	C	2019-12-20 22:13:53.799521+00	849
1654	4	-44193	Polerad	\N	1	1	-1654	\N	C	2019-12-20 22:13:53.799521+00	850
1653	4	-44192	Polerad	\N	1	1	-1653	\N	C	2019-12-20 22:13:53.799521+00	851
1652	4	-44191	glättad	\N	1	1	-1652	\N	C	2019-12-20 22:13:53.799521+00	852
1651	4	-44190	glättad	\N	1	1	-1651	\N	C	2019-12-20 22:13:53.799521+00	853
1650	4	-44185	polerad	\N	1	1	-1650	\N	C	2019-12-20 22:13:53.799521+00	854
1649	4	-44184	glättad	\N	1	1	-1649	\N	C	2019-12-20 22:13:53.799521+00	855
1648	4	-44183	glättad	\N	1	1	-1648	\N	C	2019-12-20 22:13:53.799521+00	856
1647	4	-44182	polerad	\N	1	1	-1647	\N	C	2019-12-20 22:13:53.799521+00	857
1646	4	-44181	glättad	\N	1	1	-1646	\N	C	2019-12-20 22:13:53.799521+00	858
1645	4	-44180	glättad	\N	1	1	-1645	\N	C	2019-12-20 22:13:53.799521+00	859
1644	4	-44179	avstruken	\N	1	1	-1644	\N	C	2019-12-20 22:13:53.799521+00	860
1643	4	-44178	glättad	\N	1	1	-1643	\N	C	2019-12-20 22:13:53.799521+00	861
1642	4	-44177	polerad	\N	1	1	-1642	\N	C	2019-12-20 22:13:53.799521+00	862
1641	4	-44176	polerad	\N	1	1	-1641	\N	C	2019-12-20 22:13:53.799521+00	863
1640	4	-44175	glättad	\N	1	1	-1640	\N	C	2019-12-20 22:13:53.799521+00	864
1639	4	-44174	glättad	\N	1	1	-1639	\N	C	2019-12-20 22:13:53.799521+00	865
1638	4	-44173	obehandlad	\N	1	1	-1638	\N	C	2019-12-20 22:13:53.799521+00	866
1637	4	-44172	polerad	\N	1	1	-1637	\N	C	2019-12-20 22:13:53.799521+00	867
1636	4	-44171	odef	\N	1	1	-1636	\N	C	2019-12-20 22:13:53.799521+00	868
1635	4	-44170	glättad	\N	1	1	-1635	\N	C	2019-12-20 22:13:53.799521+00	869
1634	4	-44169	glättad	\N	1	1	-1634	\N	C	2019-12-20 22:13:53.799521+00	870
1633	4	-44168	glättad	\N	1	1	-1633	\N	C	2019-12-20 22:13:53.799521+00	871
1632	4	-44167	obehandlad	\N	1	1	-1632	\N	C	2019-12-20 22:13:53.799521+00	872
1631	4	-44166	glättad	\N	1	1	-1631	\N	C	2019-12-20 22:13:53.799521+00	873
1630	1	-44163	nej	\N	1	1	-1630	\N	C	2019-12-20 22:13:53.799521+00	874
1629	1	-44162	nej	\N	1	1	-1629	\N	C	2019-12-20 22:13:53.799521+00	875
1628	1	-44149	hål	\N	1	1	-1628	\N	C	2019-12-20 22:13:53.799521+00	876
1627	4	-44148	obehandlad	\N	1	1	-1627	\N	C	2019-12-20 22:13:53.799521+00	877
1626	4	-44147	glättad	\N	1	1	-1626	\N	C	2019-12-20 22:13:53.799521+00	878
1625	4	-44146	glättad	\N	1	1	-1625	\N	C	2019-12-20 22:13:53.799521+00	879
1624	4	-44145	glättad	\N	1	1	-1624	\N	C	2019-12-20 22:13:53.799521+00	880
1623	4	-44144	glättad	\N	1	1	-1623	\N	C	2019-12-20 22:13:53.799521+00	881
1622	4	-44143	glättad	\N	1	1	-1622	\N	C	2019-12-20 22:13:53.799521+00	882
1621	4	-44142	glättad	\N	1	1	-1621	\N	C	2019-12-20 22:13:53.799521+00	883
1620	4	-44141	glättad	\N	1	1	-1620	\N	C	2019-12-20 22:13:53.799521+00	884
1619	4	-44140	Rabbad	\N	1	1	-1619	\N	C	2019-12-20 22:13:53.799521+00	885
1618	1	-44139	Dekor	\N	1	1	-1618	\N	C	2019-12-20 22:13:53.799521+00	886
1617	1	-44138	Dekor	\N	1	1	-1617	\N	C	2019-12-20 22:13:53.799521+00	887
1616	1	-44137	nej	\N	1	1	-1616	\N	C	2019-12-20 22:13:53.799521+00	888
1615	2	-44136	mynning	\N	1	1	-1615	\N	C	2019-12-20 22:13:53.799521+00	889
1614	2	-44135	buk	\N	1	1	-1614	\N	C	2019-12-20 22:13:53.799521+00	890
1613	2	-44134	buk	\N	1	1	-1613	\N	C	2019-12-20 22:13:53.799521+00	891
1612	2	-44133	buk	\N	1	1	-1612	\N	C	2019-12-20 22:13:53.799521+00	892
1611	2	-44132	buk	\N	1	1	-1611	\N	C	2019-12-20 22:13:53.799521+00	893
1610	2	-44131	buk	\N	1	1	-1610	\N	C	2019-12-20 22:13:53.799521+00	894
1609	2	-44130	buk	\N	1	1	-1609	\N	C	2019-12-20 22:13:53.799521+00	895
1608	2	-44129	buk	\N	1	1	-1608	\N	C	2019-12-20 22:13:53.799521+00	896
1607	2	-44128	buk	\N	1	1	-1607	\N	C	2019-12-20 22:13:53.799521+00	897
1606	2	-44127	buk	\N	1	1	-1606	\N	C	2019-12-20 22:13:53.799521+00	898
1605	2	-44126	buk	\N	1	1	-1605	\N	C	2019-12-20 22:13:53.799521+00	899
1604	2	-44125	buk	\N	1	1	-1604	\N	C	2019-12-20 22:13:53.799521+00	900
1603	2	-44124	hals	\N	1	1	-1603	\N	C	2019-12-20 22:13:53.799521+00	901
1602	2	-44123	buk	\N	1	1	-1602	\N	C	2019-12-20 22:13:53.799521+00	902
1601	2	-44122	buk	\N	1	1	-1601	\N	C	2019-12-20 22:13:53.799521+00	903
1600	2	-44121	buk	\N	1	1	-1600	\N	C	2019-12-20 22:13:53.799521+00	904
1599	2	-44120	mynning	\N	1	1	-1599	\N	C	2019-12-20 22:13:53.799521+00	905
1598	2	-44119	buk	\N	1	1	-1598	\N	C	2019-12-20 22:13:53.799521+00	906
1597	2	-44118	mynning	\N	1	1	-1597	\N	C	2019-12-20 22:13:53.799521+00	907
1596	2	-44117	buk	\N	1	1	-1596	\N	C	2019-12-20 22:13:53.799521+00	908
1595	2	-44116	buk	\N	1	1	-1595	\N	C	2019-12-20 22:13:53.799521+00	909
1594	1	-44060	taggtråd	\N	1	1	-1594	\N	C	2019-12-20 22:13:53.799521+00	910
1593	4	-44060	glättad	\N	1	1	-1593	\N	C	2019-12-20 22:13:53.799521+00	911
1592	1	-44059	nej	\N	1	1	-1592	\N	C	2019-12-20 22:13:53.799521+00	912
1591	4	-44059	odef	\N	1	1	-1591	\N	C	2019-12-20 22:13:53.799521+00	913
1590	2	-44059	Botten	\N	1	1	-1590	\N	C	2019-12-20 22:13:53.799521+00	914
1589	1	-44058	nej	\N	1	1	-1589	\N	C	2019-12-20 22:13:53.799521+00	915
1588	4	-44058	glättad	\N	1	1	-1588	\N	C	2019-12-20 22:13:53.799521+00	916
1587	1	-44057	nej	\N	1	1	-1587	\N	C	2019-12-20 22:13:53.799521+00	917
1586	4	-44057	glättad	\N	1	1	-1586	\N	C	2019-12-20 22:13:53.799521+00	918
1585	1	-44056	nej	\N	1	1	-1585	\N	C	2019-12-20 22:13:53.799521+00	919
1584	4	-44056	glättad	\N	1	1	-1584	\N	C	2019-12-20 22:13:53.799521+00	920
1583	1	-44055	nej	\N	1	1	-1583	\N	C	2019-12-20 22:13:53.799521+00	921
1582	4	-44055	glättad	\N	1	1	-1582	\N	C	2019-12-20 22:13:53.799521+00	922
1581	1	-44054	nej	\N	1	1	-1581	\N	C	2019-12-20 22:13:53.799521+00	923
1580	4	-44054	Polerad	\N	1	1	-1580	\N	C	2019-12-20 22:13:53.799521+00	924
1579	1	-44053	nej	\N	1	1	-1579	\N	C	2019-12-20 22:13:53.799521+00	925
1578	4	-44053	Grov	\N	1	1	-1578	\N	C	2019-12-20 22:13:53.799521+00	926
1577	1	-44052	Dekor	\N	1	1	-1577	\N	C	2019-12-20 22:13:53.799521+00	927
1576	4	-44052	glättad	\N	1	1	-1576	\N	C	2019-12-20 22:13:53.799521+00	928
1575	1	-44051	insidig kannelyr	\N	1	1	-1575	\N	C	2019-12-20 22:13:53.799521+00	929
1574	4	-44051	Polerad	\N	1	1	-1574	\N	C	2019-12-20 22:13:53.799521+00	930
1573	1	-44050	knopp	\N	1	1	-1573	\N	C	2019-12-20 22:13:53.799521+00	931
1572	4	-44050	Polerad	\N	1	1	-1572	\N	C	2019-12-20 22:13:53.799521+00	932
1571	1	-44049	dekor	\N	1	1	-1571	\N	C	2019-12-20 22:13:53.799521+00	933
1570	4	-44049	Rabbad	\N	1	1	-1570	\N	C	2019-12-20 22:13:53.799521+00	934
1569	1	-44048	vulst	\N	1	1	-1569	\N	C	2019-12-20 22:13:53.799521+00	935
1568	4	-44048	Rabbad	\N	1	1	-1568	\N	C	2019-12-20 22:13:53.799521+00	936
1567	1	-44047	nej	\N	1	1	-1567	\N	C	2019-12-20 22:13:53.799521+00	937
1566	4	-44047	Rabbad	\N	1	1	-1566	\N	C	2019-12-20 22:13:53.799521+00	938
1565	1	-44046	hank	\N	1	1	-1565	\N	C	2019-12-20 22:13:53.799521+00	939
1564	4	-44046	glättad	\N	1	1	-1564	\N	C	2019-12-20 22:13:53.799521+00	940
1563	1	-44045	hank	\N	1	1	-1563	\N	C	2019-12-20 22:13:53.799521+00	941
1562	4	-44045	glättad	\N	1	1	-1562	\N	C	2019-12-20 22:13:53.799521+00	942
1561	1	-44044	nej	\N	1	1	-1561	\N	C	2019-12-20 22:13:53.799521+00	943
1560	1	-44043	vulst	\N	1	1	-1560	\N	C	2019-12-20 22:13:53.799521+00	944
1559	4	-44043	glättad	\N	1	1	-1559	\N	C	2019-12-20 22:13:53.799521+00	945
1558	1	-44042	nej	\N	1	1	-1558	\N	C	2019-12-20 22:13:53.799521+00	946
1557	4	-44042	glättad	\N	1	1	-1557	\N	C	2019-12-20 22:13:53.799521+00	947
1556	1	-44041	knopp	\N	1	1	-1556	\N	C	2019-12-20 22:13:53.799521+00	948
1555	4	-44041	Rabbad	\N	1	1	-1555	\N	C	2019-12-20 22:13:53.799521+00	949
1554	1	-44040	nej	\N	1	1	-1554	\N	C	2019-12-20 22:13:53.799521+00	950
1553	4	-44040	glättad	\N	1	1	-1553	\N	C	2019-12-20 22:13:53.799521+00	951
1552	4	-44039	odef	\N	1	1	-1552	\N	C	2019-12-20 22:13:53.799521+00	952
1551	1	-44038	nej	\N	1	1	-1551	\N	C	2019-12-20 22:13:53.799521+00	953
1550	4	-44038	glättad	\N	1	1	-1550	\N	C	2019-12-20 22:13:53.799521+00	954
1549	1	-44037	Perforerat kärl	\N	1	1	-1549	\N	C	2019-12-20 22:13:53.799521+00	955
1548	4	-44037	glättad	\N	1	1	-1548	\N	C	2019-12-20 22:13:53.799521+00	956
1547	1	-44036	nej	\N	1	1	-1547	\N	C	2019-12-20 22:13:53.799521+00	957
1546	4	-44036	glättad	\N	1	1	-1546	\N	C	2019-12-20 22:13:53.799521+00	958
1545	1	-44035	nej	\N	1	1	-1545	\N	C	2019-12-20 22:13:53.799521+00	959
1544	4	-44035	glättad	\N	1	1	-1544	\N	C	2019-12-20 22:13:53.799521+00	960
1543	1	-44034	knopp	\N	1	1	-1543	\N	C	2019-12-20 22:13:53.799521+00	961
1542	4	-44034	Rabbad	\N	1	1	-1542	\N	C	2019-12-20 22:13:53.799521+00	962
1541	4	-44033	odef	\N	1	1	-1541	\N	C	2019-12-20 22:13:53.799521+00	963
1540	1	-44032	Dekor	\N	1	1	-1540	\N	C	2019-12-20 22:13:53.799521+00	964
1539	4	-44032	glättad	\N	1	1	-1539	\N	C	2019-12-20 22:13:53.799521+00	965
1538	4	-44031	odef	\N	1	1	-1538	\N	C	2019-12-20 22:13:53.799521+00	966
1537	1	-44030	nej	\N	1	1	-1537	\N	C	2019-12-20 22:13:53.799521+00	967
1536	4	-44030	Strierad/strimmig	\N	1	1	-1536	\N	C	2019-12-20 22:13:53.799521+00	968
1535	1	-44029	nej	\N	1	1	-1535	\N	C	2019-12-20 22:13:53.799521+00	969
1534	4	-44029	glättad	\N	1	1	-1534	\N	C	2019-12-20 22:13:53.799521+00	970
1533	4	-44028	odef	\N	1	1	-1533	\N	C	2019-12-20 22:13:53.799521+00	971
1532	1	-44027	nej	\N	1	1	-1532	\N	C	2019-12-20 22:13:53.799521+00	972
1531	4	-44027	Textil	\N	1	1	-1531	\N	C	2019-12-20 22:13:53.799521+00	973
1530	1	-44026	nej	\N	1	1	-1530	\N	C	2019-12-20 22:13:53.799521+00	974
1529	4	-44026	odef	\N	1	1	-1529	\N	C	2019-12-20 22:13:53.799521+00	975
1528	1	-44025	nej	\N	1	1	-1528	\N	C	2019-12-20 22:13:53.799521+00	976
1527	4	-44025	Rabbad	\N	1	1	-1527	\N	C	2019-12-20 22:13:53.799521+00	977
1526	1	-44024	nej	\N	1	1	-1526	\N	C	2019-12-20 22:13:53.799521+00	978
1525	4	-44024	Rabbad	\N	1	1	-1525	\N	C	2019-12-20 22:13:53.799521+00	979
1524	1	-44023	nej	\N	1	1	-1524	\N	C	2019-12-20 22:13:53.799521+00	980
1523	4	-44023	Rabbad	\N	1	1	-1523	\N	C	2019-12-20 22:13:53.799521+00	981
1522	1	-44022	nej	\N	1	1	-1522	\N	C	2019-12-20 22:13:53.799521+00	982
1521	4	-44022	Rabbad	\N	1	1	-1521	\N	C	2019-12-20 22:13:53.799521+00	983
1520	1	-44021	nej	\N	1	1	-1520	\N	C	2019-12-20 22:13:53.799521+00	984
1519	4	-44021	Rabbad	\N	1	1	-1519	\N	C	2019-12-20 22:13:53.799521+00	985
1518	1	-44020	nej	\N	1	1	-1518	\N	C	2019-12-20 22:13:53.799521+00	986
1517	4	-44020	Rabbad	\N	1	1	-1517	\N	C	2019-12-20 22:13:53.799521+00	987
1516	1	-44019	nej	\N	1	1	-1516	\N	C	2019-12-20 22:13:53.799521+00	988
1515	4	-44019	Rabbad	\N	1	1	-1515	\N	C	2019-12-20 22:13:53.799521+00	989
1514	1	-44018	nej	\N	1	1	-1514	\N	C	2019-12-20 22:13:53.799521+00	990
1513	1	-44017	nej	\N	1	1	-1513	\N	C	2019-12-20 22:13:53.799521+00	991
1512	4	-44017	Rabbad	\N	1	1	-1512	\N	C	2019-12-20 22:13:53.799521+00	992
1511	1	-44016	nej	\N	1	1	-1511	\N	C	2019-12-20 22:13:53.799521+00	993
1510	4	-44016	Rabbad	\N	1	1	-1510	\N	C	2019-12-20 22:13:53.799521+00	994
1509	1	-44015	nej	\N	1	1	-1509	\N	C	2019-12-20 22:13:53.799521+00	995
1508	4	-44015	Rabbad	\N	1	1	-1508	\N	C	2019-12-20 22:13:53.799521+00	996
1507	1	-44014	nej	\N	1	1	-1507	\N	C	2019-12-20 22:13:53.799521+00	997
1506	4	-44014	Polerad	\N	1	1	-1506	\N	C	2019-12-20 22:13:53.799521+00	998
1505	1	-44013	nej	\N	1	1	-1505	\N	C	2019-12-20 22:13:53.799521+00	999
1504	4	-44013	Polerad	\N	1	1	-1504	\N	C	2019-12-20 22:13:53.799521+00	1000
1503	1	-44012	nej	\N	1	1	-1503	\N	C	2019-12-20 22:13:53.799521+00	1001
1502	4	-44012	Polerad	\N	1	1	-1502	\N	C	2019-12-20 22:13:53.799521+00	1002
1501	1	-44011	nej	\N	1	1	-1501	\N	C	2019-12-20 22:13:53.799521+00	1003
1500	4	-44011	Polerad	\N	1	1	-1500	\N	C	2019-12-20 22:13:53.799521+00	1004
1499	1	-44010	nej	\N	1	1	-1499	\N	C	2019-12-20 22:13:53.799521+00	1005
1498	1	-44009	nej	\N	1	1	-1498	\N	C	2019-12-20 22:13:53.799521+00	1006
1497	4	-44009	Polerad	\N	1	1	-1497	\N	C	2019-12-20 22:13:53.799521+00	1007
1496	1	-44008	nej	\N	1	1	-1496	\N	C	2019-12-20 22:13:53.799521+00	1008
1495	4	-44008	Polerad	\N	1	1	-1495	\N	C	2019-12-20 22:13:53.799521+00	1009
1494	1	-44007	nej	\N	1	1	-1494	\N	C	2019-12-20 22:13:53.799521+00	1010
1493	4	-44007	Polerad	\N	1	1	-1493	\N	C	2019-12-20 22:13:53.799521+00	1011
1492	1	-44006	nej	\N	1	1	-1492	\N	C	2019-12-20 22:13:53.799521+00	1012
1491	4	-44006	Textil	\N	1	1	-1491	\N	C	2019-12-20 22:13:53.799521+00	1013
1490	1	-44005	nej	\N	1	1	-1490	\N	C	2019-12-20 22:13:53.799521+00	1014
1489	4	-44005	Rabbad	\N	1	1	-1489	\N	C	2019-12-20 22:13:53.799521+00	1015
1488	1	-44004	nej	\N	1	1	-1488	\N	C	2019-12-20 22:13:53.799521+00	1016
1487	4	-44004	odef	\N	1	1	-1487	\N	C	2019-12-20 22:13:53.799521+00	1017
1486	1	-44002	nej	\N	1	1	-1486	\N	C	2019-12-20 22:13:53.799521+00	1018
1485	4	-44002	Rabbad	\N	1	1	-1485	\N	C	2019-12-20 22:13:53.799521+00	1019
1484	1	-44001	nej	\N	1	1	-1484	\N	C	2019-12-20 22:13:53.799521+00	1020
1483	4	-44001	Polerad	\N	1	1	-1483	\N	C	2019-12-20 22:13:53.799521+00	1021
1482	1	-44000	nej	\N	1	1	-1482	\N	C	2019-12-20 22:13:53.799521+00	1022
1481	4	-44000	odef	\N	1	1	-1481	\N	C	2019-12-20 22:13:53.799521+00	1023
1480	1	-43999	nej	\N	1	1	-1480	\N	C	2019-12-20 22:13:53.799521+00	1024
1479	4	-43999	Textil	\N	1	1	-1479	\N	C	2019-12-20 22:13:53.799521+00	1025
1478	1	-43998	nej	\N	1	1	-1478	\N	C	2019-12-20 22:13:53.799521+00	1026
1477	4	-43998	Rabbad	\N	1	1	-1477	\N	C	2019-12-20 22:13:53.799521+00	1027
1476	1	-43997	ränder i rabbning	\N	1	1	-1476	\N	C	2019-12-20 22:13:53.799521+00	1028
1475	4	-43997	Rabbad	\N	1	1	-1475	\N	C	2019-12-20 22:13:53.799521+00	1029
1474	1	-43996	ränder i rabbning	\N	1	1	-1474	\N	C	2019-12-20 22:13:53.799521+00	1030
1473	4	-43996	Rabbad	\N	1	1	-1473	\N	C	2019-12-20 22:13:53.799521+00	1031
1472	1	-43995	ränder i rabbning	\N	1	1	-1472	\N	C	2019-12-20 22:13:53.799521+00	1032
1471	4	-43995	Rabbad	\N	1	1	-1471	\N	C	2019-12-20 22:13:53.799521+00	1033
1470	1	-43994	ränder i rabbning	\N	1	1	-1470	\N	C	2019-12-20 22:13:53.799521+00	1034
1469	4	-43994	Rabbad	\N	1	1	-1469	\N	C	2019-12-20 22:13:53.799521+00	1035
1468	1	-43993	Dekor	\N	1	1	-1468	\N	C	2019-12-20 22:13:53.799521+00	1036
1467	1	-43991	Dekor	\N	1	1	-1467	\N	C	2019-12-20 22:13:53.799521+00	1037
1466	1	-43990	Dekor	\N	1	1	-1466	\N	C	2019-12-20 22:13:53.799521+00	1038
1465	1	-43987	nej	\N	1	1	-1465	\N	C	2019-12-20 22:13:53.799521+00	1039
1464	1	-43921	nej	\N	1	1	-1464	\N	C	2019-12-20 22:13:53.799521+00	1040
1463	1	-43920	nej	\N	1	1	-1463	\N	C	2019-12-20 22:13:53.799521+00	1041
1462	1	-43919	nej	\N	1	1	-1462	\N	C	2019-12-20 22:13:53.799521+00	1042
1461	4	-43919	vittrad	\N	1	1	-1461	\N	C	2019-12-20 22:13:53.799521+00	1043
1460	1	-43918	nej	\N	1	1	-1460	\N	C	2019-12-20 22:13:53.799521+00	1044
1459	4	-43918	vittrad	\N	1	1	-1459	\N	C	2019-12-20 22:13:53.799521+00	1045
1458	1	-43917	nej	\N	1	1	-1458	\N	C	2019-12-20 22:13:53.799521+00	1046
1457	4	-43917	Polerad	\N	1	1	-1457	\N	C	2019-12-20 22:13:53.799521+00	1047
1456	1	-43916	Dekor	\N	1	1	-1456	\N	C	2019-12-20 22:13:53.799521+00	1048
1455	4	-43916	vittrad	\N	1	1	-1455	\N	C	2019-12-20 22:13:53.799521+00	1049
1454	1	-43915	nej	\N	1	1	-1454	\N	C	2019-12-20 22:13:53.799521+00	1050
1453	4	-43915	glättad	\N	1	1	-1453	\N	C	2019-12-20 22:13:53.799521+00	1051
1452	4	-43910	vittrad	\N	1	1	-1452	\N	C	2019-12-20 22:13:53.799521+00	1052
1451	4	-43909	Polerad	\N	1	1	-1451	\N	C	2019-12-20 22:13:53.799521+00	1053
1450	4	-43908	vittrad	\N	1	1	-1450	\N	C	2019-12-20 22:13:53.799521+00	1054
1449	4	-43907	Polerad	\N	1	1	-1449	\N	C	2019-12-20 22:13:53.799521+00	1055
1448	4	-43906	vittrad	\N	1	1	-1448	\N	C	2019-12-20 22:13:53.799521+00	1056
1447	4	-43905	vittrad	\N	1	1	-1447	\N	C	2019-12-20 22:13:53.799521+00	1057
1446	4	-43904	glättad	\N	1	1	-1446	\N	C	2019-12-20 22:13:53.799521+00	1058
1445	4	-43903	vittrad	\N	1	1	-1445	\N	C	2019-12-20 22:13:53.799521+00	1059
1444	4	-43902	glättad	\N	1	1	-1444	\N	C	2019-12-20 22:13:53.799521+00	1060
1443	4	-43901	glättad	\N	1	1	-1443	\N	C	2019-12-20 22:13:53.799521+00	1061
1442	4	-43900	glättad	\N	1	1	-1442	\N	C	2019-12-20 22:13:53.799521+00	1062
1441	4	-43899	vittrad	\N	1	1	-1441	\N	C	2019-12-20 22:13:53.799521+00	1063
1440	4	-43898	glättad	\N	1	1	-1440	\N	C	2019-12-20 22:13:53.799521+00	1064
1439	4	-43896	vittrad	\N	1	1	-1439	\N	C	2019-12-20 22:13:53.799521+00	1065
1438	4	-43895	glättad	\N	1	1	-1438	\N	C	2019-12-20 22:13:53.799521+00	1066
1437	4	-43894	vittrad	\N	1	1	-1437	\N	C	2019-12-20 22:13:53.799521+00	1067
1436	4	-43893	glättad	\N	1	1	-1436	\N	C	2019-12-20 22:13:53.799521+00	1068
1435	4	-43892	glättad	\N	1	1	-1435	\N	C	2019-12-20 22:13:53.799521+00	1069
1434	4	-43891	Polerad	\N	1	1	-1434	\N	C	2019-12-20 22:13:53.799521+00	1070
1433	4	-43890	Polerad	\N	1	1	-1433	\N	C	2019-12-20 22:13:53.799521+00	1071
1432	4	-43889	Polerad	\N	1	1	-1432	\N	C	2019-12-20 22:13:53.799521+00	1072
1431	4	-43888	Polerad	\N	1	1	-1431	\N	C	2019-12-20 22:13:53.799521+00	1073
1430	4	-43887	Polerad	\N	1	1	-1430	\N	C	2019-12-20 22:13:53.799521+00	1074
1429	4	-43885	Polerad	\N	1	1	-1429	\N	C	2019-12-20 22:13:53.799521+00	1075
1428	4	-43884	glättad	\N	1	1	-1428	\N	C	2019-12-20 22:13:53.799521+00	1076
1427	4	-43883	glättad	\N	1	1	-1427	\N	C	2019-12-20 22:13:53.799521+00	1077
1426	4	-43882	Polerad	\N	1	1	-1426	\N	C	2019-12-20 22:13:53.799521+00	1078
1425	4	-43880	Polerad	\N	1	1	-1425	\N	C	2019-12-20 22:13:53.799521+00	1079
1424	4	-43879	Polerad	\N	1	1	-1424	\N	C	2019-12-20 22:13:53.799521+00	1080
1423	4	-43878	Polerad	\N	1	1	-1423	\N	C	2019-12-20 22:13:53.799521+00	1081
1422	4	-43877	glättad	\N	1	1	-1422	\N	C	2019-12-20 22:13:53.799521+00	1082
1421	4	-43876	kam	\N	1	1	-1421	\N	C	2019-12-20 22:13:53.799521+00	1083
1420	4	-43875	kam	\N	1	1	-1420	\N	C	2019-12-20 22:13:53.799521+00	1084
1419	4	-43874	kam	\N	1	1	-1419	\N	C	2019-12-20 22:13:53.799521+00	1085
1418	4	-43873	Polerad	\N	1	1	-1418	\N	C	2019-12-20 22:13:53.799521+00	1086
1417	4	-43872	Polerad	\N	1	1	-1417	\N	C	2019-12-20 22:13:53.799521+00	1087
1416	4	-43871	fs	\N	1	1	-1416	\N	C	2019-12-20 22:13:53.799521+00	1088
1415	4	-43870	Polerad	\N	1	1	-1415	\N	C	2019-12-20 22:13:53.799521+00	1089
1414	4	-43869	Polerad	\N	1	1	-1414	\N	C	2019-12-20 22:13:53.799521+00	1090
1413	4	-43868	Polerad	\N	1	1	-1413	\N	C	2019-12-20 22:13:53.799521+00	1091
1412	4	-43867	Polerad	\N	1	1	-1412	\N	C	2019-12-20 22:13:53.799521+00	1092
1411	4	-43866	glättad	\N	1	1	-1411	\N	C	2019-12-20 22:13:53.799521+00	1093
1410	4	-43865	glättad	\N	1	1	-1410	\N	C	2019-12-20 22:13:53.799521+00	1094
1409	4	-43864	glättad	\N	1	1	-1409	\N	C	2019-12-20 22:13:53.799521+00	1095
1408	4	-43863	glättad	\N	1	1	-1408	\N	C	2019-12-20 22:13:53.799521+00	1096
1407	4	-43862	Polerad	\N	1	1	-1407	\N	C	2019-12-20 22:13:53.799521+00	1097
1406	4	-43861	glättad	\N	1	1	-1406	\N	C	2019-12-20 22:13:53.799521+00	1098
1405	4	-43860	glättad	\N	1	1	-1405	\N	C	2019-12-20 22:13:53.799521+00	1099
1404	4	-43859	Polerad	\N	1	1	-1404	\N	C	2019-12-20 22:13:53.799521+00	1100
1403	4	-43858	glättad	\N	1	1	-1403	\N	C	2019-12-20 22:13:53.799521+00	1101
1402	4	-43857	Polerad	\N	1	1	-1402	\N	C	2019-12-20 22:13:53.799521+00	1102
1401	4	-43856	Polerad	\N	1	1	-1401	\N	C	2019-12-20 22:13:53.799521+00	1103
1400	4	-43855	glättad	\N	1	1	-1400	\N	C	2019-12-20 22:13:53.799521+00	1104
1399	4	-43854	glättad	\N	1	1	-1399	\N	C	2019-12-20 22:13:53.799521+00	1105
1398	4	-43853	glättad	\N	1	1	-1398	\N	C	2019-12-20 22:13:53.799521+00	1106
1397	4	-43852	Polerad	\N	1	1	-1397	\N	C	2019-12-20 22:13:53.799521+00	1107
1396	4	-43851	glättad	\N	1	1	-1396	\N	C	2019-12-20 22:13:53.799521+00	1108
1395	4	-43850	Polerad	\N	1	1	-1395	\N	C	2019-12-20 22:13:53.799521+00	1109
1394	4	-43849	glättad	\N	1	1	-1394	\N	C	2019-12-20 22:13:53.799521+00	1110
1393	4	-43848	glättad	\N	1	1	-1393	\N	C	2019-12-20 22:13:53.799521+00	1111
1392	4	-43847	Polerad	\N	1	1	-1392	\N	C	2019-12-20 22:13:53.799521+00	1112
1391	4	-43846	Polerad	\N	1	1	-1391	\N	C	2019-12-20 22:13:53.799521+00	1113
1390	4	-43845	Polerad	\N	1	1	-1390	\N	C	2019-12-20 22:13:53.799521+00	1114
1389	4	-43844	Polerad	\N	1	1	-1389	\N	C	2019-12-20 22:13:53.799521+00	1115
1388	4	-43843	Polerad	\N	1	1	-1388	\N	C	2019-12-20 22:13:53.799521+00	1116
1387	4	-43842	Polerad	\N	1	1	-1387	\N	C	2019-12-20 22:13:53.799521+00	1117
1386	4	-43841	Polerad	\N	1	1	-1386	\N	C	2019-12-20 22:13:53.799521+00	1118
1385	4	-43840	Polerad	\N	1	1	-1385	\N	C	2019-12-20 22:13:53.799521+00	1119
1384	4	-43838	glättad	\N	1	1	-1384	\N	C	2019-12-20 22:13:53.799521+00	1120
1383	4	-43836	glättad	\N	1	1	-1383	\N	C	2019-12-20 22:13:53.799521+00	1121
1382	4	-43835	Polerad	\N	1	1	-1382	\N	C	2019-12-20 22:13:53.799521+00	1122
1381	4	-43834	glättad	\N	1	1	-1381	\N	C	2019-12-20 22:13:53.799521+00	1123
1380	4	-43831	Polerad	\N	1	1	-1380	\N	C	2019-12-20 22:13:53.799521+00	1124
1379	4	-43829	Polerad	\N	1	1	-1379	\N	C	2019-12-20 22:13:53.799521+00	1125
1378	4	-43828	Polerad	\N	1	1	-1378	\N	C	2019-12-20 22:13:53.799521+00	1126
1377	4	-43827	glättad	\N	1	1	-1377	\N	C	2019-12-20 22:13:53.799521+00	1127
1376	4	-43825	glättad	\N	1	1	-1376	\N	C	2019-12-20 22:13:53.799521+00	1128
1375	4	-43824	glättad	\N	1	1	-1375	\N	C	2019-12-20 22:13:53.799521+00	1129
1374	4	-43822	glättad	\N	1	1	-1374	\N	C	2019-12-20 22:13:53.799521+00	1130
1373	4	-43821	Polerad	\N	1	1	-1373	\N	C	2019-12-20 22:13:53.799521+00	1131
1372	4	-43820	glättad	\N	1	1	-1372	\N	C	2019-12-20 22:13:53.799521+00	1132
1371	4	-43819	Polerad	\N	1	1	-1371	\N	C	2019-12-20 22:13:53.799521+00	1133
1370	4	-43818	Polerad	\N	1	1	-1370	\N	C	2019-12-20 22:13:53.799521+00	1134
1369	4	-43817	glättad	\N	1	1	-1369	\N	C	2019-12-20 22:13:53.799521+00	1135
1368	4	-43816	Polerad	\N	1	1	-1368	\N	C	2019-12-20 22:13:53.799521+00	1136
1367	4	-43815	Polerad	\N	1	1	-1367	\N	C	2019-12-20 22:13:53.799521+00	1137
1366	4	-43814	Polerad	\N	1	1	-1366	\N	C	2019-12-20 22:13:53.799521+00	1138
1365	4	-43813	Polerad	\N	1	1	-1365	\N	C	2019-12-20 22:13:53.799521+00	1139
1364	4	-43812	Polerad	\N	1	1	-1364	\N	C	2019-12-20 22:13:53.799521+00	1140
1363	4	-43810	glättad	\N	1	1	-1363	\N	C	2019-12-20 22:13:53.799521+00	1141
1362	4	-43808	Polerad	\N	1	1	-1362	\N	C	2019-12-20 22:13:53.799521+00	1142
1361	4	-43807	Polerad	\N	1	1	-1361	\N	C	2019-12-20 22:13:53.799521+00	1143
1360	4	-43806	Polerad	\N	1	1	-1360	\N	C	2019-12-20 22:13:53.799521+00	1144
1359	4	-43804	glättad	\N	1	1	-1359	\N	C	2019-12-20 22:13:53.799521+00	1145
1358	4	-43803	Polerad	\N	1	1	-1358	\N	C	2019-12-20 22:13:53.799521+00	1146
1357	4	-43802	Polerad	\N	1	1	-1357	\N	C	2019-12-20 22:13:53.799521+00	1147
1356	4	-43801	Polerad	\N	1	1	-1356	\N	C	2019-12-20 22:13:53.799521+00	1148
1355	4	-43798	glättad	\N	1	1	-1355	\N	C	2019-12-20 22:13:53.799521+00	1149
1354	4	-43797	Polerad	\N	1	1	-1354	\N	C	2019-12-20 22:13:53.799521+00	1150
1353	4	-43796	glättad	\N	1	1	-1353	\N	C	2019-12-20 22:13:53.799521+00	1151
1352	4	-43794	semirabbad	\N	1	1	-1352	\N	C	2019-12-20 22:13:53.799521+00	1152
1351	4	-43793	glättad	\N	1	1	-1351	\N	C	2019-12-20 22:13:53.799521+00	1153
1350	4	-43792	Polerad	\N	1	1	-1350	\N	C	2019-12-20 22:13:53.799521+00	1154
1349	4	-43790	glättad	\N	1	1	-1349	\N	C	2019-12-20 22:13:53.799521+00	1155
1348	4	-43789	Polerad	\N	1	1	-1348	\N	C	2019-12-20 22:13:53.799521+00	1156
1347	4	-43788	Polerad	\N	1	1	-1347	\N	C	2019-12-20 22:13:53.799521+00	1157
1346	4	-43787	Polerad	\N	1	1	-1346	\N	C	2019-12-20 22:13:53.799521+00	1158
1345	4	-43786	Polerad	\N	1	1	-1345	\N	C	2019-12-20 22:13:53.799521+00	1159
1344	4	-43785	Polerad	\N	1	1	-1344	\N	C	2019-12-20 22:13:53.799521+00	1160
1343	4	-43782	Polerad	\N	1	1	-1343	\N	C	2019-12-20 22:13:53.799521+00	1161
1342	4	-43781	Polerad	\N	1	1	-1342	\N	C	2019-12-20 22:13:53.799521+00	1162
1341	4	-43780	Polerad	\N	1	1	-1341	\N	C	2019-12-20 22:13:53.799521+00	1163
1340	4	-43779	Polerad	\N	1	1	-1340	\N	C	2019-12-20 22:13:53.799521+00	1164
1339	4	-43778	Polerad	\N	1	1	-1339	\N	C	2019-12-20 22:13:53.799521+00	1165
1338	4	-43777	Polerad	\N	1	1	-1338	\N	C	2019-12-20 22:13:53.799521+00	1166
1337	4	-43776	Polerad	\N	1	1	-1337	\N	C	2019-12-20 22:13:53.799521+00	1167
1336	4	-43775	Polerad	\N	1	1	-1336	\N	C	2019-12-20 22:13:53.799521+00	1168
1335	4	-43774	Polerad	\N	1	1	-1335	\N	C	2019-12-20 22:13:53.799521+00	1169
1334	4	-43773	Polerad	\N	1	1	-1334	\N	C	2019-12-20 22:13:53.799521+00	1170
1333	4	-43772	Polerad	\N	1	1	-1333	\N	C	2019-12-20 22:13:53.799521+00	1171
1332	4	-43771	Polerad	\N	1	1	-1332	\N	C	2019-12-20 22:13:53.799521+00	1172
1331	4	-43770	Polerad	\N	1	1	-1331	\N	C	2019-12-20 22:13:53.799521+00	1173
1330	4	-43769	glättad	\N	1	1	-1330	\N	C	2019-12-20 22:13:53.799521+00	1174
1329	4	-43768	Polerad	\N	1	1	-1329	\N	C	2019-12-20 22:13:53.799521+00	1175
1328	4	-43767	Polerad	\N	1	1	-1328	\N	C	2019-12-20 22:13:53.799521+00	1176
1327	4	-43766	Polerad	\N	1	1	-1327	\N	C	2019-12-20 22:13:53.799521+00	1177
1326	4	-43765	glättad	\N	1	1	-1326	\N	C	2019-12-20 22:13:53.799521+00	1178
1325	4	-43764	glättad	\N	1	1	-1325	\N	C	2019-12-20 22:13:53.799521+00	1179
1324	4	-43763	Polerad	\N	1	1	-1324	\N	C	2019-12-20 22:13:53.799521+00	1180
1323	4	-43762	Polerad	\N	1	1	-1323	\N	C	2019-12-20 22:13:53.799521+00	1181
1322	4	-43761	Polerad	\N	1	1	-1322	\N	C	2019-12-20 22:13:53.799521+00	1182
1321	4	-43760	Polerad	\N	1	1	-1321	\N	C	2019-12-20 22:13:53.799521+00	1183
1320	4	-43759	Polerad	\N	1	1	-1320	\N	C	2019-12-20 22:13:53.799521+00	1184
1319	4	-43758	Polerad	\N	1	1	-1319	\N	C	2019-12-20 22:13:53.799521+00	1185
1318	4	-43757	Polerad	\N	1	1	-1318	\N	C	2019-12-20 22:13:53.799521+00	1186
1317	4	-43754	Polerad	\N	1	1	-1317	\N	C	2019-12-20 22:13:53.799521+00	1187
1316	4	-43753	Polerad	\N	1	1	-1316	\N	C	2019-12-20 22:13:53.799521+00	1188
1315	4	-43752	Polerad	\N	1	1	-1315	\N	C	2019-12-20 22:13:53.799521+00	1189
1314	4	-43751	Polerad	\N	1	1	-1314	\N	C	2019-12-20 22:13:53.799521+00	1190
1313	4	-43750	Polerad	\N	1	1	-1313	\N	C	2019-12-20 22:13:53.799521+00	1191
1312	4	-43749	Polerad	\N	1	1	-1312	\N	C	2019-12-20 22:13:53.799521+00	1192
1311	4	-43748	Polerad	\N	1	1	-1311	\N	C	2019-12-20 22:13:53.799521+00	1193
1310	4	-43747	Polerad	\N	1	1	-1310	\N	C	2019-12-20 22:13:53.799521+00	1194
1309	4	-43746	Polerad	\N	1	1	-1309	\N	C	2019-12-20 22:13:53.799521+00	1195
1308	4	-43745	Polerad	\N	1	1	-1308	\N	C	2019-12-20 22:13:53.799521+00	1196
1307	4	-43744	Polerad	\N	1	1	-1307	\N	C	2019-12-20 22:13:53.799521+00	1197
1306	4	-43743	Polerad	\N	1	1	-1306	\N	C	2019-12-20 22:13:53.799521+00	1198
1305	4	-43742	Polerad	\N	1	1	-1305	\N	C	2019-12-20 22:13:53.799521+00	1199
1304	4	-43741	glättad	\N	1	1	-1304	\N	C	2019-12-20 22:13:53.799521+00	1200
1303	4	-43740	Polerad	\N	1	1	-1303	\N	C	2019-12-20 22:13:53.799521+00	1201
1302	4	-43739	Polerad	\N	1	1	-1302	\N	C	2019-12-20 22:13:53.799521+00	1202
1301	4	-43738	Polerad	\N	1	1	-1301	\N	C	2019-12-20 22:13:53.799521+00	1203
1300	4	-43737	Polerad	\N	1	1	-1300	\N	C	2019-12-20 22:13:53.799521+00	1204
1299	4	-43736	Polerad	\N	1	1	-1299	\N	C	2019-12-20 22:13:53.799521+00	1205
1298	4	-43735	Polerad	\N	1	1	-1298	\N	C	2019-12-20 22:13:53.799521+00	1206
1297	4	-43734	Polerad	\N	1	1	-1297	\N	C	2019-12-20 22:13:53.799521+00	1207
1296	4	-43733	Polerad	\N	1	1	-1296	\N	C	2019-12-20 22:13:53.799521+00	1208
1295	4	-43732	glättad	\N	1	1	-1295	\N	C	2019-12-20 22:13:53.799521+00	1209
1294	4	-43731	Polerad	\N	1	1	-1294	\N	C	2019-12-20 22:13:53.799521+00	1210
1293	4	-43730	glättad	\N	1	1	-1293	\N	C	2019-12-20 22:13:53.799521+00	1211
1292	4	-43729	Polerad	\N	1	1	-1292	\N	C	2019-12-20 22:13:53.799521+00	1212
1291	4	-43728	glättad	\N	1	1	-1291	\N	C	2019-12-20 22:13:53.799521+00	1213
1290	4	-43727	Polerad	\N	1	1	-1290	\N	C	2019-12-20 22:13:53.799521+00	1214
1289	4	-43726	Polerad	\N	1	1	-1289	\N	C	2019-12-20 22:13:53.799521+00	1215
1288	4	-43725	Polerad	\N	1	1	-1288	\N	C	2019-12-20 22:13:53.799521+00	1216
1287	4	-43723	Polerad	\N	1	1	-1287	\N	C	2019-12-20 22:13:53.799521+00	1217
1286	4	-43722	Polerad	\N	1	1	-1286	\N	C	2019-12-20 22:13:53.799521+00	1218
1285	4	-43721	Polerad	\N	1	1	-1285	\N	C	2019-12-20 22:13:53.799521+00	1219
1284	4	-43720	Polerad	\N	1	1	-1284	\N	C	2019-12-20 22:13:53.799521+00	1220
1283	4	-43719	glättad	\N	1	1	-1283	\N	C	2019-12-20 22:13:53.799521+00	1221
1282	4	-43718	Polerad	\N	1	1	-1282	\N	C	2019-12-20 22:13:53.799521+00	1222
1281	4	-43717	glättad	\N	1	1	-1281	\N	C	2019-12-20 22:13:53.799521+00	1223
1280	4	-43716	Polerad	\N	1	1	-1280	\N	C	2019-12-20 22:13:53.799521+00	1224
1279	4	-43715	Polerad	\N	1	1	-1279	\N	C	2019-12-20 22:13:53.799521+00	1225
1278	4	-43714	glättad	\N	1	1	-1278	\N	C	2019-12-20 22:13:53.799521+00	1226
1277	4	-43713	glättad	\N	1	1	-1277	\N	C	2019-12-20 22:13:53.799521+00	1227
1276	4	-43712	glättad	\N	1	1	-1276	\N	C	2019-12-20 22:13:53.799521+00	1228
1275	4	-43711	Polerad	\N	1	1	-1275	\N	C	2019-12-20 22:13:53.799521+00	1229
1274	4	-43710	glättad	\N	1	1	-1274	\N	C	2019-12-20 22:13:53.799521+00	1230
1273	4	-43709	Polerad	\N	1	1	-1273	\N	C	2019-12-20 22:13:53.799521+00	1231
1272	4	-43708	glättad	\N	1	1	-1272	\N	C	2019-12-20 22:13:53.799521+00	1232
1271	4	-43707	Polerad	\N	1	1	-1271	\N	C	2019-12-20 22:13:53.799521+00	1233
1270	4	-43706	Polerad	\N	1	1	-1270	\N	C	2019-12-20 22:13:53.799521+00	1234
1269	4	-43705	glättad	\N	1	1	-1269	\N	C	2019-12-20 22:13:53.799521+00	1235
1268	4	-43703	Polerad	\N	1	1	-1268	\N	C	2019-12-20 22:13:53.799521+00	1236
1267	4	-43702	glättad	\N	1	1	-1267	\N	C	2019-12-20 22:13:53.799521+00	1237
1266	4	-43701	glättad	\N	1	1	-1266	\N	C	2019-12-20 22:13:53.799521+00	1238
1265	4	-43700	Polerad	\N	1	1	-1265	\N	C	2019-12-20 22:13:53.799521+00	1239
1264	4	-43699	glättad	\N	1	1	-1264	\N	C	2019-12-20 22:13:53.799521+00	1240
1263	4	-43698	glättad	\N	1	1	-1263	\N	C	2019-12-20 22:13:53.799521+00	1241
1262	4	-43697	glättad	\N	1	1	-1262	\N	C	2019-12-20 22:13:53.799521+00	1242
1261	4	-43696	glättad	\N	1	1	-1261	\N	C	2019-12-20 22:13:53.799521+00	1243
1260	4	-43695	Polerad	\N	1	1	-1260	\N	C	2019-12-20 22:13:53.799521+00	1244
1259	4	-43694	Polerad	\N	1	1	-1259	\N	C	2019-12-20 22:13:53.799521+00	1245
1258	4	-43693	Polerad	\N	1	1	-1258	\N	C	2019-12-20 22:13:53.799521+00	1246
1257	4	-43692	Rabbad	\N	1	1	-1257	\N	C	2019-12-20 22:13:53.799521+00	1247
1256	4	-43690	glättad	\N	1	1	-1256	\N	C	2019-12-20 22:13:53.799521+00	1248
1255	4	-43689	glättad	\N	1	1	-1255	\N	C	2019-12-20 22:13:53.799521+00	1249
1254	4	-43688	Polerad	\N	1	1	-1254	\N	C	2019-12-20 22:13:53.799521+00	1250
1253	4	-43687	glättad	\N	1	1	-1253	\N	C	2019-12-20 22:13:53.799521+00	1251
1252	4	-43686	glättad	\N	1	1	-1252	\N	C	2019-12-20 22:13:53.799521+00	1252
1251	4	-43685	glättad	\N	1	1	-1251	\N	C	2019-12-20 22:13:53.799521+00	1253
1250	4	-43684	Polerad	\N	1	1	-1250	\N	C	2019-12-20 22:13:53.799521+00	1254
1249	4	-43682	Polerad	\N	1	1	-1249	\N	C	2019-12-20 22:13:53.799521+00	1255
1248	4	-43680	glättad	\N	1	1	-1248	\N	C	2019-12-20 22:13:53.799521+00	1256
1247	4	-43679	Polerad	\N	1	1	-1247	\N	C	2019-12-20 22:13:53.799521+00	1257
1246	4	-43678	glättad	\N	1	1	-1246	\N	C	2019-12-20 22:13:53.799521+00	1258
1245	4	-43677	glättad	\N	1	1	-1245	\N	C	2019-12-20 22:13:53.799521+00	1259
1244	4	-43676	glättad	\N	1	1	-1244	\N	C	2019-12-20 22:13:53.799521+00	1260
1243	4	-43675	glättad	\N	1	1	-1243	\N	C	2019-12-20 22:13:53.799521+00	1261
1242	4	-43674	Polerad	\N	1	1	-1242	\N	C	2019-12-20 22:13:53.799521+00	1262
1241	4	-43673	glättad	\N	1	1	-1241	\N	C	2019-12-20 22:13:53.799521+00	1263
1240	4	-43672	Polerad	\N	1	1	-1240	\N	C	2019-12-20 22:13:53.799521+00	1264
1239	4	-43671	fs	\N	1	1	-1239	\N	C	2019-12-20 22:13:53.799521+00	1265
1238	4	-43670	fs	\N	1	1	-1238	\N	C	2019-12-20 22:13:53.799521+00	1266
1237	4	-43669	fs	\N	1	1	-1237	\N	C	2019-12-20 22:13:53.799521+00	1267
1236	4	-43668	glättad	\N	1	1	-1236	\N	C	2019-12-20 22:13:53.799521+00	1268
1235	4	-43667	Polerad	\N	1	1	-1235	\N	C	2019-12-20 22:13:53.799521+00	1269
1234	4	-43666	glättad	\N	1	1	-1234	\N	C	2019-12-20 22:13:53.799521+00	1270
1233	4	-43664	glättad	\N	1	1	-1233	\N	C	2019-12-20 22:13:53.799521+00	1271
1232	4	-43663	Polerad	\N	1	1	-1232	\N	C	2019-12-20 22:13:53.799521+00	1272
1231	4	-43662	glättad	\N	1	1	-1231	\N	C	2019-12-20 22:13:53.799521+00	1273
1230	4	-43661	glättad	\N	1	1	-1230	\N	C	2019-12-20 22:13:53.799521+00	1274
1229	4	-43660	Polerad	\N	1	1	-1229	\N	C	2019-12-20 22:13:53.799521+00	1275
1228	4	-43658	Polerad	\N	1	1	-1228	\N	C	2019-12-20 22:13:53.799521+00	1276
1227	4	-43657	glättad	\N	1	1	-1227	\N	C	2019-12-20 22:13:53.799521+00	1277
1226	4	-43656	glättad	\N	1	1	-1226	\N	C	2019-12-20 22:13:53.799521+00	1278
1225	4	-43655	Polerad	\N	1	1	-1225	\N	C	2019-12-20 22:13:53.799521+00	1279
1224	4	-43654	glättad	\N	1	1	-1224	\N	C	2019-12-20 22:13:53.799521+00	1280
1223	4	-43652	glättad	\N	1	1	-1223	\N	C	2019-12-20 22:13:53.799521+00	1281
1222	4	-43651	Polerad	\N	1	1	-1222	\N	C	2019-12-20 22:13:53.799521+00	1282
1221	4	-43650	glättad	\N	1	1	-1221	\N	C	2019-12-20 22:13:53.799521+00	1283
1220	4	-43649	glättad	\N	1	1	-1220	\N	C	2019-12-20 22:13:53.799521+00	1284
1219	4	-43648	glättad	\N	1	1	-1219	\N	C	2019-12-20 22:13:53.799521+00	1285
1218	4	-43647	glättad	\N	1	1	-1218	\N	C	2019-12-20 22:13:53.799521+00	1286
1217	4	-43646	Polerad	\N	1	1	-1217	\N	C	2019-12-20 22:13:53.799521+00	1287
1216	4	-43645	glättad	\N	1	1	-1216	\N	C	2019-12-20 22:13:53.799521+00	1288
1215	4	-43644	Rabbad	\N	1	1	-1215	\N	C	2019-12-20 22:13:53.799521+00	1289
1214	4	-43643	Rabbad	\N	1	1	-1214	\N	C	2019-12-20 22:13:53.799521+00	1290
1213	4	-43641	Polerad	\N	1	1	-1213	\N	C	2019-12-20 22:13:53.799521+00	1291
1212	4	-43640	Rabbad	\N	1	1	-1212	\N	C	2019-12-20 22:13:53.799521+00	1292
1211	4	-43639	glättad	\N	1	1	-1211	\N	C	2019-12-20 22:13:53.799521+00	1293
1210	4	-43637	glättad	\N	1	1	-1210	\N	C	2019-12-20 22:13:53.799521+00	1294
1209	4	-43636	Rabbad	\N	1	1	-1209	\N	C	2019-12-20 22:13:53.799521+00	1295
1208	4	-43635	glättad	\N	1	1	-1208	\N	C	2019-12-20 22:13:53.799521+00	1296
1207	4	-43634	Polerad	\N	1	1	-1207	\N	C	2019-12-20 22:13:53.799521+00	1297
1206	4	-43633	glättad	\N	1	1	-1206	\N	C	2019-12-20 22:13:53.799521+00	1298
1205	4	-43632	glättad	\N	1	1	-1205	\N	C	2019-12-20 22:13:53.799521+00	1299
1204	4	-43631	Polerad	\N	1	1	-1204	\N	C	2019-12-20 22:13:53.799521+00	1300
1203	4	-43630	Polerad	\N	1	1	-1203	\N	C	2019-12-20 22:13:53.799521+00	1301
1202	4	-43629	glättad	\N	1	1	-1202	\N	C	2019-12-20 22:13:53.799521+00	1302
1201	4	-43628	Polerad	\N	1	1	-1201	\N	C	2019-12-20 22:13:53.799521+00	1303
1200	4	-43627	glättad	\N	1	1	-1200	\N	C	2019-12-20 22:13:53.799521+00	1304
1199	4	-43626	glättad	\N	1	1	-1199	\N	C	2019-12-20 22:13:53.799521+00	1305
1198	4	-43625	Polerad	\N	1	1	-1198	\N	C	2019-12-20 22:13:53.799521+00	1306
1197	4	-43624	glättad	\N	1	1	-1197	\N	C	2019-12-20 22:13:53.799521+00	1307
1196	4	-43623	Polerad	\N	1	1	-1196	\N	C	2019-12-20 22:13:53.799521+00	1308
1195	4	-43622	glättad	\N	1	1	-1195	\N	C	2019-12-20 22:13:53.799521+00	1309
1194	4	-43621	Rabbad	\N	1	1	-1194	\N	C	2019-12-20 22:13:53.799521+00	1310
1193	4	-43620	glättad	\N	1	1	-1193	\N	C	2019-12-20 22:13:53.799521+00	1311
1192	4	-43618	glättad	\N	1	1	-1192	\N	C	2019-12-20 22:13:53.799521+00	1312
1191	4	-43617	Rabbad	\N	1	1	-1191	\N	C	2019-12-20 22:13:53.799521+00	1313
1190	4	-43616	glättad	\N	1	1	-1190	\N	C	2019-12-20 22:13:53.799521+00	1314
1189	4	-43615	glättad	\N	1	1	-1189	\N	C	2019-12-20 22:13:53.799521+00	1315
1188	4	-43614	glättad	\N	1	1	-1188	\N	C	2019-12-20 22:13:53.799521+00	1316
1187	4	-43613	Rabbad	\N	1	1	-1187	\N	C	2019-12-20 22:13:53.799521+00	1317
1186	4	-43612	glättad	\N	1	1	-1186	\N	C	2019-12-20 22:13:53.799521+00	1318
1185	4	-43611	Polerad	\N	1	1	-1185	\N	C	2019-12-20 22:13:53.799521+00	1319
1184	4	-43610	glättad	\N	1	1	-1184	\N	C	2019-12-20 22:13:53.799521+00	1320
1183	4	-43609	glättad	\N	1	1	-1183	\N	C	2019-12-20 22:13:53.799521+00	1321
1182	4	-43608	glättad	\N	1	1	-1182	\N	C	2019-12-20 22:13:53.799521+00	1322
1181	4	-43607	glättad	\N	1	1	-1181	\N	C	2019-12-20 22:13:53.799521+00	1323
1180	4	-43606	glättad	\N	1	1	-1180	\N	C	2019-12-20 22:13:53.799521+00	1324
1179	4	-43605	Polerad	\N	1	1	-1179	\N	C	2019-12-20 22:13:53.799521+00	1325
1178	4	-43604	glättad	\N	1	1	-1178	\N	C	2019-12-20 22:13:53.799521+00	1326
1177	4	-43603	Polerad	\N	1	1	-1177	\N	C	2019-12-20 22:13:53.799521+00	1327
1176	4	-43602	glättad	\N	1	1	-1176	\N	C	2019-12-20 22:13:53.799521+00	1328
1175	4	-43601	glättad	\N	1	1	-1175	\N	C	2019-12-20 22:13:53.799521+00	1329
1174	4	-43600	glättad	\N	1	1	-1174	\N	C	2019-12-20 22:13:53.799521+00	1330
1173	4	-43599	glättad	\N	1	1	-1173	\N	C	2019-12-20 22:13:53.799521+00	1331
1172	4	-43598	glättad	\N	1	1	-1172	\N	C	2019-12-20 22:13:53.799521+00	1332
1171	4	-43597	fs	\N	1	1	-1171	\N	C	2019-12-20 22:13:53.799521+00	1333
1170	4	-43596	glättad	\N	1	1	-1170	\N	C	2019-12-20 22:13:53.799521+00	1334
1169	4	-43595	Polerad	\N	1	1	-1169	\N	C	2019-12-20 22:13:53.799521+00	1335
1168	4	-43594	glättad	\N	1	1	-1168	\N	C	2019-12-20 22:13:53.799521+00	1336
1167	4	-43589	glättad	\N	1	1	-1167	\N	C	2019-12-20 22:13:53.799521+00	1337
1166	4	-43588	glättad	\N	1	1	-1166	\N	C	2019-12-20 22:13:53.799521+00	1338
1165	4	-43587	Polerad	\N	1	1	-1165	\N	C	2019-12-20 22:13:53.799521+00	1339
1164	4	-43586	Polerad	\N	1	1	-1164	\N	C	2019-12-20 22:13:53.799521+00	1340
1163	4	-43585	glättad	\N	1	1	-1163	\N	C	2019-12-20 22:13:53.799521+00	1341
1162	4	-43584	Polerad	\N	1	1	-1162	\N	C	2019-12-20 22:13:53.799521+00	1342
1161	4	-43583	Polerad	\N	1	1	-1161	\N	C	2019-12-20 22:13:53.799521+00	1343
1160	4	-43582	glättad	\N	1	1	-1160	\N	C	2019-12-20 22:13:53.799521+00	1344
1159	4	-43581	glättad	\N	1	1	-1159	\N	C	2019-12-20 22:13:53.799521+00	1345
1158	4	-43580	Rabbad	\N	1	1	-1158	\N	C	2019-12-20 22:13:53.799521+00	1346
1157	4	-43579	glättad	\N	1	1	-1157	\N	C	2019-12-20 22:13:53.799521+00	1347
1156	4	-43578	Polerad	\N	1	1	-1156	\N	C	2019-12-20 22:13:53.799521+00	1348
1155	4	-43577	Rabbad	\N	1	1	-1155	\N	C	2019-12-20 22:13:53.799521+00	1349
1154	4	-43576	Polerad	\N	1	1	-1154	\N	C	2019-12-20 22:13:53.799521+00	1350
1153	4	-43575	Polerad	\N	1	1	-1153	\N	C	2019-12-20 22:13:53.799521+00	1351
1152	4	-43573	glättad	\N	1	1	-1152	\N	C	2019-12-20 22:13:53.799521+00	1352
1151	4	-43572	Polerad	\N	1	1	-1151	\N	C	2019-12-20 22:13:53.799521+00	1353
1150	4	-43571	Polerad	\N	1	1	-1150	\N	C	2019-12-20 22:13:53.799521+00	1354
1149	4	-43570	obehandlad	\N	1	1	-1149	\N	C	2019-12-20 22:13:53.799521+00	1355
1148	4	-43569	Polerad	\N	1	1	-1148	\N	C	2019-12-20 22:13:53.799521+00	1356
1147	4	-43568	glättad	\N	1	1	-1147	\N	C	2019-12-20 22:13:53.799521+00	1357
1146	4	-43567	glättad	\N	1	1	-1146	\N	C	2019-12-20 22:13:53.799521+00	1358
1145	4	-43566	glättad	\N	1	1	-1145	\N	C	2019-12-20 22:13:53.799521+00	1359
1144	4	-43565	Polerad	\N	1	1	-1144	\N	C	2019-12-20 22:13:53.799521+00	1360
1143	4	-43564	glättad	\N	1	1	-1143	\N	C	2019-12-20 22:13:53.799521+00	1361
1142	4	-43563	glättad	\N	1	1	-1142	\N	C	2019-12-20 22:13:53.799521+00	1362
1141	4	-43562	glättad	\N	1	1	-1141	\N	C	2019-12-20 22:13:53.799521+00	1363
1140	4	-43561	Polerad	\N	1	1	-1140	\N	C	2019-12-20 22:13:53.799521+00	1364
1139	4	-43560	Polerad	\N	1	1	-1139	\N	C	2019-12-20 22:13:53.799521+00	1365
1138	4	-43559	glättad	\N	1	1	-1138	\N	C	2019-12-20 22:13:53.799521+00	1366
1137	4	-43558	glättad	\N	1	1	-1137	\N	C	2019-12-20 22:13:53.799521+00	1367
1136	4	-43557	Polerad	\N	1	1	-1136	\N	C	2019-12-20 22:13:53.799521+00	1368
1135	4	-43556	glättad	\N	1	1	-1135	\N	C	2019-12-20 22:13:53.799521+00	1369
1134	4	-43555	Polerad	\N	1	1	-1134	\N	C	2019-12-20 22:13:53.799521+00	1370
1133	4	-43554	glättad	\N	1	1	-1133	\N	C	2019-12-20 22:13:53.799521+00	1371
1132	4	-43553	glättad	\N	1	1	-1132	\N	C	2019-12-20 22:13:53.799521+00	1372
1131	4	-43552	Polerad	\N	1	1	-1131	\N	C	2019-12-20 22:13:53.799521+00	1373
1130	4	-43551	Polerad	\N	1	1	-1130	\N	C	2019-12-20 22:13:53.799521+00	1374
1129	4	-43550	Rabbad	\N	1	1	-1129	\N	C	2019-12-20 22:13:53.799521+00	1375
1128	4	-43549	glättad	\N	1	1	-1128	\N	C	2019-12-20 22:13:53.799521+00	1376
1127	4	-43548	Polerad	\N	1	1	-1127	\N	C	2019-12-20 22:13:53.799521+00	1377
1126	4	-43546	glättad	\N	1	1	-1126	\N	C	2019-12-20 22:13:53.799521+00	1378
1125	4	-43545	glättad	\N	1	1	-1125	\N	C	2019-12-20 22:13:53.799521+00	1379
1124	4	-43544	glättad	\N	1	1	-1124	\N	C	2019-12-20 22:13:53.799521+00	1380
1123	4	-43542	glättad	\N	1	1	-1123	\N	C	2019-12-20 22:13:53.799521+00	1381
1122	4	-43541	glättad	\N	1	1	-1122	\N	C	2019-12-20 22:13:53.799521+00	1382
1121	4	-43540	Rabbad	\N	1	1	-1121	\N	C	2019-12-20 22:13:53.799521+00	1383
1120	4	-43539	Polerad	\N	1	1	-1120	\N	C	2019-12-20 22:13:53.799521+00	1384
1119	4	-43538	glättad	\N	1	1	-1119	\N	C	2019-12-20 22:13:53.799521+00	1385
1118	4	-43537	Polerad	\N	1	1	-1118	\N	C	2019-12-20 22:13:53.799521+00	1386
1117	4	-43536	Polerad	\N	1	1	-1117	\N	C	2019-12-20 22:13:53.799521+00	1387
1116	4	-43535	Polerad	\N	1	1	-1116	\N	C	2019-12-20 22:13:53.799521+00	1388
1115	4	-43534	glättad	\N	1	1	-1115	\N	C	2019-12-20 22:13:53.799521+00	1389
1114	4	-43533	Rabbad	\N	1	1	-1114	\N	C	2019-12-20 22:13:53.799521+00	1390
1113	4	-43532	glättad	\N	1	1	-1113	\N	C	2019-12-20 22:13:53.799521+00	1391
1112	4	-43531	Rabbad	\N	1	1	-1112	\N	C	2019-12-20 22:13:53.799521+00	1392
1111	4	-43530	glättad	\N	1	1	-1111	\N	C	2019-12-20 22:13:53.799521+00	1393
1110	4	-43529	glättad	\N	1	1	-1110	\N	C	2019-12-20 22:13:53.799521+00	1394
1109	4	-43528	glättad	\N	1	1	-1109	\N	C	2019-12-20 22:13:53.799521+00	1395
1108	4	-43527	glättad	\N	1	1	-1108	\N	C	2019-12-20 22:13:53.799521+00	1396
1107	4	-43526	glättad	\N	1	1	-1107	\N	C	2019-12-20 22:13:53.799521+00	1397
1106	4	-43525	glättad	\N	1	1	-1106	\N	C	2019-12-20 22:13:53.799521+00	1398
1105	4	-43524	glättad	\N	1	1	-1105	\N	C	2019-12-20 22:13:53.799521+00	1399
1104	4	-43523	semirabbad	\N	1	1	-1104	\N	C	2019-12-20 22:13:53.799521+00	1400
1103	4	-43522	glättad	\N	1	1	-1103	\N	C	2019-12-20 22:13:53.799521+00	1401
1102	4	-43521	Rabbad	\N	1	1	-1102	\N	C	2019-12-20 22:13:53.799521+00	1402
1101	4	-43520	glättad	\N	1	1	-1101	\N	C	2019-12-20 22:13:53.799521+00	1403
1100	4	-43519	glättad	\N	1	1	-1100	\N	C	2019-12-20 22:13:53.799521+00	1404
1099	4	-43518	glättad	\N	1	1	-1099	\N	C	2019-12-20 22:13:53.799521+00	1405
1098	4	-43517	glättad	\N	1	1	-1098	\N	C	2019-12-20 22:13:53.799521+00	1406
1097	4	-43516	Rabbad	\N	1	1	-1097	\N	C	2019-12-20 22:13:53.799521+00	1407
1096	4	-43515	glättad	\N	1	1	-1096	\N	C	2019-12-20 22:13:53.799521+00	1408
1095	4	-43514	Polerad	\N	1	1	-1095	\N	C	2019-12-20 22:13:53.799521+00	1409
1094	4	-43513	Polerad	\N	1	1	-1094	\N	C	2019-12-20 22:13:53.799521+00	1410
1093	4	-43512	Polerad	\N	1	1	-1093	\N	C	2019-12-20 22:13:53.799521+00	1411
1092	4	-43511	glättad	\N	1	1	-1092	\N	C	2019-12-20 22:13:53.799521+00	1412
1091	4	-43510	Polerad	\N	1	1	-1091	\N	C	2019-12-20 22:13:53.799521+00	1413
1090	4	-43509	Polerad	\N	1	1	-1090	\N	C	2019-12-20 22:13:53.799521+00	1414
1089	4	-43508	glättad	\N	1	1	-1089	\N	C	2019-12-20 22:13:53.799521+00	1415
1088	4	-43507	fs	\N	1	1	-1088	\N	C	2019-12-20 22:13:53.799521+00	1416
1087	4	-43506	Rabbad	\N	1	1	-1087	\N	C	2019-12-20 22:13:53.799521+00	1417
1086	4	-43505	Polerad	\N	1	1	-1086	\N	C	2019-12-20 22:13:53.799521+00	1418
1085	4	-43504	Polerad	\N	1	1	-1085	\N	C	2019-12-20 22:13:53.799521+00	1419
1084	4	-43503	Polerad	\N	1	1	-1084	\N	C	2019-12-20 22:13:53.799521+00	1420
1083	4	-43502	glättad	\N	1	1	-1083	\N	C	2019-12-20 22:13:53.799521+00	1421
1082	4	-43501	fs	\N	1	1	-1082	\N	C	2019-12-20 22:13:53.799521+00	1422
1081	4	-43500	Rabbad	\N	1	1	-1081	\N	C	2019-12-20 22:13:53.799521+00	1423
1080	4	-43499	glättad	\N	1	1	-1080	\N	C	2019-12-20 22:13:53.799521+00	1424
1079	1	-43497	nej	\N	1	1	-1079	\N	C	2019-12-20 22:13:53.799521+00	1425
1078	4	-43497	Polerad	\N	1	1	-1078	\N	C	2019-12-20 22:13:53.799521+00	1426
1077	1	-43496	nej	\N	1	1	-1077	\N	C	2019-12-20 22:13:53.799521+00	1427
1076	4	-43496	Rabbad	\N	1	1	-1076	\N	C	2019-12-20 22:13:53.799521+00	1428
1075	1	-43495	nej	\N	1	1	-1075	\N	C	2019-12-20 22:13:53.799521+00	1429
1074	4	-43495	glättad	\N	1	1	-1074	\N	C	2019-12-20 22:13:53.799521+00	1430
1073	1	-43494	Dekor	\N	1	1	-1073	\N	C	2019-12-20 22:13:53.799521+00	1431
1072	4	-43494	glättad	\N	1	1	-1072	\N	C	2019-12-20 22:13:53.799521+00	1432
1071	1	-43493	nej	\N	1	1	-1071	\N	C	2019-12-20 22:13:53.799521+00	1433
1070	4	-43493	glättad	\N	1	1	-1070	\N	C	2019-12-20 22:13:53.799521+00	1434
1069	1	-43492	nej	\N	1	1	-1069	\N	C	2019-12-20 22:13:53.799521+00	1435
1068	4	-43492	Polerad	\N	1	1	-1068	\N	C	2019-12-20 22:13:53.799521+00	1436
1067	1	-43479	Otterböte	\N	1	1	-1067	\N	C	2019-12-20 22:13:53.799521+00	1437
1066	4	-43479	Rabbad	\N	1	1	-1066	\N	C	2019-12-20 22:13:53.799521+00	1438
1065	1	-43477	nej	\N	1	1	-1065	\N	C	2019-12-20 22:13:53.799521+00	1439
1064	4	-43477	Rabbad	\N	1	1	-1064	\N	C	2019-12-20 22:13:53.799521+00	1440
1063	1	-43476	nej	\N	1	1	-1063	\N	C	2019-12-20 22:13:53.799521+00	1441
1062	4	-43476	Rabbad	\N	1	1	-1062	\N	C	2019-12-20 22:13:53.799521+00	1442
1061	1	-43475	nej	\N	1	1	-1061	\N	C	2019-12-20 22:13:53.799521+00	1443
1060	4	-43475	Avstruken	\N	1	1	-1060	\N	C	2019-12-20 22:13:53.799521+00	1444
1059	1	-43474	nej	\N	1	1	-1059	\N	C	2019-12-20 22:13:53.799521+00	1445
1058	4	-43474	Rabbad	\N	1	1	-1058	\N	C	2019-12-20 22:13:53.799521+00	1446
1057	1	-43473	Otterböte	\N	1	1	-1057	\N	C	2019-12-20 22:13:53.799521+00	1447
1056	4	-43473	Rabbad	\N	1	1	-1056	\N	C	2019-12-20 22:13:53.799521+00	1448
1055	1	-43472	nej	\N	1	1	-1055	\N	C	2019-12-20 22:13:53.799521+00	1449
1054	4	-43472	Rabbad	\N	1	1	-1054	\N	C	2019-12-20 22:13:53.799521+00	1450
1053	1	-43471	nej	\N	1	1	-1053	\N	C	2019-12-20 22:13:53.799521+00	1451
1052	4	-43471	Polerad	\N	1	1	-1052	\N	C	2019-12-20 22:13:53.799521+00	1452
1051	1	-43470	nej	\N	1	1	-1051	\N	C	2019-12-20 22:13:53.799521+00	1453
1050	4	-43470	Polerad	\N	1	1	-1050	\N	C	2019-12-20 22:13:53.799521+00	1454
1049	1	-43469	nej	\N	1	1	-1049	\N	C	2019-12-20 22:13:53.799521+00	1455
1048	4	-43469	Polerad	\N	1	1	-1048	\N	C	2019-12-20 22:13:53.799521+00	1456
1047	1	-43468	nej	\N	1	1	-1047	\N	C	2019-12-20 22:13:53.799521+00	1457
1046	4	-43468	Polerad	\N	1	1	-1046	\N	C	2019-12-20 22:13:53.799521+00	1458
1045	1	-43467	Otterböte	\N	1	1	-1045	\N	C	2019-12-20 22:13:53.799521+00	1459
1044	4	-43467	Rabbad	\N	1	1	-1044	\N	C	2019-12-20 22:13:53.799521+00	1460
1043	1	-43466	Otterböte	\N	1	1	-1043	\N	C	2019-12-20 22:13:53.799521+00	1461
1042	4	-43466	Rabbad	\N	1	1	-1042	\N	C	2019-12-20 22:13:53.799521+00	1462
1041	1	-43465	Otterböte	\N	1	1	-1041	\N	C	2019-12-20 22:13:53.799521+00	1463
1040	4	-43465	Rabbad	\N	1	1	-1040	\N	C	2019-12-20 22:13:53.799521+00	1464
1039	1	-43464	nej	\N	1	1	-1039	\N	C	2019-12-20 22:13:53.799521+00	1465
1038	4	-43464	Rabbad	\N	1	1	-1038	\N	C	2019-12-20 22:13:53.799521+00	1466
1037	1	-43463	nej	\N	1	1	-1037	\N	C	2019-12-20 22:13:53.799521+00	1467
1036	4	-43463	Rabbad	\N	1	1	-1036	\N	C	2019-12-20 22:13:53.799521+00	1468
1035	1	-43462	Otterböte	\N	1	1	-1035	\N	C	2019-12-20 22:13:53.799521+00	1469
1034	4	-43462	Rabbad	\N	1	1	-1034	\N	C	2019-12-20 22:13:53.799521+00	1470
1033	1	-43461	nej	\N	1	1	-1033	\N	C	2019-12-20 22:13:53.799521+00	1471
1032	4	-43461	Rabbad	\N	1	1	-1032	\N	C	2019-12-20 22:13:53.799521+00	1472
1031	1	-43460	nej	\N	1	1	-1031	\N	C	2019-12-20 22:13:53.799521+00	1473
1030	4	-43460	Polerad	\N	1	1	-1030	\N	C	2019-12-20 22:13:53.799521+00	1474
1029	1	-43459	nej	\N	1	1	-1029	\N	C	2019-12-20 22:13:53.799521+00	1475
1028	4	-43459	Polerad	\N	1	1	-1028	\N	C	2019-12-20 22:13:53.799521+00	1476
1027	1	-43458	nej	\N	1	1	-1027	\N	C	2019-12-20 22:13:53.799521+00	1477
1026	4	-43458	Polerad	\N	1	1	-1026	\N	C	2019-12-20 22:13:53.799521+00	1478
1025	1	-43457	nej	\N	1	1	-1025	\N	C	2019-12-20 22:13:53.799521+00	1479
1024	4	-43457	Polerad	\N	1	1	-1024	\N	C	2019-12-20 22:13:53.799521+00	1480
1023	1	-43456	nej	\N	1	1	-1023	\N	C	2019-12-20 22:13:53.799521+00	1481
1022	4	-43456	Polerad	\N	1	1	-1022	\N	C	2019-12-20 22:13:53.799521+00	1482
1021	1	-43455	nej	\N	1	1	-1021	\N	C	2019-12-20 22:13:53.799521+00	1483
1020	4	-43455	Polerad	\N	1	1	-1020	\N	C	2019-12-20 22:13:53.799521+00	1484
1019	1	-43454	nej	\N	1	1	-1019	\N	C	2019-12-20 22:13:53.799521+00	1485
1018	4	-43454	Polerad	\N	1	1	-1018	\N	C	2019-12-20 22:13:53.799521+00	1486
1017	1	-43453	nej	\N	1	1	-1017	\N	C	2019-12-20 22:13:53.799521+00	1487
1016	4	-43453	Polerad	\N	1	1	-1016	\N	C	2019-12-20 22:13:53.799521+00	1488
1015	1	-43452	nej	\N	1	1	-1015	\N	C	2019-12-20 22:13:53.799521+00	1489
1014	4	-43452	Polerad	\N	1	1	-1014	\N	C	2019-12-20 22:13:53.799521+00	1490
1013	1	-43451	kannelerad	\N	1	1	-1013	\N	C	2019-12-20 22:13:53.799521+00	1491
1012	4	-43451	Polerad	\N	1	1	-1012	\N	C	2019-12-20 22:13:53.799521+00	1492
1011	1	-43450	kannelerad	\N	1	1	-1011	\N	C	2019-12-20 22:13:53.799521+00	1493
1010	4	-43450	Polerad	\N	1	1	-1010	\N	C	2019-12-20 22:13:53.799521+00	1494
1009	1	-43449	kannelerad	\N	1	1	-1009	\N	C	2019-12-20 22:13:53.799521+00	1495
1008	4	-43449	Polerad	\N	1	1	-1008	\N	C	2019-12-20 22:13:53.799521+00	1496
1007	1	-43448	kannelerad	\N	1	1	-1007	\N	C	2019-12-20 22:13:53.799521+00	1497
1006	4	-43448	Polerad	\N	1	1	-1006	\N	C	2019-12-20 22:13:53.799521+00	1498
1005	1	-43447	kannelerad	\N	1	1	-1005	\N	C	2019-12-20 22:13:53.799521+00	1499
1004	4	-43447	Polerad	\N	1	1	-1004	\N	C	2019-12-20 22:13:53.799521+00	1500
1003	1	-43446	kannelerad	\N	1	1	-1003	\N	C	2019-12-20 22:13:53.799521+00	1501
1002	4	-43446	Polerad	\N	1	1	-1002	\N	C	2019-12-20 22:13:53.799521+00	1502
1001	1	-43445	kannelerad	\N	1	1	-1001	\N	C	2019-12-20 22:13:53.799521+00	1503
1000	4	-43445	Polerad	\N	1	1	-1000	\N	C	2019-12-20 22:13:53.799521+00	1504
999	1	-43444	kannelerad	\N	1	1	-999	\N	C	2019-12-20 22:13:53.799521+00	1505
998	4	-43444	Polerad	\N	1	1	-998	\N	C	2019-12-20 22:13:53.799521+00	1506
997	1	-43400	nej	\N	1	1	-997	\N	C	2019-12-20 22:13:53.799521+00	1507
996	1	-43399	nej	\N	1	1	-996	\N	C	2019-12-20 22:13:53.799521+00	1508
995	1	-43398	nej	\N	1	1	-995	\N	C	2019-12-20 22:13:53.799521+00	1509
994	1	-43397	nej	\N	1	1	-994	\N	C	2019-12-20 22:13:53.799521+00	1510
993	1	-43396	nej	\N	1	1	-993	\N	C	2019-12-20 22:13:53.799521+00	1511
992	1	-43395	Dekor	\N	1	1	-992	\N	C	2019-12-20 22:13:53.799521+00	1512
991	1	-43394	Dekor	\N	1	1	-991	\N	C	2019-12-20 22:13:53.799521+00	1513
990	1	-43393	Dekor	\N	1	1	-990	\N	C	2019-12-20 22:13:53.799521+00	1514
989	1	-43392	Dekor	\N	1	1	-989	\N	C	2019-12-20 22:13:53.799521+00	1515
988	1	-43391	Dekor	\N	1	1	-988	\N	C	2019-12-20 22:13:53.799521+00	1516
987	1	-43336	nej	\N	1	1	-987	\N	C	2019-12-20 22:13:53.799521+00	1517
986	1	-43335	nej	\N	1	1	-986	\N	C	2019-12-20 22:13:53.799521+00	1518
985	1	-43334	nej	\N	1	1	-985	\N	C	2019-12-20 22:13:53.799521+00	1519
984	1	-43333	nej	\N	1	1	-984	\N	C	2019-12-20 22:13:53.799521+00	1520
983	1	-43332	nej	\N	1	1	-983	\N	C	2019-12-20 22:13:53.799521+00	1521
982	1	-43331	nej	\N	1	1	-982	\N	C	2019-12-20 22:13:53.799521+00	1522
981	1	-43330	nej	\N	1	1	-981	\N	C	2019-12-20 22:13:53.799521+00	1523
980	1	-43329	nej	\N	1	1	-980	\N	C	2019-12-20 22:13:53.799521+00	1524
979	1	-43328	nej	\N	1	1	-979	\N	C	2019-12-20 22:13:53.799521+00	1525
978	1	-43327	halsring	\N	1	1	-978	\N	C	2019-12-20 22:13:53.799521+00	1526
977	2	-43327	Mynning	\N	1	1	-977	\N	C	2019-12-20 22:13:53.799521+00	1527
976	1	-43326	Dekor	\N	1	1	-976	\N	C	2019-12-20 22:13:53.799521+00	1528
975	1	-43325	Dekor	\N	1	1	-975	\N	C	2019-12-20 22:13:53.799521+00	1529
974	1	-43324	Dekor	\N	1	1	-974	\N	C	2019-12-20 22:13:53.799521+00	1530
973	1	-43315	nej	\N	1	1	-973	\N	C	2019-12-20 22:13:53.799521+00	1531
972	4	-43315	glättad	\N	1	1	-972	\N	C	2019-12-20 22:13:53.799521+00	1532
971	1	-43314	nej	\N	1	1	-971	\N	C	2019-12-20 22:13:53.799521+00	1533
970	4	-43314	Strierad/strimmig	\N	1	1	-970	\N	C	2019-12-20 22:13:53.799521+00	1534
969	1	-43313	nej	\N	1	1	-969	\N	C	2019-12-20 22:13:53.799521+00	1535
968	4	-43313	glättad	\N	1	1	-968	\N	C	2019-12-20 22:13:53.799521+00	1536
967	1	-43312	nej	\N	1	1	-967	\N	C	2019-12-20 22:13:53.799521+00	1537
966	4	-43312	glättad	\N	1	1	-966	\N	C	2019-12-20 22:13:53.799521+00	1538
965	1	-43311	nej	\N	1	1	-965	\N	C	2019-12-20 22:13:53.799521+00	1539
964	4	-43311	glättad	\N	1	1	-964	\N	C	2019-12-20 22:13:53.799521+00	1540
963	1	-43310	nej	\N	1	1	-963	\N	C	2019-12-20 22:13:53.799521+00	1541
962	4	-43310	Avstruken	\N	1	1	-962	\N	C	2019-12-20 22:13:53.799521+00	1542
961	1	-43309	nej	\N	1	1	-961	\N	C	2019-12-20 22:13:53.799521+00	1543
960	4	-43309	Avstruken	\N	1	1	-960	\N	C	2019-12-20 22:13:53.799521+00	1544
959	1	-43308	nej	\N	1	1	-959	\N	C	2019-12-20 22:13:53.799521+00	1545
958	4	-43308	glättad	\N	1	1	-958	\N	C	2019-12-20 22:13:53.799521+00	1546
957	1	-43291	nej	\N	1	1	-957	\N	C	2019-12-20 22:13:53.799521+00	1547
956	2	-43291	Mynning	\N	1	1	-956	\N	C	2019-12-20 22:13:53.799521+00	1548
955	1	-43290	Dekor	\N	1	1	-955	\N	C	2019-12-20 22:13:53.799521+00	1549
954	2	-43290	Mynning	\N	1	1	-954	\N	C	2019-12-20 22:13:53.799521+00	1550
953	1	-43289	Dekor	\N	1	1	-953	\N	C	2019-12-20 22:13:53.799521+00	1551
952	2	-43289	Mynning	\N	1	1	-952	\N	C	2019-12-20 22:13:53.799521+00	1552
951	1	-43288	Dekor	\N	1	1	-951	\N	C	2019-12-20 22:13:53.799521+00	1553
950	2	-43288	Mynning	\N	1	1	-950	\N	C	2019-12-20 22:13:53.799521+00	1554
949	1	-43287	nej	\N	1	1	-949	\N	C	2019-12-20 22:13:53.799521+00	1555
948	2	-43287	Mynning	\N	1	1	-948	\N	C	2019-12-20 22:13:53.799521+00	1556
947	1	-43286	nej	\N	1	1	-947	\N	C	2019-12-20 22:13:53.799521+00	1557
946	2	-43286	Mynning	\N	1	1	-946	\N	C	2019-12-20 22:13:53.799521+00	1558
945	1	-43285	Dekor	\N	1	1	-945	\N	C	2019-12-20 22:13:53.799521+00	1559
944	2	-43285	Mynning	\N	1	1	-944	\N	C	2019-12-20 22:13:53.799521+00	1560
943	1	-43284	Dekor	\N	1	1	-943	\N	C	2019-12-20 22:13:53.799521+00	1561
942	1	-43283	Dekor	\N	1	1	-942	\N	C	2019-12-20 22:13:53.799521+00	1562
941	1	-43282	nej	\N	1	1	-941	\N	C	2019-12-20 22:13:53.799521+00	1563
940	2	-43282	Mynning	\N	1	1	-940	\N	C	2019-12-20 22:13:53.799521+00	1564
939	1	-43281	nej	\N	1	1	-939	\N	C	2019-12-20 22:13:53.799521+00	1565
938	2	-43281	Mynning	\N	1	1	-938	\N	C	2019-12-20 22:13:53.799521+00	1566
937	1	-43280	Dekor	\N	1	1	-937	\N	C	2019-12-20 22:13:53.799521+00	1567
936	1	-43279	Dekor	\N	1	1	-936	\N	C	2019-12-20 22:13:53.799521+00	1568
935	1	-43278	Dekor	\N	1	1	-935	\N	C	2019-12-20 22:13:53.799521+00	1569
934	1	-43277	nej	\N	1	1	-934	\N	C	2019-12-20 22:13:53.799521+00	1570
933	2	-43277	Mynning	\N	1	1	-933	\N	C	2019-12-20 22:13:53.799521+00	1571
932	1	-43276	Dekor	\N	1	1	-932	\N	C	2019-12-20 22:13:53.799521+00	1572
931	1	-43275	nej	\N	1	1	-931	\N	C	2019-12-20 22:13:53.799521+00	1573
930	2	-43275	Mynning	\N	1	1	-930	\N	C	2019-12-20 22:13:53.799521+00	1574
929	1	-43274	Dekor	\N	1	1	-929	\N	C	2019-12-20 22:13:53.799521+00	1575
928	2	-43274	Mynning	\N	1	1	-928	\N	C	2019-12-20 22:13:53.799521+00	1576
927	1	-43273	Dekor	\N	1	1	-927	\N	C	2019-12-20 22:13:53.799521+00	1577
926	1	-43272	Dekor	\N	1	1	-926	\N	C	2019-12-20 22:13:53.799521+00	1578
925	2	-43272	Mynning	\N	1	1	-925	\N	C	2019-12-20 22:13:53.799521+00	1579
924	1	-43271	nej	\N	1	1	-924	\N	C	2019-12-20 22:13:53.799521+00	1580
923	2	-43271	Mynning	\N	1	1	-923	\N	C	2019-12-20 22:13:53.799521+00	1581
922	1	-43270	Dekor	\N	1	1	-922	\N	C	2019-12-20 22:13:53.799521+00	1582
921	2	-43270	Mynning	\N	1	1	-921	\N	C	2019-12-20 22:13:53.799521+00	1583
920	1	-43269	Dekor	\N	1	1	-920	\N	C	2019-12-20 22:13:53.799521+00	1584
919	2	-43269	Mynning	\N	1	1	-919	\N	C	2019-12-20 22:13:53.799521+00	1585
918	1	-43268	Dekor	\N	1	1	-918	\N	C	2019-12-20 22:13:53.799521+00	1586
917	1	-43267	nej	\N	1	1	-917	\N	C	2019-12-20 22:13:53.799521+00	1587
916	2	-43267	Mynning	\N	1	1	-916	\N	C	2019-12-20 22:13:53.799521+00	1588
915	1	-43266	Dekor	\N	1	1	-915	\N	C	2019-12-20 22:13:53.799521+00	1589
914	1	-43265	nej	\N	1	1	-914	\N	C	2019-12-20 22:13:53.799521+00	1590
913	1	-43264	nej	\N	1	1	-913	\N	C	2019-12-20 22:13:53.799521+00	1591
912	1	-43263	Dekor	\N	1	1	-912	\N	C	2019-12-20 22:13:53.799521+00	1592
911	1	-43262	nej	\N	1	1	-911	\N	C	2019-12-20 22:13:53.799521+00	1593
910	1	-43261	Dekor	\N	1	1	-910	\N	C	2019-12-20 22:13:53.799521+00	1594
909	1	-43260	Dekor	\N	1	1	-909	\N	C	2019-12-20 22:13:53.799521+00	1595
908	1	-43259	nej	\N	1	1	-908	\N	C	2019-12-20 22:13:53.799521+00	1596
907	4	-43259	Rabbad	\N	1	1	-907	\N	C	2019-12-20 22:13:53.799521+00	1597
906	1	-43258	nej	\N	1	1	-906	\N	C	2019-12-20 22:13:53.799521+00	1598
905	4	-43258	Rabbad	\N	1	1	-905	\N	C	2019-12-20 22:13:53.799521+00	1599
904	1	-43257	nej	\N	1	1	-904	\N	C	2019-12-20 22:13:53.799521+00	1600
903	4	-43257	Rabbad	\N	1	1	-903	\N	C	2019-12-20 22:13:53.799521+00	1601
902	1	-43256	nej	\N	1	1	-902	\N	C	2019-12-20 22:13:53.799521+00	1602
901	4	-43256	Rabbad	\N	1	1	-901	\N	C	2019-12-20 22:13:53.799521+00	1603
900	1	-43255	nej	\N	1	1	-900	\N	C	2019-12-20 22:13:53.799521+00	1604
899	1	-43254	nej	\N	1	1	-899	\N	C	2019-12-20 22:13:53.799521+00	1605
898	1	-43253	nej	\N	1	1	-898	\N	C	2019-12-20 22:13:53.799521+00	1606
897	4	-43253	glättad	\N	1	1	-897	\N	C	2019-12-20 22:13:53.799521+00	1607
896	2	-43253	Mynning	\N	1	1	-896	\N	C	2019-12-20 22:13:53.799521+00	1608
895	1	-43252	nej	\N	1	1	-895	\N	C	2019-12-20 22:13:53.799521+00	1609
894	4	-43252	glättad	\N	1	1	-894	\N	C	2019-12-20 22:13:53.799521+00	1610
893	1	-43251	nej	\N	1	1	-893	\N	C	2019-12-20 22:13:53.799521+00	1611
892	4	-43251	Rabbad	\N	1	1	-892	\N	C	2019-12-20 22:13:53.799521+00	1612
891	1	-43250	nej	\N	1	1	-891	\N	C	2019-12-20 22:13:53.799521+00	1613
890	1	-43248	Dekor	\N	1	1	-890	\N	C	2019-12-20 22:13:53.799521+00	1614
889	1	-43247	Dekor	\N	1	1	-889	\N	C	2019-12-20 22:13:53.799521+00	1615
888	1	-43246	Dekor	\N	1	1	-888	\N	C	2019-12-20 22:13:53.799521+00	1616
887	1	-43245	Dekor	\N	1	1	-887	\N	C	2019-12-20 22:13:53.799521+00	1617
886	1	-43244	Dekor	\N	1	1	-886	\N	C	2019-12-20 22:13:53.799521+00	1618
885	2	-43244	Mynning	\N	1	1	-885	\N	C	2019-12-20 22:13:53.799521+00	1619
884	1	-43243	Dekor	\N	1	1	-884	\N	C	2019-12-20 22:13:53.799521+00	1620
883	2	-43243	Mynning	\N	1	1	-883	\N	C	2019-12-20 22:13:53.799521+00	1621
882	1	-43242	Dekor	\N	1	1	-882	\N	C	2019-12-20 22:13:53.799521+00	1622
881	2	-43242	Mynning	\N	1	1	-881	\N	C	2019-12-20 22:13:53.799521+00	1623
880	1	-43241	Dekor	\N	1	1	-880	\N	C	2019-12-20 22:13:53.799521+00	1624
879	1	-43240	Dekor	\N	1	1	-879	\N	C	2019-12-20 22:13:53.799521+00	1625
878	1	-43239	nej	\N	1	1	-878	\N	C	2019-12-20 22:13:53.799521+00	1626
877	1	-43238	Dekor	\N	1	1	-877	\N	C	2019-12-20 22:13:53.799521+00	1627
876	1	-43237	Dekor	\N	1	1	-876	\N	C	2019-12-20 22:13:53.799521+00	1628
875	2	-43237	Mynning	\N	1	1	-875	\N	C	2019-12-20 22:13:53.799521+00	1629
874	1	-43236	Dekor	\N	1	1	-874	\N	C	2019-12-20 22:13:53.799521+00	1630
873	1	-43235	Dekor	\N	1	1	-873	\N	C	2019-12-20 22:13:53.799521+00	1631
872	1	-43234	Dekor	\N	1	1	-872	\N	C	2019-12-20 22:13:53.799521+00	1632
871	2	-43234	Mynning	\N	1	1	-871	\N	C	2019-12-20 22:13:53.799521+00	1633
870	1	-43233	Dekor	\N	1	1	-870	\N	C	2019-12-20 22:13:53.799521+00	1634
869	2	-43233	Mynning	\N	1	1	-869	\N	C	2019-12-20 22:13:53.799521+00	1635
868	1	-43232	Dekor	\N	1	1	-868	\N	C	2019-12-20 22:13:53.799521+00	1636
867	1	-43231	Dekor	\N	1	1	-867	\N	C	2019-12-20 22:13:53.799521+00	1637
866	1	-43230	Dekor	\N	1	1	-866	\N	C	2019-12-20 22:13:53.799521+00	1638
865	1	-43229	Dekor	\N	1	1	-865	\N	C	2019-12-20 22:13:53.799521+00	1639
864	1	-43212	Dekor	\N	1	1	-864	\N	C	2019-12-20 22:13:53.799521+00	1640
863	1	-43211	nej	\N	1	1	-863	\N	C	2019-12-20 22:13:53.799521+00	1641
862	1	-43210	nej	\N	1	1	-862	\N	C	2019-12-20 22:13:53.799521+00	1642
861	1	-43209	Dekor	\N	1	1	-861	\N	C	2019-12-20 22:13:53.799521+00	1643
860	1	-43208	Dekor	\N	1	1	-860	\N	C	2019-12-20 22:13:53.799521+00	1644
859	1	-43207	Dekor	\N	1	1	-859	\N	C	2019-12-20 22:13:53.799521+00	1645
858	4	-43200	glättad	\N	1	1	-858	\N	C	2019-12-20 22:13:53.799521+00	1646
857	4	-43199	glättad	\N	1	1	-857	\N	C	2019-12-20 22:13:53.799521+00	1647
856	4	-43198	fs	\N	1	1	-856	\N	C	2019-12-20 22:13:53.799521+00	1648
855	4	-43197	Polerad	\N	1	1	-855	\N	C	2019-12-20 22:13:53.799521+00	1649
854	4	-43196	ra	\N	1	1	-854	\N	C	2019-12-20 22:13:53.799521+00	1650
853	4	-43195	glättad	\N	1	1	-853	\N	C	2019-12-20 22:13:53.799521+00	1651
852	4	-43194	glättad	\N	1	1	-852	\N	C	2019-12-20 22:13:53.799521+00	1652
851	4	-43193	glättad	\N	1	1	-851	\N	C	2019-12-20 22:13:53.799521+00	1653
850	4	-43192	glättad	\N	1	1	-850	\N	C	2019-12-20 22:13:53.799521+00	1654
849	4	-43191	glättad	\N	1	1	-849	\N	C	2019-12-20 22:13:53.799521+00	1655
848	4	-43190	glättad	\N	1	1	-848	\N	C	2019-12-20 22:13:53.799521+00	1656
847	4	-43189	glättad	\N	1	1	-847	\N	C	2019-12-20 22:13:53.799521+00	1657
846	4	-43188	fs	\N	1	1	-846	\N	C	2019-12-20 22:13:53.799521+00	1658
845	4	-43187	fs	\N	1	1	-845	\N	C	2019-12-20 22:13:53.799521+00	1659
844	4	-43186	glättad	\N	1	1	-844	\N	C	2019-12-20 22:13:53.799521+00	1660
843	4	-43185	glättad	\N	1	1	-843	\N	C	2019-12-20 22:13:53.799521+00	1661
842	4	-43184	glättad	\N	1	1	-842	\N	C	2019-12-20 22:13:53.799521+00	1662
841	4	-43183	glättad	\N	1	1	-841	\N	C	2019-12-20 22:13:53.799521+00	1663
840	4	-43182	glättad	\N	1	1	-840	\N	C	2019-12-20 22:13:53.799521+00	1664
839	4	-43181	glättad	\N	1	1	-839	\N	C	2019-12-20 22:13:53.799521+00	1665
838	4	-43180	glättad	\N	1	1	-838	\N	C	2019-12-20 22:13:53.799521+00	1666
837	4	-43179	glättad	\N	1	1	-837	\N	C	2019-12-20 22:13:53.799521+00	1667
836	1	-43178	Dekor	\N	1	1	-836	\N	C	2019-12-20 22:13:53.799521+00	1668
835	1	-43177	nej	\N	1	1	-835	\N	C	2019-12-20 22:13:53.799521+00	1669
834	1	-43176	nej	\N	1	1	-834	\N	C	2019-12-20 22:13:53.799521+00	1670
833	1	-43175	Dekor	\N	1	1	-833	\N	C	2019-12-20 22:13:53.799521+00	1671
832	1	-43174	nej	\N	1	1	-832	\N	C	2019-12-20 22:13:53.799521+00	1672
831	1	-43173	Dekor	\N	1	1	-831	\N	C	2019-12-20 22:13:53.799521+00	1673
830	1	-43172	Dekor	\N	1	1	-830	\N	C	2019-12-20 22:13:53.799521+00	1674
829	1	-43171	Dekor	\N	1	1	-829	\N	C	2019-12-20 22:13:53.799521+00	1675
828	1	-43170	Dekor	\N	1	1	-828	\N	C	2019-12-20 22:13:53.799521+00	1676
827	1	-43169	Dekor	\N	1	1	-827	\N	C	2019-12-20 22:13:53.799521+00	1677
826	1	-43168	Dekor	\N	1	1	-826	\N	C	2019-12-20 22:13:53.799521+00	1678
825	1	-43167	Dekor	\N	1	1	-825	\N	C	2019-12-20 22:13:53.799521+00	1679
824	4	-43164	glättad	\N	1	1	-824	\N	C	2019-12-20 22:13:53.799521+00	1680
823	4	-43163	glättad	\N	1	1	-823	\N	C	2019-12-20 22:13:53.799521+00	1681
822	2	-43163	Mynning	\N	1	1	-822	\N	C	2019-12-20 22:13:53.799521+00	1682
821	1	-43162	nej	\N	1	1	-821	\N	C	2019-12-20 22:13:53.799521+00	1683
820	1	-43161	nej	\N	1	1	-820	\N	C	2019-12-20 22:13:53.799521+00	1684
819	1	-43160	nej	\N	1	1	-819	\N	C	2019-12-20 22:13:53.799521+00	1685
818	4	-43160	glättad	\N	1	1	-818	\N	C	2019-12-20 22:13:53.799521+00	1686
817	1	-43159	nej	\N	1	1	-817	\N	C	2019-12-20 22:13:53.799521+00	1687
816	1	-43158	nej	\N	1	1	-816	\N	C	2019-12-20 22:13:53.799521+00	1688
815	1	-43157	nej	\N	1	1	-815	\N	C	2019-12-20 22:13:53.799521+00	1689
814	1	-43156	nej	\N	1	1	-814	\N	C	2019-12-20 22:13:53.799521+00	1690
813	1	-43155	nej	\N	1	1	-813	\N	C	2019-12-20 22:13:53.799521+00	1691
812	1	-43154	Dekor	\N	1	1	-812	\N	C	2019-12-20 22:13:53.799521+00	1692
811	1	-43153	Dekor	\N	1	1	-811	\N	C	2019-12-20 22:13:53.799521+00	1693
810	1	-43152	Dekor	\N	1	1	-810	\N	C	2019-12-20 22:13:53.799521+00	1694
809	1	-43151	nej	\N	1	1	-809	\N	C	2019-12-20 22:13:53.799521+00	1695
808	1	-43150	Dekor	\N	1	1	-808	\N	C	2019-12-20 22:13:53.799521+00	1696
807	1	-43149	Dekor	\N	1	1	-807	\N	C	2019-12-20 22:13:53.799521+00	1697
806	1	-43148	Dekor	\N	1	1	-806	\N	C	2019-12-20 22:13:53.799521+00	1698
805	1	-43147	nej	\N	1	1	-805	\N	C	2019-12-20 22:13:53.799521+00	1699
804	2	-43147	Hängkärl	\N	1	1	-804	\N	C	2019-12-20 22:13:53.799521+00	1700
803	1	-43146	Dekor	\N	1	1	-803	\N	C	2019-12-20 22:13:53.799521+00	1701
802	2	-43146	LOCK	\N	1	1	-802	\N	C	2019-12-20 22:13:53.799521+00	1702
801	1	-43145	nej	\N	1	1	-801	\N	C	2019-12-20 22:13:53.799521+00	1703
800	2	-43145	LOCK	\N	1	1	-800	\N	C	2019-12-20 22:13:53.799521+00	1704
799	1	-43144	Dekor	\N	1	1	-799	\N	C	2019-12-20 22:13:53.799521+00	1705
798	1	-43136	nej	\N	1	1	-798	\N	C	2019-12-20 22:13:53.799521+00	1706
797	4	-43136	gs	\N	1	1	-797	\N	C	2019-12-20 22:13:53.799521+00	1707
796	1	-43135	Dekor	\N	1	1	-796	\N	C	2019-12-20 22:13:53.799521+00	1708
795	4	-43135	glättad	\N	1	1	-795	\N	C	2019-12-20 22:13:53.799521+00	1709
794	1	-43134	nej	\N	1	1	-794	\N	C	2019-12-20 22:13:53.799521+00	1710
793	1	-43133	Dekor	\N	1	1	-793	\N	C	2019-12-20 22:13:53.799521+00	1711
792	4	-43133	gs	\N	1	1	-792	\N	C	2019-12-20 22:13:53.799521+00	1712
791	1	-43132	Dekor	\N	1	1	-791	\N	C	2019-12-20 22:13:53.799521+00	1713
790	4	-43132	gs	\N	1	1	-790	\N	C	2019-12-20 22:13:53.799521+00	1714
789	1	-43131	Dekor	\N	1	1	-789	\N	C	2019-12-20 22:13:53.799521+00	1715
788	1	-43130	Dekor	\N	1	1	-788	\N	C	2019-12-20 22:13:53.799521+00	1716
787	1	-43129	nej	\N	1	1	-787	\N	C	2019-12-20 22:13:53.799521+00	1717
786	4	-43129	gs	\N	1	1	-786	\N	C	2019-12-20 22:13:53.799521+00	1718
785	1	-43128	Dekor	\N	1	1	-785	\N	C	2019-12-20 22:13:53.799521+00	1719
784	4	-43128	gs	\N	1	1	-784	\N	C	2019-12-20 22:13:53.799521+00	1720
783	1	-43127	Dekor	\N	1	1	-783	\N	C	2019-12-20 22:13:53.799521+00	1721
782	4	-43127	gs	\N	1	1	-782	\N	C	2019-12-20 22:13:53.799521+00	1722
781	1	-43126	Dekor	\N	1	1	-781	\N	C	2019-12-20 22:13:53.799521+00	1723
780	4	-43126	gs	\N	1	1	-780	\N	C	2019-12-20 22:13:53.799521+00	1724
779	1	-43125	Dekor	\N	1	1	-779	\N	C	2019-12-20 22:13:53.799521+00	1725
778	4	-43125	gs	\N	1	1	-778	\N	C	2019-12-20 22:13:53.799521+00	1726
777	1	-43124	Dekor	\N	1	1	-777	\N	C	2019-12-20 22:13:53.799521+00	1727
776	4	-43124	gs	\N	1	1	-776	\N	C	2019-12-20 22:13:53.799521+00	1728
775	1	-43123	nej	\N	1	1	-775	\N	C	2019-12-20 22:13:53.799521+00	1729
774	4	-43123	gs	\N	1	1	-774	\N	C	2019-12-20 22:13:53.799521+00	1730
773	1	-43122	nej	\N	1	1	-773	\N	C	2019-12-20 22:13:53.799521+00	1731
772	4	-43122	gs	\N	1	1	-772	\N	C	2019-12-20 22:13:53.799521+00	1732
771	1	-43121	nej	\N	1	1	-771	\N	C	2019-12-20 22:13:53.799521+00	1733
770	4	-43121	gs	\N	1	1	-770	\N	C	2019-12-20 22:13:53.799521+00	1734
769	2	-43121	ben	\N	1	1	-769	\N	C	2019-12-20 22:13:53.799521+00	1735
768	1	-43120	nej	\N	1	1	-768	\N	C	2019-12-20 22:13:53.799521+00	1736
767	4	-43120	gs	\N	1	1	-767	\N	C	2019-12-20 22:13:53.799521+00	1737
766	1	-43119	nej	\N	1	1	-766	\N	C	2019-12-20 22:13:53.799521+00	1738
765	4	-43119	gs	\N	1	1	-765	\N	C	2019-12-20 22:13:53.799521+00	1739
764	1	-43118	nej	\N	1	1	-764	\N	C	2019-12-20 22:13:53.799521+00	1740
763	4	-43118	glättad	\N	1	1	-763	\N	C	2019-12-20 22:13:53.799521+00	1741
762	1	-43117	nej	\N	1	1	-762	\N	C	2019-12-20 22:13:53.799521+00	1742
761	4	-43117	Polerad	\N	1	1	-761	\N	C	2019-12-20 22:13:53.799521+00	1743
760	1	-43116	nej	\N	1	1	-760	\N	C	2019-12-20 22:13:53.799521+00	1744
759	4	-43116	glättad	\N	1	1	-759	\N	C	2019-12-20 22:13:53.799521+00	1745
758	1	-43115	nej	\N	1	1	-758	\N	C	2019-12-20 22:13:53.799521+00	1746
757	4	-43115	glättad	\N	1	1	-757	\N	C	2019-12-20 22:13:53.799521+00	1747
756	1	-43114	Dekor	\N	1	1	-756	\N	C	2019-12-20 22:13:53.799521+00	1748
755	2	-43114	buk	\N	1	1	-755	\N	C	2019-12-20 22:13:53.799521+00	1749
754	1	-43113	Dekor	\N	1	1	-754	\N	C	2019-12-20 22:13:53.799521+00	1750
753	4	-43113	gs	\N	1	1	-753	\N	C	2019-12-20 22:13:53.799521+00	1751
752	2	-43113	buk	\N	1	1	-752	\N	C	2019-12-20 22:13:53.799521+00	1752
751	1	-43112	nej	\N	1	1	-751	\N	C	2019-12-20 22:13:53.799521+00	1753
750	2	-43112	buk	\N	1	1	-750	\N	C	2019-12-20 22:13:53.799521+00	1754
749	1	-43111	nej	\N	1	1	-749	\N	C	2019-12-20 22:13:53.799521+00	1755
748	4	-43111	gs	\N	1	1	-748	\N	C	2019-12-20 22:13:53.799521+00	1756
747	2	-43111	buk	\N	1	1	-747	\N	C	2019-12-20 22:13:53.799521+00	1757
746	1	-43110	nej	\N	1	1	-746	\N	C	2019-12-20 22:13:53.799521+00	1758
745	2	-43110	buk	\N	1	1	-745	\N	C	2019-12-20 22:13:53.799521+00	1759
744	1	-43109	Dekor	\N	1	1	-744	\N	C	2019-12-20 22:13:53.799521+00	1760
743	2	-43109	buk	\N	1	1	-743	\N	C	2019-12-20 22:13:53.799521+00	1761
742	1	-43108	nej	\N	1	1	-742	\N	C	2019-12-20 22:13:53.799521+00	1762
741	4	-43108	gs	\N	1	1	-741	\N	C	2019-12-20 22:13:53.799521+00	1763
740	2	-43108	buk	\N	1	1	-740	\N	C	2019-12-20 22:13:53.799521+00	1764
739	1	-43107	nej	\N	1	1	-739	\N	C	2019-12-20 22:13:53.799521+00	1765
738	4	-43107	fs	\N	1	1	-738	\N	C	2019-12-20 22:13:53.799521+00	1766
737	2	-43107	buk	\N	1	1	-737	\N	C	2019-12-20 22:13:53.799521+00	1767
736	1	-43106	Dekor	\N	1	1	-736	\N	C	2019-12-20 22:13:53.799521+00	1768
735	4	-43106	gs	\N	1	1	-735	\N	C	2019-12-20 22:13:53.799521+00	1769
734	2	-43106	buk	\N	1	1	-734	\N	C	2019-12-20 22:13:53.799521+00	1770
733	1	-43105	Dekor	\N	1	1	-733	\N	C	2019-12-20 22:13:53.799521+00	1771
732	4	-43105	glättad	\N	1	1	-732	\N	C	2019-12-20 22:13:53.799521+00	1772
731	2	-43105	buk	\N	1	1	-731	\N	C	2019-12-20 22:13:53.799521+00	1773
730	1	-43104	Dekor	\N	1	1	-730	\N	C	2019-12-20 22:13:53.799521+00	1774
729	2	-43104	buk	\N	1	1	-729	\N	C	2019-12-20 22:13:53.799521+00	1775
728	1	-43103	nej	\N	1	1	-728	\N	C	2019-12-20 22:13:53.799521+00	1776
727	2	-43103	buk	\N	1	1	-727	\N	C	2019-12-20 22:13:53.799521+00	1777
726	1	-43102	Dekor	\N	1	1	-726	\N	C	2019-12-20 22:13:53.799521+00	1778
725	4	-43102	glättad	\N	1	1	-725	\N	C	2019-12-20 22:13:53.799521+00	1779
724	2	-43102	buk	\N	1	1	-724	\N	C	2019-12-20 22:13:53.799521+00	1780
723	1	-43101	nej	\N	1	1	-723	\N	C	2019-12-20 22:13:53.799521+00	1781
722	4	-43101	fs	\N	1	1	-722	\N	C	2019-12-20 22:13:53.799521+00	1782
721	2	-43101	buk	\N	1	1	-721	\N	C	2019-12-20 22:13:53.799521+00	1783
720	1	-43100	Dekor	\N	1	1	-720	\N	C	2019-12-20 22:13:53.799521+00	1784
719	2	-43100	buk	\N	1	1	-719	\N	C	2019-12-20 22:13:53.799521+00	1785
718	1	-43099	nej	\N	1	1	-718	\N	C	2019-12-20 22:13:53.799521+00	1786
717	4	-43099	engobe	\N	1	1	-717	\N	C	2019-12-20 22:13:53.799521+00	1787
716	2	-43099	buk	\N	1	1	-716	\N	C	2019-12-20 22:13:53.799521+00	1788
715	1	-43098	Dekor	\N	1	1	-715	\N	C	2019-12-20 22:13:53.799521+00	1789
714	4	-43098	gs	\N	1	1	-714	\N	C	2019-12-20 22:13:53.799521+00	1790
713	2	-43098	buk	\N	1	1	-713	\N	C	2019-12-20 22:13:53.799521+00	1791
712	1	-43097	Dekor	\N	1	1	-712	\N	C	2019-12-20 22:13:53.799521+00	1792
711	4	-43097	gs	\N	1	1	-711	\N	C	2019-12-20 22:13:53.799521+00	1793
710	2	-43097	buk	\N	1	1	-710	\N	C	2019-12-20 22:13:53.799521+00	1794
709	1	-43096	nej	\N	1	1	-709	\N	C	2019-12-20 22:13:53.799521+00	1795
708	4	-43096	gs	\N	1	1	-708	\N	C	2019-12-20 22:13:53.799521+00	1796
707	2	-43096	buk	\N	1	1	-707	\N	C	2019-12-20 22:13:53.799521+00	1797
706	1	-43095	Dekor	\N	1	1	-706	\N	C	2019-12-20 22:13:53.799521+00	1798
705	4	-43095	gs	\N	1	1	-705	\N	C	2019-12-20 22:13:53.799521+00	1799
704	2	-43095	buk	\N	1	1	-704	\N	C	2019-12-20 22:13:53.799521+00	1800
703	1	-43094	nej	\N	1	1	-703	\N	C	2019-12-20 22:13:53.799521+00	1801
702	4	-43094	gs	\N	1	1	-702	\N	C	2019-12-20 22:13:53.799521+00	1802
701	2	-43094	hals	\N	1	1	-701	\N	C	2019-12-20 22:13:53.799521+00	1803
700	1	-43093	Dekor	\N	1	1	-700	\N	C	2019-12-20 22:13:53.799521+00	1804
699	4	-43093	gs	\N	1	1	-699	\N	C	2019-12-20 22:13:53.799521+00	1805
698	2	-43093	buk	\N	1	1	-698	\N	C	2019-12-20 22:13:53.799521+00	1806
697	1	-43092	nej	\N	1	1	-697	\N	C	2019-12-20 22:13:53.799521+00	1807
696	4	-43092	gs	\N	1	1	-696	\N	C	2019-12-20 22:13:53.799521+00	1808
695	2	-43092	buk	\N	1	1	-695	\N	C	2019-12-20 22:13:53.799521+00	1809
694	1	-43091	Dekor	\N	1	1	-694	\N	C	2019-12-20 22:13:53.799521+00	1810
693	4	-43091	gs	\N	1	1	-693	\N	C	2019-12-20 22:13:53.799521+00	1811
692	2	-43091	buk	\N	1	1	-692	\N	C	2019-12-20 22:13:53.799521+00	1812
691	1	-43090	Dekor	\N	1	1	-691	\N	C	2019-12-20 22:13:53.799521+00	1813
690	4	-43090	gs	\N	1	1	-690	\N	C	2019-12-20 22:13:53.799521+00	1814
689	2	-43090	buk	\N	1	1	-689	\N	C	2019-12-20 22:13:53.799521+00	1815
688	1	-43089	Dekor	\N	1	1	-688	\N	C	2019-12-20 22:13:53.799521+00	1816
687	2	-43089	buk	\N	1	1	-687	\N	C	2019-12-20 22:13:53.799521+00	1817
686	1	-43088	nej	\N	1	1	-686	\N	C	2019-12-20 22:13:53.799521+00	1818
685	4	-43088	glättad	\N	1	1	-685	\N	C	2019-12-20 22:13:53.799521+00	1819
684	2	-43088	buk	\N	1	1	-684	\N	C	2019-12-20 22:13:53.799521+00	1820
683	1	-43087	Dekor	\N	1	1	-683	\N	C	2019-12-20 22:13:53.799521+00	1821
682	4	-43087	gs	\N	1	1	-682	\N	C	2019-12-20 22:13:53.799521+00	1822
681	2	-43087	buk	\N	1	1	-681	\N	C	2019-12-20 22:13:53.799521+00	1823
680	1	-43086	Dekor	\N	1	1	-680	\N	C	2019-12-20 22:13:53.799521+00	1824
679	4	-43086	gs	\N	1	1	-679	\N	C	2019-12-20 22:13:53.799521+00	1825
678	2	-43086	skuldra	\N	1	1	-678	\N	C	2019-12-20 22:13:53.799521+00	1826
677	1	-43085	nej	\N	1	1	-677	\N	C	2019-12-20 22:13:53.799521+00	1827
676	4	-43085	gs	\N	1	1	-676	\N	C	2019-12-20 22:13:53.799521+00	1828
675	2	-43085	buk	\N	1	1	-675	\N	C	2019-12-20 22:13:53.799521+00	1829
674	1	-43084	Dekor	\N	1	1	-674	\N	C	2019-12-20 22:13:53.799521+00	1830
673	4	-43084	gs	\N	1	1	-673	\N	C	2019-12-20 22:13:53.799521+00	1831
672	2	-43084	Mynning	\N	1	1	-672	\N	C	2019-12-20 22:13:53.799521+00	1832
671	1	-43083	Dekor	\N	1	1	-671	\N	C	2019-12-20 22:13:53.799521+00	1833
670	4	-43083	gs	\N	1	1	-670	\N	C	2019-12-20 22:13:53.799521+00	1834
669	2	-43083	Mynning	\N	1	1	-669	\N	C	2019-12-20 22:13:53.799521+00	1835
668	1	-43082	nej	\N	1	1	-668	\N	C	2019-12-20 22:13:53.799521+00	1836
667	4	-43082	gs	\N	1	1	-667	\N	C	2019-12-20 22:13:53.799521+00	1837
666	2	-43082	buk	\N	1	1	-666	\N	C	2019-12-20 22:13:53.799521+00	1838
665	1	-43081	nej	\N	1	1	-665	\N	C	2019-12-20 22:13:53.799521+00	1839
664	4	-43081	gs	\N	1	1	-664	\N	C	2019-12-20 22:13:53.799521+00	1840
663	2	-43081	Mynning	\N	1	1	-663	\N	C	2019-12-20 22:13:53.799521+00	1841
662	1	-43080	Dekor	\N	1	1	-662	\N	C	2019-12-20 22:13:53.799521+00	1842
661	4	-43080	gs	\N	1	1	-661	\N	C	2019-12-20 22:13:53.799521+00	1843
660	2	-43080	buk	\N	1	1	-660	\N	C	2019-12-20 22:13:53.799521+00	1844
659	1	-43079	nej	\N	1	1	-659	\N	C	2019-12-20 22:13:53.799521+00	1845
658	4	-43079	gs	\N	1	1	-658	\N	C	2019-12-20 22:13:53.799521+00	1846
657	1	-43078	Dekor	\N	1	1	-657	\N	C	2019-12-20 22:13:53.799521+00	1847
656	4	-43078	gs	\N	1	1	-656	\N	C	2019-12-20 22:13:53.799521+00	1848
655	2	-43078	Mynning	\N	1	1	-655	\N	C	2019-12-20 22:13:53.799521+00	1849
654	1	-43077	nej	\N	1	1	-654	\N	C	2019-12-20 22:13:53.799521+00	1850
653	4	-43077	gs	\N	1	1	-653	\N	C	2019-12-20 22:13:53.799521+00	1851
652	2	-43077	buk	\N	1	1	-652	\N	C	2019-12-20 22:13:53.799521+00	1852
651	1	-43076	Dekor	\N	1	1	-651	\N	C	2019-12-20 22:13:53.799521+00	1853
650	4	-43076	gs	\N	1	1	-650	\N	C	2019-12-20 22:13:53.799521+00	1854
649	2	-43076	buk	\N	1	1	-649	\N	C	2019-12-20 22:13:53.799521+00	1855
648	1	-43075	Dekor	\N	1	1	-648	\N	C	2019-12-20 22:13:53.799521+00	1856
647	4	-43075	engobe	\N	1	1	-647	\N	C	2019-12-20 22:13:53.799521+00	1857
646	2	-43075	buk	\N	1	1	-646	\N	C	2019-12-20 22:13:53.799521+00	1858
645	1	-43074	nej	\N	1	1	-645	\N	C	2019-12-20 22:13:53.799521+00	1859
644	4	-43074	glättad	\N	1	1	-644	\N	C	2019-12-20 22:13:53.799521+00	1860
643	2	-43074	trindhänkel	\N	1	1	-643	\N	C	2019-12-20 22:13:53.799521+00	1861
642	1	-43073	nej	\N	1	1	-642	\N	C	2019-12-20 22:13:53.799521+00	1862
641	4	-43073	glättad	\N	1	1	-641	\N	C	2019-12-20 22:13:53.799521+00	1863
640	2	-43073	buk	\N	1	1	-640	\N	C	2019-12-20 22:13:53.799521+00	1864
639	1	-43072	nej	\N	1	1	-639	\N	C	2019-12-20 22:13:53.799521+00	1865
638	4	-43072	glättad	\N	1	1	-638	\N	C	2019-12-20 22:13:53.799521+00	1866
637	2	-43072	buk	\N	1	1	-637	\N	C	2019-12-20 22:13:53.799521+00	1867
636	1	-43071	nej	\N	1	1	-636	\N	C	2019-12-20 22:13:53.799521+00	1868
635	4	-43071	glättad	\N	1	1	-635	\N	C	2019-12-20 22:13:53.799521+00	1869
634	2	-43071	buk	\N	1	1	-634	\N	C	2019-12-20 22:13:53.799521+00	1870
633	1	-43070	nej	\N	1	1	-633	\N	C	2019-12-20 22:13:53.799521+00	1871
632	4	-43070	glättad	\N	1	1	-632	\N	C	2019-12-20 22:13:53.799521+00	1872
631	2	-43070	buk	\N	1	1	-631	\N	C	2019-12-20 22:13:53.799521+00	1873
630	1	-43069	nej	\N	1	1	-630	\N	C	2019-12-20 22:13:53.799521+00	1874
629	4	-43069	glättad	\N	1	1	-629	\N	C	2019-12-20 22:13:53.799521+00	1875
628	2	-43069	buk	\N	1	1	-628	\N	C	2019-12-20 22:13:53.799521+00	1876
627	1	-43068	nej	\N	1	1	-627	\N	C	2019-12-20 22:13:53.799521+00	1877
626	4	-43068	glättad	\N	1	1	-626	\N	C	2019-12-20 22:13:53.799521+00	1878
625	2	-43068	buk	\N	1	1	-625	\N	C	2019-12-20 22:13:53.799521+00	1879
624	1	-43067	Dekor	\N	1	1	-624	\N	C	2019-12-20 22:13:53.799521+00	1880
623	4	-43067	gs	\N	1	1	-623	\N	C	2019-12-20 22:13:53.799521+00	1881
622	2	-43067	Mynning	\N	1	1	-622	\N	C	2019-12-20 22:13:53.799521+00	1882
621	1	-43066	Dekor	\N	1	1	-621	\N	C	2019-12-20 22:13:53.799521+00	1883
620	4	-43066	gs	\N	1	1	-620	\N	C	2019-12-20 22:13:53.799521+00	1884
619	2	-43066	hals	\N	1	1	-619	\N	C	2019-12-20 22:13:53.799521+00	1885
618	1	-43065	Dekor	\N	1	1	-618	\N	C	2019-12-20 22:13:53.799521+00	1886
617	4	-43065	gs	\N	1	1	-617	\N	C	2019-12-20 22:13:53.799521+00	1887
616	2	-43065	buk	\N	1	1	-616	\N	C	2019-12-20 22:13:53.799521+00	1888
615	4	-43034	gs	\N	1	1	-615	\N	C	2019-12-20 22:13:53.799521+00	1889
614	4	-43030	gs	\N	1	1	-614	\N	C	2019-12-20 22:13:53.799521+00	1890
613	4	-43029	gs	\N	1	1	-613	\N	C	2019-12-20 22:13:53.799521+00	1891
612	4	-43028	gs	\N	1	1	-612	\N	C	2019-12-20 22:13:53.799521+00	1892
611	4	-43027	gs	\N	1	1	-611	\N	C	2019-12-20 22:13:53.799521+00	1893
610	4	-43026	gs	\N	1	1	-610	\N	C	2019-12-20 22:13:53.799521+00	1894
609	4	-43025	gs	\N	1	1	-609	\N	C	2019-12-20 22:13:53.799521+00	1895
608	4	-43024	gs	\N	1	1	-608	\N	C	2019-12-20 22:13:53.799521+00	1896
607	4	-43023	gs	\N	1	1	-607	\N	C	2019-12-20 22:13:53.799521+00	1897
606	4	-43022	gs	\N	1	1	-606	\N	C	2019-12-20 22:13:53.799521+00	1898
605	4	-43017	gs	\N	1	1	-605	\N	C	2019-12-20 22:13:53.799521+00	1899
604	4	-43016	gs	\N	1	1	-604	\N	C	2019-12-20 22:13:53.799521+00	1900
603	4	-43015	gs	\N	1	1	-603	\N	C	2019-12-20 22:13:53.799521+00	1901
602	4	-43014	gs	\N	1	1	-602	\N	C	2019-12-20 22:13:53.799521+00	1902
601	4	-43013	gs	\N	1	1	-601	\N	C	2019-12-20 22:13:53.799521+00	1903
600	4	-43012	gs	\N	1	1	-600	\N	C	2019-12-20 22:13:53.799521+00	1904
599	4	-43011	gs	\N	1	1	-599	\N	C	2019-12-20 22:13:53.799521+00	1905
598	4	-43010	gs	\N	1	1	-598	\N	C	2019-12-20 22:13:53.799521+00	1906
597	4	-43009	gs	\N	1	1	-597	\N	C	2019-12-20 22:13:53.799521+00	1907
596	4	-43008	gs	\N	1	1	-596	\N	C	2019-12-20 22:13:53.799521+00	1908
595	4	-43007	gs	\N	1	1	-595	\N	C	2019-12-20 22:13:53.799521+00	1909
594	4	-43006	gs	\N	1	1	-594	\N	C	2019-12-20 22:13:53.799521+00	1910
593	4	-43005	gs	\N	1	1	-593	\N	C	2019-12-20 22:13:53.799521+00	1911
592	4	-43004	gs	\N	1	1	-592	\N	C	2019-12-20 22:13:53.799521+00	1912
591	4	-43003	gs	\N	1	1	-591	\N	C	2019-12-20 22:13:53.799521+00	1913
590	4	-43002	gs	\N	1	1	-590	\N	C	2019-12-20 22:13:53.799521+00	1914
589	4	-43000	gs	\N	1	1	-589	\N	C	2019-12-20 22:13:53.799521+00	1915
588	4	-42999	gs	\N	1	1	-588	\N	C	2019-12-20 22:13:53.799521+00	1916
587	4	-42998	gs	\N	1	1	-587	\N	C	2019-12-20 22:13:53.799521+00	1917
586	4	-42997	gs	\N	1	1	-586	\N	C	2019-12-20 22:13:53.799521+00	1918
585	4	-42996	gs	\N	1	1	-585	\N	C	2019-12-20 22:13:53.799521+00	1919
584	4	-42995	gs	\N	1	1	-584	\N	C	2019-12-20 22:13:53.799521+00	1920
583	4	-42994	gs	\N	1	1	-583	\N	C	2019-12-20 22:13:53.799521+00	1921
582	4	-42993	gs	\N	1	1	-582	\N	C	2019-12-20 22:13:53.799521+00	1922
581	4	-42992	gs	\N	1	1	-581	\N	C	2019-12-20 22:13:53.799521+00	1923
580	4	-42991	gs	\N	1	1	-580	\N	C	2019-12-20 22:13:53.799521+00	1924
579	4	-42989	gs	\N	1	1	-579	\N	C	2019-12-20 22:13:53.799521+00	1925
578	4	-42988	gs	\N	1	1	-578	\N	C	2019-12-20 22:13:53.799521+00	1926
577	4	-42987	gs	\N	1	1	-577	\N	C	2019-12-20 22:13:53.799521+00	1927
576	4	-42986	gs	\N	1	1	-576	\N	C	2019-12-20 22:13:53.799521+00	1928
575	4	-42985	gs	\N	1	1	-575	\N	C	2019-12-20 22:13:53.799521+00	1929
574	4	-42984	gs	\N	1	1	-574	\N	C	2019-12-20 22:13:53.799521+00	1930
573	4	-42983	gs	\N	1	1	-573	\N	C	2019-12-20 22:13:53.799521+00	1931
572	4	-42982	gs	\N	1	1	-572	\N	C	2019-12-20 22:13:53.799521+00	1932
571	4	-42981	gs	\N	1	1	-571	\N	C	2019-12-20 22:13:53.799521+00	1933
570	4	-42979	gs	\N	1	1	-570	\N	C	2019-12-20 22:13:53.799521+00	1934
569	4	-42978	gs	\N	1	1	-569	\N	C	2019-12-20 22:13:53.799521+00	1935
568	4	-42977	gs	\N	1	1	-568	\N	C	2019-12-20 22:13:53.799521+00	1936
567	4	-42976	gs	\N	1	1	-567	\N	C	2019-12-20 22:13:53.799521+00	1937
566	4	-42975	gs	\N	1	1	-566	\N	C	2019-12-20 22:13:53.799521+00	1938
565	4	-42974	gs	\N	1	1	-565	\N	C	2019-12-20 22:13:53.799521+00	1939
564	4	-42973	gs	\N	1	1	-564	\N	C	2019-12-20 22:13:53.799521+00	1940
563	4	-42972	gs	\N	1	1	-563	\N	C	2019-12-20 22:13:53.799521+00	1941
562	4	-42971	gs	\N	1	1	-562	\N	C	2019-12-20 22:13:53.799521+00	1942
561	4	-42970	gs	\N	1	1	-561	\N	C	2019-12-20 22:13:53.799521+00	1943
560	4	-42969	gs	\N	1	1	-560	\N	C	2019-12-20 22:13:53.799521+00	1944
559	4	-42968	gs	\N	1	1	-559	\N	C	2019-12-20 22:13:53.799521+00	1945
558	4	-42967	gs	\N	1	1	-558	\N	C	2019-12-20 22:13:53.799521+00	1946
557	4	-42966	gs	\N	1	1	-557	\N	C	2019-12-20 22:13:53.799521+00	1947
556	4	-42965	gs	\N	1	1	-556	\N	C	2019-12-20 22:13:53.799521+00	1948
555	4	-42964	gs	\N	1	1	-555	\N	C	2019-12-20 22:13:53.799521+00	1949
554	4	-42963	gs	\N	1	1	-554	\N	C	2019-12-20 22:13:53.799521+00	1950
553	4	-42962	gs	\N	1	1	-553	\N	C	2019-12-20 22:13:53.799521+00	1951
552	4	-42961	gs	\N	1	1	-552	\N	C	2019-12-20 22:13:53.799521+00	1952
551	4	-42960	gs	\N	1	1	-551	\N	C	2019-12-20 22:13:53.799521+00	1953
550	4	-42958	gs	\N	1	1	-550	\N	C	2019-12-20 22:13:53.799521+00	1954
549	4	-42957	gs	\N	1	1	-549	\N	C	2019-12-20 22:13:53.799521+00	1955
548	4	-42956	gs	\N	1	1	-548	\N	C	2019-12-20 22:13:53.799521+00	1956
547	4	-42955	gs	\N	1	1	-547	\N	C	2019-12-20 22:13:53.799521+00	1957
546	4	-42953	gs	\N	1	1	-546	\N	C	2019-12-20 22:13:53.799521+00	1958
545	4	-42952	gs	\N	1	1	-545	\N	C	2019-12-20 22:13:53.799521+00	1959
544	4	-42951	gs	\N	1	1	-544	\N	C	2019-12-20 22:13:53.799521+00	1960
543	4	-42950	gs	\N	1	1	-543	\N	C	2019-12-20 22:13:53.799521+00	1961
542	4	-42949	gs	\N	1	1	-542	\N	C	2019-12-20 22:13:53.799521+00	1962
541	4	-42948	gs	\N	1	1	-541	\N	C	2019-12-20 22:13:53.799521+00	1963
540	4	-42947	gs	\N	1	1	-540	\N	C	2019-12-20 22:13:53.799521+00	1964
539	4	-42946	gs	\N	1	1	-539	\N	C	2019-12-20 22:13:53.799521+00	1965
538	4	-42945	gs	\N	1	1	-538	\N	C	2019-12-20 22:13:53.799521+00	1966
537	4	-42944	gs	\N	1	1	-537	\N	C	2019-12-20 22:13:53.799521+00	1967
536	4	-42943	gs	\N	1	1	-536	\N	C	2019-12-20 22:13:53.799521+00	1968
535	4	-42942	gs	\N	1	1	-535	\N	C	2019-12-20 22:13:53.799521+00	1969
534	4	-42941	gs	\N	1	1	-534	\N	C	2019-12-20 22:13:53.799521+00	1970
533	4	-42940	gs	\N	1	1	-533	\N	C	2019-12-20 22:13:53.799521+00	1971
532	4	-42939	gs	\N	1	1	-532	\N	C	2019-12-20 22:13:53.799521+00	1972
531	4	-42938	gs	\N	1	1	-531	\N	C	2019-12-20 22:13:53.799521+00	1973
530	4	-42937	gs	\N	1	1	-530	\N	C	2019-12-20 22:13:53.799521+00	1974
529	4	-42934	gs	\N	1	1	-529	\N	C	2019-12-20 22:13:53.799521+00	1975
528	4	-42933	gs	\N	1	1	-528	\N	C	2019-12-20 22:13:53.799521+00	1976
527	4	-42932	gs	\N	1	1	-527	\N	C	2019-12-20 22:13:53.799521+00	1977
526	4	-42931	gs	\N	1	1	-526	\N	C	2019-12-20 22:13:53.799521+00	1978
525	4	-42930	gs	\N	1	1	-525	\N	C	2019-12-20 22:13:53.799521+00	1979
524	4	-42929	gs	\N	1	1	-524	\N	C	2019-12-20 22:13:53.799521+00	1980
523	4	-42928	gs	\N	1	1	-523	\N	C	2019-12-20 22:13:53.799521+00	1981
522	4	-42927	gs	\N	1	1	-522	\N	C	2019-12-20 22:13:53.799521+00	1982
521	4	-42926	gs	\N	1	1	-521	\N	C	2019-12-20 22:13:53.799521+00	1983
520	4	-42925	gs	\N	1	1	-520	\N	C	2019-12-20 22:13:53.799521+00	1984
519	4	-42924	gs	\N	1	1	-519	\N	C	2019-12-20 22:13:53.799521+00	1985
518	4	-42923	gs	\N	1	1	-518	\N	C	2019-12-20 22:13:53.799521+00	1986
517	4	-42922	gs	\N	1	1	-517	\N	C	2019-12-20 22:13:53.799521+00	1987
516	1	-42913	nej	\N	1	1	-516	\N	C	2019-12-20 22:13:53.799521+00	1988
515	1	-42912	Dekor	\N	1	1	-515	\N	C	2019-12-20 22:13:53.799521+00	1989
514	1	-42911	Dekor	\N	1	1	-514	\N	C	2019-12-20 22:13:53.799521+00	1990
513	1	-42910	Dekor	\N	1	1	-513	\N	C	2019-12-20 22:13:53.799521+00	1991
512	1	-42909	nej	\N	1	1	-512	\N	C	2019-12-20 22:13:53.799521+00	1992
511	1	-42908	Dekor	\N	1	1	-511	\N	C	2019-12-20 22:13:53.799521+00	1993
510	1	-42907	Dekor	\N	1	1	-510	\N	C	2019-12-20 22:13:53.799521+00	1994
509	1	-42906	Dekor	\N	1	1	-509	\N	C	2019-12-20 22:13:53.799521+00	1995
508	1	-42905	Dekor	\N	1	1	-508	\N	C	2019-12-20 22:13:53.799521+00	1996
507	1	-42904	nej	\N	1	1	-507	\N	C	2019-12-20 22:13:53.799521+00	1997
506	1	-42903	Dekor	\N	1	1	-506	\N	C	2019-12-20 22:13:53.799521+00	1998
505	1	-42880	Dekor	\N	1	1	-505	\N	C	2019-12-20 22:13:53.799521+00	1999
504	1	-42878	Dekor	\N	1	1	-504	\N	C	2019-12-20 22:13:53.799521+00	2000
503	1	-42877	Dekor	\N	1	1	-503	\N	C	2019-12-20 22:13:53.799521+00	2001
502	1	-42870	Dekor	\N	1	1	-502	\N	C	2019-12-20 22:13:53.799521+00	2002
501	4	-42870	glättad	\N	1	1	-501	\N	C	2019-12-20 22:13:53.799521+00	2003
500	1	-42819	Dekor	\N	1	1	-500	\N	C	2019-12-20 22:13:53.799521+00	2004
499	4	-42819	glättad	\N	1	1	-499	\N	C	2019-12-20 22:13:53.799521+00	2005
498	1	-42818	Dekor	\N	1	1	-498	\N	C	2019-12-20 22:13:53.799521+00	2006
497	4	-42818	glättad	\N	1	1	-497	\N	C	2019-12-20 22:13:53.799521+00	2007
496	1	-42817	Dekor	\N	1	1	-496	\N	C	2019-12-20 22:13:53.799521+00	2008
495	4	-42817	glättad	\N	1	1	-495	\N	C	2019-12-20 22:13:53.799521+00	2009
494	1	-42816	Dekor	\N	1	1	-494	\N	C	2019-12-20 22:13:53.799521+00	2010
493	4	-42816	glättad	\N	1	1	-493	\N	C	2019-12-20 22:13:53.799521+00	2011
492	1	-42815	Dekor	\N	1	1	-492	\N	C	2019-12-20 22:13:53.799521+00	2012
491	4	-42815	glättad	\N	1	1	-491	\N	C	2019-12-20 22:13:53.799521+00	2013
490	1	-42814	Dekor	\N	1	1	-490	\N	C	2019-12-20 22:13:53.799521+00	2014
489	4	-42814	glättad	\N	1	1	-489	\N	C	2019-12-20 22:13:53.799521+00	2015
488	1	-42813	Dekor	\N	1	1	-488	\N	C	2019-12-20 22:13:53.799521+00	2016
487	4	-42813	glättad	\N	1	1	-487	\N	C	2019-12-20 22:13:53.799521+00	2017
486	1	-42812	Dekor	\N	1	1	-486	\N	C	2019-12-20 22:13:53.799521+00	2018
485	4	-42812	glättad	\N	1	1	-485	\N	C	2019-12-20 22:13:53.799521+00	2019
484	1	-42811	Dekor	\N	1	1	-484	\N	C	2019-12-20 22:13:53.799521+00	2020
483	4	-42811	glättad	\N	1	1	-483	\N	C	2019-12-20 22:13:53.799521+00	2021
482	1	-42810	Dekor	\N	1	1	-482	\N	C	2019-12-20 22:13:53.799521+00	2022
481	4	-42810	glättad	\N	1	1	-481	\N	C	2019-12-20 22:13:53.799521+00	2023
480	1	-42809	Dekor	\N	1	1	-480	\N	C	2019-12-20 22:13:53.799521+00	2024
479	4	-42809	glättad	\N	1	1	-479	\N	C	2019-12-20 22:13:53.799521+00	2025
478	1	-42808	Dekor	\N	1	1	-478	\N	C	2019-12-20 22:13:53.799521+00	2026
477	4	-42808	glättad	\N	1	1	-477	\N	C	2019-12-20 22:13:53.799521+00	2027
476	1	-42807	Dekor	\N	1	1	-476	\N	C	2019-12-20 22:13:53.799521+00	2028
475	4	-42807	glättad	\N	1	1	-475	\N	C	2019-12-20 22:13:53.799521+00	2029
474	1	-42806	Dekor	\N	1	1	-474	\N	C	2019-12-20 22:13:53.799521+00	2030
473	4	-42806	glättad	\N	1	1	-473	\N	C	2019-12-20 22:13:53.799521+00	2031
472	1	-42805	Dekor	\N	1	1	-472	\N	C	2019-12-20 22:13:53.799521+00	2032
471	4	-42805	glättad	\N	1	1	-471	\N	C	2019-12-20 22:13:53.799521+00	2033
470	1	-42804	Dekor	\N	1	1	-470	\N	C	2019-12-20 22:13:53.799521+00	2034
469	4	-42804	glättad	\N	1	1	-469	\N	C	2019-12-20 22:13:53.799521+00	2035
468	1	-42803	Dekor	\N	1	1	-468	\N	C	2019-12-20 22:13:53.799521+00	2036
467	4	-42803	glättad	\N	1	1	-467	\N	C	2019-12-20 22:13:53.799521+00	2037
466	1	-42802	Dekor	\N	1	1	-466	\N	C	2019-12-20 22:13:53.799521+00	2038
465	4	-42802	glättad	\N	1	1	-465	\N	C	2019-12-20 22:13:53.799521+00	2039
464	1	-42801	Dekor	\N	1	1	-464	\N	C	2019-12-20 22:13:53.799521+00	2040
463	4	-42801	glättad	\N	1	1	-463	\N	C	2019-12-20 22:13:53.799521+00	2041
462	1	-42800	Dekor	\N	1	1	-462	\N	C	2019-12-20 22:13:53.799521+00	2042
461	4	-42800	glättad	\N	1	1	-461	\N	C	2019-12-20 22:13:53.799521+00	2043
460	1	-42799	Dekor	\N	1	1	-460	\N	C	2019-12-20 22:13:53.799521+00	2044
459	4	-42799	glättad	\N	1	1	-459	\N	C	2019-12-20 22:13:53.799521+00	2045
458	1	-42798	Dekor	\N	1	1	-458	\N	C	2019-12-20 22:13:53.799521+00	2046
457	4	-42798	glättad	\N	1	1	-457	\N	C	2019-12-20 22:13:53.799521+00	2047
456	1	-42732	Dekor	\N	1	1	-456	\N	C	2019-12-20 22:13:53.799521+00	2048
455	1	-42731	Dekor	\N	1	1	-455	\N	C	2019-12-20 22:13:53.799521+00	2049
454	1	-42724	Dekor	\N	1	1	-454	\N	C	2019-12-20 22:13:53.799521+00	2050
453	4	-42724	glättad	\N	1	1	-453	\N	C	2019-12-20 22:13:53.799521+00	2051
452	1	-42723	nej	\N	1	1	-452	\N	C	2019-12-20 22:13:53.799521+00	2052
451	4	-42723	Rabbad	\N	1	1	-451	\N	C	2019-12-20 22:13:53.799521+00	2053
450	1	-42722	nej	\N	1	1	-450	\N	C	2019-12-20 22:13:53.799521+00	2054
449	4	-42722	Rabbad	\N	1	1	-449	\N	C	2019-12-20 22:13:53.799521+00	2055
448	1	-42721	Dekor	\N	1	1	-448	\N	C	2019-12-20 22:13:53.799521+00	2056
447	4	-42721	glättad	\N	1	1	-447	\N	C	2019-12-20 22:13:53.799521+00	2057
446	1	-42720	nej	\N	1	1	-446	\N	C	2019-12-20 22:13:53.799521+00	2058
445	4	-42720	Polerad	\N	1	1	-445	\N	C	2019-12-20 22:13:53.799521+00	2059
444	1	-42719	nej	\N	1	1	-444	\N	C	2019-12-20 22:13:53.799521+00	2060
443	4	-42719	glättad	\N	1	1	-443	\N	C	2019-12-20 22:13:53.799521+00	2061
442	1	-42718	Dekor	\N	1	1	-442	\N	C	2019-12-20 22:13:53.799521+00	2062
441	4	-42718	Polerad	\N	1	1	-441	\N	C	2019-12-20 22:13:53.799521+00	2063
440	1	-42717	Dekor	\N	1	1	-440	\N	C	2019-12-20 22:13:53.799521+00	2064
439	4	-42717	glättad	\N	1	1	-439	\N	C	2019-12-20 22:13:53.799521+00	2065
438	1	-42716	Dekor	\N	1	1	-438	\N	C	2019-12-20 22:13:53.799521+00	2066
437	4	-42716	glättad	\N	1	1	-437	\N	C	2019-12-20 22:13:53.799521+00	2067
436	1	-42715	nej	\N	1	1	-436	\N	C	2019-12-20 22:13:53.799521+00	2068
435	4	-42715	glättad	\N	1	1	-435	\N	C	2019-12-20 22:13:53.799521+00	2069
434	1	-42714	Dekor	\N	1	1	-434	\N	C	2019-12-20 22:13:53.799521+00	2070
433	4	-42714	glättad	\N	1	1	-433	\N	C	2019-12-20 22:13:53.799521+00	2071
432	1	-42713	Dekor	\N	1	1	-432	\N	C	2019-12-20 22:13:53.799521+00	2072
431	4	-42713	glättad	\N	1	1	-431	\N	C	2019-12-20 22:13:53.799521+00	2073
430	1	-42712	Dekor	\N	1	1	-430	\N	C	2019-12-20 22:13:53.799521+00	2074
429	4	-42712	Polerad	\N	1	1	-429	\N	C	2019-12-20 22:13:53.799521+00	2075
428	1	-42711	nej	\N	1	1	-428	\N	C	2019-12-20 22:13:53.799521+00	2076
427	4	-42711	Rabbad	\N	1	1	-427	\N	C	2019-12-20 22:13:53.799521+00	2077
426	1	-42710	nej	\N	1	1	-426	\N	C	2019-12-20 22:13:53.799521+00	2078
425	4	-42710	Rabbad	\N	1	1	-425	\N	C	2019-12-20 22:13:53.799521+00	2079
424	1	-42709	nej	\N	1	1	-424	\N	C	2019-12-20 22:13:53.799521+00	2080
423	4	-42709	Rabbad	\N	1	1	-423	\N	C	2019-12-20 22:13:53.799521+00	2081
422	1	-42708	Dekor	\N	1	1	-422	\N	C	2019-12-20 22:13:53.799521+00	2082
421	4	-42708	glättad	\N	1	1	-421	\N	C	2019-12-20 22:13:53.799521+00	2083
420	1	-42707	Dekor	\N	1	1	-420	\N	C	2019-12-20 22:13:53.799521+00	2084
419	4	-42707	Polerad	\N	1	1	-419	\N	C	2019-12-20 22:13:53.799521+00	2085
418	1	-42706	Dekor	\N	1	1	-418	\N	C	2019-12-20 22:13:53.799521+00	2086
417	4	-42706	Polerad	\N	1	1	-417	\N	C	2019-12-20 22:13:53.799521+00	2087
416	1	-42705	nej	\N	1	1	-416	\N	C	2019-12-20 22:13:53.799521+00	2088
415	1	-42704	nej	\N	1	1	-415	\N	C	2019-12-20 22:13:53.799521+00	2089
414	1	-42703	nej	\N	1	1	-414	\N	C	2019-12-20 22:13:53.799521+00	2090
413	1	-42702	nej	\N	1	1	-413	\N	C	2019-12-20 22:13:53.799521+00	2091
412	1	-42701	Dekor	\N	1	1	-412	\N	C	2019-12-20 22:13:53.799521+00	2092
411	1	-42700	Dekor	\N	1	1	-411	\N	C	2019-12-20 22:13:53.799521+00	2093
410	1	-42699	Dekor	\N	1	1	-410	\N	C	2019-12-20 22:13:53.799521+00	2094
409	1	-42697	nej	\N	1	1	-409	\N	C	2019-12-20 22:13:53.799521+00	2095
408	4	-42697	glättad	\N	1	1	-408	\N	C	2019-12-20 22:13:53.799521+00	2096
407	1	-42696	nej	\N	1	1	-407	\N	C	2019-12-20 22:13:53.799521+00	2097
406	4	-42696	glättad	\N	1	1	-406	\N	C	2019-12-20 22:13:53.799521+00	2098
405	4	-42674	fs	\N	1	1	-405	\N	C	2019-12-20 22:13:53.799521+00	2099
404	4	-42672	fs	\N	1	1	-404	\N	C	2019-12-20 22:13:53.799521+00	2100
403	1	-42671	nej	\N	1	1	-403	\N	C	2019-12-20 22:13:53.799521+00	2101
402	1	-42670	nej	\N	1	1	-402	\N	C	2019-12-20 22:13:53.799521+00	2102
401	1	-42669	nej	\N	1	1	-401	\N	C	2019-12-20 22:13:53.799521+00	2103
400	1	-42668	nej	\N	1	1	-400	\N	C	2019-12-20 22:13:53.799521+00	2104
399	1	-42667	nej	\N	1	1	-399	\N	C	2019-12-20 22:13:53.799521+00	2105
398	1	-42666	nej	\N	1	1	-398	\N	C	2019-12-20 22:13:53.799521+00	2106
397	1	-42665	Dekor	\N	1	1	-397	\N	C	2019-12-20 22:13:53.799521+00	2107
396	1	-42664	Dekor	\N	1	1	-396	\N	C	2019-12-20 22:13:53.799521+00	2108
395	1	-42663	Dekor	\N	1	1	-395	\N	C	2019-12-20 22:13:53.799521+00	2109
394	1	-42662	Dekor	\N	1	1	-394	\N	C	2019-12-20 22:13:53.799521+00	2110
393	1	-42661	Dekor	\N	1	1	-393	\N	C	2019-12-20 22:13:53.799521+00	2111
392	1	-42660	Dekor	\N	1	1	-392	\N	C	2019-12-20 22:13:53.799521+00	2112
391	1	-42659	Dekor	\N	1	1	-391	\N	C	2019-12-20 22:13:53.799521+00	2113
390	1	-42658	Dekor	\N	1	1	-390	\N	C	2019-12-20 22:13:53.799521+00	2114
389	1	-42657	Dekor	\N	1	1	-389	\N	C	2019-12-20 22:13:53.799521+00	2115
388	1	-42656	Dekor	\N	1	1	-388	\N	C	2019-12-20 22:13:53.799521+00	2116
387	1	-42655	Dekor	\N	1	1	-387	\N	C	2019-12-20 22:13:53.799521+00	2117
386	1	-42654	Dekor	\N	1	1	-386	\N	C	2019-12-20 22:13:53.799521+00	2118
385	1	-42653	Dekor	\N	1	1	-385	\N	C	2019-12-20 22:13:53.799521+00	2119
384	1	-42652	Dekor	\N	1	1	-384	\N	C	2019-12-20 22:13:53.799521+00	2120
383	1	-42647	Dekor	\N	1	1	-383	\N	C	2019-12-20 22:13:53.799521+00	2121
382	1	-42646	Dekor	\N	1	1	-382	\N	C	2019-12-20 22:13:53.799521+00	2122
381	1	-42645	nej	\N	1	1	-381	\N	C	2019-12-20 22:13:53.799521+00	2123
380	1	-42644	Dekor	\N	1	1	-380	\N	C	2019-12-20 22:13:53.799521+00	2124
379	1	-42643	nej	\N	1	1	-379	\N	C	2019-12-20 22:13:53.799521+00	2125
378	1	-42642	Dekor	\N	1	1	-378	\N	C	2019-12-20 22:13:53.799521+00	2126
377	1	-42641	Dekor	\N	1	1	-377	\N	C	2019-12-20 22:13:53.799521+00	2127
376	1	-42640	Dekor	\N	1	1	-376	\N	C	2019-12-20 22:13:53.799521+00	2128
375	1	-42639	Dekor	\N	1	1	-375	\N	C	2019-12-20 22:13:53.799521+00	2129
374	1	-42638	Dekor	\N	1	1	-374	\N	C	2019-12-20 22:13:53.799521+00	2130
373	1	-42637	Dekor	\N	1	1	-373	\N	C	2019-12-20 22:13:53.799521+00	2131
372	1	-42636	nej	\N	1	1	-372	\N	C	2019-12-20 22:13:53.799521+00	2132
371	1	-42635	nej	\N	1	1	-371	\N	C	2019-12-20 22:13:53.799521+00	2133
370	1	-42634	nej	\N	1	1	-370	\N	C	2019-12-20 22:13:53.799521+00	2134
369	1	-42633	nej	\N	1	1	-369	\N	C	2019-12-20 22:13:53.799521+00	2135
368	1	-42632	nej	\N	1	1	-368	\N	C	2019-12-20 22:13:53.799521+00	2136
367	1	-42631	nej	\N	1	1	-367	\N	C	2019-12-20 22:13:53.799521+00	2137
366	1	-42630	nej	\N	1	1	-366	\N	C	2019-12-20 22:13:53.799521+00	2138
365	1	-42629	Dekor	\N	1	1	-365	\N	C	2019-12-20 22:13:53.799521+00	2139
364	1	-42628	Dekor	\N	1	1	-364	\N	C	2019-12-20 22:13:53.799521+00	2140
363	1	-42627	nej	\N	1	1	-363	\N	C	2019-12-20 22:13:53.799521+00	2141
362	1	-42626	Dekor	\N	1	1	-362	\N	C	2019-12-20 22:13:53.799521+00	2142
361	1	-42625	nej	\N	1	1	-361	\N	C	2019-12-20 22:13:53.799521+00	2143
360	1	-42624	Dekor	\N	1	1	-360	\N	C	2019-12-20 22:13:53.799521+00	2144
359	1	-42623	nej	\N	1	1	-359	\N	C	2019-12-20 22:13:53.799521+00	2145
358	1	-42622	Dekor	\N	1	1	-358	\N	C	2019-12-20 22:13:53.799521+00	2146
357	1	-42621	Dekor	\N	1	1	-357	\N	C	2019-12-20 22:13:53.799521+00	2147
356	1	-42620	nej	\N	1	1	-356	\N	C	2019-12-20 22:13:53.799521+00	2148
355	1	-42619	Dekor	\N	1	1	-355	\N	C	2019-12-20 22:13:53.799521+00	2149
354	1	-42618	Dekor	\N	1	1	-354	\N	C	2019-12-20 22:13:53.799521+00	2150
353	4	-42614	Rabbad	\N	1	1	-353	\N	C	2019-12-20 22:13:53.799521+00	2151
352	4	-42613	Polerad	\N	1	1	-352	\N	C	2019-12-20 22:13:53.799521+00	2152
351	4	-42612	Rabbad	\N	1	1	-351	\N	C	2019-12-20 22:13:53.799521+00	2153
350	4	-42610	Rabbad	\N	1	1	-350	\N	C	2019-12-20 22:13:53.799521+00	2154
349	4	-42609	Polerad	\N	1	1	-349	\N	C	2019-12-20 22:13:53.799521+00	2155
348	4	-42608	Polerad	\N	1	1	-348	\N	C	2019-12-20 22:13:53.799521+00	2156
347	4	-42607	Rabbad	\N	1	1	-347	\N	C	2019-12-20 22:13:53.799521+00	2157
346	1	-42605	nej	\N	1	1	-346	\N	C	2019-12-20 22:13:53.799521+00	2158
345	4	-42605	Polerad	\N	1	1	-345	\N	C	2019-12-20 22:13:53.799521+00	2159
344	1	-42604	nej	\N	1	1	-344	\N	C	2019-12-20 22:13:53.799521+00	2160
343	4	-42604	Rabbad	\N	1	1	-343	\N	C	2019-12-20 22:13:53.799521+00	2161
342	4	-42603	Polerad	\N	1	1	-342	\N	C	2019-12-20 22:13:53.799521+00	2162
341	1	-42602	nej	\N	1	1	-341	\N	C	2019-12-20 22:13:53.799521+00	2163
340	4	-42602	Polerad	\N	1	1	-340	\N	C	2019-12-20 22:13:53.799521+00	2164
339	4	-42597	glättad	\N	1	1	-339	\N	C	2019-12-20 22:13:53.799521+00	2165
338	2	-42596	Botten	\N	1	1	-338	\N	C	2019-12-20 22:13:53.799521+00	2166
337	4	-42593	Rabbad	\N	1	1	-337	\N	C	2019-12-20 22:13:53.799521+00	2167
336	4	-42592	Rabbad	\N	1	1	-336	\N	C	2019-12-20 22:13:53.799521+00	2168
335	4	-42591	Rabbad	\N	1	1	-335	\N	C	2019-12-20 22:13:53.799521+00	2169
334	4	-42590	Polerad	\N	1	1	-334	\N	C	2019-12-20 22:13:53.799521+00	2170
333	4	-42588	obehandlad	\N	1	1	-333	\N	C	2019-12-20 22:13:53.799521+00	2171
332	4	-42587	Rabbad	\N	1	1	-332	\N	C	2019-12-20 22:13:53.799521+00	2172
331	4	-42586	glättad	\N	1	1	-331	\N	C	2019-12-20 22:13:53.799521+00	2173
330	4	-42585	Polerad	\N	1	1	-330	\N	C	2019-12-20 22:13:53.799521+00	2174
329	4	-42584	Rabbad	\N	1	1	-329	\N	C	2019-12-20 22:13:53.799521+00	2175
328	4	-42583	Polerad	\N	1	1	-328	\N	C	2019-12-20 22:13:53.799521+00	2176
327	4	-42581	Rabbad	\N	1	1	-327	\N	C	2019-12-20 22:13:53.799521+00	2177
326	4	-42580	Rabbad	\N	1	1	-326	\N	C	2019-12-20 22:13:53.799521+00	2178
325	1	-42579	nej	\N	1	1	-325	\N	C	2019-12-20 22:13:53.799521+00	2179
324	4	-42579	Rabbad	\N	1	1	-324	\N	C	2019-12-20 22:13:53.799521+00	2180
323	1	-42578	nej	\N	1	1	-323	\N	C	2019-12-20 22:13:53.799521+00	2181
322	4	-42578	glättad	\N	1	1	-322	\N	C	2019-12-20 22:13:53.799521+00	2182
321	1	-42577	nej	\N	1	1	-321	\N	C	2019-12-20 22:13:53.799521+00	2183
320	1	-42576	nej	\N	1	1	-320	\N	C	2019-12-20 22:13:53.799521+00	2184
319	1	-42575	nej	\N	1	1	-319	\N	C	2019-12-20 22:13:53.799521+00	2185
318	1	-42574	Dekor	\N	1	1	-318	\N	C	2019-12-20 22:13:53.799521+00	2186
317	1	-42573	Dekor	\N	1	1	-317	\N	C	2019-12-20 22:13:53.799521+00	2187
316	4	-42573	Rabbad	\N	1	1	-316	\N	C	2019-12-20 22:13:53.799521+00	2188
315	1	-42572	Dekor	\N	1	1	-315	\N	C	2019-12-20 22:13:53.799521+00	2189
314	1	-42571	Dekor	\N	1	1	-314	\N	C	2019-12-20 22:13:53.799521+00	2190
313	4	-42571	FS	\N	1	1	-313	\N	C	2019-12-20 22:13:53.799521+00	2191
312	1	-42570	Dekor	\N	1	1	-312	\N	C	2019-12-20 22:13:53.799521+00	2192
311	4	-42570	FS	\N	1	1	-311	\N	C	2019-12-20 22:13:53.799521+00	2193
310	1	-42569	Dekor	\N	1	1	-310	\N	C	2019-12-20 22:13:53.799521+00	2194
309	1	-42568	Dekor	\N	1	1	-309	\N	C	2019-12-20 22:13:53.799521+00	2195
308	4	-42568	FS	\N	1	1	-308	\N	C	2019-12-20 22:13:53.799521+00	2196
307	1	-42567	Dekor	\N	1	1	-307	\N	C	2019-12-20 22:13:53.799521+00	2197
306	1	-42566	Dekor	\N	1	1	-306	\N	C	2019-12-20 22:13:53.799521+00	2198
305	1	-42565	nej	\N	1	1	-305	\N	C	2019-12-20 22:13:53.799521+00	2199
304	1	-42564	nej	\N	1	1	-304	\N	C	2019-12-20 22:13:53.799521+00	2200
303	1	-42563	nej	\N	1	1	-303	\N	C	2019-12-20 22:13:53.799521+00	2201
302	1	-42562	Dekor	\N	1	1	-302	\N	C	2019-12-20 22:13:53.799521+00	2202
301	1	-42561	nej	\N	1	1	-301	\N	C	2019-12-20 22:13:53.799521+00	2203
300	1	-42560	nej	\N	1	1	-300	\N	C	2019-12-20 22:13:53.799521+00	2204
299	4	-42560	glättad	\N	1	1	-299	\N	C	2019-12-20 22:13:53.799521+00	2205
298	1	-42559	nej	\N	1	1	-298	\N	C	2019-12-20 22:13:53.799521+00	2206
297	4	-42559	glättad	\N	1	1	-297	\N	C	2019-12-20 22:13:53.799521+00	2207
296	1	-42558	nej	\N	1	1	-296	\N	C	2019-12-20 22:13:53.799521+00	2208
295	4	-42558	glättad	\N	1	1	-295	\N	C	2019-12-20 22:13:53.799521+00	2209
294	1	-42557	nej	\N	1	1	-294	\N	C	2019-12-20 22:13:53.799521+00	2210
293	4	-42557	glättad	\N	1	1	-293	\N	C	2019-12-20 22:13:53.799521+00	2211
292	4	-42556	glättad	\N	1	1	-292	\N	C	2019-12-20 22:13:53.799521+00	2212
291	1	-42553	Dekor	\N	1	1	-291	\N	C	2019-12-20 22:13:53.799521+00	2213
290	4	-42551	glättad	\N	1	1	-290	\N	C	2019-12-20 22:13:53.799521+00	2214
289	1	-42542	Dekor	\N	1	1	-289	\N	C	2019-12-20 22:13:53.799521+00	2215
288	4	-42542	glättad	\N	1	1	-288	\N	C	2019-12-20 22:13:53.799521+00	2216
287	1	-42541	Dekor	\N	1	1	-287	\N	C	2019-12-20 22:13:53.799521+00	2217
286	4	-42541	glättad	\N	1	1	-286	\N	C	2019-12-20 22:13:53.799521+00	2218
285	1	-42540	Dekor	\N	1	1	-285	\N	C	2019-12-20 22:13:53.799521+00	2219
284	1	-42539	Dekor	\N	1	1	-284	\N	C	2019-12-20 22:13:53.799521+00	2220
283	1	-42534	Dekor	\N	1	1	-283	\N	C	2019-12-20 22:13:53.799521+00	2221
282	4	-42534	glättad	\N	1	1	-282	\N	C	2019-12-20 22:13:53.799521+00	2222
281	1	-42533	Dekor	\N	1	1	-281	\N	C	2019-12-20 22:13:53.799521+00	2223
280	4	-42533	glättad	\N	1	1	-280	\N	C	2019-12-20 22:13:53.799521+00	2224
279	1	-42532	Dekor	\N	1	1	-279	\N	C	2019-12-20 22:13:53.799521+00	2225
278	1	-42505	nej	\N	1	1	-278	\N	C	2019-12-20 22:13:53.799521+00	2226
277	1	-42504	nej	\N	1	1	-277	\N	C	2019-12-20 22:13:53.799521+00	2227
276	1	-42503	nej	\N	1	1	-276	\N	C	2019-12-20 22:13:53.799521+00	2228
275	1	-42502	nej	\N	1	1	-275	\N	C	2019-12-20 22:13:53.799521+00	2229
274	1	-42501	nej	\N	1	1	-274	\N	C	2019-12-20 22:13:53.799521+00	2230
273	1	-42500	Dekor	\N	1	1	-273	\N	C	2019-12-20 22:13:53.799521+00	2231
272	2	-42500	Mynning	\N	1	1	-272	\N	C	2019-12-20 22:13:53.799521+00	2232
271	1	-42499	nej	\N	1	1	-271	\N	C	2019-12-20 22:13:53.799521+00	2233
270	1	-42498	Dekor	\N	1	1	-270	\N	C	2019-12-20 22:13:53.799521+00	2234
269	1	-42497	Dekor	\N	1	1	-269	\N	C	2019-12-20 22:13:53.799521+00	2235
268	1	-42496	Dekor	\N	1	1	-268	\N	C	2019-12-20 22:13:53.799521+00	2236
267	2	-42496	Mynning	\N	1	1	-267	\N	C	2019-12-20 22:13:53.799521+00	2237
266	1	-42495	Dekor	\N	1	1	-266	\N	C	2019-12-20 22:13:53.799521+00	2238
265	1	-42494	Dekor	\N	1	1	-265	\N	C	2019-12-20 22:13:53.799521+00	2239
264	1	-42493	Dekor	\N	1	1	-264	\N	C	2019-12-20 22:13:53.799521+00	2240
263	2	-42493	Mynning	\N	1	1	-263	\N	C	2019-12-20 22:13:53.799521+00	2241
262	1	-42492	Dekor	\N	1	1	-262	\N	C	2019-12-20 22:13:53.799521+00	2242
261	1	-42491	Dekor	\N	1	1	-261	\N	C	2019-12-20 22:13:53.799521+00	2243
260	2	-42491	Mynning	\N	1	1	-260	\N	C	2019-12-20 22:13:53.799521+00	2244
259	1	-42490	nej	\N	1	1	-259	\N	C	2019-12-20 22:13:53.799521+00	2245
258	1	-42489	Dekor	\N	1	1	-258	\N	C	2019-12-20 22:13:53.799521+00	2246
257	1	-42488	Dekor	\N	1	1	-257	\N	C	2019-12-20 22:13:53.799521+00	2247
256	2	-42488	Mynning	\N	1	1	-256	\N	C	2019-12-20 22:13:53.799521+00	2248
255	1	-42487	Dekor	\N	1	1	-255	\N	C	2019-12-20 22:13:53.799521+00	2249
254	1	-42486	Dekor	\N	1	1	-254	\N	C	2019-12-20 22:13:53.799521+00	2250
253	2	-42486	Mynning	\N	1	1	-253	\N	C	2019-12-20 22:13:53.799521+00	2251
252	1	-42485	Dekor	\N	1	1	-252	\N	C	2019-12-20 22:13:53.799521+00	2252
251	1	-42484	Dekor	\N	1	1	-251	\N	C	2019-12-20 22:13:53.799521+00	2253
250	2	-42484	Mynning	\N	1	1	-250	\N	C	2019-12-20 22:13:53.799521+00	2254
249	1	-42483	Dekor	\N	1	1	-249	\N	C	2019-12-20 22:13:53.799521+00	2255
248	1	-42482	Dekor	\N	1	1	-248	\N	C	2019-12-20 22:13:53.799521+00	2256
247	2	-42482	Mynning	\N	1	1	-247	\N	C	2019-12-20 22:13:53.799521+00	2257
246	1	-42481	Dekor	\N	1	1	-246	\N	C	2019-12-20 22:13:53.799521+00	2258
245	2	-42481	Mynning	\N	1	1	-245	\N	C	2019-12-20 22:13:53.799521+00	2259
244	1	-42480	Dekor	\N	1	1	-244	\N	C	2019-12-20 22:13:53.799521+00	2260
243	2	-42480	Mynning	\N	1	1	-243	\N	C	2019-12-20 22:13:53.799521+00	2261
242	1	-42478	Dekor	\N	1	1	-242	\N	C	2019-12-20 22:13:53.799521+00	2262
241	2	-42478	Mynning	\N	1	1	-241	\N	C	2019-12-20 22:13:53.799521+00	2263
240	1	-42477	Dekor	\N	1	1	-240	\N	C	2019-12-20 22:13:53.799521+00	2264
239	2	-42477	Mynning	\N	1	1	-239	\N	C	2019-12-20 22:13:53.799521+00	2265
238	1	-42476	Dekor	\N	1	1	-238	\N	C	2019-12-20 22:13:53.799521+00	2266
237	2	-42464	Mynning	\N	1	1	-237	\N	C	2019-12-20 22:13:53.799521+00	2267
236	2	-42463	Mynning	\N	1	1	-236	\N	C	2019-12-20 22:13:53.799521+00	2268
235	1	-42460	Dekor	\N	1	1	-235	\N	C	2019-12-20 22:13:53.799521+00	2269
234	1	-42459	Dekor	\N	1	1	-234	\N	C	2019-12-20 22:13:53.799521+00	2270
233	1	-42458	Dekor	\N	1	1	-233	\N	C	2019-12-20 22:13:53.799521+00	2271
232	1	-42457	Dekor	\N	1	1	-232	\N	C	2019-12-20 22:13:53.799521+00	2272
231	2	-42457	Mynning	\N	1	1	-231	\N	C	2019-12-20 22:13:53.799521+00	2273
230	1	-42456	Dekor	\N	1	1	-230	\N	C	2019-12-20 22:13:53.799521+00	2274
229	2	-42456	Mynning	\N	1	1	-229	\N	C	2019-12-20 22:13:53.799521+00	2275
228	1	-42455	Dekor	\N	1	1	-228	\N	C	2019-12-20 22:13:53.799521+00	2276
227	1	-42454	Dekor	\N	1	1	-227	\N	C	2019-12-20 22:13:53.799521+00	2277
226	2	-42454	Mynning	\N	1	1	-226	\N	C	2019-12-20 22:13:53.799521+00	2278
225	1	-42453	Dekor	\N	1	1	-225	\N	C	2019-12-20 22:13:53.799521+00	2279
224	1	-42452	Dekor	\N	1	1	-224	\N	C	2019-12-20 22:13:53.799521+00	2280
223	1	-42451	Dekor	\N	1	1	-223	\N	C	2019-12-20 22:13:53.799521+00	2281
222	1	-42450	Dekor	\N	1	1	-222	\N	C	2019-12-20 22:13:53.799521+00	2282
221	2	-42450	Mynning	\N	1	1	-221	\N	C	2019-12-20 22:13:53.799521+00	2283
220	1	-42449	Dekor	\N	1	1	-220	\N	C	2019-12-20 22:13:53.799521+00	2284
219	2	-42449	Mynning	\N	1	1	-219	\N	C	2019-12-20 22:13:53.799521+00	2285
218	1	-42448	Dekor	\N	1	1	-218	\N	C	2019-12-20 22:13:53.799521+00	2286
217	1	-42417	Dekor	\N	1	1	-217	\N	C	2019-12-20 22:13:53.799521+00	2287
216	1	-42416	Dekor	\N	1	1	-216	\N	C	2019-12-20 22:13:53.799521+00	2288
215	1	-42415	nej	\N	1	1	-215	\N	C	2019-12-20 22:13:53.799521+00	2289
214	1	-42414	Dekor	\N	1	1	-214	\N	C	2019-12-20 22:13:53.799521+00	2290
213	1	-42413	Dekor	\N	1	1	-213	\N	C	2019-12-20 22:13:53.799521+00	2291
212	1	-42412	nej	\N	1	1	-212	\N	C	2019-12-20 22:13:53.799521+00	2292
211	1	-42411	Dekor	\N	1	1	-211	\N	C	2019-12-20 22:13:53.799521+00	2293
210	1	-42410	Dekor	\N	1	1	-210	\N	C	2019-12-20 22:13:53.799521+00	2294
209	1	-42409	Dekor	\N	1	1	-209	\N	C	2019-12-20 22:13:53.799521+00	2295
208	1	-42408	Dekor	\N	1	1	-208	\N	C	2019-12-20 22:13:53.799521+00	2296
207	1	-42407	Dekor	\N	1	1	-207	\N	C	2019-12-20 22:13:53.799521+00	2297
206	1	-42406	Dekor	\N	1	1	-206	\N	C	2019-12-20 22:13:53.799521+00	2298
205	1	-42405	nej	\N	1	1	-205	\N	C	2019-12-20 22:13:53.799521+00	2299
204	1	-42404	nej	\N	1	1	-204	\N	C	2019-12-20 22:13:53.799521+00	2300
203	1	-42403	nej	\N	1	1	-203	\N	C	2019-12-20 22:13:53.799521+00	2301
202	1	-42402	nej	\N	1	1	-202	\N	C	2019-12-20 22:13:53.799521+00	2302
201	1	-42401	nej	\N	1	1	-201	\N	C	2019-12-20 22:13:53.799521+00	2303
200	1	-42400	Dekor	\N	1	1	-200	\N	C	2019-12-20 22:13:53.799521+00	2304
199	1	-42399	Dekor	\N	1	1	-199	\N	C	2019-12-20 22:13:53.799521+00	2305
198	1	-42398	Dekor	\N	1	1	-198	\N	C	2019-12-20 22:13:53.799521+00	2306
197	1	-42397	nej	\N	1	1	-197	\N	C	2019-12-20 22:13:53.799521+00	2307
196	1	-42396	nej	\N	1	1	-196	\N	C	2019-12-20 22:13:53.799521+00	2308
195	1	-42395	nej	\N	1	1	-195	\N	C	2019-12-20 22:13:53.799521+00	2309
194	1	-42394	Dekor	\N	1	1	-194	\N	C	2019-12-20 22:13:53.799521+00	2310
193	1	-42393	Dekor	\N	1	1	-193	\N	C	2019-12-20 22:13:53.799521+00	2311
192	1	-42392	Dekor	\N	1	1	-192	\N	C	2019-12-20 22:13:53.799521+00	2312
191	2	-42392	Mynning	\N	1	1	-191	\N	C	2019-12-20 22:13:53.799521+00	2313
190	1	-42391	Dekor	\N	1	1	-190	\N	C	2019-12-20 22:13:53.799521+00	2314
189	1	-42390	Dekor	\N	1	1	-189	\N	C	2019-12-20 22:13:53.799521+00	2315
188	1	-42389	nej	\N	1	1	-188	\N	C	2019-12-20 22:13:53.799521+00	2316
187	1	-42388	nej	\N	1	1	-187	\N	C	2019-12-20 22:13:53.799521+00	2317
186	1	-42387	Dekor	\N	1	1	-186	\N	C	2019-12-20 22:13:53.799521+00	2318
185	1	-42386	Dekor	\N	1	1	-185	\N	C	2019-12-20 22:13:53.799521+00	2319
184	1	-42385	Dekor	\N	1	1	-184	\N	C	2019-12-20 22:13:53.799521+00	2320
183	1	-42384	nej	\N	1	1	-183	\N	C	2019-12-20 22:13:53.799521+00	2321
182	1	-42383	nej	\N	1	1	-182	\N	C	2019-12-20 22:13:53.799521+00	2322
181	1	-42382	Dekor	\N	1	1	-181	\N	C	2019-12-20 22:13:53.799521+00	2323
180	1	-42381	Dekor	\N	1	1	-180	\N	C	2019-12-20 22:13:53.799521+00	2324
179	1	-42380	Dekor	\N	1	1	-179	\N	C	2019-12-20 22:13:53.799521+00	2325
178	1	-42379	Dekor	\N	1	1	-178	\N	C	2019-12-20 22:13:53.799521+00	2326
177	1	-42378	Dekor	\N	1	1	-177	\N	C	2019-12-20 22:13:53.799521+00	2327
176	1	-42377	nej	\N	1	1	-176	\N	C	2019-12-20 22:13:53.799521+00	2328
175	1	-42376	Dekor	\N	1	1	-175	\N	C	2019-12-20 22:13:53.799521+00	2329
174	1	-42375	Dekor	\N	1	1	-174	\N	C	2019-12-20 22:13:53.799521+00	2330
173	1	-42374	nej	\N	1	1	-173	\N	C	2019-12-20 22:13:53.799521+00	2331
172	1	-42373	nej	\N	1	1	-172	\N	C	2019-12-20 22:13:53.799521+00	2332
171	2	-42373	Mynning	\N	1	1	-171	\N	C	2019-12-20 22:13:53.799521+00	2333
170	1	-42372	nej	\N	1	1	-170	\N	C	2019-12-20 22:13:53.799521+00	2334
169	2	-42372	Mynning	\N	1	1	-169	\N	C	2019-12-20 22:13:53.799521+00	2335
168	1	-42371	Dekor	\N	1	1	-168	\N	C	2019-12-20 22:13:53.799521+00	2336
167	1	-42370	nej	\N	1	1	-167	\N	C	2019-12-20 22:13:53.799521+00	2337
166	2	-42370	Mynning	\N	1	1	-166	\N	C	2019-12-20 22:13:53.799521+00	2338
165	1	-42369	nej	\N	1	1	-165	\N	C	2019-12-20 22:13:53.799521+00	2339
164	1	-42368	Dekor	\N	1	1	-164	\N	C	2019-12-20 22:13:53.799521+00	2340
163	1	-42367	nej	\N	1	1	-163	\N	C	2019-12-20 22:13:53.799521+00	2341
162	1	-42366	Dekor	\N	1	1	-162	\N	C	2019-12-20 22:13:53.799521+00	2342
161	1	-42365	nej	\N	1	1	-161	\N	C	2019-12-20 22:13:53.799521+00	2343
160	1	-42364	Dekor	\N	1	1	-160	\N	C	2019-12-20 22:13:53.799521+00	2344
159	1	-42363	nej	\N	1	1	-159	\N	C	2019-12-20 22:13:53.799521+00	2345
158	1	-42362	Dekor	\N	1	1	-158	\N	C	2019-12-20 22:13:53.799521+00	2346
157	2	-42362	Mynning	\N	1	1	-157	\N	C	2019-12-20 22:13:53.799521+00	2347
156	1	-42361	nej	\N	1	1	-156	\N	C	2019-12-20 22:13:53.799521+00	2348
155	2	-42361	Mynning	\N	1	1	-155	\N	C	2019-12-20 22:13:53.799521+00	2349
154	1	-42360	Dekor	\N	1	1	-154	\N	C	2019-12-20 22:13:53.799521+00	2350
153	1	-42359	nej	\N	1	1	-153	\N	C	2019-12-20 22:13:53.799521+00	2351
152	1	-42358	nej	\N	1	1	-152	\N	C	2019-12-20 22:13:53.799521+00	2352
151	2	-42358	Mynning	\N	1	1	-151	\N	C	2019-12-20 22:13:53.799521+00	2353
150	1	-42357	Dekor	\N	1	1	-150	\N	C	2019-12-20 22:13:53.799521+00	2354
149	1	-42356	Dekor	\N	1	1	-149	\N	C	2019-12-20 22:13:53.799521+00	2355
148	2	-42356	Mynning	\N	1	1	-148	\N	C	2019-12-20 22:13:53.799521+00	2356
147	1	-42355	nej	\N	1	1	-147	\N	C	2019-12-20 22:13:53.799521+00	2357
146	2	-42355	Mynning	\N	1	1	-146	\N	C	2019-12-20 22:13:53.799521+00	2358
145	1	-42354	Dekor	\N	1	1	-145	\N	C	2019-12-20 22:13:53.799521+00	2359
144	2	-42354	Mynning	\N	1	1	-144	\N	C	2019-12-20 22:13:53.799521+00	2360
143	1	-42353	Dekor	\N	1	1	-143	\N	C	2019-12-20 22:13:53.799521+00	2361
142	2	-42353	Mynning	\N	1	1	-142	\N	C	2019-12-20 22:13:53.799521+00	2362
141	1	-42352	Dekor	\N	1	1	-141	\N	C	2019-12-20 22:13:53.799521+00	2363
140	2	-42352	Mynning	\N	1	1	-140	\N	C	2019-12-20 22:13:53.799521+00	2364
139	1	-42351	nej	\N	1	1	-139	\N	C	2019-12-20 22:13:53.799521+00	2365
138	2	-42351	Mynning	\N	1	1	-138	\N	C	2019-12-20 22:13:53.799521+00	2366
137	1	-42350	nej	\N	1	1	-137	\N	C	2019-12-20 22:13:53.799521+00	2367
136	2	-42350	Mynning	\N	1	1	-136	\N	C	2019-12-20 22:13:53.799521+00	2368
135	1	-42349	Dekor	\N	1	1	-135	\N	C	2019-12-20 22:13:53.799521+00	2369
134	4	-42349	glättad	\N	1	1	-134	\N	C	2019-12-20 22:13:53.799521+00	2370
133	2	-42347	Mynning	\N	1	1	-133	\N	C	2019-12-20 22:13:53.799521+00	2371
132	2	-42346	Mynning	\N	1	1	-132	\N	C	2019-12-20 22:13:53.799521+00	2372
131	2	-42341	Mynning	\N	1	1	-131	\N	C	2019-12-20 22:13:53.799521+00	2373
130	2	-42339	Mynning	\N	1	1	-130	\N	C	2019-12-20 22:13:53.799521+00	2374
129	1	-42318	nej	\N	1	1	-129	\N	C	2019-12-20 22:13:53.799521+00	2375
128	1	-42317	nej	\N	1	1	-128	\N	C	2019-12-20 22:13:53.799521+00	2376
127	1	-42316	nej	\N	1	1	-127	\N	C	2019-12-20 22:13:53.799521+00	2377
126	1	-42315	Dekor	\N	1	1	-126	\N	C	2019-12-20 22:13:53.799521+00	2378
125	1	-42314	Dekor	\N	1	1	-125	\N	C	2019-12-20 22:13:53.799521+00	2379
124	1	-42313	Dekor	\N	1	1	-124	\N	C	2019-12-20 22:13:53.799521+00	2380
123	1	-42312	Dekor	\N	1	1	-123	\N	C	2019-12-20 22:13:53.799521+00	2381
122	1	-42311	nej	\N	1	1	-122	\N	C	2019-12-20 22:13:53.799521+00	2382
121	1	-42310	nej	\N	1	1	-121	\N	C	2019-12-20 22:13:53.799521+00	2383
120	1	-42309	nej	\N	1	1	-120	\N	C	2019-12-20 22:13:53.799521+00	2384
119	1	-42308	Dekor	\N	1	1	-119	\N	C	2019-12-20 22:13:53.799521+00	2385
118	1	-42307	nej	\N	1	1	-118	\N	C	2019-12-20 22:13:53.799521+00	2386
117	4	-42307	glättad	\N	1	1	-117	\N	C	2019-12-20 22:13:53.799521+00	2387
116	1	-42306	nej	\N	1	1	-116	\N	C	2019-12-20 22:13:53.799521+00	2388
115	4	-42306	glättad	\N	1	1	-115	\N	C	2019-12-20 22:13:53.799521+00	2389
114	1	-42305	nej	\N	1	1	-114	\N	C	2019-12-20 22:13:53.799521+00	2390
113	4	-42305	glättad	\N	1	1	-113	\N	C	2019-12-20 22:13:53.799521+00	2391
112	1	-42304	nej	\N	1	1	-112	\N	C	2019-12-20 22:13:53.799521+00	2392
111	4	-42304	glättad	\N	1	1	-111	\N	C	2019-12-20 22:13:53.799521+00	2393
110	1	-42303	nej	\N	1	1	-110	\N	C	2019-12-20 22:13:53.799521+00	2394
109	1	-42301	nej	\N	1	1	-109	\N	C	2019-12-20 22:13:53.799521+00	2395
108	4	-42301	glättad	\N	1	1	-108	\N	C	2019-12-20 22:13:53.799521+00	2396
107	1	-42300	nej	\N	1	1	-107	\N	C	2019-12-20 22:13:53.799521+00	2397
106	4	-42300	Slammad	\N	1	1	-106	\N	C	2019-12-20 22:13:53.799521+00	2398
105	1	-42299	nej	\N	1	1	-105	\N	C	2019-12-20 22:13:53.799521+00	2399
104	4	-42299	glättad	\N	1	1	-104	\N	C	2019-12-20 22:13:53.799521+00	2400
103	1	-42298	nej	\N	1	1	-103	\N	C	2019-12-20 22:13:53.799521+00	2401
102	1	-42297	nej	\N	1	1	-102	\N	C	2019-12-20 22:13:53.799521+00	2402
101	1	-42296	nej	\N	1	1	-101	\N	C	2019-12-20 22:13:53.799521+00	2403
100	1	-42295	nej	\N	1	1	-100	\N	C	2019-12-20 22:13:53.799521+00	2404
99	1	-42294	nej	\N	1	1	-99	\N	C	2019-12-20 22:13:53.799521+00	2405
98	1	-42293	nej	\N	1	1	-98	\N	C	2019-12-20 22:13:53.799521+00	2406
97	1	-42292	nej	\N	1	1	-97	\N	C	2019-12-20 22:13:53.799521+00	2407
96	1	-42291	nej	\N	1	1	-96	\N	C	2019-12-20 22:13:53.799521+00	2408
95	1	-42290	nej	\N	1	1	-95	\N	C	2019-12-20 22:13:53.799521+00	2409
94	1	-42289	nej	\N	1	1	-94	\N	C	2019-12-20 22:13:53.799521+00	2410
93	1	-42288	nej	\N	1	1	-93	\N	C	2019-12-20 22:13:53.799521+00	2411
92	1	-42287	nej	\N	1	1	-92	\N	C	2019-12-20 22:13:53.799521+00	2412
91	1	-42286	nej	\N	1	1	-91	\N	C	2019-12-20 22:13:53.799521+00	2413
90	1	-42285	nej	\N	1	1	-90	\N	C	2019-12-20 22:13:53.799521+00	2414
89	1	-42284	nej	\N	1	1	-89	\N	C	2019-12-20 22:13:53.799521+00	2415
88	1	-42283	nej	\N	1	1	-88	\N	C	2019-12-20 22:13:53.799521+00	2416
87	1	-42282	nej	\N	1	1	-87	\N	C	2019-12-20 22:13:53.799521+00	2417
86	1	-42281	nej	\N	1	1	-86	\N	C	2019-12-20 22:13:53.799521+00	2418
85	1	-42280	Dekor	\N	1	1	-85	\N	C	2019-12-20 22:13:53.799521+00	2419
84	1	-42279	nej	\N	1	1	-84	\N	C	2019-12-20 22:13:53.799521+00	2420
83	1	-42278	nej	\N	1	1	-83	\N	C	2019-12-20 22:13:53.799521+00	2421
82	1	-42277	nej	\N	1	1	-82	\N	C	2019-12-20 22:13:53.799521+00	2422
81	1	-42276	nej	\N	1	1	-81	\N	C	2019-12-20 22:13:53.799521+00	2423
80	1	-42275	nej	\N	1	1	-80	\N	C	2019-12-20 22:13:53.799521+00	2424
79	1	-42274	nej	\N	1	1	-79	\N	C	2019-12-20 22:13:53.799521+00	2425
78	1	-42273	nej	\N	1	1	-78	\N	C	2019-12-20 22:13:53.799521+00	2426
77	1	-42272	nej	\N	1	1	-77	\N	C	2019-12-20 22:13:53.799521+00	2427
76	1	-42271	nej	\N	1	1	-76	\N	C	2019-12-20 22:13:53.799521+00	2428
75	1	-42270	nej	\N	1	1	-75	\N	C	2019-12-20 22:13:53.799521+00	2429
74	1	-42269	nej	\N	1	1	-74	\N	C	2019-12-20 22:13:53.799521+00	2430
73	1	-42268	nej	\N	1	1	-73	\N	C	2019-12-20 22:13:53.799521+00	2431
72	1	-42266	nej	\N	1	1	-72	\N	C	2019-12-20 22:13:53.799521+00	2432
71	1	-42265	nej	\N	1	1	-71	\N	C	2019-12-20 22:13:53.799521+00	2433
70	1	-42264	nej	\N	1	1	-70	\N	C	2019-12-20 22:13:53.799521+00	2434
69	1	-42263	nej	\N	1	1	-69	\N	C	2019-12-20 22:13:53.799521+00	2435
68	1	-42262	nej	\N	1	1	-68	\N	C	2019-12-20 22:13:53.799521+00	2436
67	1	-42261	nej	\N	1	1	-67	\N	C	2019-12-20 22:13:53.799521+00	2437
66	1	-42260	nej	\N	1	1	-66	\N	C	2019-12-20 22:13:53.799521+00	2438
65	1	-42259	nej	\N	1	1	-65	\N	C	2019-12-20 22:13:53.799521+00	2439
64	1	-42258	nej	\N	1	1	-64	\N	C	2019-12-20 22:13:53.799521+00	2440
63	1	-42257	nej	\N	1	1	-63	\N	C	2019-12-20 22:13:53.799521+00	2441
62	1	-42256	nej	\N	1	1	-62	\N	C	2019-12-20 22:13:53.799521+00	2442
61	1	-42255	nej	\N	1	1	-61	\N	C	2019-12-20 22:13:53.799521+00	2443
60	1	-42254	nej	\N	1	1	-60	\N	C	2019-12-20 22:13:53.799521+00	2444
59	1	-42253	nej	\N	1	1	-59	\N	C	2019-12-20 22:13:53.799521+00	2445
58	1	-42252	nej	\N	1	1	-58	\N	C	2019-12-20 22:13:53.799521+00	2446
57	1	-42251	nej	\N	1	1	-57	\N	C	2019-12-20 22:13:53.799521+00	2447
56	1	-42250	nej	\N	1	1	-56	\N	C	2019-12-20 22:13:53.799521+00	2448
55	1	-42249	nej	\N	1	1	-55	\N	C	2019-12-20 22:13:53.799521+00	2449
54	2	-42249	Botten	\N	1	1	-54	\N	C	2019-12-20 22:13:53.799521+00	2450
53	1	-42248	nej	\N	1	1	-53	\N	C	2019-12-20 22:13:53.799521+00	2451
52	1	-42247	nej	\N	1	1	-52	\N	C	2019-12-20 22:13:53.799521+00	2452
51	1	-42246	nej	\N	1	1	-51	\N	C	2019-12-20 22:13:53.799521+00	2453
50	1	-42245	nej	\N	1	1	-50	\N	C	2019-12-20 22:13:53.799521+00	2454
49	1	-42244	nej	\N	1	1	-49	\N	C	2019-12-20 22:13:53.799521+00	2455
48	4	-42244	glättad	\N	1	1	-48	\N	C	2019-12-20 22:13:53.799521+00	2456
47	1	-42243	nej	\N	1	1	-47	\N	C	2019-12-20 22:13:53.799521+00	2457
46	4	-42243	s	\N	1	1	-46	\N	C	2019-12-20 22:13:53.799521+00	2458
45	1	-42242	nej	\N	1	1	-45	\N	C	2019-12-20 22:13:53.799521+00	2459
44	4	-42242	glättad	\N	1	1	-44	\N	C	2019-12-20 22:13:53.799521+00	2460
43	1	-42241	nej	\N	1	1	-43	\N	C	2019-12-20 22:13:53.799521+00	2461
42	1	-42240	nej	\N	1	1	-42	\N	C	2019-12-20 22:13:53.799521+00	2462
41	1	-42239	nej	\N	1	1	-41	\N	C	2019-12-20 22:13:53.799521+00	2463
40	1	-42238	nej	\N	1	1	-40	\N	C	2019-12-20 22:13:53.799521+00	2464
39	1	-42237	nej	\N	1	1	-39	\N	C	2019-12-20 22:13:53.799521+00	2465
38	1	-42236	nej	\N	1	1	-38	\N	C	2019-12-20 22:13:53.799521+00	2466
37	1	-42235	nej	\N	1	1	-37	\N	C	2019-12-20 22:13:53.799521+00	2467
36	1	-42234	nej	\N	1	1	-36	\N	C	2019-12-20 22:13:53.799521+00	2468
35	1	-42233	Dekor	\N	1	1	-35	\N	C	2019-12-20 22:13:53.799521+00	2469
34	1	-42232	Dekor	\N	1	1	-34	\N	C	2019-12-20 22:13:53.799521+00	2470
33	4	-42232	glättad	\N	1	1	-33	\N	C	2019-12-20 22:13:53.799521+00	2471
32	2	-42232	Mynning	\N	1	1	-32	\N	C	2019-12-20 22:13:53.799521+00	2472
31	1	-42231	nej	\N	1	1	-31	\N	C	2019-12-20 22:13:53.799521+00	2473
30	1	-42230	nej	\N	1	1	-30	\N	C	2019-12-20 22:13:53.799521+00	2474
29	1	-42229	nej	\N	1	1	-29	\N	C	2019-12-20 22:13:53.799521+00	2475
28	1	-42228	nej	\N	1	1	-28	\N	C	2019-12-20 22:13:53.799521+00	2476
27	1	-42227	nej	\N	1	1	-27	\N	C	2019-12-20 22:13:53.799521+00	2477
26	4	-42227	glättad	\N	1	1	-26	\N	C	2019-12-20 22:13:53.799521+00	2478
25	1	-42226	nej	\N	1	1	-25	\N	C	2019-12-20 22:13:53.799521+00	2479
24	1	-42225	nej	\N	1	1	-24	\N	C	2019-12-20 22:13:53.799521+00	2480
23	1	-42224	nej	\N	1	1	-23	\N	C	2019-12-20 22:13:53.799521+00	2481
22	1	-42223	nej	\N	1	1	-22	\N	C	2019-12-20 22:13:53.799521+00	2482
21	1	-42222	nej	\N	1	1	-21	\N	C	2019-12-20 22:13:53.799521+00	2483
20	1	-42221	nej	\N	1	1	-20	\N	C	2019-12-20 22:13:53.799521+00	2484
19	1	-42220	nej	\N	1	1	-19	\N	C	2019-12-20 22:13:53.799521+00	2485
18	1	-42219	nej	\N	1	1	-18	\N	C	2019-12-20 22:13:53.799521+00	2486
17	1	-42218	nej	\N	1	1	-17	\N	C	2019-12-20 22:13:53.799521+00	2487
16	1	-42217	nej	\N	1	1	-16	\N	C	2019-12-20 22:13:53.799521+00	2488
15	1	-42216	nej	\N	1	1	-15	\N	C	2019-12-20 22:13:53.799521+00	2489
14	1	-42215	Dekor	\N	1	1	-14	\N	C	2019-12-20 22:13:53.799521+00	2490
13	1	-42214	nej	\N	1	1	-13	\N	C	2019-12-20 22:13:53.799521+00	2491
12	1	-42213	nej	\N	1	1	-12	\N	C	2019-12-20 22:13:53.799521+00	2492
11	1	-42212	nej	\N	1	1	-11	\N	C	2019-12-20 22:13:53.799521+00	2493
10	1	-42211	nej	\N	1	1	-10	\N	C	2019-12-20 22:13:53.799521+00	2494
9	1	-42210	nej	\N	1	1	-9	\N	C	2019-12-20 22:13:53.799521+00	2495
8	1	-42209	nej	\N	1	1	-8	\N	C	2019-12-20 22:13:53.799521+00	2496
7	1	-42208	nej	\N	1	1	-7	\N	C	2019-12-20 22:13:53.799521+00	2497
6	1	-42207	nej	\N	1	1	-6	\N	C	2019-12-20 22:13:53.799521+00	2498
5	1	-42206	Dekor	\N	1	1	-5	\N	C	2019-12-20 22:13:53.799521+00	2499
4	2	-42206	Mynning	\N	1	1	-4	\N	C	2019-12-20 22:13:53.799521+00	2500
3	1	-42205	nej	\N	1	1	-3	\N	C	2019-12-20 22:13:53.799521+00	2501
2	1	-42204	nej	\N	1	1	-2	\N	C	2019-12-20 22:13:53.799521+00	2502
1	4	-42204	glättad	\N	1	1	-1	\N	C	2019-12-20 22:13:53.799521+00	2503
350	2	-350	rim of initial Jomon pottery of type SIV	\N	4	1	-350	\N	C	2019-12-20 22:14:28.053842+00	4075
349	2	-349	body of initial Jomon pottery of type SIV	\N	4	1	-349	\N	C	2019-12-20 22:14:28.053842+00	4076
348	2	-348	body of initial Jomon pottery of type SIV	\N	4	1	-348	\N	C	2019-12-20 22:14:28.053842+00	4077
347	2	-347	body of incipient Jomon pottery of type SIII	\N	4	1	-347	\N	C	2019-12-20 22:14:28.053842+00	4078
346	2	-346	body of incipient Jomon pottery of type SIII	\N	4	1	-346	\N	C	2019-12-20 22:14:28.053842+00	4079
345	2	-345	body of incipient Jomon pottery of type SIII	\N	4	1	-345	\N	C	2019-12-20 22:14:28.053842+00	4080
344	2	-344	rim of incipient Jomon pottery of type SIII	\N	4	1	-344	\N	C	2019-12-20 22:14:28.053842+00	4081
343	2	-343	body of incipient Jomon pottery of type SIII	\N	4	1	-343	\N	C	2019-12-20 22:14:28.053842+00	4082
342	2	-342	base of initial Jomon pottery of type SIV	\N	4	1	-342	\N	C	2019-12-20 22:14:28.053842+00	4083
341	2	-341	base of initial Jomon pottery of type SIV	\N	4	1	-341	\N	C	2019-12-20 22:14:28.053842+00	4084
340	2	-340	base of initial Jomon pottery of type SIV	\N	4	1	-340	\N	C	2019-12-20 22:14:28.053842+00	4085
339	2	-339	rim of initial Jomon pottery of type SIV	\N	4	1	-339	\N	C	2019-12-20 22:14:28.053842+00	4086
338	2	-338	body of initial Jomon pottery of type SIV	\N	4	1	-338	\N	C	2019-12-20 22:14:28.053842+00	4087
337	2	-337	body of initial Jomon pottery of type SIV	\N	4	1	-337	\N	C	2019-12-20 22:14:28.053842+00	4088
336	2	-336	body of initial Jomon pottery of type SIV	\N	4	1	-336	\N	C	2019-12-20 22:14:28.053842+00	4089
335	2	-335	body of initial Jomon pottery of type SIV	\N	4	1	-335	\N	C	2019-12-20 22:14:28.053842+00	4090
334	2	-334	body of initial Jomon pottery of type SIV	\N	4	1	-334	\N	C	2019-12-20 22:14:28.053842+00	4091
333	2	-333	body of initial Jomon pottery of type SIV	\N	4	1	-333	\N	C	2019-12-20 22:14:28.053842+00	4092
332	2	-332	body of initial Jomon pottery of type SIV	\N	4	1	-332	\N	C	2019-12-20 22:14:28.053842+00	4093
331	2	-331	body of initial Jomon pottery of type SIV	\N	4	1	-331	\N	C	2019-12-20 22:14:28.053842+00	4094
330	2	-330	rim of initial Jomon pottery of type SIV	\N	4	1	-330	\N	C	2019-12-20 22:14:28.053842+00	4095
329	2	-329	rim of initial Jomon pottery of type SIV	\N	4	1	-329	\N	C	2019-12-20 22:14:28.053842+00	4096
328	2	-328	rim of initial Jomon pottery of type SIV	\N	4	1	-328	\N	C	2019-12-20 22:14:28.053842+00	4097
327	2	-327	rim of initial Jomon pottery of type SIV	\N	4	1	-327	\N	C	2019-12-20 22:14:28.053842+00	4098
326	2	-326	rim of initial Jomon pottery of type SIV	\N	4	1	-326	\N	C	2019-12-20 22:14:28.053842+00	4099
325	2	-325	rim of initial Jomon pottery of type SIV	\N	4	1	-325	\N	C	2019-12-20 22:14:28.053842+00	4100
324	2	-324	rim of initial Jomon pottery of type SIV	\N	4	1	-324	\N	C	2019-12-20 22:14:28.053842+00	4101
306	2	-306	body of initial Jomon pottery of type SIV	\N	4	1	-306	\N	C	2019-12-20 22:14:28.053842+00	4119
305	2	-305	body of initial Jomon pottery of type SIV	\N	4	1	-305	\N	C	2019-12-20 22:14:28.053842+00	4120
304	2	-304	body of initial Jomon pottery of type SIV	\N	4	1	-304	\N	C	2019-12-20 22:14:28.053842+00	4121
303	2	-303	body of initial Jomon pottery of type SIV	\N	4	1	-303	\N	C	2019-12-20 22:14:28.053842+00	4122
302	2	-302	body of initial Jomon pottery of type SIV	\N	4	1	-302	\N	C	2019-12-20 22:14:28.053842+00	4123
301	2	-301	rim of initial Jomon pottery of type SIV	\N	4	1	-301	\N	C	2019-12-20 22:14:28.053842+00	4124
300	2	-300	rim of initial Jomon pottery of type SIV	\N	4	1	-300	\N	C	2019-12-20 22:14:28.053842+00	4125
299	2	-299	rim of initial Jomon pottery of type SIV	\N	4	1	-299	\N	C	2019-12-20 22:14:28.053842+00	4126
298	2	-298	rim of initial Jomon pottery of type SIV	\N	4	1	-298	\N	C	2019-12-20 22:14:28.053842+00	4127
297	2	-297	rim of initial Jomon pottery of type SIV	\N	4	1	-297	\N	C	2019-12-20 22:14:28.053842+00	4128
296	2	-296	rim of initial Jomon pottery of type SIV	\N	4	1	-296	\N	C	2019-12-20 22:14:28.053842+00	4129
295	2	-295	rim of initial Jomon pottery of type SIV	\N	4	1	-295	\N	C	2019-12-20 22:14:28.053842+00	4130
294	2	-294	rim of initial Jomon pottery of type SIV	\N	4	1	-294	\N	C	2019-12-20 22:14:28.053842+00	4131
293	2	-293	rim of initial Jomon pottery of type SIV	\N	4	1	-293	\N	C	2019-12-20 22:14:28.053842+00	4132
292	2	-292	rim of initial Jomon pottery of type SIV	\N	4	1	-292	\N	C	2019-12-20 22:14:28.053842+00	4133
291	2	-291	rim of initial Jomon pottery of type SIV	\N	4	1	-291	\N	C	2019-12-20 22:14:28.053842+00	4134
290	2	-290	rim of initial Jomon pottery of type SIV	\N	4	1	-290	\N	C	2019-12-20 22:14:28.053842+00	4135
289	2	-289	rim of initial Jomon pottery of type SIV	\N	4	1	-289	\N	C	2019-12-20 22:14:28.053842+00	4136
288	2	-288	rim of initial Jomon pottery of type SIV	\N	4	1	-288	\N	C	2019-12-20 22:14:28.053842+00	4137
287	2	-287	rim of initial Jomon pottery of type SIV	\N	4	1	-287	\N	C	2019-12-20 22:14:28.053842+00	4138
286	2	-286	rim of initial Jomon pottery of type SIV	\N	4	1	-286	\N	C	2019-12-20 22:14:28.053842+00	4139
285	2	-285	rim of initial Jomon pottery of type SIV	\N	4	1	-285	\N	C	2019-12-20 22:14:28.053842+00	4140
284	2	-284	rim of initial Jomon pottery of type SIV	\N	4	1	-284	\N	C	2019-12-20 22:14:28.053842+00	4141
283	2	-283	rim of initial Jomon pottery of type SIV	\N	4	1	-283	\N	C	2019-12-20 22:14:28.053842+00	4142
282	2	-282	rim of initial Jomon pottery of type SIV	\N	4	1	-282	\N	C	2019-12-20 22:14:28.053842+00	4143
281	2	-281	rim of initial Jomon pottery of type SIV	\N	4	1	-281	\N	C	2019-12-20 22:14:28.053842+00	4144
280	2	-280	rim of initial Jomon pottery of type SIV	\N	4	1	-280	\N	C	2019-12-20 22:14:28.053842+00	4145
279	2	-279	rim of initial Jomon pottery of type SIV	\N	4	1	-279	\N	C	2019-12-20 22:14:28.053842+00	4146
278	2	-278	rim of initial Jomon pottery of type SIV	\N	4	1	-278	\N	C	2019-12-20 22:14:28.053842+00	4147
277	2	-277	rim of initial Jomon pottery of type SIV	\N	4	1	-277	\N	C	2019-12-20 22:14:28.053842+00	4148
276	2	-276	rim of initial Jomon pottery of type SIV	\N	4	1	-276	\N	C	2019-12-20 22:14:28.053842+00	4149
275	2	-275	rim of initial Jomon pottery of type SIV	\N	4	1	-275	\N	C	2019-12-20 22:14:28.053842+00	4150
274	2	-274	rim of initial Jomon pottery of type SIV	\N	4	1	-274	\N	C	2019-12-20 22:14:28.053842+00	4151
273	2	-273	rim of initial Jomon pottery of type SIV	\N	4	1	-273	\N	C	2019-12-20 22:14:28.053842+00	4152
272	2	-272	rim of initial Jomon pottery of type SIV	\N	4	1	-272	\N	C	2019-12-20 22:14:28.053842+00	4153
271	2	-271	rim of initial Jomon pottery of type SIV	\N	4	1	-271	\N	C	2019-12-20 22:14:28.053842+00	4154
270	2	-270	rim of initial Jomon pottery of type SIV	\N	4	1	-270	\N	C	2019-12-20 22:14:28.053842+00	4155
269	2	-269	rim of initial Jomon pottery of type SIV	\N	4	1	-269	\N	C	2019-12-20 22:14:28.053842+00	4156
268	2	-268	rim of initial Jomon pottery of type SIV	\N	4	1	-268	\N	C	2019-12-20 22:14:28.053842+00	4157
267	2	-267	rim of initial Jomon pottery of type SIV	\N	4	1	-267	\N	C	2019-12-20 22:14:28.053842+00	4158
266	2	-266	rim of initial Jomon pottery of type SIV	\N	4	1	-266	\N	C	2019-12-20 22:14:28.053842+00	4159
265	2	-265	rim of initial Jomon pottery of type SIV	\N	4	1	-265	\N	C	2019-12-20 22:14:28.053842+00	4160
264	2	-264	rim of initial Jomon pottery of type SIV	\N	4	1	-264	\N	C	2019-12-20 22:14:28.053842+00	4161
263	2	-263	rim of initial Jomon pottery of type SIV	\N	4	1	-263	\N	C	2019-12-20 22:14:28.053842+00	4162
262	2	-262	rim of initial Jomon pottery of type SIV	\N	4	1	-262	\N	C	2019-12-20 22:14:28.053842+00	4163
261	2	-261	rim of initial Jomon pottery of type SIV	\N	4	1	-261	\N	C	2019-12-20 22:14:28.053842+00	4164
260	2	-260	rim of initial Jomon pottery of type SIV	\N	4	1	-260	\N	C	2019-12-20 22:14:28.053842+00	4165
259	2	-259	rim of initial Jomon pottery of type SIV	\N	4	1	-259	\N	C	2019-12-20 22:14:28.053842+00	4166
258	2	-258	body of incipient Jomon pottery of type SIII	\N	4	1	-258	\N	C	2019-12-20 22:14:28.053842+00	4167
257	2	-257	body of incipient Jomon pottery of type SIII	\N	4	1	-257	\N	C	2019-12-20 22:14:28.053842+00	4168
256	2	-256	body of incipient Jomon pottery of type SIII	\N	4	1	-256	\N	C	2019-12-20 22:14:28.053842+00	4169
255	2	-255	body of incipient Jomon pottery of type SIII	\N	4	1	-255	\N	C	2019-12-20 22:14:28.053842+00	4170
254	2	-254	body of incipient Jomon pottery of type SIII	\N	4	1	-254	\N	C	2019-12-20 22:14:28.053842+00	4171
253	2	-253	body of incipient Jomon pottery of type SIII	\N	4	1	-253	\N	C	2019-12-20 22:14:28.053842+00	4172
252	2	-252	body of incipient Jomon pottery of type SIII	\N	4	1	-252	\N	C	2019-12-20 22:14:28.053842+00	4173
251	2	-251	body of incipient Jomon pottery of type SIII	\N	4	1	-251	\N	C	2019-12-20 22:14:28.053842+00	4174
250	2	-250	body of incipient Jomon pottery of type SIII	\N	4	1	-250	\N	C	2019-12-20 22:14:28.053842+00	4175
249	2	-249	body of incipient Jomon pottery of type SIII	\N	4	1	-249	\N	C	2019-12-20 22:14:28.053842+00	4176
248	2	-248	body of incipient Jomon pottery of type SIII	\N	4	1	-248	\N	C	2019-12-20 22:14:28.053842+00	4177
247	2	-247	body of incipient Jomon pottery of type SIII	\N	4	1	-247	\N	C	2019-12-20 22:14:28.053842+00	4178
246	2	-246	body of incipient Jomon pottery of type SIII	\N	4	1	-246	\N	C	2019-12-20 22:14:28.053842+00	4179
245	2	-245	body of incipient Jomon pottery of type SIII	\N	4	1	-245	\N	C	2019-12-20 22:14:28.053842+00	4180
244	2	-244	body of incipient Jomon pottery of type SIII	\N	4	1	-244	\N	C	2019-12-20 22:14:28.053842+00	4181
243	2	-243	body of incipient Jomon pottery of type SIII	\N	4	1	-243	\N	C	2019-12-20 22:14:28.053842+00	4182
242	2	-242	body of incipient Jomon pottery of type SIII	\N	4	1	-242	\N	C	2019-12-20 22:14:28.053842+00	4183
241	2	-241	body of incipient Jomon pottery of type SIII	\N	4	1	-241	\N	C	2019-12-20 22:14:28.053842+00	4184
240	2	-240	body of incipient Jomon pottery of type SIII	\N	4	1	-240	\N	C	2019-12-20 22:14:28.053842+00	4185
239	2	-239	rim of incipient Jomon pottery of type SIII	\N	4	1	-239	\N	C	2019-12-20 22:14:28.053842+00	4186
238	2	-238	body of incipient Jomon pottery of type SIII	\N	4	1	-238	\N	C	2019-12-20 22:14:28.053842+00	4187
237	2	-237	body of incipient Jomon pottery of type SIII	\N	4	1	-237	\N	C	2019-12-20 22:14:28.053842+00	4188
236	2	-236	body of incipient Jomon pottery of type SIII	\N	4	1	-236	\N	C	2019-12-20 22:14:28.053842+00	4189
235	2	-235	body of incipient Jomon pottery of type SIII	\N	4	1	-235	\N	C	2019-12-20 22:14:28.053842+00	4190
234	2	-234	rim of incipient Jomon pottery of type SIII	\N	4	1	-234	\N	C	2019-12-20 22:14:28.053842+00	4191
233	2	-233	body of incipient Jomon pottery of type SIII	\N	4	1	-233	\N	C	2019-12-20 22:14:28.053842+00	4192
232	2	-232	body of incipient Jomon pottery of type SIII	\N	4	1	-232	\N	C	2019-12-20 22:14:28.053842+00	4193
231	2	-231	body of incipient Jomon pottery of type SIII	\N	4	1	-231	\N	C	2019-12-20 22:14:28.053842+00	4194
230	2	-230	body of initial Jomon pottery of type SIV	\N	4	1	-230	\N	C	2019-12-20 22:14:28.053842+00	4195
229	2	-229	body of initial Jomon pottery of type SIV	\N	4	1	-229	\N	C	2019-12-20 22:14:28.053842+00	4196
228	2	-228	body of initial Jomon pottery of type SIV	\N	4	1	-228	\N	C	2019-12-20 22:14:28.053842+00	4197
227	2	-227	body of initial Jomon pottery of type SIV	\N	4	1	-227	\N	C	2019-12-20 22:14:28.053842+00	4198
226	2	-226	body of initial Jomon pottery of type SIV	\N	4	1	-226	\N	C	2019-12-20 22:14:28.053842+00	4199
225	2	-225	body of initial Jomon pottery of type SIV	\N	4	1	-225	\N	C	2019-12-20 22:14:28.053842+00	4200
224	2	-224	body of initial Jomon pottery of type SIV	\N	4	1	-224	\N	C	2019-12-20 22:14:28.053842+00	4201
223	2	-223	body of initial Jomon pottery of type SIV	\N	4	1	-223	\N	C	2019-12-20 22:14:28.053842+00	4202
222	2	-222	body of initial Jomon pottery of type SIV	\N	4	1	-222	\N	C	2019-12-20 22:14:28.053842+00	4203
221	2	-221	body of initial Jomon pottery of type SIV	\N	4	1	-221	\N	C	2019-12-20 22:14:28.053842+00	4204
220	2	-220	body of initial Jomon pottery of type SIV	\N	4	1	-220	\N	C	2019-12-20 22:14:28.053842+00	4205
219	2	-219	body of initial Jomon pottery of type SIV	\N	4	1	-219	\N	C	2019-12-20 22:14:28.053842+00	4206
218	2	-218	body of initial Jomon pottery of type SIV	\N	4	1	-218	\N	C	2019-12-20 22:14:28.053842+00	4207
217	2	-217	body of initial Jomon pottery of type SIV	\N	4	1	-217	\N	C	2019-12-20 22:14:28.053842+00	4208
216	2	-216	body of initial Jomon pottery of type SIV	\N	4	1	-216	\N	C	2019-12-20 22:14:28.053842+00	4209
215	2	-215	body of initial Jomon pottery of type SIV	\N	4	1	-215	\N	C	2019-12-20 22:14:28.053842+00	4210
214	2	-214	body of initial Jomon pottery of type SIV	\N	4	1	-214	\N	C	2019-12-20 22:14:28.053842+00	4211
213	2	-213	body of initial Jomon pottery of type SIV	\N	4	1	-213	\N	C	2019-12-20 22:14:28.053842+00	4212
212	2	-212	body of initial Jomon pottery of type SIV	\N	4	1	-212	\N	C	2019-12-20 22:14:28.053842+00	4213
211	2	-211	body of initial Jomon pottery of type SIV	\N	4	1	-211	\N	C	2019-12-20 22:14:28.053842+00	4214
210	2	-210	body of initial Jomon pottery of type SIV	\N	4	1	-210	\N	C	2019-12-20 22:14:28.053842+00	4215
209	2	-209	body of initial Jomon pottery of type SIV	\N	4	1	-209	\N	C	2019-12-20 22:14:28.053842+00	4216
208	2	-208	body of initial Jomon pottery of type SIV	\N	4	1	-208	\N	C	2019-12-20 22:14:28.053842+00	4217
207	2	-207	body of initial Jomon pottery of type SIV	\N	4	1	-207	\N	C	2019-12-20 22:14:28.053842+00	4218
206	2	-206	body of initial Jomon pottery of type SIV	\N	4	1	-206	\N	C	2019-12-20 22:14:28.053842+00	4219
205	2	-205	body of initial Jomon pottery of type SIV	\N	4	1	-205	\N	C	2019-12-20 22:14:28.053842+00	4220
204	2	-204	body of initial Jomon pottery of type SIV	\N	4	1	-204	\N	C	2019-12-20 22:14:28.053842+00	4221
203	2	-203	body of initial Jomon pottery of type SIV	\N	4	1	-203	\N	C	2019-12-20 22:14:28.053842+00	4222
202	2	-202	body of initial Jomon pottery of type SIV	\N	4	1	-202	\N	C	2019-12-20 22:14:28.053842+00	4223
201	2	-201	body of initial Jomon pottery of type SIV	\N	4	1	-201	\N	C	2019-12-20 22:14:28.053842+00	4224
200	2	-200	body of initial Jomon pottery of type SIV	\N	4	1	-200	\N	C	2019-12-20 22:14:28.053842+00	4225
199	2	-199	body of initial Jomon pottery of type SIV	\N	4	1	-199	\N	C	2019-12-20 22:14:28.053842+00	4226
198	2	-198	rim of initial Jomon pottery of type SIV	\N	4	1	-198	\N	C	2019-12-20 22:14:28.053842+00	4227
197	2	-197	rim of initial Jomon pottery of type SIV	\N	4	1	-197	\N	C	2019-12-20 22:14:28.053842+00	4228
196	2	-196	rim of incipient Jomon pottery of type SIII	\N	4	1	-196	\N	C	2019-12-20 22:14:28.053842+00	4229
195	2	-195	body of incipient Jomon pottery of type SIII	\N	4	1	-195	\N	C	2019-12-20 22:14:28.053842+00	4230
194	2	-194	body of incipient Jomon pottery of type SIII	\N	4	1	-194	\N	C	2019-12-20 22:14:28.053842+00	4231
193	2	-193	body of incipient Jomon pottery of type SIII	\N	4	1	-193	\N	C	2019-12-20 22:14:28.053842+00	4232
192	2	-192	body of incipient Jomon pottery of type SIII	\N	4	1	-192	\N	C	2019-12-20 22:14:28.053842+00	4233
191	2	-191	body of incipient Jomon pottery of type SIII	\N	4	1	-191	\N	C	2019-12-20 22:14:28.053842+00	4234
190	2	-190	body of incipient Jomon pottery of type SIII	\N	4	1	-190	\N	C	2019-12-20 22:14:28.053842+00	4235
189	2	-189	body of incipient Jomon pottery of type SIII	\N	4	1	-189	\N	C	2019-12-20 22:14:28.053842+00	4236
188	2	-188	body of incipient Jomon pottery of type SIII	\N	4	1	-188	\N	C	2019-12-20 22:14:28.053842+00	4237
187	2	-187	rim of incipient Jomon pottery of type SIII	\N	4	1	-187	\N	C	2019-12-20 22:14:28.053842+00	4238
186	2	-186	rim of incipient Jomon pottery of type SIII	\N	4	1	-186	\N	C	2019-12-20 22:14:28.053842+00	4239
185	2	-185	rim of incipient Jomon pottery of type SIII	\N	4	1	-185	\N	C	2019-12-20 22:14:28.053842+00	4240
184	2	-184	rim of incipient Jomon pottery of type SIII	\N	4	1	-184	\N	C	2019-12-20 22:14:28.053842+00	4241
183	2	-183	rim of incipient Jomon pottery of type SIII	\N	4	1	-183	\N	C	2019-12-20 22:14:28.053842+00	4242
182	2	-182	rim of incipient Jomon pottery of type SIII	\N	4	1	-182	\N	C	2019-12-20 22:14:28.053842+00	4243
181	2	-181	body of initial Jomon pottery of type SIV	\N	4	1	-181	\N	C	2019-12-20 22:14:28.053842+00	4244
180	2	-180	body of initial Jomon pottery of type SIV	\N	4	1	-180	\N	C	2019-12-20 22:14:28.053842+00	4245
179	2	-179	body of initial Jomon pottery of type SIV	\N	4	1	-179	\N	C	2019-12-20 22:14:28.053842+00	4246
178	2	-178	body of initial Jomon pottery of type SIV	\N	4	1	-178	\N	C	2019-12-20 22:14:28.053842+00	4247
177	2	-177	body of initial Jomon pottery of type SIV	\N	4	1	-177	\N	C	2019-12-20 22:14:28.053842+00	4248
176	2	-176	body of initial Jomon pottery of type SIV	\N	4	1	-176	\N	C	2019-12-20 22:14:28.053842+00	4249
175	2	-175	body of initial Jomon pottery of type SIV	\N	4	1	-175	\N	C	2019-12-20 22:14:28.053842+00	4250
174	2	-174	body of initial Jomon pottery of type SIV	\N	4	1	-174	\N	C	2019-12-20 22:14:28.053842+00	4251
173	2	-173	rim of initial Jomon pottery of type SIV	\N	4	1	-173	\N	C	2019-12-20 22:14:28.053842+00	4252
172	2	-172	body of initial Jomon pottery of type SIV	\N	4	1	-172	\N	C	2019-12-20 22:14:28.053842+00	4253
171	2	-171	body of initial Jomon pottery of type SIV	\N	4	1	-171	\N	C	2019-12-20 22:14:28.053842+00	4254
170	2	-170	body of initial Jomon pottery of type SIV	\N	4	1	-170	\N	C	2019-12-20 22:14:28.053842+00	4255
169	2	-169	body of initial Jomon pottery of type SIV	\N	4	1	-169	\N	C	2019-12-20 22:14:28.053842+00	4256
168	2	-168	body of initial Jomon pottery of type SIV	\N	4	1	-168	\N	C	2019-12-20 22:14:28.053842+00	4257
167	2	-167	rim of initial Jomon pottery of type SIV	\N	4	1	-167	\N	C	2019-12-20 22:14:28.053842+00	4258
166	2	-166	rim of initial Jomon pottery of type SIV	\N	4	1	-166	\N	C	2019-12-20 22:14:28.053842+00	4259
165	2	-165	rim of initial Jomon pottery of type SIV	\N	4	1	-165	\N	C	2019-12-20 22:14:28.053842+00	4260
164	2	-164	rim of initial Jomon pottery of type SIV	\N	4	1	-164	\N	C	2019-12-20 22:14:28.053842+00	4261
163	2	-163	rim of initial Jomon pottery of type SIV	\N	4	1	-163	\N	C	2019-12-20 22:14:28.053842+00	4262
162	2	-162	rim of initial Jomon pottery of type SIV	\N	4	1	-162	\N	C	2019-12-20 22:14:28.053842+00	4263
161	2	-161	rim of initial Jomon pottery of type SIV	\N	4	1	-161	\N	C	2019-12-20 22:14:28.053842+00	4264
160	2	-160	rim of initial Jomon pottery of type SIV	\N	4	1	-160	\N	C	2019-12-20 22:14:28.053842+00	4265
159	2	-159	rim of initial Jomon pottery of type SIV	\N	4	1	-159	\N	C	2019-12-20 22:14:28.053842+00	4266
158	2	-158	body of initial Jomon pottery of type SIV	\N	4	1	-158	\N	C	2019-12-20 22:14:28.053842+00	4267
157	2	-157	rim of initial Jomon pottery of type SIV	\N	4	1	-157	\N	C	2019-12-20 22:14:28.053842+00	4268
156	2	-156	body of initial Jomon pottery of type SIV	\N	4	1	-156	\N	C	2019-12-20 22:14:28.053842+00	4269
155	2	-155	body of initial Jomon pottery of type SIV	\N	4	1	-155	\N	C	2019-12-20 22:14:28.053842+00	4270
154	2	-154	body of initial Jomon pottery of type SIV	\N	4	1	-154	\N	C	2019-12-20 22:14:28.053842+00	4271
153	2	-153	body of initial Jomon pottery of type SIV	\N	4	1	-153	\N	C	2019-12-20 22:14:28.053842+00	4272
152	2	-152	body of initial Jomon pottery of type SIV	\N	4	1	-152	\N	C	2019-12-20 22:14:28.053842+00	4273
151	2	-151	body of initial Jomon pottery of type SIV	\N	4	1	-151	\N	C	2019-12-20 22:14:28.053842+00	4274
150	2	-150	body of initial Jomon pottery of type SIV	\N	4	1	-150	\N	C	2019-12-20 22:14:28.053842+00	4275
149	2	-149	body of initial Jomon pottery of type SIV	\N	4	1	-149	\N	C	2019-12-20 22:14:28.053842+00	4276
148	2	-148	body of initial Jomon pottery of type SIV	\N	4	1	-148	\N	C	2019-12-20 22:14:28.053842+00	4277
147	2	-147	body of initial Jomon pottery of type SIV	\N	4	1	-147	\N	C	2019-12-20 22:14:28.053842+00	4278
146	2	-146	body of initial Jomon pottery of type SIV	\N	4	1	-146	\N	C	2019-12-20 22:14:28.053842+00	4279
145	2	-145	rim of initial Jomon pottery of type SIV	\N	4	1	-145	\N	C	2019-12-20 22:14:28.053842+00	4280
144	2	-144	body of initial Jomon pottery of type SIV	\N	4	1	-144	\N	C	2019-12-20 22:14:28.053842+00	4281
143	2	-143	body of initial Jomon pottery of type SIV	\N	4	1	-143	\N	C	2019-12-20 22:14:28.053842+00	4282
142	2	-142	body of initial Jomon pottery of type SIV	\N	4	1	-142	\N	C	2019-12-20 22:14:28.053842+00	4283
141	2	-141	rim of initial Jomon pottery of type SIV	\N	4	1	-141	\N	C	2019-12-20 22:14:28.053842+00	4284
140	2	-140	body of initial Jomon pottery of type SIV	\N	4	1	-140	\N	C	2019-12-20 22:14:28.053842+00	4285
139	2	-139	body of initial Jomon pottery of type SIV	\N	4	1	-139	\N	C	2019-12-20 22:14:28.053842+00	4286
138	2	-138	body of incipient Jomon pottery of type SIII	\N	4	1	-138	\N	C	2019-12-20 22:14:28.053842+00	4287
137	2	-137	body of incipient Jomon pottery of type SIII	\N	4	1	-137	\N	C	2019-12-20 22:14:28.053842+00	4288
136	2	-136	rim of incipient Jomon pottery of type SIII	\N	4	1	-136	\N	C	2019-12-20 22:14:28.053842+00	4289
135	2	-135	rim of incipient Jomon pottery of type SIII	\N	4	1	-135	\N	C	2019-12-20 22:14:28.053842+00	4290
134	2	-134	body of incipient Jomon pottery of type SIII	\N	4	1	-134	\N	C	2019-12-20 22:14:28.053842+00	4291
133	2	-133	body of incipient Jomon pottery of type SIII	\N	4	1	-133	\N	C	2019-12-20 22:14:28.053842+00	4292
132	2	-132	body of incipient Jomon pottery of type SIII	\N	4	1	-132	\N	C	2019-12-20 22:14:28.053842+00	4293
131	2	-131	body of incipient Jomon pottery of type SIII	\N	4	1	-131	\N	C	2019-12-20 22:14:28.053842+00	4294
130	2	-130	body of incipient Jomon pottery of type SIII	\N	4	1	-130	\N	C	2019-12-20 22:14:28.053842+00	4295
129	2	-129	body of incipient Jomon pottery of type SIII	\N	4	1	-129	\N	C	2019-12-20 22:14:28.053842+00	4296
128	2	-128	body of incipient Jomon pottery of type SIII	\N	4	1	-128	\N	C	2019-12-20 22:14:28.053842+00	4297
127	2	-127	rim of incipient Jomon pottery of type SIII	\N	4	1	-127	\N	C	2019-12-20 22:14:28.053842+00	4298
126	2	-126	body of incipient Jomon pottery of type SIII	\N	4	1	-126	\N	C	2019-12-20 22:14:28.053842+00	4299
125	2	-125	body of incipient Jomon pottery of type SIII	\N	4	1	-125	\N	C	2019-12-20 22:14:28.053842+00	4300
124	2	-124	body of incipient Jomon pottery of type SIII	\N	4	1	-124	\N	C	2019-12-20 22:14:28.053842+00	4301
123	2	-123	rim of incipient Jomon pottery of type SIII	\N	4	1	-123	\N	C	2019-12-20 22:14:28.053842+00	4302
122	2	-122	body of incipient Jomon pottery of type SIII	\N	4	1	-122	\N	C	2019-12-20 22:14:28.053842+00	4303
121	2	-121	body of incipient Jomon pottery of type SIII	\N	4	1	-121	\N	C	2019-12-20 22:14:28.053842+00	4304
120	2	-120	body of incipient Jomon pottery of type SIII	\N	4	1	-120	\N	C	2019-12-20 22:14:28.053842+00	4305
119	2	-119	rim of incipient Jomon pottery of type SIII	\N	4	1	-119	\N	C	2019-12-20 22:14:28.053842+00	4306
118	2	-118	rim of incipient Jomon pottery of type SIII	\N	4	1	-118	\N	C	2019-12-20 22:14:28.053842+00	4307
117	2	-117	rim of initial Jomon pottery of type SIV	\N	4	1	-117	\N	C	2019-12-20 22:14:28.053842+00	4308
116	2	-116	body of initial Jomon pottery of type SIV	\N	4	1	-116	\N	C	2019-12-20 22:14:28.053842+00	4309
115	2	-115	body of initial Jomon pottery of type SIV	\N	4	1	-115	\N	C	2019-12-20 22:14:28.053842+00	4310
114	2	-114	body of initial Jomon pottery of type SIV	\N	4	1	-114	\N	C	2019-12-20 22:14:28.053842+00	4311
113	2	-113	body of initial Jomon pottery of type SIV	\N	4	1	-113	\N	C	2019-12-20 22:14:28.053842+00	4312
112	2	-112	body of initial Jomon pottery of type SIV	\N	4	1	-112	\N	C	2019-12-20 22:14:28.053842+00	4313
111	2	-111	body of initial Jomon pottery of type SIV	\N	4	1	-111	\N	C	2019-12-20 22:14:28.053842+00	4314
110	2	-110	body of initial Jomon pottery of type SIV	\N	4	1	-110	\N	C	2019-12-20 22:14:28.053842+00	4315
109	2	-109	body of initial Jomon pottery of type SIV	\N	4	1	-109	\N	C	2019-12-20 22:14:28.053842+00	4316
108	2	-108	body of initial Jomon pottery of type SIV	\N	4	1	-108	\N	C	2019-12-20 22:14:28.053842+00	4317
107	2	-107	body of initial Jomon pottery of type SIV	\N	4	1	-107	\N	C	2019-12-20 22:14:28.053842+00	4318
106	2	-106	body of initial Jomon pottery of type SIV	\N	4	1	-106	\N	C	2019-12-20 22:14:28.053842+00	4319
105	2	-105	body of initial Jomon pottery of type SIV	\N	4	1	-105	\N	C	2019-12-20 22:14:28.053842+00	4320
104	2	-104	body of initial Jomon pottery of type SIV	\N	4	1	-104	\N	C	2019-12-20 22:14:28.053842+00	4321
103	2	-103	body of initial Jomon pottery of type SIV	\N	4	1	-103	\N	C	2019-12-20 22:14:28.053842+00	4322
102	2	-102	body of initial Jomon pottery of type SIV	\N	4	1	-102	\N	C	2019-12-20 22:14:28.053842+00	4323
101	2	-101	body of initial Jomon pottery of type SIV	\N	4	1	-101	\N	C	2019-12-20 22:14:28.053842+00	4324
100	2	-100	body of initial Jomon pottery of type SIV	\N	4	1	-100	\N	C	2019-12-20 22:14:28.053842+00	4325
99	2	-99	body of initial Jomon pottery of type SIV	\N	4	1	-99	\N	C	2019-12-20 22:14:28.053842+00	4326
98	2	-98	body of initial Jomon pottery of type SIV	\N	4	1	-98	\N	C	2019-12-20 22:14:28.053842+00	4327
97	2	-97	body of initial Jomon pottery of type SIV	\N	4	1	-97	\N	C	2019-12-20 22:14:28.053842+00	4328
96	2	-96	body of initial Jomon pottery of type SIV	\N	4	1	-96	\N	C	2019-12-20 22:14:28.053842+00	4329
95	2	-95	body of initial Jomon pottery of type SIV	\N	4	1	-95	\N	C	2019-12-20 22:14:28.053842+00	4330
94	2	-94	body of initial Jomon pottery of type SIV	\N	4	1	-94	\N	C	2019-12-20 22:14:28.053842+00	4331
93	2	-93	body of initial Jomon pottery of type SIV	\N	4	1	-93	\N	C	2019-12-20 22:14:28.053842+00	4332
92	2	-92	body of initial Jomon pottery of type SIV	\N	4	1	-92	\N	C	2019-12-20 22:14:28.053842+00	4333
91	2	-91	body of initial Jomon pottery of type SIV	\N	4	1	-91	\N	C	2019-12-20 22:14:28.053842+00	4334
90	2	-90	body of initial Jomon pottery of type SIV	\N	4	1	-90	\N	C	2019-12-20 22:14:28.053842+00	4335
89	2	-89	body of initial Jomon pottery of type SIV	\N	4	1	-89	\N	C	2019-12-20 22:14:28.053842+00	4336
88	2	-88	body of initial Jomon pottery of type SIV	\N	4	1	-88	\N	C	2019-12-20 22:14:28.053842+00	4337
87	2	-87	body of initial Jomon pottery of type SIV	\N	4	1	-87	\N	C	2019-12-20 22:14:28.053842+00	4338
86	2	-86	body of initial Jomon pottery of type SIV	\N	4	1	-86	\N	C	2019-12-20 22:14:28.053842+00	4339
85	2	-85	rim of initial Jomon pottery of type SIV	\N	4	1	-85	\N	C	2019-12-20 22:14:28.053842+00	4340
84	2	-84	rim of initial Jomon pottery of type SIV	\N	4	1	-84	\N	C	2019-12-20 22:14:28.053842+00	4341
83	2	-83	rim of initial Jomon pottery of type SIV	\N	4	1	-83	\N	C	2019-12-20 22:14:28.053842+00	4342
82	2	-82	rim of initial Jomon pottery of type SIV	\N	4	1	-82	\N	C	2019-12-20 22:14:28.053842+00	4343
81	2	-81	rim of initial Jomon pottery of type SIV	\N	4	1	-81	\N	C	2019-12-20 22:14:28.053842+00	4344
80	2	-80	body of initial Jomon pottery of type SIV	\N	4	1	-80	\N	C	2019-12-20 22:14:28.053842+00	4345
79	2	-79	rim of initial Jomon pottery of type SIV	\N	4	1	-79	\N	C	2019-12-20 22:14:28.053842+00	4346
78	2	-78	rim of initial Jomon pottery of type SIV	\N	4	1	-78	\N	C	2019-12-20 22:14:28.053842+00	4347
77	2	-77	body of initial Jomon pottery of type SIV	\N	4	1	-77	\N	C	2019-12-20 22:14:28.053842+00	4348
76	2	-76	body of initial Jomon pottery of type SIV	\N	4	1	-76	\N	C	2019-12-20 22:14:28.053842+00	4349
75	2	-75	body of initial Jomon pottery of type SIV	\N	4	1	-75	\N	C	2019-12-20 22:14:28.053842+00	4350
74	2	-74	body of initial Jomon pottery of type SIV	\N	4	1	-74	\N	C	2019-12-20 22:14:28.053842+00	4351
73	2	-73	body of initial Jomon pottery of type SIV	\N	4	1	-73	\N	C	2019-12-20 22:14:28.053842+00	4352
72	2	-72	body of initial Jomon pottery of type SIV	\N	4	1	-72	\N	C	2019-12-20 22:14:28.053842+00	4353
71	2	-71	body of initial Jomon pottery of type SIV	\N	4	1	-71	\N	C	2019-12-20 22:14:28.053842+00	4354
70	2	-70	body of initial Jomon pottery of type SIV	\N	4	1	-70	\N	C	2019-12-20 22:14:28.053842+00	4355
69	2	-69	body of initial Jomon pottery of type SIV	\N	4	1	-69	\N	C	2019-12-20 22:14:28.053842+00	4356
68	2	-68	rim of initial Jomon pottery of type SIV	\N	4	1	-68	\N	C	2019-12-20 22:14:28.053842+00	4357
67	2	-67	rim of initial Jomon pottery of type SIV	\N	4	1	-67	\N	C	2019-12-20 22:14:28.053842+00	4358
66	2	-66	body of initial Jomon pottery of type SIV	\N	4	1	-66	\N	C	2019-12-20 22:14:28.053842+00	4359
65	2	-65	body of initial Jomon pottery of type SIV	\N	4	1	-65	\N	C	2019-12-20 22:14:28.053842+00	4360
64	2	-64	rim of initial Jomon pottery of type SIV	\N	4	1	-64	\N	C	2019-12-20 22:14:28.053842+00	4361
63	2	-63	rim of initial Jomon pottery of type SIV	\N	4	1	-63	\N	C	2019-12-20 22:14:28.053842+00	4362
62	2	-62	rim of initial Jomon pottery of type SIV	\N	4	1	-62	\N	C	2019-12-20 22:14:28.053842+00	4363
61	2	-61	rim of initial Jomon pottery of type SIV	\N	4	1	-61	\N	C	2019-12-20 22:14:28.053842+00	4364
60	2	-60	rim of initial Jomon pottery of type SIV	\N	4	1	-60	\N	C	2019-12-20 22:14:28.053842+00	4365
59	2	-59	rim of initial Jomon pottery of type SIV	\N	4	1	-59	\N	C	2019-12-20 22:14:28.053842+00	4366
58	2	-58	body of initial Jomon pottery of type SIV	\N	4	1	-58	\N	C	2019-12-20 22:14:28.053842+00	4367
57	2	-57	rim of initial Jomon pottery of type SIV	\N	4	1	-57	\N	C	2019-12-20 22:14:28.053842+00	4368
56	2	-56	rim of initial Jomon pottery of type SIV	\N	4	1	-56	\N	C	2019-12-20 22:14:28.053842+00	4369
55	2	-55	body of initial Jomon pottery of type SIV	\N	4	1	-55	\N	C	2019-12-20 22:14:28.053842+00	4370
54	2	-54	rim of initial Jomon pottery of type SIV	\N	4	1	-54	\N	C	2019-12-20 22:14:28.053842+00	4371
53	2	-53	rim of initial Jomon pottery of type SIV	\N	4	1	-53	\N	C	2019-12-20 22:14:28.053842+00	4372
52	2	-52	rim of initial Jomon pottery of type SIV	\N	4	1	-52	\N	C	2019-12-20 22:14:28.053842+00	4373
51	2	-51	rim of initial Jomon pottery of type SIV	\N	4	1	-51	\N	C	2019-12-20 22:14:28.053842+00	4374
50	2	-50	rim of initial Jomon pottery of type SIV	\N	4	1	-50	\N	C	2019-12-20 22:14:28.053842+00	4375
49	2	-49	rim of initial Jomon pottery of type SIV	\N	4	1	-49	\N	C	2019-12-20 22:14:28.053842+00	4376
48	2	-48	rim of initial Jomon pottery of type SIV	\N	4	1	-48	\N	C	2019-12-20 22:14:28.053842+00	4377
24	2	-24	body of incipient Jomon pottery of type SIII	\N	4	1	-24	\N	C	2019-12-20 22:14:28.053842+00	4401
23	2	-23	body of incipient Jomon pottery of type SIII	\N	4	1	-23	\N	C	2019-12-20 22:14:28.053842+00	4402
22	2	-22	body of incipient Jomon pottery of type SIII	\N	4	1	-22	\N	C	2019-12-20 22:14:28.053842+00	4403
21	2	-21	body of incipient Jomon pottery of type SIII	\N	4	1	-21	\N	C	2019-12-20 22:14:28.053842+00	4404
20	2	-20	body of incipient Jomon pottery of type SIII	\N	4	1	-20	\N	C	2019-12-20 22:14:28.053842+00	4405
19	2	-19	body of incipient Jomon pottery of type SIII	\N	4	1	-19	\N	C	2019-12-20 22:14:28.053842+00	4406
18	2	-18	body of incipient Jomon pottery of type SIII	\N	4	1	-18	\N	C	2019-12-20 22:14:28.053842+00	4407
17	2	-17	body of incipient Jomon pottery of type SIII	\N	4	1	-17	\N	C	2019-12-20 22:14:28.053842+00	4408
16	2	-16	body of incipient Jomon pottery of type SIII	\N	4	1	-16	\N	C	2019-12-20 22:14:28.053842+00	4409
15	2	-15	body of incipient Jomon pottery of type SIII	\N	4	1	-15	\N	C	2019-12-20 22:14:28.053842+00	4410
14	2	-14	body of incipient Jomon pottery of type SIII	\N	4	1	-14	\N	C	2019-12-20 22:14:28.053842+00	4411
13	2	-13	body of incipient Jomon pottery of type SIII	\N	4	1	-13	\N	C	2019-12-20 22:14:28.053842+00	4412
12	2	-12	body of incipient Jomon pottery of type SIII	\N	4	1	-12	\N	C	2019-12-20 22:14:28.053842+00	4413
11	2	-11	body of incipient Jomon pottery of type SIII	\N	4	1	-11	\N	C	2019-12-20 22:14:28.053842+00	4414
10	2	-10	body of incipient Jomon pottery of type SIII	\N	4	1	-10	\N	C	2019-12-20 22:14:28.053842+00	4415
9	2	-9	body of incipient Jomon pottery of type SIII	\N	4	1	-9	\N	C	2019-12-20 22:14:28.053842+00	4416
8	2	-8	body of incipient Jomon pottery of type SIII	\N	4	1	-8	\N	C	2019-12-20 22:14:28.053842+00	4417
7	2	-7	body of incipient Jomon pottery of type SIII	\N	4	1	-7	\N	C	2019-12-20 22:14:28.053842+00	4418
6	2	-6	body of incipient Jomon pottery of type SIII	\N	4	1	-6	\N	C	2019-12-20 22:14:28.053842+00	4419
5	2	-5	body of incipient Jomon pottery of type SIII	\N	4	1	-5	\N	C	2019-12-20 22:14:28.053842+00	4420
4	2	-4	unknown part of incipient Jomon pottery of type SIII	\N	4	1	-4	\N	C	2019-12-20 22:14:28.053842+00	4421
3	2	-3	body of incipient Jomon pottery of type SIII	\N	4	1	-3	\N	C	2019-12-20 22:14:28.053842+00	4422
2	2	-2	body of incipient Jomon pottery of type SIII	\N	4	1	-2	\N	C	2019-12-20 22:14:28.053842+00	4423
1	2	-1	body of incipient Jomon pottery of type SIII	\N	4	1	-1	\N	C	2019-12-20 22:14:28.053842+00	4424
