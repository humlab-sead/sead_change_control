1	logger	folder	/tmp/	string
2		max_execution_time	120	numeric
3	mailer	smtp-server	mail.acc.umu.se	string
4	mailer	reply-address	noreply@sead.se	string
5	mailer	sender-name	SEAD Clearing House	string
6	mailer	smtp-auth	false	bool
7	mailer	smtp-username		string
8	mailer	smtp-password		string
9	signal-templates	reject-subject	SEAD Clearing House: submission has been rejected	string
10	signal-templates	reject-body	\nYour submission to SEAD Clearing House has been rejected!\n\nReject causes:\n\n#REJECT-CAUSES#\n\nThis is an auto-generated mail from the SEAD Clearing House system\n\n	string
11	signal-templates	reject-cause	\n\nEntity type: #ENTITY-TYPE#\nError scope: #ERROR-SCOPE#\nEntities: #ENTITY-ID-LIST#\nNote:  #ERROR-DESCRIPTION#\n\n--------------------------------------------------------------------\n\n	string
12	signal-templates	accept-subject	SEAD Clearing House: submission has been accepted	string
13	signal-templates	accept-body	\n\nYour submission to SEAD Clearing House has been accepted!\n\nThis is an auto-generated mail from the SEAD Clearing House system\n\n	string
14	signal-templates	reclaim-subject	SEAD Clearing House notfication: Submission #SUBMISSION-ID# has been transfered to pending	string
15	signal-templates	reclaim-body	\n\nStatus of submission #SUBMISSION-ID# has been reset to pending due to inactivity.\n\nA submission is automatically reset to pending status when #DAYS-UNTIL-RECLAIM# days have passed since the submission\nwas claimed for review, and if no activity during has been registered during last #DAYS-WITHOUT-ACTIVITY# days.\n\nThis is an auto-generated mail from the SEAD Clearing House system.\n\n	string
16	signal-templates	reminder-subject	SEAD Clearing House reminder: Submission #SUBMISSION-ID#	string
17	signal-templates	reminder-body	\n\nStatus of submission #SUBMISSION-ID# has been reset to pending due to inactivity.\n\nA reminder is automatically send when #DAYS-UNTIL-REMINDER# have passed since the submission\nwas claimed for review.\n\nThis is an auto-generated mail from the SEAD Clearing House system.\n\n	string
18	reminder	days_until_first_reminder	14	numeric
19	reminder	days_since_claimed_until_transfer_back_to_pending	28	numeric
20	reminder	days_without_activity_until_transfer_back_to_pending	14	numeric
