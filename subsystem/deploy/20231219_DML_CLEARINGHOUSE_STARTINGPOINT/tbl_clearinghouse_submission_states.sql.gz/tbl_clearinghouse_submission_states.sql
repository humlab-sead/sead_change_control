0	Undefined
1	New
2	Pending
3	In progress
4	Accepted
5	Rejected
9	Error
