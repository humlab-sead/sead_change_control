2	45	2025-03-07 15:03:14.516018+00	Tree height (m)	Height of tree given in metres.	Tree height in metres	1	14	1	-45	\N	C	2025-03-07 15:03:14.788225+00	45
