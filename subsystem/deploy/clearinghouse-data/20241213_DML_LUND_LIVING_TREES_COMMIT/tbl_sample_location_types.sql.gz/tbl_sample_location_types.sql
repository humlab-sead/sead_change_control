2	80	Sampling height	Height (centimetres (cm)) at which a sample was collected, measured from the ground.	2025-03-07 15:03:14.516018+00	1	-80	\N	C	2025-03-07 15:03:14.788225+00	80
