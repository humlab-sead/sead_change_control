2	4	Ceramics	4	2019-12-20	Pending	\N	\N	5efc44da-b8ba-4aaf-8c8f-daff2bdec21e	20200109_DML_SUBMISSION_CERAMICS_005_COMMIT	ceramics_data_latest_20200107
