2	1	-2	\N	SciLifelab Ancient DNA	\N	https://www.scilifelab.se/units/ancient-dna/	2025-04-17 07:58:00.174553+00	1	-1	\N	C	2025-04-17 07:58:00.757214+00	12
