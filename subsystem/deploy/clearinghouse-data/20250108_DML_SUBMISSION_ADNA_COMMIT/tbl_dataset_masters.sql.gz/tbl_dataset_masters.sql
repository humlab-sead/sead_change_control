2	1	-2	\N	SciLifelab Ancient DNA	\N	https://www.scilifelab.se/units/ancient-dna/	2025-04-11 21:05:15.317791+00	1	-1	\N	C	2025-04-11 21:05:15.919463+00	12
