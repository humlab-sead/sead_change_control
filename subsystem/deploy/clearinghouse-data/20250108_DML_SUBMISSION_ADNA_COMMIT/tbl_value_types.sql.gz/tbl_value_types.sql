2	3	\N	19	Molecular sex	category	\N	Molecular sex	24b6da23-8e15-4e52-a57e-86c3fc3cc2e8	1	-3	\N	C	2025-04-17 07:58:00.757214+00	17
2	5	\N	19	Damage treatment	category	\N	Type of damage treatment	c1c55b76-2abd-4f11-a9db-e29e0363ebd8	1	-5	\N	C	2025-04-17 07:58:00.757214+00	16
2	6	\N	19	SNP capture	category	\N	Type of SNP capture.	8731168a-031f-4911-8f74-d3df5917a1de	1	-6	\N	C	2025-04-17 07:58:00.757214+00	15
2	8	\N	19	Library preparation	category	\N	Type of sequence library preparation	aa7a0cde-df55-4fbe-aead-49140838857d	1	-8	\N	C	2025-04-17 07:58:00.757214+00	14
