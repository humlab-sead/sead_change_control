2	3	\N	19	Molecular sex	category	\N	Molecular sex	c6bd17f2-9110-4210-90d7-252e3213cdcd	1	-3	\N	C	2025-04-11 21:05:15.919463+00	17
2	5	\N	19	Damage treatment	category	\N	Type of damage treatment	a8a199f5-ef43-41c7-89ed-98b453ef2ea6	1	-5	\N	C	2025-04-11 21:05:15.919463+00	16
2	6	\N	19	SNP capture	category	\N	Type of SNP capture.	e2453ede-3e0d-4446-a303-2b2484fbfe60	1	-6	\N	C	2025-04-11 21:05:15.919463+00	15
2	8	\N	19	Library preparation	category	\N	Type of sequence library preparation	2b180465-78ce-42f2-b134-616ea01bee55	1	-8	\N	C	2025-04-11 21:05:15.919463+00	14
