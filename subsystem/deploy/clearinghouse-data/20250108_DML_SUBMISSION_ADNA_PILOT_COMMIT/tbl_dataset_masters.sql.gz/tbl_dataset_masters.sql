2	1	-2	\N	SciLifelab Ancient DNA	\N	https://www.scilifelab.se/units/ancient-dna/	2025-04-22 09:07:27.817552+00	1	-1	\N	C	2025-04-22 09:07:28.389013+00	12
