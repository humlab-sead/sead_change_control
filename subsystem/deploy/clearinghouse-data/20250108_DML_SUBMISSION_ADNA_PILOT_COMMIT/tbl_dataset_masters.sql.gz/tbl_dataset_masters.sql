2	1	-2	\N	SciLifelab Ancient DNA	\N	https://www.scilifelab.se/units/ancient-dna/	2025-04-20 12:11:21.366528+00	1	-1	\N	C	2025-04-20 12:11:21.944261+00	12
