2	1	-2	\N	SciLifelab Ancient DNA	\N	https://www.scilifelab.se/units/ancient-dna/	2025-04-21 08:07:02.092688+00	1	-1	\N	C	2025-04-21 08:07:02.686011+00	12
