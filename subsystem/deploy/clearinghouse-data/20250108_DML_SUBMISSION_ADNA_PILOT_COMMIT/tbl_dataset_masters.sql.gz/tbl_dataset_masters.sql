2	1	-2	\N	SciLifelab Ancient DNA	\N	https://www.scilifelab.se/units/ancient-dna/	2025-04-17 14:49:39.719876+00	1	-1	\N	C	2025-04-17 14:49:40.307993+00	12
