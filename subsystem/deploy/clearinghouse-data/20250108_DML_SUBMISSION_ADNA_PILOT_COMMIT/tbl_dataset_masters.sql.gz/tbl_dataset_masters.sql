3	1	-2	\N	SciLifelab Ancient DNA	\N	https://www.scilifelab.se/units/ancient-dna/	2025-04-24 08:34:07.182333+00	1	-1	\N	C	2025-04-24 08:34:07.752181+00	12
