2	1	DNA	Any type of DNA analysis (e.g. ancient humans or sedimentary)	2025-04-22 09:07:27.817552+00	1	-1	\N	C	2025-04-22 09:07:28.389013+00	22
