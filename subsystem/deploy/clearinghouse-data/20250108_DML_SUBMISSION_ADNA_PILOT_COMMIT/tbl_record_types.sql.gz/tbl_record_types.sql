2	1	DNA	Any type of DNA analysis (e.g. ancient humans or sedimentary)	2025-04-17 14:49:39.719876+00	1	-1	\N	C	2025-04-17 14:49:40.307993+00	22
