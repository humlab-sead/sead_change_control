2	1	DNA	Any type of DNA analysis (e.g. ancient humans or sedimentary)	2025-04-22 08:40:46.448965+00	1	-1	\N	C	2025-04-22 08:40:46.99621+00	22
