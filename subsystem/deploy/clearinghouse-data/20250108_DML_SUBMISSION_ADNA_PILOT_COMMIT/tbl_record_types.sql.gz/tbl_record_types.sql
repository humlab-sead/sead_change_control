3	1	DNA	Any type of DNA analysis (e.g. ancient humans or sedimentary)	2025-04-24 08:34:07.182333+00	1	-1	\N	C	2025-04-24 08:34:07.752181+00	22
