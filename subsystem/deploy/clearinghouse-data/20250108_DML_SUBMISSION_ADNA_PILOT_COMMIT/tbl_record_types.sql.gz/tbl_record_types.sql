2	1	DNA	Any type of DNA analysis (e.g. ancient humans or sedimentary)	2025-04-21 08:07:02.092688+00	1	-1	\N	C	2025-04-21 08:07:02.686011+00	22
