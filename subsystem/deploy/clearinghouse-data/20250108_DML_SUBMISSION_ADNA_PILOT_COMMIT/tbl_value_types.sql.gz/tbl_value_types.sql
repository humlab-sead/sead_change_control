2	3	\N	19	Molecular sex	category	\N	Molecular sex	ff211b68-ee29-4bee-a30e-dc6dea185c30	1	-3	\N	C	2025-04-22 09:07:28.389013+00	17
2	5	\N	19	Damage treatment	category	\N	Type of damage treatment	8a9a51c0-879a-41f2-8422-572f3560bccc	1	-5	\N	C	2025-04-22 09:07:28.389013+00	16
2	6	\N	19	SNP capture	category	\N	Type of SNP capture.	9f656446-e5be-4166-a2d8-562c4dcf6fee	1	-6	\N	C	2025-04-22 09:07:28.389013+00	15
2	8	\N	19	Library preparation	category	\N	Type of sequence library preparation	4885cbed-c3e7-40e4-8445-e23489716e26	1	-8	\N	C	2025-04-22 09:07:28.389013+00	14
