3	3	\N	19	Molecular sex	category	\N	Molecular sex	0dc5e2db-99e4-4083-9911-341f1e1bbf79	1	-3	\N	C	2025-04-24 08:34:07.752181+00	17
3	5	\N	19	Damage treatment	category	\N	Type of damage treatment	ebba34d2-88a1-45a0-af57-aa204fe9a7fa	1	-5	\N	C	2025-04-24 08:34:07.752181+00	16
3	6	\N	19	SNP capture	category	\N	Type of SNP capture.	cc501c20-f9b8-439e-ba8c-4ff5d53ea237	1	-6	\N	C	2025-04-24 08:34:07.752181+00	15
3	8	\N	19	Library preparation	category	\N	Type of sequence library preparation	c19ad080-2f8e-429c-8958-15a124068f33	1	-8	\N	C	2025-04-24 08:34:07.752181+00	14
