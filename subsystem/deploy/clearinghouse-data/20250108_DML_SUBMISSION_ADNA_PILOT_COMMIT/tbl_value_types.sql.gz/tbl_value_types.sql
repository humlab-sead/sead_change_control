2	3	\N	19	Molecular sex	category	\N	Molecular sex	b036e1ed-0091-4595-a894-5f52b8a4530f	1	-3	\N	C	2025-04-17 14:49:40.307993+00	17
2	5	\N	19	Damage treatment	category	\N	Type of damage treatment	9735d05b-19ca-4e09-a013-783cb59c8599	1	-5	\N	C	2025-04-17 14:49:40.307993+00	16
2	6	\N	19	SNP capture	category	\N	Type of SNP capture.	e7c9adaf-f326-453b-9efe-02a9cd393156	1	-6	\N	C	2025-04-17 14:49:40.307993+00	15
2	8	\N	19	Library preparation	category	\N	Type of sequence library preparation	bf2b7539-693d-4a03-9042-15f50bdcefea	1	-8	\N	C	2025-04-17 14:49:40.307993+00	14
