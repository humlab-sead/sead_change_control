2	3	\N	19	Molecular sex	category	\N	Molecular sex	7aa96996-e846-4ed3-816d-6ec22bdb5178	1	-3	\N	C	2025-04-21 08:07:02.686011+00	17
2	5	\N	19	Damage treatment	category	\N	Type of damage treatment	9409bff1-c8e7-42c4-ba1f-386c92291f6e	1	-5	\N	C	2025-04-21 08:07:02.686011+00	16
2	6	\N	19	SNP capture	category	\N	Type of SNP capture.	d2cded70-847f-4fa1-8398-101c303bc65a	1	-6	\N	C	2025-04-21 08:07:02.686011+00	15
2	8	\N	19	Library preparation	category	\N	Type of sequence library preparation	86070e6c-3446-4456-87fc-91a1aa1cdd57	1	-8	\N	C	2025-04-21 08:07:02.686011+00	14
