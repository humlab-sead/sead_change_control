2	3	\N	19	Molecular sex	category	\N	Molecular sex	53002db4-7cab-400b-8f79-910edc343ade	1	-3	\N	C	2025-04-22 08:40:46.99621+00	17
2	5	\N	19	Damage treatment	category	\N	Type of damage treatment	7c60ed02-8924-4ef4-a368-c0593437ca0c	1	-5	\N	C	2025-04-22 08:40:46.99621+00	16
2	6	\N	19	SNP capture	category	\N	Type of SNP capture.	2cdca215-1904-49c7-af2a-4e01bd2303af	1	-6	\N	C	2025-04-22 08:40:46.99621+00	15
2	8	\N	19	Library preparation	category	\N	Type of sequence library preparation	f92766c6-d0b1-4e1c-9414-202a6e12f274	1	-8	\N	C	2025-04-22 08:40:46.99621+00	14
