2	3	\N	19	Molecular sex	category	\N	Molecular sex	41e620e2-e252-4aac-bea6-3c03ddaa89eb	1	-3	\N	C	2025-04-20 12:11:21.944261+00	17
2	5	\N	19	Damage treatment	category	\N	Type of damage treatment	5c7596c0-4eb0-43f5-9bd2-d6b707774c1f	1	-5	\N	C	2025-04-20 12:11:21.944261+00	16
2	6	\N	19	SNP capture	category	\N	Type of SNP capture.	1c004db4-79e8-4f20-82cd-4dce7bfc4348	1	-6	\N	C	2025-04-20 12:11:21.944261+00	15
2	8	\N	19	Library preparation	category	\N	Type of sequence library preparation	f2d01335-57f1-4329-99c4-8df5ab22f760	1	-8	\N	C	2025-04-20 12:11:21.944261+00	14
