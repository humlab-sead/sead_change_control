1	1	6295	\N	destructive metod used to measure the relative abundance of stable isotopes in a sample	IRMS	-1	Isotope-ratio mass spectrometry	\N	\N	1	-1	\N	C	2019-12-20 22:14:28.053842+00	175
1	2	6296	\N	The use of acid to extract sample material for isotope analysis.	AE	-2	Acid Extraction	\N	\N	1	-2	\N	C	2019-12-20 22:14:28.053842+00	174
