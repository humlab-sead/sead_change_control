1	546	27	feature	Open-air; Close to the coast	\N	1	-546	\N	C	2019-12-20 22:14:28.053842+00	3347
1	545	27	feature	Open-air; Close to the coast	\N	1	-545	\N	C	2019-12-20 22:14:28.053842+00	3348
1	544	27	feature	Open-air; Close to the coast	\N	1	-544	\N	C	2019-12-20 22:14:28.053842+00	3349
1	543	27	feature	Open-air; Close to the coast	\N	1	-543	\N	C	2019-12-20 22:14:28.053842+00	3350
1	542	27	feature	Open-air; Close to the coast	\N	1	-542	\N	C	2019-12-20 22:14:28.053842+00	3351
1	541	27	feature	Open-air; Close to the coast	\N	1	-541	\N	C	2019-12-20 22:14:28.053842+00	3352
1	540	27	feature	Open-air; Close to the coast	\N	1	-540	\N	C	2019-12-20 22:14:28.053842+00	3353
1	539	27	feature	Open-air; Close to the coast	\N	1	-539	\N	C	2019-12-20 22:14:28.053842+00	3354
1	538	27	feature	Open-air; Close to the coast	\N	1	-538	\N	C	2019-12-20 22:14:28.053842+00	3355
1	537	27	feature	Open-air; Close to the coast	\N	1	-537	\N	C	2019-12-20 22:14:28.053842+00	3356
1	536	27	feature	Open-air; Close to the coast	\N	1	-536	\N	C	2019-12-20 22:14:28.053842+00	3357
1	535	27	feature	Open-air; Close to the coast	\N	1	-535	\N	C	2019-12-20 22:14:28.053842+00	3358
1	534	27	feature	Open-air; Close to the coast	\N	1	-534	\N	C	2019-12-20 22:14:28.053842+00	3359
1	533	27	feature	Open-air; Close to the coast	\N	1	-533	\N	C	2019-12-20 22:14:28.053842+00	3360
1	532	27	feature	Open-air; Close to the coast	\N	1	-532	\N	C	2019-12-20 22:14:28.053842+00	3361
1	531	27	feature	Open-air; Close to the coast	\N	1	-531	\N	C	2019-12-20 22:14:28.053842+00	3362
1	530	27	feature	Open-air; Close to the coast	\N	1	-530	\N	C	2019-12-20 22:14:28.053842+00	3363
1	529	27	feature	Open-air; Close to the coast	\N	1	-529	\N	C	2019-12-20 22:14:28.053842+00	3364
1	528	27	feature	Open-air; Close to the coast	\N	1	-528	\N	C	2019-12-20 22:14:28.053842+00	3365
1	527	27	feature	Open-air; Close to the coast	\N	1	-527	\N	C	2019-12-20 22:14:28.053842+00	3366
1	526	27	feature	Open-air; Close to the coast	\N	1	-526	\N	C	2019-12-20 22:14:28.053842+00	3367
1	525	27	feature	Open-air; Close to the coast	\N	1	-525	\N	C	2019-12-20 22:14:28.053842+00	3368
1	944	27	feature	Open-air; Inland	\N	1	-944	\N	C	2019-12-20 22:14:28.053842+00	2949
1	943	27	feature	Open-air; Inland	\N	1	-943	\N	C	2019-12-20 22:14:28.053842+00	2950
1	942	27	feature	Open-air; Inland	\N	1	-942	\N	C	2019-12-20 22:14:28.053842+00	2951
1	941	27	feature	Open-air; Inland	\N	1	-941	\N	C	2019-12-20 22:14:28.053842+00	2952
1	940	27	feature	Open-air; Inland	\N	1	-940	\N	C	2019-12-20 22:14:28.053842+00	2953
1	939	27	feature	Open-air; Inland	\N	1	-939	\N	C	2019-12-20 22:14:28.053842+00	2954
1	938	27	feature	Open-air; Inland	\N	1	-938	\N	C	2019-12-20 22:14:28.053842+00	2955
1	937	27	feature	Open-air; Inland	\N	1	-937	\N	C	2019-12-20 22:14:28.053842+00	2956
1	936	27	feature	Open-air; Inland	\N	1	-936	\N	C	2019-12-20 22:14:28.053842+00	2957
1	935	27	feature	Open-air; Inland	\N	1	-935	\N	C	2019-12-20 22:14:28.053842+00	2958
1	934	27	feature	Open-air; Lake shore	\N	1	-934	\N	C	2019-12-20 22:14:28.053842+00	2959
1	933	27	feature	Open-air; Lake shore	\N	1	-933	\N	C	2019-12-20 22:14:28.053842+00	2960
1	932	27	feature	Open-air; Lake shore	\N	1	-932	\N	C	2019-12-20 22:14:28.053842+00	2961
1	931	27	feature	Open-air; Lake shore	\N	1	-931	\N	C	2019-12-20 22:14:28.053842+00	2962
1	930	27	feature	Open-air; Lake shore	\N	1	-930	\N	C	2019-12-20 22:14:28.053842+00	2963
1	929	27	feature	Open-air; Lake shore	\N	1	-929	\N	C	2019-12-20 22:14:28.053842+00	2964
1	928	27	feature	Open-air; Lake shore	\N	1	-928	\N	C	2019-12-20 22:14:28.053842+00	2965
1	927	27	feature	Open-air; Lake shore	\N	1	-927	\N	C	2019-12-20 22:14:28.053842+00	2966
1	926	27	feature	Open-air; Lake shore	\N	1	-926	\N	C	2019-12-20 22:14:28.053842+00	2967
1	925	27	feature	Open-air; Lake shore	\N	1	-925	\N	C	2019-12-20 22:14:28.053842+00	2968
1	924	27	feature	Open-air; Lake shore	\N	1	-924	\N	C	2019-12-20 22:14:28.053842+00	2969
1	923	27	feature	Open-air; Lake shore	\N	1	-923	\N	C	2019-12-20 22:14:28.053842+00	2970
1	922	27	feature	Open-air; Lake shore	\N	1	-922	\N	C	2019-12-20 22:14:28.053842+00	2971
1	921	27	feature	Open-air; Inland	\N	1	-921	\N	C	2019-12-20 22:14:28.053842+00	2972
1	920	27	feature	Open-air; Inland	\N	1	-920	\N	C	2019-12-20 22:14:28.053842+00	2973
1	919	27	feature	Open-air; Inland	\N	1	-919	\N	C	2019-12-20 22:14:28.053842+00	2974
1	918	27	feature	Open-air; Inland	\N	1	-918	\N	C	2019-12-20 22:14:28.053842+00	2975
1	917	27	feature	Open-air; Inland	\N	1	-917	\N	C	2019-12-20 22:14:28.053842+00	2976
1	916	27	feature	Open-air; Inland	\N	1	-916	\N	C	2019-12-20 22:14:28.053842+00	2977
1	915	27	feature	Open-air; Inland	\N	1	-915	\N	C	2019-12-20 22:14:28.053842+00	2978
1	914	27	feature	Open-air; Inland	\N	1	-914	\N	C	2019-12-20 22:14:28.053842+00	2979
1	913	27	feature	Open-air; Inland	\N	1	-913	\N	C	2019-12-20 22:14:28.053842+00	2980
1	912	27	feature	Open-air; Inland	\N	1	-912	\N	C	2019-12-20 22:14:28.053842+00	2981
1	911	27	feature	Open-air; Inland	\N	1	-911	\N	C	2019-12-20 22:14:28.053842+00	2982
1	910	27	feature	Open-air; Inland	\N	1	-910	\N	C	2019-12-20 22:14:28.053842+00	2983
1	909	27	feature	Open-air; Inland	\N	1	-909	\N	C	2019-12-20 22:14:28.053842+00	2984
1	908	27	feature	Open-air; Inland	\N	1	-908	\N	C	2019-12-20 22:14:28.053842+00	2985
1	907	27	feature	Open-air; Inland	\N	1	-907	\N	C	2019-12-20 22:14:28.053842+00	2986
1	906	27	feature	Open-air; Inland	\N	1	-906	\N	C	2019-12-20 22:14:28.053842+00	2987
1	905	27	feature	Open-air; Inland	\N	1	-905	\N	C	2019-12-20 22:14:28.053842+00	2988
1	904	27	feature	Open-air; Inland	\N	1	-904	\N	C	2019-12-20 22:14:28.053842+00	2989
1	903	27	feature	Open-air; Inland	\N	1	-903	\N	C	2019-12-20 22:14:28.053842+00	2990
1	902	27	feature	Open-air; Inland	\N	1	-902	\N	C	2019-12-20 22:14:28.053842+00	2991
1	901	27	feature	Open-air; Inland	\N	1	-901	\N	C	2019-12-20 22:14:28.053842+00	2992
1	900	27	feature	Open-air; Inland	\N	1	-900	\N	C	2019-12-20 22:14:28.053842+00	2993
1	899	27	feature	Open-air; Inland	\N	1	-899	\N	C	2019-12-20 22:14:28.053842+00	2994
1	898	27	feature	Open-air; Inland	\N	1	-898	\N	C	2019-12-20 22:14:28.053842+00	2995
1	897	27	feature	Open-air; Inland	\N	1	-897	\N	C	2019-12-20 22:14:28.053842+00	2996
1	896	27	feature	Open-air; Inland	\N	1	-896	\N	C	2019-12-20 22:14:28.053842+00	2997
1	895	27	feature	Open-air; Inland	\N	1	-895	\N	C	2019-12-20 22:14:28.053842+00	2998
1	894	27	feature	Open-air; Inland	\N	1	-894	\N	C	2019-12-20 22:14:28.053842+00	2999
1	893	27	feature	Open-air; Inland	\N	1	-893	\N	C	2019-12-20 22:14:28.053842+00	3000
1	892	27	feature	Open-air; Inland	\N	1	-892	\N	C	2019-12-20 22:14:28.053842+00	3001
1	891	27	feature	Open-air; Inland	\N	1	-891	\N	C	2019-12-20 22:14:28.053842+00	3002
1	890	27	feature	Open-air; Inland	\N	1	-890	\N	C	2019-12-20 22:14:28.053842+00	3003
1	889	27	feature	Open-air; Close to the coast	\N	1	-889	\N	C	2019-12-20 22:14:28.053842+00	3004
1	888	27	feature	Open-air; Close to the coast	\N	1	-888	\N	C	2019-12-20 22:14:28.053842+00	3005
1	887	27	feature	Open-air; Close to the coast	\N	1	-887	\N	C	2019-12-20 22:14:28.053842+00	3006
1	886	27	feature	Open-air; Close to the coast	\N	1	-886	\N	C	2019-12-20 22:14:28.053842+00	3007
1	885	27	feature	Open-air; Close to the coast	\N	1	-885	\N	C	2019-12-20 22:14:28.053842+00	3008
1	884	27	feature	Open-air; Close to the coast	\N	1	-884	\N	C	2019-12-20 22:14:28.053842+00	3009
1	883	27	feature	Open-air; Close to the coast	\N	1	-883	\N	C	2019-12-20 22:14:28.053842+00	3010
1	882	27	feature	Open-air; Close to the coast	\N	1	-882	\N	C	2019-12-20 22:14:28.053842+00	3011
1	881	27	feature	Open-air; Close to the coast	\N	1	-881	\N	C	2019-12-20 22:14:28.053842+00	3012
1	880	27	feature	Open-air; Close to the coast	\N	1	-880	\N	C	2019-12-20 22:14:28.053842+00	3013
1	879	27	feature	Open-air; Close to the coast	\N	1	-879	\N	C	2019-12-20 22:14:28.053842+00	3014
1	878	27	feature	Open-air; Close to the coast	\N	1	-878	\N	C	2019-12-20 22:14:28.053842+00	3015
1	877	27	feature	Open-air; Close to the coast	\N	1	-877	\N	C	2019-12-20 22:14:28.053842+00	3016
1	876	27	feature	Open-air; Close to the coast	\N	1	-876	\N	C	2019-12-20 22:14:28.053842+00	3017
1	875	27	feature	Open-air; Close to the coast	\N	1	-875	\N	C	2019-12-20 22:14:28.053842+00	3018
1	874	27	feature	Open-air; Close to the coast	\N	1	-874	\N	C	2019-12-20 22:14:28.053842+00	3019
1	873	27	feature	Open-air; Close to the coast	\N	1	-873	\N	C	2019-12-20 22:14:28.053842+00	3020
1	872	27	feature	Open-air; Close to the coast	\N	1	-872	\N	C	2019-12-20 22:14:28.053842+00	3021
1	871	27	feature	Open-air; Close to the coast	\N	1	-871	\N	C	2019-12-20 22:14:28.053842+00	3022
1	870	27	feature	Open-air; Close to the coast	\N	1	-870	\N	C	2019-12-20 22:14:28.053842+00	3023
1	869	27	feature	Open-air; Close to the coast	\N	1	-869	\N	C	2019-12-20 22:14:28.053842+00	3024
1	868	27	feature	Open-air; Close to the coast	\N	1	-868	\N	C	2019-12-20 22:14:28.053842+00	3025
1	867	27	feature	Open-air; Inland	\N	1	-867	\N	C	2019-12-20 22:14:28.053842+00	3026
1	866	27	feature	Open-air; Inland	\N	1	-866	\N	C	2019-12-20 22:14:28.053842+00	3027
1	865	27	feature	Open-air; Inland	\N	1	-865	\N	C	2019-12-20 22:14:28.053842+00	3028
1	864	27	feature	Open-air; Inland	\N	1	-864	\N	C	2019-12-20 22:14:28.053842+00	3029
1	863	27	feature	Open-air; Inland	\N	1	-863	\N	C	2019-12-20 22:14:28.053842+00	3030
1	862	27	feature	Open-air; Close to the coast	\N	1	-862	\N	C	2019-12-20 22:14:28.053842+00	3031
1	861	12	feature	Shell midden; Lake shore	\N	1	-861	\N	C	2019-12-20 22:14:28.053842+00	3032
1	860	12	feature	Shell midden; Lake shore	\N	1	-860	\N	C	2019-12-20 22:14:28.053842+00	3033
1	859	12	feature	Shell midden; Lake shore	\N	1	-859	\N	C	2019-12-20 22:14:28.053842+00	3034
1	858	12	feature	Shell midden; Lake shore	\N	1	-858	\N	C	2019-12-20 22:14:28.053842+00	3035
1	857	12	feature	Shell midden; Lake shore	\N	1	-857	\N	C	2019-12-20 22:14:28.053842+00	3036
1	856	12	feature	Shell midden; Lake shore	\N	1	-856	\N	C	2019-12-20 22:14:28.053842+00	3037
1	855	12	feature	Shell midden; Lake shore	\N	1	-855	\N	C	2019-12-20 22:14:28.053842+00	3038
1	854	12	feature	Shell midden; Lake shore	\N	1	-854	\N	C	2019-12-20 22:14:28.053842+00	3039
1	853	12	feature	Shell midden; Lake shore	\N	1	-853	\N	C	2019-12-20 22:14:28.053842+00	3040
1	852	12	feature	Shell midden; Lake shore	\N	1	-852	\N	C	2019-12-20 22:14:28.053842+00	3041
1	851	12	feature	Shell midden; Lake shore	\N	1	-851	\N	C	2019-12-20 22:14:28.053842+00	3042
1	850	12	feature	Shell midden; Lake shore	\N	1	-850	\N	C	2019-12-20 22:14:28.053842+00	3043
1	849	12	feature	Shell midden; Lake shore	\N	1	-849	\N	C	2019-12-20 22:14:28.053842+00	3044
1	848	12	feature	Shell midden; Lake shore	\N	1	-848	\N	C	2019-12-20 22:14:28.053842+00	3045
1	847	12	feature	Shell midden; Lake shore	\N	1	-847	\N	C	2019-12-20 22:14:28.053842+00	3046
1	846	12	feature	Shell midden; Lake shore	\N	1	-846	\N	C	2019-12-20 22:14:28.053842+00	3047
1	845	12	feature	Shell midden; Lake shore	\N	1	-845	\N	C	2019-12-20 22:14:28.053842+00	3048
1	844	12	feature	Shell midden; Lake shore	\N	1	-844	\N	C	2019-12-20 22:14:28.053842+00	3049
1	843	12	feature	Shell midden; Lake shore	\N	1	-843	\N	C	2019-12-20 22:14:28.053842+00	3050
1	842	12	feature	Shell midden; Lake shore	\N	1	-842	\N	C	2019-12-20 22:14:28.053842+00	3051
1	841	12	feature	Shell midden; Lake shore	\N	1	-841	\N	C	2019-12-20 22:14:28.053842+00	3052
1	840	12	feature	Shell midden; Lake shore	\N	1	-840	\N	C	2019-12-20 22:14:28.053842+00	3053
1	839	12	feature	Shell midden; Lake shore	\N	1	-839	\N	C	2019-12-20 22:14:28.053842+00	3054
1	838	12	feature	Shell midden; Lake shore	\N	1	-838	\N	C	2019-12-20 22:14:28.053842+00	3055
1	837	12	feature	Shell midden; Lake shore	\N	1	-837	\N	C	2019-12-20 22:14:28.053842+00	3056
1	836	12	feature	Shell midden; Lake shore	\N	1	-836	\N	C	2019-12-20 22:14:28.053842+00	3057
1	835	12	feature	Shell midden; Lake shore	\N	1	-835	\N	C	2019-12-20 22:14:28.053842+00	3058
1	834	12	feature	Shell midden; Lake shore	\N	1	-834	\N	C	2019-12-20 22:14:28.053842+00	3059
1	833	12	feature	Shell midden; Lake shore	\N	1	-833	\N	C	2019-12-20 22:14:28.053842+00	3060
1	832	12	feature	Shell midden; Lake shore	\N	1	-832	\N	C	2019-12-20 22:14:28.053842+00	3061
1	831	12	feature	Shell midden; Lake shore	\N	1	-831	\N	C	2019-12-20 22:14:28.053842+00	3062
1	830	12	feature	Shell midden; Lake shore	\N	1	-830	\N	C	2019-12-20 22:14:28.053842+00	3063
1	829	12	feature	Shell midden; Lake shore	\N	1	-829	\N	C	2019-12-20 22:14:28.053842+00	3064
1	828	12	feature	Shell midden; Lake shore	\N	1	-828	\N	C	2019-12-20 22:14:28.053842+00	3065
1	827	12	feature	Shell midden; Lake shore	\N	1	-827	\N	C	2019-12-20 22:14:28.053842+00	3066
1	826	12	feature	Shell midden; Lake shore	\N	1	-826	\N	C	2019-12-20 22:14:28.053842+00	3067
1	825	12	feature	Shell midden; Lake shore	\N	1	-825	\N	C	2019-12-20 22:14:28.053842+00	3068
1	824	12	feature	Shell midden; Lake shore	\N	1	-824	\N	C	2019-12-20 22:14:28.053842+00	3069
1	823	12	feature	Shell midden; Lake shore	\N	1	-823	\N	C	2019-12-20 22:14:28.053842+00	3070
1	822	12	feature	Shell midden; Lake shore	\N	1	-822	\N	C	2019-12-20 22:14:28.053842+00	3071
1	821	12	feature	Shell midden; Lake shore	\N	1	-821	\N	C	2019-12-20 22:14:28.053842+00	3072
1	820	12	feature	Shell midden; Lake shore	\N	1	-820	\N	C	2019-12-20 22:14:28.053842+00	3073
1	819	12	feature	Shell midden; Lake shore	\N	1	-819	\N	C	2019-12-20 22:14:28.053842+00	3074
1	818	12	feature	Shell midden; Lake shore	\N	1	-818	\N	C	2019-12-20 22:14:28.053842+00	3075
1	817	12	feature	Shell midden; Lake shore	\N	1	-817	\N	C	2019-12-20 22:14:28.053842+00	3076
1	816	12	feature	Shell midden; Lake shore	\N	1	-816	\N	C	2019-12-20 22:14:28.053842+00	3077
1	815	12	feature	Shell midden; Lake shore	\N	1	-815	\N	C	2019-12-20 22:14:28.053842+00	3078
1	814	12	feature	Shell midden; Lake shore	\N	1	-814	\N	C	2019-12-20 22:14:28.053842+00	3079
1	813	12	feature	Shell midden; Lake shore	\N	1	-813	\N	C	2019-12-20 22:14:28.053842+00	3080
1	812	12	feature	Shell midden; Lake shore	\N	1	-812	\N	C	2019-12-20 22:14:28.053842+00	3081
1	811	12	feature	Shell midden; Lake shore	\N	1	-811	\N	C	2019-12-20 22:14:28.053842+00	3082
1	810	12	feature	Shell midden; Lake shore	\N	1	-810	\N	C	2019-12-20 22:14:28.053842+00	3083
1	809	12	feature	Shell midden; Lake shore	\N	1	-809	\N	C	2019-12-20 22:14:28.053842+00	3084
1	808	12	feature	Shell midden; Lake shore	\N	1	-808	\N	C	2019-12-20 22:14:28.053842+00	3085
1	807	12	feature	Shell midden; Lake shore	\N	1	-807	\N	C	2019-12-20 22:14:28.053842+00	3086
1	806	12	feature	Shell midden; Lake shore	\N	1	-806	\N	C	2019-12-20 22:14:28.053842+00	3087
1	805	12	feature	Shell midden; Lake shore	\N	1	-805	\N	C	2019-12-20 22:14:28.053842+00	3088
1	804	12	feature	Shell midden; Lake shore	\N	1	-804	\N	C	2019-12-20 22:14:28.053842+00	3089
1	803	12	feature	Shell midden; Lake shore	\N	1	-803	\N	C	2019-12-20 22:14:28.053842+00	3090
1	802	12	feature	Shell midden; Lake shore	\N	1	-802	\N	C	2019-12-20 22:14:28.053842+00	3091
1	801	12	feature	Shell midden; Lake shore	\N	1	-801	\N	C	2019-12-20 22:14:28.053842+00	3092
1	800	12	feature	Shell midden; Lake shore	\N	1	-800	\N	C	2019-12-20 22:14:28.053842+00	3093
1	799	12	feature	Shell midden; Lake shore	\N	1	-799	\N	C	2019-12-20 22:14:28.053842+00	3094
1	798	12	feature	Shell midden; Lake shore	\N	1	-798	\N	C	2019-12-20 22:14:28.053842+00	3095
1	797	12	feature	Shell midden; Lake shore	\N	1	-797	\N	C	2019-12-20 22:14:28.053842+00	3096
1	796	12	feature	Shell midden; Lake shore	\N	1	-796	\N	C	2019-12-20 22:14:28.053842+00	3097
1	795	12	feature	Shell midden; Lake shore	\N	1	-795	\N	C	2019-12-20 22:14:28.053842+00	3098
1	794	12	feature	Shell midden; Lake shore	\N	1	-794	\N	C	2019-12-20 22:14:28.053842+00	3099
1	793	12	feature	Shell midden; Lake shore	\N	1	-793	\N	C	2019-12-20 22:14:28.053842+00	3100
1	792	12	feature	Shell midden; Lake shore	\N	1	-792	\N	C	2019-12-20 22:14:28.053842+00	3101
1	791	12	feature	Shell midden; Lake shore	\N	1	-791	\N	C	2019-12-20 22:14:28.053842+00	3102
1	790	12	feature	Shell midden; Lake shore	\N	1	-790	\N	C	2019-12-20 22:14:28.053842+00	3103
1	789	12	feature	Shell midden; Lake shore	\N	1	-789	\N	C	2019-12-20 22:14:28.053842+00	3104
1	788	12	feature	Shell midden; Lake shore	\N	1	-788	\N	C	2019-12-20 22:14:28.053842+00	3105
1	787	12	feature	Shell midden; Lake shore	\N	1	-787	\N	C	2019-12-20 22:14:28.053842+00	3106
1	786	12	feature	Shell midden; Lake shore	\N	1	-786	\N	C	2019-12-20 22:14:28.053842+00	3107
1	785	12	feature	Shell midden; Lake shore	\N	1	-785	\N	C	2019-12-20 22:14:28.053842+00	3108
1	784	12	feature	Shell midden; Lake shore	\N	1	-784	\N	C	2019-12-20 22:14:28.053842+00	3109
1	783	12	feature	Shell midden; Lake shore	\N	1	-783	\N	C	2019-12-20 22:14:28.053842+00	3110
1	782	12	feature	Shell midden; Lake shore	\N	1	-782	\N	C	2019-12-20 22:14:28.053842+00	3111
1	781	27	feature	Open-air; Lake shore	\N	1	-781	\N	C	2019-12-20 22:14:28.053842+00	3112
1	780	27	feature	Open-air; Lake shore	\N	1	-780	\N	C	2019-12-20 22:14:28.053842+00	3113
1	779	27	feature	Open-air; Lake shore	\N	1	-779	\N	C	2019-12-20 22:14:28.053842+00	3114
1	778	27	feature	Open-air; Lake shore	\N	1	-778	\N	C	2019-12-20 22:14:28.053842+00	3115
1	777	27	feature	Open-air; Lake shore	\N	1	-777	\N	C	2019-12-20 22:14:28.053842+00	3116
1	776	27	feature	Open-air; Lake shore	\N	1	-776	\N	C	2019-12-20 22:14:28.053842+00	3117
1	775	27	feature	Open-air; Lake shore	\N	1	-775	\N	C	2019-12-20 22:14:28.053842+00	3118
1	774	27	feature	Open-air; Lake shore	\N	1	-774	\N	C	2019-12-20 22:14:28.053842+00	3119
1	773	27	feature	Open-air; Lake shore	\N	1	-773	\N	C	2019-12-20 22:14:28.053842+00	3120
1	772	27	feature	Open-air; Lake shore	\N	1	-772	\N	C	2019-12-20 22:14:28.053842+00	3121
1	771	27	feature	Open-air; Lake shore	\N	1	-771	\N	C	2019-12-20 22:14:28.053842+00	3122
1	770	27	feature	Open-air; Lake shore	\N	1	-770	\N	C	2019-12-20 22:14:28.053842+00	3123
1	769	27	feature	Open-air; Lake shore	\N	1	-769	\N	C	2019-12-20 22:14:28.053842+00	3124
1	768	27	feature	Open-air; Lake shore	\N	1	-768	\N	C	2019-12-20 22:14:28.053842+00	3125
1	767	27	feature	Open-air; Lake shore	\N	1	-767	\N	C	2019-12-20 22:14:28.053842+00	3126
1	766	27	feature	Open-air; Lake shore	\N	1	-766	\N	C	2019-12-20 22:14:28.053842+00	3127
1	765	27	feature	Open-air; Lake shore	\N	1	-765	\N	C	2019-12-20 22:14:28.053842+00	3128
1	764	27	feature	Open-air; Lake shore	\N	1	-764	\N	C	2019-12-20 22:14:28.053842+00	3129
1	763	27	feature	Open-air; Lake shore	\N	1	-763	\N	C	2019-12-20 22:14:28.053842+00	3130
1	762	27	feature	Open-air; Lake shore	\N	1	-762	\N	C	2019-12-20 22:14:28.053842+00	3131
1	761	27	feature	Open-air; Lake shore	\N	1	-761	\N	C	2019-12-20 22:14:28.053842+00	3132
1	760	27	feature	Open-air; Lake shore	\N	1	-760	\N	C	2019-12-20 22:14:28.053842+00	3133
1	759	27	feature	Open-air; Lake shore	\N	1	-759	\N	C	2019-12-20 22:14:28.053842+00	3134
1	758	27	feature	Open-air; Lake shore	\N	1	-758	\N	C	2019-12-20 22:14:28.053842+00	3135
1	757	27	feature	Open-air; Lake shore	\N	1	-757	\N	C	2019-12-20 22:14:28.053842+00	3136
1	756	27	feature	Open-air; Lake shore	\N	1	-756	\N	C	2019-12-20 22:14:28.053842+00	3137
1	755	27	feature	Open-air; Lake shore	\N	1	-755	\N	C	2019-12-20 22:14:28.053842+00	3138
1	754	27	feature	Open-air; Lake shore	\N	1	-754	\N	C	2019-12-20 22:14:28.053842+00	3139
1	753	27	feature	Open-air; Lake shore	\N	1	-753	\N	C	2019-12-20 22:14:28.053842+00	3140
1	752	27	feature	Open-air; Lake shore	\N	1	-752	\N	C	2019-12-20 22:14:28.053842+00	3141
1	751	27	feature	Open-air; Lake shore	\N	1	-751	\N	C	2019-12-20 22:14:28.053842+00	3142
1	750	27	feature	Open-air; Lake shore	\N	1	-750	\N	C	2019-12-20 22:14:28.053842+00	3143
1	749	27	feature	Open-air; Lake shore	\N	1	-749	\N	C	2019-12-20 22:14:28.053842+00	3144
1	748	27	feature	Open-air; Lake shore	\N	1	-748	\N	C	2019-12-20 22:14:28.053842+00	3145
1	747	27	feature	Open-air; Lake shore	\N	1	-747	\N	C	2019-12-20 22:14:28.053842+00	3146
1	746	27	feature	Open-air; Lake shore	\N	1	-746	\N	C	2019-12-20 22:14:28.053842+00	3147
1	745	27	feature	Open-air; Lake shore	\N	1	-745	\N	C	2019-12-20 22:14:28.053842+00	3148
1	744	27	feature	Open-air; Lake shore	\N	1	-744	\N	C	2019-12-20 22:14:28.053842+00	3149
1	743	27	feature	Open-air; Lake shore	\N	1	-743	\N	C	2019-12-20 22:14:28.053842+00	3150
1	742	27	feature	Open-air; Lake shore	\N	1	-742	\N	C	2019-12-20 22:14:28.053842+00	3151
1	741	27	feature	Open-air; Lake shore	\N	1	-741	\N	C	2019-12-20 22:14:28.053842+00	3152
1	740	27	feature	Open-air; Lake shore	\N	1	-740	\N	C	2019-12-20 22:14:28.053842+00	3153
1	739	27	feature	Open-air; Lake shore	\N	1	-739	\N	C	2019-12-20 22:14:28.053842+00	3154
1	738	27	feature	Open-air; Lake shore	\N	1	-738	\N	C	2019-12-20 22:14:28.053842+00	3155
1	737	27	feature	Open-air; Lake shore	\N	1	-737	\N	C	2019-12-20 22:14:28.053842+00	3156
1	736	27	feature	Open-air; Lake shore	\N	1	-736	\N	C	2019-12-20 22:14:28.053842+00	3157
1	735	27	feature	Open-air; Lake shore	\N	1	-735	\N	C	2019-12-20 22:14:28.053842+00	3158
1	734	27	feature	Open-air; Lake shore	\N	1	-734	\N	C	2019-12-20 22:14:28.053842+00	3159
1	733	27	feature	Open-air; Lake shore	\N	1	-733	\N	C	2019-12-20 22:14:28.053842+00	3160
1	732	27	feature	Open-air; Lake shore	\N	1	-732	\N	C	2019-12-20 22:14:28.053842+00	3161
1	731	27	feature	Open-air; Lake shore	\N	1	-731	\N	C	2019-12-20 22:14:28.053842+00	3162
1	730	27	feature	Open-air; Lake shore	\N	1	-730	\N	C	2019-12-20 22:14:28.053842+00	3163
1	729	27	feature	Open-air; Lake shore	\N	1	-729	\N	C	2019-12-20 22:14:28.053842+00	3164
1	728	27	feature	Open-air; Lake shore	\N	1	-728	\N	C	2019-12-20 22:14:28.053842+00	3165
1	727	27	feature	Open-air; Lake shore	\N	1	-727	\N	C	2019-12-20 22:14:28.053842+00	3166
1	726	27	feature	Open-air; Lake shore	\N	1	-726	\N	C	2019-12-20 22:14:28.053842+00	3167
1	725	27	feature	Open-air; Lake shore	\N	1	-725	\N	C	2019-12-20 22:14:28.053842+00	3168
1	724	27	feature	Open-air; Lake shore	\N	1	-724	\N	C	2019-12-20 22:14:28.053842+00	3169
1	723	27	feature	Open-air; Lake shore	\N	1	-723	\N	C	2019-12-20 22:14:28.053842+00	3170
1	722	27	feature	Open-air; Lake shore	\N	1	-722	\N	C	2019-12-20 22:14:28.053842+00	3171
1	721	27	feature	Open-air; Lake shore	\N	1	-721	\N	C	2019-12-20 22:14:28.053842+00	3172
1	720	27	feature	Open-air; Lake shore	\N	1	-720	\N	C	2019-12-20 22:14:28.053842+00	3173
1	719	27	feature	Open-air; Lake shore	\N	1	-719	\N	C	2019-12-20 22:14:28.053842+00	3174
1	718	27	feature	Open-air; Lake shore	\N	1	-718	\N	C	2019-12-20 22:14:28.053842+00	3175
1	717	27	feature	Open-air; Lake shore	\N	1	-717	\N	C	2019-12-20 22:14:28.053842+00	3176
1	716	27	feature	Open-air; Lake shore	\N	1	-716	\N	C	2019-12-20 22:14:28.053842+00	3177
1	715	27	feature	Open-air; Lake shore	\N	1	-715	\N	C	2019-12-20 22:14:28.053842+00	3178
1	714	27	feature	Open-air; Lake shore	\N	1	-714	\N	C	2019-12-20 22:14:28.053842+00	3179
1	713	27	feature	Open-air; Lake shore	\N	1	-713	\N	C	2019-12-20 22:14:28.053842+00	3180
1	712	27	feature	Open-air; Lake shore	\N	1	-712	\N	C	2019-12-20 22:14:28.053842+00	3181
1	711	27	feature	Open-air; Lake shore	\N	1	-711	\N	C	2019-12-20 22:14:28.053842+00	3182
1	710	27	feature	Open-air; Lake shore	\N	1	-710	\N	C	2019-12-20 22:14:28.053842+00	3183
1	709	27	feature	Open-air; Lake shore	\N	1	-709	\N	C	2019-12-20 22:14:28.053842+00	3184
1	708	27	feature	Open-air; Lake shore	\N	1	-708	\N	C	2019-12-20 22:14:28.053842+00	3185
1	707	27	feature	Open-air; Lake shore	\N	1	-707	\N	C	2019-12-20 22:14:28.053842+00	3186
1	706	27	feature	Open-air; Lake shore	\N	1	-706	\N	C	2019-12-20 22:14:28.053842+00	3187
1	705	27	feature	Open-air; Lake shore	\N	1	-705	\N	C	2019-12-20 22:14:28.053842+00	3188
1	704	27	feature	Open-air; Lake shore	\N	1	-704	\N	C	2019-12-20 22:14:28.053842+00	3189
1	703	27	feature	Open-air; Lake shore	\N	1	-703	\N	C	2019-12-20 22:14:28.053842+00	3190
1	702	27	feature	Open-air; Lake shore	\N	1	-702	\N	C	2019-12-20 22:14:28.053842+00	3191
1	701	27	feature	Open-air; Lake shore	\N	1	-701	\N	C	2019-12-20 22:14:28.053842+00	3192
1	700	27	feature	Open-air; Lake shore	\N	1	-700	\N	C	2019-12-20 22:14:28.053842+00	3193
1	699	27	feature	Open-air; Close to the coast	\N	1	-699	\N	C	2019-12-20 22:14:28.053842+00	3194
1	698	27	feature	Open-air; Close to the coast	\N	1	-698	\N	C	2019-12-20 22:14:28.053842+00	3195
1	697	27	feature	Open-air; Close to the coast	\N	1	-697	\N	C	2019-12-20 22:14:28.053842+00	3196
1	696	27	feature	Open-air; Close to the coast	\N	1	-696	\N	C	2019-12-20 22:14:28.053842+00	3197
1	695	27	feature	Open-air; Close to the coast	\N	1	-695	\N	C	2019-12-20 22:14:28.053842+00	3198
1	694	27	feature	Open-air; Close to the coast	\N	1	-694	\N	C	2019-12-20 22:14:28.053842+00	3199
1	693	27	feature	Open-air; Close to the coast	\N	1	-693	\N	C	2019-12-20 22:14:28.053842+00	3200
1	692	27	feature	Open-air; Close to the coast	\N	1	-692	\N	C	2019-12-20 22:14:28.053842+00	3201
1	691	27	feature	Open-air; Close to the coast	\N	1	-691	\N	C	2019-12-20 22:14:28.053842+00	3202
1	690	27	feature	Open-air; Close to the coast	\N	1	-690	\N	C	2019-12-20 22:14:28.053842+00	3203
1	689	27	feature	Open-air; Close to the coast	\N	1	-689	\N	C	2019-12-20 22:14:28.053842+00	3204
1	688	27	feature	Open-air; Close to the coast	\N	1	-688	\N	C	2019-12-20 22:14:28.053842+00	3205
1	687	27	feature	Open-air; Close to the coast	\N	1	-687	\N	C	2019-12-20 22:14:28.053842+00	3206
1	686	27	feature	Open-air; Close to the coast	\N	1	-686	\N	C	2019-12-20 22:14:28.053842+00	3207
1	685	27	feature	Open-air; Close to the coast	\N	1	-685	\N	C	2019-12-20 22:14:28.053842+00	3208
1	684	27	feature	Open-air; Close to the coast	\N	1	-684	\N	C	2019-12-20 22:14:28.053842+00	3209
1	683	27	feature	Open-air; Close to the coast	\N	1	-683	\N	C	2019-12-20 22:14:28.053842+00	3210
1	682	27	feature	Open-air; Close to the coast	\N	1	-682	\N	C	2019-12-20 22:14:28.053842+00	3211
1	681	27	feature	Open-air; Close to the coast	\N	1	-681	\N	C	2019-12-20 22:14:28.053842+00	3212
1	680	27	feature	Open-air; Close to the coast	\N	1	-680	\N	C	2019-12-20 22:14:28.053842+00	3213
1	679	27	feature	Open-air; Close to the coast	\N	1	-679	\N	C	2019-12-20 22:14:28.053842+00	3214
1	678	27	feature	Open-air; Close to the coast	\N	1	-678	\N	C	2019-12-20 22:14:28.053842+00	3215
1	677	27	feature	Open-air; Close to the coast	\N	1	-677	\N	C	2019-12-20 22:14:28.053842+00	3216
1	676	12	feature	Shell midden; Inland	\N	1	-676	\N	C	2019-12-20 22:14:28.053842+00	3217
1	675	12	feature	Shell midden; Inland	\N	1	-675	\N	C	2019-12-20 22:14:28.053842+00	3218
1	674	12	feature	Shell midden; Inland	\N	1	-674	\N	C	2019-12-20 22:14:28.053842+00	3219
1	673	12	feature	Shell midden; Inland	\N	1	-673	\N	C	2019-12-20 22:14:28.053842+00	3220
1	672	12	feature	Shell midden; Inland	\N	1	-672	\N	C	2019-12-20 22:14:28.053842+00	3221
1	671	12	feature	Shell midden; Inland	\N	1	-671	\N	C	2019-12-20 22:14:28.053842+00	3222
1	670	12	feature	Shell midden; Inland	\N	1	-670	\N	C	2019-12-20 22:14:28.053842+00	3223
1	669	12	feature	Shell midden; Inland	\N	1	-669	\N	C	2019-12-20 22:14:28.053842+00	3224
1	668	12	feature	Shell midden; Inland	\N	1	-668	\N	C	2019-12-20 22:14:28.053842+00	3225
1	667	12	feature	Shell midden; Inland	\N	1	-667	\N	C	2019-12-20 22:14:28.053842+00	3226
1	666	12	feature	Shell midden; Inland	\N	1	-666	\N	C	2019-12-20 22:14:28.053842+00	3227
1	665	12	feature	Shell midden; Inland	\N	1	-665	\N	C	2019-12-20 22:14:28.053842+00	3228
1	664	12	feature	Shell midden; Inland	\N	1	-664	\N	C	2019-12-20 22:14:28.053842+00	3229
1	663	12	feature	Shell midden; Inland	\N	1	-663	\N	C	2019-12-20 22:14:28.053842+00	3230
1	662	12	feature	Shell midden; Inland	\N	1	-662	\N	C	2019-12-20 22:14:28.053842+00	3231
1	661	12	feature	Shell midden; Inland	\N	1	-661	\N	C	2019-12-20 22:14:28.053842+00	3232
1	660	12	feature	Shell midden; Inland	\N	1	-660	\N	C	2019-12-20 22:14:28.053842+00	3233
1	659	12	feature	Shell midden; Inland	\N	1	-659	\N	C	2019-12-20 22:14:28.053842+00	3234
1	658	12	feature	Shell midden; Inland	\N	1	-658	\N	C	2019-12-20 22:14:28.053842+00	3235
1	657	12	feature	Shell midden; Inland	\N	1	-657	\N	C	2019-12-20 22:14:28.053842+00	3236
1	656	12	feature	Shell midden; Inland	\N	1	-656	\N	C	2019-12-20 22:14:28.053842+00	3237
1	655	12	feature	Shell midden; Inland	\N	1	-655	\N	C	2019-12-20 22:14:28.053842+00	3238
1	654	12	feature	Shell midden; Inland	\N	1	-654	\N	C	2019-12-20 22:14:28.053842+00	3239
1	653	12	feature	Shell midden; Inland	\N	1	-653	\N	C	2019-12-20 22:14:28.053842+00	3240
1	652	12	feature	Shell midden; Inland	\N	1	-652	\N	C	2019-12-20 22:14:28.053842+00	3241
1	651	12	feature	Shell midden; Inland	\N	1	-651	\N	C	2019-12-20 22:14:28.053842+00	3242
1	650	12	feature	Shell midden; Inland	\N	1	-650	\N	C	2019-12-20 22:14:28.053842+00	3243
1	649	12	feature	Shell midden; Inland	\N	1	-649	\N	C	2019-12-20 22:14:28.053842+00	3244
1	648	12	feature	Shell midden; Inland	\N	1	-648	\N	C	2019-12-20 22:14:28.053842+00	3245
1	647	12	feature	Shell midden; Inland	\N	1	-647	\N	C	2019-12-20 22:14:28.053842+00	3246
1	646	12	feature	Shell midden; Inland	\N	1	-646	\N	C	2019-12-20 22:14:28.053842+00	3247
1	645	12	feature	Shell midden; Inland	\N	1	-645	\N	C	2019-12-20 22:14:28.053842+00	3248
1	644	12	feature	Shell midden; Inland	\N	1	-644	\N	C	2019-12-20 22:14:28.053842+00	3249
1	643	12	feature	Shell midden; Inland	\N	1	-643	\N	C	2019-12-20 22:14:28.053842+00	3250
1	642	12	feature	Shell midden; Inland	\N	1	-642	\N	C	2019-12-20 22:14:28.053842+00	3251
1	641	12	feature	Shell midden; Inland	\N	1	-641	\N	C	2019-12-20 22:14:28.053842+00	3252
1	640	12	feature	Shell midden; Inland	\N	1	-640	\N	C	2019-12-20 22:14:28.053842+00	3253
1	639	12	feature	Shell midden; Inland	\N	1	-639	\N	C	2019-12-20 22:14:28.053842+00	3254
1	638	12	feature	Shell midden; Inland	\N	1	-638	\N	C	2019-12-20 22:14:28.053842+00	3255
1	637	12	feature	Shell midden; Inland	\N	1	-637	\N	C	2019-12-20 22:14:28.053842+00	3256
1	636	12	feature	Shell midden; Inland	\N	1	-636	\N	C	2019-12-20 22:14:28.053842+00	3257
1	635	12	feature	Shell midden; Inland	\N	1	-635	\N	C	2019-12-20 22:14:28.053842+00	3258
1	634	12	feature	Shell midden; Inland	\N	1	-634	\N	C	2019-12-20 22:14:28.053842+00	3259
1	633	12	feature	Shell midden; Inland	\N	1	-633	\N	C	2019-12-20 22:14:28.053842+00	3260
1	632	12	feature	Shell midden; Inland	\N	1	-632	\N	C	2019-12-20 22:14:28.053842+00	3261
1	631	12	feature	Shell midden; Inland	\N	1	-631	\N	C	2019-12-20 22:14:28.053842+00	3262
1	630	12	feature	Shell midden; Inland	\N	1	-630	\N	C	2019-12-20 22:14:28.053842+00	3263
1	629	12	feature	Shell midden; Inland	\N	1	-629	\N	C	2019-12-20 22:14:28.053842+00	3264
1	628	12	feature	Shell midden; Inland	\N	1	-628	\N	C	2019-12-20 22:14:28.053842+00	3265
1	627	12	feature	Shell midden; Inland	\N	1	-627	\N	C	2019-12-20 22:14:28.053842+00	3266
1	626	12	feature	Shell midden; Inland	\N	1	-626	\N	C	2019-12-20 22:14:28.053842+00	3267
1	625	12	feature	Shell midden; Inland	\N	1	-625	\N	C	2019-12-20 22:14:28.053842+00	3268
1	624	12	feature	Shell midden; Inland	\N	1	-624	\N	C	2019-12-20 22:14:28.053842+00	3269
1	623	12	feature	Shell midden; Inland	\N	1	-623	\N	C	2019-12-20 22:14:28.053842+00	3270
1	622	12	feature	Shell midden; Inland	\N	1	-622	\N	C	2019-12-20 22:14:28.053842+00	3271
1	621	12	feature	Shell midden; Inland	\N	1	-621	\N	C	2019-12-20 22:14:28.053842+00	3272
1	620	12	feature	Shell midden; Inland	\N	1	-620	\N	C	2019-12-20 22:14:28.053842+00	3273
1	619	12	feature	Shell midden; Inland	\N	1	-619	\N	C	2019-12-20 22:14:28.053842+00	3274
1	618	12	feature	Shell midden; Inland	\N	1	-618	\N	C	2019-12-20 22:14:28.053842+00	3275
1	617	12	feature	Shell midden; Inland	\N	1	-617	\N	C	2019-12-20 22:14:28.053842+00	3276
1	616	12	feature	Shell midden; Inland	\N	1	-616	\N	C	2019-12-20 22:14:28.053842+00	3277
1	615	12	feature	Shell midden; Inland	\N	1	-615	\N	C	2019-12-20 22:14:28.053842+00	3278
1	614	12	feature	Shell midden; Inland	\N	1	-614	\N	C	2019-12-20 22:14:28.053842+00	3279
1	613	12	feature	Shell midden; Close to the coast	\N	1	-613	\N	C	2019-12-20 22:14:28.053842+00	3280
1	612	12	feature	Shell midden; Close to the coast	\N	1	-612	\N	C	2019-12-20 22:14:28.053842+00	3281
1	611	12	feature	Shell midden; Close to the coast	\N	1	-611	\N	C	2019-12-20 22:14:28.053842+00	3282
1	610	12	feature	Shell midden; Close to the coast	\N	1	-610	\N	C	2019-12-20 22:14:28.053842+00	3283
1	609	12	feature	Shell midden; Close to the coast	\N	1	-609	\N	C	2019-12-20 22:14:28.053842+00	3284
1	608	12	feature	Shell midden; Close to the coast	\N	1	-608	\N	C	2019-12-20 22:14:28.053842+00	3285
1	607	12	feature	Shell midden; Close to the coast	\N	1	-607	\N	C	2019-12-20 22:14:28.053842+00	3286
1	606	12	feature	Shell midden; Close to the coast	\N	1	-606	\N	C	2019-12-20 22:14:28.053842+00	3287
1	605	12	feature	Shell midden; Close to the coast	\N	1	-605	\N	C	2019-12-20 22:14:28.053842+00	3288
1	604	12	feature	Shell midden; Close to the coast	\N	1	-604	\N	C	2019-12-20 22:14:28.053842+00	3289
1	603	12	feature	Shell midden; Close to the coast	\N	1	-603	\N	C	2019-12-20 22:14:28.053842+00	3290
1	602	12	feature	Shell midden; Close to the coast	\N	1	-602	\N	C	2019-12-20 22:14:28.053842+00	3291
1	601	12	feature	Shell midden; Close to the coast	\N	1	-601	\N	C	2019-12-20 22:14:28.053842+00	3292
1	600	12	feature	Shell midden; Close to the coast	\N	1	-600	\N	C	2019-12-20 22:14:28.053842+00	3293
1	599	12	feature	Shell midden; Close to the coast	\N	1	-599	\N	C	2019-12-20 22:14:28.053842+00	3294
1	598	12	feature	Shell midden; Close to the coast	\N	1	-598	\N	C	2019-12-20 22:14:28.053842+00	3295
1	597	27	feature	Open-air; Close to the coast	\N	1	-597	\N	C	2019-12-20 22:14:28.053842+00	3296
1	596	27	feature	Open-air; Close to the coast	\N	1	-596	\N	C	2019-12-20 22:14:28.053842+00	3297
1	595	27	feature	Open-air; Close to the coast	\N	1	-595	\N	C	2019-12-20 22:14:28.053842+00	3298
1	594	27	feature	Open-air; Close to the coast	\N	1	-594	\N	C	2019-12-20 22:14:28.053842+00	3299
1	593	27	feature	Open-air; Close to the coast	\N	1	-593	\N	C	2019-12-20 22:14:28.053842+00	3300
1	592	27	feature	Open-air; Close to the coast	\N	1	-592	\N	C	2019-12-20 22:14:28.053842+00	3301
1	591	27	feature	Open-air; Close to the coast	\N	1	-591	\N	C	2019-12-20 22:14:28.053842+00	3302
1	590	27	feature	Open-air; Close to the coast	\N	1	-590	\N	C	2019-12-20 22:14:28.053842+00	3303
1	589	27	feature	Open-air; Close to the coast	\N	1	-589	\N	C	2019-12-20 22:14:28.053842+00	3304
1	588	27	feature	Open-air; Close to the coast	\N	1	-588	\N	C	2019-12-20 22:14:28.053842+00	3305
1	587	27	feature	Open-air; Close to the coast	\N	1	-587	\N	C	2019-12-20 22:14:28.053842+00	3306
1	586	27	feature	Open-air; Close to the coast	\N	1	-586	\N	C	2019-12-20 22:14:28.053842+00	3307
1	585	27	feature	Open-air; Close to the coast	\N	1	-585	\N	C	2019-12-20 22:14:28.053842+00	3308
1	584	27	feature	Open-air; Close to the coast	\N	1	-584	\N	C	2019-12-20 22:14:28.053842+00	3309
1	583	27	feature	Open-air; Close to the coast	\N	1	-583	\N	C	2019-12-20 22:14:28.053842+00	3310
1	582	27	feature	Open-air; Close to the coast	\N	1	-582	\N	C	2019-12-20 22:14:28.053842+00	3311
1	581	27	feature	Open-air; Close to the coast	\N	1	-581	\N	C	2019-12-20 22:14:28.053842+00	3312
1	580	27	feature	Open-air; Close to the coast	\N	1	-580	\N	C	2019-12-20 22:14:28.053842+00	3313
1	579	27	feature	Open-air; Close to the coast	\N	1	-579	\N	C	2019-12-20 22:14:28.053842+00	3314
1	578	27	feature	Open-air; Close to the coast	\N	1	-578	\N	C	2019-12-20 22:14:28.053842+00	3315
1	577	27	feature	Open-air; Close to the coast	\N	1	-577	\N	C	2019-12-20 22:14:28.053842+00	3316
1	576	27	feature	Open-air; Close to the coast	\N	1	-576	\N	C	2019-12-20 22:14:28.053842+00	3317
1	575	27	feature	Open-air; Close to the coast	\N	1	-575	\N	C	2019-12-20 22:14:28.053842+00	3318
1	574	27	feature	Open-air; Close to the coast	\N	1	-574	\N	C	2019-12-20 22:14:28.053842+00	3319
1	573	27	feature	Open-air; Close to the coast	\N	1	-573	\N	C	2019-12-20 22:14:28.053842+00	3320
1	572	27	feature	Open-air; Close to the coast	\N	1	-572	\N	C	2019-12-20 22:14:28.053842+00	3321
1	571	27	feature	Open-air; Close to the coast	\N	1	-571	\N	C	2019-12-20 22:14:28.053842+00	3322
1	570	27	feature	Open-air; Close to the coast	\N	1	-570	\N	C	2019-12-20 22:14:28.053842+00	3323
1	569	27	feature	Open-air; Close to the coast	\N	1	-569	\N	C	2019-12-20 22:14:28.053842+00	3324
1	568	27	feature	Open-air; Close to the coast	\N	1	-568	\N	C	2019-12-20 22:14:28.053842+00	3325
1	567	27	feature	Open-air; Close to the coast	\N	1	-567	\N	C	2019-12-20 22:14:28.053842+00	3326
1	566	27	feature	Open-air; Close to the coast	\N	1	-566	\N	C	2019-12-20 22:14:28.053842+00	3327
1	565	27	feature	Open-air; Close to the coast	\N	1	-565	\N	C	2019-12-20 22:14:28.053842+00	3328
1	564	27	feature	Open-air; Close to the coast	\N	1	-564	\N	C	2019-12-20 22:14:28.053842+00	3329
1	563	27	feature	Open-air; Close to the coast	\N	1	-563	\N	C	2019-12-20 22:14:28.053842+00	3330
1	562	27	feature	Open-air; Close to the coast	\N	1	-562	\N	C	2019-12-20 22:14:28.053842+00	3331
1	63	27	feature	Open-air; Close to the coast	\N	1	-63	\N	C	2019-12-20 22:14:28.053842+00	3830
1	62	27	feature	Open-air; Close to the coast	\N	1	-62	\N	C	2019-12-20 22:14:28.053842+00	3831
1	61	27	feature	Open-air; Close to the coast	\N	1	-61	\N	C	2019-12-20 22:14:28.053842+00	3832
1	60	27	feature	Open-air; Close to the coast	\N	1	-60	\N	C	2019-12-20 22:14:28.053842+00	3833
1	59	27	feature	Open-air; Close to the coast	\N	1	-59	\N	C	2019-12-20 22:14:28.053842+00	3834
1	58	27	feature	Open-air; Close to the coast	\N	1	-58	\N	C	2019-12-20 22:14:28.053842+00	3835
1	57	27	feature	Open-air; Close to the coast	\N	1	-57	\N	C	2019-12-20 22:14:28.053842+00	3836
1	56	27	feature	Open-air; Close to the coast	\N	1	-56	\N	C	2019-12-20 22:14:28.053842+00	3837
1	55	27	feature	Open-air; Close to the coast	\N	1	-55	\N	C	2019-12-20 22:14:28.053842+00	3838
1	54	27	feature	Open-air; Close to the coast	\N	1	-54	\N	C	2019-12-20 22:14:28.053842+00	3839
1	53	27	feature	Open-air; Close to the coast	\N	1	-53	\N	C	2019-12-20 22:14:28.053842+00	3840
1	52	27	feature	Open-air; Close to the coast	\N	1	-52	\N	C	2019-12-20 22:14:28.053842+00	3841
1	51	27	feature	Open-air; Close to the coast	\N	1	-51	\N	C	2019-12-20 22:14:28.053842+00	3842
1	50	27	feature	Open-air; Close to the coast	\N	1	-50	\N	C	2019-12-20 22:14:28.053842+00	3843
1	49	27	feature	Open-air; Close to the coast	\N	1	-49	\N	C	2019-12-20 22:14:28.053842+00	3844
1	48	27	feature	Open-air; Close to the coast	\N	1	-48	\N	C	2019-12-20 22:14:28.053842+00	3845
1	47	27	feature	Open-air; Close to the coast	\N	1	-47	\N	C	2019-12-20 22:14:28.053842+00	3846
1	46	27	feature	Open-air; Close to the coast	\N	1	-46	\N	C	2019-12-20 22:14:28.053842+00	3847
1	561	27	feature	Open-air; Close to the coast	\N	1	-561	\N	C	2019-12-20 22:14:28.053842+00	3332
1	560	27	feature	Open-air; Close to the coast	\N	1	-560	\N	C	2019-12-20 22:14:28.053842+00	3333
1	559	27	feature	Open-air; Close to the coast	\N	1	-559	\N	C	2019-12-20 22:14:28.053842+00	3334
1	558	27	feature	Open-air; Close to the coast	\N	1	-558	\N	C	2019-12-20 22:14:28.053842+00	3335
1	557	27	feature	Open-air; Close to the coast	\N	1	-557	\N	C	2019-12-20 22:14:28.053842+00	3336
1	556	27	feature	Open-air; Close to the coast	\N	1	-556	\N	C	2019-12-20 22:14:28.053842+00	3337
1	555	27	feature	Open-air; Close to the coast	\N	1	-555	\N	C	2019-12-20 22:14:28.053842+00	3338
1	554	27	feature	Open-air; Close to the coast	\N	1	-554	\N	C	2019-12-20 22:14:28.053842+00	3339
1	553	27	feature	Open-air; Close to the coast	\N	1	-553	\N	C	2019-12-20 22:14:28.053842+00	3340
1	552	27	feature	Open-air; Close to the coast	\N	1	-552	\N	C	2019-12-20 22:14:28.053842+00	3341
1	551	27	feature	Open-air; Close to the coast	\N	1	-551	\N	C	2019-12-20 22:14:28.053842+00	3342
1	550	27	feature	Open-air; Close to the coast	\N	1	-550	\N	C	2019-12-20 22:14:28.053842+00	3343
1	549	27	feature	Open-air; Close to the coast	\N	1	-549	\N	C	2019-12-20 22:14:28.053842+00	3344
1	548	27	feature	Open-air; Close to the coast	\N	1	-548	\N	C	2019-12-20 22:14:28.053842+00	3345
1	547	27	feature	Open-air; Close to the coast	\N	1	-547	\N	C	2019-12-20 22:14:28.053842+00	3346
1	524	27	feature	Open-air; Close to the coast	\N	1	-524	\N	C	2019-12-20 22:14:28.053842+00	3369
1	523	27	feature	Open-air; Close to the coast	\N	1	-523	\N	C	2019-12-20 22:14:28.053842+00	3370
1	522	27	feature	Open-air; Close to the coast	\N	1	-522	\N	C	2019-12-20 22:14:28.053842+00	3371
1	521	27	feature	Open-air; Close to the coast	\N	1	-521	\N	C	2019-12-20 22:14:28.053842+00	3372
1	520	27	feature	Open-air; Close to the coast	\N	1	-520	\N	C	2019-12-20 22:14:28.053842+00	3373
1	519	27	feature	Open-air; Close to the coast	\N	1	-519	\N	C	2019-12-20 22:14:28.053842+00	3374
1	518	27	feature	Open-air; Close to the coast	\N	1	-518	\N	C	2019-12-20 22:14:28.053842+00	3375
1	517	27	feature	Open-air; Close to the coast	\N	1	-517	\N	C	2019-12-20 22:14:28.053842+00	3376
1	516	27	feature	Open-air; Close to the coast	\N	1	-516	\N	C	2019-12-20 22:14:28.053842+00	3377
1	515	27	feature	Open-air; Close to the coast	\N	1	-515	\N	C	2019-12-20 22:14:28.053842+00	3378
1	514	27	feature	Open-air; Close to the coast	\N	1	-514	\N	C	2019-12-20 22:14:28.053842+00	3379
1	513	27	feature	Open-air; Close to the coast	\N	1	-513	\N	C	2019-12-20 22:14:28.053842+00	3380
1	512	27	feature	Open-air; Close to the coast	\N	1	-512	\N	C	2019-12-20 22:14:28.053842+00	3381
1	511	27	feature	Open-air; Close to the coast	\N	1	-511	\N	C	2019-12-20 22:14:28.053842+00	3382
1	510	27	feature	Open-air; Close to the coast	\N	1	-510	\N	C	2019-12-20 22:14:28.053842+00	3383
1	509	27	feature	Open-air; Close to the coast	\N	1	-509	\N	C	2019-12-20 22:14:28.053842+00	3384
1	508	27	feature	Open-air; Close to the coast	\N	1	-508	\N	C	2019-12-20 22:14:28.053842+00	3385
1	507	27	feature	Open-air; Close to the coast	\N	1	-507	\N	C	2019-12-20 22:14:28.053842+00	3386
1	506	27	feature	Open-air; Close to the coast	\N	1	-506	\N	C	2019-12-20 22:14:28.053842+00	3387
1	505	27	feature	Open-air; Close to the coast	\N	1	-505	\N	C	2019-12-20 22:14:28.053842+00	3388
1	504	27	feature	Open-air; Close to the coast	\N	1	-504	\N	C	2019-12-20 22:14:28.053842+00	3389
1	503	27	feature	Open-air; Close to the coast	\N	1	-503	\N	C	2019-12-20 22:14:28.053842+00	3390
1	502	27	feature	Open-air; Close to the coast	\N	1	-502	\N	C	2019-12-20 22:14:28.053842+00	3391
1	501	27	feature	Open-air; Close to the coast	\N	1	-501	\N	C	2019-12-20 22:14:28.053842+00	3392
1	500	27	feature	Open-air; Close to the coast	\N	1	-500	\N	C	2019-12-20 22:14:28.053842+00	3393
1	499	27	feature	Open-air; Close to the coast	\N	1	-499	\N	C	2019-12-20 22:14:28.053842+00	3394
1	498	27	feature	Open-air; Close to the coast	\N	1	-498	\N	C	2019-12-20 22:14:28.053842+00	3395
1	497	27	feature	Open-air; Close to the coast	\N	1	-497	\N	C	2019-12-20 22:14:28.053842+00	3396
1	496	27	feature	Open-air; Close to the coast	\N	1	-496	\N	C	2019-12-20 22:14:28.053842+00	3397
1	495	27	feature	Open-air; Close to the coast	\N	1	-495	\N	C	2019-12-20 22:14:28.053842+00	3398
1	494	27	feature	Open-air; Close to the coast	\N	1	-494	\N	C	2019-12-20 22:14:28.053842+00	3399
1	493	27	feature	Open-air; Close to the coast	\N	1	-493	\N	C	2019-12-20 22:14:28.053842+00	3400
1	492	27	feature	Open-air; Inland	\N	1	-492	\N	C	2019-12-20 22:14:28.053842+00	3401
1	491	27	feature	Open-air; Inland	\N	1	-491	\N	C	2019-12-20 22:14:28.053842+00	3402
1	490	27	feature	Open-air; Inland	\N	1	-490	\N	C	2019-12-20 22:14:28.053842+00	3403
1	489	27	feature	Open-air; Lake shore	\N	1	-489	\N	C	2019-12-20 22:14:28.053842+00	3404
1	488	27	feature	Open-air; Inland	\N	1	-488	\N	C	2019-12-20 22:14:28.053842+00	3405
1	487	27	feature	Open-air; Inland	\N	1	-487	\N	C	2019-12-20 22:14:28.053842+00	3406
1	486	27	feature	Open-air; Inland	\N	1	-486	\N	C	2019-12-20 22:14:28.053842+00	3407
1	485	27	feature	Open-air; Inland	\N	1	-485	\N	C	2019-12-20 22:14:28.053842+00	3408
1	484	27	feature	Open-air; Inland	\N	1	-484	\N	C	2019-12-20 22:14:28.053842+00	3409
1	483	27	feature	Open-air; Inland	\N	1	-483	\N	C	2019-12-20 22:14:28.053842+00	3410
1	482	27	feature	Open-air; Inland	\N	1	-482	\N	C	2019-12-20 22:14:28.053842+00	3411
1	481	27	feature	Open-air; Inland	\N	1	-481	\N	C	2019-12-20 22:14:28.053842+00	3412
1	480	27	feature	Open-air; Inland	\N	1	-480	\N	C	2019-12-20 22:14:28.053842+00	3413
1	479	27	feature	Open-air; Inland	\N	1	-479	\N	C	2019-12-20 22:14:28.053842+00	3414
1	478	27	feature	Open-air; Inland	\N	1	-478	\N	C	2019-12-20 22:14:28.053842+00	3415
1	477	27	feature	Open-air; Inland	\N	1	-477	\N	C	2019-12-20 22:14:28.053842+00	3416
1	476	27	feature	Open-air; Inland	\N	1	-476	\N	C	2019-12-20 22:14:28.053842+00	3417
1	475	27	feature	Open-air; Inland	\N	1	-475	\N	C	2019-12-20 22:14:28.053842+00	3418
1	474	27	feature	Open-air; Inland	\N	1	-474	\N	C	2019-12-20 22:14:28.053842+00	3419
1	473	27	feature	Open-air; Inland	\N	1	-473	\N	C	2019-12-20 22:14:28.053842+00	3420
1	472	27	feature	Open-air; Inland	\N	1	-472	\N	C	2019-12-20 22:14:28.053842+00	3421
1	471	27	feature	Open-air; Inland	\N	1	-471	\N	C	2019-12-20 22:14:28.053842+00	3422
1	470	27	feature	Open-air; Inland	\N	1	-470	\N	C	2019-12-20 22:14:28.053842+00	3423
1	469	27	feature	Open-air; Inland	\N	1	-469	\N	C	2019-12-20 22:14:28.053842+00	3424
1	468	34	feature	Rock shelter/Cave; Inland	\N	1	-468	\N	C	2019-12-20 22:14:28.053842+00	3425
1	467	34	feature	Rock shelter/Cave; Inland	\N	1	-467	\N	C	2019-12-20 22:14:28.053842+00	3426
1	466	34	feature	Rock shelter/Cave; Inland	\N	1	-466	\N	C	2019-12-20 22:14:28.053842+00	3427
1	465	34	feature	Rock shelter/Cave; Inland	\N	1	-465	\N	C	2019-12-20 22:14:28.053842+00	3428
1	464	34	feature	Rock shelter/Cave; Inland	\N	1	-464	\N	C	2019-12-20 22:14:28.053842+00	3429
1	463	34	feature	Rock shelter/Cave; Inland	\N	1	-463	\N	C	2019-12-20 22:14:28.053842+00	3430
1	462	27	feature	Open-air; Inland	\N	1	-462	\N	C	2019-12-20 22:14:28.053842+00	3431
1	461	27	feature	Open-air; Inland	\N	1	-461	\N	C	2019-12-20 22:14:28.053842+00	3432
1	460	27	feature	Open-air; Inland	\N	1	-460	\N	C	2019-12-20 22:14:28.053842+00	3433
1	459	27	feature	Open-air; Inland	\N	1	-459	\N	C	2019-12-20 22:14:28.053842+00	3434
1	458	27	feature	Open-air; Inland	\N	1	-458	\N	C	2019-12-20 22:14:28.053842+00	3435
1	457	27	feature	Open-air; Inland	\N	1	-457	\N	C	2019-12-20 22:14:28.053842+00	3436
1	456	27	feature	Open-air; Inland	\N	1	-456	\N	C	2019-12-20 22:14:28.053842+00	3437
1	455	27	feature	Open-air; Inland	\N	1	-455	\N	C	2019-12-20 22:14:28.053842+00	3438
1	454	27	feature	Open-air; Inland	\N	1	-454	\N	C	2019-12-20 22:14:28.053842+00	3439
1	453	27	feature	Open-air; Inland	\N	1	-453	\N	C	2019-12-20 22:14:28.053842+00	3440
1	452	27	feature	Open-air; Inland	\N	1	-452	\N	C	2019-12-20 22:14:28.053842+00	3441
1	451	27	feature	Open-air; Inland	\N	1	-451	\N	C	2019-12-20 22:14:28.053842+00	3442
1	450	34	feature	Rock shelter/Cave; Inland	\N	1	-450	\N	C	2019-12-20 22:14:28.053842+00	3443
1	449	27	feature	Open-air; Close to the coast	\N	1	-449	\N	C	2019-12-20 22:14:28.053842+00	3444
1	448	27	feature	Open-air; Close to the coast	\N	1	-448	\N	C	2019-12-20 22:14:28.053842+00	3445
1	447	27	feature	Open-air; Close to the coast	\N	1	-447	\N	C	2019-12-20 22:14:28.053842+00	3446
1	446	27	feature	Open-air; Close to the coast	\N	1	-446	\N	C	2019-12-20 22:14:28.053842+00	3447
1	445	27	feature	Open-air; Close to the coast	\N	1	-445	\N	C	2019-12-20 22:14:28.053842+00	3448
1	444	27	feature	Open-air; Close to the coast	\N	1	-444	\N	C	2019-12-20 22:14:28.053842+00	3449
1	443	27	feature	Open-air; Inland	\N	1	-443	\N	C	2019-12-20 22:14:28.053842+00	3450
1	442	27	feature	Open-air; Inland	\N	1	-442	\N	C	2019-12-20 22:14:28.053842+00	3451
1	441	27	feature	Open-air; Inland	\N	1	-441	\N	C	2019-12-20 22:14:28.053842+00	3452
1	440	12	feature	Shell midden; Lake shore	\N	1	-440	\N	C	2019-12-20 22:14:28.053842+00	3453
1	439	12	feature	Shell midden; Lake shore	\N	1	-439	\N	C	2019-12-20 22:14:28.053842+00	3454
1	438	12	feature	Shell midden; Lake shore	\N	1	-438	\N	C	2019-12-20 22:14:28.053842+00	3455
1	437	27	feature	Open-air; Close to the coast	\N	1	-437	\N	C	2019-12-20 22:14:28.053842+00	3456
1	436	27	feature	Open-air; Close to the coast	\N	1	-436	\N	C	2019-12-20 22:14:28.053842+00	3457
1	435	27	feature	Open-air; Close to the coast	\N	1	-435	\N	C	2019-12-20 22:14:28.053842+00	3458
1	434	27	feature	Open-air; Close to the coast	\N	1	-434	\N	C	2019-12-20 22:14:28.053842+00	3459
1	433	27	feature	Open-air; Close to the coast	\N	1	-433	\N	C	2019-12-20 22:14:28.053842+00	3460
1	432	27	feature	Open-air; Close to the coast	\N	1	-432	\N	C	2019-12-20 22:14:28.053842+00	3461
1	431	27	feature	Open-air; Close to the coast	\N	1	-431	\N	C	2019-12-20 22:14:28.053842+00	3462
1	430	27	feature	Open-air; Close to the coast	\N	1	-430	\N	C	2019-12-20 22:14:28.053842+00	3463
1	429	27	feature	Open-air; Close to the coast	\N	1	-429	\N	C	2019-12-20 22:14:28.053842+00	3464
1	428	27	feature	Open-air; Close to the coast	\N	1	-428	\N	C	2019-12-20 22:14:28.053842+00	3465
1	427	27	feature	Open-air; Close to the coast	\N	1	-427	\N	C	2019-12-20 22:14:28.053842+00	3466
1	426	27	feature	Open-air; Close to the coast	\N	1	-426	\N	C	2019-12-20 22:14:28.053842+00	3467
1	425	27	feature	Open-air; Close to the coast	\N	1	-425	\N	C	2019-12-20 22:14:28.053842+00	3468
1	424	27	feature	Open-air; Close to the coast	\N	1	-424	\N	C	2019-12-20 22:14:28.053842+00	3469
1	423	27	feature	Open-air; Close to the coast	\N	1	-423	\N	C	2019-12-20 22:14:28.053842+00	3470
1	422	27	feature	Open-air; Close to the coast	\N	1	-422	\N	C	2019-12-20 22:14:28.053842+00	3471
1	421	27	feature	Open-air; Close to the coast	\N	1	-421	\N	C	2019-12-20 22:14:28.053842+00	3472
1	420	27	feature	Open-air; Close to the coast	\N	1	-420	\N	C	2019-12-20 22:14:28.053842+00	3473
1	419	27	feature	Open-air; Close to the coast	\N	1	-419	\N	C	2019-12-20 22:14:28.053842+00	3474
1	418	27	feature	Open-air; Close to the coast	\N	1	-418	\N	C	2019-12-20 22:14:28.053842+00	3475
1	417	27	feature	Open-air; Close to the coast	\N	1	-417	\N	C	2019-12-20 22:14:28.053842+00	3476
1	416	27	feature	Open-air; Close to the coast	\N	1	-416	\N	C	2019-12-20 22:14:28.053842+00	3477
1	415	27	feature	Open-air; Close to the coast	\N	1	-415	\N	C	2019-12-20 22:14:28.053842+00	3478
1	414	27	feature	Open-air; Close to the coast	\N	1	-414	\N	C	2019-12-20 22:14:28.053842+00	3479
1	413	27	feature	Open-air; Close to the coast	\N	1	-413	\N	C	2019-12-20 22:14:28.053842+00	3480
1	412	27	feature	Open-air; Close to the coast	\N	1	-412	\N	C	2019-12-20 22:14:28.053842+00	3481
1	411	27	feature	Open-air; Close to the coast	\N	1	-411	\N	C	2019-12-20 22:14:28.053842+00	3482
1	410	27	feature	Open-air; Close to the coast	\N	1	-410	\N	C	2019-12-20 22:14:28.053842+00	3483
1	409	27	feature	Open-air; Close to the coast	\N	1	-409	\N	C	2019-12-20 22:14:28.053842+00	3484
1	408	27	feature	Open-air; Close to the coast	\N	1	-408	\N	C	2019-12-20 22:14:28.053842+00	3485
1	407	27	feature	Open-air; Close to the coast	\N	1	-407	\N	C	2019-12-20 22:14:28.053842+00	3486
1	406	27	feature	Open-air; Close to the coast	\N	1	-406	\N	C	2019-12-20 22:14:28.053842+00	3487
1	405	27	feature	Open-air; Close to the coast	\N	1	-405	\N	C	2019-12-20 22:14:28.053842+00	3488
1	404	27	feature	Open-air; Close to the coast	\N	1	-404	\N	C	2019-12-20 22:14:28.053842+00	3489
1	403	27	feature	Open-air; Close to the coast	\N	1	-403	\N	C	2019-12-20 22:14:28.053842+00	3490
1	402	27	feature	Open-air; Close to the coast	\N	1	-402	\N	C	2019-12-20 22:14:28.053842+00	3491
1	401	27	feature	Open-air; Close to the coast	\N	1	-401	\N	C	2019-12-20 22:14:28.053842+00	3492
1	400	27	feature	Open-air; Close to the coast	\N	1	-400	\N	C	2019-12-20 22:14:28.053842+00	3493
1	399	27	feature	Open-air; Close to the coast	\N	1	-399	\N	C	2019-12-20 22:14:28.053842+00	3494
1	398	27	feature	Open-air; Close to the coast	\N	1	-398	\N	C	2019-12-20 22:14:28.053842+00	3495
1	397	27	feature	Open-air; Inland	\N	1	-397	\N	C	2019-12-20 22:14:28.053842+00	3496
1	396	27	feature	Open-air; Inland	\N	1	-396	\N	C	2019-12-20 22:14:28.053842+00	3497
1	395	27	feature	Open-air; Inland	\N	1	-395	\N	C	2019-12-20 22:14:28.053842+00	3498
1	394	27	feature	Open-air; Inland	\N	1	-394	\N	C	2019-12-20 22:14:28.053842+00	3499
1	393	27	feature	Open-air; Inland	\N	1	-393	\N	C	2019-12-20 22:14:28.053842+00	3500
1	392	27	feature	Open-air; Inland	\N	1	-392	\N	C	2019-12-20 22:14:28.053842+00	3501
1	391	27	feature	Open-air; Inland	\N	1	-391	\N	C	2019-12-20 22:14:28.053842+00	3502
1	390	27	feature	Open-air; Inland	\N	1	-390	\N	C	2019-12-20 22:14:28.053842+00	3503
1	389	27	feature	Open-air; Inland	\N	1	-389	\N	C	2019-12-20 22:14:28.053842+00	3504
1	388	27	feature	Open-air; Inland	\N	1	-388	\N	C	2019-12-20 22:14:28.053842+00	3505
1	387	27	feature	Open-air; Inland	\N	1	-387	\N	C	2019-12-20 22:14:28.053842+00	3506
1	386	27	feature	Open-air; Inland	\N	1	-386	\N	C	2019-12-20 22:14:28.053842+00	3507
1	385	27	feature	Open-air; Inland	\N	1	-385	\N	C	2019-12-20 22:14:28.053842+00	3508
1	384	27	feature	Open-air; Inland	\N	1	-384	\N	C	2019-12-20 22:14:28.053842+00	3509
1	383	27	feature	Open-air; Inland	\N	1	-383	\N	C	2019-12-20 22:14:28.053842+00	3510
1	382	27	feature	Open-air; Inland	\N	1	-382	\N	C	2019-12-20 22:14:28.053842+00	3511
1	381	27	feature	Open-air; Inland	\N	1	-381	\N	C	2019-12-20 22:14:28.053842+00	3512
1	380	27	feature	Open-air; Inland	\N	1	-380	\N	C	2019-12-20 22:14:28.053842+00	3513
1	379	27	feature	Open-air; Inland	\N	1	-379	\N	C	2019-12-20 22:14:28.053842+00	3514
1	378	27	feature	Open-air; Inland	\N	1	-378	\N	C	2019-12-20 22:14:28.053842+00	3515
1	377	27	feature	Open-air; Inland	\N	1	-377	\N	C	2019-12-20 22:14:28.053842+00	3516
1	376	27	feature	Open-air; Inland	\N	1	-376	\N	C	2019-12-20 22:14:28.053842+00	3517
1	375	27	feature	Open-air; Inland	\N	1	-375	\N	C	2019-12-20 22:14:28.053842+00	3518
1	374	27	feature	Open-air; Inland	\N	1	-374	\N	C	2019-12-20 22:14:28.053842+00	3519
1	373	27	feature	Open-air; Inland	\N	1	-373	\N	C	2019-12-20 22:14:28.053842+00	3520
1	372	27	feature	Open-air; Inland	\N	1	-372	\N	C	2019-12-20 22:14:28.053842+00	3521
1	371	27	feature	Open-air; Inland	\N	1	-371	\N	C	2019-12-20 22:14:28.053842+00	3522
1	370	27	feature	Open-air; Inland	\N	1	-370	\N	C	2019-12-20 22:14:28.053842+00	3523
1	369	27	feature	Open-air; Inland	\N	1	-369	\N	C	2019-12-20 22:14:28.053842+00	3524
1	368	27	feature	Open-air; Inland	\N	1	-368	\N	C	2019-12-20 22:14:28.053842+00	3525
1	367	27	feature	Open-air; Inland	\N	1	-367	\N	C	2019-12-20 22:14:28.053842+00	3526
1	366	27	feature	Open-air; Inland	\N	1	-366	\N	C	2019-12-20 22:14:28.053842+00	3527
1	365	27	feature	Open-air; Inland	\N	1	-365	\N	C	2019-12-20 22:14:28.053842+00	3528
1	364	27	feature	Open-air; Inland	\N	1	-364	\N	C	2019-12-20 22:14:28.053842+00	3529
1	363	27	feature	Open-air; Inland	\N	1	-363	\N	C	2019-12-20 22:14:28.053842+00	3530
1	362	27	feature	Open-air; Inland	\N	1	-362	\N	C	2019-12-20 22:14:28.053842+00	3531
1	361	27	feature	Open-air; Inland	\N	1	-361	\N	C	2019-12-20 22:14:28.053842+00	3532
1	360	27	feature	Open-air; Inland	\N	1	-360	\N	C	2019-12-20 22:14:28.053842+00	3533
1	359	27	feature	Open-air; Inland	\N	1	-359	\N	C	2019-12-20 22:14:28.053842+00	3534
1	358	27	feature	Open-air; Inland	\N	1	-358	\N	C	2019-12-20 22:14:28.053842+00	3535
1	357	12	feature	Shell midden; Lake shore	\N	1	-357	\N	C	2019-12-20 22:14:28.053842+00	3536
1	356	12	feature	Shell midden; Lake shore	\N	1	-356	\N	C	2019-12-20 22:14:28.053842+00	3537
1	355	12	feature	Shell midden; Lake shore	\N	1	-355	\N	C	2019-12-20 22:14:28.053842+00	3538
1	354	12	feature	Shell midden; Lake shore	\N	1	-354	\N	C	2019-12-20 22:14:28.053842+00	3539
1	353	12	feature	Shell midden; Lake shore	\N	1	-353	\N	C	2019-12-20 22:14:28.053842+00	3540
1	352	12	feature	Shell midden; Lake shore	\N	1	-352	\N	C	2019-12-20 22:14:28.053842+00	3541
1	351	12	feature	Shell midden; Lake shore	\N	1	-351	\N	C	2019-12-20 22:14:28.053842+00	3542
1	350	12	feature	Shell midden; Lake shore	\N	1	-350	\N	C	2019-12-20 22:14:28.053842+00	3543
1	349	12	feature	Shell midden; Lake shore	\N	1	-349	\N	C	2019-12-20 22:14:28.053842+00	3544
1	348	12	feature	Shell midden; Lake shore	\N	1	-348	\N	C	2019-12-20 22:14:28.053842+00	3545
1	347	27	feature	Open-air; Close to the coast	\N	1	-347	\N	C	2019-12-20 22:14:28.053842+00	3546
1	346	27	feature	Open-air; Close to the coast	\N	1	-346	\N	C	2019-12-20 22:14:28.053842+00	3547
1	345	27	feature	Open-air; Close to the coast	\N	1	-345	\N	C	2019-12-20 22:14:28.053842+00	3548
1	344	27	feature	Open-air; Close to the coast	\N	1	-344	\N	C	2019-12-20 22:14:28.053842+00	3549
1	343	27	feature	Open-air; Close to the coast	\N	1	-343	\N	C	2019-12-20 22:14:28.053842+00	3550
1	342	27	feature	Open-air; Inland	\N	1	-342	\N	C	2019-12-20 22:14:28.053842+00	3551
1	341	27	feature	Open-air; Inland	\N	1	-341	\N	C	2019-12-20 22:14:28.053842+00	3552
1	340	27	feature	Open-air; Inland	\N	1	-340	\N	C	2019-12-20 22:14:28.053842+00	3553
1	339	27	feature	Open-air; Inland	\N	1	-339	\N	C	2019-12-20 22:14:28.053842+00	3554
1	338	27	feature	Open-air; Inland	\N	1	-338	\N	C	2019-12-20 22:14:28.053842+00	3555
1	337	27	feature	Open-air; Inland	\N	1	-337	\N	C	2019-12-20 22:14:28.053842+00	3556
1	336	27	feature	Open-air; Inland	\N	1	-336	\N	C	2019-12-20 22:14:28.053842+00	3557
1	335	27	feature	Open-air; Inland	\N	1	-335	\N	C	2019-12-20 22:14:28.053842+00	3558
1	334	27	feature	Open-air; Inland	\N	1	-334	\N	C	2019-12-20 22:14:28.053842+00	3559
1	333	27	feature	Open-air; Inland	\N	1	-333	\N	C	2019-12-20 22:14:28.053842+00	3560
1	332	27	feature	Open-air; Inland	\N	1	-332	\N	C	2019-12-20 22:14:28.053842+00	3561
1	331	27	feature	Open-air; Inland	\N	1	-331	\N	C	2019-12-20 22:14:28.053842+00	3562
1	330	27	feature	Open-air; Inland	\N	1	-330	\N	C	2019-12-20 22:14:28.053842+00	3563
1	329	27	feature	Open-air; Inland	\N	1	-329	\N	C	2019-12-20 22:14:28.053842+00	3564
1	328	27	feature	Open-air; Inland	\N	1	-328	\N	C	2019-12-20 22:14:28.053842+00	3565
1	327	27	feature	Open-air; Inland	\N	1	-327	\N	C	2019-12-20 22:14:28.053842+00	3566
1	326	27	feature	Open-air; Inland	\N	1	-326	\N	C	2019-12-20 22:14:28.053842+00	3567
1	325	27	feature	Open-air; Inland	\N	1	-325	\N	C	2019-12-20 22:14:28.053842+00	3568
1	324	27	feature	Open-air; Inland	\N	1	-324	\N	C	2019-12-20 22:14:28.053842+00	3569
1	323	27	feature	Open-air; Inland	\N	1	-323	\N	C	2019-12-20 22:14:28.053842+00	3570
1	322	27	feature	Open-air; Inland	\N	1	-322	\N	C	2019-12-20 22:14:28.053842+00	3571
1	321	27	feature	Open-air; Inland	\N	1	-321	\N	C	2019-12-20 22:14:28.053842+00	3572
1	320	27	feature	Open-air; Inland	\N	1	-320	\N	C	2019-12-20 22:14:28.053842+00	3573
1	319	27	feature	Open-air; Inland	\N	1	-319	\N	C	2019-12-20 22:14:28.053842+00	3574
1	318	27	feature	Open-air; Inland	\N	1	-318	\N	C	2019-12-20 22:14:28.053842+00	3575
1	317	27	feature	Open-air; Inland	\N	1	-317	\N	C	2019-12-20 22:14:28.053842+00	3576
1	316	27	feature	Open-air; Inland	\N	1	-316	\N	C	2019-12-20 22:14:28.053842+00	3577
1	315	27	feature	Open-air; Inland	\N	1	-315	\N	C	2019-12-20 22:14:28.053842+00	3578
1	314	27	feature	Open-air; Inland	\N	1	-314	\N	C	2019-12-20 22:14:28.053842+00	3579
1	313	27	feature	Open-air; Inland	\N	1	-313	\N	C	2019-12-20 22:14:28.053842+00	3580
1	312	27	feature	Open-air; Inland	\N	1	-312	\N	C	2019-12-20 22:14:28.053842+00	3581
1	311	27	feature	Open-air; Inland	\N	1	-311	\N	C	2019-12-20 22:14:28.053842+00	3582
1	310	27	feature	Open-air; Inland	\N	1	-310	\N	C	2019-12-20 22:14:28.053842+00	3583
1	309	27	feature	Open-air; Inland	\N	1	-309	\N	C	2019-12-20 22:14:28.053842+00	3584
1	308	27	feature	Open-air; Inland	\N	1	-308	\N	C	2019-12-20 22:14:28.053842+00	3585
1	307	27	feature	Open-air; Inland	\N	1	-307	\N	C	2019-12-20 22:14:28.053842+00	3586
1	306	27	feature	Open-air; Inland	\N	1	-306	\N	C	2019-12-20 22:14:28.053842+00	3587
1	305	27	feature	Open-air; Inland	\N	1	-305	\N	C	2019-12-20 22:14:28.053842+00	3588
1	304	27	feature	Open-air; Inland	\N	1	-304	\N	C	2019-12-20 22:14:28.053842+00	3589
1	303	27	feature	Open-air; Inland	\N	1	-303	\N	C	2019-12-20 22:14:28.053842+00	3590
1	302	27	feature	Open-air; Inland	\N	1	-302	\N	C	2019-12-20 22:14:28.053842+00	3591
1	301	27	feature	Open-air; Inland	\N	1	-301	\N	C	2019-12-20 22:14:28.053842+00	3592
1	300	27	feature	Open-air; Inland	\N	1	-300	\N	C	2019-12-20 22:14:28.053842+00	3593
1	299	27	feature	Open-air; Inland	\N	1	-299	\N	C	2019-12-20 22:14:28.053842+00	3594
1	298	27	feature	Open-air; Inland	\N	1	-298	\N	C	2019-12-20 22:14:28.053842+00	3595
1	297	27	feature	Open-air; Inland	\N	1	-297	\N	C	2019-12-20 22:14:28.053842+00	3596
1	296	27	feature	Open-air; Inland	\N	1	-296	\N	C	2019-12-20 22:14:28.053842+00	3597
1	295	27	feature	Open-air; Inland	\N	1	-295	\N	C	2019-12-20 22:14:28.053842+00	3598
1	294	27	feature	Open-air; Inland	\N	1	-294	\N	C	2019-12-20 22:14:28.053842+00	3599
1	293	27	feature	Open-air; Inland	\N	1	-293	\N	C	2019-12-20 22:14:28.053842+00	3600
1	292	27	feature	Open-air; Inland	\N	1	-292	\N	C	2019-12-20 22:14:28.053842+00	3601
1	291	27	feature	Open-air; Inland	\N	1	-291	\N	C	2019-12-20 22:14:28.053842+00	3602
1	290	27	feature	Open-air; Inland	\N	1	-290	\N	C	2019-12-20 22:14:28.053842+00	3603
1	289	27	feature	Open-air; Inland	\N	1	-289	\N	C	2019-12-20 22:14:28.053842+00	3604
1	288	27	feature	Open-air; Inland	\N	1	-288	\N	C	2019-12-20 22:14:28.053842+00	3605
1	287	27	feature	Open-air; Inland	\N	1	-287	\N	C	2019-12-20 22:14:28.053842+00	3606
1	286	27	feature	Open-air; Inland	\N	1	-286	\N	C	2019-12-20 22:14:28.053842+00	3607
1	285	27	feature	Open-air; Inland	\N	1	-285	\N	C	2019-12-20 22:14:28.053842+00	3608
1	284	27	feature	Open-air; Inland	\N	1	-284	\N	C	2019-12-20 22:14:28.053842+00	3609
1	283	27	feature	Open-air; Inland	\N	1	-283	\N	C	2019-12-20 22:14:28.053842+00	3610
1	282	27	feature	Open-air; Inland	\N	1	-282	\N	C	2019-12-20 22:14:28.053842+00	3611
1	281	27	feature	Open-air; Inland	\N	1	-281	\N	C	2019-12-20 22:14:28.053842+00	3612
1	280	27	feature	Open-air; Inland	\N	1	-280	\N	C	2019-12-20 22:14:28.053842+00	3613
1	279	27	feature	Open-air; Inland	\N	1	-279	\N	C	2019-12-20 22:14:28.053842+00	3614
1	278	27	feature	Open-air; Inland	\N	1	-278	\N	C	2019-12-20 22:14:28.053842+00	3615
1	277	27	feature	Open-air; Inland	\N	1	-277	\N	C	2019-12-20 22:14:28.053842+00	3616
1	276	27	feature	Open-air; Inland	\N	1	-276	\N	C	2019-12-20 22:14:28.053842+00	3617
1	275	27	feature	Open-air; Inland	\N	1	-275	\N	C	2019-12-20 22:14:28.053842+00	3618
1	274	27	feature	Open-air; Inland	\N	1	-274	\N	C	2019-12-20 22:14:28.053842+00	3619
1	273	27	feature	Open-air; Inland	\N	1	-273	\N	C	2019-12-20 22:14:28.053842+00	3620
1	272	27	feature	Open-air; Inland	\N	1	-272	\N	C	2019-12-20 22:14:28.053842+00	3621
1	271	27	feature	Open-air; Inland	\N	1	-271	\N	C	2019-12-20 22:14:28.053842+00	3622
1	270	27	feature	Open-air; Inland	\N	1	-270	\N	C	2019-12-20 22:14:28.053842+00	3623
1	269	27	feature	Open-air; Inland	\N	1	-269	\N	C	2019-12-20 22:14:28.053842+00	3624
1	268	27	feature	Open-air; Inland	\N	1	-268	\N	C	2019-12-20 22:14:28.053842+00	3625
1	267	27	feature	Open-air; Inland	\N	1	-267	\N	C	2019-12-20 22:14:28.053842+00	3626
1	266	27	feature	Open-air; Inland	\N	1	-266	\N	C	2019-12-20 22:14:28.053842+00	3627
1	265	27	feature	Open-air; Inland	\N	1	-265	\N	C	2019-12-20 22:14:28.053842+00	3628
1	264	27	feature	Open-air; Inland	\N	1	-264	\N	C	2019-12-20 22:14:28.053842+00	3629
1	263	27	feature	Open-air; Inland	\N	1	-263	\N	C	2019-12-20 22:14:28.053842+00	3630
1	262	27	feature	Open-air; Inland	\N	1	-262	\N	C	2019-12-20 22:14:28.053842+00	3631
1	261	27	feature	Open-air; Inland	\N	1	-261	\N	C	2019-12-20 22:14:28.053842+00	3632
1	260	27	feature	Open-air; Inland	\N	1	-260	\N	C	2019-12-20 22:14:28.053842+00	3633
1	259	27	feature	Open-air; Inland	\N	1	-259	\N	C	2019-12-20 22:14:28.053842+00	3634
1	258	27	feature	Open-air; Inland	\N	1	-258	\N	C	2019-12-20 22:14:28.053842+00	3635
1	257	27	feature	Open-air; Inland	\N	1	-257	\N	C	2019-12-20 22:14:28.053842+00	3636
1	256	27	feature	Open-air; Inland	\N	1	-256	\N	C	2019-12-20 22:14:28.053842+00	3637
1	255	27	feature	Open-air; Inland	\N	1	-255	\N	C	2019-12-20 22:14:28.053842+00	3638
1	254	27	feature	Open-air; Inland	\N	1	-254	\N	C	2019-12-20 22:14:28.053842+00	3639
1	253	27	feature	Open-air; Inland	\N	1	-253	\N	C	2019-12-20 22:14:28.053842+00	3640
1	252	27	feature	Open-air; Inland	\N	1	-252	\N	C	2019-12-20 22:14:28.053842+00	3641
1	251	27	feature	Open-air; Inland	\N	1	-251	\N	C	2019-12-20 22:14:28.053842+00	3642
1	250	27	feature	Open-air; Inland	\N	1	-250	\N	C	2019-12-20 22:14:28.053842+00	3643
1	249	27	feature	Open-air; Inland	\N	1	-249	\N	C	2019-12-20 22:14:28.053842+00	3644
1	248	27	feature	Open-air; Inland	\N	1	-248	\N	C	2019-12-20 22:14:28.053842+00	3645
1	247	27	feature	Open-air; Inland	\N	1	-247	\N	C	2019-12-20 22:14:28.053842+00	3646
1	246	27	feature	Open-air; Inland	\N	1	-246	\N	C	2019-12-20 22:14:28.053842+00	3647
1	245	27	feature	Open-air; Inland	\N	1	-245	\N	C	2019-12-20 22:14:28.053842+00	3648
1	244	27	feature	Open-air; Inland	\N	1	-244	\N	C	2019-12-20 22:14:28.053842+00	3649
1	243	27	feature	Open-air; Inland	\N	1	-243	\N	C	2019-12-20 22:14:28.053842+00	3650
1	242	27	feature	Open-air; Inland	\N	1	-242	\N	C	2019-12-20 22:14:28.053842+00	3651
1	241	27	feature	Open-air; Inland	\N	1	-241	\N	C	2019-12-20 22:14:28.053842+00	3652
1	240	27	feature	Open-air; Inland	\N	1	-240	\N	C	2019-12-20 22:14:28.053842+00	3653
1	239	27	feature	Open-air; Inland	\N	1	-239	\N	C	2019-12-20 22:14:28.053842+00	3654
1	238	27	feature	Open-air; Mountainous	\N	1	-238	\N	C	2019-12-20 22:14:28.053842+00	3655
1	237	27	feature	Open-air; Mountainous	\N	1	-237	\N	C	2019-12-20 22:14:28.053842+00	3656
1	236	27	feature	Open-air; Mountainous	\N	1	-236	\N	C	2019-12-20 22:14:28.053842+00	3657
1	235	27	feature	Open-air; Mountainous	\N	1	-235	\N	C	2019-12-20 22:14:28.053842+00	3658
1	234	27	feature	Open-air; Mountainous	\N	1	-234	\N	C	2019-12-20 22:14:28.053842+00	3659
1	233	27	feature	Open-air; Mountainous	\N	1	-233	\N	C	2019-12-20 22:14:28.053842+00	3660
1	232	27	feature	Open-air; Mountainous	\N	1	-232	\N	C	2019-12-20 22:14:28.053842+00	3661
1	231	27	feature	Open-air; Mountainous	\N	1	-231	\N	C	2019-12-20 22:14:28.053842+00	3662
1	230	12	feature	Shell midden; Inland	\N	1	-230	\N	C	2019-12-20 22:14:28.053842+00	3663
1	229	12	feature	Shell midden; Inland	\N	1	-229	\N	C	2019-12-20 22:14:28.053842+00	3664
1	228	12	feature	Shell midden; Inland	\N	1	-228	\N	C	2019-12-20 22:14:28.053842+00	3665
1	227	12	feature	Shell midden; Inland	\N	1	-227	\N	C	2019-12-20 22:14:28.053842+00	3666
1	226	12	feature	Shell midden; Inland	\N	1	-226	\N	C	2019-12-20 22:14:28.053842+00	3667
1	225	12	feature	Shell midden; Inland	\N	1	-225	\N	C	2019-12-20 22:14:28.053842+00	3668
1	224	12	feature	Shell midden; Inland	\N	1	-224	\N	C	2019-12-20 22:14:28.053842+00	3669
1	223	12	feature	Shell midden; Inland	\N	1	-223	\N	C	2019-12-20 22:14:28.053842+00	3670
1	222	12	feature	Shell midden; Inland	\N	1	-222	\N	C	2019-12-20 22:14:28.053842+00	3671
1	221	12	feature	Shell midden; Inland	\N	1	-221	\N	C	2019-12-20 22:14:28.053842+00	3672
1	220	12	feature	Shell midden; Inland	\N	1	-220	\N	C	2019-12-20 22:14:28.053842+00	3673
1	219	12	feature	Shell midden; Inland	\N	1	-219	\N	C	2019-12-20 22:14:28.053842+00	3674
1	218	12	feature	Shell midden; Inland	\N	1	-218	\N	C	2019-12-20 22:14:28.053842+00	3675
1	217	12	feature	Shell midden; Inland	\N	1	-217	\N	C	2019-12-20 22:14:28.053842+00	3676
1	216	12	feature	Shell midden; Inland	\N	1	-216	\N	C	2019-12-20 22:14:28.053842+00	3677
1	215	12	feature	Shell midden; Inland	\N	1	-215	\N	C	2019-12-20 22:14:28.053842+00	3678
1	214	12	feature	Shell midden; Inland	\N	1	-214	\N	C	2019-12-20 22:14:28.053842+00	3679
1	213	12	feature	Shell midden; Inland	\N	1	-213	\N	C	2019-12-20 22:14:28.053842+00	3680
1	212	12	feature	Shell midden; Inland	\N	1	-212	\N	C	2019-12-20 22:14:28.053842+00	3681
1	211	12	feature	Shell midden; Inland	\N	1	-211	\N	C	2019-12-20 22:14:28.053842+00	3682
1	210	12	feature	Shell midden; Inland	\N	1	-210	\N	C	2019-12-20 22:14:28.053842+00	3683
1	209	12	feature	Shell midden; Inland	\N	1	-209	\N	C	2019-12-20 22:14:28.053842+00	3684
1	208	12	feature	Shell midden; Inland	\N	1	-208	\N	C	2019-12-20 22:14:28.053842+00	3685
1	207	12	feature	Shell midden; Inland	\N	1	-207	\N	C	2019-12-20 22:14:28.053842+00	3686
1	206	12	feature	Shell midden; Inland	\N	1	-206	\N	C	2019-12-20 22:14:28.053842+00	3687
1	205	12	feature	Shell midden; Inland	\N	1	-205	\N	C	2019-12-20 22:14:28.053842+00	3688
1	204	12	feature	Shell midden; Inland	\N	1	-204	\N	C	2019-12-20 22:14:28.053842+00	3689
1	203	12	feature	Shell midden; Inland	\N	1	-203	\N	C	2019-12-20 22:14:28.053842+00	3690
1	202	12	feature	Shell midden; Inland	\N	1	-202	\N	C	2019-12-20 22:14:28.053842+00	3691
1	201	12	feature	Shell midden; Inland	\N	1	-201	\N	C	2019-12-20 22:14:28.053842+00	3692
1	200	12	feature	Shell midden; Inland	\N	1	-200	\N	C	2019-12-20 22:14:28.053842+00	3693
1	199	12	feature	Shell midden; Inland	\N	1	-199	\N	C	2019-12-20 22:14:28.053842+00	3694
1	198	12	feature	Shell midden; Inland	\N	1	-198	\N	C	2019-12-20 22:14:28.053842+00	3695
1	197	12	feature	Shell midden; Inland	\N	1	-197	\N	C	2019-12-20 22:14:28.053842+00	3696
1	196	34	feature	Rock shelter/Cave; Mountainous	\N	1	-196	\N	C	2019-12-20 22:14:28.053842+00	3697
1	195	34	feature	Rock shelter/Cave; Mountainous	\N	1	-195	\N	C	2019-12-20 22:14:28.053842+00	3698
1	194	34	feature	Rock shelter/Cave; Mountainous	\N	1	-194	\N	C	2019-12-20 22:14:28.053842+00	3699
1	193	34	feature	Rock shelter/Cave; Mountainous	\N	1	-193	\N	C	2019-12-20 22:14:28.053842+00	3700
1	192	34	feature	Rock shelter/Cave; Mountainous	\N	1	-192	\N	C	2019-12-20 22:14:28.053842+00	3701
1	191	34	feature	Rock shelter/Cave; Mountainous	\N	1	-191	\N	C	2019-12-20 22:14:28.053842+00	3702
1	190	34	feature	Rock shelter/Cave; Mountainous	\N	1	-190	\N	C	2019-12-20 22:14:28.053842+00	3703
1	189	34	feature	Rock shelter/Cave; Mountainous	\N	1	-189	\N	C	2019-12-20 22:14:28.053842+00	3704
1	188	34	feature	Rock shelter/Cave; Mountainous	\N	1	-188	\N	C	2019-12-20 22:14:28.053842+00	3705
1	187	34	feature	Rock shelter/Cave; Mountainous	\N	1	-187	\N	C	2019-12-20 22:14:28.053842+00	3706
1	186	34	feature	Rock shelter/Cave; Mountainous	\N	1	-186	\N	C	2019-12-20 22:14:28.053842+00	3707
1	185	34	feature	Rock shelter/Cave; Mountainous	\N	1	-185	\N	C	2019-12-20 22:14:28.053842+00	3708
1	184	34	feature	Rock shelter/Cave; Mountainous	\N	1	-184	\N	C	2019-12-20 22:14:28.053842+00	3709
1	183	34	feature	Rock shelter/Cave; Mountainous	\N	1	-183	\N	C	2019-12-20 22:14:28.053842+00	3710
1	182	34	feature	Rock shelter/Cave; Mountainous	\N	1	-182	\N	C	2019-12-20 22:14:28.053842+00	3711
1	181	34	feature	Rock shelter/Cave; Inland	\N	1	-181	\N	C	2019-12-20 22:14:28.053842+00	3712
1	180	34	feature	Rock shelter/Cave; Inland	\N	1	-180	\N	C	2019-12-20 22:14:28.053842+00	3713
1	179	34	feature	Rock shelter/Cave; Inland	\N	1	-179	\N	C	2019-12-20 22:14:28.053842+00	3714
1	178	34	feature	Rock shelter/Cave; Inland	\N	1	-178	\N	C	2019-12-20 22:14:28.053842+00	3715
1	177	34	feature	Rock shelter/Cave; Inland	\N	1	-177	\N	C	2019-12-20 22:14:28.053842+00	3716
1	176	34	feature	Rock shelter/Cave; Inland	\N	1	-176	\N	C	2019-12-20 22:14:28.053842+00	3717
1	175	34	feature	Rock shelter/Cave; Inland	\N	1	-175	\N	C	2019-12-20 22:14:28.053842+00	3718
1	174	12	feature	Shell midden; Inland	\N	1	-174	\N	C	2019-12-20 22:14:28.053842+00	3719
1	173	12	feature	Shell midden; Inland	\N	1	-173	\N	C	2019-12-20 22:14:28.053842+00	3720
1	172	12	feature	Shell midden; Inland	\N	1	-172	\N	C	2019-12-20 22:14:28.053842+00	3721
1	171	12	feature	Shell midden; Inland	\N	1	-171	\N	C	2019-12-20 22:14:28.053842+00	3722
1	170	12	feature	Shell midden; Inland	\N	1	-170	\N	C	2019-12-20 22:14:28.053842+00	3723
1	169	12	feature	Shell midden; Inland	\N	1	-169	\N	C	2019-12-20 22:14:28.053842+00	3724
1	168	12	feature	Shell midden; Inland	\N	1	-168	\N	C	2019-12-20 22:14:28.053842+00	3725
1	167	12	feature	Shell midden; Inland	\N	1	-167	\N	C	2019-12-20 22:14:28.053842+00	3726
1	166	12	feature	Shell midden; Inland	\N	1	-166	\N	C	2019-12-20 22:14:28.053842+00	3727
1	165	12	feature	Shell midden; Inland	\N	1	-165	\N	C	2019-12-20 22:14:28.053842+00	3728
1	164	12	feature	Shell midden; Inland	\N	1	-164	\N	C	2019-12-20 22:14:28.053842+00	3729
1	163	12	feature	Shell midden; Inland	\N	1	-163	\N	C	2019-12-20 22:14:28.053842+00	3730
1	162	12	feature	Shell midden; Inland	\N	1	-162	\N	C	2019-12-20 22:14:28.053842+00	3731
1	161	34	feature	Rock shelter/Cave; Mountainous	\N	1	-161	\N	C	2019-12-20 22:14:28.053842+00	3732
1	160	34	feature	Rock shelter/Cave; Mountainous	\N	1	-160	\N	C	2019-12-20 22:14:28.053842+00	3733
1	159	34	feature	Rock shelter/Cave; Mountainous	\N	1	-159	\N	C	2019-12-20 22:14:28.053842+00	3734
1	158	34	feature	Rock shelter/Cave; Mountainous	\N	1	-158	\N	C	2019-12-20 22:14:28.053842+00	3735
1	157	34	feature	Rock shelter/Cave; Mountainous	\N	1	-157	\N	C	2019-12-20 22:14:28.053842+00	3736
1	156	34	feature	Rock shelter/Cave; Mountainous	\N	1	-156	\N	C	2019-12-20 22:14:28.053842+00	3737
1	155	34	feature	Rock shelter/Cave; Mountainous	\N	1	-155	\N	C	2019-12-20 22:14:28.053842+00	3738
1	154	34	feature	Rock shelter/Cave; Mountainous	\N	1	-154	\N	C	2019-12-20 22:14:28.053842+00	3739
1	153	34	feature	Rock shelter/Cave; Mountainous	\N	1	-153	\N	C	2019-12-20 22:14:28.053842+00	3740
1	152	34	feature	Rock shelter/Cave; Mountainous	\N	1	-152	\N	C	2019-12-20 22:14:28.053842+00	3741
1	151	34	feature	Rock shelter/Cave; Mountainous	\N	1	-151	\N	C	2019-12-20 22:14:28.053842+00	3742
1	150	34	feature	Rock shelter/Cave; Mountainous	\N	1	-150	\N	C	2019-12-20 22:14:28.053842+00	3743
1	149	34	feature	Rock shelter/Cave; Mountainous	\N	1	-149	\N	C	2019-12-20 22:14:28.053842+00	3744
1	148	34	feature	Rock shelter/Cave; Mountainous	\N	1	-148	\N	C	2019-12-20 22:14:28.053842+00	3745
1	147	34	feature	Rock shelter/Cave; Mountainous	\N	1	-147	\N	C	2019-12-20 22:14:28.053842+00	3746
1	146	34	feature	Rock shelter/Cave; Mountainous	\N	1	-146	\N	C	2019-12-20 22:14:28.053842+00	3747
1	145	34	feature	Rock shelter/Cave; Mountainous	\N	1	-145	\N	C	2019-12-20 22:14:28.053842+00	3748
1	144	34	feature	Rock shelter/Cave; Mountainous	\N	1	-144	\N	C	2019-12-20 22:14:28.053842+00	3749
1	143	34	feature	Rock shelter/Cave; Mountainous	\N	1	-143	\N	C	2019-12-20 22:14:28.053842+00	3750
1	142	34	feature	Rock shelter/Cave; Mountainous	\N	1	-142	\N	C	2019-12-20 22:14:28.053842+00	3751
1	141	34	feature	Rock shelter/Cave; Mountainous	\N	1	-141	\N	C	2019-12-20 22:14:28.053842+00	3752
1	140	34	feature	Rock shelter/Cave; Mountainous	\N	1	-140	\N	C	2019-12-20 22:14:28.053842+00	3753
1	139	34	feature	Rock shelter/Cave; Mountainous	\N	1	-139	\N	C	2019-12-20 22:14:28.053842+00	3754
1	138	34	feature	Rock shelter/Cave; Mountainous	\N	1	-138	\N	C	2019-12-20 22:14:28.053842+00	3755
1	137	34	feature	Rock shelter/Cave; Mountainous	\N	1	-137	\N	C	2019-12-20 22:14:28.053842+00	3756
1	136	34	feature	Rock shelter/Cave; Mountainous	\N	1	-136	\N	C	2019-12-20 22:14:28.053842+00	3757
1	135	34	feature	Rock shelter/Cave; Mountainous	\N	1	-135	\N	C	2019-12-20 22:14:28.053842+00	3758
1	134	34	feature	Rock shelter/Cave; Mountainous	\N	1	-134	\N	C	2019-12-20 22:14:28.053842+00	3759
1	133	34	feature	Rock shelter/Cave; Mountainous	\N	1	-133	\N	C	2019-12-20 22:14:28.053842+00	3760
1	132	34	feature	Rock shelter/Cave; Mountainous	\N	1	-132	\N	C	2019-12-20 22:14:28.053842+00	3761
1	131	34	feature	Rock shelter/Cave; Mountainous	\N	1	-131	\N	C	2019-12-20 22:14:28.053842+00	3762
1	130	34	feature	Rock shelter/Cave; Mountainous	\N	1	-130	\N	C	2019-12-20 22:14:28.053842+00	3763
1	129	34	feature	Rock shelter/Cave; Mountainous	\N	1	-129	\N	C	2019-12-20 22:14:28.053842+00	3764
1	128	34	feature	Rock shelter/Cave; Mountainous	\N	1	-128	\N	C	2019-12-20 22:14:28.053842+00	3765
1	127	34	feature	Rock shelter/Cave; Mountainous	\N	1	-127	\N	C	2019-12-20 22:14:28.053842+00	3766
1	126	34	feature	Rock shelter/Cave; Mountainous	\N	1	-126	\N	C	2019-12-20 22:14:28.053842+00	3767
1	125	34	feature	Rock shelter/Cave; Mountainous	\N	1	-125	\N	C	2019-12-20 22:14:28.053842+00	3768
1	124	34	feature	Rock shelter/Cave; Mountainous	\N	1	-124	\N	C	2019-12-20 22:14:28.053842+00	3769
1	123	34	feature	Rock shelter/Cave; Mountainous	\N	1	-123	\N	C	2019-12-20 22:14:28.053842+00	3770
1	122	34	feature	Rock shelter/Cave; Mountainous	\N	1	-122	\N	C	2019-12-20 22:14:28.053842+00	3771
1	121	34	feature	Rock shelter/Cave; Mountainous	\N	1	-121	\N	C	2019-12-20 22:14:28.053842+00	3772
1	120	34	feature	Rock shelter/Cave; Mountainous	\N	1	-120	\N	C	2019-12-20 22:14:28.053842+00	3773
1	119	34	feature	Rock shelter/Cave; Mountainous	\N	1	-119	\N	C	2019-12-20 22:14:28.053842+00	3774
1	118	34	feature	Rock shelter/Cave; Mountainous	\N	1	-118	\N	C	2019-12-20 22:14:28.053842+00	3775
1	117	27	feature	Open-air; Close to the coast	\N	1	-117	\N	C	2019-12-20 22:14:28.053842+00	3776
1	116	27	feature	Open-air; Close to the coast	\N	1	-116	\N	C	2019-12-20 22:14:28.053842+00	3777
1	115	27	feature	Open-air; Close to the coast	\N	1	-115	\N	C	2019-12-20 22:14:28.053842+00	3778
1	114	27	feature	Open-air; Close to the coast	\N	1	-114	\N	C	2019-12-20 22:14:28.053842+00	3779
1	113	27	feature	Open-air; Close to the coast	\N	1	-113	\N	C	2019-12-20 22:14:28.053842+00	3780
1	112	27	feature	Open-air; Close to the coast	\N	1	-112	\N	C	2019-12-20 22:14:28.053842+00	3781
1	111	27	feature	Open-air; Close to the coast	\N	1	-111	\N	C	2019-12-20 22:14:28.053842+00	3782
1	110	27	feature	Open-air; Close to the coast	\N	1	-110	\N	C	2019-12-20 22:14:28.053842+00	3783
1	109	27	feature	Open-air; Close to the coast	\N	1	-109	\N	C	2019-12-20 22:14:28.053842+00	3784
1	108	27	feature	Open-air; Close to the coast	\N	1	-108	\N	C	2019-12-20 22:14:28.053842+00	3785
1	107	27	feature	Open-air; Close to the coast	\N	1	-107	\N	C	2019-12-20 22:14:28.053842+00	3786
1	106	27	feature	Open-air; Close to the coast	\N	1	-106	\N	C	2019-12-20 22:14:28.053842+00	3787
1	105	27	feature	Open-air; Close to the coast	\N	1	-105	\N	C	2019-12-20 22:14:28.053842+00	3788
1	104	27	feature	Open-air; Close to the coast	\N	1	-104	\N	C	2019-12-20 22:14:28.053842+00	3789
1	103	27	feature	Open-air; Close to the coast	\N	1	-103	\N	C	2019-12-20 22:14:28.053842+00	3790
1	102	27	feature	Open-air; Close to the coast	\N	1	-102	\N	C	2019-12-20 22:14:28.053842+00	3791
1	101	27	feature	Open-air; Close to the coast	\N	1	-101	\N	C	2019-12-20 22:14:28.053842+00	3792
1	100	27	feature	Open-air; Close to the coast	\N	1	-100	\N	C	2019-12-20 22:14:28.053842+00	3793
1	99	27	feature	Open-air; Close to the coast	\N	1	-99	\N	C	2019-12-20 22:14:28.053842+00	3794
1	98	27	feature	Open-air; Close to the coast	\N	1	-98	\N	C	2019-12-20 22:14:28.053842+00	3795
1	97	27	feature	Open-air; Close to the coast	\N	1	-97	\N	C	2019-12-20 22:14:28.053842+00	3796
1	96	27	feature	Open-air; Close to the coast	\N	1	-96	\N	C	2019-12-20 22:14:28.053842+00	3797
1	95	27	feature	Open-air; Close to the coast	\N	1	-95	\N	C	2019-12-20 22:14:28.053842+00	3798
1	94	27	feature	Open-air; Close to the coast	\N	1	-94	\N	C	2019-12-20 22:14:28.053842+00	3799
1	93	27	feature	Open-air; Close to the coast	\N	1	-93	\N	C	2019-12-20 22:14:28.053842+00	3800
1	92	27	feature	Open-air; Close to the coast	\N	1	-92	\N	C	2019-12-20 22:14:28.053842+00	3801
1	91	27	feature	Open-air; Close to the coast	\N	1	-91	\N	C	2019-12-20 22:14:28.053842+00	3802
1	90	27	feature	Open-air; Close to the coast	\N	1	-90	\N	C	2019-12-20 22:14:28.053842+00	3803
1	89	27	feature	Open-air; Close to the coast	\N	1	-89	\N	C	2019-12-20 22:14:28.053842+00	3804
1	88	27	feature	Open-air; Close to the coast	\N	1	-88	\N	C	2019-12-20 22:14:28.053842+00	3805
1	87	27	feature	Open-air; Close to the coast	\N	1	-87	\N	C	2019-12-20 22:14:28.053842+00	3806
1	86	27	feature	Open-air; Close to the coast	\N	1	-86	\N	C	2019-12-20 22:14:28.053842+00	3807
1	85	27	feature	Open-air; Close to the coast	\N	1	-85	\N	C	2019-12-20 22:14:28.053842+00	3808
1	84	27	feature	Open-air; Close to the coast	\N	1	-84	\N	C	2019-12-20 22:14:28.053842+00	3809
1	83	27	feature	Open-air; Close to the coast	\N	1	-83	\N	C	2019-12-20 22:14:28.053842+00	3810
1	82	27	feature	Open-air; Close to the coast	\N	1	-82	\N	C	2019-12-20 22:14:28.053842+00	3811
1	81	27	feature	Open-air; Close to the coast	\N	1	-81	\N	C	2019-12-20 22:14:28.053842+00	3812
1	80	27	feature	Open-air; Close to the coast	\N	1	-80	\N	C	2019-12-20 22:14:28.053842+00	3813
1	79	27	feature	Open-air; Close to the coast	\N	1	-79	\N	C	2019-12-20 22:14:28.053842+00	3814
1	78	27	feature	Open-air; Close to the coast	\N	1	-78	\N	C	2019-12-20 22:14:28.053842+00	3815
1	77	27	feature	Open-air; Close to the coast	\N	1	-77	\N	C	2019-12-20 22:14:28.053842+00	3816
1	76	27	feature	Open-air; Close to the coast	\N	1	-76	\N	C	2019-12-20 22:14:28.053842+00	3817
1	75	27	feature	Open-air; Close to the coast	\N	1	-75	\N	C	2019-12-20 22:14:28.053842+00	3818
1	74	27	feature	Open-air; Close to the coast	\N	1	-74	\N	C	2019-12-20 22:14:28.053842+00	3819
1	73	27	feature	Open-air; Close to the coast	\N	1	-73	\N	C	2019-12-20 22:14:28.053842+00	3820
1	72	27	feature	Open-air; Close to the coast	\N	1	-72	\N	C	2019-12-20 22:14:28.053842+00	3821
1	71	27	feature	Open-air; Close to the coast	\N	1	-71	\N	C	2019-12-20 22:14:28.053842+00	3822
1	70	27	feature	Open-air; Close to the coast	\N	1	-70	\N	C	2019-12-20 22:14:28.053842+00	3823
1	69	27	feature	Open-air; Close to the coast	\N	1	-69	\N	C	2019-12-20 22:14:28.053842+00	3824
1	68	27	feature	Open-air; Close to the coast	\N	1	-68	\N	C	2019-12-20 22:14:28.053842+00	3825
1	67	27	feature	Open-air; Close to the coast	\N	1	-67	\N	C	2019-12-20 22:14:28.053842+00	3826
1	66	27	feature	Open-air; Close to the coast	\N	1	-66	\N	C	2019-12-20 22:14:28.053842+00	3827
1	65	27	feature	Open-air; Close to the coast	\N	1	-65	\N	C	2019-12-20 22:14:28.053842+00	3828
1	64	27	feature	Open-air; Close to the coast	\N	1	-64	\N	C	2019-12-20 22:14:28.053842+00	3829
1	45	27	feature	Open-air; Close to the coast	\N	1	-45	\N	C	2019-12-20 22:14:28.053842+00	3848
1	44	27	feature	Open-air; Close to the coast	\N	1	-44	\N	C	2019-12-20 22:14:28.053842+00	3849
1	43	27	feature	Open-air; Close to the coast	\N	1	-43	\N	C	2019-12-20 22:14:28.053842+00	3850
1	42	27	feature	Open-air; Close to the coast	\N	1	-42	\N	C	2019-12-20 22:14:28.053842+00	3851
1	41	27	feature	Open-air; Close to the coast	\N	1	-41	\N	C	2019-12-20 22:14:28.053842+00	3852
1	40	27	feature	Open-air; Close to the coast	\N	1	-40	\N	C	2019-12-20 22:14:28.053842+00	3853
1	39	27	feature	Open-air; Close to the coast	\N	1	-39	\N	C	2019-12-20 22:14:28.053842+00	3854
1	38	27	feature	Open-air; Close to the coast	\N	1	-38	\N	C	2019-12-20 22:14:28.053842+00	3855
1	37	27	feature	Open-air; Close to the coast	\N	1	-37	\N	C	2019-12-20 22:14:28.053842+00	3856
1	36	27	feature	Open-air; Close to the coast	\N	1	-36	\N	C	2019-12-20 22:14:28.053842+00	3857
1	35	27	feature	Open-air; Close to the coast	\N	1	-35	\N	C	2019-12-20 22:14:28.053842+00	3858
1	34	27	feature	Open-air; Close to the coast	\N	1	-34	\N	C	2019-12-20 22:14:28.053842+00	3859
1	33	27	feature	Open-air; Close to the coast	\N	1	-33	\N	C	2019-12-20 22:14:28.053842+00	3860
1	32	27	feature	Open-air; Close to the coast	\N	1	-32	\N	C	2019-12-20 22:14:28.053842+00	3861
1	31	27	feature	Open-air; Close to the coast	\N	1	-31	\N	C	2019-12-20 22:14:28.053842+00	3862
1	30	27	feature	Open-air; Close to the coast	\N	1	-30	\N	C	2019-12-20 22:14:28.053842+00	3863
1	29	27	feature	Open-air; Close to the coast	\N	1	-29	\N	C	2019-12-20 22:14:28.053842+00	3864
1	28	27	feature	Open-air; Close to the coast	\N	1	-28	\N	C	2019-12-20 22:14:28.053842+00	3865
1	27	27	feature	Open-air; Inland	\N	1	-27	\N	C	2019-12-20 22:14:28.053842+00	3866
1	26	27	feature	Open-air; Inland	\N	1	-26	\N	C	2019-12-20 22:14:28.053842+00	3867
1	25	27	feature	Open-air; Inland	\N	1	-25	\N	C	2019-12-20 22:14:28.053842+00	3868
1	24	27	feature	Open-air; Inland	\N	1	-24	\N	C	2019-12-20 22:14:28.053842+00	3869
1	23	27	feature	Open-air; Inland	\N	1	-23	\N	C	2019-12-20 22:14:28.053842+00	3870
1	22	27	feature	Open-air; Inland	\N	1	-22	\N	C	2019-12-20 22:14:28.053842+00	3871
1	21	27	feature	Open-air; Inland	\N	1	-21	\N	C	2019-12-20 22:14:28.053842+00	3872
1	20	27	feature	Open-air; Inland	\N	1	-20	\N	C	2019-12-20 22:14:28.053842+00	3873
1	19	27	feature	Open-air; Inland	\N	1	-19	\N	C	2019-12-20 22:14:28.053842+00	3874
1	18	27	feature	Open-air; Inland	\N	1	-18	\N	C	2019-12-20 22:14:28.053842+00	3875
1	17	27	feature	Open-air; Inland	\N	1	-17	\N	C	2019-12-20 22:14:28.053842+00	3876
1	16	27	feature	Open-air; Inland	\N	1	-16	\N	C	2019-12-20 22:14:28.053842+00	3877
1	15	27	feature	Open-air; Inland	\N	1	-15	\N	C	2019-12-20 22:14:28.053842+00	3878
1	14	27	feature	Open-air; Inland	\N	1	-14	\N	C	2019-12-20 22:14:28.053842+00	3879
1	13	27	feature	Open-air; Inland	\N	1	-13	\N	C	2019-12-20 22:14:28.053842+00	3880
1	12	27	feature	Open-air; Inland	\N	1	-12	\N	C	2019-12-20 22:14:28.053842+00	3881
1	11	27	feature	Open-air; Inland	\N	1	-11	\N	C	2019-12-20 22:14:28.053842+00	3882
1	10	27	feature	Open-air; Inland	\N	1	-10	\N	C	2019-12-20 22:14:28.053842+00	3883
1	9	27	feature	Open-air; Inland	\N	1	-9	\N	C	2019-12-20 22:14:28.053842+00	3884
1	8	27	feature	Open-air; Inland	\N	1	-8	\N	C	2019-12-20 22:14:28.053842+00	3885
1	7	27	feature	Open-air; Inland	\N	1	-7	\N	C	2019-12-20 22:14:28.053842+00	3886
1	6	27	feature	Open-air; Inland	\N	1	-6	\N	C	2019-12-20 22:14:28.053842+00	3887
1	5	27	feature	Open-air; Inland	\N	1	-5	\N	C	2019-12-20 22:14:28.053842+00	3888
1	4	27	feature	Open-air; Inland	\N	1	-4	\N	C	2019-12-20 22:14:28.053842+00	3889
1	3	27	feature	Open-air; Inland	\N	1	-3	\N	C	2019-12-20 22:14:28.053842+00	3890
1	2	27	feature	Open-air; Inland	\N	1	-2	\N	C	2019-12-20 22:14:28.053842+00	3891
1	1	27	feature	Open-air; Inland	\N	1	-1	\N	C	2019-12-20 22:14:28.053842+00	3892
