1	1	11	46	-1	\N	\N	1	Isotope test-data for import in to SEAD	\N	1	-1	\N	C	2019-12-20 22:14:28.053842+00	24421
