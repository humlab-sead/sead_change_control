1	1	\N	Data expressed as a percentage (i.e. out x of 100)	%	Percentage	1	-1	\N	C	2019-12-20 22:14:28.053842+00	23
1	2	\N	Data expressed as a parts per thousand (i.e. out x of 1000)	‰	Parts per thousand	1	-2	\N	C	2019-12-20 22:14:28.053842+00	22
1	3	\N	The element/fossil is present in the sample, but not quantified (numerical classification where 1 = presence)	\N	Presence	1	-3	\N	C	2019-12-20 22:14:28.053842+00	21
1	4	\N	Data type is not clearly defined, could be a combination of quantification, presence/absence and semi-quantification or qualification. Beware of using data of this type for quantification.	\N	Undefined other	1	-4	\N	C	2019-12-20 22:14:28.053842+00	20
1	5	\N	A measured quantity.	\N	Continuous	1	-5	\N	C	2019-12-20 22:14:28.053842+00	19
1	6	\N	Weight measure 1/1 000 000 grams	µg g-1	Micrograms	1	-6	\N	C	2019-12-20 22:14:28.053842+00	18
1	7	\N	Weight measure 1/1 000 grams	mg	Milligrams	1	-7	\N	C	2019-12-20 22:14:28.053842+00	17
