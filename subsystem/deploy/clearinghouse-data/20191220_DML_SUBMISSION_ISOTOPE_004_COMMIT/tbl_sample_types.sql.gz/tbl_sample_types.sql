1	1	Ceramic part	Describes what part of ceramic vessel/structure was sampled	\N	1	-1	\N	C	2019-12-20 22:14:28.053842+00	19
1	2	Sample position	Describes what substance and possibly more accurate information on where on the ceramic part the sample came from (e.g. charred deposit from inside the vessel)	\N	1	-2	\N	C	2019-12-20 22:14:28.053842+00	18
