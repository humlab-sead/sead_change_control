3	1	9	-1	\N	Organism genome mapped to	Organism whose reference sequence / genome assembly was used for sequence alignment.	1	-1	\N	C	2025-02-03 15:45:49.896387+00	53
3	2	9	-1	\N	Reference genome assembly	reference sequence / genome assembly name or accession code.	1	-2	\N	C	2025-02-03 15:45:49.896387+00	52
3	3	1	-1	\N	Endogenous reads (filtered)	The number of sequence reads which have successfully mapped to the organism reference sequence after filtering.	1	-3	\N	C	2025-02-03 15:45:49.896387+00	51
3	4	11	-1	\N	Average read length	The average length of mapped sequence reads, excluding reads shorter than 35 bases and reads with less than 90% consensus to the species reference.	1	-4	\N	C	2025-02-03 15:45:49.896387+00	50
3	5	11	-1	\N	Average depth of coverage - genome (x)	The number of times on average that a given nucleotide in the genome has been sequenced.	1	-5	\N	C	2025-02-03 15:45:49.896387+00	49
3	6	4	-1	\N	Breadth of coverage - genome (%)	The percentage of the reference sequence / genome assembly covered after alignment.	1	-6	\N	C	2025-02-03 15:45:49.896387+00	48
3	7	11	-1	\N	Average depth of coverage - mtDNA (x)	The number of times on average that a given nucleotide in the mitochondrial genome has been sequenced.	1	-7	\N	C	2025-02-03 15:45:49.896387+00	47
3	8	2	-1	\N	mtDNA reads	The number of sequence reads which have successfully mapped to the mitochondrial DNA in the reference sequence.	1	-8	\N	C	2025-02-03 15:45:49.896387+00	46
3	9	2	-1	\N	X chromosome reads	The number of sequence reads which have successfully mapped to the X chromosome in the reference sequence.	1	-9	\N	C	2025-02-03 15:45:49.896387+00	45
3	10	1	-1	\N	Y chromosome reads	The number of sequence reads which have successfully mapped to the Y chromosome in reference sequence.	1	-10	\N	C	2025-02-03 15:45:49.896387+00	44
3	11	-3	-1	\N	Molecular sex - Ry	Prediction of molecular sex of individual. Ry is based on the ratio of reads aligning to the X and Y chromosomes.	1	-11	\N	C	2025-02-03 15:45:49.896387+00	43
3	12	-3	-1	\N	Molecular sex - Rx	Prediction of molecular sex of individual. Rx is based on the ratio of reads aligning to the X chromosome and autosomes.	1	-12	\N	C	2025-02-03 15:45:49.896387+00	42
3	13	9	-1	\N	mtDNA haplogroup	Prediction of mitochondrial DNA haplogroup.	1	-13	\N	C	2025-02-03 15:45:49.896387+00	41
3	14	9	-1	\N	Y haplogroup	Prediction of Y chromosome haplogroup.	1	-14	\N	C	2025-02-03 15:45:49.896387+00	40
3	15	9	-1	\N	1st deg. relatives	List of sample IDs that are 1st degree relatives to the analysed individual.	1	-15	\N	C	2025-02-03 15:45:49.896387+00	39
3	16	9	-1	\N	2nd deg. relatives	List of sample IDs that are 2nd degree relatives to the analysed individual.	1	-16	\N	C	2025-02-03 15:45:49.896387+00	38
3	17	9	-1	\N	>2nd deg. relatives	List of sample IDs that are further than 2nd degree relatives to the analysed individual.	1	-17	\N	C	2025-02-03 15:45:49.896387+00	37
3	18	-8	-1	\N	Library preparation(s)	Type of sequence library preparation (e.g. blunt-end, single-stranded, etc.).	1	-18	\N	C	2025-02-03 15:45:49.896387+00	36
3	19	-5	-1	\N	Damage treatment(s)	Type of damage treatment if applicable (e.g. UDG).	1	-19	\N	C	2025-02-03 15:45:49.896387+00	35
3	20	-6	-1	\N	SNP capture	Type of SNP capture if applicable (e.g. 1240k).	1	-20	\N	C	2025-02-03 15:45:49.896387+00	34
3	21	7	-1	\N	Metagenomics analysis	Record of whether the library been subjected to a metagenomic analysis.	1	-21	\N	C	2025-02-03 15:45:49.896387+00	33
3	22	9	-1	\N	General library file name	General file name suffix for library DNA sequence fastq files, BAM files, etc.	1	-22	\N	C	2025-02-03 15:45:49.896387+00	32
3	23	1	-1	\N	Merged reads	The total number of merged sequence reads retained following adapter removal and merging of read pairs.	1	-23	\N	C	2025-02-03 15:45:49.896387+00	31
3	24	2	-1	\N	Endogenous reads (raw)	The number of sequence reads which have successfully mapped to the organism reference sequence before filtering.	1	-24	\N	C	2025-02-03 15:45:49.896387+00	30
3	25	4	-1	\N	Raw endogenous content (%) 	The number of sequence reads which have successfully mapped to the organism reference sequence after filtering.	1	-25	\N	C	2025-02-03 15:45:49.896387+00	29
3	26	4	-1	\N	Duplicate reads (%)	The percentage of mapped sequence reads that are PCR duplicates i.e. they have identical start and end positions.	1	-26	\N	C	2025-02-03 15:45:49.896387+00	28
3	27	4	-1	\N	Short reads (%)	The percentage of mapped sequence reads that are shorter than 35 bases.	1	-27	\N	C	2025-02-03 15:45:49.896387+00	27
3	28	11	-1	\N	5’ damage	Proportion of T nucleotides (given C nucleotide in reference) at the 5’ end of sequence reads. Representative of damage to DNA due to deamination of cytosines.	1	-28	\N	C	2025-02-03 15:45:49.896387+00	26
3	29	11	-1	\N	3’ damage	Proportion of A nucleotides (given G nucleotide in reference) at the 3’ end of sequence reads. Representative of damage to DNA due to deamination of cytosines on complementary strand.	1	-29	\N	C	2025-02-03 15:45:49.896387+00	25
3	30	7	-1	\N	Methods metadata download link	Link to methods metadata worksheet (with lab and bioinformatics methods, tools, parameters, etc.).	1	-30	\N	C	2025-02-03 15:45:49.896387+00	24
