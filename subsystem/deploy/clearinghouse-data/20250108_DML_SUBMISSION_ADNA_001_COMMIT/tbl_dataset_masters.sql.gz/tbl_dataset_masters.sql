2	1	-2	\N	SciLifelab Ancient DNA	\N	https://www.scilifelab.se/units/ancient-dna/	2025-02-14 12:56:54.843301+00	1	-1	\N	C	2025-02-14 12:56:55.455319+00	12
