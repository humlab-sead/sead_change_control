2	1	-2	\N	SciLifelab Ancient DNA	\N	https://www.scilifelab.se/units/ancient-dna/	2025-02-17 15:02:44.116641+00	1	-1	\N	C	2025-02-17 15:02:44.731991+00	12
