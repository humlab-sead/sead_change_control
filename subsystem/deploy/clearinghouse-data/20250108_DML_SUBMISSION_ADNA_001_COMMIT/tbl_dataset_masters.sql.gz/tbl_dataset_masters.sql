3	1	-2	\N	SciLifelab Ancient DNA	\N	https://www.scilifelab.se/units/ancient-dna/	2025-02-03 15:45:49.287746+00	e578e472-3395-479d-80cd-f715b579b9c4	1	-1	\N	C	2025-02-03 15:45:49.896387+00	12
