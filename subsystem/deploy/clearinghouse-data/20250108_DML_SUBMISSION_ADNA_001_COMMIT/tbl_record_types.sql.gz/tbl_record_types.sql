2	1	DNA	Any type of DNA analysis (e.g. ancient humans or sedimentary)	2025-02-17 15:02:44.116641+00	1	-1	\N	C	2025-02-17 15:02:44.731991+00	22
