2	1	DNA	Any type of DNA analysis (e.g. ancient humans or sedimentary)	2025-02-14 12:56:54.843301+00	1	-1	\N	C	2025-02-14 12:56:55.455319+00	22
