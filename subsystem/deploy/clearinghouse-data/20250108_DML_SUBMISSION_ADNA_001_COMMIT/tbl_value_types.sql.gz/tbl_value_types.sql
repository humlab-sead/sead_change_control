2	3	\N	19	Molecular sex	category	\N	Molecular sex	cc958d02-39ff-4262-842d-4df5197222ec	1	-3	\N	C	2025-02-17 15:02:44.731991+00	17
2	5	\N	19	Damage treatment	category	\N	Type of damage treatment	d1799c9f-1dac-44d7-bac1-8462a661e30b	1	-5	\N	C	2025-02-17 15:02:44.731991+00	16
2	6	\N	19	SNP capture	category	\N	Type of SNP capture.	6968fe5f-722c-45b2-a0bb-b12d6f41cc80	1	-6	\N	C	2025-02-17 15:02:44.731991+00	15
2	8	\N	19	Library preparation	category	\N	Type of sequence library preparation	40a0a25f-6edc-4fcf-bedb-8e0d0fc0fa67	1	-8	\N	C	2025-02-17 15:02:44.731991+00	14
