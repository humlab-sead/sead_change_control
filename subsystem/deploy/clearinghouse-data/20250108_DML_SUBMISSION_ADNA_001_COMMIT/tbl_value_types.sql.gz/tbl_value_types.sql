1	3	\N	19	Molecular sex	category	\N	Molecular sex	20fd5652-c5c3-496c-bede-c1dcf816ed85	1	-3	\N	C	2025-02-13 14:31:51.757199+00	17
1	5	\N	19	Damage treatment	category	\N	Type of damage treatment	471f706b-2dc5-4e9d-b58d-996709d2a14d	1	-5	\N	C	2025-02-13 14:31:51.757199+00	16
1	6	\N	19	SNP capture	category	\N	Type of SNP capture.	911f8a93-5704-42d0-a594-6b093c11a94f	1	-6	\N	C	2025-02-13 14:31:51.757199+00	15
1	8	\N	19	Library preparation	category	\N	Type of sequence library preparation	dde83794-a7bc-48b1-ab14-f0937a128297	1	-8	\N	C	2025-02-13 14:31:51.757199+00	14
