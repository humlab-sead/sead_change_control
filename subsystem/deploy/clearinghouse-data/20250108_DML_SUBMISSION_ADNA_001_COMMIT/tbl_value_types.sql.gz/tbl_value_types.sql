2	3	\N	19	Molecular sex	category	\N	Molecular sex	ee7131ea-4bf4-4617-be59-b772d1b4824e	1	-3	\N	C	2025-02-14 12:56:55.455319+00	17
2	5	\N	19	Damage treatment	category	\N	Type of damage treatment	f624cc2f-5a7a-43e8-b5fb-eb21b0ccdf11	1	-5	\N	C	2025-02-14 12:56:55.455319+00	16
2	6	\N	19	SNP capture	category	\N	Type of SNP capture.	151da2d5-889d-4ef3-a5f8-d9503f721676	1	-6	\N	C	2025-02-14 12:56:55.455319+00	15
2	8	\N	19	Library preparation	category	\N	Type of sequence library preparation	8764f838-d52f-4347-80cc-9124a11e0c67	1	-8	\N	C	2025-02-14 12:56:55.455319+00	14
