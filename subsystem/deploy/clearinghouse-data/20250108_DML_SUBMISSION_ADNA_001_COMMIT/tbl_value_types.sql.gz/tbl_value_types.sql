3	3	\N	19	Molecular sex	category	\N	Molecular sex	1	-3	\N	C	2025-02-03 15:45:49.896387+00	17
3	5	\N	19	Damage treatment	category	\N	Type of damage treatment	1	-5	\N	C	2025-02-03 15:45:49.896387+00	16
3	6	\N	19	SNP capture	category	\N	Type of SNP capture.	1	-6	\N	C	2025-02-03 15:45:49.896387+00	15
3	8	\N	19	Library preparation	category	\N	Type of sequence library preparation	1	-8	\N	C	2025-02-03 15:45:49.896387+00	14
