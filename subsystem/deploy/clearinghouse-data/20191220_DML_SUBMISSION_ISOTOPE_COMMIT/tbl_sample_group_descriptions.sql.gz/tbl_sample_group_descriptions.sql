1	989	Open-air; Close to the coast	3	\N	-45	1	-989	\N	C	2019-12-20 22:14:28.053842+00	1350
1	7	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-7	1	-7	\N	C	2019-12-20 22:14:28.053842+00	2332
1	6	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-6	1	-6	\N	C	2019-12-20 22:14:28.053842+00	2333
1	5	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-5	1	-5	\N	C	2019-12-20 22:14:28.053842+00	2334
1	4	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-4	1	-4	\N	C	2019-12-20 22:14:28.053842+00	2335
1	3	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-3	1	-3	\N	C	2019-12-20 22:14:28.053842+00	2336
1	2	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-2	1	-2	\N	C	2019-12-20 22:14:28.053842+00	2337
1	1	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-1	1	-1	\N	C	2019-12-20 22:14:28.053842+00	2338
1	10	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-10	1	-10	\N	C	2019-12-20 22:14:28.053842+00	2329
1	9	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-9	1	-9	\N	C	2019-12-20 22:14:28.053842+00	2330
1	8	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-8	1	-8	\N	C	2019-12-20 22:14:28.053842+00	2331
1	1854	Open-air; Inland	3	\N	-910	1	-1854	\N	C	2019-12-20 22:14:28.053842+00	485
1	1888	Open-air; Inland	3	\N	-944	1	-1888	\N	C	2019-12-20 22:14:28.053842+00	451
1	1887	Open-air; Inland	3	\N	-943	1	-1887	\N	C	2019-12-20 22:14:28.053842+00	452
1	1886	Open-air; Inland	3	\N	-942	1	-1886	\N	C	2019-12-20 22:14:28.053842+00	453
1	1885	Open-air; Inland	3	\N	-941	1	-1885	\N	C	2019-12-20 22:14:28.053842+00	454
1	1884	Open-air; Inland	3	\N	-940	1	-1884	\N	C	2019-12-20 22:14:28.053842+00	455
1	1883	Open-air; Inland	3	\N	-939	1	-1883	\N	C	2019-12-20 22:14:28.053842+00	456
1	1882	Open-air; Inland	3	\N	-938	1	-1882	\N	C	2019-12-20 22:14:28.053842+00	457
1	1881	Open-air; Inland	3	\N	-937	1	-1881	\N	C	2019-12-20 22:14:28.053842+00	458
1	1880	Open-air; Inland	3	\N	-936	1	-1880	\N	C	2019-12-20 22:14:28.053842+00	459
1	1879	Open-air; Inland	3	\N	-935	1	-1879	\N	C	2019-12-20 22:14:28.053842+00	460
1	1878	Open-air; Lake shore	3	\N	-934	1	-1878	\N	C	2019-12-20 22:14:28.053842+00	461
1	1877	Open-air; Lake shore	3	\N	-933	1	-1877	\N	C	2019-12-20 22:14:28.053842+00	462
1	1876	Open-air; Lake shore	3	\N	-932	1	-1876	\N	C	2019-12-20 22:14:28.053842+00	463
1	1875	Open-air; Lake shore	3	\N	-931	1	-1875	\N	C	2019-12-20 22:14:28.053842+00	464
1	1874	Open-air; Lake shore	3	\N	-930	1	-1874	\N	C	2019-12-20 22:14:28.053842+00	465
1	1873	Open-air; Lake shore	3	\N	-929	1	-1873	\N	C	2019-12-20 22:14:28.053842+00	466
1	1872	Open-air; Lake shore	3	\N	-928	1	-1872	\N	C	2019-12-20 22:14:28.053842+00	467
1	1871	Open-air; Lake shore	3	\N	-927	1	-1871	\N	C	2019-12-20 22:14:28.053842+00	468
1	1870	Open-air; Lake shore	3	\N	-926	1	-1870	\N	C	2019-12-20 22:14:28.053842+00	469
1	1869	Open-air; Lake shore	3	\N	-925	1	-1869	\N	C	2019-12-20 22:14:28.053842+00	470
1	1868	Open-air; Lake shore	3	\N	-924	1	-1868	\N	C	2019-12-20 22:14:28.053842+00	471
1	1867	Open-air; Lake shore	3	\N	-923	1	-1867	\N	C	2019-12-20 22:14:28.053842+00	472
1	1866	Open-air; Lake shore	3	\N	-922	1	-1866	\N	C	2019-12-20 22:14:28.053842+00	473
1	1865	Open-air; Inland	3	\N	-921	1	-1865	\N	C	2019-12-20 22:14:28.053842+00	474
1	1864	Open-air; Inland	3	\N	-920	1	-1864	\N	C	2019-12-20 22:14:28.053842+00	475
1	1863	Open-air; Inland	3	\N	-919	1	-1863	\N	C	2019-12-20 22:14:28.053842+00	476
1	1862	Open-air; Inland	3	\N	-918	1	-1862	\N	C	2019-12-20 22:14:28.053842+00	477
1	1861	Open-air; Inland	3	\N	-917	1	-1861	\N	C	2019-12-20 22:14:28.053842+00	478
1	1860	Open-air; Inland	3	\N	-916	1	-1860	\N	C	2019-12-20 22:14:28.053842+00	479
1	1859	Open-air; Inland	3	\N	-915	1	-1859	\N	C	2019-12-20 22:14:28.053842+00	480
1	1858	Open-air; Inland	3	\N	-914	1	-1858	\N	C	2019-12-20 22:14:28.053842+00	481
1	1857	Open-air; Inland	3	\N	-913	1	-1857	\N	C	2019-12-20 22:14:28.053842+00	482
1	1856	Open-air; Inland	3	\N	-912	1	-1856	\N	C	2019-12-20 22:14:28.053842+00	483
1	1855	Open-air; Inland	3	\N	-911	1	-1855	\N	C	2019-12-20 22:14:28.053842+00	484
1	1853	Open-air; Inland	3	\N	-909	1	-1853	\N	C	2019-12-20 22:14:28.053842+00	486
1	1852	Open-air; Inland	3	\N	-908	1	-1852	\N	C	2019-12-20 22:14:28.053842+00	487
1	1851	Open-air; Inland	3	\N	-907	1	-1851	\N	C	2019-12-20 22:14:28.053842+00	488
1	1850	Open-air; Inland	3	\N	-906	1	-1850	\N	C	2019-12-20 22:14:28.053842+00	489
1	1849	Open-air; Inland	3	\N	-905	1	-1849	\N	C	2019-12-20 22:14:28.053842+00	490
1	1848	Open-air; Inland	3	\N	-904	1	-1848	\N	C	2019-12-20 22:14:28.053842+00	491
1	1847	Open-air; Inland	3	\N	-903	1	-1847	\N	C	2019-12-20 22:14:28.053842+00	492
1	1846	Open-air; Inland	3	\N	-902	1	-1846	\N	C	2019-12-20 22:14:28.053842+00	493
1	1845	Open-air; Inland	3	\N	-901	1	-1845	\N	C	2019-12-20 22:14:28.053842+00	494
1	1844	Open-air; Inland	3	\N	-900	1	-1844	\N	C	2019-12-20 22:14:28.053842+00	495
1	1843	Open-air; Inland	3	\N	-899	1	-1843	\N	C	2019-12-20 22:14:28.053842+00	496
1	1842	Open-air; Inland	3	\N	-898	1	-1842	\N	C	2019-12-20 22:14:28.053842+00	497
1	1841	Open-air; Inland	3	\N	-897	1	-1841	\N	C	2019-12-20 22:14:28.053842+00	498
1	1840	Open-air; Inland	3	\N	-896	1	-1840	\N	C	2019-12-20 22:14:28.053842+00	499
1	1839	Open-air; Inland	3	\N	-895	1	-1839	\N	C	2019-12-20 22:14:28.053842+00	500
1	1838	Open-air; Inland	3	\N	-894	1	-1838	\N	C	2019-12-20 22:14:28.053842+00	501
1	1837	Open-air; Inland	3	\N	-893	1	-1837	\N	C	2019-12-20 22:14:28.053842+00	502
1	1836	Open-air; Inland	3	\N	-892	1	-1836	\N	C	2019-12-20 22:14:28.053842+00	503
1	1835	Open-air; Inland	3	\N	-891	1	-1835	\N	C	2019-12-20 22:14:28.053842+00	504
1	1834	Open-air; Inland	3	\N	-890	1	-1834	\N	C	2019-12-20 22:14:28.053842+00	505
1	1833	Open-air; Close to the coast	3	\N	-889	1	-1833	\N	C	2019-12-20 22:14:28.053842+00	506
1	1832	Open-air; Close to the coast	3	\N	-888	1	-1832	\N	C	2019-12-20 22:14:28.053842+00	507
1	1831	Open-air; Close to the coast	3	\N	-887	1	-1831	\N	C	2019-12-20 22:14:28.053842+00	508
1	1830	Open-air; Close to the coast	3	\N	-886	1	-1830	\N	C	2019-12-20 22:14:28.053842+00	509
1	1829	Open-air; Close to the coast	3	\N	-885	1	-1829	\N	C	2019-12-20 22:14:28.053842+00	510
1	1828	Open-air; Close to the coast	3	\N	-884	1	-1828	\N	C	2019-12-20 22:14:28.053842+00	511
1	1827	Open-air; Close to the coast	3	\N	-883	1	-1827	\N	C	2019-12-20 22:14:28.053842+00	512
1	1826	Open-air; Close to the coast	3	\N	-882	1	-1826	\N	C	2019-12-20 22:14:28.053842+00	513
1	1825	Open-air; Close to the coast	3	\N	-881	1	-1825	\N	C	2019-12-20 22:14:28.053842+00	514
1	1824	Open-air; Close to the coast	3	\N	-880	1	-1824	\N	C	2019-12-20 22:14:28.053842+00	515
1	1823	Open-air; Close to the coast	3	\N	-879	1	-1823	\N	C	2019-12-20 22:14:28.053842+00	516
1	1822	Open-air; Close to the coast	3	\N	-878	1	-1822	\N	C	2019-12-20 22:14:28.053842+00	517
1	1821	Open-air; Close to the coast	3	\N	-877	1	-1821	\N	C	2019-12-20 22:14:28.053842+00	518
1	1820	Open-air; Close to the coast	3	\N	-876	1	-1820	\N	C	2019-12-20 22:14:28.053842+00	519
1	1819	Open-air; Close to the coast	3	\N	-875	1	-1819	\N	C	2019-12-20 22:14:28.053842+00	520
1	1818	Open-air; Close to the coast	3	\N	-874	1	-1818	\N	C	2019-12-20 22:14:28.053842+00	521
1	1817	Open-air; Close to the coast	3	\N	-873	1	-1817	\N	C	2019-12-20 22:14:28.053842+00	522
1	1816	Open-air; Close to the coast	3	\N	-872	1	-1816	\N	C	2019-12-20 22:14:28.053842+00	523
1	1815	Open-air; Close to the coast	3	\N	-871	1	-1815	\N	C	2019-12-20 22:14:28.053842+00	524
1	1814	Open-air; Close to the coast	3	\N	-870	1	-1814	\N	C	2019-12-20 22:14:28.053842+00	525
1	1813	Open-air; Close to the coast	3	\N	-869	1	-1813	\N	C	2019-12-20 22:14:28.053842+00	526
1	1812	Open-air; Close to the coast	3	\N	-868	1	-1812	\N	C	2019-12-20 22:14:28.053842+00	527
1	1811	Open-air; Inland	3	\N	-867	1	-1811	\N	C	2019-12-20 22:14:28.053842+00	528
1	1810	Open-air; Inland	3	\N	-866	1	-1810	\N	C	2019-12-20 22:14:28.053842+00	529
1	1809	Open-air; Inland	3	\N	-865	1	-1809	\N	C	2019-12-20 22:14:28.053842+00	530
1	1808	Open-air; Inland	3	\N	-864	1	-1808	\N	C	2019-12-20 22:14:28.053842+00	531
1	1807	Open-air; Inland	3	\N	-863	1	-1807	\N	C	2019-12-20 22:14:28.053842+00	532
1	1806	Open-air; Close to the coast	3	\N	-862	1	-1806	\N	C	2019-12-20 22:14:28.053842+00	533
1	1805	Shell midden; Lake shore	3	\N	-861	1	-1805	\N	C	2019-12-20 22:14:28.053842+00	534
1	1804	Shell midden; Lake shore	3	\N	-860	1	-1804	\N	C	2019-12-20 22:14:28.053842+00	535
1	1803	Shell midden; Lake shore	3	\N	-859	1	-1803	\N	C	2019-12-20 22:14:28.053842+00	536
1	1802	Shell midden; Lake shore	3	\N	-858	1	-1802	\N	C	2019-12-20 22:14:28.053842+00	537
1	1801	Shell midden; Lake shore	3	\N	-857	1	-1801	\N	C	2019-12-20 22:14:28.053842+00	538
1	1800	Shell midden; Lake shore	3	\N	-856	1	-1800	\N	C	2019-12-20 22:14:28.053842+00	539
1	1799	Shell midden; Lake shore	3	\N	-855	1	-1799	\N	C	2019-12-20 22:14:28.053842+00	540
1	1798	Shell midden; Lake shore	3	\N	-854	1	-1798	\N	C	2019-12-20 22:14:28.053842+00	541
1	1797	Shell midden; Lake shore	3	\N	-853	1	-1797	\N	C	2019-12-20 22:14:28.053842+00	542
1	1796	Shell midden; Lake shore	3	\N	-852	1	-1796	\N	C	2019-12-20 22:14:28.053842+00	543
1	1795	Shell midden; Lake shore	3	\N	-851	1	-1795	\N	C	2019-12-20 22:14:28.053842+00	544
1	1794	Shell midden; Lake shore	3	\N	-850	1	-1794	\N	C	2019-12-20 22:14:28.053842+00	545
1	1793	Shell midden; Lake shore	3	\N	-849	1	-1793	\N	C	2019-12-20 22:14:28.053842+00	546
1	1792	Shell midden; Lake shore	3	\N	-848	1	-1792	\N	C	2019-12-20 22:14:28.053842+00	547
1	1791	Shell midden; Lake shore	3	\N	-847	1	-1791	\N	C	2019-12-20 22:14:28.053842+00	548
1	1790	Shell midden; Lake shore	3	\N	-846	1	-1790	\N	C	2019-12-20 22:14:28.053842+00	549
1	1789	Shell midden; Lake shore	3	\N	-845	1	-1789	\N	C	2019-12-20 22:14:28.053842+00	550
1	1788	Shell midden; Lake shore	3	\N	-844	1	-1788	\N	C	2019-12-20 22:14:28.053842+00	551
1	1787	Shell midden; Lake shore	3	\N	-843	1	-1787	\N	C	2019-12-20 22:14:28.053842+00	552
1	1786	Shell midden; Lake shore	3	\N	-842	1	-1786	\N	C	2019-12-20 22:14:28.053842+00	553
1	1785	Shell midden; Lake shore	3	\N	-841	1	-1785	\N	C	2019-12-20 22:14:28.053842+00	554
1	1784	Shell midden; Lake shore	3	\N	-840	1	-1784	\N	C	2019-12-20 22:14:28.053842+00	555
1	1783	Shell midden; Lake shore	3	\N	-839	1	-1783	\N	C	2019-12-20 22:14:28.053842+00	556
1	1782	Shell midden; Lake shore	3	\N	-838	1	-1782	\N	C	2019-12-20 22:14:28.053842+00	557
1	1781	Shell midden; Lake shore	3	\N	-837	1	-1781	\N	C	2019-12-20 22:14:28.053842+00	558
1	1780	Shell midden; Lake shore	3	\N	-836	1	-1780	\N	C	2019-12-20 22:14:28.053842+00	559
1	1779	Shell midden; Lake shore	3	\N	-835	1	-1779	\N	C	2019-12-20 22:14:28.053842+00	560
1	1778	Shell midden; Lake shore	3	\N	-834	1	-1778	\N	C	2019-12-20 22:14:28.053842+00	561
1	1777	Shell midden; Lake shore	3	\N	-833	1	-1777	\N	C	2019-12-20 22:14:28.053842+00	562
1	1776	Shell midden; Lake shore	3	\N	-832	1	-1776	\N	C	2019-12-20 22:14:28.053842+00	563
1	1775	Shell midden; Lake shore	3	\N	-831	1	-1775	\N	C	2019-12-20 22:14:28.053842+00	564
1	1774	Shell midden; Lake shore	3	\N	-830	1	-1774	\N	C	2019-12-20 22:14:28.053842+00	565
1	1773	Shell midden; Lake shore	3	\N	-829	1	-1773	\N	C	2019-12-20 22:14:28.053842+00	566
1	1772	Shell midden; Lake shore	3	\N	-828	1	-1772	\N	C	2019-12-20 22:14:28.053842+00	567
1	1771	Shell midden; Lake shore	3	\N	-827	1	-1771	\N	C	2019-12-20 22:14:28.053842+00	568
1	1770	Shell midden; Lake shore	3	\N	-826	1	-1770	\N	C	2019-12-20 22:14:28.053842+00	569
1	1769	Shell midden; Lake shore	3	\N	-825	1	-1769	\N	C	2019-12-20 22:14:28.053842+00	570
1	1768	Shell midden; Lake shore	3	\N	-824	1	-1768	\N	C	2019-12-20 22:14:28.053842+00	571
1	1767	Shell midden; Lake shore	3	\N	-823	1	-1767	\N	C	2019-12-20 22:14:28.053842+00	572
1	1766	Shell midden; Lake shore	3	\N	-822	1	-1766	\N	C	2019-12-20 22:14:28.053842+00	573
1	1765	Shell midden; Lake shore	3	\N	-821	1	-1765	\N	C	2019-12-20 22:14:28.053842+00	574
1	1764	Shell midden; Lake shore	3	\N	-820	1	-1764	\N	C	2019-12-20 22:14:28.053842+00	575
1	1763	Shell midden; Lake shore	3	\N	-819	1	-1763	\N	C	2019-12-20 22:14:28.053842+00	576
1	1762	Shell midden; Lake shore	3	\N	-818	1	-1762	\N	C	2019-12-20 22:14:28.053842+00	577
1	1761	Shell midden; Lake shore	3	\N	-817	1	-1761	\N	C	2019-12-20 22:14:28.053842+00	578
1	1760	Shell midden; Lake shore	3	\N	-816	1	-1760	\N	C	2019-12-20 22:14:28.053842+00	579
1	1759	Shell midden; Lake shore	3	\N	-815	1	-1759	\N	C	2019-12-20 22:14:28.053842+00	580
1	1758	Shell midden; Lake shore	3	\N	-814	1	-1758	\N	C	2019-12-20 22:14:28.053842+00	581
1	1757	Shell midden; Lake shore	3	\N	-813	1	-1757	\N	C	2019-12-20 22:14:28.053842+00	582
1	1756	Shell midden; Lake shore	3	\N	-812	1	-1756	\N	C	2019-12-20 22:14:28.053842+00	583
1	1755	Shell midden; Lake shore	3	\N	-811	1	-1755	\N	C	2019-12-20 22:14:28.053842+00	584
1	1754	Shell midden; Lake shore	3	\N	-810	1	-1754	\N	C	2019-12-20 22:14:28.053842+00	585
1	1753	Shell midden; Lake shore	3	\N	-809	1	-1753	\N	C	2019-12-20 22:14:28.053842+00	586
1	1752	Shell midden; Lake shore	3	\N	-808	1	-1752	\N	C	2019-12-20 22:14:28.053842+00	587
1	1751	Shell midden; Lake shore	3	\N	-807	1	-1751	\N	C	2019-12-20 22:14:28.053842+00	588
1	1750	Shell midden; Lake shore	3	\N	-806	1	-1750	\N	C	2019-12-20 22:14:28.053842+00	589
1	1749	Shell midden; Lake shore	3	\N	-805	1	-1749	\N	C	2019-12-20 22:14:28.053842+00	590
1	1748	Shell midden; Lake shore	3	\N	-804	1	-1748	\N	C	2019-12-20 22:14:28.053842+00	591
1	1747	Shell midden; Lake shore	3	\N	-803	1	-1747	\N	C	2019-12-20 22:14:28.053842+00	592
1	1746	Shell midden; Lake shore	3	\N	-802	1	-1746	\N	C	2019-12-20 22:14:28.053842+00	593
1	1745	Shell midden; Lake shore	3	\N	-801	1	-1745	\N	C	2019-12-20 22:14:28.053842+00	594
1	1744	Shell midden; Lake shore	3	\N	-800	1	-1744	\N	C	2019-12-20 22:14:28.053842+00	595
1	1743	Shell midden; Lake shore	3	\N	-799	1	-1743	\N	C	2019-12-20 22:14:28.053842+00	596
1	1742	Shell midden; Lake shore	3	\N	-798	1	-1742	\N	C	2019-12-20 22:14:28.053842+00	597
1	1741	Shell midden; Lake shore	3	\N	-797	1	-1741	\N	C	2019-12-20 22:14:28.053842+00	598
1	1740	Shell midden; Lake shore	3	\N	-796	1	-1740	\N	C	2019-12-20 22:14:28.053842+00	599
1	1739	Shell midden; Lake shore	3	\N	-795	1	-1739	\N	C	2019-12-20 22:14:28.053842+00	600
1	1738	Shell midden; Lake shore	3	\N	-794	1	-1738	\N	C	2019-12-20 22:14:28.053842+00	601
1	1737	Shell midden; Lake shore	3	\N	-793	1	-1737	\N	C	2019-12-20 22:14:28.053842+00	602
1	1736	Shell midden; Lake shore	3	\N	-792	1	-1736	\N	C	2019-12-20 22:14:28.053842+00	603
1	1735	Shell midden; Lake shore	3	\N	-791	1	-1735	\N	C	2019-12-20 22:14:28.053842+00	604
1	1734	Shell midden; Lake shore	3	\N	-790	1	-1734	\N	C	2019-12-20 22:14:28.053842+00	605
1	1733	Shell midden; Lake shore	3	\N	-789	1	-1733	\N	C	2019-12-20 22:14:28.053842+00	606
1	1732	Shell midden; Lake shore	3	\N	-788	1	-1732	\N	C	2019-12-20 22:14:28.053842+00	607
1	1731	Shell midden; Lake shore	3	\N	-787	1	-1731	\N	C	2019-12-20 22:14:28.053842+00	608
1	1730	Shell midden; Lake shore	3	\N	-786	1	-1730	\N	C	2019-12-20 22:14:28.053842+00	609
1	1729	Shell midden; Lake shore	3	\N	-785	1	-1729	\N	C	2019-12-20 22:14:28.053842+00	610
1	1728	Shell midden; Lake shore	3	\N	-784	1	-1728	\N	C	2019-12-20 22:14:28.053842+00	611
1	1727	Shell midden; Lake shore	3	\N	-783	1	-1727	\N	C	2019-12-20 22:14:28.053842+00	612
1	1726	Shell midden; Lake shore	3	\N	-782	1	-1726	\N	C	2019-12-20 22:14:28.053842+00	613
1	1725	Open-air; Lake shore	3	\N	-781	1	-1725	\N	C	2019-12-20 22:14:28.053842+00	614
1	1724	Open-air; Lake shore	3	\N	-780	1	-1724	\N	C	2019-12-20 22:14:28.053842+00	615
1	1723	Open-air; Lake shore	3	\N	-779	1	-1723	\N	C	2019-12-20 22:14:28.053842+00	616
1	1722	Open-air; Lake shore	3	\N	-778	1	-1722	\N	C	2019-12-20 22:14:28.053842+00	617
1	1721	Open-air; Lake shore	3	\N	-777	1	-1721	\N	C	2019-12-20 22:14:28.053842+00	618
1	1720	Open-air; Lake shore	3	\N	-776	1	-1720	\N	C	2019-12-20 22:14:28.053842+00	619
1	1719	Open-air; Lake shore	3	\N	-775	1	-1719	\N	C	2019-12-20 22:14:28.053842+00	620
1	1718	Open-air; Lake shore	3	\N	-774	1	-1718	\N	C	2019-12-20 22:14:28.053842+00	621
1	1717	Open-air; Lake shore	3	\N	-773	1	-1717	\N	C	2019-12-20 22:14:28.053842+00	622
1	1716	Open-air; Lake shore	3	\N	-772	1	-1716	\N	C	2019-12-20 22:14:28.053842+00	623
1	1715	Open-air; Lake shore	3	\N	-771	1	-1715	\N	C	2019-12-20 22:14:28.053842+00	624
1	1714	Open-air; Lake shore	3	\N	-770	1	-1714	\N	C	2019-12-20 22:14:28.053842+00	625
1	1713	Open-air; Lake shore	3	\N	-769	1	-1713	\N	C	2019-12-20 22:14:28.053842+00	626
1	1712	Open-air; Lake shore	3	\N	-768	1	-1712	\N	C	2019-12-20 22:14:28.053842+00	627
1	1711	Open-air; Lake shore	3	\N	-767	1	-1711	\N	C	2019-12-20 22:14:28.053842+00	628
1	1710	Open-air; Lake shore	3	\N	-766	1	-1710	\N	C	2019-12-20 22:14:28.053842+00	629
1	1709	Open-air; Lake shore	3	\N	-765	1	-1709	\N	C	2019-12-20 22:14:28.053842+00	630
1	1708	Open-air; Lake shore	3	\N	-764	1	-1708	\N	C	2019-12-20 22:14:28.053842+00	631
1	1707	Open-air; Lake shore	3	\N	-763	1	-1707	\N	C	2019-12-20 22:14:28.053842+00	632
1	1706	Open-air; Lake shore	3	\N	-762	1	-1706	\N	C	2019-12-20 22:14:28.053842+00	633
1	1705	Open-air; Lake shore	3	\N	-761	1	-1705	\N	C	2019-12-20 22:14:28.053842+00	634
1	1704	Open-air; Lake shore	3	\N	-760	1	-1704	\N	C	2019-12-20 22:14:28.053842+00	635
1	1703	Open-air; Lake shore	3	\N	-759	1	-1703	\N	C	2019-12-20 22:14:28.053842+00	636
1	1702	Open-air; Lake shore	3	\N	-758	1	-1702	\N	C	2019-12-20 22:14:28.053842+00	637
1	1701	Open-air; Lake shore	3	\N	-757	1	-1701	\N	C	2019-12-20 22:14:28.053842+00	638
1	1700	Open-air; Lake shore	3	\N	-756	1	-1700	\N	C	2019-12-20 22:14:28.053842+00	639
1	1699	Open-air; Lake shore	3	\N	-755	1	-1699	\N	C	2019-12-20 22:14:28.053842+00	640
1	1698	Open-air; Lake shore	3	\N	-754	1	-1698	\N	C	2019-12-20 22:14:28.053842+00	641
1	1697	Open-air; Lake shore	3	\N	-753	1	-1697	\N	C	2019-12-20 22:14:28.053842+00	642
1	1696	Open-air; Lake shore	3	\N	-752	1	-1696	\N	C	2019-12-20 22:14:28.053842+00	643
1	1695	Open-air; Lake shore	3	\N	-751	1	-1695	\N	C	2019-12-20 22:14:28.053842+00	644
1	1694	Open-air; Lake shore	3	\N	-750	1	-1694	\N	C	2019-12-20 22:14:28.053842+00	645
1	1693	Open-air; Lake shore	3	\N	-749	1	-1693	\N	C	2019-12-20 22:14:28.053842+00	646
1	1692	Open-air; Lake shore	3	\N	-748	1	-1692	\N	C	2019-12-20 22:14:28.053842+00	647
1	1691	Open-air; Lake shore	3	\N	-747	1	-1691	\N	C	2019-12-20 22:14:28.053842+00	648
1	1690	Open-air; Lake shore	3	\N	-746	1	-1690	\N	C	2019-12-20 22:14:28.053842+00	649
1	1689	Open-air; Lake shore	3	\N	-745	1	-1689	\N	C	2019-12-20 22:14:28.053842+00	650
1	1688	Open-air; Lake shore	3	\N	-744	1	-1688	\N	C	2019-12-20 22:14:28.053842+00	651
1	1687	Open-air; Lake shore	3	\N	-743	1	-1687	\N	C	2019-12-20 22:14:28.053842+00	652
1	1686	Open-air; Lake shore	3	\N	-742	1	-1686	\N	C	2019-12-20 22:14:28.053842+00	653
1	1685	Open-air; Lake shore	3	\N	-741	1	-1685	\N	C	2019-12-20 22:14:28.053842+00	654
1	1684	Open-air; Lake shore	3	\N	-740	1	-1684	\N	C	2019-12-20 22:14:28.053842+00	655
1	1683	Open-air; Lake shore	3	\N	-739	1	-1683	\N	C	2019-12-20 22:14:28.053842+00	656
1	1682	Open-air; Lake shore	3	\N	-738	1	-1682	\N	C	2019-12-20 22:14:28.053842+00	657
1	1681	Open-air; Lake shore	3	\N	-737	1	-1681	\N	C	2019-12-20 22:14:28.053842+00	658
1	1680	Open-air; Lake shore	3	\N	-736	1	-1680	\N	C	2019-12-20 22:14:28.053842+00	659
1	1679	Open-air; Lake shore	3	\N	-735	1	-1679	\N	C	2019-12-20 22:14:28.053842+00	660
1	1678	Open-air; Lake shore	3	\N	-734	1	-1678	\N	C	2019-12-20 22:14:28.053842+00	661
1	1677	Open-air; Lake shore	3	\N	-733	1	-1677	\N	C	2019-12-20 22:14:28.053842+00	662
1	1676	Open-air; Lake shore	3	\N	-732	1	-1676	\N	C	2019-12-20 22:14:28.053842+00	663
1	1675	Open-air; Lake shore	3	\N	-731	1	-1675	\N	C	2019-12-20 22:14:28.053842+00	664
1	1674	Open-air; Lake shore	3	\N	-730	1	-1674	\N	C	2019-12-20 22:14:28.053842+00	665
1	1673	Open-air; Lake shore	3	\N	-729	1	-1673	\N	C	2019-12-20 22:14:28.053842+00	666
1	1672	Open-air; Lake shore	3	\N	-728	1	-1672	\N	C	2019-12-20 22:14:28.053842+00	667
1	1671	Open-air; Lake shore	3	\N	-727	1	-1671	\N	C	2019-12-20 22:14:28.053842+00	668
1	1670	Open-air; Lake shore	3	\N	-726	1	-1670	\N	C	2019-12-20 22:14:28.053842+00	669
1	1669	Open-air; Lake shore	3	\N	-725	1	-1669	\N	C	2019-12-20 22:14:28.053842+00	670
1	1668	Open-air; Lake shore	3	\N	-724	1	-1668	\N	C	2019-12-20 22:14:28.053842+00	671
1	1667	Open-air; Lake shore	3	\N	-723	1	-1667	\N	C	2019-12-20 22:14:28.053842+00	672
1	1666	Open-air; Lake shore	3	\N	-722	1	-1666	\N	C	2019-12-20 22:14:28.053842+00	673
1	1665	Open-air; Lake shore	3	\N	-721	1	-1665	\N	C	2019-12-20 22:14:28.053842+00	674
1	1664	Open-air; Lake shore	3	\N	-720	1	-1664	\N	C	2019-12-20 22:14:28.053842+00	675
1	1663	Open-air; Lake shore	3	\N	-719	1	-1663	\N	C	2019-12-20 22:14:28.053842+00	676
1	1662	Open-air; Lake shore	3	\N	-718	1	-1662	\N	C	2019-12-20 22:14:28.053842+00	677
1	1661	Open-air; Lake shore	3	\N	-717	1	-1661	\N	C	2019-12-20 22:14:28.053842+00	678
1	1660	Open-air; Lake shore	3	\N	-716	1	-1660	\N	C	2019-12-20 22:14:28.053842+00	679
1	1659	Open-air; Lake shore	3	\N	-715	1	-1659	\N	C	2019-12-20 22:14:28.053842+00	680
1	1658	Open-air; Lake shore	3	\N	-714	1	-1658	\N	C	2019-12-20 22:14:28.053842+00	681
1	1657	Open-air; Lake shore	3	\N	-713	1	-1657	\N	C	2019-12-20 22:14:28.053842+00	682
1	1656	Open-air; Lake shore	3	\N	-712	1	-1656	\N	C	2019-12-20 22:14:28.053842+00	683
1	1655	Open-air; Lake shore	3	\N	-711	1	-1655	\N	C	2019-12-20 22:14:28.053842+00	684
1	1654	Open-air; Lake shore	3	\N	-710	1	-1654	\N	C	2019-12-20 22:14:28.053842+00	685
1	1653	Open-air; Lake shore	3	\N	-709	1	-1653	\N	C	2019-12-20 22:14:28.053842+00	686
1	1652	Open-air; Lake shore	3	\N	-708	1	-1652	\N	C	2019-12-20 22:14:28.053842+00	687
1	1651	Open-air; Lake shore	3	\N	-707	1	-1651	\N	C	2019-12-20 22:14:28.053842+00	688
1	1650	Open-air; Lake shore	3	\N	-706	1	-1650	\N	C	2019-12-20 22:14:28.053842+00	689
1	1649	Open-air; Lake shore	3	\N	-705	1	-1649	\N	C	2019-12-20 22:14:28.053842+00	690
1	1648	Open-air; Lake shore	3	\N	-704	1	-1648	\N	C	2019-12-20 22:14:28.053842+00	691
1	1647	Open-air; Lake shore	3	\N	-703	1	-1647	\N	C	2019-12-20 22:14:28.053842+00	692
1	1646	Open-air; Lake shore	3	\N	-702	1	-1646	\N	C	2019-12-20 22:14:28.053842+00	693
1	1645	Open-air; Lake shore	3	\N	-701	1	-1645	\N	C	2019-12-20 22:14:28.053842+00	694
1	1644	Open-air; Lake shore	3	\N	-700	1	-1644	\N	C	2019-12-20 22:14:28.053842+00	695
1	1643	Open-air; Close to the coast	3	\N	-699	1	-1643	\N	C	2019-12-20 22:14:28.053842+00	696
1	1642	Open-air; Close to the coast	3	\N	-698	1	-1642	\N	C	2019-12-20 22:14:28.053842+00	697
1	1641	Open-air; Close to the coast	3	\N	-697	1	-1641	\N	C	2019-12-20 22:14:28.053842+00	698
1	1640	Open-air; Close to the coast	3	\N	-696	1	-1640	\N	C	2019-12-20 22:14:28.053842+00	699
1	1639	Open-air; Close to the coast	3	\N	-695	1	-1639	\N	C	2019-12-20 22:14:28.053842+00	700
1	1638	Open-air; Close to the coast	3	\N	-694	1	-1638	\N	C	2019-12-20 22:14:28.053842+00	701
1	1637	Open-air; Close to the coast	3	\N	-693	1	-1637	\N	C	2019-12-20 22:14:28.053842+00	702
1	1636	Open-air; Close to the coast	3	\N	-692	1	-1636	\N	C	2019-12-20 22:14:28.053842+00	703
1	1635	Open-air; Close to the coast	3	\N	-691	1	-1635	\N	C	2019-12-20 22:14:28.053842+00	704
1	1634	Open-air; Close to the coast	3	\N	-690	1	-1634	\N	C	2019-12-20 22:14:28.053842+00	705
1	1633	Open-air; Close to the coast	3	\N	-689	1	-1633	\N	C	2019-12-20 22:14:28.053842+00	706
1	1632	Open-air; Close to the coast	3	\N	-688	1	-1632	\N	C	2019-12-20 22:14:28.053842+00	707
1	1631	Open-air; Close to the coast	3	\N	-687	1	-1631	\N	C	2019-12-20 22:14:28.053842+00	708
1	1630	Open-air; Close to the coast	3	\N	-686	1	-1630	\N	C	2019-12-20 22:14:28.053842+00	709
1	1629	Open-air; Close to the coast	3	\N	-685	1	-1629	\N	C	2019-12-20 22:14:28.053842+00	710
1	1628	Open-air; Close to the coast	3	\N	-684	1	-1628	\N	C	2019-12-20 22:14:28.053842+00	711
1	1627	Open-air; Close to the coast	3	\N	-683	1	-1627	\N	C	2019-12-20 22:14:28.053842+00	712
1	1626	Open-air; Close to the coast	3	\N	-682	1	-1626	\N	C	2019-12-20 22:14:28.053842+00	713
1	1625	Open-air; Close to the coast	3	\N	-681	1	-1625	\N	C	2019-12-20 22:14:28.053842+00	714
1	1624	Open-air; Close to the coast	3	\N	-680	1	-1624	\N	C	2019-12-20 22:14:28.053842+00	715
1	1623	Open-air; Close to the coast	3	\N	-679	1	-1623	\N	C	2019-12-20 22:14:28.053842+00	716
1	1622	Open-air; Close to the coast	3	\N	-678	1	-1622	\N	C	2019-12-20 22:14:28.053842+00	717
1	1621	Open-air; Close to the coast	3	\N	-677	1	-1621	\N	C	2019-12-20 22:14:28.053842+00	718
1	1620	Shell midden; Inland	3	\N	-676	1	-1620	\N	C	2019-12-20 22:14:28.053842+00	719
1	1619	Shell midden; Inland	3	\N	-675	1	-1619	\N	C	2019-12-20 22:14:28.053842+00	720
1	1618	Shell midden; Inland	3	\N	-674	1	-1618	\N	C	2019-12-20 22:14:28.053842+00	721
1	1617	Shell midden; Inland	3	\N	-673	1	-1617	\N	C	2019-12-20 22:14:28.053842+00	722
1	1616	Shell midden; Inland	3	\N	-672	1	-1616	\N	C	2019-12-20 22:14:28.053842+00	723
1	1615	Shell midden; Inland	3	\N	-671	1	-1615	\N	C	2019-12-20 22:14:28.053842+00	724
1	1614	Shell midden; Inland	3	\N	-670	1	-1614	\N	C	2019-12-20 22:14:28.053842+00	725
1	1613	Shell midden; Inland	3	\N	-669	1	-1613	\N	C	2019-12-20 22:14:28.053842+00	726
1	1612	Shell midden; Inland	3	\N	-668	1	-1612	\N	C	2019-12-20 22:14:28.053842+00	727
1	1611	Shell midden; Inland	3	\N	-667	1	-1611	\N	C	2019-12-20 22:14:28.053842+00	728
1	1610	Shell midden; Inland	3	\N	-666	1	-1610	\N	C	2019-12-20 22:14:28.053842+00	729
1	1609	Shell midden; Inland	3	\N	-665	1	-1609	\N	C	2019-12-20 22:14:28.053842+00	730
1	1608	Shell midden; Inland	3	\N	-664	1	-1608	\N	C	2019-12-20 22:14:28.053842+00	731
1	1607	Shell midden; Inland	3	\N	-663	1	-1607	\N	C	2019-12-20 22:14:28.053842+00	732
1	1606	Shell midden; Inland	3	\N	-662	1	-1606	\N	C	2019-12-20 22:14:28.053842+00	733
1	1605	Shell midden; Inland	3	\N	-661	1	-1605	\N	C	2019-12-20 22:14:28.053842+00	734
1	1604	Shell midden; Inland	3	\N	-660	1	-1604	\N	C	2019-12-20 22:14:28.053842+00	735
1	1603	Shell midden; Inland	3	\N	-659	1	-1603	\N	C	2019-12-20 22:14:28.053842+00	736
1	1602	Shell midden; Inland	3	\N	-658	1	-1602	\N	C	2019-12-20 22:14:28.053842+00	737
1	1601	Shell midden; Inland	3	\N	-657	1	-1601	\N	C	2019-12-20 22:14:28.053842+00	738
1	1600	Shell midden; Inland	3	\N	-656	1	-1600	\N	C	2019-12-20 22:14:28.053842+00	739
1	1599	Shell midden; Inland	3	\N	-655	1	-1599	\N	C	2019-12-20 22:14:28.053842+00	740
1	1598	Shell midden; Inland	3	\N	-654	1	-1598	\N	C	2019-12-20 22:14:28.053842+00	741
1	1597	Shell midden; Inland	3	\N	-653	1	-1597	\N	C	2019-12-20 22:14:28.053842+00	742
1	1596	Shell midden; Inland	3	\N	-652	1	-1596	\N	C	2019-12-20 22:14:28.053842+00	743
1	1595	Shell midden; Inland	3	\N	-651	1	-1595	\N	C	2019-12-20 22:14:28.053842+00	744
1	1594	Shell midden; Inland	3	\N	-650	1	-1594	\N	C	2019-12-20 22:14:28.053842+00	745
1	1593	Shell midden; Inland	3	\N	-649	1	-1593	\N	C	2019-12-20 22:14:28.053842+00	746
1	1218	Open-air; Inland	3	\N	-274	1	-1218	\N	C	2019-12-20 22:14:28.053842+00	1121
1	1592	Shell midden; Inland	3	\N	-648	1	-1592	\N	C	2019-12-20 22:14:28.053842+00	747
1	1591	Shell midden; Inland	3	\N	-647	1	-1591	\N	C	2019-12-20 22:14:28.053842+00	748
1	1590	Shell midden; Inland	3	\N	-646	1	-1590	\N	C	2019-12-20 22:14:28.053842+00	749
1	1589	Shell midden; Inland	3	\N	-645	1	-1589	\N	C	2019-12-20 22:14:28.053842+00	750
1	1588	Shell midden; Inland	3	\N	-644	1	-1588	\N	C	2019-12-20 22:14:28.053842+00	751
1	1587	Shell midden; Inland	3	\N	-643	1	-1587	\N	C	2019-12-20 22:14:28.053842+00	752
1	1586	Shell midden; Inland	3	\N	-642	1	-1586	\N	C	2019-12-20 22:14:28.053842+00	753
1	1585	Shell midden; Inland	3	\N	-641	1	-1585	\N	C	2019-12-20 22:14:28.053842+00	754
1	1584	Shell midden; Inland	3	\N	-640	1	-1584	\N	C	2019-12-20 22:14:28.053842+00	755
1	1583	Shell midden; Inland	3	\N	-639	1	-1583	\N	C	2019-12-20 22:14:28.053842+00	756
1	1582	Shell midden; Inland	3	\N	-638	1	-1582	\N	C	2019-12-20 22:14:28.053842+00	757
1	1581	Shell midden; Inland	3	\N	-637	1	-1581	\N	C	2019-12-20 22:14:28.053842+00	758
1	1580	Shell midden; Inland	3	\N	-636	1	-1580	\N	C	2019-12-20 22:14:28.053842+00	759
1	1579	Shell midden; Inland	3	\N	-635	1	-1579	\N	C	2019-12-20 22:14:28.053842+00	760
1	1578	Shell midden; Inland	3	\N	-634	1	-1578	\N	C	2019-12-20 22:14:28.053842+00	761
1	1577	Shell midden; Inland	3	\N	-633	1	-1577	\N	C	2019-12-20 22:14:28.053842+00	762
1	1576	Shell midden; Inland	3	\N	-632	1	-1576	\N	C	2019-12-20 22:14:28.053842+00	763
1	1575	Shell midden; Inland	3	\N	-631	1	-1575	\N	C	2019-12-20 22:14:28.053842+00	764
1	1574	Shell midden; Inland	3	\N	-630	1	-1574	\N	C	2019-12-20 22:14:28.053842+00	765
1	1573	Shell midden; Inland	3	\N	-629	1	-1573	\N	C	2019-12-20 22:14:28.053842+00	766
1	1572	Shell midden; Inland	3	\N	-628	1	-1572	\N	C	2019-12-20 22:14:28.053842+00	767
1	1571	Shell midden; Inland	3	\N	-627	1	-1571	\N	C	2019-12-20 22:14:28.053842+00	768
1	1570	Shell midden; Inland	3	\N	-626	1	-1570	\N	C	2019-12-20 22:14:28.053842+00	769
1	1569	Shell midden; Inland	3	\N	-625	1	-1569	\N	C	2019-12-20 22:14:28.053842+00	770
1	1568	Shell midden; Inland	3	\N	-624	1	-1568	\N	C	2019-12-20 22:14:28.053842+00	771
1	1567	Shell midden; Inland	3	\N	-623	1	-1567	\N	C	2019-12-20 22:14:28.053842+00	772
1	1566	Shell midden; Inland	3	\N	-622	1	-1566	\N	C	2019-12-20 22:14:28.053842+00	773
1	1565	Shell midden; Inland	3	\N	-621	1	-1565	\N	C	2019-12-20 22:14:28.053842+00	774
1	1564	Shell midden; Inland	3	\N	-620	1	-1564	\N	C	2019-12-20 22:14:28.053842+00	775
1	1563	Shell midden; Inland	3	\N	-619	1	-1563	\N	C	2019-12-20 22:14:28.053842+00	776
1	1562	Shell midden; Inland	3	\N	-618	1	-1562	\N	C	2019-12-20 22:14:28.053842+00	777
1	1561	Shell midden; Inland	3	\N	-617	1	-1561	\N	C	2019-12-20 22:14:28.053842+00	778
1	1560	Shell midden; Inland	3	\N	-616	1	-1560	\N	C	2019-12-20 22:14:28.053842+00	779
1	1559	Shell midden; Inland	3	\N	-615	1	-1559	\N	C	2019-12-20 22:14:28.053842+00	780
1	1558	Shell midden; Inland	3	\N	-614	1	-1558	\N	C	2019-12-20 22:14:28.053842+00	781
1	1557	Shell midden; Close to the coast	3	\N	-613	1	-1557	\N	C	2019-12-20 22:14:28.053842+00	782
1	1556	Shell midden; Close to the coast	3	\N	-612	1	-1556	\N	C	2019-12-20 22:14:28.053842+00	783
1	1555	Shell midden; Close to the coast	3	\N	-611	1	-1555	\N	C	2019-12-20 22:14:28.053842+00	784
1	1554	Shell midden; Close to the coast	3	\N	-610	1	-1554	\N	C	2019-12-20 22:14:28.053842+00	785
1	1553	Shell midden; Close to the coast	3	\N	-609	1	-1553	\N	C	2019-12-20 22:14:28.053842+00	786
1	1552	Shell midden; Close to the coast	3	\N	-608	1	-1552	\N	C	2019-12-20 22:14:28.053842+00	787
1	1551	Shell midden; Close to the coast	3	\N	-607	1	-1551	\N	C	2019-12-20 22:14:28.053842+00	788
1	1550	Shell midden; Close to the coast	3	\N	-606	1	-1550	\N	C	2019-12-20 22:14:28.053842+00	789
1	1549	Shell midden; Close to the coast	3	\N	-605	1	-1549	\N	C	2019-12-20 22:14:28.053842+00	790
1	1548	Shell midden; Close to the coast	3	\N	-604	1	-1548	\N	C	2019-12-20 22:14:28.053842+00	791
1	1547	Shell midden; Close to the coast	3	\N	-603	1	-1547	\N	C	2019-12-20 22:14:28.053842+00	792
1	1546	Shell midden; Close to the coast	3	\N	-602	1	-1546	\N	C	2019-12-20 22:14:28.053842+00	793
1	1545	Shell midden; Close to the coast	3	\N	-601	1	-1545	\N	C	2019-12-20 22:14:28.053842+00	794
1	1544	Shell midden; Close to the coast	3	\N	-600	1	-1544	\N	C	2019-12-20 22:14:28.053842+00	795
1	1543	Shell midden; Close to the coast	3	\N	-599	1	-1543	\N	C	2019-12-20 22:14:28.053842+00	796
1	1542	Shell midden; Close to the coast	3	\N	-598	1	-1542	\N	C	2019-12-20 22:14:28.053842+00	797
1	1541	Open-air; Close to the coast	3	\N	-597	1	-1541	\N	C	2019-12-20 22:14:28.053842+00	798
1	1540	Open-air; Close to the coast	3	\N	-596	1	-1540	\N	C	2019-12-20 22:14:28.053842+00	799
1	1539	Open-air; Close to the coast	3	\N	-595	1	-1539	\N	C	2019-12-20 22:14:28.053842+00	800
1	1538	Open-air; Close to the coast	3	\N	-594	1	-1538	\N	C	2019-12-20 22:14:28.053842+00	801
1	1537	Open-air; Close to the coast	3	\N	-593	1	-1537	\N	C	2019-12-20 22:14:28.053842+00	802
1	1536	Open-air; Close to the coast	3	\N	-592	1	-1536	\N	C	2019-12-20 22:14:28.053842+00	803
1	1535	Open-air; Close to the coast	3	\N	-591	1	-1535	\N	C	2019-12-20 22:14:28.053842+00	804
1	1534	Open-air; Close to the coast	3	\N	-590	1	-1534	\N	C	2019-12-20 22:14:28.053842+00	805
1	1533	Open-air; Close to the coast	3	\N	-589	1	-1533	\N	C	2019-12-20 22:14:28.053842+00	806
1	1532	Open-air; Close to the coast	3	\N	-588	1	-1532	\N	C	2019-12-20 22:14:28.053842+00	807
1	1531	Open-air; Close to the coast	3	\N	-587	1	-1531	\N	C	2019-12-20 22:14:28.053842+00	808
1	1530	Open-air; Close to the coast	3	\N	-586	1	-1530	\N	C	2019-12-20 22:14:28.053842+00	809
1	1529	Open-air; Close to the coast	3	\N	-585	1	-1529	\N	C	2019-12-20 22:14:28.053842+00	810
1	1528	Open-air; Close to the coast	3	\N	-584	1	-1528	\N	C	2019-12-20 22:14:28.053842+00	811
1	1527	Open-air; Close to the coast	3	\N	-583	1	-1527	\N	C	2019-12-20 22:14:28.053842+00	812
1	1526	Open-air; Close to the coast	3	\N	-582	1	-1526	\N	C	2019-12-20 22:14:28.053842+00	813
1	1525	Open-air; Close to the coast	3	\N	-581	1	-1525	\N	C	2019-12-20 22:14:28.053842+00	814
1	1524	Open-air; Close to the coast	3	\N	-580	1	-1524	\N	C	2019-12-20 22:14:28.053842+00	815
1	1523	Open-air; Close to the coast	3	\N	-579	1	-1523	\N	C	2019-12-20 22:14:28.053842+00	816
1	1522	Open-air; Close to the coast	3	\N	-578	1	-1522	\N	C	2019-12-20 22:14:28.053842+00	817
1	1521	Open-air; Close to the coast	3	\N	-577	1	-1521	\N	C	2019-12-20 22:14:28.053842+00	818
1	1520	Open-air; Close to the coast	3	\N	-576	1	-1520	\N	C	2019-12-20 22:14:28.053842+00	819
1	1519	Open-air; Close to the coast	3	\N	-575	1	-1519	\N	C	2019-12-20 22:14:28.053842+00	820
1	1518	Open-air; Close to the coast	3	\N	-574	1	-1518	\N	C	2019-12-20 22:14:28.053842+00	821
1	1517	Open-air; Close to the coast	3	\N	-573	1	-1517	\N	C	2019-12-20 22:14:28.053842+00	822
1	1516	Open-air; Close to the coast	3	\N	-572	1	-1516	\N	C	2019-12-20 22:14:28.053842+00	823
1	1515	Open-air; Close to the coast	3	\N	-571	1	-1515	\N	C	2019-12-20 22:14:28.053842+00	824
1	1514	Open-air; Close to the coast	3	\N	-570	1	-1514	\N	C	2019-12-20 22:14:28.053842+00	825
1	1513	Open-air; Close to the coast	3	\N	-569	1	-1513	\N	C	2019-12-20 22:14:28.053842+00	826
1	1512	Open-air; Close to the coast	3	\N	-568	1	-1512	\N	C	2019-12-20 22:14:28.053842+00	827
1	1511	Open-air; Close to the coast	3	\N	-567	1	-1511	\N	C	2019-12-20 22:14:28.053842+00	828
1	1510	Open-air; Close to the coast	3	\N	-566	1	-1510	\N	C	2019-12-20 22:14:28.053842+00	829
1	1509	Open-air; Close to the coast	3	\N	-565	1	-1509	\N	C	2019-12-20 22:14:28.053842+00	830
1	1508	Open-air; Close to the coast	3	\N	-564	1	-1508	\N	C	2019-12-20 22:14:28.053842+00	831
1	1507	Open-air; Close to the coast	3	\N	-563	1	-1507	\N	C	2019-12-20 22:14:28.053842+00	832
1	1506	Open-air; Close to the coast	3	\N	-562	1	-1506	\N	C	2019-12-20 22:14:28.053842+00	833
1	1505	Open-air; Close to the coast	3	\N	-561	1	-1505	\N	C	2019-12-20 22:14:28.053842+00	834
1	1504	Open-air; Close to the coast	3	\N	-560	1	-1504	\N	C	2019-12-20 22:14:28.053842+00	835
1	1503	Open-air; Close to the coast	3	\N	-559	1	-1503	\N	C	2019-12-20 22:14:28.053842+00	836
1	1502	Open-air; Close to the coast	3	\N	-558	1	-1502	\N	C	2019-12-20 22:14:28.053842+00	837
1	1501	Open-air; Close to the coast	3	\N	-557	1	-1501	\N	C	2019-12-20 22:14:28.053842+00	838
1	1500	Open-air; Close to the coast	3	\N	-556	1	-1500	\N	C	2019-12-20 22:14:28.053842+00	839
1	1499	Open-air; Close to the coast	3	\N	-555	1	-1499	\N	C	2019-12-20 22:14:28.053842+00	840
1	1498	Open-air; Close to the coast	3	\N	-554	1	-1498	\N	C	2019-12-20 22:14:28.053842+00	841
1	1497	Open-air; Close to the coast	3	\N	-553	1	-1497	\N	C	2019-12-20 22:14:28.053842+00	842
1	1496	Open-air; Close to the coast	3	\N	-552	1	-1496	\N	C	2019-12-20 22:14:28.053842+00	843
1	1495	Open-air; Close to the coast	3	\N	-551	1	-1495	\N	C	2019-12-20 22:14:28.053842+00	844
1	1494	Open-air; Close to the coast	3	\N	-550	1	-1494	\N	C	2019-12-20 22:14:28.053842+00	845
1	1493	Open-air; Close to the coast	3	\N	-549	1	-1493	\N	C	2019-12-20 22:14:28.053842+00	846
1	1492	Open-air; Close to the coast	3	\N	-548	1	-1492	\N	C	2019-12-20 22:14:28.053842+00	847
1	1491	Open-air; Close to the coast	3	\N	-547	1	-1491	\N	C	2019-12-20 22:14:28.053842+00	848
1	1490	Open-air; Close to the coast	3	\N	-546	1	-1490	\N	C	2019-12-20 22:14:28.053842+00	849
1	1489	Open-air; Close to the coast	3	\N	-545	1	-1489	\N	C	2019-12-20 22:14:28.053842+00	850
1	1488	Open-air; Close to the coast	3	\N	-544	1	-1488	\N	C	2019-12-20 22:14:28.053842+00	851
1	1487	Open-air; Close to the coast	3	\N	-543	1	-1487	\N	C	2019-12-20 22:14:28.053842+00	852
1	1486	Open-air; Close to the coast	3	\N	-542	1	-1486	\N	C	2019-12-20 22:14:28.053842+00	853
1	1485	Open-air; Close to the coast	3	\N	-541	1	-1485	\N	C	2019-12-20 22:14:28.053842+00	854
1	1484	Open-air; Close to the coast	3	\N	-540	1	-1484	\N	C	2019-12-20 22:14:28.053842+00	855
1	1483	Open-air; Close to the coast	3	\N	-539	1	-1483	\N	C	2019-12-20 22:14:28.053842+00	856
1	1482	Open-air; Close to the coast	3	\N	-538	1	-1482	\N	C	2019-12-20 22:14:28.053842+00	857
1	1481	Open-air; Close to the coast	3	\N	-537	1	-1481	\N	C	2019-12-20 22:14:28.053842+00	858
1	1480	Open-air; Close to the coast	3	\N	-536	1	-1480	\N	C	2019-12-20 22:14:28.053842+00	859
1	1479	Open-air; Close to the coast	3	\N	-535	1	-1479	\N	C	2019-12-20 22:14:28.053842+00	860
1	1478	Open-air; Close to the coast	3	\N	-534	1	-1478	\N	C	2019-12-20 22:14:28.053842+00	861
1	1477	Open-air; Close to the coast	3	\N	-533	1	-1477	\N	C	2019-12-20 22:14:28.053842+00	862
1	1476	Open-air; Close to the coast	3	\N	-532	1	-1476	\N	C	2019-12-20 22:14:28.053842+00	863
1	1475	Open-air; Close to the coast	3	\N	-531	1	-1475	\N	C	2019-12-20 22:14:28.053842+00	864
1	1474	Open-air; Close to the coast	3	\N	-530	1	-1474	\N	C	2019-12-20 22:14:28.053842+00	865
1	1473	Open-air; Close to the coast	3	\N	-529	1	-1473	\N	C	2019-12-20 22:14:28.053842+00	866
1	1472	Open-air; Close to the coast	3	\N	-528	1	-1472	\N	C	2019-12-20 22:14:28.053842+00	867
1	1471	Open-air; Close to the coast	3	\N	-527	1	-1471	\N	C	2019-12-20 22:14:28.053842+00	868
1	1470	Open-air; Close to the coast	3	\N	-526	1	-1470	\N	C	2019-12-20 22:14:28.053842+00	869
1	1469	Open-air; Close to the coast	3	\N	-525	1	-1469	\N	C	2019-12-20 22:14:28.053842+00	870
1	1468	Open-air; Close to the coast	3	\N	-524	1	-1468	\N	C	2019-12-20 22:14:28.053842+00	871
1	1467	Open-air; Close to the coast	3	\N	-523	1	-1467	\N	C	2019-12-20 22:14:28.053842+00	872
1	1466	Open-air; Close to the coast	3	\N	-522	1	-1466	\N	C	2019-12-20 22:14:28.053842+00	873
1	1465	Open-air; Close to the coast	3	\N	-521	1	-1465	\N	C	2019-12-20 22:14:28.053842+00	874
1	1464	Open-air; Close to the coast	3	\N	-520	1	-1464	\N	C	2019-12-20 22:14:28.053842+00	875
1	1463	Open-air; Close to the coast	3	\N	-519	1	-1463	\N	C	2019-12-20 22:14:28.053842+00	876
1	1462	Open-air; Close to the coast	3	\N	-518	1	-1462	\N	C	2019-12-20 22:14:28.053842+00	877
1	1461	Open-air; Close to the coast	3	\N	-517	1	-1461	\N	C	2019-12-20 22:14:28.053842+00	878
1	1460	Open-air; Close to the coast	3	\N	-516	1	-1460	\N	C	2019-12-20 22:14:28.053842+00	879
1	1459	Open-air; Close to the coast	3	\N	-515	1	-1459	\N	C	2019-12-20 22:14:28.053842+00	880
1	1458	Open-air; Close to the coast	3	\N	-514	1	-1458	\N	C	2019-12-20 22:14:28.053842+00	881
1	1457	Open-air; Close to the coast	3	\N	-513	1	-1457	\N	C	2019-12-20 22:14:28.053842+00	882
1	1456	Open-air; Close to the coast	3	\N	-512	1	-1456	\N	C	2019-12-20 22:14:28.053842+00	883
1	1455	Open-air; Close to the coast	3	\N	-511	1	-1455	\N	C	2019-12-20 22:14:28.053842+00	884
1	1454	Open-air; Close to the coast	3	\N	-510	1	-1454	\N	C	2019-12-20 22:14:28.053842+00	885
1	1453	Open-air; Close to the coast	3	\N	-509	1	-1453	\N	C	2019-12-20 22:14:28.053842+00	886
1	1452	Open-air; Close to the coast	3	\N	-508	1	-1452	\N	C	2019-12-20 22:14:28.053842+00	887
1	1451	Open-air; Close to the coast	3	\N	-507	1	-1451	\N	C	2019-12-20 22:14:28.053842+00	888
1	1450	Open-air; Close to the coast	3	\N	-506	1	-1450	\N	C	2019-12-20 22:14:28.053842+00	889
1	1449	Open-air; Close to the coast	3	\N	-505	1	-1449	\N	C	2019-12-20 22:14:28.053842+00	890
1	1448	Open-air; Close to the coast	3	\N	-504	1	-1448	\N	C	2019-12-20 22:14:28.053842+00	891
1	1447	Open-air; Close to the coast	3	\N	-503	1	-1447	\N	C	2019-12-20 22:14:28.053842+00	892
1	1446	Open-air; Close to the coast	3	\N	-502	1	-1446	\N	C	2019-12-20 22:14:28.053842+00	893
1	1445	Open-air; Close to the coast	3	\N	-501	1	-1445	\N	C	2019-12-20 22:14:28.053842+00	894
1	1444	Open-air; Close to the coast	3	\N	-500	1	-1444	\N	C	2019-12-20 22:14:28.053842+00	895
1	1443	Open-air; Close to the coast	3	\N	-499	1	-1443	\N	C	2019-12-20 22:14:28.053842+00	896
1	1442	Open-air; Close to the coast	3	\N	-498	1	-1442	\N	C	2019-12-20 22:14:28.053842+00	897
1	1441	Open-air; Close to the coast	3	\N	-497	1	-1441	\N	C	2019-12-20 22:14:28.053842+00	898
1	1440	Open-air; Close to the coast	3	\N	-496	1	-1440	\N	C	2019-12-20 22:14:28.053842+00	899
1	1439	Open-air; Close to the coast	3	\N	-495	1	-1439	\N	C	2019-12-20 22:14:28.053842+00	900
1	1438	Open-air; Close to the coast	3	\N	-494	1	-1438	\N	C	2019-12-20 22:14:28.053842+00	901
1	1437	Open-air; Close to the coast	3	\N	-493	1	-1437	\N	C	2019-12-20 22:14:28.053842+00	902
1	1436	Open-air; Inland	3	\N	-492	1	-1436	\N	C	2019-12-20 22:14:28.053842+00	903
1	1435	Open-air; Inland	3	\N	-491	1	-1435	\N	C	2019-12-20 22:14:28.053842+00	904
1	1434	Open-air; Inland	3	\N	-490	1	-1434	\N	C	2019-12-20 22:14:28.053842+00	905
1	1433	Open-air; Lake shore	3	\N	-489	1	-1433	\N	C	2019-12-20 22:14:28.053842+00	906
1	1432	Open-air; Inland	3	\N	-488	1	-1432	\N	C	2019-12-20 22:14:28.053842+00	907
1	1431	Open-air; Inland	3	\N	-487	1	-1431	\N	C	2019-12-20 22:14:28.053842+00	908
1	1430	Open-air; Inland	3	\N	-486	1	-1430	\N	C	2019-12-20 22:14:28.053842+00	909
1	1429	Open-air; Inland	3	\N	-485	1	-1429	\N	C	2019-12-20 22:14:28.053842+00	910
1	1428	Open-air; Inland	3	\N	-484	1	-1428	\N	C	2019-12-20 22:14:28.053842+00	911
1	1427	Open-air; Inland	3	\N	-483	1	-1427	\N	C	2019-12-20 22:14:28.053842+00	912
1	1426	Open-air; Inland	3	\N	-482	1	-1426	\N	C	2019-12-20 22:14:28.053842+00	913
1	1425	Open-air; Inland	3	\N	-481	1	-1425	\N	C	2019-12-20 22:14:28.053842+00	914
1	1424	Open-air; Inland	3	\N	-480	1	-1424	\N	C	2019-12-20 22:14:28.053842+00	915
1	1423	Open-air; Inland	3	\N	-479	1	-1423	\N	C	2019-12-20 22:14:28.053842+00	916
1	1422	Open-air; Inland	3	\N	-478	1	-1422	\N	C	2019-12-20 22:14:28.053842+00	917
1	1421	Open-air; Inland	3	\N	-477	1	-1421	\N	C	2019-12-20 22:14:28.053842+00	918
1	1420	Open-air; Inland	3	\N	-476	1	-1420	\N	C	2019-12-20 22:14:28.053842+00	919
1	1419	Open-air; Inland	3	\N	-475	1	-1419	\N	C	2019-12-20 22:14:28.053842+00	920
1	1418	Open-air; Inland	3	\N	-474	1	-1418	\N	C	2019-12-20 22:14:28.053842+00	921
1	1417	Open-air; Inland	3	\N	-473	1	-1417	\N	C	2019-12-20 22:14:28.053842+00	922
1	1416	Open-air; Inland	3	\N	-472	1	-1416	\N	C	2019-12-20 22:14:28.053842+00	923
1	1415	Open-air; Inland	3	\N	-471	1	-1415	\N	C	2019-12-20 22:14:28.053842+00	924
1	1414	Open-air; Inland	3	\N	-470	1	-1414	\N	C	2019-12-20 22:14:28.053842+00	925
1	1413	Open-air; Inland	3	\N	-469	1	-1413	\N	C	2019-12-20 22:14:28.053842+00	926
1	1412	Rock shelter/Cave; Inland	3	\N	-468	1	-1412	\N	C	2019-12-20 22:14:28.053842+00	927
1	1411	Rock shelter/Cave; Inland	3	\N	-467	1	-1411	\N	C	2019-12-20 22:14:28.053842+00	928
1	1410	Rock shelter/Cave; Inland	3	\N	-466	1	-1410	\N	C	2019-12-20 22:14:28.053842+00	929
1	1409	Rock shelter/Cave; Inland	3	\N	-465	1	-1409	\N	C	2019-12-20 22:14:28.053842+00	930
1	1408	Rock shelter/Cave; Inland	3	\N	-464	1	-1408	\N	C	2019-12-20 22:14:28.053842+00	931
1	1407	Rock shelter/Cave; Inland	3	\N	-463	1	-1407	\N	C	2019-12-20 22:14:28.053842+00	932
1	1406	Open-air; Inland	3	\N	-462	1	-1406	\N	C	2019-12-20 22:14:28.053842+00	933
1	1405	Open-air; Inland	3	\N	-461	1	-1405	\N	C	2019-12-20 22:14:28.053842+00	934
1	1404	Open-air; Inland	3	\N	-460	1	-1404	\N	C	2019-12-20 22:14:28.053842+00	935
1	1403	Open-air; Inland	3	\N	-459	1	-1403	\N	C	2019-12-20 22:14:28.053842+00	936
1	1402	Open-air; Inland	3	\N	-458	1	-1402	\N	C	2019-12-20 22:14:28.053842+00	937
1	1401	Open-air; Inland	3	\N	-457	1	-1401	\N	C	2019-12-20 22:14:28.053842+00	938
1	1400	Open-air; Inland	3	\N	-456	1	-1400	\N	C	2019-12-20 22:14:28.053842+00	939
1	1399	Open-air; Inland	3	\N	-455	1	-1399	\N	C	2019-12-20 22:14:28.053842+00	940
1	1398	Open-air; Inland	3	\N	-454	1	-1398	\N	C	2019-12-20 22:14:28.053842+00	941
1	1397	Open-air; Inland	3	\N	-453	1	-1397	\N	C	2019-12-20 22:14:28.053842+00	942
1	1396	Open-air; Inland	3	\N	-452	1	-1396	\N	C	2019-12-20 22:14:28.053842+00	943
1	1395	Open-air; Inland	3	\N	-451	1	-1395	\N	C	2019-12-20 22:14:28.053842+00	944
1	1394	Rock shelter/Cave; Inland	3	\N	-450	1	-1394	\N	C	2019-12-20 22:14:28.053842+00	945
1	1393	Open-air; Close to the coast	3	\N	-449	1	-1393	\N	C	2019-12-20 22:14:28.053842+00	946
1	1392	Open-air; Close to the coast	3	\N	-448	1	-1392	\N	C	2019-12-20 22:14:28.053842+00	947
1	1391	Open-air; Close to the coast	3	\N	-447	1	-1391	\N	C	2019-12-20 22:14:28.053842+00	948
1	1390	Open-air; Close to the coast	3	\N	-446	1	-1390	\N	C	2019-12-20 22:14:28.053842+00	949
1	1389	Open-air; Close to the coast	3	\N	-445	1	-1389	\N	C	2019-12-20 22:14:28.053842+00	950
1	1388	Open-air; Close to the coast	3	\N	-444	1	-1388	\N	C	2019-12-20 22:14:28.053842+00	951
1	1387	Open-air; Inland	3	\N	-443	1	-1387	\N	C	2019-12-20 22:14:28.053842+00	952
1	1386	Open-air; Inland	3	\N	-442	1	-1386	\N	C	2019-12-20 22:14:28.053842+00	953
1	1385	Open-air; Inland	3	\N	-441	1	-1385	\N	C	2019-12-20 22:14:28.053842+00	954
1	1384	Shell midden; Lake shore	3	\N	-440	1	-1384	\N	C	2019-12-20 22:14:28.053842+00	955
1	1383	Shell midden; Lake shore	3	\N	-439	1	-1383	\N	C	2019-12-20 22:14:28.053842+00	956
1	1382	Shell midden; Lake shore	3	\N	-438	1	-1382	\N	C	2019-12-20 22:14:28.053842+00	957
1	1381	Open-air; Close to the coast	3	\N	-437	1	-1381	\N	C	2019-12-20 22:14:28.053842+00	958
1	1380	Open-air; Close to the coast	3	\N	-436	1	-1380	\N	C	2019-12-20 22:14:28.053842+00	959
1	1379	Open-air; Close to the coast	3	\N	-435	1	-1379	\N	C	2019-12-20 22:14:28.053842+00	960
1	1378	Open-air; Close to the coast	3	\N	-434	1	-1378	\N	C	2019-12-20 22:14:28.053842+00	961
1	1377	Open-air; Close to the coast	3	\N	-433	1	-1377	\N	C	2019-12-20 22:14:28.053842+00	962
1	1376	Open-air; Close to the coast	3	\N	-432	1	-1376	\N	C	2019-12-20 22:14:28.053842+00	963
1	1375	Open-air; Close to the coast	3	\N	-431	1	-1375	\N	C	2019-12-20 22:14:28.053842+00	964
1	1374	Open-air; Close to the coast	3	\N	-430	1	-1374	\N	C	2019-12-20 22:14:28.053842+00	965
1	1373	Open-air; Close to the coast	3	\N	-429	1	-1373	\N	C	2019-12-20 22:14:28.053842+00	966
1	1372	Open-air; Close to the coast	3	\N	-428	1	-1372	\N	C	2019-12-20 22:14:28.053842+00	967
1	1371	Open-air; Close to the coast	3	\N	-427	1	-1371	\N	C	2019-12-20 22:14:28.053842+00	968
1	1370	Open-air; Close to the coast	3	\N	-426	1	-1370	\N	C	2019-12-20 22:14:28.053842+00	969
1	1369	Open-air; Close to the coast	3	\N	-425	1	-1369	\N	C	2019-12-20 22:14:28.053842+00	970
1	1368	Open-air; Close to the coast	3	\N	-424	1	-1368	\N	C	2019-12-20 22:14:28.053842+00	971
1	1367	Open-air; Close to the coast	3	\N	-423	1	-1367	\N	C	2019-12-20 22:14:28.053842+00	972
1	1366	Open-air; Close to the coast	3	\N	-422	1	-1366	\N	C	2019-12-20 22:14:28.053842+00	973
1	1365	Open-air; Close to the coast	3	\N	-421	1	-1365	\N	C	2019-12-20 22:14:28.053842+00	974
1	1364	Open-air; Close to the coast	3	\N	-420	1	-1364	\N	C	2019-12-20 22:14:28.053842+00	975
1	1363	Open-air; Close to the coast	3	\N	-419	1	-1363	\N	C	2019-12-20 22:14:28.053842+00	976
1	1362	Open-air; Close to the coast	3	\N	-418	1	-1362	\N	C	2019-12-20 22:14:28.053842+00	977
1	1361	Open-air; Close to the coast	3	\N	-417	1	-1361	\N	C	2019-12-20 22:14:28.053842+00	978
1	1360	Open-air; Close to the coast	3	\N	-416	1	-1360	\N	C	2019-12-20 22:14:28.053842+00	979
1	1359	Open-air; Close to the coast	3	\N	-415	1	-1359	\N	C	2019-12-20 22:14:28.053842+00	980
1	1358	Open-air; Close to the coast	3	\N	-414	1	-1358	\N	C	2019-12-20 22:14:28.053842+00	981
1	1357	Open-air; Close to the coast	3	\N	-413	1	-1357	\N	C	2019-12-20 22:14:28.053842+00	982
1	1356	Open-air; Close to the coast	3	\N	-412	1	-1356	\N	C	2019-12-20 22:14:28.053842+00	983
1	1355	Open-air; Close to the coast	3	\N	-411	1	-1355	\N	C	2019-12-20 22:14:28.053842+00	984
1	1354	Open-air; Close to the coast	3	\N	-410	1	-1354	\N	C	2019-12-20 22:14:28.053842+00	985
1	1353	Open-air; Close to the coast	3	\N	-409	1	-1353	\N	C	2019-12-20 22:14:28.053842+00	986
1	1352	Open-air; Close to the coast	3	\N	-408	1	-1352	\N	C	2019-12-20 22:14:28.053842+00	987
1	1351	Open-air; Close to the coast	3	\N	-407	1	-1351	\N	C	2019-12-20 22:14:28.053842+00	988
1	1350	Open-air; Close to the coast	3	\N	-406	1	-1350	\N	C	2019-12-20 22:14:28.053842+00	989
1	1349	Open-air; Close to the coast	3	\N	-405	1	-1349	\N	C	2019-12-20 22:14:28.053842+00	990
1	1348	Open-air; Close to the coast	3	\N	-404	1	-1348	\N	C	2019-12-20 22:14:28.053842+00	991
1	1347	Open-air; Close to the coast	3	\N	-403	1	-1347	\N	C	2019-12-20 22:14:28.053842+00	992
1	1346	Open-air; Close to the coast	3	\N	-402	1	-1346	\N	C	2019-12-20 22:14:28.053842+00	993
1	1345	Open-air; Close to the coast	3	\N	-401	1	-1345	\N	C	2019-12-20 22:14:28.053842+00	994
1	1344	Open-air; Close to the coast	3	\N	-400	1	-1344	\N	C	2019-12-20 22:14:28.053842+00	995
1	1343	Open-air; Close to the coast	3	\N	-399	1	-1343	\N	C	2019-12-20 22:14:28.053842+00	996
1	1342	Open-air; Close to the coast	3	\N	-398	1	-1342	\N	C	2019-12-20 22:14:28.053842+00	997
1	1341	Open-air; Inland	3	\N	-397	1	-1341	\N	C	2019-12-20 22:14:28.053842+00	998
1	1340	Open-air; Inland	3	\N	-396	1	-1340	\N	C	2019-12-20 22:14:28.053842+00	999
1	1339	Open-air; Inland	3	\N	-395	1	-1339	\N	C	2019-12-20 22:14:28.053842+00	1000
1	1338	Open-air; Inland	3	\N	-394	1	-1338	\N	C	2019-12-20 22:14:28.053842+00	1001
1	1337	Open-air; Inland	3	\N	-393	1	-1337	\N	C	2019-12-20 22:14:28.053842+00	1002
1	1336	Open-air; Inland	3	\N	-392	1	-1336	\N	C	2019-12-20 22:14:28.053842+00	1003
1	1335	Open-air; Inland	3	\N	-391	1	-1335	\N	C	2019-12-20 22:14:28.053842+00	1004
1	1334	Open-air; Inland	3	\N	-390	1	-1334	\N	C	2019-12-20 22:14:28.053842+00	1005
1	1333	Open-air; Inland	3	\N	-389	1	-1333	\N	C	2019-12-20 22:14:28.053842+00	1006
1	1332	Open-air; Inland	3	\N	-388	1	-1332	\N	C	2019-12-20 22:14:28.053842+00	1007
1	1331	Open-air; Inland	3	\N	-387	1	-1331	\N	C	2019-12-20 22:14:28.053842+00	1008
1	1330	Open-air; Inland	3	\N	-386	1	-1330	\N	C	2019-12-20 22:14:28.053842+00	1009
1	1329	Open-air; Inland	3	\N	-385	1	-1329	\N	C	2019-12-20 22:14:28.053842+00	1010
1	1328	Open-air; Inland	3	\N	-384	1	-1328	\N	C	2019-12-20 22:14:28.053842+00	1011
1	1327	Open-air; Inland	3	\N	-383	1	-1327	\N	C	2019-12-20 22:14:28.053842+00	1012
1	1326	Open-air; Inland	3	\N	-382	1	-1326	\N	C	2019-12-20 22:14:28.053842+00	1013
1	1325	Open-air; Inland	3	\N	-381	1	-1325	\N	C	2019-12-20 22:14:28.053842+00	1014
1	1324	Open-air; Inland	3	\N	-380	1	-1324	\N	C	2019-12-20 22:14:28.053842+00	1015
1	1323	Open-air; Inland	3	\N	-379	1	-1323	\N	C	2019-12-20 22:14:28.053842+00	1016
1	1322	Open-air; Inland	3	\N	-378	1	-1322	\N	C	2019-12-20 22:14:28.053842+00	1017
1	1321	Open-air; Inland	3	\N	-377	1	-1321	\N	C	2019-12-20 22:14:28.053842+00	1018
1	1320	Open-air; Inland	3	\N	-376	1	-1320	\N	C	2019-12-20 22:14:28.053842+00	1019
1	1319	Open-air; Inland	3	\N	-375	1	-1319	\N	C	2019-12-20 22:14:28.053842+00	1020
1	1318	Open-air; Inland	3	\N	-374	1	-1318	\N	C	2019-12-20 22:14:28.053842+00	1021
1	1317	Open-air; Inland	3	\N	-373	1	-1317	\N	C	2019-12-20 22:14:28.053842+00	1022
1	1316	Open-air; Inland	3	\N	-372	1	-1316	\N	C	2019-12-20 22:14:28.053842+00	1023
1	1315	Open-air; Inland	3	\N	-371	1	-1315	\N	C	2019-12-20 22:14:28.053842+00	1024
1	1314	Open-air; Inland	3	\N	-370	1	-1314	\N	C	2019-12-20 22:14:28.053842+00	1025
1	1313	Open-air; Inland	3	\N	-369	1	-1313	\N	C	2019-12-20 22:14:28.053842+00	1026
1	1312	Open-air; Inland	3	\N	-368	1	-1312	\N	C	2019-12-20 22:14:28.053842+00	1027
1	1311	Open-air; Inland	3	\N	-367	1	-1311	\N	C	2019-12-20 22:14:28.053842+00	1028
1	1310	Open-air; Inland	3	\N	-366	1	-1310	\N	C	2019-12-20 22:14:28.053842+00	1029
1	1309	Open-air; Inland	3	\N	-365	1	-1309	\N	C	2019-12-20 22:14:28.053842+00	1030
1	1308	Open-air; Inland	3	\N	-364	1	-1308	\N	C	2019-12-20 22:14:28.053842+00	1031
1	1307	Open-air; Inland	3	\N	-363	1	-1307	\N	C	2019-12-20 22:14:28.053842+00	1032
1	1306	Open-air; Inland	3	\N	-362	1	-1306	\N	C	2019-12-20 22:14:28.053842+00	1033
1	1305	Open-air; Inland	3	\N	-361	1	-1305	\N	C	2019-12-20 22:14:28.053842+00	1034
1	1304	Open-air; Inland	3	\N	-360	1	-1304	\N	C	2019-12-20 22:14:28.053842+00	1035
1	1303	Open-air; Inland	3	\N	-359	1	-1303	\N	C	2019-12-20 22:14:28.053842+00	1036
1	1302	Open-air; Inland	3	\N	-358	1	-1302	\N	C	2019-12-20 22:14:28.053842+00	1037
1	1301	Shell midden; Lake shore	3	\N	-357	1	-1301	\N	C	2019-12-20 22:14:28.053842+00	1038
1	1300	Shell midden; Lake shore	3	\N	-356	1	-1300	\N	C	2019-12-20 22:14:28.053842+00	1039
1	1299	Shell midden; Lake shore	3	\N	-355	1	-1299	\N	C	2019-12-20 22:14:28.053842+00	1040
1	1298	Shell midden; Lake shore	3	\N	-354	1	-1298	\N	C	2019-12-20 22:14:28.053842+00	1041
1	1297	Shell midden; Lake shore	3	\N	-353	1	-1297	\N	C	2019-12-20 22:14:28.053842+00	1042
1	1296	Shell midden; Lake shore	3	\N	-352	1	-1296	\N	C	2019-12-20 22:14:28.053842+00	1043
1	1295	Shell midden; Lake shore	3	\N	-351	1	-1295	\N	C	2019-12-20 22:14:28.053842+00	1044
1	1294	Shell midden; Lake shore	3	\N	-350	1	-1294	\N	C	2019-12-20 22:14:28.053842+00	1045
1	1293	Shell midden; Lake shore	3	\N	-349	1	-1293	\N	C	2019-12-20 22:14:28.053842+00	1046
1	1292	Shell midden; Lake shore	3	\N	-348	1	-1292	\N	C	2019-12-20 22:14:28.053842+00	1047
1	1291	Open-air; Close to the coast	3	\N	-347	1	-1291	\N	C	2019-12-20 22:14:28.053842+00	1048
1	1290	Open-air; Close to the coast	3	\N	-346	1	-1290	\N	C	2019-12-20 22:14:28.053842+00	1049
1	1289	Open-air; Close to the coast	3	\N	-345	1	-1289	\N	C	2019-12-20 22:14:28.053842+00	1050
1	1288	Open-air; Close to the coast	3	\N	-344	1	-1288	\N	C	2019-12-20 22:14:28.053842+00	1051
1	1287	Open-air; Close to the coast	3	\N	-343	1	-1287	\N	C	2019-12-20 22:14:28.053842+00	1052
1	1286	Open-air; Inland	3	\N	-342	1	-1286	\N	C	2019-12-20 22:14:28.053842+00	1053
1	1285	Open-air; Inland	3	\N	-341	1	-1285	\N	C	2019-12-20 22:14:28.053842+00	1054
1	1284	Open-air; Inland	3	\N	-340	1	-1284	\N	C	2019-12-20 22:14:28.053842+00	1055
1	1283	Open-air; Inland	3	\N	-339	1	-1283	\N	C	2019-12-20 22:14:28.053842+00	1056
1	1282	Open-air; Inland	3	\N	-338	1	-1282	\N	C	2019-12-20 22:14:28.053842+00	1057
1	1281	Open-air; Inland	3	\N	-337	1	-1281	\N	C	2019-12-20 22:14:28.053842+00	1058
1	1280	Open-air; Inland	3	\N	-336	1	-1280	\N	C	2019-12-20 22:14:28.053842+00	1059
1	1279	Open-air; Inland	3	\N	-335	1	-1279	\N	C	2019-12-20 22:14:28.053842+00	1060
1	1278	Open-air; Inland	3	\N	-334	1	-1278	\N	C	2019-12-20 22:14:28.053842+00	1061
1	1277	Open-air; Inland	3	\N	-333	1	-1277	\N	C	2019-12-20 22:14:28.053842+00	1062
1	1276	Open-air; Inland	3	\N	-332	1	-1276	\N	C	2019-12-20 22:14:28.053842+00	1063
1	1275	Open-air; Inland	3	\N	-331	1	-1275	\N	C	2019-12-20 22:14:28.053842+00	1064
1	1274	Open-air; Inland	3	\N	-330	1	-1274	\N	C	2019-12-20 22:14:28.053842+00	1065
1	1273	Open-air; Inland	3	\N	-329	1	-1273	\N	C	2019-12-20 22:14:28.053842+00	1066
1	1272	Open-air; Inland	3	\N	-328	1	-1272	\N	C	2019-12-20 22:14:28.053842+00	1067
1	1271	Open-air; Inland	3	\N	-327	1	-1271	\N	C	2019-12-20 22:14:28.053842+00	1068
1	1270	Open-air; Inland	3	\N	-326	1	-1270	\N	C	2019-12-20 22:14:28.053842+00	1069
1	1269	Open-air; Inland	3	\N	-325	1	-1269	\N	C	2019-12-20 22:14:28.053842+00	1070
1	1268	Open-air; Inland	3	\N	-324	1	-1268	\N	C	2019-12-20 22:14:28.053842+00	1071
1	1267	Open-air; Inland	3	\N	-323	1	-1267	\N	C	2019-12-20 22:14:28.053842+00	1072
1	1266	Open-air; Inland	3	\N	-322	1	-1266	\N	C	2019-12-20 22:14:28.053842+00	1073
1	1265	Open-air; Inland	3	\N	-321	1	-1265	\N	C	2019-12-20 22:14:28.053842+00	1074
1	1264	Open-air; Inland	3	\N	-320	1	-1264	\N	C	2019-12-20 22:14:28.053842+00	1075
1	1263	Open-air; Inland	3	\N	-319	1	-1263	\N	C	2019-12-20 22:14:28.053842+00	1076
1	1262	Open-air; Inland	3	\N	-318	1	-1262	\N	C	2019-12-20 22:14:28.053842+00	1077
1	1261	Open-air; Inland	3	\N	-317	1	-1261	\N	C	2019-12-20 22:14:28.053842+00	1078
1	1260	Open-air; Inland	3	\N	-316	1	-1260	\N	C	2019-12-20 22:14:28.053842+00	1079
1	1259	Open-air; Inland	3	\N	-315	1	-1259	\N	C	2019-12-20 22:14:28.053842+00	1080
1	1258	Open-air; Inland	3	\N	-314	1	-1258	\N	C	2019-12-20 22:14:28.053842+00	1081
1	1257	Open-air; Inland	3	\N	-313	1	-1257	\N	C	2019-12-20 22:14:28.053842+00	1082
1	1256	Open-air; Inland	3	\N	-312	1	-1256	\N	C	2019-12-20 22:14:28.053842+00	1083
1	1255	Open-air; Inland	3	\N	-311	1	-1255	\N	C	2019-12-20 22:14:28.053842+00	1084
1	1254	Open-air; Inland	3	\N	-310	1	-1254	\N	C	2019-12-20 22:14:28.053842+00	1085
1	1253	Open-air; Inland	3	\N	-309	1	-1253	\N	C	2019-12-20 22:14:28.053842+00	1086
1	1252	Open-air; Inland	3	\N	-308	1	-1252	\N	C	2019-12-20 22:14:28.053842+00	1087
1	1251	Open-air; Inland	3	\N	-307	1	-1251	\N	C	2019-12-20 22:14:28.053842+00	1088
1	1250	Open-air; Inland	3	\N	-306	1	-1250	\N	C	2019-12-20 22:14:28.053842+00	1089
1	1249	Open-air; Inland	3	\N	-305	1	-1249	\N	C	2019-12-20 22:14:28.053842+00	1090
1	1248	Open-air; Inland	3	\N	-304	1	-1248	\N	C	2019-12-20 22:14:28.053842+00	1091
1	1247	Open-air; Inland	3	\N	-303	1	-1247	\N	C	2019-12-20 22:14:28.053842+00	1092
1	1246	Open-air; Inland	3	\N	-302	1	-1246	\N	C	2019-12-20 22:14:28.053842+00	1093
1	1245	Open-air; Inland	3	\N	-301	1	-1245	\N	C	2019-12-20 22:14:28.053842+00	1094
1	1244	Open-air; Inland	3	\N	-300	1	-1244	\N	C	2019-12-20 22:14:28.053842+00	1095
1	1243	Open-air; Inland	3	\N	-299	1	-1243	\N	C	2019-12-20 22:14:28.053842+00	1096
1	1242	Open-air; Inland	3	\N	-298	1	-1242	\N	C	2019-12-20 22:14:28.053842+00	1097
1	1241	Open-air; Inland	3	\N	-297	1	-1241	\N	C	2019-12-20 22:14:28.053842+00	1098
1	1240	Open-air; Inland	3	\N	-296	1	-1240	\N	C	2019-12-20 22:14:28.053842+00	1099
1	1239	Open-air; Inland	3	\N	-295	1	-1239	\N	C	2019-12-20 22:14:28.053842+00	1100
1	1238	Open-air; Inland	3	\N	-294	1	-1238	\N	C	2019-12-20 22:14:28.053842+00	1101
1	1237	Open-air; Inland	3	\N	-293	1	-1237	\N	C	2019-12-20 22:14:28.053842+00	1102
1	1236	Open-air; Inland	3	\N	-292	1	-1236	\N	C	2019-12-20 22:14:28.053842+00	1103
1	1235	Open-air; Inland	3	\N	-291	1	-1235	\N	C	2019-12-20 22:14:28.053842+00	1104
1	1234	Open-air; Inland	3	\N	-290	1	-1234	\N	C	2019-12-20 22:14:28.053842+00	1105
1	1233	Open-air; Inland	3	\N	-289	1	-1233	\N	C	2019-12-20 22:14:28.053842+00	1106
1	1232	Open-air; Inland	3	\N	-288	1	-1232	\N	C	2019-12-20 22:14:28.053842+00	1107
1	1231	Open-air; Inland	3	\N	-287	1	-1231	\N	C	2019-12-20 22:14:28.053842+00	1108
1	1230	Open-air; Inland	3	\N	-286	1	-1230	\N	C	2019-12-20 22:14:28.053842+00	1109
1	1229	Open-air; Inland	3	\N	-285	1	-1229	\N	C	2019-12-20 22:14:28.053842+00	1110
1	1228	Open-air; Inland	3	\N	-284	1	-1228	\N	C	2019-12-20 22:14:28.053842+00	1111
1	1227	Open-air; Inland	3	\N	-283	1	-1227	\N	C	2019-12-20 22:14:28.053842+00	1112
1	1226	Open-air; Inland	3	\N	-282	1	-1226	\N	C	2019-12-20 22:14:28.053842+00	1113
1	1225	Open-air; Inland	3	\N	-281	1	-1225	\N	C	2019-12-20 22:14:28.053842+00	1114
1	1224	Open-air; Inland	3	\N	-280	1	-1224	\N	C	2019-12-20 22:14:28.053842+00	1115
1	1223	Open-air; Inland	3	\N	-279	1	-1223	\N	C	2019-12-20 22:14:28.053842+00	1116
1	1222	Open-air; Inland	3	\N	-278	1	-1222	\N	C	2019-12-20 22:14:28.053842+00	1117
1	1221	Open-air; Inland	3	\N	-277	1	-1221	\N	C	2019-12-20 22:14:28.053842+00	1118
1	1220	Open-air; Inland	3	\N	-276	1	-1220	\N	C	2019-12-20 22:14:28.053842+00	1119
1	1219	Open-air; Inland	3	\N	-275	1	-1219	\N	C	2019-12-20 22:14:28.053842+00	1120
1	1217	Open-air; Inland	3	\N	-273	1	-1217	\N	C	2019-12-20 22:14:28.053842+00	1122
1	1216	Open-air; Inland	3	\N	-272	1	-1216	\N	C	2019-12-20 22:14:28.053842+00	1123
1	1215	Open-air; Inland	3	\N	-271	1	-1215	\N	C	2019-12-20 22:14:28.053842+00	1124
1	1214	Open-air; Inland	3	\N	-270	1	-1214	\N	C	2019-12-20 22:14:28.053842+00	1125
1	1213	Open-air; Inland	3	\N	-269	1	-1213	\N	C	2019-12-20 22:14:28.053842+00	1126
1	1212	Open-air; Inland	3	\N	-268	1	-1212	\N	C	2019-12-20 22:14:28.053842+00	1127
1	1211	Open-air; Inland	3	\N	-267	1	-1211	\N	C	2019-12-20 22:14:28.053842+00	1128
1	1210	Open-air; Inland	3	\N	-266	1	-1210	\N	C	2019-12-20 22:14:28.053842+00	1129
1	1209	Open-air; Inland	3	\N	-265	1	-1209	\N	C	2019-12-20 22:14:28.053842+00	1130
1	1208	Open-air; Inland	3	\N	-264	1	-1208	\N	C	2019-12-20 22:14:28.053842+00	1131
1	1207	Open-air; Inland	3	\N	-263	1	-1207	\N	C	2019-12-20 22:14:28.053842+00	1132
1	1206	Open-air; Inland	3	\N	-262	1	-1206	\N	C	2019-12-20 22:14:28.053842+00	1133
1	1205	Open-air; Inland	3	\N	-261	1	-1205	\N	C	2019-12-20 22:14:28.053842+00	1134
1	1204	Open-air; Inland	3	\N	-260	1	-1204	\N	C	2019-12-20 22:14:28.053842+00	1135
1	1203	Open-air; Inland	3	\N	-259	1	-1203	\N	C	2019-12-20 22:14:28.053842+00	1136
1	1202	Open-air; Inland	3	\N	-258	1	-1202	\N	C	2019-12-20 22:14:28.053842+00	1137
1	1201	Open-air; Inland	3	\N	-257	1	-1201	\N	C	2019-12-20 22:14:28.053842+00	1138
1	1200	Open-air; Inland	3	\N	-256	1	-1200	\N	C	2019-12-20 22:14:28.053842+00	1139
1	1199	Open-air; Inland	3	\N	-255	1	-1199	\N	C	2019-12-20 22:14:28.053842+00	1140
1	1198	Open-air; Inland	3	\N	-254	1	-1198	\N	C	2019-12-20 22:14:28.053842+00	1141
1	1197	Open-air; Inland	3	\N	-253	1	-1197	\N	C	2019-12-20 22:14:28.053842+00	1142
1	1196	Open-air; Inland	3	\N	-252	1	-1196	\N	C	2019-12-20 22:14:28.053842+00	1143
1	1195	Open-air; Inland	3	\N	-251	1	-1195	\N	C	2019-12-20 22:14:28.053842+00	1144
1	1194	Open-air; Inland	3	\N	-250	1	-1194	\N	C	2019-12-20 22:14:28.053842+00	1145
1	1193	Open-air; Inland	3	\N	-249	1	-1193	\N	C	2019-12-20 22:14:28.053842+00	1146
1	1192	Open-air; Inland	3	\N	-248	1	-1192	\N	C	2019-12-20 22:14:28.053842+00	1147
1	1191	Open-air; Inland	3	\N	-247	1	-1191	\N	C	2019-12-20 22:14:28.053842+00	1148
1	1190	Open-air; Inland	3	\N	-246	1	-1190	\N	C	2019-12-20 22:14:28.053842+00	1149
1	1189	Open-air; Inland	3	\N	-245	1	-1189	\N	C	2019-12-20 22:14:28.053842+00	1150
1	1188	Open-air; Inland	3	\N	-244	1	-1188	\N	C	2019-12-20 22:14:28.053842+00	1151
1	1187	Open-air; Inland	3	\N	-243	1	-1187	\N	C	2019-12-20 22:14:28.053842+00	1152
1	1186	Open-air; Inland	3	\N	-242	1	-1186	\N	C	2019-12-20 22:14:28.053842+00	1153
1	1185	Open-air; Inland	3	\N	-241	1	-1185	\N	C	2019-12-20 22:14:28.053842+00	1154
1	1184	Open-air; Inland	3	\N	-240	1	-1184	\N	C	2019-12-20 22:14:28.053842+00	1155
1	1183	Open-air; Inland	3	\N	-239	1	-1183	\N	C	2019-12-20 22:14:28.053842+00	1156
1	1182	Open-air; Mountainous	3	\N	-238	1	-1182	\N	C	2019-12-20 22:14:28.053842+00	1157
1	1181	Open-air; Mountainous	3	\N	-237	1	-1181	\N	C	2019-12-20 22:14:28.053842+00	1158
1	1180	Open-air; Mountainous	3	\N	-236	1	-1180	\N	C	2019-12-20 22:14:28.053842+00	1159
1	1179	Open-air; Mountainous	3	\N	-235	1	-1179	\N	C	2019-12-20 22:14:28.053842+00	1160
1	1178	Open-air; Mountainous	3	\N	-234	1	-1178	\N	C	2019-12-20 22:14:28.053842+00	1161
1	1177	Open-air; Mountainous	3	\N	-233	1	-1177	\N	C	2019-12-20 22:14:28.053842+00	1162
1	1176	Open-air; Mountainous	3	\N	-232	1	-1176	\N	C	2019-12-20 22:14:28.053842+00	1163
1	1175	Open-air; Mountainous	3	\N	-231	1	-1175	\N	C	2019-12-20 22:14:28.053842+00	1164
1	1174	Shell midden; Inland	3	\N	-230	1	-1174	\N	C	2019-12-20 22:14:28.053842+00	1165
1	1173	Shell midden; Inland	3	\N	-229	1	-1173	\N	C	2019-12-20 22:14:28.053842+00	1166
1	1172	Shell midden; Inland	3	\N	-228	1	-1172	\N	C	2019-12-20 22:14:28.053842+00	1167
1	1171	Shell midden; Inland	3	\N	-227	1	-1171	\N	C	2019-12-20 22:14:28.053842+00	1168
1	1170	Shell midden; Inland	3	\N	-226	1	-1170	\N	C	2019-12-20 22:14:28.053842+00	1169
1	1169	Shell midden; Inland	3	\N	-225	1	-1169	\N	C	2019-12-20 22:14:28.053842+00	1170
1	1168	Shell midden; Inland	3	\N	-224	1	-1168	\N	C	2019-12-20 22:14:28.053842+00	1171
1	1167	Shell midden; Inland	3	\N	-223	1	-1167	\N	C	2019-12-20 22:14:28.053842+00	1172
1	1166	Shell midden; Inland	3	\N	-222	1	-1166	\N	C	2019-12-20 22:14:28.053842+00	1173
1	1165	Shell midden; Inland	3	\N	-221	1	-1165	\N	C	2019-12-20 22:14:28.053842+00	1174
1	1164	Shell midden; Inland	3	\N	-220	1	-1164	\N	C	2019-12-20 22:14:28.053842+00	1175
1	1163	Shell midden; Inland	3	\N	-219	1	-1163	\N	C	2019-12-20 22:14:28.053842+00	1176
1	1162	Shell midden; Inland	3	\N	-218	1	-1162	\N	C	2019-12-20 22:14:28.053842+00	1177
1	1161	Shell midden; Inland	3	\N	-217	1	-1161	\N	C	2019-12-20 22:14:28.053842+00	1178
1	1160	Shell midden; Inland	3	\N	-216	1	-1160	\N	C	2019-12-20 22:14:28.053842+00	1179
1	1159	Shell midden; Inland	3	\N	-215	1	-1159	\N	C	2019-12-20 22:14:28.053842+00	1180
1	1158	Shell midden; Inland	3	\N	-214	1	-1158	\N	C	2019-12-20 22:14:28.053842+00	1181
1	1157	Shell midden; Inland	3	\N	-213	1	-1157	\N	C	2019-12-20 22:14:28.053842+00	1182
1	1156	Shell midden; Inland	3	\N	-212	1	-1156	\N	C	2019-12-20 22:14:28.053842+00	1183
1	1155	Shell midden; Inland	3	\N	-211	1	-1155	\N	C	2019-12-20 22:14:28.053842+00	1184
1	1154	Shell midden; Inland	3	\N	-210	1	-1154	\N	C	2019-12-20 22:14:28.053842+00	1185
1	1153	Shell midden; Inland	3	\N	-209	1	-1153	\N	C	2019-12-20 22:14:28.053842+00	1186
1	1152	Shell midden; Inland	3	\N	-208	1	-1152	\N	C	2019-12-20 22:14:28.053842+00	1187
1	1151	Shell midden; Inland	3	\N	-207	1	-1151	\N	C	2019-12-20 22:14:28.053842+00	1188
1	1150	Shell midden; Inland	3	\N	-206	1	-1150	\N	C	2019-12-20 22:14:28.053842+00	1189
1	1149	Shell midden; Inland	3	\N	-205	1	-1149	\N	C	2019-12-20 22:14:28.053842+00	1190
1	1148	Shell midden; Inland	3	\N	-204	1	-1148	\N	C	2019-12-20 22:14:28.053842+00	1191
1	1147	Shell midden; Inland	3	\N	-203	1	-1147	\N	C	2019-12-20 22:14:28.053842+00	1192
1	1146	Shell midden; Inland	3	\N	-202	1	-1146	\N	C	2019-12-20 22:14:28.053842+00	1193
1	1145	Shell midden; Inland	3	\N	-201	1	-1145	\N	C	2019-12-20 22:14:28.053842+00	1194
1	1144	Shell midden; Inland	3	\N	-200	1	-1144	\N	C	2019-12-20 22:14:28.053842+00	1195
1	1143	Shell midden; Inland	3	\N	-199	1	-1143	\N	C	2019-12-20 22:14:28.053842+00	1196
1	1142	Shell midden; Inland	3	\N	-198	1	-1142	\N	C	2019-12-20 22:14:28.053842+00	1197
1	1141	Shell midden; Inland	3	\N	-197	1	-1141	\N	C	2019-12-20 22:14:28.053842+00	1198
1	1140	Rock shelter/Cave; Mountainous	3	\N	-196	1	-1140	\N	C	2019-12-20 22:14:28.053842+00	1199
1	1139	Rock shelter/Cave; Mountainous	3	\N	-195	1	-1139	\N	C	2019-12-20 22:14:28.053842+00	1200
1	1138	Rock shelter/Cave; Mountainous	3	\N	-194	1	-1138	\N	C	2019-12-20 22:14:28.053842+00	1201
1	1137	Rock shelter/Cave; Mountainous	3	\N	-193	1	-1137	\N	C	2019-12-20 22:14:28.053842+00	1202
1	1136	Rock shelter/Cave; Mountainous	3	\N	-192	1	-1136	\N	C	2019-12-20 22:14:28.053842+00	1203
1	1135	Rock shelter/Cave; Mountainous	3	\N	-191	1	-1135	\N	C	2019-12-20 22:14:28.053842+00	1204
1	1134	Rock shelter/Cave; Mountainous	3	\N	-190	1	-1134	\N	C	2019-12-20 22:14:28.053842+00	1205
1	1133	Rock shelter/Cave; Mountainous	3	\N	-189	1	-1133	\N	C	2019-12-20 22:14:28.053842+00	1206
1	1132	Rock shelter/Cave; Mountainous	3	\N	-188	1	-1132	\N	C	2019-12-20 22:14:28.053842+00	1207
1	1131	Rock shelter/Cave; Mountainous	3	\N	-187	1	-1131	\N	C	2019-12-20 22:14:28.053842+00	1208
1	1130	Rock shelter/Cave; Mountainous	3	\N	-186	1	-1130	\N	C	2019-12-20 22:14:28.053842+00	1209
1	1129	Rock shelter/Cave; Mountainous	3	\N	-185	1	-1129	\N	C	2019-12-20 22:14:28.053842+00	1210
1	1128	Rock shelter/Cave; Mountainous	3	\N	-184	1	-1128	\N	C	2019-12-20 22:14:28.053842+00	1211
1	1127	Rock shelter/Cave; Mountainous	3	\N	-183	1	-1127	\N	C	2019-12-20 22:14:28.053842+00	1212
1	1126	Rock shelter/Cave; Mountainous	3	\N	-182	1	-1126	\N	C	2019-12-20 22:14:28.053842+00	1213
1	1125	Rock shelter/Cave; Inland	3	\N	-181	1	-1125	\N	C	2019-12-20 22:14:28.053842+00	1214
1	1124	Rock shelter/Cave; Inland	3	\N	-180	1	-1124	\N	C	2019-12-20 22:14:28.053842+00	1215
1	1123	Rock shelter/Cave; Inland	3	\N	-179	1	-1123	\N	C	2019-12-20 22:14:28.053842+00	1216
1	1122	Rock shelter/Cave; Inland	3	\N	-178	1	-1122	\N	C	2019-12-20 22:14:28.053842+00	1217
1	1121	Rock shelter/Cave; Inland	3	\N	-177	1	-1121	\N	C	2019-12-20 22:14:28.053842+00	1218
1	1120	Rock shelter/Cave; Inland	3	\N	-176	1	-1120	\N	C	2019-12-20 22:14:28.053842+00	1219
1	1119	Rock shelter/Cave; Inland	3	\N	-175	1	-1119	\N	C	2019-12-20 22:14:28.053842+00	1220
1	1118	Shell midden; Inland	3	\N	-174	1	-1118	\N	C	2019-12-20 22:14:28.053842+00	1221
1	1117	Shell midden; Inland	3	\N	-173	1	-1117	\N	C	2019-12-20 22:14:28.053842+00	1222
1	1116	Shell midden; Inland	3	\N	-172	1	-1116	\N	C	2019-12-20 22:14:28.053842+00	1223
1	1115	Shell midden; Inland	3	\N	-171	1	-1115	\N	C	2019-12-20 22:14:28.053842+00	1224
1	1114	Shell midden; Inland	3	\N	-170	1	-1114	\N	C	2019-12-20 22:14:28.053842+00	1225
1	1113	Shell midden; Inland	3	\N	-169	1	-1113	\N	C	2019-12-20 22:14:28.053842+00	1226
1	1112	Shell midden; Inland	3	\N	-168	1	-1112	\N	C	2019-12-20 22:14:28.053842+00	1227
1	1111	Shell midden; Inland	3	\N	-167	1	-1111	\N	C	2019-12-20 22:14:28.053842+00	1228
1	1110	Shell midden; Inland	3	\N	-166	1	-1110	\N	C	2019-12-20 22:14:28.053842+00	1229
1	1109	Shell midden; Inland	3	\N	-165	1	-1109	\N	C	2019-12-20 22:14:28.053842+00	1230
1	1108	Shell midden; Inland	3	\N	-164	1	-1108	\N	C	2019-12-20 22:14:28.053842+00	1231
1	1107	Shell midden; Inland	3	\N	-163	1	-1107	\N	C	2019-12-20 22:14:28.053842+00	1232
1	1106	Shell midden; Inland	3	\N	-162	1	-1106	\N	C	2019-12-20 22:14:28.053842+00	1233
1	1105	Rock shelter/Cave; Mountainous	3	\N	-161	1	-1105	\N	C	2019-12-20 22:14:28.053842+00	1234
1	1104	Rock shelter/Cave; Mountainous	3	\N	-160	1	-1104	\N	C	2019-12-20 22:14:28.053842+00	1235
1	1103	Rock shelter/Cave; Mountainous	3	\N	-159	1	-1103	\N	C	2019-12-20 22:14:28.053842+00	1236
1	1102	Rock shelter/Cave; Mountainous	3	\N	-158	1	-1102	\N	C	2019-12-20 22:14:28.053842+00	1237
1	1101	Rock shelter/Cave; Mountainous	3	\N	-157	1	-1101	\N	C	2019-12-20 22:14:28.053842+00	1238
1	1100	Rock shelter/Cave; Mountainous	3	\N	-156	1	-1100	\N	C	2019-12-20 22:14:28.053842+00	1239
1	1099	Rock shelter/Cave; Mountainous	3	\N	-155	1	-1099	\N	C	2019-12-20 22:14:28.053842+00	1240
1	1098	Rock shelter/Cave; Mountainous	3	\N	-154	1	-1098	\N	C	2019-12-20 22:14:28.053842+00	1241
1	1097	Rock shelter/Cave; Mountainous	3	\N	-153	1	-1097	\N	C	2019-12-20 22:14:28.053842+00	1242
1	1096	Rock shelter/Cave; Mountainous	3	\N	-152	1	-1096	\N	C	2019-12-20 22:14:28.053842+00	1243
1	1095	Rock shelter/Cave; Mountainous	3	\N	-151	1	-1095	\N	C	2019-12-20 22:14:28.053842+00	1244
1	1094	Rock shelter/Cave; Mountainous	3	\N	-150	1	-1094	\N	C	2019-12-20 22:14:28.053842+00	1245
1	1093	Rock shelter/Cave; Mountainous	3	\N	-149	1	-1093	\N	C	2019-12-20 22:14:28.053842+00	1246
1	1092	Rock shelter/Cave; Mountainous	3	\N	-148	1	-1092	\N	C	2019-12-20 22:14:28.053842+00	1247
1	1091	Rock shelter/Cave; Mountainous	3	\N	-147	1	-1091	\N	C	2019-12-20 22:14:28.053842+00	1248
1	1090	Rock shelter/Cave; Mountainous	3	\N	-146	1	-1090	\N	C	2019-12-20 22:14:28.053842+00	1249
1	1089	Rock shelter/Cave; Mountainous	3	\N	-145	1	-1089	\N	C	2019-12-20 22:14:28.053842+00	1250
1	1088	Rock shelter/Cave; Mountainous	3	\N	-144	1	-1088	\N	C	2019-12-20 22:14:28.053842+00	1251
1	1087	Rock shelter/Cave; Mountainous	3	\N	-143	1	-1087	\N	C	2019-12-20 22:14:28.053842+00	1252
1	1086	Rock shelter/Cave; Mountainous	3	\N	-142	1	-1086	\N	C	2019-12-20 22:14:28.053842+00	1253
1	1085	Rock shelter/Cave; Mountainous	3	\N	-141	1	-1085	\N	C	2019-12-20 22:14:28.053842+00	1254
1	1084	Rock shelter/Cave; Mountainous	3	\N	-140	1	-1084	\N	C	2019-12-20 22:14:28.053842+00	1255
1	1083	Rock shelter/Cave; Mountainous	3	\N	-139	1	-1083	\N	C	2019-12-20 22:14:28.053842+00	1256
1	1082	Rock shelter/Cave; Mountainous	3	\N	-138	1	-1082	\N	C	2019-12-20 22:14:28.053842+00	1257
1	1081	Rock shelter/Cave; Mountainous	3	\N	-137	1	-1081	\N	C	2019-12-20 22:14:28.053842+00	1258
1	1080	Rock shelter/Cave; Mountainous	3	\N	-136	1	-1080	\N	C	2019-12-20 22:14:28.053842+00	1259
1	1079	Rock shelter/Cave; Mountainous	3	\N	-135	1	-1079	\N	C	2019-12-20 22:14:28.053842+00	1260
1	1078	Rock shelter/Cave; Mountainous	3	\N	-134	1	-1078	\N	C	2019-12-20 22:14:28.053842+00	1261
1	1077	Rock shelter/Cave; Mountainous	3	\N	-133	1	-1077	\N	C	2019-12-20 22:14:28.053842+00	1262
1	1076	Rock shelter/Cave; Mountainous	3	\N	-132	1	-1076	\N	C	2019-12-20 22:14:28.053842+00	1263
1	1075	Rock shelter/Cave; Mountainous	3	\N	-131	1	-1075	\N	C	2019-12-20 22:14:28.053842+00	1264
1	1074	Rock shelter/Cave; Mountainous	3	\N	-130	1	-1074	\N	C	2019-12-20 22:14:28.053842+00	1265
1	1073	Rock shelter/Cave; Mountainous	3	\N	-129	1	-1073	\N	C	2019-12-20 22:14:28.053842+00	1266
1	1072	Rock shelter/Cave; Mountainous	3	\N	-128	1	-1072	\N	C	2019-12-20 22:14:28.053842+00	1267
1	1071	Rock shelter/Cave; Mountainous	3	\N	-127	1	-1071	\N	C	2019-12-20 22:14:28.053842+00	1268
1	1070	Rock shelter/Cave; Mountainous	3	\N	-126	1	-1070	\N	C	2019-12-20 22:14:28.053842+00	1269
1	1069	Rock shelter/Cave; Mountainous	3	\N	-125	1	-1069	\N	C	2019-12-20 22:14:28.053842+00	1270
1	1068	Rock shelter/Cave; Mountainous	3	\N	-124	1	-1068	\N	C	2019-12-20 22:14:28.053842+00	1271
1	1067	Rock shelter/Cave; Mountainous	3	\N	-123	1	-1067	\N	C	2019-12-20 22:14:28.053842+00	1272
1	1066	Rock shelter/Cave; Mountainous	3	\N	-122	1	-1066	\N	C	2019-12-20 22:14:28.053842+00	1273
1	1065	Rock shelter/Cave; Mountainous	3	\N	-121	1	-1065	\N	C	2019-12-20 22:14:28.053842+00	1274
1	1064	Rock shelter/Cave; Mountainous	3	\N	-120	1	-1064	\N	C	2019-12-20 22:14:28.053842+00	1275
1	1063	Rock shelter/Cave; Mountainous	3	\N	-119	1	-1063	\N	C	2019-12-20 22:14:28.053842+00	1276
1	1062	Rock shelter/Cave; Mountainous	3	\N	-118	1	-1062	\N	C	2019-12-20 22:14:28.053842+00	1277
1	1061	Open-air; Close to the coast	3	\N	-117	1	-1061	\N	C	2019-12-20 22:14:28.053842+00	1278
1	1060	Open-air; Close to the coast	3	\N	-116	1	-1060	\N	C	2019-12-20 22:14:28.053842+00	1279
1	1059	Open-air; Close to the coast	3	\N	-115	1	-1059	\N	C	2019-12-20 22:14:28.053842+00	1280
1	1058	Open-air; Close to the coast	3	\N	-114	1	-1058	\N	C	2019-12-20 22:14:28.053842+00	1281
1	1057	Open-air; Close to the coast	3	\N	-113	1	-1057	\N	C	2019-12-20 22:14:28.053842+00	1282
1	1056	Open-air; Close to the coast	3	\N	-112	1	-1056	\N	C	2019-12-20 22:14:28.053842+00	1283
1	1055	Open-air; Close to the coast	3	\N	-111	1	-1055	\N	C	2019-12-20 22:14:28.053842+00	1284
1	1054	Open-air; Close to the coast	3	\N	-110	1	-1054	\N	C	2019-12-20 22:14:28.053842+00	1285
1	1053	Open-air; Close to the coast	3	\N	-109	1	-1053	\N	C	2019-12-20 22:14:28.053842+00	1286
1	1052	Open-air; Close to the coast	3	\N	-108	1	-1052	\N	C	2019-12-20 22:14:28.053842+00	1287
1	1051	Open-air; Close to the coast	3	\N	-107	1	-1051	\N	C	2019-12-20 22:14:28.053842+00	1288
1	1050	Open-air; Close to the coast	3	\N	-106	1	-1050	\N	C	2019-12-20 22:14:28.053842+00	1289
1	1049	Open-air; Close to the coast	3	\N	-105	1	-1049	\N	C	2019-12-20 22:14:28.053842+00	1290
1	1048	Open-air; Close to the coast	3	\N	-104	1	-1048	\N	C	2019-12-20 22:14:28.053842+00	1291
1	1047	Open-air; Close to the coast	3	\N	-103	1	-1047	\N	C	2019-12-20 22:14:28.053842+00	1292
1	1046	Open-air; Close to the coast	3	\N	-102	1	-1046	\N	C	2019-12-20 22:14:28.053842+00	1293
1	1045	Open-air; Close to the coast	3	\N	-101	1	-1045	\N	C	2019-12-20 22:14:28.053842+00	1294
1	1044	Open-air; Close to the coast	3	\N	-100	1	-1044	\N	C	2019-12-20 22:14:28.053842+00	1295
1	1043	Open-air; Close to the coast	3	\N	-99	1	-1043	\N	C	2019-12-20 22:14:28.053842+00	1296
1	1042	Open-air; Close to the coast	3	\N	-98	1	-1042	\N	C	2019-12-20 22:14:28.053842+00	1297
1	1041	Open-air; Close to the coast	3	\N	-97	1	-1041	\N	C	2019-12-20 22:14:28.053842+00	1298
1	1040	Open-air; Close to the coast	3	\N	-96	1	-1040	\N	C	2019-12-20 22:14:28.053842+00	1299
1	1039	Open-air; Close to the coast	3	\N	-95	1	-1039	\N	C	2019-12-20 22:14:28.053842+00	1300
1	1038	Open-air; Close to the coast	3	\N	-94	1	-1038	\N	C	2019-12-20 22:14:28.053842+00	1301
1	1037	Open-air; Close to the coast	3	\N	-93	1	-1037	\N	C	2019-12-20 22:14:28.053842+00	1302
1	1036	Open-air; Close to the coast	3	\N	-92	1	-1036	\N	C	2019-12-20 22:14:28.053842+00	1303
1	1035	Open-air; Close to the coast	3	\N	-91	1	-1035	\N	C	2019-12-20 22:14:28.053842+00	1304
1	1034	Open-air; Close to the coast	3	\N	-90	1	-1034	\N	C	2019-12-20 22:14:28.053842+00	1305
1	1033	Open-air; Close to the coast	3	\N	-89	1	-1033	\N	C	2019-12-20 22:14:28.053842+00	1306
1	1032	Open-air; Close to the coast	3	\N	-88	1	-1032	\N	C	2019-12-20 22:14:28.053842+00	1307
1	1031	Open-air; Close to the coast	3	\N	-87	1	-1031	\N	C	2019-12-20 22:14:28.053842+00	1308
1	1030	Open-air; Close to the coast	3	\N	-86	1	-1030	\N	C	2019-12-20 22:14:28.053842+00	1309
1	1029	Open-air; Close to the coast	3	\N	-85	1	-1029	\N	C	2019-12-20 22:14:28.053842+00	1310
1	1028	Open-air; Close to the coast	3	\N	-84	1	-1028	\N	C	2019-12-20 22:14:28.053842+00	1311
1	1027	Open-air; Close to the coast	3	\N	-83	1	-1027	\N	C	2019-12-20 22:14:28.053842+00	1312
1	1026	Open-air; Close to the coast	3	\N	-82	1	-1026	\N	C	2019-12-20 22:14:28.053842+00	1313
1	1025	Open-air; Close to the coast	3	\N	-81	1	-1025	\N	C	2019-12-20 22:14:28.053842+00	1314
1	1024	Open-air; Close to the coast	3	\N	-80	1	-1024	\N	C	2019-12-20 22:14:28.053842+00	1315
1	1023	Open-air; Close to the coast	3	\N	-79	1	-1023	\N	C	2019-12-20 22:14:28.053842+00	1316
1	1022	Open-air; Close to the coast	3	\N	-78	1	-1022	\N	C	2019-12-20 22:14:28.053842+00	1317
1	1021	Open-air; Close to the coast	3	\N	-77	1	-1021	\N	C	2019-12-20 22:14:28.053842+00	1318
1	1020	Open-air; Close to the coast	3	\N	-76	1	-1020	\N	C	2019-12-20 22:14:28.053842+00	1319
1	1019	Open-air; Close to the coast	3	\N	-75	1	-1019	\N	C	2019-12-20 22:14:28.053842+00	1320
1	1018	Open-air; Close to the coast	3	\N	-74	1	-1018	\N	C	2019-12-20 22:14:28.053842+00	1321
1	1017	Open-air; Close to the coast	3	\N	-73	1	-1017	\N	C	2019-12-20 22:14:28.053842+00	1322
1	1016	Open-air; Close to the coast	3	\N	-72	1	-1016	\N	C	2019-12-20 22:14:28.053842+00	1323
1	1015	Open-air; Close to the coast	3	\N	-71	1	-1015	\N	C	2019-12-20 22:14:28.053842+00	1324
1	1014	Open-air; Close to the coast	3	\N	-70	1	-1014	\N	C	2019-12-20 22:14:28.053842+00	1325
1	1013	Open-air; Close to the coast	3	\N	-69	1	-1013	\N	C	2019-12-20 22:14:28.053842+00	1326
1	1012	Open-air; Close to the coast	3	\N	-68	1	-1012	\N	C	2019-12-20 22:14:28.053842+00	1327
1	1011	Open-air; Close to the coast	3	\N	-67	1	-1011	\N	C	2019-12-20 22:14:28.053842+00	1328
1	1010	Open-air; Close to the coast	3	\N	-66	1	-1010	\N	C	2019-12-20 22:14:28.053842+00	1329
1	1009	Open-air; Close to the coast	3	\N	-65	1	-1009	\N	C	2019-12-20 22:14:28.053842+00	1330
1	1008	Open-air; Close to the coast	3	\N	-64	1	-1008	\N	C	2019-12-20 22:14:28.053842+00	1331
1	1007	Open-air; Close to the coast	3	\N	-63	1	-1007	\N	C	2019-12-20 22:14:28.053842+00	1332
1	1006	Open-air; Close to the coast	3	\N	-62	1	-1006	\N	C	2019-12-20 22:14:28.053842+00	1333
1	1005	Open-air; Close to the coast	3	\N	-61	1	-1005	\N	C	2019-12-20 22:14:28.053842+00	1334
1	1004	Open-air; Close to the coast	3	\N	-60	1	-1004	\N	C	2019-12-20 22:14:28.053842+00	1335
1	1003	Open-air; Close to the coast	3	\N	-59	1	-1003	\N	C	2019-12-20 22:14:28.053842+00	1336
1	1002	Open-air; Close to the coast	3	\N	-58	1	-1002	\N	C	2019-12-20 22:14:28.053842+00	1337
1	1001	Open-air; Close to the coast	3	\N	-57	1	-1001	\N	C	2019-12-20 22:14:28.053842+00	1338
1	1000	Open-air; Close to the coast	3	\N	-56	1	-1000	\N	C	2019-12-20 22:14:28.053842+00	1339
1	999	Open-air; Close to the coast	3	\N	-55	1	-999	\N	C	2019-12-20 22:14:28.053842+00	1340
1	998	Open-air; Close to the coast	3	\N	-54	1	-998	\N	C	2019-12-20 22:14:28.053842+00	1341
1	997	Open-air; Close to the coast	3	\N	-53	1	-997	\N	C	2019-12-20 22:14:28.053842+00	1342
1	996	Open-air; Close to the coast	3	\N	-52	1	-996	\N	C	2019-12-20 22:14:28.053842+00	1343
1	995	Open-air; Close to the coast	3	\N	-51	1	-995	\N	C	2019-12-20 22:14:28.053842+00	1344
1	994	Open-air; Close to the coast	3	\N	-50	1	-994	\N	C	2019-12-20 22:14:28.053842+00	1345
1	993	Open-air; Close to the coast	3	\N	-49	1	-993	\N	C	2019-12-20 22:14:28.053842+00	1346
1	992	Open-air; Close to the coast	3	\N	-48	1	-992	\N	C	2019-12-20 22:14:28.053842+00	1347
1	991	Open-air; Close to the coast	3	\N	-47	1	-991	\N	C	2019-12-20 22:14:28.053842+00	1348
1	990	Open-air; Close to the coast	3	\N	-46	1	-990	\N	C	2019-12-20 22:14:28.053842+00	1349
1	988	Open-air; Close to the coast	3	\N	-44	1	-988	\N	C	2019-12-20 22:14:28.053842+00	1351
1	987	Open-air; Close to the coast	3	\N	-43	1	-987	\N	C	2019-12-20 22:14:28.053842+00	1352
1	986	Open-air; Close to the coast	3	\N	-42	1	-986	\N	C	2019-12-20 22:14:28.053842+00	1353
1	985	Open-air; Close to the coast	3	\N	-41	1	-985	\N	C	2019-12-20 22:14:28.053842+00	1354
1	984	Open-air; Close to the coast	3	\N	-40	1	-984	\N	C	2019-12-20 22:14:28.053842+00	1355
1	983	Open-air; Close to the coast	3	\N	-39	1	-983	\N	C	2019-12-20 22:14:28.053842+00	1356
1	982	Open-air; Close to the coast	3	\N	-38	1	-982	\N	C	2019-12-20 22:14:28.053842+00	1357
1	981	Open-air; Close to the coast	3	\N	-37	1	-981	\N	C	2019-12-20 22:14:28.053842+00	1358
1	980	Open-air; Close to the coast	3	\N	-36	1	-980	\N	C	2019-12-20 22:14:28.053842+00	1359
1	979	Open-air; Close to the coast	3	\N	-35	1	-979	\N	C	2019-12-20 22:14:28.053842+00	1360
1	978	Open-air; Close to the coast	3	\N	-34	1	-978	\N	C	2019-12-20 22:14:28.053842+00	1361
1	977	Open-air; Close to the coast	3	\N	-33	1	-977	\N	C	2019-12-20 22:14:28.053842+00	1362
1	976	Open-air; Close to the coast	3	\N	-32	1	-976	\N	C	2019-12-20 22:14:28.053842+00	1363
1	975	Open-air; Close to the coast	3	\N	-31	1	-975	\N	C	2019-12-20 22:14:28.053842+00	1364
1	974	Open-air; Close to the coast	3	\N	-30	1	-974	\N	C	2019-12-20 22:14:28.053842+00	1365
1	973	Open-air; Close to the coast	3	\N	-29	1	-973	\N	C	2019-12-20 22:14:28.053842+00	1366
1	972	Open-air; Close to the coast	3	\N	-28	1	-972	\N	C	2019-12-20 22:14:28.053842+00	1367
1	971	Open-air; Inland	3	\N	-27	1	-971	\N	C	2019-12-20 22:14:28.053842+00	1368
1	970	Open-air; Inland	3	\N	-26	1	-970	\N	C	2019-12-20 22:14:28.053842+00	1369
1	969	Open-air; Inland	3	\N	-25	1	-969	\N	C	2019-12-20 22:14:28.053842+00	1370
1	968	Open-air; Inland	3	\N	-24	1	-968	\N	C	2019-12-20 22:14:28.053842+00	1371
1	967	Open-air; Inland	3	\N	-23	1	-967	\N	C	2019-12-20 22:14:28.053842+00	1372
1	966	Open-air; Inland	3	\N	-22	1	-966	\N	C	2019-12-20 22:14:28.053842+00	1373
1	965	Open-air; Inland	3	\N	-21	1	-965	\N	C	2019-12-20 22:14:28.053842+00	1374
1	964	Open-air; Inland	3	\N	-20	1	-964	\N	C	2019-12-20 22:14:28.053842+00	1375
1	963	Open-air; Inland	3	\N	-19	1	-963	\N	C	2019-12-20 22:14:28.053842+00	1376
1	962	Open-air; Inland	3	\N	-18	1	-962	\N	C	2019-12-20 22:14:28.053842+00	1377
1	961	Open-air; Inland	3	\N	-17	1	-961	\N	C	2019-12-20 22:14:28.053842+00	1378
1	960	Open-air; Inland	3	\N	-16	1	-960	\N	C	2019-12-20 22:14:28.053842+00	1379
1	959	Open-air; Inland	3	\N	-15	1	-959	\N	C	2019-12-20 22:14:28.053842+00	1380
1	958	Open-air; Inland	3	\N	-14	1	-958	\N	C	2019-12-20 22:14:28.053842+00	1381
1	957	Open-air; Inland	3	\N	-13	1	-957	\N	C	2019-12-20 22:14:28.053842+00	1382
1	956	Open-air; Inland	3	\N	-12	1	-956	\N	C	2019-12-20 22:14:28.053842+00	1383
1	955	Open-air; Inland	3	\N	-11	1	-955	\N	C	2019-12-20 22:14:28.053842+00	1384
1	954	Open-air; Inland	3	\N	-10	1	-954	\N	C	2019-12-20 22:14:28.053842+00	1385
1	953	Open-air; Inland	3	\N	-9	1	-953	\N	C	2019-12-20 22:14:28.053842+00	1386
1	952	Open-air; Inland	3	\N	-8	1	-952	\N	C	2019-12-20 22:14:28.053842+00	1387
1	951	Open-air; Inland	3	\N	-7	1	-951	\N	C	2019-12-20 22:14:28.053842+00	1388
1	950	Open-air; Inland	3	\N	-6	1	-950	\N	C	2019-12-20 22:14:28.053842+00	1389
1	949	Open-air; Inland	3	\N	-5	1	-949	\N	C	2019-12-20 22:14:28.053842+00	1390
1	948	Open-air; Inland	3	\N	-4	1	-948	\N	C	2019-12-20 22:14:28.053842+00	1391
1	947	Open-air; Inland	3	\N	-3	1	-947	\N	C	2019-12-20 22:14:28.053842+00	1392
1	946	Open-air; Inland	3	\N	-2	1	-946	\N	C	2019-12-20 22:14:28.053842+00	1393
1	945	Open-air; Inland	3	\N	-1	1	-945	\N	C	2019-12-20 22:14:28.053842+00	1394
1	944	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-944	1	-944	\N	C	2019-12-20 22:14:28.053842+00	1395
1	943	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-943	1	-943	\N	C	2019-12-20 22:14:28.053842+00	1396
1	942	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-942	1	-942	\N	C	2019-12-20 22:14:28.053842+00	1397
1	941	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-941	1	-941	\N	C	2019-12-20 22:14:28.053842+00	1398
1	940	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-940	1	-940	\N	C	2019-12-20 22:14:28.053842+00	1399
1	939	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-939	1	-939	\N	C	2019-12-20 22:14:28.053842+00	1400
1	938	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-938	1	-938	\N	C	2019-12-20 22:14:28.053842+00	1401
1	937	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-937	1	-937	\N	C	2019-12-20 22:14:28.053842+00	1402
1	936	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-936	1	-936	\N	C	2019-12-20 22:14:28.053842+00	1403
1	935	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-935	1	-935	\N	C	2019-12-20 22:14:28.053842+00	1404
1	934	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-934	1	-934	\N	C	2019-12-20 22:14:28.053842+00	1405
1	933	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-933	1	-933	\N	C	2019-12-20 22:14:28.053842+00	1406
1	932	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-932	1	-932	\N	C	2019-12-20 22:14:28.053842+00	1407
1	931	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-931	1	-931	\N	C	2019-12-20 22:14:28.053842+00	1408
1	930	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-930	1	-930	\N	C	2019-12-20 22:14:28.053842+00	1409
1	929	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-929	1	-929	\N	C	2019-12-20 22:14:28.053842+00	1410
1	928	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-928	1	-928	\N	C	2019-12-20 22:14:28.053842+00	1411
1	927	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-927	1	-927	\N	C	2019-12-20 22:14:28.053842+00	1412
1	926	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-926	1	-926	\N	C	2019-12-20 22:14:28.053842+00	1413
1	925	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-925	1	-925	\N	C	2019-12-20 22:14:28.053842+00	1414
1	924	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-924	1	-924	\N	C	2019-12-20 22:14:28.053842+00	1415
1	923	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-923	1	-923	\N	C	2019-12-20 22:14:28.053842+00	1416
1	922	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-922	1	-922	\N	C	2019-12-20 22:14:28.053842+00	1417
1	921	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-921	1	-921	\N	C	2019-12-20 22:14:28.053842+00	1418
1	920	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-920	1	-920	\N	C	2019-12-20 22:14:28.053842+00	1419
1	919	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-919	1	-919	\N	C	2019-12-20 22:14:28.053842+00	1420
1	918	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-918	1	-918	\N	C	2019-12-20 22:14:28.053842+00	1421
1	917	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-917	1	-917	\N	C	2019-12-20 22:14:28.053842+00	1422
1	916	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-916	1	-916	\N	C	2019-12-20 22:14:28.053842+00	1423
1	915	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-915	1	-915	\N	C	2019-12-20 22:14:28.053842+00	1424
1	914	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-914	1	-914	\N	C	2019-12-20 22:14:28.053842+00	1425
1	913	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-913	1	-913	\N	C	2019-12-20 22:14:28.053842+00	1426
1	912	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-912	1	-912	\N	C	2019-12-20 22:14:28.053842+00	1427
1	911	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-911	1	-911	\N	C	2019-12-20 22:14:28.053842+00	1428
1	910	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-910	1	-910	\N	C	2019-12-20 22:14:28.053842+00	1429
1	909	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-909	1	-909	\N	C	2019-12-20 22:14:28.053842+00	1430
1	908	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-908	1	-908	\N	C	2019-12-20 22:14:28.053842+00	1431
1	907	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-907	1	-907	\N	C	2019-12-20 22:14:28.053842+00	1432
1	906	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-906	1	-906	\N	C	2019-12-20 22:14:28.053842+00	1433
1	905	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-905	1	-905	\N	C	2019-12-20 22:14:28.053842+00	1434
1	904	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-904	1	-904	\N	C	2019-12-20 22:14:28.053842+00	1435
1	903	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-903	1	-903	\N	C	2019-12-20 22:14:28.053842+00	1436
1	902	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-902	1	-902	\N	C	2019-12-20 22:14:28.053842+00	1437
1	901	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-901	1	-901	\N	C	2019-12-20 22:14:28.053842+00	1438
1	900	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-900	1	-900	\N	C	2019-12-20 22:14:28.053842+00	1439
1	899	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-899	1	-899	\N	C	2019-12-20 22:14:28.053842+00	1440
1	898	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-898	1	-898	\N	C	2019-12-20 22:14:28.053842+00	1441
1	897	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-897	1	-897	\N	C	2019-12-20 22:14:28.053842+00	1442
1	896	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-896	1	-896	\N	C	2019-12-20 22:14:28.053842+00	1443
1	895	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-895	1	-895	\N	C	2019-12-20 22:14:28.053842+00	1444
1	894	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-894	1	-894	\N	C	2019-12-20 22:14:28.053842+00	1445
1	893	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-893	1	-893	\N	C	2019-12-20 22:14:28.053842+00	1446
1	892	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-892	1	-892	\N	C	2019-12-20 22:14:28.053842+00	1447
1	891	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-891	1	-891	\N	C	2019-12-20 22:14:28.053842+00	1448
1	890	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-890	1	-890	\N	C	2019-12-20 22:14:28.053842+00	1449
1	889	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-889	1	-889	\N	C	2019-12-20 22:14:28.053842+00	1450
1	888	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-888	1	-888	\N	C	2019-12-20 22:14:28.053842+00	1451
1	887	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-887	1	-887	\N	C	2019-12-20 22:14:28.053842+00	1452
1	886	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-886	1	-886	\N	C	2019-12-20 22:14:28.053842+00	1453
1	885	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-885	1	-885	\N	C	2019-12-20 22:14:28.053842+00	1454
1	884	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-884	1	-884	\N	C	2019-12-20 22:14:28.053842+00	1455
1	883	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-883	1	-883	\N	C	2019-12-20 22:14:28.053842+00	1456
1	882	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-882	1	-882	\N	C	2019-12-20 22:14:28.053842+00	1457
1	881	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-881	1	-881	\N	C	2019-12-20 22:14:28.053842+00	1458
1	880	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-880	1	-880	\N	C	2019-12-20 22:14:28.053842+00	1459
1	879	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-879	1	-879	\N	C	2019-12-20 22:14:28.053842+00	1460
1	878	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-878	1	-878	\N	C	2019-12-20 22:14:28.053842+00	1461
1	877	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-877	1	-877	\N	C	2019-12-20 22:14:28.053842+00	1462
1	876	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-876	1	-876	\N	C	2019-12-20 22:14:28.053842+00	1463
1	875	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-875	1	-875	\N	C	2019-12-20 22:14:28.053842+00	1464
1	874	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-874	1	-874	\N	C	2019-12-20 22:14:28.053842+00	1465
1	873	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-873	1	-873	\N	C	2019-12-20 22:14:28.053842+00	1466
1	872	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-872	1	-872	\N	C	2019-12-20 22:14:28.053842+00	1467
1	871	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-871	1	-871	\N	C	2019-12-20 22:14:28.053842+00	1468
1	870	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-870	1	-870	\N	C	2019-12-20 22:14:28.053842+00	1469
1	869	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-869	1	-869	\N	C	2019-12-20 22:14:28.053842+00	1470
1	868	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-868	1	-868	\N	C	2019-12-20 22:14:28.053842+00	1471
1	867	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-867	1	-867	\N	C	2019-12-20 22:14:28.053842+00	1472
1	866	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-866	1	-866	\N	C	2019-12-20 22:14:28.053842+00	1473
1	865	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-865	1	-865	\N	C	2019-12-20 22:14:28.053842+00	1474
1	864	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-864	1	-864	\N	C	2019-12-20 22:14:28.053842+00	1475
1	863	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-863	1	-863	\N	C	2019-12-20 22:14:28.053842+00	1476
1	862	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-862	1	-862	\N	C	2019-12-20 22:14:28.053842+00	1477
1	861	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-861	1	-861	\N	C	2019-12-20 22:14:28.053842+00	1478
1	860	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-860	1	-860	\N	C	2019-12-20 22:14:28.053842+00	1479
1	859	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-859	1	-859	\N	C	2019-12-20 22:14:28.053842+00	1480
1	858	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-858	1	-858	\N	C	2019-12-20 22:14:28.053842+00	1481
1	857	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-857	1	-857	\N	C	2019-12-20 22:14:28.053842+00	1482
1	856	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-856	1	-856	\N	C	2019-12-20 22:14:28.053842+00	1483
1	855	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-855	1	-855	\N	C	2019-12-20 22:14:28.053842+00	1484
1	854	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-854	1	-854	\N	C	2019-12-20 22:14:28.053842+00	1485
1	853	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-853	1	-853	\N	C	2019-12-20 22:14:28.053842+00	1486
1	852	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-852	1	-852	\N	C	2019-12-20 22:14:28.053842+00	1487
1	851	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-851	1	-851	\N	C	2019-12-20 22:14:28.053842+00	1488
1	850	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-850	1	-850	\N	C	2019-12-20 22:14:28.053842+00	1489
1	849	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-849	1	-849	\N	C	2019-12-20 22:14:28.053842+00	1490
1	848	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-848	1	-848	\N	C	2019-12-20 22:14:28.053842+00	1491
1	847	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-847	1	-847	\N	C	2019-12-20 22:14:28.053842+00	1492
1	846	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-846	1	-846	\N	C	2019-12-20 22:14:28.053842+00	1493
1	845	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-845	1	-845	\N	C	2019-12-20 22:14:28.053842+00	1494
1	844	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-844	1	-844	\N	C	2019-12-20 22:14:28.053842+00	1495
1	843	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-843	1	-843	\N	C	2019-12-20 22:14:28.053842+00	1496
1	842	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-842	1	-842	\N	C	2019-12-20 22:14:28.053842+00	1497
1	841	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-841	1	-841	\N	C	2019-12-20 22:14:28.053842+00	1498
1	840	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-840	1	-840	\N	C	2019-12-20 22:14:28.053842+00	1499
1	839	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-839	1	-839	\N	C	2019-12-20 22:14:28.053842+00	1500
1	838	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-838	1	-838	\N	C	2019-12-20 22:14:28.053842+00	1501
1	837	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-837	1	-837	\N	C	2019-12-20 22:14:28.053842+00	1502
1	836	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-836	1	-836	\N	C	2019-12-20 22:14:28.053842+00	1503
1	835	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-835	1	-835	\N	C	2019-12-20 22:14:28.053842+00	1504
1	834	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-834	1	-834	\N	C	2019-12-20 22:14:28.053842+00	1505
1	833	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-833	1	-833	\N	C	2019-12-20 22:14:28.053842+00	1506
1	832	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-832	1	-832	\N	C	2019-12-20 22:14:28.053842+00	1507
1	831	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-831	1	-831	\N	C	2019-12-20 22:14:28.053842+00	1508
1	830	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-830	1	-830	\N	C	2019-12-20 22:14:28.053842+00	1509
1	829	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-829	1	-829	\N	C	2019-12-20 22:14:28.053842+00	1510
1	828	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-828	1	-828	\N	C	2019-12-20 22:14:28.053842+00	1511
1	827	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-827	1	-827	\N	C	2019-12-20 22:14:28.053842+00	1512
1	826	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-826	1	-826	\N	C	2019-12-20 22:14:28.053842+00	1513
1	825	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-825	1	-825	\N	C	2019-12-20 22:14:28.053842+00	1514
1	824	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-824	1	-824	\N	C	2019-12-20 22:14:28.053842+00	1515
1	823	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-823	1	-823	\N	C	2019-12-20 22:14:28.053842+00	1516
1	822	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-822	1	-822	\N	C	2019-12-20 22:14:28.053842+00	1517
1	821	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-821	1	-821	\N	C	2019-12-20 22:14:28.053842+00	1518
1	820	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-820	1	-820	\N	C	2019-12-20 22:14:28.053842+00	1519
1	819	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-819	1	-819	\N	C	2019-12-20 22:14:28.053842+00	1520
1	818	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-818	1	-818	\N	C	2019-12-20 22:14:28.053842+00	1521
1	817	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-817	1	-817	\N	C	2019-12-20 22:14:28.053842+00	1522
1	816	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-816	1	-816	\N	C	2019-12-20 22:14:28.053842+00	1523
1	815	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-815	1	-815	\N	C	2019-12-20 22:14:28.053842+00	1524
1	814	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-814	1	-814	\N	C	2019-12-20 22:14:28.053842+00	1525
1	813	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-813	1	-813	\N	C	2019-12-20 22:14:28.053842+00	1526
1	812	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-812	1	-812	\N	C	2019-12-20 22:14:28.053842+00	1527
1	811	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-811	1	-811	\N	C	2019-12-20 22:14:28.053842+00	1528
1	810	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-810	1	-810	\N	C	2019-12-20 22:14:28.053842+00	1529
1	809	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-809	1	-809	\N	C	2019-12-20 22:14:28.053842+00	1530
1	808	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-808	1	-808	\N	C	2019-12-20 22:14:28.053842+00	1531
1	807	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-807	1	-807	\N	C	2019-12-20 22:14:28.053842+00	1532
1	806	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-806	1	-806	\N	C	2019-12-20 22:14:28.053842+00	1533
1	805	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-805	1	-805	\N	C	2019-12-20 22:14:28.053842+00	1534
1	804	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-804	1	-804	\N	C	2019-12-20 22:14:28.053842+00	1535
1	803	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-803	1	-803	\N	C	2019-12-20 22:14:28.053842+00	1536
1	802	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-802	1	-802	\N	C	2019-12-20 22:14:28.053842+00	1537
1	801	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-801	1	-801	\N	C	2019-12-20 22:14:28.053842+00	1538
1	800	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-800	1	-800	\N	C	2019-12-20 22:14:28.053842+00	1539
1	799	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-799	1	-799	\N	C	2019-12-20 22:14:28.053842+00	1540
1	798	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-798	1	-798	\N	C	2019-12-20 22:14:28.053842+00	1541
1	797	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-797	1	-797	\N	C	2019-12-20 22:14:28.053842+00	1542
1	796	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-796	1	-796	\N	C	2019-12-20 22:14:28.053842+00	1543
1	795	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-795	1	-795	\N	C	2019-12-20 22:14:28.053842+00	1544
1	794	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-794	1	-794	\N	C	2019-12-20 22:14:28.053842+00	1545
1	793	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-793	1	-793	\N	C	2019-12-20 22:14:28.053842+00	1546
1	792	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-792	1	-792	\N	C	2019-12-20 22:14:28.053842+00	1547
1	791	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-791	1	-791	\N	C	2019-12-20 22:14:28.053842+00	1548
1	790	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-790	1	-790	\N	C	2019-12-20 22:14:28.053842+00	1549
1	789	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-789	1	-789	\N	C	2019-12-20 22:14:28.053842+00	1550
1	788	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-788	1	-788	\N	C	2019-12-20 22:14:28.053842+00	1551
1	787	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-787	1	-787	\N	C	2019-12-20 22:14:28.053842+00	1552
1	786	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-786	1	-786	\N	C	2019-12-20 22:14:28.053842+00	1553
1	785	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-785	1	-785	\N	C	2019-12-20 22:14:28.053842+00	1554
1	784	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-784	1	-784	\N	C	2019-12-20 22:14:28.053842+00	1555
1	783	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-783	1	-783	\N	C	2019-12-20 22:14:28.053842+00	1556
1	782	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-782	1	-782	\N	C	2019-12-20 22:14:28.053842+00	1557
1	781	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-781	1	-781	\N	C	2019-12-20 22:14:28.053842+00	1558
1	780	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-780	1	-780	\N	C	2019-12-20 22:14:28.053842+00	1559
1	779	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-779	1	-779	\N	C	2019-12-20 22:14:28.053842+00	1560
1	778	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-778	1	-778	\N	C	2019-12-20 22:14:28.053842+00	1561
1	777	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-777	1	-777	\N	C	2019-12-20 22:14:28.053842+00	1562
1	776	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-776	1	-776	\N	C	2019-12-20 22:14:28.053842+00	1563
1	775	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-775	1	-775	\N	C	2019-12-20 22:14:28.053842+00	1564
1	774	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-774	1	-774	\N	C	2019-12-20 22:14:28.053842+00	1565
1	773	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-773	1	-773	\N	C	2019-12-20 22:14:28.053842+00	1566
1	772	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-772	1	-772	\N	C	2019-12-20 22:14:28.053842+00	1567
1	771	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-771	1	-771	\N	C	2019-12-20 22:14:28.053842+00	1568
1	770	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-770	1	-770	\N	C	2019-12-20 22:14:28.053842+00	1569
1	769	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-769	1	-769	\N	C	2019-12-20 22:14:28.053842+00	1570
1	768	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-768	1	-768	\N	C	2019-12-20 22:14:28.053842+00	1571
1	767	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-767	1	-767	\N	C	2019-12-20 22:14:28.053842+00	1572
1	766	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-766	1	-766	\N	C	2019-12-20 22:14:28.053842+00	1573
1	765	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-765	1	-765	\N	C	2019-12-20 22:14:28.053842+00	1574
1	764	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-764	1	-764	\N	C	2019-12-20 22:14:28.053842+00	1575
1	763	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-763	1	-763	\N	C	2019-12-20 22:14:28.053842+00	1576
1	762	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-762	1	-762	\N	C	2019-12-20 22:14:28.053842+00	1577
1	761	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-761	1	-761	\N	C	2019-12-20 22:14:28.053842+00	1578
1	760	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-760	1	-760	\N	C	2019-12-20 22:14:28.053842+00	1579
1	759	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-759	1	-759	\N	C	2019-12-20 22:14:28.053842+00	1580
1	758	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-758	1	-758	\N	C	2019-12-20 22:14:28.053842+00	1581
1	757	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-757	1	-757	\N	C	2019-12-20 22:14:28.053842+00	1582
1	756	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-756	1	-756	\N	C	2019-12-20 22:14:28.053842+00	1583
1	755	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-755	1	-755	\N	C	2019-12-20 22:14:28.053842+00	1584
1	754	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-754	1	-754	\N	C	2019-12-20 22:14:28.053842+00	1585
1	753	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-753	1	-753	\N	C	2019-12-20 22:14:28.053842+00	1586
1	752	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-752	1	-752	\N	C	2019-12-20 22:14:28.053842+00	1587
1	751	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-751	1	-751	\N	C	2019-12-20 22:14:28.053842+00	1588
1	750	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-750	1	-750	\N	C	2019-12-20 22:14:28.053842+00	1589
1	749	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-749	1	-749	\N	C	2019-12-20 22:14:28.053842+00	1590
1	748	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-748	1	-748	\N	C	2019-12-20 22:14:28.053842+00	1591
1	747	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-747	1	-747	\N	C	2019-12-20 22:14:28.053842+00	1592
1	746	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-746	1	-746	\N	C	2019-12-20 22:14:28.053842+00	1593
1	745	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-745	1	-745	\N	C	2019-12-20 22:14:28.053842+00	1594
1	744	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-744	1	-744	\N	C	2019-12-20 22:14:28.053842+00	1595
1	743	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-743	1	-743	\N	C	2019-12-20 22:14:28.053842+00	1596
1	742	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-742	1	-742	\N	C	2019-12-20 22:14:28.053842+00	1597
1	741	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-741	1	-741	\N	C	2019-12-20 22:14:28.053842+00	1598
1	740	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-740	1	-740	\N	C	2019-12-20 22:14:28.053842+00	1599
1	739	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-739	1	-739	\N	C	2019-12-20 22:14:28.053842+00	1600
1	738	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-738	1	-738	\N	C	2019-12-20 22:14:28.053842+00	1601
1	737	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-737	1	-737	\N	C	2019-12-20 22:14:28.053842+00	1602
1	736	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-736	1	-736	\N	C	2019-12-20 22:14:28.053842+00	1603
1	735	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-735	1	-735	\N	C	2019-12-20 22:14:28.053842+00	1604
1	734	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-734	1	-734	\N	C	2019-12-20 22:14:28.053842+00	1605
1	733	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-733	1	-733	\N	C	2019-12-20 22:14:28.053842+00	1606
1	732	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-732	1	-732	\N	C	2019-12-20 22:14:28.053842+00	1607
1	731	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-731	1	-731	\N	C	2019-12-20 22:14:28.053842+00	1608
1	730	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-730	1	-730	\N	C	2019-12-20 22:14:28.053842+00	1609
1	729	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-729	1	-729	\N	C	2019-12-20 22:14:28.053842+00	1610
1	728	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-728	1	-728	\N	C	2019-12-20 22:14:28.053842+00	1611
1	727	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-727	1	-727	\N	C	2019-12-20 22:14:28.053842+00	1612
1	726	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-726	1	-726	\N	C	2019-12-20 22:14:28.053842+00	1613
1	725	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-725	1	-725	\N	C	2019-12-20 22:14:28.053842+00	1614
1	724	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-724	1	-724	\N	C	2019-12-20 22:14:28.053842+00	1615
1	723	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-723	1	-723	\N	C	2019-12-20 22:14:28.053842+00	1616
1	722	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-722	1	-722	\N	C	2019-12-20 22:14:28.053842+00	1617
1	721	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-721	1	-721	\N	C	2019-12-20 22:14:28.053842+00	1618
1	720	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-720	1	-720	\N	C	2019-12-20 22:14:28.053842+00	1619
1	719	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-719	1	-719	\N	C	2019-12-20 22:14:28.053842+00	1620
1	718	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-718	1	-718	\N	C	2019-12-20 22:14:28.053842+00	1621
1	717	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-717	1	-717	\N	C	2019-12-20 22:14:28.053842+00	1622
1	716	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-716	1	-716	\N	C	2019-12-20 22:14:28.053842+00	1623
1	715	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-715	1	-715	\N	C	2019-12-20 22:14:28.053842+00	1624
1	714	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-714	1	-714	\N	C	2019-12-20 22:14:28.053842+00	1625
1	713	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-713	1	-713	\N	C	2019-12-20 22:14:28.053842+00	1626
1	712	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-712	1	-712	\N	C	2019-12-20 22:14:28.053842+00	1627
1	711	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-711	1	-711	\N	C	2019-12-20 22:14:28.053842+00	1628
1	710	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-710	1	-710	\N	C	2019-12-20 22:14:28.053842+00	1629
1	709	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-709	1	-709	\N	C	2019-12-20 22:14:28.053842+00	1630
1	708	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-708	1	-708	\N	C	2019-12-20 22:14:28.053842+00	1631
1	707	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-707	1	-707	\N	C	2019-12-20 22:14:28.053842+00	1632
1	706	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-706	1	-706	\N	C	2019-12-20 22:14:28.053842+00	1633
1	705	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-705	1	-705	\N	C	2019-12-20 22:14:28.053842+00	1634
1	704	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-704	1	-704	\N	C	2019-12-20 22:14:28.053842+00	1635
1	703	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-703	1	-703	\N	C	2019-12-20 22:14:28.053842+00	1636
1	702	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-702	1	-702	\N	C	2019-12-20 22:14:28.053842+00	1637
1	701	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-701	1	-701	\N	C	2019-12-20 22:14:28.053842+00	1638
1	700	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-700	1	-700	\N	C	2019-12-20 22:14:28.053842+00	1639
1	699	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-699	1	-699	\N	C	2019-12-20 22:14:28.053842+00	1640
1	698	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-698	1	-698	\N	C	2019-12-20 22:14:28.053842+00	1641
1	697	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-697	1	-697	\N	C	2019-12-20 22:14:28.053842+00	1642
1	696	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-696	1	-696	\N	C	2019-12-20 22:14:28.053842+00	1643
1	695	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-695	1	-695	\N	C	2019-12-20 22:14:28.053842+00	1644
1	694	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-694	1	-694	\N	C	2019-12-20 22:14:28.053842+00	1645
1	693	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-693	1	-693	\N	C	2019-12-20 22:14:28.053842+00	1646
1	692	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-692	1	-692	\N	C	2019-12-20 22:14:28.053842+00	1647
1	691	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-691	1	-691	\N	C	2019-12-20 22:14:28.053842+00	1648
1	690	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-690	1	-690	\N	C	2019-12-20 22:14:28.053842+00	1649
1	689	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-689	1	-689	\N	C	2019-12-20 22:14:28.053842+00	1650
1	688	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-688	1	-688	\N	C	2019-12-20 22:14:28.053842+00	1651
1	687	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-687	1	-687	\N	C	2019-12-20 22:14:28.053842+00	1652
1	686	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-686	1	-686	\N	C	2019-12-20 22:14:28.053842+00	1653
1	685	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-685	1	-685	\N	C	2019-12-20 22:14:28.053842+00	1654
1	684	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-684	1	-684	\N	C	2019-12-20 22:14:28.053842+00	1655
1	683	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-683	1	-683	\N	C	2019-12-20 22:14:28.053842+00	1656
1	682	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-682	1	-682	\N	C	2019-12-20 22:14:28.053842+00	1657
1	681	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-681	1	-681	\N	C	2019-12-20 22:14:28.053842+00	1658
1	680	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-680	1	-680	\N	C	2019-12-20 22:14:28.053842+00	1659
1	679	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-679	1	-679	\N	C	2019-12-20 22:14:28.053842+00	1660
1	678	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-678	1	-678	\N	C	2019-12-20 22:14:28.053842+00	1661
1	677	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-677	1	-677	\N	C	2019-12-20 22:14:28.053842+00	1662
1	676	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-676	1	-676	\N	C	2019-12-20 22:14:28.053842+00	1663
1	675	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-675	1	-675	\N	C	2019-12-20 22:14:28.053842+00	1664
1	674	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-674	1	-674	\N	C	2019-12-20 22:14:28.053842+00	1665
1	673	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-673	1	-673	\N	C	2019-12-20 22:14:28.053842+00	1666
1	672	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-672	1	-672	\N	C	2019-12-20 22:14:28.053842+00	1667
1	671	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-671	1	-671	\N	C	2019-12-20 22:14:28.053842+00	1668
1	670	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-670	1	-670	\N	C	2019-12-20 22:14:28.053842+00	1669
1	669	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-669	1	-669	\N	C	2019-12-20 22:14:28.053842+00	1670
1	668	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-668	1	-668	\N	C	2019-12-20 22:14:28.053842+00	1671
1	667	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-667	1	-667	\N	C	2019-12-20 22:14:28.053842+00	1672
1	666	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-666	1	-666	\N	C	2019-12-20 22:14:28.053842+00	1673
1	665	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-665	1	-665	\N	C	2019-12-20 22:14:28.053842+00	1674
1	664	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-664	1	-664	\N	C	2019-12-20 22:14:28.053842+00	1675
1	663	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-663	1	-663	\N	C	2019-12-20 22:14:28.053842+00	1676
1	662	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-662	1	-662	\N	C	2019-12-20 22:14:28.053842+00	1677
1	661	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-661	1	-661	\N	C	2019-12-20 22:14:28.053842+00	1678
1	660	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-660	1	-660	\N	C	2019-12-20 22:14:28.053842+00	1679
1	659	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-659	1	-659	\N	C	2019-12-20 22:14:28.053842+00	1680
1	658	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-658	1	-658	\N	C	2019-12-20 22:14:28.053842+00	1681
1	657	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-657	1	-657	\N	C	2019-12-20 22:14:28.053842+00	1682
1	656	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-656	1	-656	\N	C	2019-12-20 22:14:28.053842+00	1683
1	655	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-655	1	-655	\N	C	2019-12-20 22:14:28.053842+00	1684
1	654	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-654	1	-654	\N	C	2019-12-20 22:14:28.053842+00	1685
1	653	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-653	1	-653	\N	C	2019-12-20 22:14:28.053842+00	1686
1	652	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-652	1	-652	\N	C	2019-12-20 22:14:28.053842+00	1687
1	651	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-651	1	-651	\N	C	2019-12-20 22:14:28.053842+00	1688
1	650	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-650	1	-650	\N	C	2019-12-20 22:14:28.053842+00	1689
1	649	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-649	1	-649	\N	C	2019-12-20 22:14:28.053842+00	1690
1	648	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-648	1	-648	\N	C	2019-12-20 22:14:28.053842+00	1691
1	647	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-647	1	-647	\N	C	2019-12-20 22:14:28.053842+00	1692
1	646	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-646	1	-646	\N	C	2019-12-20 22:14:28.053842+00	1693
1	645	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-645	1	-645	\N	C	2019-12-20 22:14:28.053842+00	1694
1	644	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-644	1	-644	\N	C	2019-12-20 22:14:28.053842+00	1695
1	643	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-643	1	-643	\N	C	2019-12-20 22:14:28.053842+00	1696
1	642	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-642	1	-642	\N	C	2019-12-20 22:14:28.053842+00	1697
1	641	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-641	1	-641	\N	C	2019-12-20 22:14:28.053842+00	1698
1	640	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-640	1	-640	\N	C	2019-12-20 22:14:28.053842+00	1699
1	639	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-639	1	-639	\N	C	2019-12-20 22:14:28.053842+00	1700
1	638	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-638	1	-638	\N	C	2019-12-20 22:14:28.053842+00	1701
1	637	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-637	1	-637	\N	C	2019-12-20 22:14:28.053842+00	1702
1	636	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-636	1	-636	\N	C	2019-12-20 22:14:28.053842+00	1703
1	635	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-635	1	-635	\N	C	2019-12-20 22:14:28.053842+00	1704
1	634	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-634	1	-634	\N	C	2019-12-20 22:14:28.053842+00	1705
1	633	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-633	1	-633	\N	C	2019-12-20 22:14:28.053842+00	1706
1	632	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-632	1	-632	\N	C	2019-12-20 22:14:28.053842+00	1707
1	631	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-631	1	-631	\N	C	2019-12-20 22:14:28.053842+00	1708
1	630	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-630	1	-630	\N	C	2019-12-20 22:14:28.053842+00	1709
1	629	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-629	1	-629	\N	C	2019-12-20 22:14:28.053842+00	1710
1	628	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-628	1	-628	\N	C	2019-12-20 22:14:28.053842+00	1711
1	627	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-627	1	-627	\N	C	2019-12-20 22:14:28.053842+00	1712
1	626	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-626	1	-626	\N	C	2019-12-20 22:14:28.053842+00	1713
1	625	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-625	1	-625	\N	C	2019-12-20 22:14:28.053842+00	1714
1	624	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-624	1	-624	\N	C	2019-12-20 22:14:28.053842+00	1715
1	623	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-623	1	-623	\N	C	2019-12-20 22:14:28.053842+00	1716
1	622	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-622	1	-622	\N	C	2019-12-20 22:14:28.053842+00	1717
1	621	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-621	1	-621	\N	C	2019-12-20 22:14:28.053842+00	1718
1	620	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-620	1	-620	\N	C	2019-12-20 22:14:28.053842+00	1719
1	619	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-619	1	-619	\N	C	2019-12-20 22:14:28.053842+00	1720
1	618	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-618	1	-618	\N	C	2019-12-20 22:14:28.053842+00	1721
1	617	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-617	1	-617	\N	C	2019-12-20 22:14:28.053842+00	1722
1	616	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-616	1	-616	\N	C	2019-12-20 22:14:28.053842+00	1723
1	615	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-615	1	-615	\N	C	2019-12-20 22:14:28.053842+00	1724
1	614	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-614	1	-614	\N	C	2019-12-20 22:14:28.053842+00	1725
1	613	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-613	1	-613	\N	C	2019-12-20 22:14:28.053842+00	1726
1	612	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-612	1	-612	\N	C	2019-12-20 22:14:28.053842+00	1727
1	611	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-611	1	-611	\N	C	2019-12-20 22:14:28.053842+00	1728
1	610	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-610	1	-610	\N	C	2019-12-20 22:14:28.053842+00	1729
1	609	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-609	1	-609	\N	C	2019-12-20 22:14:28.053842+00	1730
1	608	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-608	1	-608	\N	C	2019-12-20 22:14:28.053842+00	1731
1	607	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-607	1	-607	\N	C	2019-12-20 22:14:28.053842+00	1732
1	606	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-606	1	-606	\N	C	2019-12-20 22:14:28.053842+00	1733
1	605	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-605	1	-605	\N	C	2019-12-20 22:14:28.053842+00	1734
1	604	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-604	1	-604	\N	C	2019-12-20 22:14:28.053842+00	1735
1	603	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-603	1	-603	\N	C	2019-12-20 22:14:28.053842+00	1736
1	602	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-602	1	-602	\N	C	2019-12-20 22:14:28.053842+00	1737
1	601	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-601	1	-601	\N	C	2019-12-20 22:14:28.053842+00	1738
1	600	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-600	1	-600	\N	C	2019-12-20 22:14:28.053842+00	1739
1	599	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-599	1	-599	\N	C	2019-12-20 22:14:28.053842+00	1740
1	598	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-598	1	-598	\N	C	2019-12-20 22:14:28.053842+00	1741
1	597	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-597	1	-597	\N	C	2019-12-20 22:14:28.053842+00	1742
1	596	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-596	1	-596	\N	C	2019-12-20 22:14:28.053842+00	1743
1	595	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-595	1	-595	\N	C	2019-12-20 22:14:28.053842+00	1744
1	594	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-594	1	-594	\N	C	2019-12-20 22:14:28.053842+00	1745
1	593	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-593	1	-593	\N	C	2019-12-20 22:14:28.053842+00	1746
1	592	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-592	1	-592	\N	C	2019-12-20 22:14:28.053842+00	1747
1	591	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-591	1	-591	\N	C	2019-12-20 22:14:28.053842+00	1748
1	590	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-590	1	-590	\N	C	2019-12-20 22:14:28.053842+00	1749
1	589	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-589	1	-589	\N	C	2019-12-20 22:14:28.053842+00	1750
1	588	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-588	1	-588	\N	C	2019-12-20 22:14:28.053842+00	1751
1	587	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-587	1	-587	\N	C	2019-12-20 22:14:28.053842+00	1752
1	586	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-586	1	-586	\N	C	2019-12-20 22:14:28.053842+00	1753
1	585	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-585	1	-585	\N	C	2019-12-20 22:14:28.053842+00	1754
1	584	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-584	1	-584	\N	C	2019-12-20 22:14:28.053842+00	1755
1	583	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-583	1	-583	\N	C	2019-12-20 22:14:28.053842+00	1756
1	582	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-582	1	-582	\N	C	2019-12-20 22:14:28.053842+00	1757
1	581	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-581	1	-581	\N	C	2019-12-20 22:14:28.053842+00	1758
1	580	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-580	1	-580	\N	C	2019-12-20 22:14:28.053842+00	1759
1	579	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-579	1	-579	\N	C	2019-12-20 22:14:28.053842+00	1760
1	578	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-578	1	-578	\N	C	2019-12-20 22:14:28.053842+00	1761
1	577	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-577	1	-577	\N	C	2019-12-20 22:14:28.053842+00	1762
1	576	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-576	1	-576	\N	C	2019-12-20 22:14:28.053842+00	1763
1	575	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-575	1	-575	\N	C	2019-12-20 22:14:28.053842+00	1764
1	574	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-574	1	-574	\N	C	2019-12-20 22:14:28.053842+00	1765
1	573	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-573	1	-573	\N	C	2019-12-20 22:14:28.053842+00	1766
1	572	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-572	1	-572	\N	C	2019-12-20 22:14:28.053842+00	1767
1	571	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-571	1	-571	\N	C	2019-12-20 22:14:28.053842+00	1768
1	570	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-570	1	-570	\N	C	2019-12-20 22:14:28.053842+00	1769
1	569	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-569	1	-569	\N	C	2019-12-20 22:14:28.053842+00	1770
1	568	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-568	1	-568	\N	C	2019-12-20 22:14:28.053842+00	1771
1	567	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-567	1	-567	\N	C	2019-12-20 22:14:28.053842+00	1772
1	566	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-566	1	-566	\N	C	2019-12-20 22:14:28.053842+00	1773
1	565	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-565	1	-565	\N	C	2019-12-20 22:14:28.053842+00	1774
1	564	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-564	1	-564	\N	C	2019-12-20 22:14:28.053842+00	1775
1	563	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-563	1	-563	\N	C	2019-12-20 22:14:28.053842+00	1776
1	562	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-562	1	-562	\N	C	2019-12-20 22:14:28.053842+00	1777
1	561	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-561	1	-561	\N	C	2019-12-20 22:14:28.053842+00	1778
1	560	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-560	1	-560	\N	C	2019-12-20 22:14:28.053842+00	1779
1	559	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-559	1	-559	\N	C	2019-12-20 22:14:28.053842+00	1780
1	558	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-558	1	-558	\N	C	2019-12-20 22:14:28.053842+00	1781
1	557	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-557	1	-557	\N	C	2019-12-20 22:14:28.053842+00	1782
1	556	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-556	1	-556	\N	C	2019-12-20 22:14:28.053842+00	1783
1	555	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-555	1	-555	\N	C	2019-12-20 22:14:28.053842+00	1784
1	554	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-554	1	-554	\N	C	2019-12-20 22:14:28.053842+00	1785
1	553	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-553	1	-553	\N	C	2019-12-20 22:14:28.053842+00	1786
1	552	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-552	1	-552	\N	C	2019-12-20 22:14:28.053842+00	1787
1	551	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-551	1	-551	\N	C	2019-12-20 22:14:28.053842+00	1788
1	550	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-550	1	-550	\N	C	2019-12-20 22:14:28.053842+00	1789
1	549	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-549	1	-549	\N	C	2019-12-20 22:14:28.053842+00	1790
1	548	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-548	1	-548	\N	C	2019-12-20 22:14:28.053842+00	1791
1	547	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-547	1	-547	\N	C	2019-12-20 22:14:28.053842+00	1792
1	546	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-546	1	-546	\N	C	2019-12-20 22:14:28.053842+00	1793
1	545	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-545	1	-545	\N	C	2019-12-20 22:14:28.053842+00	1794
1	544	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-544	1	-544	\N	C	2019-12-20 22:14:28.053842+00	1795
1	543	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-543	1	-543	\N	C	2019-12-20 22:14:28.053842+00	1796
1	542	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-542	1	-542	\N	C	2019-12-20 22:14:28.053842+00	1797
1	541	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-541	1	-541	\N	C	2019-12-20 22:14:28.053842+00	1798
1	540	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-540	1	-540	\N	C	2019-12-20 22:14:28.053842+00	1799
1	539	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-539	1	-539	\N	C	2019-12-20 22:14:28.053842+00	1800
1	538	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-538	1	-538	\N	C	2019-12-20 22:14:28.053842+00	1801
1	537	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-537	1	-537	\N	C	2019-12-20 22:14:28.053842+00	1802
1	536	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-536	1	-536	\N	C	2019-12-20 22:14:28.053842+00	1803
1	535	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-535	1	-535	\N	C	2019-12-20 22:14:28.053842+00	1804
1	534	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-534	1	-534	\N	C	2019-12-20 22:14:28.053842+00	1805
1	533	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-533	1	-533	\N	C	2019-12-20 22:14:28.053842+00	1806
1	532	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-532	1	-532	\N	C	2019-12-20 22:14:28.053842+00	1807
1	531	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-531	1	-531	\N	C	2019-12-20 22:14:28.053842+00	1808
1	530	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-530	1	-530	\N	C	2019-12-20 22:14:28.053842+00	1809
1	529	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-529	1	-529	\N	C	2019-12-20 22:14:28.053842+00	1810
1	528	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-528	1	-528	\N	C	2019-12-20 22:14:28.053842+00	1811
1	527	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-527	1	-527	\N	C	2019-12-20 22:14:28.053842+00	1812
1	526	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-526	1	-526	\N	C	2019-12-20 22:14:28.053842+00	1813
1	525	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-525	1	-525	\N	C	2019-12-20 22:14:28.053842+00	1814
1	524	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-524	1	-524	\N	C	2019-12-20 22:14:28.053842+00	1815
1	523	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-523	1	-523	\N	C	2019-12-20 22:14:28.053842+00	1816
1	522	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-522	1	-522	\N	C	2019-12-20 22:14:28.053842+00	1817
1	521	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-521	1	-521	\N	C	2019-12-20 22:14:28.053842+00	1818
1	520	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-520	1	-520	\N	C	2019-12-20 22:14:28.053842+00	1819
1	519	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-519	1	-519	\N	C	2019-12-20 22:14:28.053842+00	1820
1	518	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-518	1	-518	\N	C	2019-12-20 22:14:28.053842+00	1821
1	517	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-517	1	-517	\N	C	2019-12-20 22:14:28.053842+00	1822
1	516	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-516	1	-516	\N	C	2019-12-20 22:14:28.053842+00	1823
1	515	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-515	1	-515	\N	C	2019-12-20 22:14:28.053842+00	1824
1	514	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-514	1	-514	\N	C	2019-12-20 22:14:28.053842+00	1825
1	513	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-513	1	-513	\N	C	2019-12-20 22:14:28.053842+00	1826
1	512	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-512	1	-512	\N	C	2019-12-20 22:14:28.053842+00	1827
1	511	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-511	1	-511	\N	C	2019-12-20 22:14:28.053842+00	1828
1	510	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-510	1	-510	\N	C	2019-12-20 22:14:28.053842+00	1829
1	509	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-509	1	-509	\N	C	2019-12-20 22:14:28.053842+00	1830
1	508	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-508	1	-508	\N	C	2019-12-20 22:14:28.053842+00	1831
1	507	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-507	1	-507	\N	C	2019-12-20 22:14:28.053842+00	1832
1	506	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-506	1	-506	\N	C	2019-12-20 22:14:28.053842+00	1833
1	505	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-505	1	-505	\N	C	2019-12-20 22:14:28.053842+00	1834
1	504	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-504	1	-504	\N	C	2019-12-20 22:14:28.053842+00	1835
1	503	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-503	1	-503	\N	C	2019-12-20 22:14:28.053842+00	1836
1	502	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-502	1	-502	\N	C	2019-12-20 22:14:28.053842+00	1837
1	501	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-501	1	-501	\N	C	2019-12-20 22:14:28.053842+00	1838
1	500	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-500	1	-500	\N	C	2019-12-20 22:14:28.053842+00	1839
1	499	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-499	1	-499	\N	C	2019-12-20 22:14:28.053842+00	1840
1	498	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-498	1	-498	\N	C	2019-12-20 22:14:28.053842+00	1841
1	497	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-497	1	-497	\N	C	2019-12-20 22:14:28.053842+00	1842
1	496	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-496	1	-496	\N	C	2019-12-20 22:14:28.053842+00	1843
1	495	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-495	1	-495	\N	C	2019-12-20 22:14:28.053842+00	1844
1	494	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-494	1	-494	\N	C	2019-12-20 22:14:28.053842+00	1845
1	493	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-493	1	-493	\N	C	2019-12-20 22:14:28.053842+00	1846
1	492	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-492	1	-492	\N	C	2019-12-20 22:14:28.053842+00	1847
1	491	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-491	1	-491	\N	C	2019-12-20 22:14:28.053842+00	1848
1	490	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-490	1	-490	\N	C	2019-12-20 22:14:28.053842+00	1849
1	489	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-489	1	-489	\N	C	2019-12-20 22:14:28.053842+00	1850
1	488	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-488	1	-488	\N	C	2019-12-20 22:14:28.053842+00	1851
1	487	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-487	1	-487	\N	C	2019-12-20 22:14:28.053842+00	1852
1	486	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-486	1	-486	\N	C	2019-12-20 22:14:28.053842+00	1853
1	485	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-485	1	-485	\N	C	2019-12-20 22:14:28.053842+00	1854
1	484	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-484	1	-484	\N	C	2019-12-20 22:14:28.053842+00	1855
1	483	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-483	1	-483	\N	C	2019-12-20 22:14:28.053842+00	1856
1	482	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-482	1	-482	\N	C	2019-12-20 22:14:28.053842+00	1857
1	481	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-481	1	-481	\N	C	2019-12-20 22:14:28.053842+00	1858
1	480	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-480	1	-480	\N	C	2019-12-20 22:14:28.053842+00	1859
1	479	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-479	1	-479	\N	C	2019-12-20 22:14:28.053842+00	1860
1	478	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-478	1	-478	\N	C	2019-12-20 22:14:28.053842+00	1861
1	477	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-477	1	-477	\N	C	2019-12-20 22:14:28.053842+00	1862
1	476	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-476	1	-476	\N	C	2019-12-20 22:14:28.053842+00	1863
1	475	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-475	1	-475	\N	C	2019-12-20 22:14:28.053842+00	1864
1	474	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-474	1	-474	\N	C	2019-12-20 22:14:28.053842+00	1865
1	473	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-473	1	-473	\N	C	2019-12-20 22:14:28.053842+00	1866
1	472	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-472	1	-472	\N	C	2019-12-20 22:14:28.053842+00	1867
1	471	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-471	1	-471	\N	C	2019-12-20 22:14:28.053842+00	1868
1	470	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-470	1	-470	\N	C	2019-12-20 22:14:28.053842+00	1869
1	469	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-469	1	-469	\N	C	2019-12-20 22:14:28.053842+00	1870
1	468	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-468	1	-468	\N	C	2019-12-20 22:14:28.053842+00	1871
1	467	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-467	1	-467	\N	C	2019-12-20 22:14:28.053842+00	1872
1	466	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-466	1	-466	\N	C	2019-12-20 22:14:28.053842+00	1873
1	465	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-465	1	-465	\N	C	2019-12-20 22:14:28.053842+00	1874
1	464	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-464	1	-464	\N	C	2019-12-20 22:14:28.053842+00	1875
1	463	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-463	1	-463	\N	C	2019-12-20 22:14:28.053842+00	1876
1	462	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-462	1	-462	\N	C	2019-12-20 22:14:28.053842+00	1877
1	461	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-461	1	-461	\N	C	2019-12-20 22:14:28.053842+00	1878
1	460	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-460	1	-460	\N	C	2019-12-20 22:14:28.053842+00	1879
1	459	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-459	1	-459	\N	C	2019-12-20 22:14:28.053842+00	1880
1	458	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-458	1	-458	\N	C	2019-12-20 22:14:28.053842+00	1881
1	457	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-457	1	-457	\N	C	2019-12-20 22:14:28.053842+00	1882
1	456	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-456	1	-456	\N	C	2019-12-20 22:14:28.053842+00	1883
1	455	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-455	1	-455	\N	C	2019-12-20 22:14:28.053842+00	1884
1	454	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-454	1	-454	\N	C	2019-12-20 22:14:28.053842+00	1885
1	453	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-453	1	-453	\N	C	2019-12-20 22:14:28.053842+00	1886
1	452	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-452	1	-452	\N	C	2019-12-20 22:14:28.053842+00	1887
1	451	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-451	1	-451	\N	C	2019-12-20 22:14:28.053842+00	1888
1	450	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-450	1	-450	\N	C	2019-12-20 22:14:28.053842+00	1889
1	449	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-449	1	-449	\N	C	2019-12-20 22:14:28.053842+00	1890
1	448	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-448	1	-448	\N	C	2019-12-20 22:14:28.053842+00	1891
1	447	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-447	1	-447	\N	C	2019-12-20 22:14:28.053842+00	1892
1	446	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-446	1	-446	\N	C	2019-12-20 22:14:28.053842+00	1893
1	445	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-445	1	-445	\N	C	2019-12-20 22:14:28.053842+00	1894
1	444	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-444	1	-444	\N	C	2019-12-20 22:14:28.053842+00	1895
1	443	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-443	1	-443	\N	C	2019-12-20 22:14:28.053842+00	1896
1	442	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-442	1	-442	\N	C	2019-12-20 22:14:28.053842+00	1897
1	441	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-441	1	-441	\N	C	2019-12-20 22:14:28.053842+00	1898
1	440	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-440	1	-440	\N	C	2019-12-20 22:14:28.053842+00	1899
1	439	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-439	1	-439	\N	C	2019-12-20 22:14:28.053842+00	1900
1	438	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-438	1	-438	\N	C	2019-12-20 22:14:28.053842+00	1901
1	437	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-437	1	-437	\N	C	2019-12-20 22:14:28.053842+00	1902
1	436	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-436	1	-436	\N	C	2019-12-20 22:14:28.053842+00	1903
1	435	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-435	1	-435	\N	C	2019-12-20 22:14:28.053842+00	1904
1	434	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-434	1	-434	\N	C	2019-12-20 22:14:28.053842+00	1905
1	433	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-433	1	-433	\N	C	2019-12-20 22:14:28.053842+00	1906
1	432	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-432	1	-432	\N	C	2019-12-20 22:14:28.053842+00	1907
1	431	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-431	1	-431	\N	C	2019-12-20 22:14:28.053842+00	1908
1	430	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-430	1	-430	\N	C	2019-12-20 22:14:28.053842+00	1909
1	429	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-429	1	-429	\N	C	2019-12-20 22:14:28.053842+00	1910
1	428	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-428	1	-428	\N	C	2019-12-20 22:14:28.053842+00	1911
1	427	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-427	1	-427	\N	C	2019-12-20 22:14:28.053842+00	1912
1	426	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-426	1	-426	\N	C	2019-12-20 22:14:28.053842+00	1913
1	425	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-425	1	-425	\N	C	2019-12-20 22:14:28.053842+00	1914
1	424	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-424	1	-424	\N	C	2019-12-20 22:14:28.053842+00	1915
1	423	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-423	1	-423	\N	C	2019-12-20 22:14:28.053842+00	1916
1	422	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-422	1	-422	\N	C	2019-12-20 22:14:28.053842+00	1917
1	421	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-421	1	-421	\N	C	2019-12-20 22:14:28.053842+00	1918
1	420	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-420	1	-420	\N	C	2019-12-20 22:14:28.053842+00	1919
1	419	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-419	1	-419	\N	C	2019-12-20 22:14:28.053842+00	1920
1	418	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-418	1	-418	\N	C	2019-12-20 22:14:28.053842+00	1921
1	417	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-417	1	-417	\N	C	2019-12-20 22:14:28.053842+00	1922
1	416	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-416	1	-416	\N	C	2019-12-20 22:14:28.053842+00	1923
1	415	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-415	1	-415	\N	C	2019-12-20 22:14:28.053842+00	1924
1	414	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-414	1	-414	\N	C	2019-12-20 22:14:28.053842+00	1925
1	413	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-413	1	-413	\N	C	2019-12-20 22:14:28.053842+00	1926
1	412	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-412	1	-412	\N	C	2019-12-20 22:14:28.053842+00	1927
1	411	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-411	1	-411	\N	C	2019-12-20 22:14:28.053842+00	1928
1	410	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-410	1	-410	\N	C	2019-12-20 22:14:28.053842+00	1929
1	409	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-409	1	-409	\N	C	2019-12-20 22:14:28.053842+00	1930
1	408	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-408	1	-408	\N	C	2019-12-20 22:14:28.053842+00	1931
1	407	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-407	1	-407	\N	C	2019-12-20 22:14:28.053842+00	1932
1	406	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-406	1	-406	\N	C	2019-12-20 22:14:28.053842+00	1933
1	405	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-405	1	-405	\N	C	2019-12-20 22:14:28.053842+00	1934
1	404	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-404	1	-404	\N	C	2019-12-20 22:14:28.053842+00	1935
1	403	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-403	1	-403	\N	C	2019-12-20 22:14:28.053842+00	1936
1	402	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-402	1	-402	\N	C	2019-12-20 22:14:28.053842+00	1937
1	401	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-401	1	-401	\N	C	2019-12-20 22:14:28.053842+00	1938
1	400	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-400	1	-400	\N	C	2019-12-20 22:14:28.053842+00	1939
1	399	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-399	1	-399	\N	C	2019-12-20 22:14:28.053842+00	1940
1	398	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-398	1	-398	\N	C	2019-12-20 22:14:28.053842+00	1941
1	397	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-397	1	-397	\N	C	2019-12-20 22:14:28.053842+00	1942
1	396	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-396	1	-396	\N	C	2019-12-20 22:14:28.053842+00	1943
1	395	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-395	1	-395	\N	C	2019-12-20 22:14:28.053842+00	1944
1	394	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-394	1	-394	\N	C	2019-12-20 22:14:28.053842+00	1945
1	393	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-393	1	-393	\N	C	2019-12-20 22:14:28.053842+00	1946
1	392	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-392	1	-392	\N	C	2019-12-20 22:14:28.053842+00	1947
1	391	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-391	1	-391	\N	C	2019-12-20 22:14:28.053842+00	1948
1	390	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-390	1	-390	\N	C	2019-12-20 22:14:28.053842+00	1949
1	389	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-389	1	-389	\N	C	2019-12-20 22:14:28.053842+00	1950
1	388	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-388	1	-388	\N	C	2019-12-20 22:14:28.053842+00	1951
1	387	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-387	1	-387	\N	C	2019-12-20 22:14:28.053842+00	1952
1	386	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-386	1	-386	\N	C	2019-12-20 22:14:28.053842+00	1953
1	385	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-385	1	-385	\N	C	2019-12-20 22:14:28.053842+00	1954
1	384	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-384	1	-384	\N	C	2019-12-20 22:14:28.053842+00	1955
1	383	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-383	1	-383	\N	C	2019-12-20 22:14:28.053842+00	1956
1	382	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-382	1	-382	\N	C	2019-12-20 22:14:28.053842+00	1957
1	381	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-381	1	-381	\N	C	2019-12-20 22:14:28.053842+00	1958
1	380	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-380	1	-380	\N	C	2019-12-20 22:14:28.053842+00	1959
1	379	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-379	1	-379	\N	C	2019-12-20 22:14:28.053842+00	1960
1	378	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-378	1	-378	\N	C	2019-12-20 22:14:28.053842+00	1961
1	377	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-377	1	-377	\N	C	2019-12-20 22:14:28.053842+00	1962
1	376	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-376	1	-376	\N	C	2019-12-20 22:14:28.053842+00	1963
1	375	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-375	1	-375	\N	C	2019-12-20 22:14:28.053842+00	1964
1	374	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-374	1	-374	\N	C	2019-12-20 22:14:28.053842+00	1965
1	373	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-373	1	-373	\N	C	2019-12-20 22:14:28.053842+00	1966
1	372	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-372	1	-372	\N	C	2019-12-20 22:14:28.053842+00	1967
1	371	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-371	1	-371	\N	C	2019-12-20 22:14:28.053842+00	1968
1	370	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-370	1	-370	\N	C	2019-12-20 22:14:28.053842+00	1969
1	369	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-369	1	-369	\N	C	2019-12-20 22:14:28.053842+00	1970
1	368	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-368	1	-368	\N	C	2019-12-20 22:14:28.053842+00	1971
1	367	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-367	1	-367	\N	C	2019-12-20 22:14:28.053842+00	1972
1	366	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-366	1	-366	\N	C	2019-12-20 22:14:28.053842+00	1973
1	365	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-365	1	-365	\N	C	2019-12-20 22:14:28.053842+00	1974
1	364	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-364	1	-364	\N	C	2019-12-20 22:14:28.053842+00	1975
1	363	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-363	1	-363	\N	C	2019-12-20 22:14:28.053842+00	1976
1	362	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-362	1	-362	\N	C	2019-12-20 22:14:28.053842+00	1977
1	361	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-361	1	-361	\N	C	2019-12-20 22:14:28.053842+00	1978
1	360	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-360	1	-360	\N	C	2019-12-20 22:14:28.053842+00	1979
1	359	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-359	1	-359	\N	C	2019-12-20 22:14:28.053842+00	1980
1	358	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-358	1	-358	\N	C	2019-12-20 22:14:28.053842+00	1981
1	357	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-357	1	-357	\N	C	2019-12-20 22:14:28.053842+00	1982
1	356	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-356	1	-356	\N	C	2019-12-20 22:14:28.053842+00	1983
1	355	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-355	1	-355	\N	C	2019-12-20 22:14:28.053842+00	1984
1	354	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-354	1	-354	\N	C	2019-12-20 22:14:28.053842+00	1985
1	353	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-353	1	-353	\N	C	2019-12-20 22:14:28.053842+00	1986
1	352	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-352	1	-352	\N	C	2019-12-20 22:14:28.053842+00	1987
1	351	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-351	1	-351	\N	C	2019-12-20 22:14:28.053842+00	1988
1	350	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-350	1	-350	\N	C	2019-12-20 22:14:28.053842+00	1989
1	349	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-349	1	-349	\N	C	2019-12-20 22:14:28.053842+00	1990
1	348	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-348	1	-348	\N	C	2019-12-20 22:14:28.053842+00	1991
1	347	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-347	1	-347	\N	C	2019-12-20 22:14:28.053842+00	1992
1	346	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-346	1	-346	\N	C	2019-12-20 22:14:28.053842+00	1993
1	345	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-345	1	-345	\N	C	2019-12-20 22:14:28.053842+00	1994
1	344	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-344	1	-344	\N	C	2019-12-20 22:14:28.053842+00	1995
1	343	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-343	1	-343	\N	C	2019-12-20 22:14:28.053842+00	1996
1	342	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-342	1	-342	\N	C	2019-12-20 22:14:28.053842+00	1997
1	341	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-341	1	-341	\N	C	2019-12-20 22:14:28.053842+00	1998
1	340	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-340	1	-340	\N	C	2019-12-20 22:14:28.053842+00	1999
1	339	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-339	1	-339	\N	C	2019-12-20 22:14:28.053842+00	2000
1	338	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-338	1	-338	\N	C	2019-12-20 22:14:28.053842+00	2001
1	337	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-337	1	-337	\N	C	2019-12-20 22:14:28.053842+00	2002
1	336	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-336	1	-336	\N	C	2019-12-20 22:14:28.053842+00	2003
1	335	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-335	1	-335	\N	C	2019-12-20 22:14:28.053842+00	2004
1	334	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-334	1	-334	\N	C	2019-12-20 22:14:28.053842+00	2005
1	333	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-333	1	-333	\N	C	2019-12-20 22:14:28.053842+00	2006
1	332	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-332	1	-332	\N	C	2019-12-20 22:14:28.053842+00	2007
1	331	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-331	1	-331	\N	C	2019-12-20 22:14:28.053842+00	2008
1	330	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-330	1	-330	\N	C	2019-12-20 22:14:28.053842+00	2009
1	329	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-329	1	-329	\N	C	2019-12-20 22:14:28.053842+00	2010
1	328	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-328	1	-328	\N	C	2019-12-20 22:14:28.053842+00	2011
1	327	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-327	1	-327	\N	C	2019-12-20 22:14:28.053842+00	2012
1	326	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-326	1	-326	\N	C	2019-12-20 22:14:28.053842+00	2013
1	325	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-325	1	-325	\N	C	2019-12-20 22:14:28.053842+00	2014
1	324	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-324	1	-324	\N	C	2019-12-20 22:14:28.053842+00	2015
1	323	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-323	1	-323	\N	C	2019-12-20 22:14:28.053842+00	2016
1	322	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-322	1	-322	\N	C	2019-12-20 22:14:28.053842+00	2017
1	321	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-321	1	-321	\N	C	2019-12-20 22:14:28.053842+00	2018
1	320	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-320	1	-320	\N	C	2019-12-20 22:14:28.053842+00	2019
1	319	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-319	1	-319	\N	C	2019-12-20 22:14:28.053842+00	2020
1	318	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-318	1	-318	\N	C	2019-12-20 22:14:28.053842+00	2021
1	317	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-317	1	-317	\N	C	2019-12-20 22:14:28.053842+00	2022
1	316	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-316	1	-316	\N	C	2019-12-20 22:14:28.053842+00	2023
1	315	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-315	1	-315	\N	C	2019-12-20 22:14:28.053842+00	2024
1	314	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-314	1	-314	\N	C	2019-12-20 22:14:28.053842+00	2025
1	313	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-313	1	-313	\N	C	2019-12-20 22:14:28.053842+00	2026
1	312	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-312	1	-312	\N	C	2019-12-20 22:14:28.053842+00	2027
1	311	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-311	1	-311	\N	C	2019-12-20 22:14:28.053842+00	2028
1	310	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-310	1	-310	\N	C	2019-12-20 22:14:28.053842+00	2029
1	309	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-309	1	-309	\N	C	2019-12-20 22:14:28.053842+00	2030
1	308	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-308	1	-308	\N	C	2019-12-20 22:14:28.053842+00	2031
1	307	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-307	1	-307	\N	C	2019-12-20 22:14:28.053842+00	2032
1	306	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-306	1	-306	\N	C	2019-12-20 22:14:28.053842+00	2033
1	305	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-305	1	-305	\N	C	2019-12-20 22:14:28.053842+00	2034
1	304	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-304	1	-304	\N	C	2019-12-20 22:14:28.053842+00	2035
1	303	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-303	1	-303	\N	C	2019-12-20 22:14:28.053842+00	2036
1	302	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-302	1	-302	\N	C	2019-12-20 22:14:28.053842+00	2037
1	301	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-301	1	-301	\N	C	2019-12-20 22:14:28.053842+00	2038
1	300	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-300	1	-300	\N	C	2019-12-20 22:14:28.053842+00	2039
1	299	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-299	1	-299	\N	C	2019-12-20 22:14:28.053842+00	2040
1	298	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-298	1	-298	\N	C	2019-12-20 22:14:28.053842+00	2041
1	297	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-297	1	-297	\N	C	2019-12-20 22:14:28.053842+00	2042
1	296	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-296	1	-296	\N	C	2019-12-20 22:14:28.053842+00	2043
1	295	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-295	1	-295	\N	C	2019-12-20 22:14:28.053842+00	2044
1	294	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-294	1	-294	\N	C	2019-12-20 22:14:28.053842+00	2045
1	293	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-293	1	-293	\N	C	2019-12-20 22:14:28.053842+00	2046
1	292	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-292	1	-292	\N	C	2019-12-20 22:14:28.053842+00	2047
1	291	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-291	1	-291	\N	C	2019-12-20 22:14:28.053842+00	2048
1	290	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-290	1	-290	\N	C	2019-12-20 22:14:28.053842+00	2049
1	289	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-289	1	-289	\N	C	2019-12-20 22:14:28.053842+00	2050
1	288	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-288	1	-288	\N	C	2019-12-20 22:14:28.053842+00	2051
1	287	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-287	1	-287	\N	C	2019-12-20 22:14:28.053842+00	2052
1	286	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-286	1	-286	\N	C	2019-12-20 22:14:28.053842+00	2053
1	285	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-285	1	-285	\N	C	2019-12-20 22:14:28.053842+00	2054
1	284	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-284	1	-284	\N	C	2019-12-20 22:14:28.053842+00	2055
1	283	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-283	1	-283	\N	C	2019-12-20 22:14:28.053842+00	2056
1	282	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-282	1	-282	\N	C	2019-12-20 22:14:28.053842+00	2057
1	281	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-281	1	-281	\N	C	2019-12-20 22:14:28.053842+00	2058
1	280	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-280	1	-280	\N	C	2019-12-20 22:14:28.053842+00	2059
1	279	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-279	1	-279	\N	C	2019-12-20 22:14:28.053842+00	2060
1	278	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-278	1	-278	\N	C	2019-12-20 22:14:28.053842+00	2061
1	277	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-277	1	-277	\N	C	2019-12-20 22:14:28.053842+00	2062
1	276	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-276	1	-276	\N	C	2019-12-20 22:14:28.053842+00	2063
1	275	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-275	1	-275	\N	C	2019-12-20 22:14:28.053842+00	2064
1	274	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-274	1	-274	\N	C	2019-12-20 22:14:28.053842+00	2065
1	273	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-273	1	-273	\N	C	2019-12-20 22:14:28.053842+00	2066
1	272	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-272	1	-272	\N	C	2019-12-20 22:14:28.053842+00	2067
1	271	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-271	1	-271	\N	C	2019-12-20 22:14:28.053842+00	2068
1	270	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-270	1	-270	\N	C	2019-12-20 22:14:28.053842+00	2069
1	269	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-269	1	-269	\N	C	2019-12-20 22:14:28.053842+00	2070
1	268	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-268	1	-268	\N	C	2019-12-20 22:14:28.053842+00	2071
1	267	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-267	1	-267	\N	C	2019-12-20 22:14:28.053842+00	2072
1	266	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-266	1	-266	\N	C	2019-12-20 22:14:28.053842+00	2073
1	265	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-265	1	-265	\N	C	2019-12-20 22:14:28.053842+00	2074
1	264	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-264	1	-264	\N	C	2019-12-20 22:14:28.053842+00	2075
1	263	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-263	1	-263	\N	C	2019-12-20 22:14:28.053842+00	2076
1	262	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-262	1	-262	\N	C	2019-12-20 22:14:28.053842+00	2077
1	261	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-261	1	-261	\N	C	2019-12-20 22:14:28.053842+00	2078
1	260	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-260	1	-260	\N	C	2019-12-20 22:14:28.053842+00	2079
1	259	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-259	1	-259	\N	C	2019-12-20 22:14:28.053842+00	2080
1	258	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-258	1	-258	\N	C	2019-12-20 22:14:28.053842+00	2081
1	257	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-257	1	-257	\N	C	2019-12-20 22:14:28.053842+00	2082
1	256	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-256	1	-256	\N	C	2019-12-20 22:14:28.053842+00	2083
1	255	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-255	1	-255	\N	C	2019-12-20 22:14:28.053842+00	2084
1	254	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-254	1	-254	\N	C	2019-12-20 22:14:28.053842+00	2085
1	253	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-253	1	-253	\N	C	2019-12-20 22:14:28.053842+00	2086
1	252	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-252	1	-252	\N	C	2019-12-20 22:14:28.053842+00	2087
1	251	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-251	1	-251	\N	C	2019-12-20 22:14:28.053842+00	2088
1	250	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-250	1	-250	\N	C	2019-12-20 22:14:28.053842+00	2089
1	249	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-249	1	-249	\N	C	2019-12-20 22:14:28.053842+00	2090
1	248	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-248	1	-248	\N	C	2019-12-20 22:14:28.053842+00	2091
1	247	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-247	1	-247	\N	C	2019-12-20 22:14:28.053842+00	2092
1	246	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-246	1	-246	\N	C	2019-12-20 22:14:28.053842+00	2093
1	245	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-245	1	-245	\N	C	2019-12-20 22:14:28.053842+00	2094
1	244	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-244	1	-244	\N	C	2019-12-20 22:14:28.053842+00	2095
1	243	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-243	1	-243	\N	C	2019-12-20 22:14:28.053842+00	2096
1	242	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-242	1	-242	\N	C	2019-12-20 22:14:28.053842+00	2097
1	241	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-241	1	-241	\N	C	2019-12-20 22:14:28.053842+00	2098
1	240	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-240	1	-240	\N	C	2019-12-20 22:14:28.053842+00	2099
1	239	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-239	1	-239	\N	C	2019-12-20 22:14:28.053842+00	2100
1	238	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-238	1	-238	\N	C	2019-12-20 22:14:28.053842+00	2101
1	237	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-237	1	-237	\N	C	2019-12-20 22:14:28.053842+00	2102
1	236	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-236	1	-236	\N	C	2019-12-20 22:14:28.053842+00	2103
1	235	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-235	1	-235	\N	C	2019-12-20 22:14:28.053842+00	2104
1	234	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-234	1	-234	\N	C	2019-12-20 22:14:28.053842+00	2105
1	233	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-233	1	-233	\N	C	2019-12-20 22:14:28.053842+00	2106
1	232	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-232	1	-232	\N	C	2019-12-20 22:14:28.053842+00	2107
1	231	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-231	1	-231	\N	C	2019-12-20 22:14:28.053842+00	2108
1	230	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-230	1	-230	\N	C	2019-12-20 22:14:28.053842+00	2109
1	229	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-229	1	-229	\N	C	2019-12-20 22:14:28.053842+00	2110
1	228	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-228	1	-228	\N	C	2019-12-20 22:14:28.053842+00	2111
1	227	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-227	1	-227	\N	C	2019-12-20 22:14:28.053842+00	2112
1	226	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-226	1	-226	\N	C	2019-12-20 22:14:28.053842+00	2113
1	225	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-225	1	-225	\N	C	2019-12-20 22:14:28.053842+00	2114
1	224	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-224	1	-224	\N	C	2019-12-20 22:14:28.053842+00	2115
1	223	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-223	1	-223	\N	C	2019-12-20 22:14:28.053842+00	2116
1	222	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-222	1	-222	\N	C	2019-12-20 22:14:28.053842+00	2117
1	221	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-221	1	-221	\N	C	2019-12-20 22:14:28.053842+00	2118
1	220	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-220	1	-220	\N	C	2019-12-20 22:14:28.053842+00	2119
1	219	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-219	1	-219	\N	C	2019-12-20 22:14:28.053842+00	2120
1	218	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-218	1	-218	\N	C	2019-12-20 22:14:28.053842+00	2121
1	217	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-217	1	-217	\N	C	2019-12-20 22:14:28.053842+00	2122
1	216	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-216	1	-216	\N	C	2019-12-20 22:14:28.053842+00	2123
1	215	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-215	1	-215	\N	C	2019-12-20 22:14:28.053842+00	2124
1	214	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-214	1	-214	\N	C	2019-12-20 22:14:28.053842+00	2125
1	213	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-213	1	-213	\N	C	2019-12-20 22:14:28.053842+00	2126
1	212	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-212	1	-212	\N	C	2019-12-20 22:14:28.053842+00	2127
1	211	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-211	1	-211	\N	C	2019-12-20 22:14:28.053842+00	2128
1	210	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-210	1	-210	\N	C	2019-12-20 22:14:28.053842+00	2129
1	209	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-209	1	-209	\N	C	2019-12-20 22:14:28.053842+00	2130
1	208	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-208	1	-208	\N	C	2019-12-20 22:14:28.053842+00	2131
1	207	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-207	1	-207	\N	C	2019-12-20 22:14:28.053842+00	2132
1	206	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-206	1	-206	\N	C	2019-12-20 22:14:28.053842+00	2133
1	205	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-205	1	-205	\N	C	2019-12-20 22:14:28.053842+00	2134
1	204	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-204	1	-204	\N	C	2019-12-20 22:14:28.053842+00	2135
1	203	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-203	1	-203	\N	C	2019-12-20 22:14:28.053842+00	2136
1	202	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-202	1	-202	\N	C	2019-12-20 22:14:28.053842+00	2137
1	201	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-201	1	-201	\N	C	2019-12-20 22:14:28.053842+00	2138
1	200	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-200	1	-200	\N	C	2019-12-20 22:14:28.053842+00	2139
1	199	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-199	1	-199	\N	C	2019-12-20 22:14:28.053842+00	2140
1	198	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-198	1	-198	\N	C	2019-12-20 22:14:28.053842+00	2141
1	197	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-197	1	-197	\N	C	2019-12-20 22:14:28.053842+00	2142
1	196	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-196	1	-196	\N	C	2019-12-20 22:14:28.053842+00	2143
1	195	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-195	1	-195	\N	C	2019-12-20 22:14:28.053842+00	2144
1	194	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-194	1	-194	\N	C	2019-12-20 22:14:28.053842+00	2145
1	193	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-193	1	-193	\N	C	2019-12-20 22:14:28.053842+00	2146
1	192	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-192	1	-192	\N	C	2019-12-20 22:14:28.053842+00	2147
1	191	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-191	1	-191	\N	C	2019-12-20 22:14:28.053842+00	2148
1	190	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-190	1	-190	\N	C	2019-12-20 22:14:28.053842+00	2149
1	189	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-189	1	-189	\N	C	2019-12-20 22:14:28.053842+00	2150
1	188	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-188	1	-188	\N	C	2019-12-20 22:14:28.053842+00	2151
1	187	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-187	1	-187	\N	C	2019-12-20 22:14:28.053842+00	2152
1	186	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-186	1	-186	\N	C	2019-12-20 22:14:28.053842+00	2153
1	185	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-185	1	-185	\N	C	2019-12-20 22:14:28.053842+00	2154
1	184	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-184	1	-184	\N	C	2019-12-20 22:14:28.053842+00	2155
1	183	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-183	1	-183	\N	C	2019-12-20 22:14:28.053842+00	2156
1	182	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-182	1	-182	\N	C	2019-12-20 22:14:28.053842+00	2157
1	181	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-181	1	-181	\N	C	2019-12-20 22:14:28.053842+00	2158
1	180	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-180	1	-180	\N	C	2019-12-20 22:14:28.053842+00	2159
1	179	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-179	1	-179	\N	C	2019-12-20 22:14:28.053842+00	2160
1	178	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-178	1	-178	\N	C	2019-12-20 22:14:28.053842+00	2161
1	177	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-177	1	-177	\N	C	2019-12-20 22:14:28.053842+00	2162
1	176	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-176	1	-176	\N	C	2019-12-20 22:14:28.053842+00	2163
1	175	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-175	1	-175	\N	C	2019-12-20 22:14:28.053842+00	2164
1	174	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-174	1	-174	\N	C	2019-12-20 22:14:28.053842+00	2165
1	173	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-173	1	-173	\N	C	2019-12-20 22:14:28.053842+00	2166
1	172	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-172	1	-172	\N	C	2019-12-20 22:14:28.053842+00	2167
1	171	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-171	1	-171	\N	C	2019-12-20 22:14:28.053842+00	2168
1	170	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-170	1	-170	\N	C	2019-12-20 22:14:28.053842+00	2169
1	169	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-169	1	-169	\N	C	2019-12-20 22:14:28.053842+00	2170
1	168	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-168	1	-168	\N	C	2019-12-20 22:14:28.053842+00	2171
1	167	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-167	1	-167	\N	C	2019-12-20 22:14:28.053842+00	2172
1	166	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-166	1	-166	\N	C	2019-12-20 22:14:28.053842+00	2173
1	165	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-165	1	-165	\N	C	2019-12-20 22:14:28.053842+00	2174
1	164	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-164	1	-164	\N	C	2019-12-20 22:14:28.053842+00	2175
1	163	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-163	1	-163	\N	C	2019-12-20 22:14:28.053842+00	2176
1	162	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-162	1	-162	\N	C	2019-12-20 22:14:28.053842+00	2177
1	161	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-161	1	-161	\N	C	2019-12-20 22:14:28.053842+00	2178
1	160	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-160	1	-160	\N	C	2019-12-20 22:14:28.053842+00	2179
1	159	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-159	1	-159	\N	C	2019-12-20 22:14:28.053842+00	2180
1	158	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-158	1	-158	\N	C	2019-12-20 22:14:28.053842+00	2181
1	157	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-157	1	-157	\N	C	2019-12-20 22:14:28.053842+00	2182
1	156	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-156	1	-156	\N	C	2019-12-20 22:14:28.053842+00	2183
1	155	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-155	1	-155	\N	C	2019-12-20 22:14:28.053842+00	2184
1	154	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-154	1	-154	\N	C	2019-12-20 22:14:28.053842+00	2185
1	153	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-153	1	-153	\N	C	2019-12-20 22:14:28.053842+00	2186
1	152	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-152	1	-152	\N	C	2019-12-20 22:14:28.053842+00	2187
1	151	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-151	1	-151	\N	C	2019-12-20 22:14:28.053842+00	2188
1	150	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-150	1	-150	\N	C	2019-12-20 22:14:28.053842+00	2189
1	149	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-149	1	-149	\N	C	2019-12-20 22:14:28.053842+00	2190
1	148	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-148	1	-148	\N	C	2019-12-20 22:14:28.053842+00	2191
1	147	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-147	1	-147	\N	C	2019-12-20 22:14:28.053842+00	2192
1	146	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-146	1	-146	\N	C	2019-12-20 22:14:28.053842+00	2193
1	145	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-145	1	-145	\N	C	2019-12-20 22:14:28.053842+00	2194
1	144	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-144	1	-144	\N	C	2019-12-20 22:14:28.053842+00	2195
1	143	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-143	1	-143	\N	C	2019-12-20 22:14:28.053842+00	2196
1	142	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-142	1	-142	\N	C	2019-12-20 22:14:28.053842+00	2197
1	141	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-141	1	-141	\N	C	2019-12-20 22:14:28.053842+00	2198
1	140	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-140	1	-140	\N	C	2019-12-20 22:14:28.053842+00	2199
1	139	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-139	1	-139	\N	C	2019-12-20 22:14:28.053842+00	2200
1	138	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-138	1	-138	\N	C	2019-12-20 22:14:28.053842+00	2201
1	137	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-137	1	-137	\N	C	2019-12-20 22:14:28.053842+00	2202
1	136	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-136	1	-136	\N	C	2019-12-20 22:14:28.053842+00	2203
1	135	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-135	1	-135	\N	C	2019-12-20 22:14:28.053842+00	2204
1	134	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-134	1	-134	\N	C	2019-12-20 22:14:28.053842+00	2205
1	133	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-133	1	-133	\N	C	2019-12-20 22:14:28.053842+00	2206
1	132	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-132	1	-132	\N	C	2019-12-20 22:14:28.053842+00	2207
1	131	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-131	1	-131	\N	C	2019-12-20 22:14:28.053842+00	2208
1	130	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-130	1	-130	\N	C	2019-12-20 22:14:28.053842+00	2209
1	129	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-129	1	-129	\N	C	2019-12-20 22:14:28.053842+00	2210
1	128	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-128	1	-128	\N	C	2019-12-20 22:14:28.053842+00	2211
1	127	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-127	1	-127	\N	C	2019-12-20 22:14:28.053842+00	2212
1	126	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-126	1	-126	\N	C	2019-12-20 22:14:28.053842+00	2213
1	125	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-125	1	-125	\N	C	2019-12-20 22:14:28.053842+00	2214
1	124	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-124	1	-124	\N	C	2019-12-20 22:14:28.053842+00	2215
1	123	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-123	1	-123	\N	C	2019-12-20 22:14:28.053842+00	2216
1	122	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-122	1	-122	\N	C	2019-12-20 22:14:28.053842+00	2217
1	121	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-121	1	-121	\N	C	2019-12-20 22:14:28.053842+00	2218
1	120	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-120	1	-120	\N	C	2019-12-20 22:14:28.053842+00	2219
1	119	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-119	1	-119	\N	C	2019-12-20 22:14:28.053842+00	2220
1	118	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-118	1	-118	\N	C	2019-12-20 22:14:28.053842+00	2221
1	117	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-117	1	-117	\N	C	2019-12-20 22:14:28.053842+00	2222
1	116	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-116	1	-116	\N	C	2019-12-20 22:14:28.053842+00	2223
1	115	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-115	1	-115	\N	C	2019-12-20 22:14:28.053842+00	2224
1	114	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-114	1	-114	\N	C	2019-12-20 22:14:28.053842+00	2225
1	113	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-113	1	-113	\N	C	2019-12-20 22:14:28.053842+00	2226
1	112	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-112	1	-112	\N	C	2019-12-20 22:14:28.053842+00	2227
1	111	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-111	1	-111	\N	C	2019-12-20 22:14:28.053842+00	2228
1	110	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-110	1	-110	\N	C	2019-12-20 22:14:28.053842+00	2229
1	109	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-109	1	-109	\N	C	2019-12-20 22:14:28.053842+00	2230
1	108	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-108	1	-108	\N	C	2019-12-20 22:14:28.053842+00	2231
1	107	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-107	1	-107	\N	C	2019-12-20 22:14:28.053842+00	2232
1	106	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-106	1	-106	\N	C	2019-12-20 22:14:28.053842+00	2233
1	105	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-105	1	-105	\N	C	2019-12-20 22:14:28.053842+00	2234
1	104	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-104	1	-104	\N	C	2019-12-20 22:14:28.053842+00	2235
1	103	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-103	1	-103	\N	C	2019-12-20 22:14:28.053842+00	2236
1	102	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-102	1	-102	\N	C	2019-12-20 22:14:28.053842+00	2237
1	101	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-101	1	-101	\N	C	2019-12-20 22:14:28.053842+00	2238
1	100	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-100	1	-100	\N	C	2019-12-20 22:14:28.053842+00	2239
1	99	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-99	1	-99	\N	C	2019-12-20 22:14:28.053842+00	2240
1	98	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-98	1	-98	\N	C	2019-12-20 22:14:28.053842+00	2241
1	97	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-97	1	-97	\N	C	2019-12-20 22:14:28.053842+00	2242
1	96	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-96	1	-96	\N	C	2019-12-20 22:14:28.053842+00	2243
1	95	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-95	1	-95	\N	C	2019-12-20 22:14:28.053842+00	2244
1	94	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-94	1	-94	\N	C	2019-12-20 22:14:28.053842+00	2245
1	93	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-93	1	-93	\N	C	2019-12-20 22:14:28.053842+00	2246
1	92	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-92	1	-92	\N	C	2019-12-20 22:14:28.053842+00	2247
1	91	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-91	1	-91	\N	C	2019-12-20 22:14:28.053842+00	2248
1	90	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-90	1	-90	\N	C	2019-12-20 22:14:28.053842+00	2249
1	89	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-89	1	-89	\N	C	2019-12-20 22:14:28.053842+00	2250
1	88	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-88	1	-88	\N	C	2019-12-20 22:14:28.053842+00	2251
1	87	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-87	1	-87	\N	C	2019-12-20 22:14:28.053842+00	2252
1	86	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-86	1	-86	\N	C	2019-12-20 22:14:28.053842+00	2253
1	85	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-85	1	-85	\N	C	2019-12-20 22:14:28.053842+00	2254
1	84	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-84	1	-84	\N	C	2019-12-20 22:14:28.053842+00	2255
1	83	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-83	1	-83	\N	C	2019-12-20 22:14:28.053842+00	2256
1	82	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-82	1	-82	\N	C	2019-12-20 22:14:28.053842+00	2257
1	81	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-81	1	-81	\N	C	2019-12-20 22:14:28.053842+00	2258
1	80	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-80	1	-80	\N	C	2019-12-20 22:14:28.053842+00	2259
1	79	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-79	1	-79	\N	C	2019-12-20 22:14:28.053842+00	2260
1	78	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-78	1	-78	\N	C	2019-12-20 22:14:28.053842+00	2261
1	77	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-77	1	-77	\N	C	2019-12-20 22:14:28.053842+00	2262
1	76	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-76	1	-76	\N	C	2019-12-20 22:14:28.053842+00	2263
1	75	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-75	1	-75	\N	C	2019-12-20 22:14:28.053842+00	2264
1	74	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-74	1	-74	\N	C	2019-12-20 22:14:28.053842+00	2265
1	73	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-73	1	-73	\N	C	2019-12-20 22:14:28.053842+00	2266
1	72	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-72	1	-72	\N	C	2019-12-20 22:14:28.053842+00	2267
1	71	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-71	1	-71	\N	C	2019-12-20 22:14:28.053842+00	2268
1	70	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-70	1	-70	\N	C	2019-12-20 22:14:28.053842+00	2269
1	69	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-69	1	-69	\N	C	2019-12-20 22:14:28.053842+00	2270
1	68	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-68	1	-68	\N	C	2019-12-20 22:14:28.053842+00	2271
1	67	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-67	1	-67	\N	C	2019-12-20 22:14:28.053842+00	2272
1	66	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-66	1	-66	\N	C	2019-12-20 22:14:28.053842+00	2273
1	65	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-65	1	-65	\N	C	2019-12-20 22:14:28.053842+00	2274
1	64	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-64	1	-64	\N	C	2019-12-20 22:14:28.053842+00	2275
1	63	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-63	1	-63	\N	C	2019-12-20 22:14:28.053842+00	2276
1	62	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-62	1	-62	\N	C	2019-12-20 22:14:28.053842+00	2277
1	61	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-61	1	-61	\N	C	2019-12-20 22:14:28.053842+00	2278
1	60	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-60	1	-60	\N	C	2019-12-20 22:14:28.053842+00	2279
1	59	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-59	1	-59	\N	C	2019-12-20 22:14:28.053842+00	2280
1	58	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-58	1	-58	\N	C	2019-12-20 22:14:28.053842+00	2281
1	57	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-57	1	-57	\N	C	2019-12-20 22:14:28.053842+00	2282
1	56	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-56	1	-56	\N	C	2019-12-20 22:14:28.053842+00	2283
1	55	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-55	1	-55	\N	C	2019-12-20 22:14:28.053842+00	2284
1	54	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-54	1	-54	\N	C	2019-12-20 22:14:28.053842+00	2285
1	53	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-53	1	-53	\N	C	2019-12-20 22:14:28.053842+00	2286
1	52	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-52	1	-52	\N	C	2019-12-20 22:14:28.053842+00	2287
1	51	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-51	1	-51	\N	C	2019-12-20 22:14:28.053842+00	2288
1	50	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-50	1	-50	\N	C	2019-12-20 22:14:28.053842+00	2289
1	49	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-49	1	-49	\N	C	2019-12-20 22:14:28.053842+00	2290
1	48	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-48	1	-48	\N	C	2019-12-20 22:14:28.053842+00	2291
1	47	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-47	1	-47	\N	C	2019-12-20 22:14:28.053842+00	2292
1	46	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-46	1	-46	\N	C	2019-12-20 22:14:28.053842+00	2293
1	45	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-45	1	-45	\N	C	2019-12-20 22:14:28.053842+00	2294
1	44	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-44	1	-44	\N	C	2019-12-20 22:14:28.053842+00	2295
1	43	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-43	1	-43	\N	C	2019-12-20 22:14:28.053842+00	2296
1	42	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-42	1	-42	\N	C	2019-12-20 22:14:28.053842+00	2297
1	41	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-41	1	-41	\N	C	2019-12-20 22:14:28.053842+00	2298
1	40	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-40	1	-40	\N	C	2019-12-20 22:14:28.053842+00	2299
1	39	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-39	1	-39	\N	C	2019-12-20 22:14:28.053842+00	2300
1	38	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-38	1	-38	\N	C	2019-12-20 22:14:28.053842+00	2301
1	37	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-37	1	-37	\N	C	2019-12-20 22:14:28.053842+00	2302
1	36	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-36	1	-36	\N	C	2019-12-20 22:14:28.053842+00	2303
1	35	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-35	1	-35	\N	C	2019-12-20 22:14:28.053842+00	2304
1	34	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-34	1	-34	\N	C	2019-12-20 22:14:28.053842+00	2305
1	33	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-33	1	-33	\N	C	2019-12-20 22:14:28.053842+00	2306
1	32	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-32	1	-32	\N	C	2019-12-20 22:14:28.053842+00	2307
1	31	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-31	1	-31	\N	C	2019-12-20 22:14:28.053842+00	2308
1	30	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-30	1	-30	\N	C	2019-12-20 22:14:28.053842+00	2309
1	29	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-29	1	-29	\N	C	2019-12-20 22:14:28.053842+00	2310
1	28	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-28	1	-28	\N	C	2019-12-20 22:14:28.053842+00	2311
1	27	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-27	1	-27	\N	C	2019-12-20 22:14:28.053842+00	2312
1	26	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-26	1	-26	\N	C	2019-12-20 22:14:28.053842+00	2313
1	25	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-25	1	-25	\N	C	2019-12-20 22:14:28.053842+00	2314
1	24	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-24	1	-24	\N	C	2019-12-20 22:14:28.053842+00	2315
1	23	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-23	1	-23	\N	C	2019-12-20 22:14:28.053842+00	2316
1	22	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-22	1	-22	\N	C	2019-12-20 22:14:28.053842+00	2317
1	21	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-21	1	-21	\N	C	2019-12-20 22:14:28.053842+00	2318
1	20	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-20	1	-20	\N	C	2019-12-20 22:14:28.053842+00	2319
1	19	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-19	1	-19	\N	C	2019-12-20 22:14:28.053842+00	2320
1	18	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-18	1	-18	\N	C	2019-12-20 22:14:28.053842+00	2321
1	17	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-17	1	-17	\N	C	2019-12-20 22:14:28.053842+00	2322
1	16	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-16	1	-16	\N	C	2019-12-20 22:14:28.053842+00	2323
1	15	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-15	1	-15	\N	C	2019-12-20 22:14:28.053842+00	2324
1	14	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-14	1	-14	\N	C	2019-12-20 22:14:28.053842+00	2325
1	13	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-13	1	-13	\N	C	2019-12-20 22:14:28.053842+00	2326
1	12	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-12	1	-12	\N	C	2019-12-20 22:14:28.053842+00	2327
1	11	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-11	1	-11	\N	C	2019-12-20 22:14:28.053842+00	2328
