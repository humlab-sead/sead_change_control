1	323	2	-323	rim of initial Jomon pottery of type SIV	\N	1	-323	\N	C	2019-12-20 22:14:28.053842+00	4102
1	322	2	-322	rim of initial Jomon pottery of type SIV	\N	1	-322	\N	C	2019-12-20 22:14:28.053842+00	4103
1	321	2	-321	rim of initial Jomon pottery of type SIV	\N	1	-321	\N	C	2019-12-20 22:14:28.053842+00	4104
1	320	2	-320	rim of initial Jomon pottery of type SIV	\N	1	-320	\N	C	2019-12-20 22:14:28.053842+00	4105
1	319	2	-319	rim of initial Jomon pottery of type SIV	\N	1	-319	\N	C	2019-12-20 22:14:28.053842+00	4106
1	318	2	-318	body of initial Jomon pottery of type SIV	\N	1	-318	\N	C	2019-12-20 22:14:28.053842+00	4107
1	317	2	-317	rim of initial Jomon pottery of type SIV	\N	1	-317	\N	C	2019-12-20 22:14:28.053842+00	4108
1	316	2	-316	rim of initial Jomon pottery of type SIV	\N	1	-316	\N	C	2019-12-20 22:14:28.053842+00	4109
1	315	2	-315	rim of initial Jomon pottery of type SIV	\N	1	-315	\N	C	2019-12-20 22:14:28.053842+00	4110
1	314	2	-314	rim of initial Jomon pottery of type SIV	\N	1	-314	\N	C	2019-12-20 22:14:28.053842+00	4111
1	313	2	-313	rim of initial Jomon pottery of type SIV	\N	1	-313	\N	C	2019-12-20 22:14:28.053842+00	4112
1	312	2	-312	rim of initial Jomon pottery of type SIV	\N	1	-312	\N	C	2019-12-20 22:14:28.053842+00	4113
1	311	2	-311	rim of initial Jomon pottery of type SIV	\N	1	-311	\N	C	2019-12-20 22:14:28.053842+00	4114
1	310	2	-310	rim of initial Jomon pottery of type SIV	\N	1	-310	\N	C	2019-12-20 22:14:28.053842+00	4115
1	309	2	-309	rim of initial Jomon pottery of type SIV	\N	1	-309	\N	C	2019-12-20 22:14:28.053842+00	4116
1	308	2	-308	body of initial Jomon pottery of type SIV	\N	1	-308	\N	C	2019-12-20 22:14:28.053842+00	4117
1	307	2	-307	body of initial Jomon pottery of type SIV	\N	1	-307	\N	C	2019-12-20 22:14:28.053842+00	4118
1	944	2	-944	unknown part of initial Jomon pottery of type SIV	\N	1	-944	\N	C	2019-12-20 22:14:28.053842+00	3481
1	943	2	-943	unknown part of initial Jomon pottery of type SIV	\N	1	-943	\N	C	2019-12-20 22:14:28.053842+00	3482
1	942	2	-942	unknown part of initial Jomon pottery of type SIV	\N	1	-942	\N	C	2019-12-20 22:14:28.053842+00	3483
1	941	2	-941	unknown part of initial Jomon pottery of type SIV	\N	1	-941	\N	C	2019-12-20 22:14:28.053842+00	3484
1	940	2	-940	unknown part of initial Jomon pottery of type SIV	\N	1	-940	\N	C	2019-12-20 22:14:28.053842+00	3485
1	939	2	-939	unknown part of initial Jomon pottery of type SIV	\N	1	-939	\N	C	2019-12-20 22:14:28.053842+00	3486
1	938	2	-938	body of initial Jomon pottery of type SIV	\N	1	-938	\N	C	2019-12-20 22:14:28.053842+00	3487
1	937	2	-937	body of initial Jomon pottery of type SIV	\N	1	-937	\N	C	2019-12-20 22:14:28.053842+00	3488
1	936	2	-936	body of initial Jomon pottery of type SIV	\N	1	-936	\N	C	2019-12-20 22:14:28.053842+00	3489
1	935	2	-935	body of initial Jomon pottery of type SIV	\N	1	-935	\N	C	2019-12-20 22:14:28.053842+00	3490
1	934	2	-934	unknown part of initial Jomon pottery of type SIV	\N	1	-934	\N	C	2019-12-20 22:14:28.053842+00	3491
1	933	2	-933	body of initial Jomon pottery of type SIV	\N	1	-933	\N	C	2019-12-20 22:14:28.053842+00	3492
1	932	2	-932	body of initial Jomon pottery of type SIV	\N	1	-932	\N	C	2019-12-20 22:14:28.053842+00	3493
1	931	2	-931	unknown part of initial Jomon pottery of type SIV	\N	1	-931	\N	C	2019-12-20 22:14:28.053842+00	3494
1	930	2	-930	rim of initial Jomon pottery of type SIV	\N	1	-930	\N	C	2019-12-20 22:14:28.053842+00	3495
1	929	2	-929	rim of initial Jomon pottery of type SIV	\N	1	-929	\N	C	2019-12-20 22:14:28.053842+00	3496
1	928	2	-928	rim of initial Jomon pottery of type SIV	\N	1	-928	\N	C	2019-12-20 22:14:28.053842+00	3497
1	927	2	-927	body of initial Jomon pottery of type SIV	\N	1	-927	\N	C	2019-12-20 22:14:28.053842+00	3498
1	926	2	-926	body of initial Jomon pottery of type SIV	\N	1	-926	\N	C	2019-12-20 22:14:28.053842+00	3499
1	925	2	-925	rim of initial Jomon pottery of type SIV	\N	1	-925	\N	C	2019-12-20 22:14:28.053842+00	3500
1	924	2	-924	rim of initial Jomon pottery of type SIV	\N	1	-924	\N	C	2019-12-20 22:14:28.053842+00	3501
1	923	2	-923	rim of initial Jomon pottery of type SIV	\N	1	-923	\N	C	2019-12-20 22:14:28.053842+00	3502
1	922	2	-922	body of initial Jomon pottery of type SIV	\N	1	-922	\N	C	2019-12-20 22:14:28.053842+00	3503
1	921	2	-921	body of initial Jomon pottery of type SIV	\N	1	-921	\N	C	2019-12-20 22:14:28.053842+00	3504
1	920	2	-920	body of initial Jomon pottery of type SIV	\N	1	-920	\N	C	2019-12-20 22:14:28.053842+00	3505
1	919	2	-919	body of initial Jomon pottery of type SIV	\N	1	-919	\N	C	2019-12-20 22:14:28.053842+00	3506
1	918	2	-918	body of initial Jomon pottery of type SIV	\N	1	-918	\N	C	2019-12-20 22:14:28.053842+00	3507
1	917	2	-917	body of initial Jomon pottery of type SIV	\N	1	-917	\N	C	2019-12-20 22:14:28.053842+00	3508
1	916	2	-916	body of initial Jomon pottery of type SIV	\N	1	-916	\N	C	2019-12-20 22:14:28.053842+00	3509
1	915	2	-915	body of initial Jomon pottery of type SIV	\N	1	-915	\N	C	2019-12-20 22:14:28.053842+00	3510
1	914	2	-914	body of initial Jomon pottery of type SIV	\N	1	-914	\N	C	2019-12-20 22:14:28.053842+00	3511
1	913	2	-913	rim of initial Jomon pottery of type SIV	\N	1	-913	\N	C	2019-12-20 22:14:28.053842+00	3512
1	912	2	-912	body of initial Jomon pottery of type SIV	\N	1	-912	\N	C	2019-12-20 22:14:28.053842+00	3513
1	911	2	-911	body of initial Jomon pottery of type SIV	\N	1	-911	\N	C	2019-12-20 22:14:28.053842+00	3514
1	910	2	-910	body of initial Jomon pottery of type SIV	\N	1	-910	\N	C	2019-12-20 22:14:28.053842+00	3515
1	909	2	-909	body of initial Jomon pottery of type SIV	\N	1	-909	\N	C	2019-12-20 22:14:28.053842+00	3516
1	908	2	-908	body of initial Jomon pottery of type SIV	\N	1	-908	\N	C	2019-12-20 22:14:28.053842+00	3517
1	907	2	-907	body of initial Jomon pottery of type SIV	\N	1	-907	\N	C	2019-12-20 22:14:28.053842+00	3518
1	906	2	-906	body of initial Jomon pottery of type SIV	\N	1	-906	\N	C	2019-12-20 22:14:28.053842+00	3519
1	905	2	-905	body of initial Jomon pottery of type SIV	\N	1	-905	\N	C	2019-12-20 22:14:28.053842+00	3520
1	904	2	-904	body of initial Jomon pottery of type SIV	\N	1	-904	\N	C	2019-12-20 22:14:28.053842+00	3521
1	903	2	-903	body of initial Jomon pottery of type SIV	\N	1	-903	\N	C	2019-12-20 22:14:28.053842+00	3522
1	902	2	-902	body of initial Jomon pottery of type SIV	\N	1	-902	\N	C	2019-12-20 22:14:28.053842+00	3523
1	901	2	-901	unknown part of initial Jomon pottery of type SIV	\N	1	-901	\N	C	2019-12-20 22:14:28.053842+00	3524
1	900	2	-900	unknown part of initial Jomon pottery of type SIV	\N	1	-900	\N	C	2019-12-20 22:14:28.053842+00	3525
1	899	2	-899	unknown part of incipient Jomon pottery of type SIII	\N	1	-899	\N	C	2019-12-20 22:14:28.053842+00	3526
1	898	2	-898	unknown part of incipient Jomon pottery of type SIII	\N	1	-898	\N	C	2019-12-20 22:14:28.053842+00	3527
1	897	2	-897	body of initial Jomon pottery of type SIV	\N	1	-897	\N	C	2019-12-20 22:14:28.053842+00	3528
1	896	2	-896	body of initial Jomon pottery of type SIV	\N	1	-896	\N	C	2019-12-20 22:14:28.053842+00	3529
1	895	2	-895	body of initial Jomon pottery of type SIV	\N	1	-895	\N	C	2019-12-20 22:14:28.053842+00	3530
1	894	2	-894	body of initial Jomon pottery of type SIV	\N	1	-894	\N	C	2019-12-20 22:14:28.053842+00	3531
1	893	2	-893	body of initial Jomon pottery of type SIV	\N	1	-893	\N	C	2019-12-20 22:14:28.053842+00	3532
1	892	2	-892	body of initial Jomon pottery of type SIV	\N	1	-892	\N	C	2019-12-20 22:14:28.053842+00	3533
1	891	2	-891	body of initial Jomon pottery of type SIV	\N	1	-891	\N	C	2019-12-20 22:14:28.053842+00	3534
1	890	2	-890	body of initial Jomon pottery of type SIV	\N	1	-890	\N	C	2019-12-20 22:14:28.053842+00	3535
1	889	2	-889	rim-upper body of initial Jomon pottery of type SIV	\N	1	-889	\N	C	2019-12-20 22:14:28.053842+00	3536
1	888	2	-888	rim of initial Jomon pottery of type SIV	\N	1	-888	\N	C	2019-12-20 22:14:28.053842+00	3537
1	887	2	-887	base of initial Jomon pottery of type SIV	\N	1	-887	\N	C	2019-12-20 22:14:28.053842+00	3538
1	886	2	-886	body of initial Jomon pottery of type SIV	\N	1	-886	\N	C	2019-12-20 22:14:28.053842+00	3539
1	885	2	-885	rim of initial Jomon pottery of type SIV	\N	1	-885	\N	C	2019-12-20 22:14:28.053842+00	3540
1	884	2	-884	rim-upper body of initial Jomon pottery of type SIV	\N	1	-884	\N	C	2019-12-20 22:14:28.053842+00	3541
1	883	2	-883	base of initial Jomon pottery of type SIV	\N	1	-883	\N	C	2019-12-20 22:14:28.053842+00	3542
1	882	2	-882	rim of initial Jomon pottery of type SIV	\N	1	-882	\N	C	2019-12-20 22:14:28.053842+00	3543
1	881	2	-881	rim of initial Jomon pottery of type SIV	\N	1	-881	\N	C	2019-12-20 22:14:28.053842+00	3544
1	880	2	-880	body of initial Jomon pottery of type SIV	\N	1	-880	\N	C	2019-12-20 22:14:28.053842+00	3545
1	879	2	-879	base of initial Jomon pottery of type SIV	\N	1	-879	\N	C	2019-12-20 22:14:28.053842+00	3546
1	878	2	-878	body of initial Jomon pottery of type SIV	\N	1	-878	\N	C	2019-12-20 22:14:28.053842+00	3547
1	877	2	-877	body of initial Jomon pottery of type SIV	\N	1	-877	\N	C	2019-12-20 22:14:28.053842+00	3548
1	876	2	-876	rim of initial Jomon pottery of type SIV	\N	1	-876	\N	C	2019-12-20 22:14:28.053842+00	3549
1	875	2	-875	body of initial Jomon pottery of type SIV	\N	1	-875	\N	C	2019-12-20 22:14:28.053842+00	3550
1	874	2	-874	rim of initial Jomon pottery of type SIV	\N	1	-874	\N	C	2019-12-20 22:14:28.053842+00	3551
1	873	2	-873	body of initial Jomon pottery of type SIV	\N	1	-873	\N	C	2019-12-20 22:14:28.053842+00	3552
1	872	2	-872	body of initial Jomon pottery of type SIV	\N	1	-872	\N	C	2019-12-20 22:14:28.053842+00	3553
1	871	2	-871	body of initial Jomon pottery of type SIV	\N	1	-871	\N	C	2019-12-20 22:14:28.053842+00	3554
1	870	2	-870	body of initial Jomon pottery of type SIV	\N	1	-870	\N	C	2019-12-20 22:14:28.053842+00	3555
1	869	2	-869	body of initial Jomon pottery of type SIV	\N	1	-869	\N	C	2019-12-20 22:14:28.053842+00	3556
1	868	2	-868	body of initial Jomon pottery of type SIV	\N	1	-868	\N	C	2019-12-20 22:14:28.053842+00	3557
1	867	2	-867	body of initial Jomon pottery of type SIV	\N	1	-867	\N	C	2019-12-20 22:14:28.053842+00	3558
1	866	2	-866	body of initial Jomon pottery of type SIV	\N	1	-866	\N	C	2019-12-20 22:14:28.053842+00	3559
1	865	2	-865	body of initial Jomon pottery of type SIV	\N	1	-865	\N	C	2019-12-20 22:14:28.053842+00	3560
1	864	2	-864	body of initial Jomon pottery of type SIV	\N	1	-864	\N	C	2019-12-20 22:14:28.053842+00	3561
1	863	2	-863	body of initial Jomon pottery of type SIV	\N	1	-863	\N	C	2019-12-20 22:14:28.053842+00	3562
1	862	2	-862	unknown part of incipient Jomon pottery of type SII	\N	1	-862	\N	C	2019-12-20 22:14:28.053842+00	3563
1	861	2	-861	body of early Jomon pottery of type ZI-ZVI	\N	1	-861	\N	C	2019-12-20 22:14:28.053842+00	3564
1	860	2	-860	body of early Jomon pottery of type ZI-ZVI	\N	1	-860	\N	C	2019-12-20 22:14:28.053842+00	3565
1	859	2	-859	body of early Jomon pottery of type ZV	\N	1	-859	\N	C	2019-12-20 22:14:28.053842+00	3566
1	858	2	-858	body of early Jomon pottery of type ZV	\N	1	-858	\N	C	2019-12-20 22:14:28.053842+00	3567
1	857	2	-857	body of early Jomon pottery of type ZV	\N	1	-857	\N	C	2019-12-20 22:14:28.053842+00	3568
1	856	2	-856	body of early Jomon pottery of type ZV	\N	1	-856	\N	C	2019-12-20 22:14:28.053842+00	3569
1	855	2	-855	body of early Jomon pottery of type ZV	\N	1	-855	\N	C	2019-12-20 22:14:28.053842+00	3570
1	854	2	-854	body of early Jomon pottery of type ZIV	\N	1	-854	\N	C	2019-12-20 22:14:28.053842+00	3571
1	853	2	-853	body of early Jomon pottery of type ZIV	\N	1	-853	\N	C	2019-12-20 22:14:28.053842+00	3572
1	852	2	-852	body of early Jomon pottery of type ZIV	\N	1	-852	\N	C	2019-12-20 22:14:28.053842+00	3573
1	851	2	-851	body of early Jomon pottery of type ZIV	\N	1	-851	\N	C	2019-12-20 22:14:28.053842+00	3574
1	850	2	-850	body of early Jomon pottery of type ZIV	\N	1	-850	\N	C	2019-12-20 22:14:28.053842+00	3575
1	849	2	-849	body of early Jomon pottery of type ZIV	\N	1	-849	\N	C	2019-12-20 22:14:28.053842+00	3576
1	848	2	-848	body of early Jomon pottery of type ZIV	\N	1	-848	\N	C	2019-12-20 22:14:28.053842+00	3577
1	847	2	-847	body of early Jomon pottery of type ZIV	\N	1	-847	\N	C	2019-12-20 22:14:28.053842+00	3578
1	846	2	-846	body of early Jomon pottery of type ZIII	\N	1	-846	\N	C	2019-12-20 22:14:28.053842+00	3579
1	845	2	-845	body of early Jomon pottery of type ZIII	\N	1	-845	\N	C	2019-12-20 22:14:28.053842+00	3580
1	844	2	-844	body of early Jomon pottery of type ZIII	\N	1	-844	\N	C	2019-12-20 22:14:28.053842+00	3581
1	843	2	-843	rim of early Jomon pottery of type ZIII	\N	1	-843	\N	C	2019-12-20 22:14:28.053842+00	3582
1	842	2	-842	body of early Jomon pottery of type ZIII	\N	1	-842	\N	C	2019-12-20 22:14:28.053842+00	3583
1	841	2	-841	body of early Jomon pottery of type ZIII	\N	1	-841	\N	C	2019-12-20 22:14:28.053842+00	3584
1	840	2	-840	body of early Jomon pottery of type ZIII	\N	1	-840	\N	C	2019-12-20 22:14:28.053842+00	3585
1	839	2	-839	body of early Jomon pottery of type ZIII	\N	1	-839	\N	C	2019-12-20 22:14:28.053842+00	3586
1	838	2	-838	body of early Jomon pottery of type ZIII	\N	1	-838	\N	C	2019-12-20 22:14:28.053842+00	3587
1	837	2	-837	body of early Jomon pottery of type ZIII	\N	1	-837	\N	C	2019-12-20 22:14:28.053842+00	3588
1	836	2	-836	body of early Jomon pottery of type ZII	\N	1	-836	\N	C	2019-12-20 22:14:28.053842+00	3589
1	835	2	-835	body of early Jomon pottery of type ZII	\N	1	-835	\N	C	2019-12-20 22:14:28.053842+00	3590
1	834	2	-834	body of early Jomon pottery of type ZII	\N	1	-834	\N	C	2019-12-20 22:14:28.053842+00	3591
1	833	2	-833	body of early Jomon pottery of type ZII	\N	1	-833	\N	C	2019-12-20 22:14:28.053842+00	3592
1	832	2	-832	rim of early Jomon pottery of type ZII	\N	1	-832	\N	C	2019-12-20 22:14:28.053842+00	3593
1	831	2	-831	body of early Jomon pottery of type ZII	\N	1	-831	\N	C	2019-12-20 22:14:28.053842+00	3594
1	830	2	-830	body of early Jomon pottery of type ZII	\N	1	-830	\N	C	2019-12-20 22:14:28.053842+00	3595
1	829	2	-829	body of early Jomon pottery of type ZII	\N	1	-829	\N	C	2019-12-20 22:14:28.053842+00	3596
1	828	2	-828	body of early Jomon pottery of type ZII	\N	1	-828	\N	C	2019-12-20 22:14:28.053842+00	3597
1	827	2	-827	body of early Jomon pottery of type ZII	\N	1	-827	\N	C	2019-12-20 22:14:28.053842+00	3598
1	826	2	-826	rim of early Jomon pottery of type ZII	\N	1	-826	\N	C	2019-12-20 22:14:28.053842+00	3599
1	825	2	-825	rim of early Jomon pottery of type ZII	\N	1	-825	\N	C	2019-12-20 22:14:28.053842+00	3600
1	824	2	-824	body of early Jomon pottery of type ZII	\N	1	-824	\N	C	2019-12-20 22:14:28.053842+00	3601
1	823	2	-823	body of early Jomon pottery of type ZII	\N	1	-823	\N	C	2019-12-20 22:14:28.053842+00	3602
1	822	2	-822	rim of early Jomon pottery of type ZII	\N	1	-822	\N	C	2019-12-20 22:14:28.053842+00	3603
1	821	2	-821	body of early Jomon pottery of type ZII	\N	1	-821	\N	C	2019-12-20 22:14:28.053842+00	3604
1	820	2	-820	body of early Jomon pottery of type ZII	\N	1	-820	\N	C	2019-12-20 22:14:28.053842+00	3605
1	819	2	-819	body of early Jomon pottery of type ZII	\N	1	-819	\N	C	2019-12-20 22:14:28.053842+00	3606
1	818	2	-818	body of early Jomon pottery of type ZII	\N	1	-818	\N	C	2019-12-20 22:14:28.053842+00	3607
1	817	2	-817	rim of early Jomon pottery of type ZII	\N	1	-817	\N	C	2019-12-20 22:14:28.053842+00	3608
1	816	2	-816	body of early Jomon pottery of type ZII	\N	1	-816	\N	C	2019-12-20 22:14:28.053842+00	3609
1	815	2	-815	body of early Jomon pottery of type ZII	\N	1	-815	\N	C	2019-12-20 22:14:28.053842+00	3610
1	814	2	-814	body of early Jomon pottery of type ZII	\N	1	-814	\N	C	2019-12-20 22:14:28.053842+00	3611
1	813	2	-813	body of early Jomon pottery of type ZII	\N	1	-813	\N	C	2019-12-20 22:14:28.053842+00	3612
1	812	2	-812	unknown part of early Jomon pottery of type ZI - ZVI	\N	1	-812	\N	C	2019-12-20 22:14:28.053842+00	3613
1	811	2	-811	unknown part of early Jomon pottery of type ZI - ZVI	\N	1	-811	\N	C	2019-12-20 22:14:28.053842+00	3614
1	810	2	-810	unknown part of early Jomon pottery of type ZI - ZVI	\N	1	-810	\N	C	2019-12-20 22:14:28.053842+00	3615
1	809	2	-809	unknown part of early Jomon pottery of type ZI - ZVI	\N	1	-809	\N	C	2019-12-20 22:14:28.053842+00	3616
1	808	2	-808	unknown part of early Jomon pottery of type ZI - ZVI	\N	1	-808	\N	C	2019-12-20 22:14:28.053842+00	3617
1	807	2	-807	unknown part of early Jomon pottery of type ZI - ZVI	\N	1	-807	\N	C	2019-12-20 22:14:28.053842+00	3618
1	806	2	-806	unknown part of early Jomon pottery of type ZI - ZVI	\N	1	-806	\N	C	2019-12-20 22:14:28.053842+00	3619
1	805	2	-805	unknown part of early Jomon pottery of type ZI - ZVI	\N	1	-805	\N	C	2019-12-20 22:14:28.053842+00	3620
1	804	2	-804	unknown part of early Jomon pottery of type ZI - ZVI	\N	1	-804	\N	C	2019-12-20 22:14:28.053842+00	3621
1	803	2	-803	unknown part of early Jomon pottery of type ZI - ZVI	\N	1	-803	\N	C	2019-12-20 22:14:28.053842+00	3622
1	802	2	-802	unknown part of early Jomon pottery of type ZI - ZVI	\N	1	-802	\N	C	2019-12-20 22:14:28.053842+00	3623
1	801	2	-801	unknown part of early Jomon pottery of type ZI - ZVI	\N	1	-801	\N	C	2019-12-20 22:14:28.053842+00	3624
1	800	2	-800	unknown part of early Jomon pottery of type ZI - ZVI	\N	1	-800	\N	C	2019-12-20 22:14:28.053842+00	3625
1	799	2	-799	unknown part of early Jomon pottery of type ZI - ZVI	\N	1	-799	\N	C	2019-12-20 22:14:28.053842+00	3626
1	798	2	-798	unknown part of early Jomon pottery of type ZI - ZVI	\N	1	-798	\N	C	2019-12-20 22:14:28.053842+00	3627
1	797	2	-797	unknown part of early Jomon pottery of type ZI - ZVI	\N	1	-797	\N	C	2019-12-20 22:14:28.053842+00	3628
1	796	2	-796	unknown part of early Jomon pottery of type ZI - ZVI	\N	1	-796	\N	C	2019-12-20 22:14:28.053842+00	3629
1	795	2	-795	unknown part of early Jomon pottery of type ZI - ZVI	\N	1	-795	\N	C	2019-12-20 22:14:28.053842+00	3630
1	794	2	-794	unknown part of early Jomon pottery of type ZI - ZVI	\N	1	-794	\N	C	2019-12-20 22:14:28.053842+00	3631
1	793	2	-793	unknown part of early Jomon pottery of type ZI - ZVI	\N	1	-793	\N	C	2019-12-20 22:14:28.053842+00	3632
1	792	2	-792	unknown part of early Jomon pottery of type ZI - ZVI	\N	1	-792	\N	C	2019-12-20 22:14:28.053842+00	3633
1	791	2	-791	body of early Jomon pottery of type ZI	\N	1	-791	\N	C	2019-12-20 22:14:28.053842+00	3634
1	790	2	-790	body of early Jomon pottery of type ZI	\N	1	-790	\N	C	2019-12-20 22:14:28.053842+00	3635
1	789	2	-789	body of early Jomon pottery of type ZI	\N	1	-789	\N	C	2019-12-20 22:14:28.053842+00	3636
1	788	2	-788	body of early Jomon pottery of type ZI	\N	1	-788	\N	C	2019-12-20 22:14:28.053842+00	3637
1	787	2	-787	body of early Jomon pottery of type ZI	\N	1	-787	\N	C	2019-12-20 22:14:28.053842+00	3638
1	786	2	-786	body of early Jomon pottery of type ZI	\N	1	-786	\N	C	2019-12-20 22:14:28.053842+00	3639
1	785	2	-785	body of early Jomon pottery of type ZI	\N	1	-785	\N	C	2019-12-20 22:14:28.053842+00	3640
1	784	2	-784	body of early Jomon pottery of type ZI	\N	1	-784	\N	C	2019-12-20 22:14:28.053842+00	3641
1	783	2	-783	body of early Jomon pottery of type ZI	\N	1	-783	\N	C	2019-12-20 22:14:28.053842+00	3642
1	782	2	-782	body of early Jomon pottery of type ZI	\N	1	-782	\N	C	2019-12-20 22:14:28.053842+00	3643
1	781	2	-781	body of initial Jomon pottery of type SIV - SV	\N	1	-781	\N	C	2019-12-20 22:14:28.053842+00	3644
1	780	2	-780	rim of initial Jomon pottery of type SIV - SV	\N	1	-780	\N	C	2019-12-20 22:14:28.053842+00	3645
1	779	2	-779	unknown part of initial Jomon pottery of type SIV	\N	1	-779	\N	C	2019-12-20 22:14:28.053842+00	3646
1	778	2	-778	unknown part of initial Jomon pottery of type SIV	\N	1	-778	\N	C	2019-12-20 22:14:28.053842+00	3647
1	777	2	-777	unknown part of initial Jomon pottery of type SIV	\N	1	-777	\N	C	2019-12-20 22:14:28.053842+00	3648
1	776	2	-776	body of initial Jomon pottery of type SIV	\N	1	-776	\N	C	2019-12-20 22:14:28.053842+00	3649
1	775	2	-775	body of initial Jomon pottery of type SIV	\N	1	-775	\N	C	2019-12-20 22:14:28.053842+00	3650
1	774	2	-774	body of initial Jomon pottery of type SIV	\N	1	-774	\N	C	2019-12-20 22:14:28.053842+00	3651
1	773	2	-773	body of initial Jomon pottery of type SIV	\N	1	-773	\N	C	2019-12-20 22:14:28.053842+00	3652
1	772	2	-772	body of initial Jomon pottery of type SIV	\N	1	-772	\N	C	2019-12-20 22:14:28.053842+00	3653
1	771	2	-771	body of initial Jomon pottery of type SIV	\N	1	-771	\N	C	2019-12-20 22:14:28.053842+00	3654
1	770	2	-770	body of initial Jomon pottery of type SIV	\N	1	-770	\N	C	2019-12-20 22:14:28.053842+00	3655
1	769	2	-769	body of initial Jomon pottery of type SIV	\N	1	-769	\N	C	2019-12-20 22:14:28.053842+00	3656
1	768	2	-768	body of initial Jomon pottery of type SIII - ZI	\N	1	-768	\N	C	2019-12-20 22:14:28.053842+00	3657
1	767	2	-767	rim of initial Jomon pottery of type SIII - ZI	\N	1	-767	\N	C	2019-12-20 22:14:28.053842+00	3658
1	766	2	-766	unknown part of incipient Jomon pottery of type SIII	\N	1	-766	\N	C	2019-12-20 22:14:28.053842+00	3659
1	765	2	-765	unknown part of incipient Jomon pottery of type SIII	\N	1	-765	\N	C	2019-12-20 22:14:28.053842+00	3660
1	764	2	-764	unknown part of incipient Jomon pottery of type SIII	\N	1	-764	\N	C	2019-12-20 22:14:28.053842+00	3661
1	763	2	-763	body of incipient Jomon pottery of type SIII	\N	1	-763	\N	C	2019-12-20 22:14:28.053842+00	3662
1	762	2	-762	body of incipient Jomon pottery of type SIII	\N	1	-762	\N	C	2019-12-20 22:14:28.053842+00	3663
1	761	2	-761	rim of incipient Jomon pottery of type SIII	\N	1	-761	\N	C	2019-12-20 22:14:28.053842+00	3664
1	760	2	-760	rim of incipient Jomon pottery of type SIII	\N	1	-760	\N	C	2019-12-20 22:14:28.053842+00	3665
1	759	2	-759	rim of incipient Jomon pottery of type SIII	\N	1	-759	\N	C	2019-12-20 22:14:28.053842+00	3666
1	758	2	-758	rim of incipient Jomon pottery of type SIII	\N	1	-758	\N	C	2019-12-20 22:14:28.053842+00	3667
1	757	2	-757	rim of incipient Jomon pottery of type SIII	\N	1	-757	\N	C	2019-12-20 22:14:28.053842+00	3668
1	756	2	-756	rim of incipient Jomon pottery of type SIII	\N	1	-756	\N	C	2019-12-20 22:14:28.053842+00	3669
1	755	2	-755	rim of incipient Jomon pottery of type SIII	\N	1	-755	\N	C	2019-12-20 22:14:28.053842+00	3670
1	754	2	-754	rim of incipient Jomon pottery of type SIII	\N	1	-754	\N	C	2019-12-20 22:14:28.053842+00	3671
1	753	2	-753	unknown part of incipient Jomon pottery of type SIII	\N	1	-753	\N	C	2019-12-20 22:14:28.053842+00	3672
1	752	2	-752	rim of incipient Jomon pottery of type SIII	\N	1	-752	\N	C	2019-12-20 22:14:28.053842+00	3673
1	751	2	-751	body of incipient Jomon pottery of type SIII	\N	1	-751	\N	C	2019-12-20 22:14:28.053842+00	3674
1	750	2	-750	body of incipient Jomon pottery of type SIII	\N	1	-750	\N	C	2019-12-20 22:14:28.053842+00	3675
1	749	2	-749	body of incipient Jomon pottery of type SIII	\N	1	-749	\N	C	2019-12-20 22:14:28.053842+00	3676
1	748	2	-748	rim of incipient Jomon pottery of type SIII	\N	1	-748	\N	C	2019-12-20 22:14:28.053842+00	3677
1	747	2	-747	body of incipient Jomon pottery of type SIII	\N	1	-747	\N	C	2019-12-20 22:14:28.053842+00	3678
1	746	2	-746	rim of incipient Jomon pottery of type SIII	\N	1	-746	\N	C	2019-12-20 22:14:28.053842+00	3679
1	745	2	-745	body of incipient Jomon pottery of type SIII	\N	1	-745	\N	C	2019-12-20 22:14:28.053842+00	3680
1	744	2	-744	body of incipient Jomon pottery of type SIII	\N	1	-744	\N	C	2019-12-20 22:14:28.053842+00	3681
1	743	2	-743	body of incipient Jomon pottery of type SIII	\N	1	-743	\N	C	2019-12-20 22:14:28.053842+00	3682
1	742	2	-742	body of incipient Jomon pottery of type SIII	\N	1	-742	\N	C	2019-12-20 22:14:28.053842+00	3683
1	741	2	-741	body of incipient Jomon pottery of type SIII	\N	1	-741	\N	C	2019-12-20 22:14:28.053842+00	3684
1	740	2	-740	body of incipient Jomon pottery of type SIII	\N	1	-740	\N	C	2019-12-20 22:14:28.053842+00	3685
1	739	2	-739	body of incipient Jomon pottery of type SIII	\N	1	-739	\N	C	2019-12-20 22:14:28.053842+00	3686
1	738	2	-738	rim of incipient Jomon pottery of type SIII	\N	1	-738	\N	C	2019-12-20 22:14:28.053842+00	3687
1	737	2	-737	rim of incipient Jomon pottery of type SIII	\N	1	-737	\N	C	2019-12-20 22:14:28.053842+00	3688
1	736	2	-736	body of incipient Jomon pottery of type SIII	\N	1	-736	\N	C	2019-12-20 22:14:28.053842+00	3689
1	735	2	-735	body of incipient Jomon pottery of type SIII	\N	1	-735	\N	C	2019-12-20 22:14:28.053842+00	3690
1	734	2	-734	body of incipient Jomon pottery of type SIII	\N	1	-734	\N	C	2019-12-20 22:14:28.053842+00	3691
1	733	2	-733	rim of incipient Jomon pottery of type SIII	\N	1	-733	\N	C	2019-12-20 22:14:28.053842+00	3692
1	732	2	-732	rim of incipient Jomon pottery of type SIII	\N	1	-732	\N	C	2019-12-20 22:14:28.053842+00	3693
1	731	2	-731	rim of incipient Jomon pottery of type SIII	\N	1	-731	\N	C	2019-12-20 22:14:28.053842+00	3694
1	730	2	-730	body of incipient Jomon pottery of type SIII	\N	1	-730	\N	C	2019-12-20 22:14:28.053842+00	3695
1	729	2	-729	body of incipient Jomon pottery of type SIII	\N	1	-729	\N	C	2019-12-20 22:14:28.053842+00	3696
1	728	2	-728	body of incipient Jomon pottery of type SIII	\N	1	-728	\N	C	2019-12-20 22:14:28.053842+00	3697
1	727	2	-727	body of incipient Jomon pottery of type SIII	\N	1	-727	\N	C	2019-12-20 22:14:28.053842+00	3698
1	726	2	-726	body of incipient Jomon pottery of type SIII	\N	1	-726	\N	C	2019-12-20 22:14:28.053842+00	3699
1	725	2	-725	body of incipient Jomon pottery of type SIII	\N	1	-725	\N	C	2019-12-20 22:14:28.053842+00	3700
1	724	2	-724	body of incipient Jomon pottery of type SIII	\N	1	-724	\N	C	2019-12-20 22:14:28.053842+00	3701
1	723	2	-723	body of incipient Jomon pottery of type SIII	\N	1	-723	\N	C	2019-12-20 22:14:28.053842+00	3702
1	722	2	-722	body of incipient Jomon pottery of type SIII	\N	1	-722	\N	C	2019-12-20 22:14:28.053842+00	3703
1	721	2	-721	body of incipient Jomon pottery of type SIII	\N	1	-721	\N	C	2019-12-20 22:14:28.053842+00	3704
1	720	2	-720	rim of incipient Jomon pottery of type SIII	\N	1	-720	\N	C	2019-12-20 22:14:28.053842+00	3705
1	719	2	-719	body of incipient Jomon pottery of type SIII	\N	1	-719	\N	C	2019-12-20 22:14:28.053842+00	3706
1	718	2	-718	body of incipient Jomon pottery of type SIII	\N	1	-718	\N	C	2019-12-20 22:14:28.053842+00	3707
1	717	2	-717	body of incipient Jomon pottery of type SIII	\N	1	-717	\N	C	2019-12-20 22:14:28.053842+00	3708
1	716	2	-716	body of incipient Jomon pottery of type SIII	\N	1	-716	\N	C	2019-12-20 22:14:28.053842+00	3709
1	715	2	-715	rim of incipient Jomon pottery of type SIII	\N	1	-715	\N	C	2019-12-20 22:14:28.053842+00	3710
1	714	2	-714	rim of incipient Jomon pottery of type SIII	\N	1	-714	\N	C	2019-12-20 22:14:28.053842+00	3711
1	713	2	-713	body of incipient Jomon pottery of type SIII	\N	1	-713	\N	C	2019-12-20 22:14:28.053842+00	3712
1	712	2	-712	body of incipient Jomon pottery of type SIII	\N	1	-712	\N	C	2019-12-20 22:14:28.053842+00	3713
1	711	2	-711	body of incipient Jomon pottery of type SIII	\N	1	-711	\N	C	2019-12-20 22:14:28.053842+00	3714
1	710	2	-710	body of incipient Jomon pottery of type SIII	\N	1	-710	\N	C	2019-12-20 22:14:28.053842+00	3715
1	709	2	-709	rim of incipient Jomon pottery of type SIII	\N	1	-709	\N	C	2019-12-20 22:14:28.053842+00	3716
1	708	2	-708	rim of incipient Jomon pottery of type SIII	\N	1	-708	\N	C	2019-12-20 22:14:28.053842+00	3717
1	707	2	-707	rim of incipient Jomon pottery of type SIII	\N	1	-707	\N	C	2019-12-20 22:14:28.053842+00	3718
1	706	2	-706	body of incipient Jomon pottery of type SIII	\N	1	-706	\N	C	2019-12-20 22:14:28.053842+00	3719
1	705	2	-705	rim of incipient Jomon pottery of type SIII	\N	1	-705	\N	C	2019-12-20 22:14:28.053842+00	3720
1	704	2	-704	rim of incipient Jomon pottery of type SIII	\N	1	-704	\N	C	2019-12-20 22:14:28.053842+00	3721
1	703	2	-703	body of incipient Jomon pottery of type SII	\N	1	-703	\N	C	2019-12-20 22:14:28.053842+00	3722
1	702	2	-702	body of incipient Jomon pottery of type SII	\N	1	-702	\N	C	2019-12-20 22:14:28.053842+00	3723
1	701	2	-701	body of incipient Jomon pottery of type SI	\N	1	-701	\N	C	2019-12-20 22:14:28.053842+00	3724
1	700	2	-700	body of incipient Jomon pottery of type SI	\N	1	-700	\N	C	2019-12-20 22:14:28.053842+00	3725
1	699	2	-699	unknown part of incipient Jomon pottery of type SII	\N	1	-699	\N	C	2019-12-20 22:14:28.053842+00	3726
1	698	2	-698	unknown part of incipient Jomon pottery of type SII	\N	1	-698	\N	C	2019-12-20 22:14:28.053842+00	3727
1	697	2	-697	unknown part of incipient Jomon pottery of type SII	\N	1	-697	\N	C	2019-12-20 22:14:28.053842+00	3728
1	696	2	-696	unknown part of incipient Jomon pottery of type SII	\N	1	-696	\N	C	2019-12-20 22:14:28.053842+00	3729
1	695	2	-695	unknown part of incipient Jomon pottery of type SII	\N	1	-695	\N	C	2019-12-20 22:14:28.053842+00	3730
1	694	2	-694	unknown part of incipient Jomon pottery of type SII	\N	1	-694	\N	C	2019-12-20 22:14:28.053842+00	3731
1	693	2	-693	unknown part of incipient Jomon pottery of type SII	\N	1	-693	\N	C	2019-12-20 22:14:28.053842+00	3732
1	692	2	-692	unknown part of incipient Jomon pottery of type SII	\N	1	-692	\N	C	2019-12-20 22:14:28.053842+00	3733
1	691	2	-691	unknown part of incipient Jomon pottery of type SII	\N	1	-691	\N	C	2019-12-20 22:14:28.053842+00	3734
1	690	2	-690	unknown part of incipient Jomon pottery of type SII	\N	1	-690	\N	C	2019-12-20 22:14:28.053842+00	3735
1	689	2	-689	unknown part of incipient Jomon pottery of type SII	\N	1	-689	\N	C	2019-12-20 22:14:28.053842+00	3736
1	688	2	-688	unknown part of incipient Jomon pottery of type SII	\N	1	-688	\N	C	2019-12-20 22:14:28.053842+00	3737
1	687	2	-687	unknown part of incipient Jomon pottery of type SII	\N	1	-687	\N	C	2019-12-20 22:14:28.053842+00	3738
1	686	2	-686	unknown part of incipient Jomon pottery of type SII	\N	1	-686	\N	C	2019-12-20 22:14:28.053842+00	3739
1	685	2	-685	unknown part of incipient Jomon pottery of type SII	\N	1	-685	\N	C	2019-12-20 22:14:28.053842+00	3740
1	684	2	-684	unknown part of incipient Jomon pottery of type SII	\N	1	-684	\N	C	2019-12-20 22:14:28.053842+00	3741
1	683	2	-683	unknown part of incipient Jomon pottery of type SII	\N	1	-683	\N	C	2019-12-20 22:14:28.053842+00	3742
1	682	2	-682	unknown part of incipient Jomon pottery of type SII	\N	1	-682	\N	C	2019-12-20 22:14:28.053842+00	3743
1	681	2	-681	unknown part of incipient Jomon pottery of type SII	\N	1	-681	\N	C	2019-12-20 22:14:28.053842+00	3744
1	680	2	-680	unknown part of incipient Jomon pottery of type SII	\N	1	-680	\N	C	2019-12-20 22:14:28.053842+00	3745
1	679	2	-679	unknown part of incipient Jomon pottery of type SII	\N	1	-679	\N	C	2019-12-20 22:14:28.053842+00	3746
1	678	2	-678	unknown part of incipient Jomon pottery of type SII	\N	1	-678	\N	C	2019-12-20 22:14:28.053842+00	3747
1	677	2	-677	unknown part of incipient Jomon pottery of type SII	\N	1	-677	\N	C	2019-12-20 22:14:28.053842+00	3748
1	676	2	-676	body of initial Jomon pottery of type SIV	\N	1	-676	\N	C	2019-12-20 22:14:28.053842+00	3749
1	675	2	-675	body of initial Jomon pottery of type SIV	\N	1	-675	\N	C	2019-12-20 22:14:28.053842+00	3750
1	674	2	-674	body of initial Jomon pottery of type SIV	\N	1	-674	\N	C	2019-12-20 22:14:28.053842+00	3751
1	673	2	-673	body of initial Jomon pottery of type SIV	\N	1	-673	\N	C	2019-12-20 22:14:28.053842+00	3752
1	672	2	-672	body of initial Jomon pottery of type SIV	\N	1	-672	\N	C	2019-12-20 22:14:28.053842+00	3753
1	671	2	-671	body of initial Jomon pottery of type SIV	\N	1	-671	\N	C	2019-12-20 22:14:28.053842+00	3754
1	670	2	-670	body of initial Jomon pottery of type SIV	\N	1	-670	\N	C	2019-12-20 22:14:28.053842+00	3755
1	669	2	-669	body of initial Jomon pottery of type SIV	\N	1	-669	\N	C	2019-12-20 22:14:28.053842+00	3756
1	668	2	-668	base of initial Jomon pottery of type SIV	\N	1	-668	\N	C	2019-12-20 22:14:28.053842+00	3757
1	667	2	-667	body of initial Jomon pottery of type SIV	\N	1	-667	\N	C	2019-12-20 22:14:28.053842+00	3758
1	666	2	-666	rim of initial Jomon pottery of type SIV	\N	1	-666	\N	C	2019-12-20 22:14:28.053842+00	3759
1	665	2	-665	body of initial Jomon pottery of type SIV	\N	1	-665	\N	C	2019-12-20 22:14:28.053842+00	3760
1	664	2	-664	body of initial Jomon pottery of type SIV	\N	1	-664	\N	C	2019-12-20 22:14:28.053842+00	3761
1	663	2	-663	body of initial Jomon pottery of type SIV	\N	1	-663	\N	C	2019-12-20 22:14:28.053842+00	3762
1	662	2	-662	rim of initial Jomon pottery of type SIV	\N	1	-662	\N	C	2019-12-20 22:14:28.053842+00	3763
1	661	2	-661	body of initial Jomon pottery of type SIV	\N	1	-661	\N	C	2019-12-20 22:14:28.053842+00	3764
1	660	2	-660	body of initial Jomon pottery of type SIV	\N	1	-660	\N	C	2019-12-20 22:14:28.053842+00	3765
1	659	2	-659	body of initial Jomon pottery of type SIV	\N	1	-659	\N	C	2019-12-20 22:14:28.053842+00	3766
1	658	2	-658	rim of initial Jomon pottery of type SIV	\N	1	-658	\N	C	2019-12-20 22:14:28.053842+00	3767
1	657	2	-657	body of initial Jomon pottery of type SIV	\N	1	-657	\N	C	2019-12-20 22:14:28.053842+00	3768
1	656	2	-656	rim of initial Jomon pottery of type SIV	\N	1	-656	\N	C	2019-12-20 22:14:28.053842+00	3769
1	655	2	-655	body of initial Jomon pottery of type SIV	\N	1	-655	\N	C	2019-12-20 22:14:28.053842+00	3770
1	654	2	-654	body of initial Jomon pottery of type SIV	\N	1	-654	\N	C	2019-12-20 22:14:28.053842+00	3771
1	653	2	-653	body of initial Jomon pottery of type SIV	\N	1	-653	\N	C	2019-12-20 22:14:28.053842+00	3772
1	652	2	-652	body of initial Jomon pottery of type SIV	\N	1	-652	\N	C	2019-12-20 22:14:28.053842+00	3773
1	651	2	-651	body of initial Jomon pottery of type SIV	\N	1	-651	\N	C	2019-12-20 22:14:28.053842+00	3774
1	650	2	-650	body of initial Jomon pottery of type SIV	\N	1	-650	\N	C	2019-12-20 22:14:28.053842+00	3775
1	649	2	-649	body of initial Jomon pottery of type SIV	\N	1	-649	\N	C	2019-12-20 22:14:28.053842+00	3776
1	648	2	-648	body of initial Jomon pottery of type SIV	\N	1	-648	\N	C	2019-12-20 22:14:28.053842+00	3777
1	647	2	-647	body of initial Jomon pottery of type SIV	\N	1	-647	\N	C	2019-12-20 22:14:28.053842+00	3778
1	646	2	-646	rim of initial Jomon pottery of type SIV	\N	1	-646	\N	C	2019-12-20 22:14:28.053842+00	3779
1	645	2	-645	rim of initial Jomon pottery of type SIV	\N	1	-645	\N	C	2019-12-20 22:14:28.053842+00	3780
1	644	2	-644	rim of initial Jomon pottery of type SIV	\N	1	-644	\N	C	2019-12-20 22:14:28.053842+00	3781
1	643	2	-643	body of initial Jomon pottery of type SIV	\N	1	-643	\N	C	2019-12-20 22:14:28.053842+00	3782
1	642	2	-642	body of initial Jomon pottery of type SIV	\N	1	-642	\N	C	2019-12-20 22:14:28.053842+00	3783
1	641	2	-641	body of initial Jomon pottery of type SIV	\N	1	-641	\N	C	2019-12-20 22:14:28.053842+00	3784
1	640	2	-640	body of initial Jomon pottery of type SIV	\N	1	-640	\N	C	2019-12-20 22:14:28.053842+00	3785
1	639	2	-639	body of initial Jomon pottery of type SIV	\N	1	-639	\N	C	2019-12-20 22:14:28.053842+00	3786
1	638	2	-638	body of initial Jomon pottery of type SIV	\N	1	-638	\N	C	2019-12-20 22:14:28.053842+00	3787
1	637	2	-637	body of initial Jomon pottery of type SIV	\N	1	-637	\N	C	2019-12-20 22:14:28.053842+00	3788
1	636	2	-636	body of initial Jomon pottery of type SIV	\N	1	-636	\N	C	2019-12-20 22:14:28.053842+00	3789
1	635	2	-635	body of initial Jomon pottery of type SIV	\N	1	-635	\N	C	2019-12-20 22:14:28.053842+00	3790
1	634	2	-634	body of initial Jomon pottery of type SIV	\N	1	-634	\N	C	2019-12-20 22:14:28.053842+00	3791
1	633	2	-633	body of initial Jomon pottery of type SIV	\N	1	-633	\N	C	2019-12-20 22:14:28.053842+00	3792
1	632	2	-632	body of initial Jomon pottery of type SIV	\N	1	-632	\N	C	2019-12-20 22:14:28.053842+00	3793
1	631	2	-631	body of initial Jomon pottery of type SIV	\N	1	-631	\N	C	2019-12-20 22:14:28.053842+00	3794
1	630	2	-630	body of initial Jomon pottery of type SIV	\N	1	-630	\N	C	2019-12-20 22:14:28.053842+00	3795
1	629	2	-629	body of initial Jomon pottery of type SIV	\N	1	-629	\N	C	2019-12-20 22:14:28.053842+00	3796
1	628	2	-628	base of initial Jomon pottery of type SIV	\N	1	-628	\N	C	2019-12-20 22:14:28.053842+00	3797
1	627	2	-627	body of initial Jomon pottery of type SIV	\N	1	-627	\N	C	2019-12-20 22:14:28.053842+00	3798
1	626	2	-626	rim of initial Jomon pottery of type SIV	\N	1	-626	\N	C	2019-12-20 22:14:28.053842+00	3799
1	625	2	-625	body of initial Jomon pottery of type SIV	\N	1	-625	\N	C	2019-12-20 22:14:28.053842+00	3800
1	624	2	-624	body of initial Jomon pottery of type SIV	\N	1	-624	\N	C	2019-12-20 22:14:28.053842+00	3801
1	623	2	-623	body of initial Jomon pottery of type SIV	\N	1	-623	\N	C	2019-12-20 22:14:28.053842+00	3802
1	622	2	-622	rim of initial Jomon pottery of type SIV	\N	1	-622	\N	C	2019-12-20 22:14:28.053842+00	3803
1	621	2	-621	base of initial Jomon pottery of type SIV	\N	1	-621	\N	C	2019-12-20 22:14:28.053842+00	3804
1	620	2	-620	rim-upper body of initial Jomon pottery of type SIV	\N	1	-620	\N	C	2019-12-20 22:14:28.053842+00	3805
1	619	2	-619	rim-upper body of initial Jomon pottery of type SIV	\N	1	-619	\N	C	2019-12-20 22:14:28.053842+00	3806
1	618	2	-618	body of initial Jomon pottery of type SIV	\N	1	-618	\N	C	2019-12-20 22:14:28.053842+00	3807
1	617	2	-617	rim of initial Jomon pottery of type SIV	\N	1	-617	\N	C	2019-12-20 22:14:28.053842+00	3808
1	616	2	-616	rim-upper body of initial Jomon pottery of type SIV	\N	1	-616	\N	C	2019-12-20 22:14:28.053842+00	3809
1	615	2	-615	rim-upper body of initial Jomon pottery of type SIV	\N	1	-615	\N	C	2019-12-20 22:14:28.053842+00	3810
1	614	2	-614	body of initial Jomon pottery of type SIV	\N	1	-614	\N	C	2019-12-20 22:14:28.053842+00	3811
1	613	2	-613	body of initial Jomon pottery of type SIV	\N	1	-613	\N	C	2019-12-20 22:14:28.053842+00	3812
1	612	2	-612	body of initial Jomon pottery of type SIV	\N	1	-612	\N	C	2019-12-20 22:14:28.053842+00	3813
1	611	2	-611	body of initial Jomon pottery of type SIV	\N	1	-611	\N	C	2019-12-20 22:14:28.053842+00	3814
1	610	2	-610	body of initial Jomon pottery of type SIV	\N	1	-610	\N	C	2019-12-20 22:14:28.053842+00	3815
1	609	2	-609	body of initial Jomon pottery of type SIV	\N	1	-609	\N	C	2019-12-20 22:14:28.053842+00	3816
1	608	2	-608	body of initial Jomon pottery of type SIV	\N	1	-608	\N	C	2019-12-20 22:14:28.053842+00	3817
1	607	2	-607	body of initial Jomon pottery of type SIV	\N	1	-607	\N	C	2019-12-20 22:14:28.053842+00	3818
1	606	2	-606	body of initial Jomon pottery of type SIV	\N	1	-606	\N	C	2019-12-20 22:14:28.053842+00	3819
1	605	2	-605	rim of initial Jomon pottery of type SIV	\N	1	-605	\N	C	2019-12-20 22:14:28.053842+00	3820
1	604	2	-604	body of initial Jomon pottery of type SIV	\N	1	-604	\N	C	2019-12-20 22:14:28.053842+00	3821
1	603	2	-603	body of initial Jomon pottery of type SIV	\N	1	-603	\N	C	2019-12-20 22:14:28.053842+00	3822
1	602	2	-602	base of initial Jomon pottery of type SIV	\N	1	-602	\N	C	2019-12-20 22:14:28.053842+00	3823
1	601	2	-601	body of initial Jomon pottery of type SIV	\N	1	-601	\N	C	2019-12-20 22:14:28.053842+00	3824
1	600	2	-600	body of initial Jomon pottery of type SIV	\N	1	-600	\N	C	2019-12-20 22:14:28.053842+00	3825
1	599	2	-599	rim of initial Jomon pottery of type SIV	\N	1	-599	\N	C	2019-12-20 22:14:28.053842+00	3826
1	598	2	-598	body of initial Jomon pottery of type SIV	\N	1	-598	\N	C	2019-12-20 22:14:28.053842+00	3827
1	597	2	-597	body of initial Jomon pottery of type SIV	\N	1	-597	\N	C	2019-12-20 22:14:28.053842+00	3828
1	596	2	-596	body of initial Jomon pottery of type SIV	\N	1	-596	\N	C	2019-12-20 22:14:28.053842+00	3829
1	595	2	-595	body of initial Jomon pottery of type SIV	\N	1	-595	\N	C	2019-12-20 22:14:28.053842+00	3830
1	594	2	-594	rim of initial Jomon pottery of type SIV	\N	1	-594	\N	C	2019-12-20 22:14:28.053842+00	3831
1	593	2	-593	body of initial Jomon pottery of type SIV	\N	1	-593	\N	C	2019-12-20 22:14:28.053842+00	3832
1	592	2	-592	body of initial Jomon pottery of type SIV	\N	1	-592	\N	C	2019-12-20 22:14:28.053842+00	3833
1	591	2	-591	rim of initial Jomon pottery of type SIV	\N	1	-591	\N	C	2019-12-20 22:14:28.053842+00	3834
1	590	2	-590	rim of initial Jomon pottery of type SIV	\N	1	-590	\N	C	2019-12-20 22:14:28.053842+00	3835
1	589	2	-589	rim of initial Jomon pottery of type SIV	\N	1	-589	\N	C	2019-12-20 22:14:28.053842+00	3836
1	588	2	-588	body of initial Jomon pottery of type SIV	\N	1	-588	\N	C	2019-12-20 22:14:28.053842+00	3837
1	587	2	-587	body of initial Jomon pottery of type SIV	\N	1	-587	\N	C	2019-12-20 22:14:28.053842+00	3838
1	586	2	-586	rim-upper body of initial Jomon pottery of type SIV	\N	1	-586	\N	C	2019-12-20 22:14:28.053842+00	3839
1	585	2	-585	rim-upper body of initial Jomon pottery of type SIV	\N	1	-585	\N	C	2019-12-20 22:14:28.053842+00	3840
1	584	2	-584	rim-upper body of initial Jomon pottery of type SIV	\N	1	-584	\N	C	2019-12-20 22:14:28.053842+00	3841
1	583	2	-583	upper body of initial Jomon pottery of type SIV	\N	1	-583	\N	C	2019-12-20 22:14:28.053842+00	3842
1	582	2	-582	rim-upper body of initial Jomon pottery of type SIV	\N	1	-582	\N	C	2019-12-20 22:14:28.053842+00	3843
1	581	2	-581	body of initial Jomon pottery of type SIV	\N	1	-581	\N	C	2019-12-20 22:14:28.053842+00	3844
1	580	2	-580	rim-upper body of initial Jomon pottery of type SIV	\N	1	-580	\N	C	2019-12-20 22:14:28.053842+00	3845
1	579	2	-579	upper body of initial Jomon pottery of type SIV	\N	1	-579	\N	C	2019-12-20 22:14:28.053842+00	3846
1	578	2	-578	upper body of initial Jomon pottery of type SIV	\N	1	-578	\N	C	2019-12-20 22:14:28.053842+00	3847
1	577	2	-577	body of initial Jomon pottery of type SIV	\N	1	-577	\N	C	2019-12-20 22:14:28.053842+00	3848
1	576	2	-576	body of initial Jomon pottery of type SIV	\N	1	-576	\N	C	2019-12-20 22:14:28.053842+00	3849
1	575	2	-575	upper body of initial Jomon pottery of type SIV	\N	1	-575	\N	C	2019-12-20 22:14:28.053842+00	3850
1	574	2	-574	upper body of initial Jomon pottery of type SIV	\N	1	-574	\N	C	2019-12-20 22:14:28.053842+00	3851
1	573	2	-573	rim-upper body of initial Jomon pottery of type SIV	\N	1	-573	\N	C	2019-12-20 22:14:28.053842+00	3852
1	572	2	-572	body of initial Jomon pottery of type SIV	\N	1	-572	\N	C	2019-12-20 22:14:28.053842+00	3853
1	571	2	-571	body of initial Jomon pottery of type SIV	\N	1	-571	\N	C	2019-12-20 22:14:28.053842+00	3854
1	570	2	-570	body of initial Jomon pottery of type SIV	\N	1	-570	\N	C	2019-12-20 22:14:28.053842+00	3855
1	569	2	-569	upper body of initial Jomon pottery of type SIV	\N	1	-569	\N	C	2019-12-20 22:14:28.053842+00	3856
1	568	2	-568	body of initial Jomon pottery of type SIV	\N	1	-568	\N	C	2019-12-20 22:14:28.053842+00	3857
1	567	2	-567	body of initial Jomon pottery of type SIV	\N	1	-567	\N	C	2019-12-20 22:14:28.053842+00	3858
1	566	2	-566	body of initial Jomon pottery of type SIV	\N	1	-566	\N	C	2019-12-20 22:14:28.053842+00	3859
1	565	2	-565	body of initial Jomon pottery of type SIV	\N	1	-565	\N	C	2019-12-20 22:14:28.053842+00	3860
1	564	2	-564	rim-upper body of initial Jomon pottery of type SIV	\N	1	-564	\N	C	2019-12-20 22:14:28.053842+00	3861
1	563	2	-563	body of initial Jomon pottery of type SIV	\N	1	-563	\N	C	2019-12-20 22:14:28.053842+00	3862
1	562	2	-562	body of initial Jomon pottery of type SIV	\N	1	-562	\N	C	2019-12-20 22:14:28.053842+00	3863
1	561	2	-561	body of initial Jomon pottery of type SIV	\N	1	-561	\N	C	2019-12-20 22:14:28.053842+00	3864
1	560	2	-560	body of initial Jomon pottery of type SIV	\N	1	-560	\N	C	2019-12-20 22:14:28.053842+00	3865
1	559	2	-559	body of initial Jomon pottery of type SIV	\N	1	-559	\N	C	2019-12-20 22:14:28.053842+00	3866
1	558	2	-558	rim of initial Jomon pottery of type SIV	\N	1	-558	\N	C	2019-12-20 22:14:28.053842+00	3867
1	557	2	-557	rim of initial Jomon pottery of type SIV	\N	1	-557	\N	C	2019-12-20 22:14:28.053842+00	3868
1	556	2	-556	body of initial Jomon pottery of type SIV	\N	1	-556	\N	C	2019-12-20 22:14:28.053842+00	3869
1	555	2	-555	rim of initial Jomon pottery of type SIV	\N	1	-555	\N	C	2019-12-20 22:14:28.053842+00	3870
1	554	2	-554	body of initial Jomon pottery of type SIV	\N	1	-554	\N	C	2019-12-20 22:14:28.053842+00	3871
1	553	2	-553	body of initial Jomon pottery of type SIV	\N	1	-553	\N	C	2019-12-20 22:14:28.053842+00	3872
1	552	2	-552	body of initial Jomon pottery of type SIV	\N	1	-552	\N	C	2019-12-20 22:14:28.053842+00	3873
1	551	2	-551	body of initial Jomon pottery of type SIV	\N	1	-551	\N	C	2019-12-20 22:14:28.053842+00	3874
1	550	2	-550	body of initial Jomon pottery of type SIV	\N	1	-550	\N	C	2019-12-20 22:14:28.053842+00	3875
1	549	2	-549	body of initial Jomon pottery of type SIV	\N	1	-549	\N	C	2019-12-20 22:14:28.053842+00	3876
1	548	2	-548	body of initial Jomon pottery of type SIV	\N	1	-548	\N	C	2019-12-20 22:14:28.053842+00	3877
1	547	2	-547	body of initial Jomon pottery of type SIV	\N	1	-547	\N	C	2019-12-20 22:14:28.053842+00	3878
1	546	2	-546	body of initial Jomon pottery of type SIV	\N	1	-546	\N	C	2019-12-20 22:14:28.053842+00	3879
1	545	2	-545	body of initial Jomon pottery of type SIV	\N	1	-545	\N	C	2019-12-20 22:14:28.053842+00	3880
1	544	2	-544	body of initial Jomon pottery of type SIV	\N	1	-544	\N	C	2019-12-20 22:14:28.053842+00	3881
1	543	2	-543	body of initial Jomon pottery of type SIV	\N	1	-543	\N	C	2019-12-20 22:14:28.053842+00	3882
1	542	2	-542	body of initial Jomon pottery of type SIV	\N	1	-542	\N	C	2019-12-20 22:14:28.053842+00	3883
1	541	2	-541	body of initial Jomon pottery of type SIV	\N	1	-541	\N	C	2019-12-20 22:14:28.053842+00	3884
1	540	2	-540	body of initial Jomon pottery of type SIV	\N	1	-540	\N	C	2019-12-20 22:14:28.053842+00	3885
1	539	2	-539	body of initial Jomon pottery of type SIV	\N	1	-539	\N	C	2019-12-20 22:14:28.053842+00	3886
1	538	2	-538	body of initial Jomon pottery of type SIV	\N	1	-538	\N	C	2019-12-20 22:14:28.053842+00	3887
1	537	2	-537	body of initial Jomon pottery of type SIV	\N	1	-537	\N	C	2019-12-20 22:14:28.053842+00	3888
1	536	2	-536	body of initial Jomon pottery of type SIV	\N	1	-536	\N	C	2019-12-20 22:14:28.053842+00	3889
1	535	2	-535	body of initial Jomon pottery of type SIV	\N	1	-535	\N	C	2019-12-20 22:14:28.053842+00	3890
1	534	2	-534	body of initial Jomon pottery of type SIV	\N	1	-534	\N	C	2019-12-20 22:14:28.053842+00	3891
1	533	2	-533	rim of initial Jomon pottery of type SIV	\N	1	-533	\N	C	2019-12-20 22:14:28.053842+00	3892
1	532	2	-532	body of initial Jomon pottery of type SIV	\N	1	-532	\N	C	2019-12-20 22:14:28.053842+00	3893
1	531	2	-531	rim of initial Jomon pottery of type SIV	\N	1	-531	\N	C	2019-12-20 22:14:28.053842+00	3894
1	530	2	-530	body of initial Jomon pottery of type SIV	\N	1	-530	\N	C	2019-12-20 22:14:28.053842+00	3895
1	529	2	-529	body of initial Jomon pottery of type SIV	\N	1	-529	\N	C	2019-12-20 22:14:28.053842+00	3896
1	528	2	-528	rim of initial Jomon pottery of type SIV	\N	1	-528	\N	C	2019-12-20 22:14:28.053842+00	3897
1	527	2	-527	body of initial Jomon pottery of type SIV	\N	1	-527	\N	C	2019-12-20 22:14:28.053842+00	3898
1	526	2	-526	body of initial Jomon pottery of type SIV	\N	1	-526	\N	C	2019-12-20 22:14:28.053842+00	3899
1	525	2	-525	body of initial Jomon pottery of type SIV	\N	1	-525	\N	C	2019-12-20 22:14:28.053842+00	3900
1	524	2	-524	body of initial Jomon pottery of type SIV	\N	1	-524	\N	C	2019-12-20 22:14:28.053842+00	3901
1	523	2	-523	body of initial Jomon pottery of type SIV	\N	1	-523	\N	C	2019-12-20 22:14:28.053842+00	3902
1	522	2	-522	rim of initial Jomon pottery of type SIV	\N	1	-522	\N	C	2019-12-20 22:14:28.053842+00	3903
1	521	2	-521	body of initial Jomon pottery of type SIV	\N	1	-521	\N	C	2019-12-20 22:14:28.053842+00	3904
1	520	2	-520	body of initial Jomon pottery of type SIV	\N	1	-520	\N	C	2019-12-20 22:14:28.053842+00	3905
1	519	2	-519	body of initial Jomon pottery of type SIV	\N	1	-519	\N	C	2019-12-20 22:14:28.053842+00	3906
1	518	2	-518	body of initial Jomon pottery of type SIV	\N	1	-518	\N	C	2019-12-20 22:14:28.053842+00	3907
1	517	2	-517	rim of initial Jomon pottery of type SIV	\N	1	-517	\N	C	2019-12-20 22:14:28.053842+00	3908
1	516	2	-516	rim of initial Jomon pottery of type SIV	\N	1	-516	\N	C	2019-12-20 22:14:28.053842+00	3909
1	515	2	-515	body of initial Jomon pottery of type SIV	\N	1	-515	\N	C	2019-12-20 22:14:28.053842+00	3910
1	514	2	-514	rim of initial Jomon pottery of type SIV	\N	1	-514	\N	C	2019-12-20 22:14:28.053842+00	3911
1	513	2	-513	body of initial Jomon pottery of type SIV	\N	1	-513	\N	C	2019-12-20 22:14:28.053842+00	3912
1	512	2	-512	body of initial Jomon pottery of type SIV	\N	1	-512	\N	C	2019-12-20 22:14:28.053842+00	3913
1	511	2	-511	body of initial Jomon pottery of type SIV	\N	1	-511	\N	C	2019-12-20 22:14:28.053842+00	3914
1	510	2	-510	body of initial Jomon pottery of type SIV	\N	1	-510	\N	C	2019-12-20 22:14:28.053842+00	3915
1	509	2	-509	body of initial Jomon pottery of type SIV	\N	1	-509	\N	C	2019-12-20 22:14:28.053842+00	3916
1	508	2	-508	body of initial Jomon pottery of type SIV	\N	1	-508	\N	C	2019-12-20 22:14:28.053842+00	3917
1	507	2	-507	body of initial Jomon pottery of type SIV	\N	1	-507	\N	C	2019-12-20 22:14:28.053842+00	3918
1	506	2	-506	body of initial Jomon pottery of type SIV	\N	1	-506	\N	C	2019-12-20 22:14:28.053842+00	3919
1	505	2	-505	body of initial Jomon pottery of type SIV	\N	1	-505	\N	C	2019-12-20 22:14:28.053842+00	3920
1	504	2	-504	body of initial Jomon pottery of type SIV	\N	1	-504	\N	C	2019-12-20 22:14:28.053842+00	3921
1	503	2	-503	body of initial Jomon pottery of type SIV	\N	1	-503	\N	C	2019-12-20 22:14:28.053842+00	3922
1	502	2	-502	body of initial Jomon pottery of type SIV	\N	1	-502	\N	C	2019-12-20 22:14:28.053842+00	3923
1	501	2	-501	body of initial Jomon pottery of type SIV	\N	1	-501	\N	C	2019-12-20 22:14:28.053842+00	3924
1	500	2	-500	body of initial Jomon pottery of type SIV	\N	1	-500	\N	C	2019-12-20 22:14:28.053842+00	3925
1	499	2	-499	body of initial Jomon pottery of type SIV	\N	1	-499	\N	C	2019-12-20 22:14:28.053842+00	3926
1	498	2	-498	body of initial Jomon pottery of type SIV	\N	1	-498	\N	C	2019-12-20 22:14:28.053842+00	3927
1	497	2	-497	body of initial Jomon pottery of type SIV	\N	1	-497	\N	C	2019-12-20 22:14:28.053842+00	3928
1	496	2	-496	body of initial Jomon pottery of type SIV	\N	1	-496	\N	C	2019-12-20 22:14:28.053842+00	3929
1	495	2	-495	body of initial Jomon pottery of type SIV	\N	1	-495	\N	C	2019-12-20 22:14:28.053842+00	3930
1	494	2	-494	body of initial Jomon pottery of type SIV	\N	1	-494	\N	C	2019-12-20 22:14:28.053842+00	3931
1	493	2	-493	body of initial Jomon pottery of type SIV	\N	1	-493	\N	C	2019-12-20 22:14:28.053842+00	3932
1	492	2	-492	unknown part of incipient Jomon pottery of type SIII	\N	1	-492	\N	C	2019-12-20 22:14:28.053842+00	3933
1	491	2	-491	unknown part of incipient Jomon pottery of type SIII	\N	1	-491	\N	C	2019-12-20 22:14:28.053842+00	3934
1	490	2	-490	unknown part of incipient Jomon pottery of type SIII	\N	1	-490	\N	C	2019-12-20 22:14:28.053842+00	3935
1	489	2	-489	rim of incipient Jomon pottery of type SIII	\N	1	-489	\N	C	2019-12-20 22:14:28.053842+00	3936
1	488	2	-488	unknown part of incipient Jomon pottery of type SIII	\N	1	-488	\N	C	2019-12-20 22:14:28.053842+00	3937
1	487	2	-487	unknown part of incipient Jomon pottery of type SIII	\N	1	-487	\N	C	2019-12-20 22:14:28.053842+00	3938
1	486	2	-486	unknown part of incipient Jomon pottery of type SII	\N	1	-486	\N	C	2019-12-20 22:14:28.053842+00	3939
1	485	2	-485	unknown part of incipient Jomon pottery of type SII	\N	1	-485	\N	C	2019-12-20 22:14:28.053842+00	3940
1	484	2	-484	unknown part of incipient Jomon pottery of type SII	\N	1	-484	\N	C	2019-12-20 22:14:28.053842+00	3941
1	483	2	-483	unknown part of incipient Jomon pottery of type SII	\N	1	-483	\N	C	2019-12-20 22:14:28.053842+00	3942
1	482	2	-482	unknown part of incipient Jomon pottery of type SII	\N	1	-482	\N	C	2019-12-20 22:14:28.053842+00	3943
1	481	2	-481	unknown part of incipient Jomon pottery of type SII	\N	1	-481	\N	C	2019-12-20 22:14:28.053842+00	3944
1	480	2	-480	unknown part of incipient Jomon pottery of type SII	\N	1	-480	\N	C	2019-12-20 22:14:28.053842+00	3945
1	479	2	-479	unknown part of incipient Jomon pottery of type SII	\N	1	-479	\N	C	2019-12-20 22:14:28.053842+00	3946
1	478	2	-478	unknown part of incipient Jomon pottery of type SII	\N	1	-478	\N	C	2019-12-20 22:14:28.053842+00	3947
1	477	2	-477	unknown part of incipient Jomon pottery of type SII	\N	1	-477	\N	C	2019-12-20 22:14:28.053842+00	3948
1	476	2	-476	unknown part of incipient Jomon pottery of type SIII	\N	1	-476	\N	C	2019-12-20 22:14:28.053842+00	3949
1	475	2	-475	unknown part of incipient Jomon pottery of type SIII	\N	1	-475	\N	C	2019-12-20 22:14:28.053842+00	3950
1	474	2	-474	unknown part of incipient Jomon pottery of type SIII	\N	1	-474	\N	C	2019-12-20 22:14:28.053842+00	3951
1	473	2	-473	unknown part of incipient Jomon pottery of type SIII	\N	1	-473	\N	C	2019-12-20 22:14:28.053842+00	3952
1	472	2	-472	unknown part of incipient Jomon pottery of type SIII	\N	1	-472	\N	C	2019-12-20 22:14:28.053842+00	3953
1	471	2	-471	unknown part of incipient Jomon pottery of type SIII	\N	1	-471	\N	C	2019-12-20 22:14:28.053842+00	3954
1	470	2	-470	unknown part of incipient Jomon pottery of type SIII	\N	1	-470	\N	C	2019-12-20 22:14:28.053842+00	3955
1	469	2	-469	unknown part of incipient Jomon pottery of type SIII	\N	1	-469	\N	C	2019-12-20 22:14:28.053842+00	3956
1	468	2	-468	unknown part of incipient Jomon pottery of type SIII	\N	1	-468	\N	C	2019-12-20 22:14:28.053842+00	3957
1	467	2	-467	unknown part of incipient Jomon pottery of type SIII	\N	1	-467	\N	C	2019-12-20 22:14:28.053842+00	3958
1	466	2	-466	unknown part of incipient Jomon pottery of type SIII	\N	1	-466	\N	C	2019-12-20 22:14:28.053842+00	3959
1	465	2	-465	unknown part of incipient Jomon pottery of type SIII	\N	1	-465	\N	C	2019-12-20 22:14:28.053842+00	3960
1	464	2	-464	unknown part of incipient Jomon pottery of type SIII	\N	1	-464	\N	C	2019-12-20 22:14:28.053842+00	3961
1	463	2	-463	unknown part of incipient Jomon pottery of type SIII	\N	1	-463	\N	C	2019-12-20 22:14:28.053842+00	3962
1	462	2	-462	unknown part of incipient Jomon pottery of type SIII	\N	1	-462	\N	C	2019-12-20 22:14:28.053842+00	3963
1	461	2	-461	unknown part of incipient Jomon pottery of type SIII	\N	1	-461	\N	C	2019-12-20 22:14:28.053842+00	3964
1	460	2	-460	unknown part of incipient Jomon pottery of type SIII	\N	1	-460	\N	C	2019-12-20 22:14:28.053842+00	3965
1	459	2	-459	unknown part of incipient Jomon pottery of type SIII	\N	1	-459	\N	C	2019-12-20 22:14:28.053842+00	3966
1	458	2	-458	unknown part of incipient Jomon pottery of type SIII	\N	1	-458	\N	C	2019-12-20 22:14:28.053842+00	3967
1	457	2	-457	unknown part of incipient Jomon pottery of type SIII	\N	1	-457	\N	C	2019-12-20 22:14:28.053842+00	3968
1	456	2	-456	unknown part of incipient Jomon pottery of type SIII	\N	1	-456	\N	C	2019-12-20 22:14:28.053842+00	3969
1	455	2	-455	unknown part of incipient Jomon pottery of type SII	\N	1	-455	\N	C	2019-12-20 22:14:28.053842+00	3970
1	454	2	-454	unknown part of incipient Jomon pottery of type SII	\N	1	-454	\N	C	2019-12-20 22:14:28.053842+00	3971
1	453	2	-453	unknown part of incipient Jomon pottery of type SII	\N	1	-453	\N	C	2019-12-20 22:14:28.053842+00	3972
1	452	2	-452	unknown part of incipient Jomon pottery of type SII	\N	1	-452	\N	C	2019-12-20 22:14:28.053842+00	3973
1	451	2	-451	unknown part of incipient Jomon pottery of type SII	\N	1	-451	\N	C	2019-12-20 22:14:28.053842+00	3974
1	450	2	-450	upper body of incipient Jomon pottery of type SIII	\N	1	-450	\N	C	2019-12-20 22:14:28.053842+00	3975
1	449	2	-449	unknown part of initial Jomon pottery of type SIV	\N	1	-449	\N	C	2019-12-20 22:14:28.053842+00	3976
1	448	2	-448	unknown part of initial Jomon pottery of type SIV	\N	1	-448	\N	C	2019-12-20 22:14:28.053842+00	3977
1	447	2	-447	unknown part of initial Jomon pottery of type SIV	\N	1	-447	\N	C	2019-12-20 22:14:28.053842+00	3978
1	446	2	-446	unknown part of initial Jomon pottery of type SIV	\N	1	-446	\N	C	2019-12-20 22:14:28.053842+00	3979
1	445	2	-445	unknown part of initial Jomon pottery of type SIV	\N	1	-445	\N	C	2019-12-20 22:14:28.053842+00	3980
1	444	2	-444	unknown part of initial Jomon pottery of type SIV	\N	1	-444	\N	C	2019-12-20 22:14:28.053842+00	3981
1	443	2	-443	body of incipient Jomon pottery of type SIII	\N	1	-443	\N	C	2019-12-20 22:14:28.053842+00	3982
1	442	2	-442	rim of incipient Jomon pottery of type SIII	\N	1	-442	\N	C	2019-12-20 22:14:28.053842+00	3983
1	441	2	-441	rim of incipient Jomon pottery of type SIII	\N	1	-441	\N	C	2019-12-20 22:14:28.053842+00	3984
1	440	2	-440	unknown part of initial Jomon pottery of type SIV	\N	1	-440	\N	C	2019-12-20 22:14:28.053842+00	3985
1	439	2	-439	unknown part of initial Jomon pottery of type SIV	\N	1	-439	\N	C	2019-12-20 22:14:28.053842+00	3986
1	438	2	-438	unknown part of initial Jomon pottery of type SIV	\N	1	-438	\N	C	2019-12-20 22:14:28.053842+00	3987
1	437	2	-437	body of initial Jomon pottery of type SIV	\N	1	-437	\N	C	2019-12-20 22:14:28.053842+00	3988
1	436	2	-436	body of initial Jomon pottery of type SIV	\N	1	-436	\N	C	2019-12-20 22:14:28.053842+00	3989
1	435	2	-435	body of initial Jomon pottery of type SIV	\N	1	-435	\N	C	2019-12-20 22:14:28.053842+00	3990
1	434	2	-434	body of initial Jomon pottery of type SIV	\N	1	-434	\N	C	2019-12-20 22:14:28.053842+00	3991
1	433	2	-433	body of initial Jomon pottery of type SIV	\N	1	-433	\N	C	2019-12-20 22:14:28.053842+00	3992
1	432	2	-432	body of initial Jomon pottery of type SIV	\N	1	-432	\N	C	2019-12-20 22:14:28.053842+00	3993
1	431	2	-431	body of initial Jomon pottery of type SIV	\N	1	-431	\N	C	2019-12-20 22:14:28.053842+00	3994
1	430	2	-430	body of initial Jomon pottery of type SIV	\N	1	-430	\N	C	2019-12-20 22:14:28.053842+00	3995
1	429	2	-429	body of initial Jomon pottery of type SIV	\N	1	-429	\N	C	2019-12-20 22:14:28.053842+00	3996
1	428	2	-428	body of initial Jomon pottery of type SIV	\N	1	-428	\N	C	2019-12-20 22:14:28.053842+00	3997
1	427	2	-427	body of initial Jomon pottery of type SIV	\N	1	-427	\N	C	2019-12-20 22:14:28.053842+00	3998
1	426	2	-426	body of initial Jomon pottery of type SIV	\N	1	-426	\N	C	2019-12-20 22:14:28.053842+00	3999
1	425	2	-425	body of initial Jomon pottery of type SIV	\N	1	-425	\N	C	2019-12-20 22:14:28.053842+00	4000
1	424	2	-424	body of initial Jomon pottery of type SIV	\N	1	-424	\N	C	2019-12-20 22:14:28.053842+00	4001
1	423	2	-423	body of initial Jomon pottery of type SIV	\N	1	-423	\N	C	2019-12-20 22:14:28.053842+00	4002
1	422	2	-422	body of initial Jomon pottery of type SIV	\N	1	-422	\N	C	2019-12-20 22:14:28.053842+00	4003
1	421	2	-421	body of initial Jomon pottery of type SIV	\N	1	-421	\N	C	2019-12-20 22:14:28.053842+00	4004
1	420	2	-420	body of initial Jomon pottery of type SIV	\N	1	-420	\N	C	2019-12-20 22:14:28.053842+00	4005
1	419	2	-419	body of initial Jomon pottery of type SIV	\N	1	-419	\N	C	2019-12-20 22:14:28.053842+00	4006
1	418	2	-418	body of initial Jomon pottery of type SIV	\N	1	-418	\N	C	2019-12-20 22:14:28.053842+00	4007
1	417	2	-417	body of initial Jomon pottery of type SIV	\N	1	-417	\N	C	2019-12-20 22:14:28.053842+00	4008
1	416	2	-416	body of initial Jomon pottery of type SIV	\N	1	-416	\N	C	2019-12-20 22:14:28.053842+00	4009
1	415	2	-415	body of initial Jomon pottery of type SIV	\N	1	-415	\N	C	2019-12-20 22:14:28.053842+00	4010
1	414	2	-414	body of initial Jomon pottery of type SIV	\N	1	-414	\N	C	2019-12-20 22:14:28.053842+00	4011
1	413	2	-413	body of initial Jomon pottery of type SIV	\N	1	-413	\N	C	2019-12-20 22:14:28.053842+00	4012
1	412	2	-412	body of initial Jomon pottery of type SIV	\N	1	-412	\N	C	2019-12-20 22:14:28.053842+00	4013
1	411	2	-411	body of initial Jomon pottery of type SIV	\N	1	-411	\N	C	2019-12-20 22:14:28.053842+00	4014
1	410	2	-410	body of initial Jomon pottery of type SIV	\N	1	-410	\N	C	2019-12-20 22:14:28.053842+00	4015
1	409	2	-409	body of initial Jomon pottery of type SIV	\N	1	-409	\N	C	2019-12-20 22:14:28.053842+00	4016
1	408	2	-408	body of initial Jomon pottery of type SIV	\N	1	-408	\N	C	2019-12-20 22:14:28.053842+00	4017
1	407	2	-407	body of initial Jomon pottery of type SIV	\N	1	-407	\N	C	2019-12-20 22:14:28.053842+00	4018
1	406	2	-406	body of initial Jomon pottery of type SIV	\N	1	-406	\N	C	2019-12-20 22:14:28.053842+00	4019
1	405	2	-405	body of initial Jomon pottery of type SIV	\N	1	-405	\N	C	2019-12-20 22:14:28.053842+00	4020
1	404	2	-404	body of initial Jomon pottery of type SIV	\N	1	-404	\N	C	2019-12-20 22:14:28.053842+00	4021
1	403	2	-403	body of initial Jomon pottery of type SIV	\N	1	-403	\N	C	2019-12-20 22:14:28.053842+00	4022
1	402	2	-402	body of initial Jomon pottery of type SIV	\N	1	-402	\N	C	2019-12-20 22:14:28.053842+00	4023
1	401	2	-401	body of initial Jomon pottery of type SIV	\N	1	-401	\N	C	2019-12-20 22:14:28.053842+00	4024
1	400	2	-400	body of initial Jomon pottery of type SIV	\N	1	-400	\N	C	2019-12-20 22:14:28.053842+00	4025
1	399	2	-399	body of initial Jomon pottery of type SIV	\N	1	-399	\N	C	2019-12-20 22:14:28.053842+00	4026
1	398	2	-398	body of initial Jomon pottery of type SIV	\N	1	-398	\N	C	2019-12-20 22:14:28.053842+00	4027
1	397	2	-397	rim of initial Jomon pottery of type SIV	\N	1	-397	\N	C	2019-12-20 22:14:28.053842+00	4028
1	396	2	-396	rim of initial Jomon pottery of type SIV	\N	1	-396	\N	C	2019-12-20 22:14:28.053842+00	4029
1	395	2	-395	base of initial Jomon pottery of type SIV	\N	1	-395	\N	C	2019-12-20 22:14:28.053842+00	4030
1	394	2	-394	Lower body of initial Jomon pottery of type SIV	\N	1	-394	\N	C	2019-12-20 22:14:28.053842+00	4031
1	393	2	-393	body of initial Jomon pottery of type SIV	\N	1	-393	\N	C	2019-12-20 22:14:28.053842+00	4032
1	392	2	-392	rim of initial Jomon pottery of type SIV	\N	1	-392	\N	C	2019-12-20 22:14:28.053842+00	4033
1	391	2	-391	rim of initial Jomon pottery of type SIV	\N	1	-391	\N	C	2019-12-20 22:14:28.053842+00	4034
1	390	2	-390	rim of initial Jomon pottery of type SIV	\N	1	-390	\N	C	2019-12-20 22:14:28.053842+00	4035
1	389	2	-389	Lower body of initial Jomon pottery of type SIV	\N	1	-389	\N	C	2019-12-20 22:14:28.053842+00	4036
1	388	2	-388	rim of initial Jomon pottery of type SIV	\N	1	-388	\N	C	2019-12-20 22:14:28.053842+00	4037
1	387	2	-387	body of initial Jomon pottery of type SIV	\N	1	-387	\N	C	2019-12-20 22:14:28.053842+00	4038
1	386	2	-386	body of initial Jomon pottery of type SIV	\N	1	-386	\N	C	2019-12-20 22:14:28.053842+00	4039
1	385	2	-385	rim of initial Jomon pottery of type SIV	\N	1	-385	\N	C	2019-12-20 22:14:28.053842+00	4040
1	384	2	-384	rim of initial Jomon pottery of type SIV	\N	1	-384	\N	C	2019-12-20 22:14:28.053842+00	4041
1	383	2	-383	body of initial Jomon pottery of type SIV	\N	1	-383	\N	C	2019-12-20 22:14:28.053842+00	4042
1	382	2	-382	Lower body of initial Jomon pottery of type SIV	\N	1	-382	\N	C	2019-12-20 22:14:28.053842+00	4043
1	381	2	-381	rim of initial Jomon pottery of type SIV	\N	1	-381	\N	C	2019-12-20 22:14:28.053842+00	4044
1	380	2	-380	rim of initial Jomon pottery of type SIV	\N	1	-380	\N	C	2019-12-20 22:14:28.053842+00	4045
1	379	2	-379	body of initial Jomon pottery of type SIV	\N	1	-379	\N	C	2019-12-20 22:14:28.053842+00	4046
1	378	2	-378	rim of initial Jomon pottery of type SIV	\N	1	-378	\N	C	2019-12-20 22:14:28.053842+00	4047
1	377	2	-377	Lower body of initial Jomon pottery of type SIV	\N	1	-377	\N	C	2019-12-20 22:14:28.053842+00	4048
1	376	2	-376	Lower body of initial Jomon pottery of type SIV	\N	1	-376	\N	C	2019-12-20 22:14:28.053842+00	4049
1	375	2	-375	body of initial Jomon pottery of type SIV	\N	1	-375	\N	C	2019-12-20 22:14:28.053842+00	4050
1	374	2	-374	body of initial Jomon pottery of type SIV	\N	1	-374	\N	C	2019-12-20 22:14:28.053842+00	4051
1	373	2	-373	body of initial Jomon pottery of type SIV	\N	1	-373	\N	C	2019-12-20 22:14:28.053842+00	4052
1	372	2	-372	base of initial Jomon pottery of type SIV	\N	1	-372	\N	C	2019-12-20 22:14:28.053842+00	4053
1	371	2	-371	body of initial Jomon pottery of type SIV	\N	1	-371	\N	C	2019-12-20 22:14:28.053842+00	4054
1	370	2	-370	body of initial Jomon pottery of type SIV	\N	1	-370	\N	C	2019-12-20 22:14:28.053842+00	4055
1	369	2	-369	body of initial Jomon pottery of type SIV	\N	1	-369	\N	C	2019-12-20 22:14:28.053842+00	4056
1	368	2	-368	body of initial Jomon pottery of type SIV	\N	1	-368	\N	C	2019-12-20 22:14:28.053842+00	4057
1	367	2	-367	neck of initial Jomon pottery of type SIV	\N	1	-367	\N	C	2019-12-20 22:14:28.053842+00	4058
1	366	2	-366	neck of initial Jomon pottery of type SIV	\N	1	-366	\N	C	2019-12-20 22:14:28.053842+00	4059
1	365	2	-365	body of initial Jomon pottery of type SIV	\N	1	-365	\N	C	2019-12-20 22:14:28.053842+00	4060
1	364	2	-364	body of initial Jomon pottery of type SIV	\N	1	-364	\N	C	2019-12-20 22:14:28.053842+00	4061
1	363	2	-363	neck of initial Jomon pottery of type SIV	\N	1	-363	\N	C	2019-12-20 22:14:28.053842+00	4062
1	362	2	-362	rim of initial Jomon pottery of type SIV	\N	1	-362	\N	C	2019-12-20 22:14:28.053842+00	4063
1	361	2	-361	neck of initial Jomon pottery of type SIV	\N	1	-361	\N	C	2019-12-20 22:14:28.053842+00	4064
1	360	2	-360	neck of initial Jomon pottery of type SIV	\N	1	-360	\N	C	2019-12-20 22:14:28.053842+00	4065
1	359	2	-359	rim of initial Jomon pottery of type SIV	\N	1	-359	\N	C	2019-12-20 22:14:28.053842+00	4066
1	358	2	-358	neck of initial Jomon pottery of type SIV	\N	1	-358	\N	C	2019-12-20 22:14:28.053842+00	4067
1	357	2	-357	base of initial Jomon pottery of type SIV	\N	1	-357	\N	C	2019-12-20 22:14:28.053842+00	4068
1	356	2	-356	body of initial Jomon pottery of type SIV	\N	1	-356	\N	C	2019-12-20 22:14:28.053842+00	4069
1	355	2	-355	body of initial Jomon pottery of type SIV	\N	1	-355	\N	C	2019-12-20 22:14:28.053842+00	4070
1	354	2	-354	body of initial Jomon pottery of type SIV	\N	1	-354	\N	C	2019-12-20 22:14:28.053842+00	4071
1	353	2	-353	body of initial Jomon pottery of type SIV	\N	1	-353	\N	C	2019-12-20 22:14:28.053842+00	4072
1	352	2	-352	body of initial Jomon pottery of type SIV	\N	1	-352	\N	C	2019-12-20 22:14:28.053842+00	4073
1	351	2	-351	body of initial Jomon pottery of type SIV	\N	1	-351	\N	C	2019-12-20 22:14:28.053842+00	4074
1	47	2	-47	body of initial Jomon pottery of type SIV	\N	1	-47	\N	C	2019-12-20 22:14:28.053842+00	4378
1	46	2	-46	rim of initial Jomon pottery of type SIV	\N	1	-46	\N	C	2019-12-20 22:14:28.053842+00	4379
1	45	2	-45	rim of initial Jomon pottery of type SIV	\N	1	-45	\N	C	2019-12-20 22:14:28.053842+00	4380
1	44	2	-44	rim of initial Jomon pottery of type SIV	\N	1	-44	\N	C	2019-12-20 22:14:28.053842+00	4381
1	43	2	-43	rim of initial Jomon pottery of type SIV	\N	1	-43	\N	C	2019-12-20 22:14:28.053842+00	4382
1	42	2	-42	rim of initial Jomon pottery of type SIV	\N	1	-42	\N	C	2019-12-20 22:14:28.053842+00	4383
1	41	2	-41	rim of initial Jomon pottery of type SIV	\N	1	-41	\N	C	2019-12-20 22:14:28.053842+00	4384
1	40	2	-40	rim of initial Jomon pottery of type SIV	\N	1	-40	\N	C	2019-12-20 22:14:28.053842+00	4385
1	39	2	-39	rim of initial Jomon pottery of type SIV	\N	1	-39	\N	C	2019-12-20 22:14:28.053842+00	4386
1	38	2	-38	rim of initial Jomon pottery of type SIV	\N	1	-38	\N	C	2019-12-20 22:14:28.053842+00	4387
1	37	2	-37	rim of initial Jomon pottery of type SIV	\N	1	-37	\N	C	2019-12-20 22:14:28.053842+00	4388
1	36	2	-36	body of initial Jomon pottery of type SIV	\N	1	-36	\N	C	2019-12-20 22:14:28.053842+00	4389
1	35	2	-35	rim of initial Jomon pottery of type SIV	\N	1	-35	\N	C	2019-12-20 22:14:28.053842+00	4390
1	34	2	-34	rim of initial Jomon pottery of type SIV	\N	1	-34	\N	C	2019-12-20 22:14:28.053842+00	4391
1	33	2	-33	body of initial Jomon pottery of type SIV	\N	1	-33	\N	C	2019-12-20 22:14:28.053842+00	4392
1	32	2	-32	rim of initial Jomon pottery of type SIV	\N	1	-32	\N	C	2019-12-20 22:14:28.053842+00	4393
1	31	2	-31	rim of initial Jomon pottery of type SIV	\N	1	-31	\N	C	2019-12-20 22:14:28.053842+00	4394
1	30	2	-30	rim of initial Jomon pottery of type SIV	\N	1	-30	\N	C	2019-12-20 22:14:28.053842+00	4395
1	29	2	-29	body of initial Jomon pottery of type SIV	\N	1	-29	\N	C	2019-12-20 22:14:28.053842+00	4396
1	28	2	-28	body of initial Jomon pottery of type SIV	\N	1	-28	\N	C	2019-12-20 22:14:28.053842+00	4397
1	27	2	-27	body of incipient Jomon pottery of type SIII	\N	1	-27	\N	C	2019-12-20 22:14:28.053842+00	4398
1	26	2	-26	body of incipient Jomon pottery of type SIII	\N	1	-26	\N	C	2019-12-20 22:14:28.053842+00	4399
1	25	2	-25	body of incipient Jomon pottery of type SIII	\N	1	-25	\N	C	2019-12-20 22:14:28.053842+00	4400
1	350	2	-350	rim of initial Jomon pottery of type SIV	\N	1	-350	\N	C	2019-12-20 22:14:28.053842+00	4075
1	349	2	-349	body of initial Jomon pottery of type SIV	\N	1	-349	\N	C	2019-12-20 22:14:28.053842+00	4076
1	348	2	-348	body of initial Jomon pottery of type SIV	\N	1	-348	\N	C	2019-12-20 22:14:28.053842+00	4077
1	347	2	-347	body of incipient Jomon pottery of type SIII	\N	1	-347	\N	C	2019-12-20 22:14:28.053842+00	4078
1	346	2	-346	body of incipient Jomon pottery of type SIII	\N	1	-346	\N	C	2019-12-20 22:14:28.053842+00	4079
1	345	2	-345	body of incipient Jomon pottery of type SIII	\N	1	-345	\N	C	2019-12-20 22:14:28.053842+00	4080
1	344	2	-344	rim of incipient Jomon pottery of type SIII	\N	1	-344	\N	C	2019-12-20 22:14:28.053842+00	4081
1	343	2	-343	body of incipient Jomon pottery of type SIII	\N	1	-343	\N	C	2019-12-20 22:14:28.053842+00	4082
1	342	2	-342	base of initial Jomon pottery of type SIV	\N	1	-342	\N	C	2019-12-20 22:14:28.053842+00	4083
1	341	2	-341	base of initial Jomon pottery of type SIV	\N	1	-341	\N	C	2019-12-20 22:14:28.053842+00	4084
1	340	2	-340	base of initial Jomon pottery of type SIV	\N	1	-340	\N	C	2019-12-20 22:14:28.053842+00	4085
1	339	2	-339	rim of initial Jomon pottery of type SIV	\N	1	-339	\N	C	2019-12-20 22:14:28.053842+00	4086
1	338	2	-338	body of initial Jomon pottery of type SIV	\N	1	-338	\N	C	2019-12-20 22:14:28.053842+00	4087
1	337	2	-337	body of initial Jomon pottery of type SIV	\N	1	-337	\N	C	2019-12-20 22:14:28.053842+00	4088
1	336	2	-336	body of initial Jomon pottery of type SIV	\N	1	-336	\N	C	2019-12-20 22:14:28.053842+00	4089
1	335	2	-335	body of initial Jomon pottery of type SIV	\N	1	-335	\N	C	2019-12-20 22:14:28.053842+00	4090
1	334	2	-334	body of initial Jomon pottery of type SIV	\N	1	-334	\N	C	2019-12-20 22:14:28.053842+00	4091
1	333	2	-333	body of initial Jomon pottery of type SIV	\N	1	-333	\N	C	2019-12-20 22:14:28.053842+00	4092
1	332	2	-332	body of initial Jomon pottery of type SIV	\N	1	-332	\N	C	2019-12-20 22:14:28.053842+00	4093
1	331	2	-331	body of initial Jomon pottery of type SIV	\N	1	-331	\N	C	2019-12-20 22:14:28.053842+00	4094
1	330	2	-330	rim of initial Jomon pottery of type SIV	\N	1	-330	\N	C	2019-12-20 22:14:28.053842+00	4095
1	329	2	-329	rim of initial Jomon pottery of type SIV	\N	1	-329	\N	C	2019-12-20 22:14:28.053842+00	4096
1	328	2	-328	rim of initial Jomon pottery of type SIV	\N	1	-328	\N	C	2019-12-20 22:14:28.053842+00	4097
1	327	2	-327	rim of initial Jomon pottery of type SIV	\N	1	-327	\N	C	2019-12-20 22:14:28.053842+00	4098
1	326	2	-326	rim of initial Jomon pottery of type SIV	\N	1	-326	\N	C	2019-12-20 22:14:28.053842+00	4099
1	325	2	-325	rim of initial Jomon pottery of type SIV	\N	1	-325	\N	C	2019-12-20 22:14:28.053842+00	4100
1	324	2	-324	rim of initial Jomon pottery of type SIV	\N	1	-324	\N	C	2019-12-20 22:14:28.053842+00	4101
1	306	2	-306	body of initial Jomon pottery of type SIV	\N	1	-306	\N	C	2019-12-20 22:14:28.053842+00	4119
1	305	2	-305	body of initial Jomon pottery of type SIV	\N	1	-305	\N	C	2019-12-20 22:14:28.053842+00	4120
1	304	2	-304	body of initial Jomon pottery of type SIV	\N	1	-304	\N	C	2019-12-20 22:14:28.053842+00	4121
1	303	2	-303	body of initial Jomon pottery of type SIV	\N	1	-303	\N	C	2019-12-20 22:14:28.053842+00	4122
1	302	2	-302	body of initial Jomon pottery of type SIV	\N	1	-302	\N	C	2019-12-20 22:14:28.053842+00	4123
1	301	2	-301	rim of initial Jomon pottery of type SIV	\N	1	-301	\N	C	2019-12-20 22:14:28.053842+00	4124
1	300	2	-300	rim of initial Jomon pottery of type SIV	\N	1	-300	\N	C	2019-12-20 22:14:28.053842+00	4125
1	299	2	-299	rim of initial Jomon pottery of type SIV	\N	1	-299	\N	C	2019-12-20 22:14:28.053842+00	4126
1	298	2	-298	rim of initial Jomon pottery of type SIV	\N	1	-298	\N	C	2019-12-20 22:14:28.053842+00	4127
1	297	2	-297	rim of initial Jomon pottery of type SIV	\N	1	-297	\N	C	2019-12-20 22:14:28.053842+00	4128
1	296	2	-296	rim of initial Jomon pottery of type SIV	\N	1	-296	\N	C	2019-12-20 22:14:28.053842+00	4129
1	295	2	-295	rim of initial Jomon pottery of type SIV	\N	1	-295	\N	C	2019-12-20 22:14:28.053842+00	4130
1	294	2	-294	rim of initial Jomon pottery of type SIV	\N	1	-294	\N	C	2019-12-20 22:14:28.053842+00	4131
1	293	2	-293	rim of initial Jomon pottery of type SIV	\N	1	-293	\N	C	2019-12-20 22:14:28.053842+00	4132
1	292	2	-292	rim of initial Jomon pottery of type SIV	\N	1	-292	\N	C	2019-12-20 22:14:28.053842+00	4133
1	291	2	-291	rim of initial Jomon pottery of type SIV	\N	1	-291	\N	C	2019-12-20 22:14:28.053842+00	4134
1	290	2	-290	rim of initial Jomon pottery of type SIV	\N	1	-290	\N	C	2019-12-20 22:14:28.053842+00	4135
1	289	2	-289	rim of initial Jomon pottery of type SIV	\N	1	-289	\N	C	2019-12-20 22:14:28.053842+00	4136
1	288	2	-288	rim of initial Jomon pottery of type SIV	\N	1	-288	\N	C	2019-12-20 22:14:28.053842+00	4137
1	287	2	-287	rim of initial Jomon pottery of type SIV	\N	1	-287	\N	C	2019-12-20 22:14:28.053842+00	4138
1	286	2	-286	rim of initial Jomon pottery of type SIV	\N	1	-286	\N	C	2019-12-20 22:14:28.053842+00	4139
1	285	2	-285	rim of initial Jomon pottery of type SIV	\N	1	-285	\N	C	2019-12-20 22:14:28.053842+00	4140
1	284	2	-284	rim of initial Jomon pottery of type SIV	\N	1	-284	\N	C	2019-12-20 22:14:28.053842+00	4141
1	283	2	-283	rim of initial Jomon pottery of type SIV	\N	1	-283	\N	C	2019-12-20 22:14:28.053842+00	4142
1	282	2	-282	rim of initial Jomon pottery of type SIV	\N	1	-282	\N	C	2019-12-20 22:14:28.053842+00	4143
1	281	2	-281	rim of initial Jomon pottery of type SIV	\N	1	-281	\N	C	2019-12-20 22:14:28.053842+00	4144
1	280	2	-280	rim of initial Jomon pottery of type SIV	\N	1	-280	\N	C	2019-12-20 22:14:28.053842+00	4145
1	279	2	-279	rim of initial Jomon pottery of type SIV	\N	1	-279	\N	C	2019-12-20 22:14:28.053842+00	4146
1	278	2	-278	rim of initial Jomon pottery of type SIV	\N	1	-278	\N	C	2019-12-20 22:14:28.053842+00	4147
1	277	2	-277	rim of initial Jomon pottery of type SIV	\N	1	-277	\N	C	2019-12-20 22:14:28.053842+00	4148
1	276	2	-276	rim of initial Jomon pottery of type SIV	\N	1	-276	\N	C	2019-12-20 22:14:28.053842+00	4149
1	275	2	-275	rim of initial Jomon pottery of type SIV	\N	1	-275	\N	C	2019-12-20 22:14:28.053842+00	4150
1	274	2	-274	rim of initial Jomon pottery of type SIV	\N	1	-274	\N	C	2019-12-20 22:14:28.053842+00	4151
1	273	2	-273	rim of initial Jomon pottery of type SIV	\N	1	-273	\N	C	2019-12-20 22:14:28.053842+00	4152
1	272	2	-272	rim of initial Jomon pottery of type SIV	\N	1	-272	\N	C	2019-12-20 22:14:28.053842+00	4153
1	271	2	-271	rim of initial Jomon pottery of type SIV	\N	1	-271	\N	C	2019-12-20 22:14:28.053842+00	4154
1	270	2	-270	rim of initial Jomon pottery of type SIV	\N	1	-270	\N	C	2019-12-20 22:14:28.053842+00	4155
1	269	2	-269	rim of initial Jomon pottery of type SIV	\N	1	-269	\N	C	2019-12-20 22:14:28.053842+00	4156
1	268	2	-268	rim of initial Jomon pottery of type SIV	\N	1	-268	\N	C	2019-12-20 22:14:28.053842+00	4157
1	267	2	-267	rim of initial Jomon pottery of type SIV	\N	1	-267	\N	C	2019-12-20 22:14:28.053842+00	4158
1	266	2	-266	rim of initial Jomon pottery of type SIV	\N	1	-266	\N	C	2019-12-20 22:14:28.053842+00	4159
1	265	2	-265	rim of initial Jomon pottery of type SIV	\N	1	-265	\N	C	2019-12-20 22:14:28.053842+00	4160
1	264	2	-264	rim of initial Jomon pottery of type SIV	\N	1	-264	\N	C	2019-12-20 22:14:28.053842+00	4161
1	263	2	-263	rim of initial Jomon pottery of type SIV	\N	1	-263	\N	C	2019-12-20 22:14:28.053842+00	4162
1	262	2	-262	rim of initial Jomon pottery of type SIV	\N	1	-262	\N	C	2019-12-20 22:14:28.053842+00	4163
1	261	2	-261	rim of initial Jomon pottery of type SIV	\N	1	-261	\N	C	2019-12-20 22:14:28.053842+00	4164
1	260	2	-260	rim of initial Jomon pottery of type SIV	\N	1	-260	\N	C	2019-12-20 22:14:28.053842+00	4165
1	259	2	-259	rim of initial Jomon pottery of type SIV	\N	1	-259	\N	C	2019-12-20 22:14:28.053842+00	4166
1	258	2	-258	body of incipient Jomon pottery of type SIII	\N	1	-258	\N	C	2019-12-20 22:14:28.053842+00	4167
1	257	2	-257	body of incipient Jomon pottery of type SIII	\N	1	-257	\N	C	2019-12-20 22:14:28.053842+00	4168
1	256	2	-256	body of incipient Jomon pottery of type SIII	\N	1	-256	\N	C	2019-12-20 22:14:28.053842+00	4169
1	255	2	-255	body of incipient Jomon pottery of type SIII	\N	1	-255	\N	C	2019-12-20 22:14:28.053842+00	4170
1	254	2	-254	body of incipient Jomon pottery of type SIII	\N	1	-254	\N	C	2019-12-20 22:14:28.053842+00	4171
1	253	2	-253	body of incipient Jomon pottery of type SIII	\N	1	-253	\N	C	2019-12-20 22:14:28.053842+00	4172
1	252	2	-252	body of incipient Jomon pottery of type SIII	\N	1	-252	\N	C	2019-12-20 22:14:28.053842+00	4173
1	251	2	-251	body of incipient Jomon pottery of type SIII	\N	1	-251	\N	C	2019-12-20 22:14:28.053842+00	4174
1	250	2	-250	body of incipient Jomon pottery of type SIII	\N	1	-250	\N	C	2019-12-20 22:14:28.053842+00	4175
1	249	2	-249	body of incipient Jomon pottery of type SIII	\N	1	-249	\N	C	2019-12-20 22:14:28.053842+00	4176
1	248	2	-248	body of incipient Jomon pottery of type SIII	\N	1	-248	\N	C	2019-12-20 22:14:28.053842+00	4177
1	247	2	-247	body of incipient Jomon pottery of type SIII	\N	1	-247	\N	C	2019-12-20 22:14:28.053842+00	4178
1	246	2	-246	body of incipient Jomon pottery of type SIII	\N	1	-246	\N	C	2019-12-20 22:14:28.053842+00	4179
1	245	2	-245	body of incipient Jomon pottery of type SIII	\N	1	-245	\N	C	2019-12-20 22:14:28.053842+00	4180
1	244	2	-244	body of incipient Jomon pottery of type SIII	\N	1	-244	\N	C	2019-12-20 22:14:28.053842+00	4181
1	243	2	-243	body of incipient Jomon pottery of type SIII	\N	1	-243	\N	C	2019-12-20 22:14:28.053842+00	4182
1	242	2	-242	body of incipient Jomon pottery of type SIII	\N	1	-242	\N	C	2019-12-20 22:14:28.053842+00	4183
1	241	2	-241	body of incipient Jomon pottery of type SIII	\N	1	-241	\N	C	2019-12-20 22:14:28.053842+00	4184
1	240	2	-240	body of incipient Jomon pottery of type SIII	\N	1	-240	\N	C	2019-12-20 22:14:28.053842+00	4185
1	239	2	-239	rim of incipient Jomon pottery of type SIII	\N	1	-239	\N	C	2019-12-20 22:14:28.053842+00	4186
1	238	2	-238	body of incipient Jomon pottery of type SIII	\N	1	-238	\N	C	2019-12-20 22:14:28.053842+00	4187
1	237	2	-237	body of incipient Jomon pottery of type SIII	\N	1	-237	\N	C	2019-12-20 22:14:28.053842+00	4188
1	236	2	-236	body of incipient Jomon pottery of type SIII	\N	1	-236	\N	C	2019-12-20 22:14:28.053842+00	4189
1	235	2	-235	body of incipient Jomon pottery of type SIII	\N	1	-235	\N	C	2019-12-20 22:14:28.053842+00	4190
1	234	2	-234	rim of incipient Jomon pottery of type SIII	\N	1	-234	\N	C	2019-12-20 22:14:28.053842+00	4191
1	233	2	-233	body of incipient Jomon pottery of type SIII	\N	1	-233	\N	C	2019-12-20 22:14:28.053842+00	4192
1	232	2	-232	body of incipient Jomon pottery of type SIII	\N	1	-232	\N	C	2019-12-20 22:14:28.053842+00	4193
1	231	2	-231	body of incipient Jomon pottery of type SIII	\N	1	-231	\N	C	2019-12-20 22:14:28.053842+00	4194
1	230	2	-230	body of initial Jomon pottery of type SIV	\N	1	-230	\N	C	2019-12-20 22:14:28.053842+00	4195
1	229	2	-229	body of initial Jomon pottery of type SIV	\N	1	-229	\N	C	2019-12-20 22:14:28.053842+00	4196
1	228	2	-228	body of initial Jomon pottery of type SIV	\N	1	-228	\N	C	2019-12-20 22:14:28.053842+00	4197
1	227	2	-227	body of initial Jomon pottery of type SIV	\N	1	-227	\N	C	2019-12-20 22:14:28.053842+00	4198
1	226	2	-226	body of initial Jomon pottery of type SIV	\N	1	-226	\N	C	2019-12-20 22:14:28.053842+00	4199
1	225	2	-225	body of initial Jomon pottery of type SIV	\N	1	-225	\N	C	2019-12-20 22:14:28.053842+00	4200
1	224	2	-224	body of initial Jomon pottery of type SIV	\N	1	-224	\N	C	2019-12-20 22:14:28.053842+00	4201
1	223	2	-223	body of initial Jomon pottery of type SIV	\N	1	-223	\N	C	2019-12-20 22:14:28.053842+00	4202
1	222	2	-222	body of initial Jomon pottery of type SIV	\N	1	-222	\N	C	2019-12-20 22:14:28.053842+00	4203
1	221	2	-221	body of initial Jomon pottery of type SIV	\N	1	-221	\N	C	2019-12-20 22:14:28.053842+00	4204
1	220	2	-220	body of initial Jomon pottery of type SIV	\N	1	-220	\N	C	2019-12-20 22:14:28.053842+00	4205
1	219	2	-219	body of initial Jomon pottery of type SIV	\N	1	-219	\N	C	2019-12-20 22:14:28.053842+00	4206
1	218	2	-218	body of initial Jomon pottery of type SIV	\N	1	-218	\N	C	2019-12-20 22:14:28.053842+00	4207
1	217	2	-217	body of initial Jomon pottery of type SIV	\N	1	-217	\N	C	2019-12-20 22:14:28.053842+00	4208
1	216	2	-216	body of initial Jomon pottery of type SIV	\N	1	-216	\N	C	2019-12-20 22:14:28.053842+00	4209
1	215	2	-215	body of initial Jomon pottery of type SIV	\N	1	-215	\N	C	2019-12-20 22:14:28.053842+00	4210
1	214	2	-214	body of initial Jomon pottery of type SIV	\N	1	-214	\N	C	2019-12-20 22:14:28.053842+00	4211
1	213	2	-213	body of initial Jomon pottery of type SIV	\N	1	-213	\N	C	2019-12-20 22:14:28.053842+00	4212
1	212	2	-212	body of initial Jomon pottery of type SIV	\N	1	-212	\N	C	2019-12-20 22:14:28.053842+00	4213
1	211	2	-211	body of initial Jomon pottery of type SIV	\N	1	-211	\N	C	2019-12-20 22:14:28.053842+00	4214
1	210	2	-210	body of initial Jomon pottery of type SIV	\N	1	-210	\N	C	2019-12-20 22:14:28.053842+00	4215
1	209	2	-209	body of initial Jomon pottery of type SIV	\N	1	-209	\N	C	2019-12-20 22:14:28.053842+00	4216
1	208	2	-208	body of initial Jomon pottery of type SIV	\N	1	-208	\N	C	2019-12-20 22:14:28.053842+00	4217
1	207	2	-207	body of initial Jomon pottery of type SIV	\N	1	-207	\N	C	2019-12-20 22:14:28.053842+00	4218
1	206	2	-206	body of initial Jomon pottery of type SIV	\N	1	-206	\N	C	2019-12-20 22:14:28.053842+00	4219
1	205	2	-205	body of initial Jomon pottery of type SIV	\N	1	-205	\N	C	2019-12-20 22:14:28.053842+00	4220
1	204	2	-204	body of initial Jomon pottery of type SIV	\N	1	-204	\N	C	2019-12-20 22:14:28.053842+00	4221
1	203	2	-203	body of initial Jomon pottery of type SIV	\N	1	-203	\N	C	2019-12-20 22:14:28.053842+00	4222
1	202	2	-202	body of initial Jomon pottery of type SIV	\N	1	-202	\N	C	2019-12-20 22:14:28.053842+00	4223
1	201	2	-201	body of initial Jomon pottery of type SIV	\N	1	-201	\N	C	2019-12-20 22:14:28.053842+00	4224
1	200	2	-200	body of initial Jomon pottery of type SIV	\N	1	-200	\N	C	2019-12-20 22:14:28.053842+00	4225
1	199	2	-199	body of initial Jomon pottery of type SIV	\N	1	-199	\N	C	2019-12-20 22:14:28.053842+00	4226
1	198	2	-198	rim of initial Jomon pottery of type SIV	\N	1	-198	\N	C	2019-12-20 22:14:28.053842+00	4227
1	197	2	-197	rim of initial Jomon pottery of type SIV	\N	1	-197	\N	C	2019-12-20 22:14:28.053842+00	4228
1	196	2	-196	rim of incipient Jomon pottery of type SIII	\N	1	-196	\N	C	2019-12-20 22:14:28.053842+00	4229
1	195	2	-195	body of incipient Jomon pottery of type SIII	\N	1	-195	\N	C	2019-12-20 22:14:28.053842+00	4230
1	194	2	-194	body of incipient Jomon pottery of type SIII	\N	1	-194	\N	C	2019-12-20 22:14:28.053842+00	4231
1	193	2	-193	body of incipient Jomon pottery of type SIII	\N	1	-193	\N	C	2019-12-20 22:14:28.053842+00	4232
1	192	2	-192	body of incipient Jomon pottery of type SIII	\N	1	-192	\N	C	2019-12-20 22:14:28.053842+00	4233
1	191	2	-191	body of incipient Jomon pottery of type SIII	\N	1	-191	\N	C	2019-12-20 22:14:28.053842+00	4234
1	190	2	-190	body of incipient Jomon pottery of type SIII	\N	1	-190	\N	C	2019-12-20 22:14:28.053842+00	4235
1	189	2	-189	body of incipient Jomon pottery of type SIII	\N	1	-189	\N	C	2019-12-20 22:14:28.053842+00	4236
1	188	2	-188	body of incipient Jomon pottery of type SIII	\N	1	-188	\N	C	2019-12-20 22:14:28.053842+00	4237
1	187	2	-187	rim of incipient Jomon pottery of type SIII	\N	1	-187	\N	C	2019-12-20 22:14:28.053842+00	4238
1	186	2	-186	rim of incipient Jomon pottery of type SIII	\N	1	-186	\N	C	2019-12-20 22:14:28.053842+00	4239
1	185	2	-185	rim of incipient Jomon pottery of type SIII	\N	1	-185	\N	C	2019-12-20 22:14:28.053842+00	4240
1	184	2	-184	rim of incipient Jomon pottery of type SIII	\N	1	-184	\N	C	2019-12-20 22:14:28.053842+00	4241
1	183	2	-183	rim of incipient Jomon pottery of type SIII	\N	1	-183	\N	C	2019-12-20 22:14:28.053842+00	4242
1	182	2	-182	rim of incipient Jomon pottery of type SIII	\N	1	-182	\N	C	2019-12-20 22:14:28.053842+00	4243
1	181	2	-181	body of initial Jomon pottery of type SIV	\N	1	-181	\N	C	2019-12-20 22:14:28.053842+00	4244
1	180	2	-180	body of initial Jomon pottery of type SIV	\N	1	-180	\N	C	2019-12-20 22:14:28.053842+00	4245
1	179	2	-179	body of initial Jomon pottery of type SIV	\N	1	-179	\N	C	2019-12-20 22:14:28.053842+00	4246
1	178	2	-178	body of initial Jomon pottery of type SIV	\N	1	-178	\N	C	2019-12-20 22:14:28.053842+00	4247
1	177	2	-177	body of initial Jomon pottery of type SIV	\N	1	-177	\N	C	2019-12-20 22:14:28.053842+00	4248
1	176	2	-176	body of initial Jomon pottery of type SIV	\N	1	-176	\N	C	2019-12-20 22:14:28.053842+00	4249
1	175	2	-175	body of initial Jomon pottery of type SIV	\N	1	-175	\N	C	2019-12-20 22:14:28.053842+00	4250
1	174	2	-174	body of initial Jomon pottery of type SIV	\N	1	-174	\N	C	2019-12-20 22:14:28.053842+00	4251
1	173	2	-173	rim of initial Jomon pottery of type SIV	\N	1	-173	\N	C	2019-12-20 22:14:28.053842+00	4252
1	172	2	-172	body of initial Jomon pottery of type SIV	\N	1	-172	\N	C	2019-12-20 22:14:28.053842+00	4253
1	171	2	-171	body of initial Jomon pottery of type SIV	\N	1	-171	\N	C	2019-12-20 22:14:28.053842+00	4254
1	170	2	-170	body of initial Jomon pottery of type SIV	\N	1	-170	\N	C	2019-12-20 22:14:28.053842+00	4255
1	169	2	-169	body of initial Jomon pottery of type SIV	\N	1	-169	\N	C	2019-12-20 22:14:28.053842+00	4256
1	168	2	-168	body of initial Jomon pottery of type SIV	\N	1	-168	\N	C	2019-12-20 22:14:28.053842+00	4257
1	167	2	-167	rim of initial Jomon pottery of type SIV	\N	1	-167	\N	C	2019-12-20 22:14:28.053842+00	4258
1	166	2	-166	rim of initial Jomon pottery of type SIV	\N	1	-166	\N	C	2019-12-20 22:14:28.053842+00	4259
1	165	2	-165	rim of initial Jomon pottery of type SIV	\N	1	-165	\N	C	2019-12-20 22:14:28.053842+00	4260
1	164	2	-164	rim of initial Jomon pottery of type SIV	\N	1	-164	\N	C	2019-12-20 22:14:28.053842+00	4261
1	163	2	-163	rim of initial Jomon pottery of type SIV	\N	1	-163	\N	C	2019-12-20 22:14:28.053842+00	4262
1	162	2	-162	rim of initial Jomon pottery of type SIV	\N	1	-162	\N	C	2019-12-20 22:14:28.053842+00	4263
1	161	2	-161	rim of initial Jomon pottery of type SIV	\N	1	-161	\N	C	2019-12-20 22:14:28.053842+00	4264
1	160	2	-160	rim of initial Jomon pottery of type SIV	\N	1	-160	\N	C	2019-12-20 22:14:28.053842+00	4265
1	159	2	-159	rim of initial Jomon pottery of type SIV	\N	1	-159	\N	C	2019-12-20 22:14:28.053842+00	4266
1	158	2	-158	body of initial Jomon pottery of type SIV	\N	1	-158	\N	C	2019-12-20 22:14:28.053842+00	4267
1	157	2	-157	rim of initial Jomon pottery of type SIV	\N	1	-157	\N	C	2019-12-20 22:14:28.053842+00	4268
1	156	2	-156	body of initial Jomon pottery of type SIV	\N	1	-156	\N	C	2019-12-20 22:14:28.053842+00	4269
1	155	2	-155	body of initial Jomon pottery of type SIV	\N	1	-155	\N	C	2019-12-20 22:14:28.053842+00	4270
1	154	2	-154	body of initial Jomon pottery of type SIV	\N	1	-154	\N	C	2019-12-20 22:14:28.053842+00	4271
1	153	2	-153	body of initial Jomon pottery of type SIV	\N	1	-153	\N	C	2019-12-20 22:14:28.053842+00	4272
1	152	2	-152	body of initial Jomon pottery of type SIV	\N	1	-152	\N	C	2019-12-20 22:14:28.053842+00	4273
1	151	2	-151	body of initial Jomon pottery of type SIV	\N	1	-151	\N	C	2019-12-20 22:14:28.053842+00	4274
1	150	2	-150	body of initial Jomon pottery of type SIV	\N	1	-150	\N	C	2019-12-20 22:14:28.053842+00	4275
1	149	2	-149	body of initial Jomon pottery of type SIV	\N	1	-149	\N	C	2019-12-20 22:14:28.053842+00	4276
1	148	2	-148	body of initial Jomon pottery of type SIV	\N	1	-148	\N	C	2019-12-20 22:14:28.053842+00	4277
1	147	2	-147	body of initial Jomon pottery of type SIV	\N	1	-147	\N	C	2019-12-20 22:14:28.053842+00	4278
1	146	2	-146	body of initial Jomon pottery of type SIV	\N	1	-146	\N	C	2019-12-20 22:14:28.053842+00	4279
1	145	2	-145	rim of initial Jomon pottery of type SIV	\N	1	-145	\N	C	2019-12-20 22:14:28.053842+00	4280
1	144	2	-144	body of initial Jomon pottery of type SIV	\N	1	-144	\N	C	2019-12-20 22:14:28.053842+00	4281
1	143	2	-143	body of initial Jomon pottery of type SIV	\N	1	-143	\N	C	2019-12-20 22:14:28.053842+00	4282
1	142	2	-142	body of initial Jomon pottery of type SIV	\N	1	-142	\N	C	2019-12-20 22:14:28.053842+00	4283
1	141	2	-141	rim of initial Jomon pottery of type SIV	\N	1	-141	\N	C	2019-12-20 22:14:28.053842+00	4284
1	140	2	-140	body of initial Jomon pottery of type SIV	\N	1	-140	\N	C	2019-12-20 22:14:28.053842+00	4285
1	139	2	-139	body of initial Jomon pottery of type SIV	\N	1	-139	\N	C	2019-12-20 22:14:28.053842+00	4286
1	138	2	-138	body of incipient Jomon pottery of type SIII	\N	1	-138	\N	C	2019-12-20 22:14:28.053842+00	4287
1	137	2	-137	body of incipient Jomon pottery of type SIII	\N	1	-137	\N	C	2019-12-20 22:14:28.053842+00	4288
1	136	2	-136	rim of incipient Jomon pottery of type SIII	\N	1	-136	\N	C	2019-12-20 22:14:28.053842+00	4289
1	135	2	-135	rim of incipient Jomon pottery of type SIII	\N	1	-135	\N	C	2019-12-20 22:14:28.053842+00	4290
1	134	2	-134	body of incipient Jomon pottery of type SIII	\N	1	-134	\N	C	2019-12-20 22:14:28.053842+00	4291
1	133	2	-133	body of incipient Jomon pottery of type SIII	\N	1	-133	\N	C	2019-12-20 22:14:28.053842+00	4292
1	132	2	-132	body of incipient Jomon pottery of type SIII	\N	1	-132	\N	C	2019-12-20 22:14:28.053842+00	4293
1	131	2	-131	body of incipient Jomon pottery of type SIII	\N	1	-131	\N	C	2019-12-20 22:14:28.053842+00	4294
1	130	2	-130	body of incipient Jomon pottery of type SIII	\N	1	-130	\N	C	2019-12-20 22:14:28.053842+00	4295
1	129	2	-129	body of incipient Jomon pottery of type SIII	\N	1	-129	\N	C	2019-12-20 22:14:28.053842+00	4296
1	128	2	-128	body of incipient Jomon pottery of type SIII	\N	1	-128	\N	C	2019-12-20 22:14:28.053842+00	4297
1	127	2	-127	rim of incipient Jomon pottery of type SIII	\N	1	-127	\N	C	2019-12-20 22:14:28.053842+00	4298
1	126	2	-126	body of incipient Jomon pottery of type SIII	\N	1	-126	\N	C	2019-12-20 22:14:28.053842+00	4299
1	125	2	-125	body of incipient Jomon pottery of type SIII	\N	1	-125	\N	C	2019-12-20 22:14:28.053842+00	4300
1	124	2	-124	body of incipient Jomon pottery of type SIII	\N	1	-124	\N	C	2019-12-20 22:14:28.053842+00	4301
1	123	2	-123	rim of incipient Jomon pottery of type SIII	\N	1	-123	\N	C	2019-12-20 22:14:28.053842+00	4302
1	122	2	-122	body of incipient Jomon pottery of type SIII	\N	1	-122	\N	C	2019-12-20 22:14:28.053842+00	4303
1	121	2	-121	body of incipient Jomon pottery of type SIII	\N	1	-121	\N	C	2019-12-20 22:14:28.053842+00	4304
1	120	2	-120	body of incipient Jomon pottery of type SIII	\N	1	-120	\N	C	2019-12-20 22:14:28.053842+00	4305
1	119	2	-119	rim of incipient Jomon pottery of type SIII	\N	1	-119	\N	C	2019-12-20 22:14:28.053842+00	4306
1	118	2	-118	rim of incipient Jomon pottery of type SIII	\N	1	-118	\N	C	2019-12-20 22:14:28.053842+00	4307
1	117	2	-117	rim of initial Jomon pottery of type SIV	\N	1	-117	\N	C	2019-12-20 22:14:28.053842+00	4308
1	116	2	-116	body of initial Jomon pottery of type SIV	\N	1	-116	\N	C	2019-12-20 22:14:28.053842+00	4309
1	115	2	-115	body of initial Jomon pottery of type SIV	\N	1	-115	\N	C	2019-12-20 22:14:28.053842+00	4310
1	114	2	-114	body of initial Jomon pottery of type SIV	\N	1	-114	\N	C	2019-12-20 22:14:28.053842+00	4311
1	113	2	-113	body of initial Jomon pottery of type SIV	\N	1	-113	\N	C	2019-12-20 22:14:28.053842+00	4312
1	112	2	-112	body of initial Jomon pottery of type SIV	\N	1	-112	\N	C	2019-12-20 22:14:28.053842+00	4313
1	111	2	-111	body of initial Jomon pottery of type SIV	\N	1	-111	\N	C	2019-12-20 22:14:28.053842+00	4314
1	110	2	-110	body of initial Jomon pottery of type SIV	\N	1	-110	\N	C	2019-12-20 22:14:28.053842+00	4315
1	109	2	-109	body of initial Jomon pottery of type SIV	\N	1	-109	\N	C	2019-12-20 22:14:28.053842+00	4316
1	108	2	-108	body of initial Jomon pottery of type SIV	\N	1	-108	\N	C	2019-12-20 22:14:28.053842+00	4317
1	107	2	-107	body of initial Jomon pottery of type SIV	\N	1	-107	\N	C	2019-12-20 22:14:28.053842+00	4318
1	106	2	-106	body of initial Jomon pottery of type SIV	\N	1	-106	\N	C	2019-12-20 22:14:28.053842+00	4319
1	105	2	-105	body of initial Jomon pottery of type SIV	\N	1	-105	\N	C	2019-12-20 22:14:28.053842+00	4320
1	104	2	-104	body of initial Jomon pottery of type SIV	\N	1	-104	\N	C	2019-12-20 22:14:28.053842+00	4321
1	103	2	-103	body of initial Jomon pottery of type SIV	\N	1	-103	\N	C	2019-12-20 22:14:28.053842+00	4322
1	102	2	-102	body of initial Jomon pottery of type SIV	\N	1	-102	\N	C	2019-12-20 22:14:28.053842+00	4323
1	101	2	-101	body of initial Jomon pottery of type SIV	\N	1	-101	\N	C	2019-12-20 22:14:28.053842+00	4324
1	100	2	-100	body of initial Jomon pottery of type SIV	\N	1	-100	\N	C	2019-12-20 22:14:28.053842+00	4325
1	99	2	-99	body of initial Jomon pottery of type SIV	\N	1	-99	\N	C	2019-12-20 22:14:28.053842+00	4326
1	98	2	-98	body of initial Jomon pottery of type SIV	\N	1	-98	\N	C	2019-12-20 22:14:28.053842+00	4327
1	97	2	-97	body of initial Jomon pottery of type SIV	\N	1	-97	\N	C	2019-12-20 22:14:28.053842+00	4328
1	96	2	-96	body of initial Jomon pottery of type SIV	\N	1	-96	\N	C	2019-12-20 22:14:28.053842+00	4329
1	95	2	-95	body of initial Jomon pottery of type SIV	\N	1	-95	\N	C	2019-12-20 22:14:28.053842+00	4330
1	94	2	-94	body of initial Jomon pottery of type SIV	\N	1	-94	\N	C	2019-12-20 22:14:28.053842+00	4331
1	93	2	-93	body of initial Jomon pottery of type SIV	\N	1	-93	\N	C	2019-12-20 22:14:28.053842+00	4332
1	92	2	-92	body of initial Jomon pottery of type SIV	\N	1	-92	\N	C	2019-12-20 22:14:28.053842+00	4333
1	91	2	-91	body of initial Jomon pottery of type SIV	\N	1	-91	\N	C	2019-12-20 22:14:28.053842+00	4334
1	90	2	-90	body of initial Jomon pottery of type SIV	\N	1	-90	\N	C	2019-12-20 22:14:28.053842+00	4335
1	89	2	-89	body of initial Jomon pottery of type SIV	\N	1	-89	\N	C	2019-12-20 22:14:28.053842+00	4336
1	88	2	-88	body of initial Jomon pottery of type SIV	\N	1	-88	\N	C	2019-12-20 22:14:28.053842+00	4337
1	87	2	-87	body of initial Jomon pottery of type SIV	\N	1	-87	\N	C	2019-12-20 22:14:28.053842+00	4338
1	86	2	-86	body of initial Jomon pottery of type SIV	\N	1	-86	\N	C	2019-12-20 22:14:28.053842+00	4339
1	85	2	-85	rim of initial Jomon pottery of type SIV	\N	1	-85	\N	C	2019-12-20 22:14:28.053842+00	4340
1	84	2	-84	rim of initial Jomon pottery of type SIV	\N	1	-84	\N	C	2019-12-20 22:14:28.053842+00	4341
1	83	2	-83	rim of initial Jomon pottery of type SIV	\N	1	-83	\N	C	2019-12-20 22:14:28.053842+00	4342
1	82	2	-82	rim of initial Jomon pottery of type SIV	\N	1	-82	\N	C	2019-12-20 22:14:28.053842+00	4343
1	81	2	-81	rim of initial Jomon pottery of type SIV	\N	1	-81	\N	C	2019-12-20 22:14:28.053842+00	4344
1	80	2	-80	body of initial Jomon pottery of type SIV	\N	1	-80	\N	C	2019-12-20 22:14:28.053842+00	4345
1	79	2	-79	rim of initial Jomon pottery of type SIV	\N	1	-79	\N	C	2019-12-20 22:14:28.053842+00	4346
1	78	2	-78	rim of initial Jomon pottery of type SIV	\N	1	-78	\N	C	2019-12-20 22:14:28.053842+00	4347
1	77	2	-77	body of initial Jomon pottery of type SIV	\N	1	-77	\N	C	2019-12-20 22:14:28.053842+00	4348
1	76	2	-76	body of initial Jomon pottery of type SIV	\N	1	-76	\N	C	2019-12-20 22:14:28.053842+00	4349
1	75	2	-75	body of initial Jomon pottery of type SIV	\N	1	-75	\N	C	2019-12-20 22:14:28.053842+00	4350
1	74	2	-74	body of initial Jomon pottery of type SIV	\N	1	-74	\N	C	2019-12-20 22:14:28.053842+00	4351
1	73	2	-73	body of initial Jomon pottery of type SIV	\N	1	-73	\N	C	2019-12-20 22:14:28.053842+00	4352
1	72	2	-72	body of initial Jomon pottery of type SIV	\N	1	-72	\N	C	2019-12-20 22:14:28.053842+00	4353
1	71	2	-71	body of initial Jomon pottery of type SIV	\N	1	-71	\N	C	2019-12-20 22:14:28.053842+00	4354
1	70	2	-70	body of initial Jomon pottery of type SIV	\N	1	-70	\N	C	2019-12-20 22:14:28.053842+00	4355
1	69	2	-69	body of initial Jomon pottery of type SIV	\N	1	-69	\N	C	2019-12-20 22:14:28.053842+00	4356
1	68	2	-68	rim of initial Jomon pottery of type SIV	\N	1	-68	\N	C	2019-12-20 22:14:28.053842+00	4357
1	67	2	-67	rim of initial Jomon pottery of type SIV	\N	1	-67	\N	C	2019-12-20 22:14:28.053842+00	4358
1	66	2	-66	body of initial Jomon pottery of type SIV	\N	1	-66	\N	C	2019-12-20 22:14:28.053842+00	4359
1	65	2	-65	body of initial Jomon pottery of type SIV	\N	1	-65	\N	C	2019-12-20 22:14:28.053842+00	4360
1	64	2	-64	rim of initial Jomon pottery of type SIV	\N	1	-64	\N	C	2019-12-20 22:14:28.053842+00	4361
1	63	2	-63	rim of initial Jomon pottery of type SIV	\N	1	-63	\N	C	2019-12-20 22:14:28.053842+00	4362
1	62	2	-62	rim of initial Jomon pottery of type SIV	\N	1	-62	\N	C	2019-12-20 22:14:28.053842+00	4363
1	61	2	-61	rim of initial Jomon pottery of type SIV	\N	1	-61	\N	C	2019-12-20 22:14:28.053842+00	4364
1	60	2	-60	rim of initial Jomon pottery of type SIV	\N	1	-60	\N	C	2019-12-20 22:14:28.053842+00	4365
1	59	2	-59	rim of initial Jomon pottery of type SIV	\N	1	-59	\N	C	2019-12-20 22:14:28.053842+00	4366
1	58	2	-58	body of initial Jomon pottery of type SIV	\N	1	-58	\N	C	2019-12-20 22:14:28.053842+00	4367
1	57	2	-57	rim of initial Jomon pottery of type SIV	\N	1	-57	\N	C	2019-12-20 22:14:28.053842+00	4368
1	56	2	-56	rim of initial Jomon pottery of type SIV	\N	1	-56	\N	C	2019-12-20 22:14:28.053842+00	4369
1	55	2	-55	body of initial Jomon pottery of type SIV	\N	1	-55	\N	C	2019-12-20 22:14:28.053842+00	4370
1	54	2	-54	rim of initial Jomon pottery of type SIV	\N	1	-54	\N	C	2019-12-20 22:14:28.053842+00	4371
1	53	2	-53	rim of initial Jomon pottery of type SIV	\N	1	-53	\N	C	2019-12-20 22:14:28.053842+00	4372
1	52	2	-52	rim of initial Jomon pottery of type SIV	\N	1	-52	\N	C	2019-12-20 22:14:28.053842+00	4373
1	51	2	-51	rim of initial Jomon pottery of type SIV	\N	1	-51	\N	C	2019-12-20 22:14:28.053842+00	4374
1	50	2	-50	rim of initial Jomon pottery of type SIV	\N	1	-50	\N	C	2019-12-20 22:14:28.053842+00	4375
1	49	2	-49	rim of initial Jomon pottery of type SIV	\N	1	-49	\N	C	2019-12-20 22:14:28.053842+00	4376
1	48	2	-48	rim of initial Jomon pottery of type SIV	\N	1	-48	\N	C	2019-12-20 22:14:28.053842+00	4377
1	24	2	-24	body of incipient Jomon pottery of type SIII	\N	1	-24	\N	C	2019-12-20 22:14:28.053842+00	4401
1	23	2	-23	body of incipient Jomon pottery of type SIII	\N	1	-23	\N	C	2019-12-20 22:14:28.053842+00	4402
1	22	2	-22	body of incipient Jomon pottery of type SIII	\N	1	-22	\N	C	2019-12-20 22:14:28.053842+00	4403
1	21	2	-21	body of incipient Jomon pottery of type SIII	\N	1	-21	\N	C	2019-12-20 22:14:28.053842+00	4404
1	20	2	-20	body of incipient Jomon pottery of type SIII	\N	1	-20	\N	C	2019-12-20 22:14:28.053842+00	4405
1	19	2	-19	body of incipient Jomon pottery of type SIII	\N	1	-19	\N	C	2019-12-20 22:14:28.053842+00	4406
1	18	2	-18	body of incipient Jomon pottery of type SIII	\N	1	-18	\N	C	2019-12-20 22:14:28.053842+00	4407
1	17	2	-17	body of incipient Jomon pottery of type SIII	\N	1	-17	\N	C	2019-12-20 22:14:28.053842+00	4408
1	16	2	-16	body of incipient Jomon pottery of type SIII	\N	1	-16	\N	C	2019-12-20 22:14:28.053842+00	4409
1	15	2	-15	body of incipient Jomon pottery of type SIII	\N	1	-15	\N	C	2019-12-20 22:14:28.053842+00	4410
1	14	2	-14	body of incipient Jomon pottery of type SIII	\N	1	-14	\N	C	2019-12-20 22:14:28.053842+00	4411
1	13	2	-13	body of incipient Jomon pottery of type SIII	\N	1	-13	\N	C	2019-12-20 22:14:28.053842+00	4412
1	12	2	-12	body of incipient Jomon pottery of type SIII	\N	1	-12	\N	C	2019-12-20 22:14:28.053842+00	4413
1	11	2	-11	body of incipient Jomon pottery of type SIII	\N	1	-11	\N	C	2019-12-20 22:14:28.053842+00	4414
1	10	2	-10	body of incipient Jomon pottery of type SIII	\N	1	-10	\N	C	2019-12-20 22:14:28.053842+00	4415
1	9	2	-9	body of incipient Jomon pottery of type SIII	\N	1	-9	\N	C	2019-12-20 22:14:28.053842+00	4416
1	8	2	-8	body of incipient Jomon pottery of type SIII	\N	1	-8	\N	C	2019-12-20 22:14:28.053842+00	4417
1	7	2	-7	body of incipient Jomon pottery of type SIII	\N	1	-7	\N	C	2019-12-20 22:14:28.053842+00	4418
1	6	2	-6	body of incipient Jomon pottery of type SIII	\N	1	-6	\N	C	2019-12-20 22:14:28.053842+00	4419
1	5	2	-5	body of incipient Jomon pottery of type SIII	\N	1	-5	\N	C	2019-12-20 22:14:28.053842+00	4420
1	4	2	-4	unknown part of incipient Jomon pottery of type SIII	\N	1	-4	\N	C	2019-12-20 22:14:28.053842+00	4421
1	3	2	-3	body of incipient Jomon pottery of type SIII	\N	1	-3	\N	C	2019-12-20 22:14:28.053842+00	4422
1	2	2	-2	body of incipient Jomon pottery of type SIII	\N	1	-2	\N	C	2019-12-20 22:14:28.053842+00	4423
1	1	2	-1	body of incipient Jomon pottery of type SIII	\N	1	-1	\N	C	2019-12-20 22:14:28.053842+00	4424
