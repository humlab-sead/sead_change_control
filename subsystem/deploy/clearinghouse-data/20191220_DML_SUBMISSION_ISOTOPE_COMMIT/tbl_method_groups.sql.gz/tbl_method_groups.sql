1	1	\N	Analysis methods used to measure the relative abundance of stable isotopes in a sample.	Isotope analysis	1	-1	\N	C	2019-12-20 22:14:28.053842+00	24
1	2	\N	Group of methods used in pretreatment for isotope analysis.	Isotope analysis pre-treatment methods	1	-2	\N	C	2019-12-20 22:14:28.053842+00	23
