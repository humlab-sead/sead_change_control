0	n/a
1	Normal
2	Good
3	Excellent
