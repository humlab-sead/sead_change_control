0	General	0
1	Login	1
2	Logout	1
3	Upload submission	2
4	Accept submission	2
5	Reject submission	2
6	Open submission	2
7	Process submission	2
8	Transfer submission	2
9	Add reject cause	2
10	Delete reject cause	2
11	Claim submission	2
12	Unclaim submission	2
13	Execute report	2
20	Add user	1
21	Change user	1
22	Send reminder	2
23	Reclaim submission	2
24	Nag	0
