0	Undefined
1	Reader
2	Normal
3	Administrator
4	Data Provider
