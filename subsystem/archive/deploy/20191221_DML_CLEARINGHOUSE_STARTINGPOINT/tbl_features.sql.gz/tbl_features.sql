48	540	Context ID 29407	\N	\N	3	1	-48	\N	C	2019-12-20 22:14:19.067462+00	2901
49	514	Context ID 30742	\N	\N	3	1	-49	\N	C	2019-12-20 22:14:19.067462+00	2900
50	540	Context ID 31182	\N	\N	3	1	-50	\N	C	2019-12-20 22:14:19.067462+00	2899
51	512	Context ID 31210	\N	\N	3	1	-51	\N	C	2019-12-20 22:14:19.067462+00	2898
52	543	Context ID 31803	\N	\N	3	1	-52	\N	C	2019-12-20 22:14:19.067462+00	2897
53	516	Context ID 32500	\N	\N	3	1	-53	\N	C	2019-12-20 22:14:19.067462+00	2896
54	539	Context ID 32705	\N	\N	3	1	-54	\N	C	2019-12-20 22:14:19.067462+00	2895
55	539	Context ID 33195	\N	\N	3	1	-55	\N	C	2019-12-20 22:14:19.067462+00	2894
56	539	Context ID 33304	\N	\N	3	1	-56	\N	C	2019-12-20 22:14:19.067462+00	2893
57	504	Context ID 33974	\N	\N	3	1	-57	\N	C	2019-12-20 22:14:19.067462+00	2892
58	514	Context ID 34866	\N	\N	3	1	-58	\N	C	2019-12-20 22:14:19.067462+00	2891
59	532	Context ID 3495	\N	\N	3	1	-59	\N	C	2019-12-20 22:14:19.067462+00	2890
60	520	Context ID 3603	\N	\N	3	1	-60	\N	C	2019-12-20 22:14:19.067462+00	2889
61	543	Context ID 36101	\N	\N	3	1	-61	\N	C	2019-12-20 22:14:19.067462+00	2888
62	523	Context ID 36124	\N	\N	3	1	-62	\N	C	2019-12-20 22:14:19.067462+00	2887
63	504	Context ID 36592	\N	\N	3	1	-63	\N	C	2019-12-20 22:14:19.067462+00	2886
64	513	Context ID 36836	\N	\N	3	1	-64	\N	C	2019-12-20 22:14:19.067462+00	2885
65	514	Context ID 36995	\N	\N	3	1	-65	\N	C	2019-12-20 22:14:19.067462+00	2884
66	514	Context ID 37435	\N	\N	3	1	-66	\N	C	2019-12-20 22:14:19.067462+00	2883
67	543	Context ID 37518	\N	\N	3	1	-67	\N	C	2019-12-20 22:14:19.067462+00	2882
68	513	Context ID 39665	\N	\N	3	1	-68	\N	C	2019-12-20 22:14:19.067462+00	2881
69	513	Context ID 40078	\N	\N	3	1	-69	\N	C	2019-12-20 22:14:19.067462+00	2880
70	513	Context ID 40276	\N	\N	3	1	-70	\N	C	2019-12-20 22:14:19.067462+00	2879
71	513	Context ID 40466	\N	\N	3	1	-71	\N	C	2019-12-20 22:14:19.067462+00	2878
72	513	Context ID 40770	\N	\N	3	1	-72	\N	C	2019-12-20 22:14:19.067462+00	2877
73	550	Context ID 40777	\N	\N	3	1	-73	\N	C	2019-12-20 22:14:19.067462+00	2876
74	522	Context ID 41400	\N	\N	3	1	-74	\N	C	2019-12-20 22:14:19.067462+00	2875
75	513	Context ID 43322	\N	\N	3	1	-75	\N	C	2019-12-20 22:14:19.067462+00	2874
76	543	Context ID 43633	\N	\N	3	1	-76	\N	C	2019-12-20 22:14:19.067462+00	2873
77	513	Context ID 43732	\N	\N	3	1	-77	\N	C	2019-12-20 22:14:19.067462+00	2872
78	514	Context ID 43924	\N	\N	3	1	-78	\N	C	2019-12-20 22:14:19.067462+00	2871
79	550	Context ID 44244	\N	\N	3	1	-79	\N	C	2019-12-20 22:14:19.067462+00	2870
80	543	Context ID 44340	\N	\N	3	1	-80	\N	C	2019-12-20 22:14:19.067462+00	2869
81	540	Context ID 4435	\N	\N	3	1	-81	\N	C	2019-12-20 22:14:19.067462+00	2868
82	513	Context ID 44366	\N	\N	3	1	-82	\N	C	2019-12-20 22:14:19.067462+00	2867
83	32	Context ID 44404	\N	\N	3	1	-83	\N	C	2019-12-20 22:14:19.067462+00	2866
84	522	Context ID 44868	\N	\N	3	1	-84	\N	C	2019-12-20 22:14:19.067462+00	2865
85	546	Context ID 4549	\N	\N	3	1	-85	\N	C	2019-12-20 22:14:19.067462+00	2864
86	513	Context ID 45500	\N	\N	3	1	-86	\N	C	2019-12-20 22:14:19.067462+00	2863
87	550	Context ID 46030	\N	\N	3	1	-87	\N	C	2019-12-20 22:14:19.067462+00	2862
88	550	Context ID 46034	\N	\N	3	1	-88	\N	C	2019-12-20 22:14:19.067462+00	2861
89	34	Context ID 46587	\N	\N	3	1	-89	\N	C	2019-12-20 22:14:19.067462+00	2860
90	523	Context ID 46744	\N	\N	3	1	-90	\N	C	2019-12-20 22:14:19.067462+00	2859
91	34	Context ID 46753	\N	\N	3	1	-91	\N	C	2019-12-20 22:14:19.067462+00	2858
92	513	Context ID 46960	\N	\N	3	1	-92	\N	C	2019-12-20 22:14:19.067462+00	2857
93	32	Context ID 47090	\N	\N	3	1	-93	\N	C	2019-12-20 22:14:19.067462+00	2856
94	32	Context ID 47116	\N	\N	3	1	-94	\N	C	2019-12-20 22:14:19.067462+00	2855
95	543	Context ID 47186	\N	\N	3	1	-95	\N	C	2019-12-20 22:14:19.067462+00	2854
96	523	Context ID 47190	\N	\N	3	1	-96	\N	C	2019-12-20 22:14:19.067462+00	2853
97	514	Context ID 8903	\N	\N	3	1	-97	\N	C	2019-12-20 22:14:19.067462+00	2852
98	524	Context ID 946	\N	\N	3	1	-98	\N	C	2019-12-20 22:14:19.067462+00	2851
99	550	Feature	\N	\N	3	1	-99	\N	C	2019-12-20 22:14:19.067462+00	2850
100	508	Feature	\N	\N	3	1	-100	\N	C	2019-12-20 22:14:19.067462+00	2849
101	509	Feature	\N	\N	3	1	-101	\N	C	2019-12-20 22:14:19.067462+00	2848
102	510	Feature	\N	\N	3	1	-102	\N	C	2019-12-20 22:14:19.067462+00	2847
103	511	Feature	\N	\N	3	1	-103	\N	C	2019-12-20 22:14:19.067462+00	2846
104	514	Feature	\N	\N	3	1	-104	\N	C	2019-12-20 22:14:19.067462+00	2845
105	528	Feature	\N	\N	3	1	-105	\N	C	2019-12-20 22:14:19.067462+00	2844
106	529	Feature	\N	\N	3	1	-106	\N	C	2019-12-20 22:14:19.067462+00	2843
107	530	Feature	\N	\N	3	1	-107	\N	C	2019-12-20 22:14:19.067462+00	2842
108	535	Feature	\N	\N	3	1	-108	\N	C	2019-12-20 22:14:19.067462+00	2841
109	541	Feature	\N	\N	3	1	-109	\N	C	2019-12-20 22:14:19.067462+00	2840
110	542	Feature	\N	\N	3	1	-110	\N	C	2019-12-20 22:14:19.067462+00	2839
111	34	Feature No. 10738	\N	\N	3	1	-111	\N	C	2019-12-20 22:14:19.067462+00	2838
112	528	Feature No. 13089	CONTEXT GROUP: KG 67	\N	3	1	-112	\N	C	2019-12-20 22:14:19.067462+00	2837
113	514	Feature No. 13309	CONTEXT GROUP: KG 68	\N	3	1	-113	\N	C	2019-12-20 22:14:19.067462+00	2836
114	34	Feature No. 13495	CONTEXT GROUP: KG 58	\N	3	1	-114	\N	C	2019-12-20 22:14:19.067462+00	2835
115	514	Feature No. 2180	CONTEXT GROUP: KG 22	\N	3	1	-115	\N	C	2019-12-20 22:14:19.067462+00	2834
116	505	Feature No. 7400	\N	\N	3	1	-116	\N	C	2019-12-20 22:14:19.067462+00	2833
117	542	Feature No. A17228	\N	\N	3	1	-117	\N	C	2019-12-20 22:14:19.067462+00	2832
118	536	Feature No. A19919	\N	\N	3	1	-118	\N	C	2019-12-20 22:14:19.067462+00	2831
119	523	Feature No. hus 300	\N	\N	3	1	-119	\N	C	2019-12-20 22:14:19.067462+00	2830
120	528	Feature No. hus 300	\N	\N	3	1	-120	\N	C	2019-12-20 22:14:19.067462+00	2829
121	550	Feature No. hus 311	\N	\N	3	1	-121	\N	C	2019-12-20 22:14:19.067462+00	2828
122	514	Feature No. hus 317	\N	\N	3	1	-122	\N	C	2019-12-20 22:14:19.067462+00	2827
123	535	Feature No. VA-schaktet	\N	\N	3	1	-123	\N	C	2019-12-20 22:14:19.067462+00	2826
124	550	Feature	\N	\N	3	1	-124	\N	C	2019-12-20 22:14:19.067462+00	2825
125	503	Feature	\N	\N	3	1	-125	\N	C	2019-12-20 22:14:19.067462+00	2824
126	506	Feature	\N	\N	3	1	-126	\N	C	2019-12-20 22:14:19.067462+00	2823
127	516	Feature	\N	\N	3	1	-127	\N	C	2019-12-20 22:14:19.067462+00	2822
128	520	Feature	\N	\N	3	1	-128	\N	C	2019-12-20 22:14:19.067462+00	2821
129	523	Feature	\N	\N	3	1	-129	\N	C	2019-12-20 22:14:19.067462+00	2820
130	524	Feature	\N	\N	3	1	-130	\N	C	2019-12-20 22:14:19.067462+00	2819
131	520	Feature No. 262	\N	\N	3	1	-131	\N	C	2019-12-20 22:14:19.067462+00	2818
132	520	Feature No. 291	\N	\N	3	1	-132	\N	C	2019-12-20 22:14:19.067462+00	2817
133	520	Feature No. 348	\N	\N	3	1	-133	\N	C	2019-12-20 22:14:19.067462+00	2816
134	520	Feature No. 490	\N	\N	3	1	-134	\N	C	2019-12-20 22:14:19.067462+00	2815
135	520	Feature No. 613	\N	\N	3	1	-135	\N	C	2019-12-20 22:14:19.067462+00	2814
136	514	Feature No. A10200	\N	\N	3	1	-136	\N	C	2019-12-20 22:14:19.067462+00	2813
137	520	Feature No. A10465	\N	\N	3	1	-137	\N	C	2019-12-20 22:14:19.067462+00	2812
138	40	Feature	\N	\N	3	1	-138	\N	C	2019-12-20 22:14:19.067462+00	2811
139	4	Feature	\N	\N	3	1	-139	\N	C	2019-12-20 22:14:19.067462+00	2810
140	533	Feature No. A1	\N	\N	3	1	-140	\N	C	2019-12-20 22:14:19.067462+00	2809
141	507	Feature No. A2	\N	\N	3	1	-141	\N	C	2019-12-20 22:14:19.067462+00	2808
142	534	Feature No. A3	\N	\N	3	1	-142	\N	C	2019-12-20 22:14:19.067462+00	2807
143	537	Feature No. A3	\N	\N	3	1	-143	\N	C	2019-12-20 22:14:19.067462+00	2806
144	533	Feature No. A4	\N	\N	3	1	-144	\N	C	2019-12-20 22:14:19.067462+00	2805
145	537	Feature No. A5	\N	\N	3	1	-145	\N	C	2019-12-20 22:14:19.067462+00	2804
146	507	Feature No. A6	\N	\N	3	1	-146	\N	C	2019-12-20 22:14:19.067462+00	2803
147	533	Feature No. A7	\N	\N	3	1	-147	\N	C	2019-12-20 22:14:19.067462+00	2802
148	533	Feature No. A8	\N	\N	3	1	-148	\N	C	2019-12-20 22:14:19.067462+00	2801
149	506	Feature No. 18	\N	\N	3	1	-149	\N	C	2019-12-20 22:14:19.067462+00	2800
150	4	Feature	\N	\N	3	1	-150	\N	C	2019-12-20 22:14:19.067462+00	2799
151	518	Feature	\N	\N	3	1	-151	\N	C	2019-12-20 22:14:19.067462+00	2798
152	526	Feature	\N	\N	3	1	-152	\N	C	2019-12-20 22:14:19.067462+00	2797
153	25	Norra schakt	\N	\N	3	1	-153	\N	C	2019-12-20 22:14:19.067462+00	2796
154	25	Södra schakt	\N	\N	3	1	-154	\N	C	2019-12-20 22:14:19.067462+00	2795
155	25	Grop 1	\N	\N	3	1	-155	\N	C	2019-12-20 22:14:19.067462+00	2794
156	25	Grop 4	\N	\N	3	1	-156	\N	C	2019-12-20 22:14:19.067462+00	2793
157	25	Grop 5	\N	\N	3	1	-157	\N	C	2019-12-20 22:14:19.067462+00	2792
158	25	1	\N	\N	3	1	-158	\N	C	2019-12-20 22:14:19.067462+00	2791
159	25	3	\N	\N	3	1	-159	\N	C	2019-12-20 22:14:19.067462+00	2790
160	25	5	\N	\N	3	1	-160	\N	C	2019-12-20 22:14:19.067462+00	2789
161	25	1	\N	\N	3	1	-161	\N	C	2019-12-20 22:14:19.067462+00	2788
162	25	2	\N	\N	3	1	-162	\N	C	2019-12-20 22:14:19.067462+00	2787
163	25	2-2009	\N	\N	3	1	-163	\N	C	2019-12-20 22:14:19.067462+00	2786
164	25	2	\N	\N	3	1	-164	\N	C	2019-12-20 22:14:19.067462+00	2785
165	25	4	\N	\N	3	1	-165	\N	C	2019-12-20 22:14:19.067462+00	2784
166	25	5	\N	\N	3	1	-166	\N	C	2019-12-20 22:14:19.067462+00	2783
167	25	287	\N	\N	3	1	-167	\N	C	2019-12-20 22:14:19.067462+00	2782
168	25	318	\N	\N	3	1	-168	\N	C	2019-12-20 22:14:19.067462+00	2781
169	25	475	\N	\N	3	1	-169	\N	C	2019-12-20 22:14:19.067462+00	2780
170	25	601	\N	\N	3	1	-170	\N	C	2019-12-20 22:14:19.067462+00	2779
171	25	Schakt vid spår 7	\N	\N	3	1	-171	\N	C	2019-12-20 22:14:19.067462+00	2778
172	25	Grop 5	\N	\N	3	1	-172	\N	C	2019-12-20 22:14:19.067462+00	2777
173	547	1	\N	\N	3	1	-173	\N	C	2019-12-20 22:14:19.067462+00	2776
174	547	3	\N	\N	3	1	-174	\N	C	2019-12-20 22:14:19.067462+00	2775
175	547	7	\N	\N	3	1	-175	\N	C	2019-12-20 22:14:19.067462+00	2774
176	547	8	\N	\N	3	1	-176	\N	C	2019-12-20 22:14:19.067462+00	2773
177	547	9	\N	\N	3	1	-177	\N	C	2019-12-20 22:14:19.067462+00	2772
178	547	13	\N	\N	3	1	-178	\N	C	2019-12-20 22:14:19.067462+00	2771
179	547	4; 6	\N	\N	3	1	-179	\N	C	2019-12-20 22:14:19.067462+00	2770
180	547	9; 10; 12	\N	\N	3	1	-180	\N	C	2019-12-20 22:14:19.067462+00	2769
181	547	9; Norra profilen	\N	\N	3	1	-181	\N	C	2019-12-20 22:14:19.067462+00	2768
182	5	Understa lagret	\N	\N	3	1	-182	\N	C	2019-12-20 22:14:19.067462+00	2767
183	5	Översta lagret	\N	\N	3	1	-183	\N	C	2019-12-20 22:14:19.067462+00	2766
184	5	23999	\N	\N	3	1	-184	\N	C	2019-12-20 22:14:19.067462+00	2765
185	5	427	\N	\N	3	1	-185	\N	C	2019-12-20 22:14:19.067462+00	2764
186	5	494	\N	\N	3	1	-186	\N	C	2019-12-20 22:14:19.067462+00	2763
187	5	584	\N	\N	3	1	-187	\N	C	2019-12-20 22:14:19.067462+00	2762
188	548	Västra del intill sjökanten	\N	\N	3	1	-188	\N	C	2019-12-20 22:14:19.067462+00	2761
189	548	Hy 4	\N	\N	3	1	-189	\N	C	2019-12-20 22:14:19.067462+00	2760
190	548	K:5	\N	\N	3	1	-190	\N	C	2019-12-20 22:14:19.067462+00	2759
546	27	feature	Open-air; Close to the coast	\N	4	1	-546	\N	C	2019-12-20 22:14:28.053842+00	3347
545	27	feature	Open-air; Close to the coast	\N	4	1	-545	\N	C	2019-12-20 22:14:28.053842+00	3348
544	27	feature	Open-air; Close to the coast	\N	4	1	-544	\N	C	2019-12-20 22:14:28.053842+00	3349
543	27	feature	Open-air; Close to the coast	\N	4	1	-543	\N	C	2019-12-20 22:14:28.053842+00	3350
542	27	feature	Open-air; Close to the coast	\N	4	1	-542	\N	C	2019-12-20 22:14:28.053842+00	3351
541	27	feature	Open-air; Close to the coast	\N	4	1	-541	\N	C	2019-12-20 22:14:28.053842+00	3352
540	27	feature	Open-air; Close to the coast	\N	4	1	-540	\N	C	2019-12-20 22:14:28.053842+00	3353
539	27	feature	Open-air; Close to the coast	\N	4	1	-539	\N	C	2019-12-20 22:14:28.053842+00	3354
538	27	feature	Open-air; Close to the coast	\N	4	1	-538	\N	C	2019-12-20 22:14:28.053842+00	3355
537	27	feature	Open-air; Close to the coast	\N	4	1	-537	\N	C	2019-12-20 22:14:28.053842+00	3356
536	27	feature	Open-air; Close to the coast	\N	4	1	-536	\N	C	2019-12-20 22:14:28.053842+00	3357
535	27	feature	Open-air; Close to the coast	\N	4	1	-535	\N	C	2019-12-20 22:14:28.053842+00	3358
534	27	feature	Open-air; Close to the coast	\N	4	1	-534	\N	C	2019-12-20 22:14:28.053842+00	3359
533	27	feature	Open-air; Close to the coast	\N	4	1	-533	\N	C	2019-12-20 22:14:28.053842+00	3360
532	27	feature	Open-air; Close to the coast	\N	4	1	-532	\N	C	2019-12-20 22:14:28.053842+00	3361
531	27	feature	Open-air; Close to the coast	\N	4	1	-531	\N	C	2019-12-20 22:14:28.053842+00	3362
530	27	feature	Open-air; Close to the coast	\N	4	1	-530	\N	C	2019-12-20 22:14:28.053842+00	3363
529	27	feature	Open-air; Close to the coast	\N	4	1	-529	\N	C	2019-12-20 22:14:28.053842+00	3364
528	27	feature	Open-air; Close to the coast	\N	4	1	-528	\N	C	2019-12-20 22:14:28.053842+00	3365
527	27	feature	Open-air; Close to the coast	\N	4	1	-527	\N	C	2019-12-20 22:14:28.053842+00	3366
526	27	feature	Open-air; Close to the coast	\N	4	1	-526	\N	C	2019-12-20 22:14:28.053842+00	3367
525	27	feature	Open-air; Close to the coast	\N	4	1	-525	\N	C	2019-12-20 22:14:28.053842+00	3368
944	27	feature	Open-air; Inland	\N	4	1	-944	\N	C	2019-12-20 22:14:28.053842+00	2949
943	27	feature	Open-air; Inland	\N	4	1	-943	\N	C	2019-12-20 22:14:28.053842+00	2950
942	27	feature	Open-air; Inland	\N	4	1	-942	\N	C	2019-12-20 22:14:28.053842+00	2951
941	27	feature	Open-air; Inland	\N	4	1	-941	\N	C	2019-12-20 22:14:28.053842+00	2952
940	27	feature	Open-air; Inland	\N	4	1	-940	\N	C	2019-12-20 22:14:28.053842+00	2953
939	27	feature	Open-air; Inland	\N	4	1	-939	\N	C	2019-12-20 22:14:28.053842+00	2954
938	27	feature	Open-air; Inland	\N	4	1	-938	\N	C	2019-12-20 22:14:28.053842+00	2955
937	27	feature	Open-air; Inland	\N	4	1	-937	\N	C	2019-12-20 22:14:28.053842+00	2956
936	27	feature	Open-air; Inland	\N	4	1	-936	\N	C	2019-12-20 22:14:28.053842+00	2957
935	27	feature	Open-air; Inland	\N	4	1	-935	\N	C	2019-12-20 22:14:28.053842+00	2958
934	27	feature	Open-air; Lake shore	\N	4	1	-934	\N	C	2019-12-20 22:14:28.053842+00	2959
933	27	feature	Open-air; Lake shore	\N	4	1	-933	\N	C	2019-12-20 22:14:28.053842+00	2960
932	27	feature	Open-air; Lake shore	\N	4	1	-932	\N	C	2019-12-20 22:14:28.053842+00	2961
931	27	feature	Open-air; Lake shore	\N	4	1	-931	\N	C	2019-12-20 22:14:28.053842+00	2962
930	27	feature	Open-air; Lake shore	\N	4	1	-930	\N	C	2019-12-20 22:14:28.053842+00	2963
929	27	feature	Open-air; Lake shore	\N	4	1	-929	\N	C	2019-12-20 22:14:28.053842+00	2964
928	27	feature	Open-air; Lake shore	\N	4	1	-928	\N	C	2019-12-20 22:14:28.053842+00	2965
927	27	feature	Open-air; Lake shore	\N	4	1	-927	\N	C	2019-12-20 22:14:28.053842+00	2966
926	27	feature	Open-air; Lake shore	\N	4	1	-926	\N	C	2019-12-20 22:14:28.053842+00	2967
925	27	feature	Open-air; Lake shore	\N	4	1	-925	\N	C	2019-12-20 22:14:28.053842+00	2968
924	27	feature	Open-air; Lake shore	\N	4	1	-924	\N	C	2019-12-20 22:14:28.053842+00	2969
923	27	feature	Open-air; Lake shore	\N	4	1	-923	\N	C	2019-12-20 22:14:28.053842+00	2970
922	27	feature	Open-air; Lake shore	\N	4	1	-922	\N	C	2019-12-20 22:14:28.053842+00	2971
921	27	feature	Open-air; Inland	\N	4	1	-921	\N	C	2019-12-20 22:14:28.053842+00	2972
920	27	feature	Open-air; Inland	\N	4	1	-920	\N	C	2019-12-20 22:14:28.053842+00	2973
919	27	feature	Open-air; Inland	\N	4	1	-919	\N	C	2019-12-20 22:14:28.053842+00	2974
918	27	feature	Open-air; Inland	\N	4	1	-918	\N	C	2019-12-20 22:14:28.053842+00	2975
917	27	feature	Open-air; Inland	\N	4	1	-917	\N	C	2019-12-20 22:14:28.053842+00	2976
916	27	feature	Open-air; Inland	\N	4	1	-916	\N	C	2019-12-20 22:14:28.053842+00	2977
915	27	feature	Open-air; Inland	\N	4	1	-915	\N	C	2019-12-20 22:14:28.053842+00	2978
914	27	feature	Open-air; Inland	\N	4	1	-914	\N	C	2019-12-20 22:14:28.053842+00	2979
913	27	feature	Open-air; Inland	\N	4	1	-913	\N	C	2019-12-20 22:14:28.053842+00	2980
912	27	feature	Open-air; Inland	\N	4	1	-912	\N	C	2019-12-20 22:14:28.053842+00	2981
911	27	feature	Open-air; Inland	\N	4	1	-911	\N	C	2019-12-20 22:14:28.053842+00	2982
910	27	feature	Open-air; Inland	\N	4	1	-910	\N	C	2019-12-20 22:14:28.053842+00	2983
909	27	feature	Open-air; Inland	\N	4	1	-909	\N	C	2019-12-20 22:14:28.053842+00	2984
908	27	feature	Open-air; Inland	\N	4	1	-908	\N	C	2019-12-20 22:14:28.053842+00	2985
907	27	feature	Open-air; Inland	\N	4	1	-907	\N	C	2019-12-20 22:14:28.053842+00	2986
906	27	feature	Open-air; Inland	\N	4	1	-906	\N	C	2019-12-20 22:14:28.053842+00	2987
905	27	feature	Open-air; Inland	\N	4	1	-905	\N	C	2019-12-20 22:14:28.053842+00	2988
904	27	feature	Open-air; Inland	\N	4	1	-904	\N	C	2019-12-20 22:14:28.053842+00	2989
903	27	feature	Open-air; Inland	\N	4	1	-903	\N	C	2019-12-20 22:14:28.053842+00	2990
902	27	feature	Open-air; Inland	\N	4	1	-902	\N	C	2019-12-20 22:14:28.053842+00	2991
901	27	feature	Open-air; Inland	\N	4	1	-901	\N	C	2019-12-20 22:14:28.053842+00	2992
900	27	feature	Open-air; Inland	\N	4	1	-900	\N	C	2019-12-20 22:14:28.053842+00	2993
899	27	feature	Open-air; Inland	\N	4	1	-899	\N	C	2019-12-20 22:14:28.053842+00	2994
898	27	feature	Open-air; Inland	\N	4	1	-898	\N	C	2019-12-20 22:14:28.053842+00	2995
897	27	feature	Open-air; Inland	\N	4	1	-897	\N	C	2019-12-20 22:14:28.053842+00	2996
896	27	feature	Open-air; Inland	\N	4	1	-896	\N	C	2019-12-20 22:14:28.053842+00	2997
895	27	feature	Open-air; Inland	\N	4	1	-895	\N	C	2019-12-20 22:14:28.053842+00	2998
894	27	feature	Open-air; Inland	\N	4	1	-894	\N	C	2019-12-20 22:14:28.053842+00	2999
893	27	feature	Open-air; Inland	\N	4	1	-893	\N	C	2019-12-20 22:14:28.053842+00	3000
892	27	feature	Open-air; Inland	\N	4	1	-892	\N	C	2019-12-20 22:14:28.053842+00	3001
891	27	feature	Open-air; Inland	\N	4	1	-891	\N	C	2019-12-20 22:14:28.053842+00	3002
890	27	feature	Open-air; Inland	\N	4	1	-890	\N	C	2019-12-20 22:14:28.053842+00	3003
889	27	feature	Open-air; Close to the coast	\N	4	1	-889	\N	C	2019-12-20 22:14:28.053842+00	3004
888	27	feature	Open-air; Close to the coast	\N	4	1	-888	\N	C	2019-12-20 22:14:28.053842+00	3005
887	27	feature	Open-air; Close to the coast	\N	4	1	-887	\N	C	2019-12-20 22:14:28.053842+00	3006
886	27	feature	Open-air; Close to the coast	\N	4	1	-886	\N	C	2019-12-20 22:14:28.053842+00	3007
885	27	feature	Open-air; Close to the coast	\N	4	1	-885	\N	C	2019-12-20 22:14:28.053842+00	3008
884	27	feature	Open-air; Close to the coast	\N	4	1	-884	\N	C	2019-12-20 22:14:28.053842+00	3009
883	27	feature	Open-air; Close to the coast	\N	4	1	-883	\N	C	2019-12-20 22:14:28.053842+00	3010
882	27	feature	Open-air; Close to the coast	\N	4	1	-882	\N	C	2019-12-20 22:14:28.053842+00	3011
881	27	feature	Open-air; Close to the coast	\N	4	1	-881	\N	C	2019-12-20 22:14:28.053842+00	3012
880	27	feature	Open-air; Close to the coast	\N	4	1	-880	\N	C	2019-12-20 22:14:28.053842+00	3013
879	27	feature	Open-air; Close to the coast	\N	4	1	-879	\N	C	2019-12-20 22:14:28.053842+00	3014
878	27	feature	Open-air; Close to the coast	\N	4	1	-878	\N	C	2019-12-20 22:14:28.053842+00	3015
877	27	feature	Open-air; Close to the coast	\N	4	1	-877	\N	C	2019-12-20 22:14:28.053842+00	3016
876	27	feature	Open-air; Close to the coast	\N	4	1	-876	\N	C	2019-12-20 22:14:28.053842+00	3017
875	27	feature	Open-air; Close to the coast	\N	4	1	-875	\N	C	2019-12-20 22:14:28.053842+00	3018
874	27	feature	Open-air; Close to the coast	\N	4	1	-874	\N	C	2019-12-20 22:14:28.053842+00	3019
873	27	feature	Open-air; Close to the coast	\N	4	1	-873	\N	C	2019-12-20 22:14:28.053842+00	3020
872	27	feature	Open-air; Close to the coast	\N	4	1	-872	\N	C	2019-12-20 22:14:28.053842+00	3021
871	27	feature	Open-air; Close to the coast	\N	4	1	-871	\N	C	2019-12-20 22:14:28.053842+00	3022
870	27	feature	Open-air; Close to the coast	\N	4	1	-870	\N	C	2019-12-20 22:14:28.053842+00	3023
869	27	feature	Open-air; Close to the coast	\N	4	1	-869	\N	C	2019-12-20 22:14:28.053842+00	3024
868	27	feature	Open-air; Close to the coast	\N	4	1	-868	\N	C	2019-12-20 22:14:28.053842+00	3025
867	27	feature	Open-air; Inland	\N	4	1	-867	\N	C	2019-12-20 22:14:28.053842+00	3026
866	27	feature	Open-air; Inland	\N	4	1	-866	\N	C	2019-12-20 22:14:28.053842+00	3027
865	27	feature	Open-air; Inland	\N	4	1	-865	\N	C	2019-12-20 22:14:28.053842+00	3028
864	27	feature	Open-air; Inland	\N	4	1	-864	\N	C	2019-12-20 22:14:28.053842+00	3029
863	27	feature	Open-air; Inland	\N	4	1	-863	\N	C	2019-12-20 22:14:28.053842+00	3030
862	27	feature	Open-air; Close to the coast	\N	4	1	-862	\N	C	2019-12-20 22:14:28.053842+00	3031
861	12	feature	Shell midden; Lake shore	\N	4	1	-861	\N	C	2019-12-20 22:14:28.053842+00	3032
860	12	feature	Shell midden; Lake shore	\N	4	1	-860	\N	C	2019-12-20 22:14:28.053842+00	3033
859	12	feature	Shell midden; Lake shore	\N	4	1	-859	\N	C	2019-12-20 22:14:28.053842+00	3034
858	12	feature	Shell midden; Lake shore	\N	4	1	-858	\N	C	2019-12-20 22:14:28.053842+00	3035
857	12	feature	Shell midden; Lake shore	\N	4	1	-857	\N	C	2019-12-20 22:14:28.053842+00	3036
856	12	feature	Shell midden; Lake shore	\N	4	1	-856	\N	C	2019-12-20 22:14:28.053842+00	3037
855	12	feature	Shell midden; Lake shore	\N	4	1	-855	\N	C	2019-12-20 22:14:28.053842+00	3038
854	12	feature	Shell midden; Lake shore	\N	4	1	-854	\N	C	2019-12-20 22:14:28.053842+00	3039
853	12	feature	Shell midden; Lake shore	\N	4	1	-853	\N	C	2019-12-20 22:14:28.053842+00	3040
852	12	feature	Shell midden; Lake shore	\N	4	1	-852	\N	C	2019-12-20 22:14:28.053842+00	3041
851	12	feature	Shell midden; Lake shore	\N	4	1	-851	\N	C	2019-12-20 22:14:28.053842+00	3042
850	12	feature	Shell midden; Lake shore	\N	4	1	-850	\N	C	2019-12-20 22:14:28.053842+00	3043
849	12	feature	Shell midden; Lake shore	\N	4	1	-849	\N	C	2019-12-20 22:14:28.053842+00	3044
848	12	feature	Shell midden; Lake shore	\N	4	1	-848	\N	C	2019-12-20 22:14:28.053842+00	3045
847	12	feature	Shell midden; Lake shore	\N	4	1	-847	\N	C	2019-12-20 22:14:28.053842+00	3046
846	12	feature	Shell midden; Lake shore	\N	4	1	-846	\N	C	2019-12-20 22:14:28.053842+00	3047
845	12	feature	Shell midden; Lake shore	\N	4	1	-845	\N	C	2019-12-20 22:14:28.053842+00	3048
844	12	feature	Shell midden; Lake shore	\N	4	1	-844	\N	C	2019-12-20 22:14:28.053842+00	3049
843	12	feature	Shell midden; Lake shore	\N	4	1	-843	\N	C	2019-12-20 22:14:28.053842+00	3050
842	12	feature	Shell midden; Lake shore	\N	4	1	-842	\N	C	2019-12-20 22:14:28.053842+00	3051
841	12	feature	Shell midden; Lake shore	\N	4	1	-841	\N	C	2019-12-20 22:14:28.053842+00	3052
840	12	feature	Shell midden; Lake shore	\N	4	1	-840	\N	C	2019-12-20 22:14:28.053842+00	3053
839	12	feature	Shell midden; Lake shore	\N	4	1	-839	\N	C	2019-12-20 22:14:28.053842+00	3054
838	12	feature	Shell midden; Lake shore	\N	4	1	-838	\N	C	2019-12-20 22:14:28.053842+00	3055
837	12	feature	Shell midden; Lake shore	\N	4	1	-837	\N	C	2019-12-20 22:14:28.053842+00	3056
836	12	feature	Shell midden; Lake shore	\N	4	1	-836	\N	C	2019-12-20 22:14:28.053842+00	3057
835	12	feature	Shell midden; Lake shore	\N	4	1	-835	\N	C	2019-12-20 22:14:28.053842+00	3058
834	12	feature	Shell midden; Lake shore	\N	4	1	-834	\N	C	2019-12-20 22:14:28.053842+00	3059
833	12	feature	Shell midden; Lake shore	\N	4	1	-833	\N	C	2019-12-20 22:14:28.053842+00	3060
832	12	feature	Shell midden; Lake shore	\N	4	1	-832	\N	C	2019-12-20 22:14:28.053842+00	3061
831	12	feature	Shell midden; Lake shore	\N	4	1	-831	\N	C	2019-12-20 22:14:28.053842+00	3062
830	12	feature	Shell midden; Lake shore	\N	4	1	-830	\N	C	2019-12-20 22:14:28.053842+00	3063
829	12	feature	Shell midden; Lake shore	\N	4	1	-829	\N	C	2019-12-20 22:14:28.053842+00	3064
828	12	feature	Shell midden; Lake shore	\N	4	1	-828	\N	C	2019-12-20 22:14:28.053842+00	3065
827	12	feature	Shell midden; Lake shore	\N	4	1	-827	\N	C	2019-12-20 22:14:28.053842+00	3066
826	12	feature	Shell midden; Lake shore	\N	4	1	-826	\N	C	2019-12-20 22:14:28.053842+00	3067
825	12	feature	Shell midden; Lake shore	\N	4	1	-825	\N	C	2019-12-20 22:14:28.053842+00	3068
824	12	feature	Shell midden; Lake shore	\N	4	1	-824	\N	C	2019-12-20 22:14:28.053842+00	3069
823	12	feature	Shell midden; Lake shore	\N	4	1	-823	\N	C	2019-12-20 22:14:28.053842+00	3070
822	12	feature	Shell midden; Lake shore	\N	4	1	-822	\N	C	2019-12-20 22:14:28.053842+00	3071
821	12	feature	Shell midden; Lake shore	\N	4	1	-821	\N	C	2019-12-20 22:14:28.053842+00	3072
820	12	feature	Shell midden; Lake shore	\N	4	1	-820	\N	C	2019-12-20 22:14:28.053842+00	3073
819	12	feature	Shell midden; Lake shore	\N	4	1	-819	\N	C	2019-12-20 22:14:28.053842+00	3074
818	12	feature	Shell midden; Lake shore	\N	4	1	-818	\N	C	2019-12-20 22:14:28.053842+00	3075
817	12	feature	Shell midden; Lake shore	\N	4	1	-817	\N	C	2019-12-20 22:14:28.053842+00	3076
816	12	feature	Shell midden; Lake shore	\N	4	1	-816	\N	C	2019-12-20 22:14:28.053842+00	3077
815	12	feature	Shell midden; Lake shore	\N	4	1	-815	\N	C	2019-12-20 22:14:28.053842+00	3078
814	12	feature	Shell midden; Lake shore	\N	4	1	-814	\N	C	2019-12-20 22:14:28.053842+00	3079
813	12	feature	Shell midden; Lake shore	\N	4	1	-813	\N	C	2019-12-20 22:14:28.053842+00	3080
812	12	feature	Shell midden; Lake shore	\N	4	1	-812	\N	C	2019-12-20 22:14:28.053842+00	3081
811	12	feature	Shell midden; Lake shore	\N	4	1	-811	\N	C	2019-12-20 22:14:28.053842+00	3082
810	12	feature	Shell midden; Lake shore	\N	4	1	-810	\N	C	2019-12-20 22:14:28.053842+00	3083
809	12	feature	Shell midden; Lake shore	\N	4	1	-809	\N	C	2019-12-20 22:14:28.053842+00	3084
808	12	feature	Shell midden; Lake shore	\N	4	1	-808	\N	C	2019-12-20 22:14:28.053842+00	3085
807	12	feature	Shell midden; Lake shore	\N	4	1	-807	\N	C	2019-12-20 22:14:28.053842+00	3086
806	12	feature	Shell midden; Lake shore	\N	4	1	-806	\N	C	2019-12-20 22:14:28.053842+00	3087
805	12	feature	Shell midden; Lake shore	\N	4	1	-805	\N	C	2019-12-20 22:14:28.053842+00	3088
804	12	feature	Shell midden; Lake shore	\N	4	1	-804	\N	C	2019-12-20 22:14:28.053842+00	3089
803	12	feature	Shell midden; Lake shore	\N	4	1	-803	\N	C	2019-12-20 22:14:28.053842+00	3090
802	12	feature	Shell midden; Lake shore	\N	4	1	-802	\N	C	2019-12-20 22:14:28.053842+00	3091
801	12	feature	Shell midden; Lake shore	\N	4	1	-801	\N	C	2019-12-20 22:14:28.053842+00	3092
800	12	feature	Shell midden; Lake shore	\N	4	1	-800	\N	C	2019-12-20 22:14:28.053842+00	3093
799	12	feature	Shell midden; Lake shore	\N	4	1	-799	\N	C	2019-12-20 22:14:28.053842+00	3094
798	12	feature	Shell midden; Lake shore	\N	4	1	-798	\N	C	2019-12-20 22:14:28.053842+00	3095
797	12	feature	Shell midden; Lake shore	\N	4	1	-797	\N	C	2019-12-20 22:14:28.053842+00	3096
796	12	feature	Shell midden; Lake shore	\N	4	1	-796	\N	C	2019-12-20 22:14:28.053842+00	3097
795	12	feature	Shell midden; Lake shore	\N	4	1	-795	\N	C	2019-12-20 22:14:28.053842+00	3098
794	12	feature	Shell midden; Lake shore	\N	4	1	-794	\N	C	2019-12-20 22:14:28.053842+00	3099
793	12	feature	Shell midden; Lake shore	\N	4	1	-793	\N	C	2019-12-20 22:14:28.053842+00	3100
792	12	feature	Shell midden; Lake shore	\N	4	1	-792	\N	C	2019-12-20 22:14:28.053842+00	3101
791	12	feature	Shell midden; Lake shore	\N	4	1	-791	\N	C	2019-12-20 22:14:28.053842+00	3102
790	12	feature	Shell midden; Lake shore	\N	4	1	-790	\N	C	2019-12-20 22:14:28.053842+00	3103
789	12	feature	Shell midden; Lake shore	\N	4	1	-789	\N	C	2019-12-20 22:14:28.053842+00	3104
788	12	feature	Shell midden; Lake shore	\N	4	1	-788	\N	C	2019-12-20 22:14:28.053842+00	3105
787	12	feature	Shell midden; Lake shore	\N	4	1	-787	\N	C	2019-12-20 22:14:28.053842+00	3106
786	12	feature	Shell midden; Lake shore	\N	4	1	-786	\N	C	2019-12-20 22:14:28.053842+00	3107
785	12	feature	Shell midden; Lake shore	\N	4	1	-785	\N	C	2019-12-20 22:14:28.053842+00	3108
784	12	feature	Shell midden; Lake shore	\N	4	1	-784	\N	C	2019-12-20 22:14:28.053842+00	3109
783	12	feature	Shell midden; Lake shore	\N	4	1	-783	\N	C	2019-12-20 22:14:28.053842+00	3110
782	12	feature	Shell midden; Lake shore	\N	4	1	-782	\N	C	2019-12-20 22:14:28.053842+00	3111
781	27	feature	Open-air; Lake shore	\N	4	1	-781	\N	C	2019-12-20 22:14:28.053842+00	3112
780	27	feature	Open-air; Lake shore	\N	4	1	-780	\N	C	2019-12-20 22:14:28.053842+00	3113
779	27	feature	Open-air; Lake shore	\N	4	1	-779	\N	C	2019-12-20 22:14:28.053842+00	3114
778	27	feature	Open-air; Lake shore	\N	4	1	-778	\N	C	2019-12-20 22:14:28.053842+00	3115
777	27	feature	Open-air; Lake shore	\N	4	1	-777	\N	C	2019-12-20 22:14:28.053842+00	3116
776	27	feature	Open-air; Lake shore	\N	4	1	-776	\N	C	2019-12-20 22:14:28.053842+00	3117
775	27	feature	Open-air; Lake shore	\N	4	1	-775	\N	C	2019-12-20 22:14:28.053842+00	3118
774	27	feature	Open-air; Lake shore	\N	4	1	-774	\N	C	2019-12-20 22:14:28.053842+00	3119
773	27	feature	Open-air; Lake shore	\N	4	1	-773	\N	C	2019-12-20 22:14:28.053842+00	3120
772	27	feature	Open-air; Lake shore	\N	4	1	-772	\N	C	2019-12-20 22:14:28.053842+00	3121
771	27	feature	Open-air; Lake shore	\N	4	1	-771	\N	C	2019-12-20 22:14:28.053842+00	3122
770	27	feature	Open-air; Lake shore	\N	4	1	-770	\N	C	2019-12-20 22:14:28.053842+00	3123
769	27	feature	Open-air; Lake shore	\N	4	1	-769	\N	C	2019-12-20 22:14:28.053842+00	3124
768	27	feature	Open-air; Lake shore	\N	4	1	-768	\N	C	2019-12-20 22:14:28.053842+00	3125
767	27	feature	Open-air; Lake shore	\N	4	1	-767	\N	C	2019-12-20 22:14:28.053842+00	3126
766	27	feature	Open-air; Lake shore	\N	4	1	-766	\N	C	2019-12-20 22:14:28.053842+00	3127
765	27	feature	Open-air; Lake shore	\N	4	1	-765	\N	C	2019-12-20 22:14:28.053842+00	3128
764	27	feature	Open-air; Lake shore	\N	4	1	-764	\N	C	2019-12-20 22:14:28.053842+00	3129
763	27	feature	Open-air; Lake shore	\N	4	1	-763	\N	C	2019-12-20 22:14:28.053842+00	3130
762	27	feature	Open-air; Lake shore	\N	4	1	-762	\N	C	2019-12-20 22:14:28.053842+00	3131
761	27	feature	Open-air; Lake shore	\N	4	1	-761	\N	C	2019-12-20 22:14:28.053842+00	3132
760	27	feature	Open-air; Lake shore	\N	4	1	-760	\N	C	2019-12-20 22:14:28.053842+00	3133
759	27	feature	Open-air; Lake shore	\N	4	1	-759	\N	C	2019-12-20 22:14:28.053842+00	3134
758	27	feature	Open-air; Lake shore	\N	4	1	-758	\N	C	2019-12-20 22:14:28.053842+00	3135
757	27	feature	Open-air; Lake shore	\N	4	1	-757	\N	C	2019-12-20 22:14:28.053842+00	3136
756	27	feature	Open-air; Lake shore	\N	4	1	-756	\N	C	2019-12-20 22:14:28.053842+00	3137
755	27	feature	Open-air; Lake shore	\N	4	1	-755	\N	C	2019-12-20 22:14:28.053842+00	3138
754	27	feature	Open-air; Lake shore	\N	4	1	-754	\N	C	2019-12-20 22:14:28.053842+00	3139
753	27	feature	Open-air; Lake shore	\N	4	1	-753	\N	C	2019-12-20 22:14:28.053842+00	3140
752	27	feature	Open-air; Lake shore	\N	4	1	-752	\N	C	2019-12-20 22:14:28.053842+00	3141
751	27	feature	Open-air; Lake shore	\N	4	1	-751	\N	C	2019-12-20 22:14:28.053842+00	3142
750	27	feature	Open-air; Lake shore	\N	4	1	-750	\N	C	2019-12-20 22:14:28.053842+00	3143
749	27	feature	Open-air; Lake shore	\N	4	1	-749	\N	C	2019-12-20 22:14:28.053842+00	3144
748	27	feature	Open-air; Lake shore	\N	4	1	-748	\N	C	2019-12-20 22:14:28.053842+00	3145
747	27	feature	Open-air; Lake shore	\N	4	1	-747	\N	C	2019-12-20 22:14:28.053842+00	3146
746	27	feature	Open-air; Lake shore	\N	4	1	-746	\N	C	2019-12-20 22:14:28.053842+00	3147
745	27	feature	Open-air; Lake shore	\N	4	1	-745	\N	C	2019-12-20 22:14:28.053842+00	3148
744	27	feature	Open-air; Lake shore	\N	4	1	-744	\N	C	2019-12-20 22:14:28.053842+00	3149
743	27	feature	Open-air; Lake shore	\N	4	1	-743	\N	C	2019-12-20 22:14:28.053842+00	3150
742	27	feature	Open-air; Lake shore	\N	4	1	-742	\N	C	2019-12-20 22:14:28.053842+00	3151
741	27	feature	Open-air; Lake shore	\N	4	1	-741	\N	C	2019-12-20 22:14:28.053842+00	3152
740	27	feature	Open-air; Lake shore	\N	4	1	-740	\N	C	2019-12-20 22:14:28.053842+00	3153
739	27	feature	Open-air; Lake shore	\N	4	1	-739	\N	C	2019-12-20 22:14:28.053842+00	3154
738	27	feature	Open-air; Lake shore	\N	4	1	-738	\N	C	2019-12-20 22:14:28.053842+00	3155
737	27	feature	Open-air; Lake shore	\N	4	1	-737	\N	C	2019-12-20 22:14:28.053842+00	3156
736	27	feature	Open-air; Lake shore	\N	4	1	-736	\N	C	2019-12-20 22:14:28.053842+00	3157
735	27	feature	Open-air; Lake shore	\N	4	1	-735	\N	C	2019-12-20 22:14:28.053842+00	3158
734	27	feature	Open-air; Lake shore	\N	4	1	-734	\N	C	2019-12-20 22:14:28.053842+00	3159
733	27	feature	Open-air; Lake shore	\N	4	1	-733	\N	C	2019-12-20 22:14:28.053842+00	3160
732	27	feature	Open-air; Lake shore	\N	4	1	-732	\N	C	2019-12-20 22:14:28.053842+00	3161
731	27	feature	Open-air; Lake shore	\N	4	1	-731	\N	C	2019-12-20 22:14:28.053842+00	3162
730	27	feature	Open-air; Lake shore	\N	4	1	-730	\N	C	2019-12-20 22:14:28.053842+00	3163
729	27	feature	Open-air; Lake shore	\N	4	1	-729	\N	C	2019-12-20 22:14:28.053842+00	3164
728	27	feature	Open-air; Lake shore	\N	4	1	-728	\N	C	2019-12-20 22:14:28.053842+00	3165
727	27	feature	Open-air; Lake shore	\N	4	1	-727	\N	C	2019-12-20 22:14:28.053842+00	3166
726	27	feature	Open-air; Lake shore	\N	4	1	-726	\N	C	2019-12-20 22:14:28.053842+00	3167
725	27	feature	Open-air; Lake shore	\N	4	1	-725	\N	C	2019-12-20 22:14:28.053842+00	3168
724	27	feature	Open-air; Lake shore	\N	4	1	-724	\N	C	2019-12-20 22:14:28.053842+00	3169
723	27	feature	Open-air; Lake shore	\N	4	1	-723	\N	C	2019-12-20 22:14:28.053842+00	3170
722	27	feature	Open-air; Lake shore	\N	4	1	-722	\N	C	2019-12-20 22:14:28.053842+00	3171
721	27	feature	Open-air; Lake shore	\N	4	1	-721	\N	C	2019-12-20 22:14:28.053842+00	3172
720	27	feature	Open-air; Lake shore	\N	4	1	-720	\N	C	2019-12-20 22:14:28.053842+00	3173
719	27	feature	Open-air; Lake shore	\N	4	1	-719	\N	C	2019-12-20 22:14:28.053842+00	3174
718	27	feature	Open-air; Lake shore	\N	4	1	-718	\N	C	2019-12-20 22:14:28.053842+00	3175
717	27	feature	Open-air; Lake shore	\N	4	1	-717	\N	C	2019-12-20 22:14:28.053842+00	3176
716	27	feature	Open-air; Lake shore	\N	4	1	-716	\N	C	2019-12-20 22:14:28.053842+00	3177
715	27	feature	Open-air; Lake shore	\N	4	1	-715	\N	C	2019-12-20 22:14:28.053842+00	3178
714	27	feature	Open-air; Lake shore	\N	4	1	-714	\N	C	2019-12-20 22:14:28.053842+00	3179
713	27	feature	Open-air; Lake shore	\N	4	1	-713	\N	C	2019-12-20 22:14:28.053842+00	3180
712	27	feature	Open-air; Lake shore	\N	4	1	-712	\N	C	2019-12-20 22:14:28.053842+00	3181
711	27	feature	Open-air; Lake shore	\N	4	1	-711	\N	C	2019-12-20 22:14:28.053842+00	3182
710	27	feature	Open-air; Lake shore	\N	4	1	-710	\N	C	2019-12-20 22:14:28.053842+00	3183
709	27	feature	Open-air; Lake shore	\N	4	1	-709	\N	C	2019-12-20 22:14:28.053842+00	3184
708	27	feature	Open-air; Lake shore	\N	4	1	-708	\N	C	2019-12-20 22:14:28.053842+00	3185
707	27	feature	Open-air; Lake shore	\N	4	1	-707	\N	C	2019-12-20 22:14:28.053842+00	3186
706	27	feature	Open-air; Lake shore	\N	4	1	-706	\N	C	2019-12-20 22:14:28.053842+00	3187
705	27	feature	Open-air; Lake shore	\N	4	1	-705	\N	C	2019-12-20 22:14:28.053842+00	3188
704	27	feature	Open-air; Lake shore	\N	4	1	-704	\N	C	2019-12-20 22:14:28.053842+00	3189
703	27	feature	Open-air; Lake shore	\N	4	1	-703	\N	C	2019-12-20 22:14:28.053842+00	3190
702	27	feature	Open-air; Lake shore	\N	4	1	-702	\N	C	2019-12-20 22:14:28.053842+00	3191
701	27	feature	Open-air; Lake shore	\N	4	1	-701	\N	C	2019-12-20 22:14:28.053842+00	3192
700	27	feature	Open-air; Lake shore	\N	4	1	-700	\N	C	2019-12-20 22:14:28.053842+00	3193
699	27	feature	Open-air; Close to the coast	\N	4	1	-699	\N	C	2019-12-20 22:14:28.053842+00	3194
698	27	feature	Open-air; Close to the coast	\N	4	1	-698	\N	C	2019-12-20 22:14:28.053842+00	3195
697	27	feature	Open-air; Close to the coast	\N	4	1	-697	\N	C	2019-12-20 22:14:28.053842+00	3196
696	27	feature	Open-air; Close to the coast	\N	4	1	-696	\N	C	2019-12-20 22:14:28.053842+00	3197
695	27	feature	Open-air; Close to the coast	\N	4	1	-695	\N	C	2019-12-20 22:14:28.053842+00	3198
694	27	feature	Open-air; Close to the coast	\N	4	1	-694	\N	C	2019-12-20 22:14:28.053842+00	3199
693	27	feature	Open-air; Close to the coast	\N	4	1	-693	\N	C	2019-12-20 22:14:28.053842+00	3200
692	27	feature	Open-air; Close to the coast	\N	4	1	-692	\N	C	2019-12-20 22:14:28.053842+00	3201
691	27	feature	Open-air; Close to the coast	\N	4	1	-691	\N	C	2019-12-20 22:14:28.053842+00	3202
690	27	feature	Open-air; Close to the coast	\N	4	1	-690	\N	C	2019-12-20 22:14:28.053842+00	3203
689	27	feature	Open-air; Close to the coast	\N	4	1	-689	\N	C	2019-12-20 22:14:28.053842+00	3204
688	27	feature	Open-air; Close to the coast	\N	4	1	-688	\N	C	2019-12-20 22:14:28.053842+00	3205
687	27	feature	Open-air; Close to the coast	\N	4	1	-687	\N	C	2019-12-20 22:14:28.053842+00	3206
686	27	feature	Open-air; Close to the coast	\N	4	1	-686	\N	C	2019-12-20 22:14:28.053842+00	3207
685	27	feature	Open-air; Close to the coast	\N	4	1	-685	\N	C	2019-12-20 22:14:28.053842+00	3208
684	27	feature	Open-air; Close to the coast	\N	4	1	-684	\N	C	2019-12-20 22:14:28.053842+00	3209
683	27	feature	Open-air; Close to the coast	\N	4	1	-683	\N	C	2019-12-20 22:14:28.053842+00	3210
682	27	feature	Open-air; Close to the coast	\N	4	1	-682	\N	C	2019-12-20 22:14:28.053842+00	3211
681	27	feature	Open-air; Close to the coast	\N	4	1	-681	\N	C	2019-12-20 22:14:28.053842+00	3212
680	27	feature	Open-air; Close to the coast	\N	4	1	-680	\N	C	2019-12-20 22:14:28.053842+00	3213
679	27	feature	Open-air; Close to the coast	\N	4	1	-679	\N	C	2019-12-20 22:14:28.053842+00	3214
678	27	feature	Open-air; Close to the coast	\N	4	1	-678	\N	C	2019-12-20 22:14:28.053842+00	3215
677	27	feature	Open-air; Close to the coast	\N	4	1	-677	\N	C	2019-12-20 22:14:28.053842+00	3216
676	12	feature	Shell midden; Inland	\N	4	1	-676	\N	C	2019-12-20 22:14:28.053842+00	3217
675	12	feature	Shell midden; Inland	\N	4	1	-675	\N	C	2019-12-20 22:14:28.053842+00	3218
674	12	feature	Shell midden; Inland	\N	4	1	-674	\N	C	2019-12-20 22:14:28.053842+00	3219
673	12	feature	Shell midden; Inland	\N	4	1	-673	\N	C	2019-12-20 22:14:28.053842+00	3220
672	12	feature	Shell midden; Inland	\N	4	1	-672	\N	C	2019-12-20 22:14:28.053842+00	3221
671	12	feature	Shell midden; Inland	\N	4	1	-671	\N	C	2019-12-20 22:14:28.053842+00	3222
670	12	feature	Shell midden; Inland	\N	4	1	-670	\N	C	2019-12-20 22:14:28.053842+00	3223
669	12	feature	Shell midden; Inland	\N	4	1	-669	\N	C	2019-12-20 22:14:28.053842+00	3224
668	12	feature	Shell midden; Inland	\N	4	1	-668	\N	C	2019-12-20 22:14:28.053842+00	3225
667	12	feature	Shell midden; Inland	\N	4	1	-667	\N	C	2019-12-20 22:14:28.053842+00	3226
666	12	feature	Shell midden; Inland	\N	4	1	-666	\N	C	2019-12-20 22:14:28.053842+00	3227
665	12	feature	Shell midden; Inland	\N	4	1	-665	\N	C	2019-12-20 22:14:28.053842+00	3228
664	12	feature	Shell midden; Inland	\N	4	1	-664	\N	C	2019-12-20 22:14:28.053842+00	3229
663	12	feature	Shell midden; Inland	\N	4	1	-663	\N	C	2019-12-20 22:14:28.053842+00	3230
662	12	feature	Shell midden; Inland	\N	4	1	-662	\N	C	2019-12-20 22:14:28.053842+00	3231
661	12	feature	Shell midden; Inland	\N	4	1	-661	\N	C	2019-12-20 22:14:28.053842+00	3232
660	12	feature	Shell midden; Inland	\N	4	1	-660	\N	C	2019-12-20 22:14:28.053842+00	3233
659	12	feature	Shell midden; Inland	\N	4	1	-659	\N	C	2019-12-20 22:14:28.053842+00	3234
658	12	feature	Shell midden; Inland	\N	4	1	-658	\N	C	2019-12-20 22:14:28.053842+00	3235
657	12	feature	Shell midden; Inland	\N	4	1	-657	\N	C	2019-12-20 22:14:28.053842+00	3236
656	12	feature	Shell midden; Inland	\N	4	1	-656	\N	C	2019-12-20 22:14:28.053842+00	3237
655	12	feature	Shell midden; Inland	\N	4	1	-655	\N	C	2019-12-20 22:14:28.053842+00	3238
654	12	feature	Shell midden; Inland	\N	4	1	-654	\N	C	2019-12-20 22:14:28.053842+00	3239
653	12	feature	Shell midden; Inland	\N	4	1	-653	\N	C	2019-12-20 22:14:28.053842+00	3240
652	12	feature	Shell midden; Inland	\N	4	1	-652	\N	C	2019-12-20 22:14:28.053842+00	3241
651	12	feature	Shell midden; Inland	\N	4	1	-651	\N	C	2019-12-20 22:14:28.053842+00	3242
650	12	feature	Shell midden; Inland	\N	4	1	-650	\N	C	2019-12-20 22:14:28.053842+00	3243
649	12	feature	Shell midden; Inland	\N	4	1	-649	\N	C	2019-12-20 22:14:28.053842+00	3244
648	12	feature	Shell midden; Inland	\N	4	1	-648	\N	C	2019-12-20 22:14:28.053842+00	3245
647	12	feature	Shell midden; Inland	\N	4	1	-647	\N	C	2019-12-20 22:14:28.053842+00	3246
646	12	feature	Shell midden; Inland	\N	4	1	-646	\N	C	2019-12-20 22:14:28.053842+00	3247
645	12	feature	Shell midden; Inland	\N	4	1	-645	\N	C	2019-12-20 22:14:28.053842+00	3248
644	12	feature	Shell midden; Inland	\N	4	1	-644	\N	C	2019-12-20 22:14:28.053842+00	3249
643	12	feature	Shell midden; Inland	\N	4	1	-643	\N	C	2019-12-20 22:14:28.053842+00	3250
642	12	feature	Shell midden; Inland	\N	4	1	-642	\N	C	2019-12-20 22:14:28.053842+00	3251
641	12	feature	Shell midden; Inland	\N	4	1	-641	\N	C	2019-12-20 22:14:28.053842+00	3252
640	12	feature	Shell midden; Inland	\N	4	1	-640	\N	C	2019-12-20 22:14:28.053842+00	3253
639	12	feature	Shell midden; Inland	\N	4	1	-639	\N	C	2019-12-20 22:14:28.053842+00	3254
638	12	feature	Shell midden; Inland	\N	4	1	-638	\N	C	2019-12-20 22:14:28.053842+00	3255
637	12	feature	Shell midden; Inland	\N	4	1	-637	\N	C	2019-12-20 22:14:28.053842+00	3256
636	12	feature	Shell midden; Inland	\N	4	1	-636	\N	C	2019-12-20 22:14:28.053842+00	3257
635	12	feature	Shell midden; Inland	\N	4	1	-635	\N	C	2019-12-20 22:14:28.053842+00	3258
634	12	feature	Shell midden; Inland	\N	4	1	-634	\N	C	2019-12-20 22:14:28.053842+00	3259
633	12	feature	Shell midden; Inland	\N	4	1	-633	\N	C	2019-12-20 22:14:28.053842+00	3260
632	12	feature	Shell midden; Inland	\N	4	1	-632	\N	C	2019-12-20 22:14:28.053842+00	3261
631	12	feature	Shell midden; Inland	\N	4	1	-631	\N	C	2019-12-20 22:14:28.053842+00	3262
630	12	feature	Shell midden; Inland	\N	4	1	-630	\N	C	2019-12-20 22:14:28.053842+00	3263
629	12	feature	Shell midden; Inland	\N	4	1	-629	\N	C	2019-12-20 22:14:28.053842+00	3264
628	12	feature	Shell midden; Inland	\N	4	1	-628	\N	C	2019-12-20 22:14:28.053842+00	3265
627	12	feature	Shell midden; Inland	\N	4	1	-627	\N	C	2019-12-20 22:14:28.053842+00	3266
626	12	feature	Shell midden; Inland	\N	4	1	-626	\N	C	2019-12-20 22:14:28.053842+00	3267
625	12	feature	Shell midden; Inland	\N	4	1	-625	\N	C	2019-12-20 22:14:28.053842+00	3268
624	12	feature	Shell midden; Inland	\N	4	1	-624	\N	C	2019-12-20 22:14:28.053842+00	3269
623	12	feature	Shell midden; Inland	\N	4	1	-623	\N	C	2019-12-20 22:14:28.053842+00	3270
622	12	feature	Shell midden; Inland	\N	4	1	-622	\N	C	2019-12-20 22:14:28.053842+00	3271
621	12	feature	Shell midden; Inland	\N	4	1	-621	\N	C	2019-12-20 22:14:28.053842+00	3272
620	12	feature	Shell midden; Inland	\N	4	1	-620	\N	C	2019-12-20 22:14:28.053842+00	3273
619	12	feature	Shell midden; Inland	\N	4	1	-619	\N	C	2019-12-20 22:14:28.053842+00	3274
618	12	feature	Shell midden; Inland	\N	4	1	-618	\N	C	2019-12-20 22:14:28.053842+00	3275
617	12	feature	Shell midden; Inland	\N	4	1	-617	\N	C	2019-12-20 22:14:28.053842+00	3276
616	12	feature	Shell midden; Inland	\N	4	1	-616	\N	C	2019-12-20 22:14:28.053842+00	3277
615	12	feature	Shell midden; Inland	\N	4	1	-615	\N	C	2019-12-20 22:14:28.053842+00	3278
614	12	feature	Shell midden; Inland	\N	4	1	-614	\N	C	2019-12-20 22:14:28.053842+00	3279
613	12	feature	Shell midden; Close to the coast	\N	4	1	-613	\N	C	2019-12-20 22:14:28.053842+00	3280
612	12	feature	Shell midden; Close to the coast	\N	4	1	-612	\N	C	2019-12-20 22:14:28.053842+00	3281
611	12	feature	Shell midden; Close to the coast	\N	4	1	-611	\N	C	2019-12-20 22:14:28.053842+00	3282
610	12	feature	Shell midden; Close to the coast	\N	4	1	-610	\N	C	2019-12-20 22:14:28.053842+00	3283
609	12	feature	Shell midden; Close to the coast	\N	4	1	-609	\N	C	2019-12-20 22:14:28.053842+00	3284
608	12	feature	Shell midden; Close to the coast	\N	4	1	-608	\N	C	2019-12-20 22:14:28.053842+00	3285
607	12	feature	Shell midden; Close to the coast	\N	4	1	-607	\N	C	2019-12-20 22:14:28.053842+00	3286
606	12	feature	Shell midden; Close to the coast	\N	4	1	-606	\N	C	2019-12-20 22:14:28.053842+00	3287
605	12	feature	Shell midden; Close to the coast	\N	4	1	-605	\N	C	2019-12-20 22:14:28.053842+00	3288
604	12	feature	Shell midden; Close to the coast	\N	4	1	-604	\N	C	2019-12-20 22:14:28.053842+00	3289
603	12	feature	Shell midden; Close to the coast	\N	4	1	-603	\N	C	2019-12-20 22:14:28.053842+00	3290
602	12	feature	Shell midden; Close to the coast	\N	4	1	-602	\N	C	2019-12-20 22:14:28.053842+00	3291
601	12	feature	Shell midden; Close to the coast	\N	4	1	-601	\N	C	2019-12-20 22:14:28.053842+00	3292
600	12	feature	Shell midden; Close to the coast	\N	4	1	-600	\N	C	2019-12-20 22:14:28.053842+00	3293
599	12	feature	Shell midden; Close to the coast	\N	4	1	-599	\N	C	2019-12-20 22:14:28.053842+00	3294
598	12	feature	Shell midden; Close to the coast	\N	4	1	-598	\N	C	2019-12-20 22:14:28.053842+00	3295
597	27	feature	Open-air; Close to the coast	\N	4	1	-597	\N	C	2019-12-20 22:14:28.053842+00	3296
596	27	feature	Open-air; Close to the coast	\N	4	1	-596	\N	C	2019-12-20 22:14:28.053842+00	3297
595	27	feature	Open-air; Close to the coast	\N	4	1	-595	\N	C	2019-12-20 22:14:28.053842+00	3298
594	27	feature	Open-air; Close to the coast	\N	4	1	-594	\N	C	2019-12-20 22:14:28.053842+00	3299
593	27	feature	Open-air; Close to the coast	\N	4	1	-593	\N	C	2019-12-20 22:14:28.053842+00	3300
592	27	feature	Open-air; Close to the coast	\N	4	1	-592	\N	C	2019-12-20 22:14:28.053842+00	3301
591	27	feature	Open-air; Close to the coast	\N	4	1	-591	\N	C	2019-12-20 22:14:28.053842+00	3302
1	517	Feature	\N	\N	3	1	-1	\N	C	2019-12-20 22:14:19.067462+00	2948
2	516	Feature	\N	\N	3	1	-2	\N	C	2019-12-20 22:14:19.067462+00	2947
3	506	Feature	\N	\N	3	1	-3	\N	C	2019-12-20 22:14:19.067462+00	2946
4	545	Feature No. 6	\N	\N	3	1	-4	\N	C	2019-12-20 22:14:19.067462+00	2945
5	550	Feature	\N	\N	3	1	-5	\N	C	2019-12-20 22:14:19.067462+00	2944
6	525	Feature	\N	\N	3	1	-6	\N	C	2019-12-20 22:14:19.067462+00	2943
7	539	Feature	\N	\N	3	1	-7	\N	C	2019-12-20 22:14:19.067462+00	2942
8	544	Feature	\N	\N	3	1	-8	\N	C	2019-12-20 22:14:19.067462+00	2941
9	527	Feature No. Ho 101	\N	\N	3	1	-9	\N	C	2019-12-20 22:14:19.067462+00	2940
10	527	Feature No. Ho 101:2	\N	\N	3	1	-10	\N	C	2019-12-20 22:14:19.067462+00	2939
11	527	Feature No. Ho 105	\N	\N	3	1	-11	\N	C	2019-12-20 22:14:19.067462+00	2938
12	527	Feature No. Ho 106	\N	\N	3	1	-12	\N	C	2019-12-20 22:14:19.067462+00	2937
13	538	Feature No. Ho 120	\N	\N	3	1	-13	\N	C	2019-12-20 22:14:19.067462+00	2936
14	515	Feature No. Ho 130	\N	\N	3	1	-14	\N	C	2019-12-20 22:14:19.067462+00	2935
15	521	Feature No. Ho 133	\N	\N	3	1	-15	\N	C	2019-12-20 22:14:19.067462+00	2934
16	538	Feature No. Ho 145	\N	\N	3	1	-16	\N	C	2019-12-20 22:14:19.067462+00	2933
17	527	Feature No. Ho 149	\N	\N	3	1	-17	\N	C	2019-12-20 22:14:19.067462+00	2932
18	519	Feature No. Ho 152	\N	\N	3	1	-18	\N	C	2019-12-20 22:14:19.067462+00	2931
19	531	Feature	\N	\N	3	1	-19	\N	C	2019-12-20 22:14:19.067462+00	2930
20	544	Feature	\N	\N	3	1	-20	\N	C	2019-12-20 22:14:19.067462+00	2929
21	550	Feature	\N	\N	3	1	-21	\N	C	2019-12-20 22:14:19.067462+00	2928
22	543	Context ID 12672	\N	\N	3	1	-22	\N	C	2019-12-20 22:14:19.067462+00	2927
23	513	Context ID 12717	\N	\N	3	1	-23	\N	C	2019-12-20 22:14:19.067462+00	2926
24	513	Context ID 12773	\N	\N	3	1	-24	\N	C	2019-12-20 22:14:19.067462+00	2925
25	513	Context ID 14341	\N	\N	3	1	-25	\N	C	2019-12-20 22:14:19.067462+00	2924
26	514	Context ID 14525	\N	\N	3	1	-26	\N	C	2019-12-20 22:14:19.067462+00	2923
27	550	Context ID 15963	\N	\N	3	1	-27	\N	C	2019-12-20 22:14:19.067462+00	2922
28	546	Context ID 16989	\N	\N	3	1	-28	\N	C	2019-12-20 22:14:19.067462+00	2921
29	514	Context ID 18018	\N	\N	3	1	-29	\N	C	2019-12-20 22:14:19.067462+00	2920
30	520	Context ID 18641	\N	\N	3	1	-30	\N	C	2019-12-20 22:14:19.067462+00	2919
31	512	Context ID 18700	\N	\N	3	1	-31	\N	C	2019-12-20 22:14:19.067462+00	2918
32	543	Context ID 19155	\N	\N	3	1	-32	\N	C	2019-12-20 22:14:19.067462+00	2917
33	520	Context ID 19468	\N	\N	3	1	-33	\N	C	2019-12-20 22:14:19.067462+00	2916
34	550	Context ID 21495	\N	\N	3	1	-34	\N	C	2019-12-20 22:14:19.067462+00	2915
35	550	Context ID 21758	\N	\N	3	1	-35	\N	C	2019-12-20 22:14:19.067462+00	2914
36	514	Context ID 21996	\N	\N	3	1	-36	\N	C	2019-12-20 22:14:19.067462+00	2913
37	514	Context ID 22826	\N	\N	3	1	-37	\N	C	2019-12-20 22:14:19.067462+00	2912
38	520	Context ID 23051	\N	\N	3	1	-38	\N	C	2019-12-20 22:14:19.067462+00	2911
39	516	Context ID 23586	\N	\N	3	1	-39	\N	C	2019-12-20 22:14:19.067462+00	2910
40	543	Context ID 24220	\N	\N	3	1	-40	\N	C	2019-12-20 22:14:19.067462+00	2909
41	32	Context ID 26470	\N	\N	3	1	-41	\N	C	2019-12-20 22:14:19.067462+00	2908
42	550	Context ID 26470	\N	\N	3	1	-42	\N	C	2019-12-20 22:14:19.067462+00	2907
43	543	Context ID 27832	\N	\N	3	1	-43	\N	C	2019-12-20 22:14:19.067462+00	2906
44	512	Context ID 27955	\N	\N	3	1	-44	\N	C	2019-12-20 22:14:19.067462+00	2905
45	514	Context ID 27984	\N	\N	3	1	-45	\N	C	2019-12-20 22:14:19.067462+00	2904
46	539	Context ID 29004	\N	\N	3	1	-46	\N	C	2019-12-20 22:14:19.067462+00	2903
47	514	Context ID 29228	\N	\N	3	1	-47	\N	C	2019-12-20 22:14:19.067462+00	2902
590	27	feature	Open-air; Close to the coast	\N	4	1	-590	\N	C	2019-12-20 22:14:28.053842+00	3303
589	27	feature	Open-air; Close to the coast	\N	4	1	-589	\N	C	2019-12-20 22:14:28.053842+00	3304
588	27	feature	Open-air; Close to the coast	\N	4	1	-588	\N	C	2019-12-20 22:14:28.053842+00	3305
587	27	feature	Open-air; Close to the coast	\N	4	1	-587	\N	C	2019-12-20 22:14:28.053842+00	3306
586	27	feature	Open-air; Close to the coast	\N	4	1	-586	\N	C	2019-12-20 22:14:28.053842+00	3307
585	27	feature	Open-air; Close to the coast	\N	4	1	-585	\N	C	2019-12-20 22:14:28.053842+00	3308
584	27	feature	Open-air; Close to the coast	\N	4	1	-584	\N	C	2019-12-20 22:14:28.053842+00	3309
583	27	feature	Open-air; Close to the coast	\N	4	1	-583	\N	C	2019-12-20 22:14:28.053842+00	3310
582	27	feature	Open-air; Close to the coast	\N	4	1	-582	\N	C	2019-12-20 22:14:28.053842+00	3311
581	27	feature	Open-air; Close to the coast	\N	4	1	-581	\N	C	2019-12-20 22:14:28.053842+00	3312
580	27	feature	Open-air; Close to the coast	\N	4	1	-580	\N	C	2019-12-20 22:14:28.053842+00	3313
579	27	feature	Open-air; Close to the coast	\N	4	1	-579	\N	C	2019-12-20 22:14:28.053842+00	3314
578	27	feature	Open-air; Close to the coast	\N	4	1	-578	\N	C	2019-12-20 22:14:28.053842+00	3315
577	27	feature	Open-air; Close to the coast	\N	4	1	-577	\N	C	2019-12-20 22:14:28.053842+00	3316
576	27	feature	Open-air; Close to the coast	\N	4	1	-576	\N	C	2019-12-20 22:14:28.053842+00	3317
575	27	feature	Open-air; Close to the coast	\N	4	1	-575	\N	C	2019-12-20 22:14:28.053842+00	3318
574	27	feature	Open-air; Close to the coast	\N	4	1	-574	\N	C	2019-12-20 22:14:28.053842+00	3319
573	27	feature	Open-air; Close to the coast	\N	4	1	-573	\N	C	2019-12-20 22:14:28.053842+00	3320
572	27	feature	Open-air; Close to the coast	\N	4	1	-572	\N	C	2019-12-20 22:14:28.053842+00	3321
571	27	feature	Open-air; Close to the coast	\N	4	1	-571	\N	C	2019-12-20 22:14:28.053842+00	3322
570	27	feature	Open-air; Close to the coast	\N	4	1	-570	\N	C	2019-12-20 22:14:28.053842+00	3323
569	27	feature	Open-air; Close to the coast	\N	4	1	-569	\N	C	2019-12-20 22:14:28.053842+00	3324
568	27	feature	Open-air; Close to the coast	\N	4	1	-568	\N	C	2019-12-20 22:14:28.053842+00	3325
567	27	feature	Open-air; Close to the coast	\N	4	1	-567	\N	C	2019-12-20 22:14:28.053842+00	3326
566	27	feature	Open-air; Close to the coast	\N	4	1	-566	\N	C	2019-12-20 22:14:28.053842+00	3327
565	27	feature	Open-air; Close to the coast	\N	4	1	-565	\N	C	2019-12-20 22:14:28.053842+00	3328
564	27	feature	Open-air; Close to the coast	\N	4	1	-564	\N	C	2019-12-20 22:14:28.053842+00	3329
563	27	feature	Open-air; Close to the coast	\N	4	1	-563	\N	C	2019-12-20 22:14:28.053842+00	3330
562	27	feature	Open-air; Close to the coast	\N	4	1	-562	\N	C	2019-12-20 22:14:28.053842+00	3331
63	27	feature	Open-air; Close to the coast	\N	4	1	-63	\N	C	2019-12-20 22:14:28.053842+00	3830
62	27	feature	Open-air; Close to the coast	\N	4	1	-62	\N	C	2019-12-20 22:14:28.053842+00	3831
61	27	feature	Open-air; Close to the coast	\N	4	1	-61	\N	C	2019-12-20 22:14:28.053842+00	3832
60	27	feature	Open-air; Close to the coast	\N	4	1	-60	\N	C	2019-12-20 22:14:28.053842+00	3833
59	27	feature	Open-air; Close to the coast	\N	4	1	-59	\N	C	2019-12-20 22:14:28.053842+00	3834
58	27	feature	Open-air; Close to the coast	\N	4	1	-58	\N	C	2019-12-20 22:14:28.053842+00	3835
57	27	feature	Open-air; Close to the coast	\N	4	1	-57	\N	C	2019-12-20 22:14:28.053842+00	3836
56	27	feature	Open-air; Close to the coast	\N	4	1	-56	\N	C	2019-12-20 22:14:28.053842+00	3837
55	27	feature	Open-air; Close to the coast	\N	4	1	-55	\N	C	2019-12-20 22:14:28.053842+00	3838
54	27	feature	Open-air; Close to the coast	\N	4	1	-54	\N	C	2019-12-20 22:14:28.053842+00	3839
53	27	feature	Open-air; Close to the coast	\N	4	1	-53	\N	C	2019-12-20 22:14:28.053842+00	3840
52	27	feature	Open-air; Close to the coast	\N	4	1	-52	\N	C	2019-12-20 22:14:28.053842+00	3841
51	27	feature	Open-air; Close to the coast	\N	4	1	-51	\N	C	2019-12-20 22:14:28.053842+00	3842
50	27	feature	Open-air; Close to the coast	\N	4	1	-50	\N	C	2019-12-20 22:14:28.053842+00	3843
49	27	feature	Open-air; Close to the coast	\N	4	1	-49	\N	C	2019-12-20 22:14:28.053842+00	3844
48	27	feature	Open-air; Close to the coast	\N	4	1	-48	\N	C	2019-12-20 22:14:28.053842+00	3845
47	27	feature	Open-air; Close to the coast	\N	4	1	-47	\N	C	2019-12-20 22:14:28.053842+00	3846
46	27	feature	Open-air; Close to the coast	\N	4	1	-46	\N	C	2019-12-20 22:14:28.053842+00	3847
2948	551	Feature	\N	\N	1	1	-2948	\N	C	2019-12-20 22:13:53.799521+00	1832
2947	551	Feature	\N	\N	1	1	-2947	\N	C	2019-12-20 22:13:53.799521+00	1833
2946	6	Feature	\N	\N	1	1	-2946	\N	C	2019-12-20 22:13:53.799521+00	1834
2945	551	Feature	\N	\N	1	1	-2945	\N	C	2019-12-20 22:13:53.799521+00	1835
2944	551	Feature	\N	\N	1	1	-2944	\N	C	2019-12-20 22:13:53.799521+00	1836
2943	6	Feature	\N	\N	1	1	-2943	\N	C	2019-12-20 22:13:53.799521+00	1837
2942	551	Feature	\N	\N	1	1	-2942	\N	C	2019-12-20 22:13:53.799521+00	1838
2941	551	Feature	\N	\N	1	1	-2941	\N	C	2019-12-20 22:13:53.799521+00	1839
2940	551	Feature	\N	\N	1	1	-2940	\N	C	2019-12-20 22:13:53.799521+00	1840
2939	6	Feature	\N	\N	1	1	-2939	\N	C	2019-12-20 22:13:53.799521+00	1841
2938	551	A13	\N	\N	1	1	-2938	\N	C	2019-12-20 22:13:53.799521+00	1842
2937	551	2	\N	\N	1	1	-2937	\N	C	2019-12-20 22:13:53.799521+00	1843
2936	551	Feature	\N	\N	1	1	-2936	\N	C	2019-12-20 22:13:53.799521+00	1844
2935	551	A1	\N	\N	1	1	-2935	\N	C	2019-12-20 22:13:53.799521+00	1845
2934	551	Feature	\N	\N	1	1	-2934	\N	C	2019-12-20 22:13:53.799521+00	1846
2933	6	Feature	\N	\N	1	1	-2933	\N	C	2019-12-20 22:13:53.799521+00	1847
2932	551	Feature	\N	\N	1	1	-2932	\N	C	2019-12-20 22:13:53.799521+00	1848
2931	551	Feature	\N	\N	1	1	-2931	\N	C	2019-12-20 22:13:53.799521+00	1849
2930	6	Feature	\N	\N	1	1	-2930	\N	C	2019-12-20 22:13:53.799521+00	1850
2929	551	Feature	\N	\N	1	1	-2929	\N	C	2019-12-20 22:13:53.799521+00	1851
2928	551	Feature	\N	\N	1	1	-2928	\N	C	2019-12-20 22:13:53.799521+00	1852
2927	551	Feature	\N	\N	1	1	-2927	\N	C	2019-12-20 22:13:53.799521+00	1853
2926	567	305	\N	\N	1	1	-2926	\N	C	2019-12-20 22:13:53.799521+00	1854
2925	567	21569	\N	\N	1	1	-2925	\N	C	2019-12-20 22:13:53.799521+00	1855
2924	567	3246	\N	\N	1	1	-2924	\N	C	2019-12-20 22:13:53.799521+00	1856
2923	567	G4051	\N	\N	1	1	-2923	\N	C	2019-12-20 22:13:53.799521+00	1857
2922	567	38551	\N	\N	1	1	-2922	\N	C	2019-12-20 22:13:53.799521+00	1858
2921	567	26216	\N	\N	1	1	-2921	\N	C	2019-12-20 22:13:53.799521+00	1859
2920	567	50912	\N	\N	1	1	-2920	\N	C	2019-12-20 22:13:53.799521+00	1860
2919	551	Feature	\N	\N	1	1	-2919	\N	C	2019-12-20 22:13:53.799521+00	1861
2918	557	707	\N	\N	1	1	-2918	\N	C	2019-12-20 22:13:53.799521+00	1862
2917	551	husgrupp 2	\N	\N	1	1	-2917	\N	C	2019-12-20 22:13:53.799521+00	1863
2916	551	husgrupp 3	\N	\N	1	1	-2916	\N	C	2019-12-20 22:13:53.799521+00	1864
2915	551	61512	\N	\N	1	1	-2915	\N	C	2019-12-20 22:13:53.799521+00	1865
2914	551	14179	\N	\N	1	1	-2914	\N	C	2019-12-20 22:13:53.799521+00	1866
2913	551	11981	\N	\N	1	1	-2913	\N	C	2019-12-20 22:13:53.799521+00	1867
2912	565	Feature	\N	\N	1	1	-2912	\N	C	2019-12-20 22:13:53.799521+00	1868
2911	6	12000	\N	\N	1	1	-2911	\N	C	2019-12-20 22:13:53.799521+00	1869
2910	6	6060	\N	\N	1	1	-2910	\N	C	2019-12-20 22:13:53.799521+00	1870
2909	6	12247	\N	\N	1	1	-2909	\N	C	2019-12-20 22:13:53.799521+00	1871
2908	6	I	\N	\N	1	1	-2908	\N	C	2019-12-20 22:13:53.799521+00	1872
2907	6	Feature	\N	\N	1	1	-2907	\N	C	2019-12-20 22:13:53.799521+00	1873
2906	6	II?	\N	\N	1	1	-2906	\N	C	2019-12-20 22:13:53.799521+00	1874
2905	551	Feature	\N	\N	1	1	-2905	\N	C	2019-12-20 22:13:53.799521+00	1875
2904	551	Feature	\N	\N	1	1	-2904	\N	C	2019-12-20 22:13:53.799521+00	1876
2903	557	14075	\N	\N	1	1	-2903	\N	C	2019-12-20 22:13:53.799521+00	1877
2902	557	19069	\N	\N	1	1	-2902	\N	C	2019-12-20 22:13:53.799521+00	1878
2901	557	8632	\N	\N	1	1	-2901	\N	C	2019-12-20 22:13:53.799521+00	1879
2900	557	15585	\N	\N	1	1	-2900	\N	C	2019-12-20 22:13:53.799521+00	1880
2899	557	9515	\N	\N	1	1	-2899	\N	C	2019-12-20 22:13:53.799521+00	1881
2898	557	300	\N	\N	1	1	-2898	\N	C	2019-12-20 22:13:53.799521+00	1882
2897	557	243	\N	\N	1	1	-2897	\N	C	2019-12-20 22:13:53.799521+00	1883
2896	557	200	\N	\N	1	1	-2896	\N	C	2019-12-20 22:13:53.799521+00	1884
2895	551	Feature	\N	\N	1	1	-2895	\N	C	2019-12-20 22:13:53.799521+00	1885
2894	551	Feature	\N	\N	1	1	-2894	\N	C	2019-12-20 22:13:53.799521+00	1886
2893	550	37	\N	\N	1	1	-2893	\N	C	2019-12-20 22:13:53.799521+00	1887
2892	565	Feature	\N	\N	1	1	-2892	\N	C	2019-12-20 22:13:53.799521+00	1888
2891	550	21	\N	\N	1	1	-2891	\N	C	2019-12-20 22:13:53.799521+00	1889
2890	550	11059	\N	\N	1	1	-2890	\N	C	2019-12-20 22:13:53.799521+00	1890
2889	551	34247	\N	\N	1	1	-2889	\N	C	2019-12-20 22:13:53.799521+00	1891
2888	551	5756	\N	\N	1	1	-2888	\N	C	2019-12-20 22:13:53.799521+00	1892
2887	550	426	\N	\N	1	1	-2887	\N	C	2019-12-20 22:13:53.799521+00	1893
2886	565	246	\N	\N	1	1	-2886	\N	C	2019-12-20 22:13:53.799521+00	1894
2885	550	256	\N	\N	1	1	-2885	\N	C	2019-12-20 22:13:53.799521+00	1895
2884	550	92	\N	\N	1	1	-2884	\N	C	2019-12-20 22:13:53.799521+00	1896
2883	551	2016	\N	\N	1	1	-2883	\N	C	2019-12-20 22:13:53.799521+00	1897
2882	551	2006	\N	\N	1	1	-2882	\N	C	2019-12-20 22:13:53.799521+00	1898
2881	551	12514	\N	\N	1	1	-2881	\N	C	2019-12-20 22:13:53.799521+00	1899
2880	551	20769	\N	\N	1	1	-2880	\N	C	2019-12-20 22:13:53.799521+00	1900
2879	551	47619	\N	\N	1	1	-2879	\N	C	2019-12-20 22:13:53.799521+00	1901
2878	551	11978	\N	\N	1	1	-2878	\N	C	2019-12-20 22:13:53.799521+00	1902
2877	551	21183	\N	\N	1	1	-2877	\N	C	2019-12-20 22:13:53.799521+00	1903
2876	551	14141	\N	\N	1	1	-2876	\N	C	2019-12-20 22:13:53.799521+00	1904
2875	551	Feature	\N	\N	1	1	-2875	\N	C	2019-12-20 22:13:53.799521+00	1905
2874	551	129048	\N	\N	1	1	-2874	\N	C	2019-12-20 22:13:53.799521+00	1906
2873	551	129048	\N	\N	1	1	-2873	\N	C	2019-12-20 22:13:53.799521+00	1907
2872	551	301127	\N	\N	1	1	-2872	\N	C	2019-12-20 22:13:53.799521+00	1908
2871	550	32778	\N	\N	1	1	-2871	\N	C	2019-12-20 22:13:53.799521+00	1909
2870	567	lösfynd	\N	\N	1	1	-2870	\N	C	2019-12-20 22:13:53.799521+00	1910
2869	567	21169	\N	\N	1	1	-2869	\N	C	2019-12-20 22:13:53.799521+00	1911
2868	567	26746	\N	\N	1	1	-2868	\N	C	2019-12-20 22:13:53.799521+00	1912
2867	567	31423	\N	\N	1	1	-2867	\N	C	2019-12-20 22:13:53.799521+00	1913
2866	557	20	\N	\N	1	1	-2866	\N	C	2019-12-20 22:13:53.799521+00	1914
2865	551	Feature	\N	\N	1	1	-2865	\N	C	2019-12-20 22:13:53.799521+00	1915
2864	551	75093	\N	\N	1	1	-2864	\N	C	2019-12-20 22:13:53.799521+00	1916
2863	551	88802	\N	\N	1	1	-2863	\N	C	2019-12-20 22:13:53.799521+00	1917
2862	551	88689	\N	\N	1	1	-2862	\N	C	2019-12-20 22:13:53.799521+00	1918
2861	551	L109	\N	\N	1	1	-2861	\N	C	2019-12-20 22:13:53.799521+00	1919
2860	551	83976	\N	\N	1	1	-2860	\N	C	2019-12-20 22:13:53.799521+00	1920
2859	551	7384	\N	\N	1	1	-2859	\N	C	2019-12-20 22:13:53.799521+00	1921
2858	551	5869	\N	\N	1	1	-2858	\N	C	2019-12-20 22:13:53.799521+00	1922
2857	551	60309	\N	\N	1	1	-2857	\N	C	2019-12-20 22:13:53.799521+00	1923
2856	551	8197	\N	\N	1	1	-2856	\N	C	2019-12-20 22:13:53.799521+00	1924
2855	551	L103	\N	\N	1	1	-2855	\N	C	2019-12-20 22:13:53.799521+00	1925
2854	551	6105	\N	\N	1	1	-2854	\N	C	2019-12-20 22:13:53.799521+00	1926
2853	565	Feature	\N	\N	1	1	-2853	\N	C	2019-12-20 22:13:53.799521+00	1927
2852	565	2148	\N	\N	1	1	-2852	\N	C	2019-12-20 22:13:53.799521+00	1928
2851	551	L107	\N	\N	1	1	-2851	\N	C	2019-12-20 22:13:53.799521+00	1929
2850	551	4093, A1:20	\N	\N	1	1	-2850	\N	C	2019-12-20 22:13:53.799521+00	1930
2849	551	4093:28, A1:34	\N	\N	1	1	-2849	\N	C	2019-12-20 22:13:53.799521+00	1931
2848	551	4093:28, A1:34	\N	\N	1	1	-2848	\N	C	2019-12-20 22:13:53.799521+00	1932
2847	551	4093:12, A1:24	\N	\N	1	1	-2847	\N	C	2019-12-20 22:13:53.799521+00	1933
2846	551	4093:12, A1:24	\N	\N	1	1	-2846	\N	C	2019-12-20 22:13:53.799521+00	1934
2845	550	Feature	\N	\N	1	1	-2845	\N	C	2019-12-20 22:13:53.799521+00	1935
2844	556	ugn	\N	\N	1	1	-2844	\N	C	2019-12-20 22:13:53.799521+00	1936
2843	556	slagghög	\N	\N	1	1	-2843	\N	C	2019-12-20 22:13:53.799521+00	1937
2842	556	lager	\N	\N	1	1	-2842	\N	C	2019-12-20 22:13:53.799521+00	1938
2841	551	Feature	\N	\N	1	1	-2841	\N	C	2019-12-20 22:13:53.799521+00	1939
2840	6	1949.2	\N	\N	1	1	-2840	\N	C	2019-12-20 22:13:53.799521+00	1940
2839	6	1954	\N	\N	1	1	-2839	\N	C	2019-12-20 22:13:53.799521+00	1941
2838	6	1875	\N	\N	1	1	-2838	\N	C	2019-12-20 22:13:53.799521+00	1942
2837	6	1949.1	\N	\N	1	1	-2837	\N	C	2019-12-20 22:13:53.799521+00	1943
2836	6	1980-22	\N	\N	1	1	-2836	\N	C	2019-12-20 22:13:53.799521+00	1944
2835	6	1978.2	\N	\N	1	1	-2835	\N	C	2019-12-20 22:13:53.799521+00	1945
2834	6	1978	\N	\N	1	1	-2834	\N	C	2019-12-20 22:13:53.799521+00	1946
2833	551	Feature	\N	\N	1	1	-2833	\N	C	2019-12-20 22:13:53.799521+00	1947
2832	551	mosse	\N	\N	1	1	-2832	\N	C	2019-12-20 22:13:53.799521+00	1948
2831	551	boplats	\N	\N	1	1	-2831	\N	C	2019-12-20 22:13:53.799521+00	1949
2830	551	Feature	\N	\N	1	1	-2830	\N	C	2019-12-20 22:13:53.799521+00	1950
2829	551	Feature	\N	\N	1	1	-2829	\N	C	2019-12-20 22:13:53.799521+00	1951
2828	551	12906	\N	\N	1	1	-2828	\N	C	2019-12-20 22:13:53.799521+00	1952
2827	551	15299	\N	\N	1	1	-2827	\N	C	2019-12-20 22:13:53.799521+00	1953
2826	551	6960	\N	\N	1	1	-2826	\N	C	2019-12-20 22:13:53.799521+00	1954
2825	551	15364	\N	\N	1	1	-2825	\N	C	2019-12-20 22:13:53.799521+00	1955
2824	551	14173	\N	\N	1	1	-2824	\N	C	2019-12-20 22:13:53.799521+00	1956
2823	551	14559	\N	\N	1	1	-2823	\N	C	2019-12-20 22:13:53.799521+00	1957
2822	551	14557	\N	\N	1	1	-2822	\N	C	2019-12-20 22:13:53.799521+00	1958
2821	551	Feature	\N	\N	1	1	-2821	\N	C	2019-12-20 22:13:53.799521+00	1959
2820	551	Feature	\N	\N	1	1	-2820	\N	C	2019-12-20 22:13:53.799521+00	1960
2819	551	Feature	\N	\N	1	1	-2819	\N	C	2019-12-20 22:13:53.799521+00	1961
2818	551	d	\N	\N	1	1	-2818	\N	C	2019-12-20 22:13:53.799521+00	1962
2817	551	e	\N	\N	1	1	-2817	\N	C	2019-12-20 22:13:53.799521+00	1963
2816	551	c	\N	\N	1	1	-2816	\N	C	2019-12-20 22:13:53.799521+00	1964
2815	551	Feature	\N	\N	1	1	-2815	\N	C	2019-12-20 22:13:53.799521+00	1965
2814	565	F gropsystem	\N	\N	1	1	-2814	\N	C	2019-12-20 22:13:53.799521+00	1966
2813	551	B norr	\N	\N	1	1	-2813	\N	C	2019-12-20 22:13:53.799521+00	1967
2812	551	E	\N	\N	1	1	-2812	\N	C	2019-12-20 22:13:53.799521+00	1968
2811	551	F 19830	\N	\N	1	1	-2811	\N	C	2019-12-20 22:13:53.799521+00	1969
2810	551	B terrass	\N	\N	1	1	-2810	\N	C	2019-12-20 22:13:53.799521+00	1970
2809	551	B krön	\N	\N	1	1	-2809	\N	C	2019-12-20 22:13:53.799521+00	1971
2808	551	B 20511	\N	\N	1	1	-2808	\N	C	2019-12-20 22:13:53.799521+00	1972
2807	551	B hus 9	\N	\N	1	1	-2807	\N	C	2019-12-20 22:13:53.799521+00	1973
2806	551	A	\N	\N	1	1	-2806	\N	C	2019-12-20 22:13:53.799521+00	1974
2805	565	Rålera	\N	\N	1	1	-2805	\N	C	2019-12-20 22:13:53.799521+00	1975
2804	551	Rabbig buk med org. beläggning	\N	\N	1	1	-2804	\N	C	2019-12-20 22:13:53.799521+00	1976
2803	551	Rabbig mynning med org. beläggning	\N	\N	1	1	-2803	\N	C	2019-12-20 22:13:53.799521+00	1977
2802	551	Tunnväggig keramik med org. beläggning	\N	\N	1	1	-2802	\N	C	2019-12-20 22:13:53.799521+00	1978
2801	551	Buk med triangulär grop	\N	\N	1	1	-2801	\N	C	2019-12-20 22:13:53.799521+00	1979
2800	551	Buk med konisk grop och vertikala streck	\N	\N	1	1	-2800	\N	C	2019-12-20 22:13:53.799521+00	1980
2799	551	Mynning med dubbelstämpel	\N	\N	1	1	-2799	\N	C	2019-12-20 22:13:53.799521+00	1981
2798	551	Feature	\N	\N	1	1	-2798	\N	C	2019-12-20 22:13:53.799521+00	1982
2797	551	Feature	\N	\N	1	1	-2797	\N	C	2019-12-20 22:13:53.799521+00	1983
2796	551	T5B:297	\N	\N	1	1	-2796	\N	C	2019-12-20 22:13:53.799521+00	1984
2795	6	gr XI,1	\N	\N	1	1	-2795	\N	C	2019-12-20 22:13:53.799521+00	1985
2794	563	A656	\N	\N	1	1	-2794	\N	C	2019-12-20 22:13:53.799521+00	1986
2793	551	2799	\N	\N	1	1	-2793	\N	C	2019-12-20 22:13:53.799521+00	1987
2792	551	13875	\N	\N	1	1	-2792	\N	C	2019-12-20 22:13:53.799521+00	1988
2791	567	Pit - Iron Age?\n	\N	\N	1	1	-2791	\N	C	2019-12-20 22:13:53.799521+00	1989
2790	6	Urn grave?\n	\N	\N	1	1	-2790	\N	C	2019-12-20 22:13:53.799521+00	1990
2789	567	Feature	\N	\N	1	1	-2789	\N	C	2019-12-20 22:13:53.799521+00	1991
2788	567	Irregular pit\n	\N	\N	1	1	-2788	\N	C	2019-12-20 22:13:53.799521+00	1992
2787	6	Urn-/Hoarse grave\n	\N	\N	1	1	-2787	\N	C	2019-12-20 22:13:53.799521+00	1993
2786	567	Posthole\n	\N	\N	1	1	-2786	\N	C	2019-12-20 22:13:53.799521+00	1994
2785	567	Culture layer\n	\N	\N	1	1	-2785	\N	C	2019-12-20 22:13:53.799521+00	1995
2784	6	Boat grave\n	\N	\N	1	1	-2784	\N	C	2019-12-20 22:13:53.799521+00	1996
2783	6	Skeleton grave\n	\N	\N	1	1	-2783	\N	C	2019-12-20 22:13:53.799521+00	1997
2782	6	Mound\n	\N	\N	1	1	-2782	\N	C	2019-12-20 22:13:53.799521+00	1998
2781	567	Hearth\n	\N	\N	1	1	-2781	\N	C	2019-12-20 22:13:53.799521+00	1999
2780	567	Pit and hearth\n	\N	\N	1	1	-2780	\N	C	2019-12-20 22:13:53.799521+00	2000
2779	567	Pit house?\n	\N	\N	1	1	-2779	\N	C	2019-12-20 22:13:53.799521+00	2001
2778	6	Cremation grave\n	\N	\N	1	1	-2778	\N	C	2019-12-20 22:13:53.799521+00	2002
2777	567	Pit-concentration\n	\N	\N	1	1	-2777	\N	C	2019-12-20 22:13:53.799521+00	2003
2776	567	Pit house\n	\N	\N	1	1	-2776	\N	C	2019-12-20 22:13:53.799521+00	2004
2775	567	Well?\n	\N	\N	1	1	-2775	\N	C	2019-12-20 22:13:53.799521+00	2005
2774	6	Urn grave\n	\N	\N	1	1	-2774	\N	C	2019-12-20 22:13:53.799521+00	2006
2773	567	Ditch\n	\N	\N	1	1	-2773	\N	C	2019-12-20 22:13:53.799521+00	2007
2772	6	Boat-/urn grave\n	\N	\N	1	1	-2772	\N	C	2019-12-20 22:13:53.799521+00	2008
2771	567	Pit\n	\N	\N	1	1	-2771	\N	C	2019-12-20 22:13:53.799521+00	2009
2770	567	Well\n	\N	\N	1	1	-2770	\N	C	2019-12-20 22:13:53.799521+00	2010
2769	567	Surface find\n	\N	\N	1	1	-2769	\N	C	2019-12-20 22:13:53.799521+00	2011
2768	557	Feature	\N	\N	1	1	-2768	\N	C	2019-12-20 22:13:53.799521+00	2012
2767	565	Feature	\N	\N	1	1	-2767	\N	C	2019-12-20 22:13:53.799521+00	2013
2766	565	Feature	\N	\N	1	1	-2766	\N	C	2019-12-20 22:13:53.799521+00	2014
2765	565	Feature	\N	\N	1	1	-2765	\N	C	2019-12-20 22:13:53.799521+00	2015
2764	565	Feature	\N	\N	1	1	-2764	\N	C	2019-12-20 22:13:53.799521+00	2016
2763	565	Feature	\N	\N	1	1	-2763	\N	C	2019-12-20 22:13:53.799521+00	2017
2762	565	Feature	\N	\N	1	1	-2762	\N	C	2019-12-20 22:13:53.799521+00	2018
2761	565	Feature	\N	\N	1	1	-2761	\N	C	2019-12-20 22:13:53.799521+00	2019
2760	6	gånggrift	\N	\N	1	1	-2760	\N	C	2019-12-20 22:13:53.799521+00	2020
2759	551	Feature	\N	\N	1	1	-2759	\N	C	2019-12-20 22:13:53.799521+00	2021
2758	551	Feature	\N	\N	1	1	-2758	\N	C	2019-12-20 22:13:53.799521+00	2022
2757	551	Feature	\N	\N	1	1	-2757	\N	C	2019-12-20 22:13:53.799521+00	2023
2756	551	Feature	\N	\N	1	1	-2756	\N	C	2019-12-20 22:13:53.799521+00	2024
2755	567	A4	\N	\N	1	1	-2755	\N	C	2019-12-20 22:13:53.799521+00	2025
2754	567	A1	\N	\N	1	1	-2754	\N	C	2019-12-20 22:13:53.799521+00	2026
2753	567	A6	\N	\N	1	1	-2753	\N	C	2019-12-20 22:13:53.799521+00	2027
2752	567	A3	\N	\N	1	1	-2752	\N	C	2019-12-20 22:13:53.799521+00	2028
2751	567	35	\N	\N	1	1	-2751	\N	C	2019-12-20 22:13:53.799521+00	2029
2750	567	34	\N	\N	1	1	-2750	\N	C	2019-12-20 22:13:53.799521+00	2030
2749	6	Feature	\N	\N	1	1	-2749	\N	C	2019-12-20 22:13:53.799521+00	2031
2748	557	Norra varpet	\N	\N	1	1	-2748	\N	C	2019-12-20 22:13:53.799521+00	2032
2747	557	SÖDRA UGNEN	\N	\N	1	1	-2747	\N	C	2019-12-20 22:13:53.799521+00	2033
2746	557	NORRA UGNEN	\N	\N	1	1	-2746	\N	C	2019-12-20 22:13:53.799521+00	2034
2745	551	A5/A152	\N	\N	1	1	-2745	\N	C	2019-12-20 22:13:53.799521+00	2035
2744	551	A5/A151	\N	\N	1	1	-2744	\N	C	2019-12-20 22:13:53.799521+00	2036
2743	551	A5/A150	\N	\N	1	1	-2743	\N	C	2019-12-20 22:13:53.799521+00	2037
2742	551	A5/A149	\N	\N	1	1	-2742	\N	C	2019-12-20 22:13:53.799521+00	2038
2741	551	A5/A148	\N	\N	1	1	-2741	\N	C	2019-12-20 22:13:53.799521+00	2039
2740	551	A5/A147	\N	\N	1	1	-2740	\N	C	2019-12-20 22:13:53.799521+00	2040
2739	551	A5/A146	\N	\N	1	1	-2739	\N	C	2019-12-20 22:13:53.799521+00	2041
2738	551	A5/A145	\N	\N	1	1	-2738	\N	C	2019-12-20 22:13:53.799521+00	2042
2737	551	A5/A144	\N	\N	1	1	-2737	\N	C	2019-12-20 22:13:53.799521+00	2043
2736	551	A5/A143	\N	\N	1	1	-2736	\N	C	2019-12-20 22:13:53.799521+00	2044
2735	551	A5/A142	\N	\N	1	1	-2735	\N	C	2019-12-20 22:13:53.799521+00	2045
2734	551	A5/A141	\N	\N	1	1	-2734	\N	C	2019-12-20 22:13:53.799521+00	2046
2733	551	A5/A140	\N	\N	1	1	-2733	\N	C	2019-12-20 22:13:53.799521+00	2047
2732	551	A5/A139	\N	\N	1	1	-2732	\N	C	2019-12-20 22:13:53.799521+00	2048
2731	551	A5/A138	\N	\N	1	1	-2731	\N	C	2019-12-20 22:13:53.799521+00	2049
2730	551	A5/A137	\N	\N	1	1	-2730	\N	C	2019-12-20 22:13:53.799521+00	2050
2729	551	A6/473	\N	\N	1	1	-2729	\N	C	2019-12-20 22:13:53.799521+00	2051
2728	560	233	\N	\N	1	1	-2728	\N	C	2019-12-20 22:13:53.799521+00	2052
2727	560	Feature	\N	\N	1	1	-2727	\N	C	2019-12-20 22:13:53.799521+00	2053
2726	560	7007	\N	\N	1	1	-2726	\N	C	2019-12-20 22:13:53.799521+00	2054
2725	560	192	\N	\N	1	1	-2725	\N	C	2019-12-20 22:13:53.799521+00	2055
2724	551	58897	\N	\N	1	1	-2724	\N	C	2019-12-20 22:13:53.799521+00	2056
2723	551	110642	\N	\N	1	1	-2723	\N	C	2019-12-20 22:13:53.799521+00	2057
2722	6	Feature	\N	\N	1	1	-2722	\N	C	2019-12-20 22:13:53.799521+00	2058
2721	6	26	\N	\N	1	1	-2721	\N	C	2019-12-20 22:13:53.799521+00	2059
2720	6	346	\N	\N	1	1	-2720	\N	C	2019-12-20 22:13:53.799521+00	2060
2719	6	373f	\N	\N	1	1	-2719	\N	C	2019-12-20 22:13:53.799521+00	2061
2718	6	359ö	\N	\N	1	1	-2718	\N	C	2019-12-20 22:13:53.799521+00	2062
2717	6	361	\N	\N	1	1	-2717	\N	C	2019-12-20 22:13:53.799521+00	2063
2716	6	359	\N	\N	1	1	-2716	\N	C	2019-12-20 22:13:53.799521+00	2064
2715	6	359:h	\N	\N	1	1	-2715	\N	C	2019-12-20 22:13:53.799521+00	2065
2714	6	88p	\N	\N	1	1	-2714	\N	C	2019-12-20 22:13:53.799521+00	2066
2713	6	151 l	\N	\N	1	1	-2713	\N	C	2019-12-20 22:13:53.799521+00	2067
2712	6	105	\N	\N	1	1	-2712	\N	C	2019-12-20 22:13:53.799521+00	2068
2711	6	114	\N	\N	1	1	-2711	\N	C	2019-12-20 22:13:53.799521+00	2069
2710	6	Va	\N	\N	1	1	-2710	\N	C	2019-12-20 22:13:53.799521+00	2070
2709	6	77	\N	\N	1	1	-2709	\N	C	2019-12-20 22:13:53.799521+00	2071
2708	6	54	\N	\N	1	1	-2708	\N	C	2019-12-20 22:13:53.799521+00	2072
2707	6	22	\N	\N	1	1	-2707	\N	C	2019-12-20 22:13:53.799521+00	2073
2706	6	32	\N	\N	1	1	-2706	\N	C	2019-12-20 22:13:53.799521+00	2074
2705	6	7	\N	\N	1	1	-2705	\N	C	2019-12-20 22:13:53.799521+00	2075
2704	6	4 (Gr. G)	\N	\N	1	1	-2704	\N	C	2019-12-20 22:13:53.799521+00	2076
2703	551	A9	\N	\N	1	1	-2703	\N	C	2019-12-20 22:13:53.799521+00	2077
2702	551	A31	\N	\N	1	1	-2702	\N	C	2019-12-20 22:13:53.799521+00	2078
2701	551	Ruta 71	\N	\N	1	1	-2701	\N	C	2019-12-20 22:13:53.799521+00	2079
2700	551	Ruta 73	\N	\N	1	1	-2700	\N	C	2019-12-20 22:13:53.799521+00	2080
2699	551	A74,H B	\N	\N	1	1	-2699	\N	C	2019-12-20 22:13:53.799521+00	2081
2698	551	Ruta 2	\N	\N	1	1	-2698	\N	C	2019-12-20 22:13:53.799521+00	2082
2697	551	Ruta 8	\N	\N	1	1	-2697	\N	C	2019-12-20 22:13:53.799521+00	2083
2696	551	A74,HB	\N	\N	1	1	-2696	\N	C	2019-12-20 22:13:53.799521+00	2084
2695	551	36	\N	\N	1	1	-2695	\N	C	2019-12-20 22:13:53.799521+00	2085
2694	551	5303	\N	\N	1	1	-2694	\N	C	2019-12-20 22:13:53.799521+00	2086
2693	551	6242	\N	\N	1	1	-2693	\N	C	2019-12-20 22:13:53.799521+00	2087
2692	551	6111	\N	\N	1	1	-2692	\N	C	2019-12-20 22:13:53.799521+00	2088
2691	551	4081	\N	\N	1	1	-2691	\N	C	2019-12-20 22:13:53.799521+00	2089
2690	551	4051	\N	\N	1	1	-2690	\N	C	2019-12-20 22:13:53.799521+00	2090
2689	551	6101	\N	\N	1	1	-2689	\N	C	2019-12-20 22:13:53.799521+00	2091
2688	551	4251	\N	\N	1	1	-2688	\N	C	2019-12-20 22:13:53.799521+00	2092
2687	551	5033	\N	\N	1	1	-2687	\N	C	2019-12-20 22:13:53.799521+00	2093
2686	551	4412c	\N	\N	1	1	-2686	\N	C	2019-12-20 22:13:53.799521+00	2094
2685	551	6021	\N	\N	1	1	-2685	\N	C	2019-12-20 22:13:53.799521+00	2095
2684	566	Feature	\N	\N	1	1	-2684	\N	C	2019-12-20 22:13:53.799521+00	2096
2683	551	Feature	\N	\N	1	1	-2683	\N	C	2019-12-20 22:13:53.799521+00	2097
2682	551	Feature	\N	\N	1	1	-2682	\N	C	2019-12-20 22:13:53.799521+00	2098
2681	558	Feature	\N	\N	1	1	-2681	\N	C	2019-12-20 22:13:53.799521+00	2099
2680	6	LP11	\N	\N	1	1	-2680	\N	C	2019-12-20 22:13:53.799521+00	2100
2679	6	LP10	\N	\N	1	1	-2679	\N	C	2019-12-20 22:13:53.799521+00	2101
2678	6	LP9	\N	\N	1	1	-2678	\N	C	2019-12-20 22:13:53.799521+00	2102
2677	6	LP8	\N	\N	1	1	-2677	\N	C	2019-12-20 22:13:53.799521+00	2103
2676	6	LP7	\N	\N	1	1	-2676	\N	C	2019-12-20 22:13:53.799521+00	2104
2675	6	LP6	\N	\N	1	1	-2675	\N	C	2019-12-20 22:13:53.799521+00	2105
2674	6	LP5	\N	\N	1	1	-2674	\N	C	2019-12-20 22:13:53.799521+00	2106
2673	6	LP4	\N	\N	1	1	-2673	\N	C	2019-12-20 22:13:53.799521+00	2107
2672	6	LP3	\N	\N	1	1	-2672	\N	C	2019-12-20 22:13:53.799521+00	2108
2671	6	LP2B	\N	\N	1	1	-2671	\N	C	2019-12-20 22:13:53.799521+00	2109
2670	6	LP2A	\N	\N	1	1	-2670	\N	C	2019-12-20 22:13:53.799521+00	2110
2669	6	LP1	\N	\N	1	1	-2669	\N	C	2019-12-20 22:13:53.799521+00	2111
2668	551	husgrund 3	\N	\N	1	1	-2668	\N	C	2019-12-20 22:13:53.799521+00	2112
2667	551	Feature	\N	\N	1	1	-2667	\N	C	2019-12-20 22:13:53.799521+00	2113
2666	560	kultgrop	\N	\N	1	1	-2666	\N	C	2019-12-20 22:13:53.799521+00	2114
2665	558	Feature	\N	\N	1	1	-2665	\N	C	2019-12-20 22:13:53.799521+00	2115
2664	558	Feature	\N	\N	1	1	-2664	\N	C	2019-12-20 22:13:53.799521+00	2116
2663	551	38242	\N	\N	1	1	-2663	\N	C	2019-12-20 22:13:53.799521+00	2117
2662	6	24299	\N	\N	1	1	-2662	\N	C	2019-12-20 22:13:53.799521+00	2118
2661	6	41400	\N	\N	1	1	-2661	\N	C	2019-12-20 22:13:53.799521+00	2119
2660	6	40004	\N	\N	1	1	-2660	\N	C	2019-12-20 22:13:53.799521+00	2120
2659	6	18125	\N	\N	1	1	-2659	\N	C	2019-12-20 22:13:53.799521+00	2121
2658	6	16381	\N	\N	1	1	-2658	\N	C	2019-12-20 22:13:53.799521+00	2122
2657	6	61394	\N	\N	1	1	-2657	\N	C	2019-12-20 22:13:53.799521+00	2123
2656	6	20197	\N	\N	1	1	-2656	\N	C	2019-12-20 22:13:53.799521+00	2124
2655	6	20112	\N	\N	1	1	-2655	\N	C	2019-12-20 22:13:53.799521+00	2125
2654	6	61940	\N	\N	1	1	-2654	\N	C	2019-12-20 22:13:53.799521+00	2126
2653	551	4722	\N	\N	1	1	-2653	\N	C	2019-12-20 22:13:53.799521+00	2127
2652	551	12346	\N	\N	1	1	-2652	\N	C	2019-12-20 22:13:53.799521+00	2128
2651	551	7899	\N	\N	1	1	-2651	\N	C	2019-12-20 22:13:53.799521+00	2129
2650	551	38	\N	\N	1	1	-2650	\N	C	2019-12-20 22:13:53.799521+00	2130
2649	551	8434	\N	\N	1	1	-2649	\N	C	2019-12-20 22:13:53.799521+00	2131
2648	550	R1730	\N	\N	1	1	-2648	\N	C	2019-12-20 22:13:53.799521+00	2132
2647	550	R1764	\N	\N	1	1	-2647	\N	C	2019-12-20 22:13:53.799521+00	2133
2646	550	2387	\N	\N	1	1	-2646	\N	C	2019-12-20 22:13:53.799521+00	2134
2645	550	A2703/2387	\N	\N	1	1	-2645	\N	C	2019-12-20 22:13:53.799521+00	2135
2644	557	A4998	\N	\N	1	1	-2644	\N	C	2019-12-20 22:13:53.799521+00	2136
2643	557	R2218	\N	\N	1	1	-2643	\N	C	2019-12-20 22:13:53.799521+00	2137
2642	557	R1335	\N	\N	1	1	-2642	\N	C	2019-12-20 22:13:53.799521+00	2138
2641	551	Lager 5a	\N	\N	1	1	-2641	\N	C	2019-12-20 22:13:53.799521+00	2139
2640	551	43673	\N	\N	1	1	-2640	\N	C	2019-12-20 22:13:53.799521+00	2140
2639	550	B62:2B	\N	\N	1	1	-2639	\N	C	2019-12-20 22:13:53.799521+00	2141
2638	550	B62:2A	\N	\N	1	1	-2638	\N	C	2019-12-20 22:13:53.799521+00	2142
2637	550	B262:1	\N	\N	1	1	-2637	\N	C	2019-12-20 22:13:53.799521+00	2143
2636	550	B329	\N	\N	1	1	-2636	\N	C	2019-12-20 22:13:53.799521+00	2144
2635	550	17	\N	\N	1	1	-2635	\N	C	2019-12-20 22:13:53.799521+00	2145
2634	550	B41	\N	\N	1	1	-2634	\N	C	2019-12-20 22:13:53.799521+00	2146
2633	550	76	\N	\N	1	1	-2633	\N	C	2019-12-20 22:13:53.799521+00	2147
2632	550	R434	\N	\N	1	1	-2632	\N	C	2019-12-20 22:13:53.799521+00	2148
2631	550	1	\N	\N	1	1	-2631	\N	C	2019-12-20 22:13:53.799521+00	2149
2630	6	A3772	\N	\N	1	1	-2630	\N	C	2019-12-20 22:13:53.799521+00	2150
2629	6	A2813	\N	\N	1	1	-2629	\N	C	2019-12-20 22:13:53.799521+00	2151
2628	6	A7061	\N	\N	1	1	-2628	\N	C	2019-12-20 22:13:53.799521+00	2152
2627	6	A2265	\N	\N	1	1	-2627	\N	C	2019-12-20 22:13:53.799521+00	2153
2626	6	A519	\N	\N	1	1	-2626	\N	C	2019-12-20 22:13:53.799521+00	2154
2625	551	Grop bf	\N	\N	1	1	-2625	\N	C	2019-12-20 22:13:53.799521+00	2155
2624	551	Aktiv.yta	\N	\N	1	1	-2624	\N	C	2019-12-20 22:13:53.799521+00	2156
2623	551	Gård	\N	\N	1	1	-2623	\N	C	2019-12-20 22:13:53.799521+00	2157
2622	6	15	\N	\N	1	1	-2622	\N	C	2019-12-20 22:13:53.799521+00	2158
2621	551	Feature	\N	\N	1	1	-2621	\N	C	2019-12-20 22:13:53.799521+00	2159
2620	551	8840	\N	\N	1	1	-2620	\N	C	2019-12-20 22:13:53.799521+00	2160
2619	551	9351	\N	\N	1	1	-2619	\N	C	2019-12-20 22:13:53.799521+00	2161
2618	551	9569	\N	\N	1	1	-2618	\N	C	2019-12-20 22:13:53.799521+00	2162
2617	551	9486	\N	\N	1	1	-2617	\N	C	2019-12-20 22:13:53.799521+00	2163
2616	551	8992	\N	\N	1	1	-2616	\N	C	2019-12-20 22:13:53.799521+00	2164
2615	551	9039	\N	\N	1	1	-2615	\N	C	2019-12-20 22:13:53.799521+00	2165
2614	560	Feature	\N	\N	1	1	-2614	\N	C	2019-12-20 22:13:53.799521+00	2166
2613	560	Feature	\N	\N	1	1	-2613	\N	C	2019-12-20 22:13:53.799521+00	2167
2612	551	Feature	\N	\N	1	1	-2612	\N	C	2019-12-20 22:13:53.799521+00	2168
2611	551	A23385	\N	\N	1	1	-2611	\N	C	2019-12-20 22:13:53.799521+00	2169
2610	551	A267	\N	\N	1	1	-2610	\N	C	2019-12-20 22:13:53.799521+00	2170
2609	551	A10087	\N	\N	1	1	-2609	\N	C	2019-12-20 22:13:53.799521+00	2171
2608	6	A142	\N	\N	1	1	-2608	\N	C	2019-12-20 22:13:53.799521+00	2172
2607	6	A96	\N	\N	1	1	-2607	\N	C	2019-12-20 22:13:53.799521+00	2173
2606	6	A181	\N	\N	1	1	-2606	\N	C	2019-12-20 22:13:53.799521+00	2174
2605	6	A151	\N	\N	1	1	-2605	\N	C	2019-12-20 22:13:53.799521+00	2175
2604	551	A29944	\N	\N	1	1	-2604	\N	C	2019-12-20 22:13:53.799521+00	2176
2603	551	A27600	\N	\N	1	1	-2603	\N	C	2019-12-20 22:13:53.799521+00	2177
2602	551	A5169	\N	\N	1	1	-2602	\N	C	2019-12-20 22:13:53.799521+00	2178
2601	551	A2831	\N	\N	1	1	-2601	\N	C	2019-12-20 22:13:53.799521+00	2179
2600	551	A10023	\N	\N	1	1	-2600	\N	C	2019-12-20 22:13:53.799521+00	2180
2599	551	A188	\N	\N	1	1	-2599	\N	C	2019-12-20 22:13:53.799521+00	2181
2598	551	A2799	\N	\N	1	1	-2598	\N	C	2019-12-20 22:13:53.799521+00	2182
2597	551	19049	\N	\N	1	1	-2597	\N	C	2019-12-20 22:13:53.799521+00	2183
2596	551	3748	\N	\N	1	1	-2596	\N	C	2019-12-20 22:13:53.799521+00	2184
2595	551	1854	\N	\N	1	1	-2595	\N	C	2019-12-20 22:13:53.799521+00	2185
2594	551	Feature	\N	\N	1	1	-2594	\N	C	2019-12-20 22:13:53.799521+00	2186
2593	551	Feature	\N	\N	1	1	-2593	\N	C	2019-12-20 22:13:53.799521+00	2187
2592	6	Feature	\N	\N	1	1	-2592	\N	C	2019-12-20 22:13:53.799521+00	2188
2591	6	6746	\N	\N	1	1	-2591	\N	C	2019-12-20 22:13:53.799521+00	2189
2590	6	8840	\N	\N	1	1	-2590	\N	C	2019-12-20 22:13:53.799521+00	2190
2589	6	10265	\N	\N	1	1	-2589	\N	C	2019-12-20 22:13:53.799521+00	2191
2588	6	7839	\N	\N	1	1	-2588	\N	C	2019-12-20 22:13:53.799521+00	2192
2587	6	19844	\N	\N	1	1	-2587	\N	C	2019-12-20 22:13:53.799521+00	2193
2586	6	17461	\N	\N	1	1	-2586	\N	C	2019-12-20 22:13:53.799521+00	2194
2585	6	8663	\N	\N	1	1	-2585	\N	C	2019-12-20 22:13:53.799521+00	2195
2584	6	21080	\N	\N	1	1	-2584	\N	C	2019-12-20 22:13:53.799521+00	2196
2583	6	21217	\N	\N	1	1	-2583	\N	C	2019-12-20 22:13:53.799521+00	2197
2582	6	21205	\N	\N	1	1	-2582	\N	C	2019-12-20 22:13:53.799521+00	2198
2581	6	23367	\N	\N	1	1	-2581	\N	C	2019-12-20 22:13:53.799521+00	2199
2580	6	474	\N	\N	1	1	-2580	\N	C	2019-12-20 22:13:53.799521+00	2200
2579	6	6697	\N	\N	1	1	-2579	\N	C	2019-12-20 22:13:53.799521+00	2201
2578	6	21033	\N	\N	1	1	-2578	\N	C	2019-12-20 22:13:53.799521+00	2202
2577	6	10517	\N	\N	1	1	-2577	\N	C	2019-12-20 22:13:53.799521+00	2203
2576	6	21003	\N	\N	1	1	-2576	\N	C	2019-12-20 22:13:53.799521+00	2204
2575	6	16222	\N	\N	1	1	-2575	\N	C	2019-12-20 22:13:53.799521+00	2205
2574	6	17479	\N	\N	1	1	-2574	\N	C	2019-12-20 22:13:53.799521+00	2206
2573	6	17490	\N	\N	1	1	-2573	\N	C	2019-12-20 22:13:53.799521+00	2207
2572	6	9182	\N	\N	1	1	-2572	\N	C	2019-12-20 22:13:53.799521+00	2208
2571	6	8653	\N	\N	1	1	-2571	\N	C	2019-12-20 22:13:53.799521+00	2209
2570	6	14628	\N	\N	1	1	-2570	\N	C	2019-12-20 22:13:53.799521+00	2210
2569	6	17247	\N	\N	1	1	-2569	\N	C	2019-12-20 22:13:53.799521+00	2211
2568	6	9653	\N	\N	1	1	-2568	\N	C	2019-12-20 22:13:53.799521+00	2212
2567	6	9611	\N	\N	1	1	-2567	\N	C	2019-12-20 22:13:53.799521+00	2213
2566	6	645	\N	\N	1	1	-2566	\N	C	2019-12-20 22:13:53.799521+00	2214
2565	6	21197	\N	\N	1	1	-2565	\N	C	2019-12-20 22:13:53.799521+00	2215
2564	551	3595	\N	\N	1	1	-2564	\N	C	2019-12-20 22:13:53.799521+00	2216
2563	550	12713	\N	\N	1	1	-2563	\N	C	2019-12-20 22:13:53.799521+00	2217
2562	550	15062	\N	\N	1	1	-2562	\N	C	2019-12-20 22:13:53.799521+00	2218
2561	550	15365	\N	\N	1	1	-2561	\N	C	2019-12-20 22:13:53.799521+00	2219
2560	568	ränna	\N	\N	1	1	-2560	\N	C	2019-12-20 22:13:53.799521+00	2220
2559	568	ugnsvalv	\N	\N	1	1	-2559	\N	C	2019-12-20 22:13:53.799521+00	2221
2558	568	golv i ugn	\N	\N	1	1	-2558	\N	C	2019-12-20 22:13:53.799521+00	2222
2557	568	F1000096	\N	\N	1	1	-2557	\N	C	2019-12-20 22:13:53.799521+00	2223
2556	6	27	\N	\N	1	1	-2556	\N	C	2019-12-20 22:13:53.799521+00	2224
2555	6	20-21	\N	\N	1	1	-2555	\N	C	2019-12-20 22:13:53.799521+00	2225
2554	6	17	\N	\N	1	1	-2554	\N	C	2019-12-20 22:13:53.799521+00	2226
2553	6	7	\N	\N	1	1	-2553	\N	C	2019-12-20 22:13:53.799521+00	2227
2552	6	4	\N	\N	1	1	-2552	\N	C	2019-12-20 22:13:53.799521+00	2228
2551	6	1	\N	\N	1	1	-2551	\N	C	2019-12-20 22:13:53.799521+00	2229
2550	6	6	\N	\N	1	1	-2550	\N	C	2019-12-20 22:13:53.799521+00	2230
2549	551	162	\N	\N	1	1	-2549	\N	C	2019-12-20 22:13:53.799521+00	2231
2548	551	180	\N	\N	1	1	-2548	\N	C	2019-12-20 22:13:53.799521+00	2232
2547	551	362	\N	\N	1	1	-2547	\N	C	2019-12-20 22:13:53.799521+00	2233
2546	551	372	\N	\N	1	1	-2546	\N	C	2019-12-20 22:13:53.799521+00	2234
2545	551	241	\N	\N	1	1	-2545	\N	C	2019-12-20 22:13:53.799521+00	2235
2544	563	SU 19	\N	\N	1	1	-2544	\N	C	2019-12-20 22:13:53.799521+00	2236
2543	553	Feature	\N	\N	1	1	-2543	\N	C	2019-12-20 22:13:53.799521+00	2237
2542	553	140	\N	\N	1	1	-2542	\N	C	2019-12-20 22:13:53.799521+00	2238
2541	553	14626	\N	\N	1	1	-2541	\N	C	2019-12-20 22:13:53.799521+00	2239
2540	553	15128	\N	\N	1	1	-2540	\N	C	2019-12-20 22:13:53.799521+00	2240
2539	551	8184	\N	\N	1	1	-2539	\N	C	2019-12-20 22:13:53.799521+00	2241
2538	563	5576	\N	\N	1	1	-2538	\N	C	2019-12-20 22:13:53.799521+00	2242
2537	563	13132	\N	\N	1	1	-2537	\N	C	2019-12-20 22:13:53.799521+00	2243
2536	551	8184	\N	\N	1	1	-2536	\N	C	2019-12-20 22:13:53.799521+00	2244
2535	563	132	\N	\N	1	1	-2535	\N	C	2019-12-20 22:13:53.799521+00	2245
2534	551	153	\N	\N	1	1	-2534	\N	C	2019-12-20 22:13:53.799521+00	2246
2533	551	156	\N	\N	1	1	-2533	\N	C	2019-12-20 22:13:53.799521+00	2247
2532	551	159	\N	\N	1	1	-2532	\N	C	2019-12-20 22:13:53.799521+00	2248
2531	551	SU 17	\N	\N	1	1	-2531	\N	C	2019-12-20 22:13:53.799521+00	2249
2530	551	150	\N	\N	1	1	-2530	\N	C	2019-12-20 22:13:53.799521+00	2250
2529	6	Hällkista	\N	\N	1	1	-2529	\N	C	2019-12-20 22:13:53.799521+00	2251
2528	551	Feature	\N	\N	1	1	-2528	\N	C	2019-12-20 22:13:53.799521+00	2252
2527	551	11638	\N	\N	1	1	-2527	\N	C	2019-12-20 22:13:53.799521+00	2253
2526	551	68904	\N	\N	1	1	-2526	\N	C	2019-12-20 22:13:53.799521+00	2254
2525	551	114988	\N	\N	1	1	-2525	\N	C	2019-12-20 22:13:53.799521+00	2255
2524	551	13545	\N	\N	1	1	-2524	\N	C	2019-12-20 22:13:53.799521+00	2256
2523	551	Feature	\N	\N	1	1	-2523	\N	C	2019-12-20 22:13:53.799521+00	2257
2522	551	Feature	\N	\N	1	1	-2522	\N	C	2019-12-20 22:13:53.799521+00	2258
2521	551	450	\N	\N	1	1	-2521	\N	C	2019-12-20 22:13:53.799521+00	2259
2520	551	301	\N	\N	1	1	-2520	\N	C	2019-12-20 22:13:53.799521+00	2260
2519	551	100	\N	\N	1	1	-2519	\N	C	2019-12-20 22:13:53.799521+00	2261
2518	551	62	\N	\N	1	1	-2518	\N	C	2019-12-20 22:13:53.799521+00	2262
2517	551	24	\N	\N	1	1	-2517	\N	C	2019-12-20 22:13:53.799521+00	2263
2516	551	Feature	\N	\N	1	1	-2516	\N	C	2019-12-20 22:13:53.799521+00	2264
2515	551	122	\N	\N	1	1	-2515	\N	C	2019-12-20 22:13:53.799521+00	2265
2514	551	116	\N	\N	1	1	-2514	\N	C	2019-12-20 22:13:53.799521+00	2266
2513	551	115	\N	\N	1	1	-2513	\N	C	2019-12-20 22:13:53.799521+00	2267
2512	551	40587	\N	\N	1	1	-2512	\N	C	2019-12-20 22:13:53.799521+00	2268
2511	551	27064	\N	\N	1	1	-2511	\N	C	2019-12-20 22:13:53.799521+00	2269
2510	551	26747	\N	\N	1	1	-2510	\N	C	2019-12-20 22:13:53.799521+00	2270
2509	551	105	\N	\N	1	1	-2509	\N	C	2019-12-20 22:13:53.799521+00	2271
2508	551	103	\N	\N	1	1	-2508	\N	C	2019-12-20 22:13:53.799521+00	2272
2507	551	83	\N	\N	1	1	-2507	\N	C	2019-12-20 22:13:53.799521+00	2273
2506	551	82	\N	\N	1	1	-2506	\N	C	2019-12-20 22:13:53.799521+00	2274
2505	551	14	\N	\N	1	1	-2505	\N	C	2019-12-20 22:13:53.799521+00	2275
2504	551	lösfynd	\N	\N	1	1	-2504	\N	C	2019-12-20 22:13:53.799521+00	2276
2503	551	Feature	\N	\N	1	1	-2503	\N	C	2019-12-20 22:13:53.799521+00	2277
2502	551	Feature	\N	\N	1	1	-2502	\N	C	2019-12-20 22:13:53.799521+00	2278
2501	551	35769	\N	\N	1	1	-2501	\N	C	2019-12-20 22:13:53.799521+00	2279
2500	551	12	\N	\N	1	1	-2500	\N	C	2019-12-20 22:13:53.799521+00	2280
2499	551	A	\N	\N	1	1	-2499	\N	C	2019-12-20 22:13:53.799521+00	2281
2498	551	6	\N	\N	1	1	-2498	\N	C	2019-12-20 22:13:53.799521+00	2282
2497	551	11	\N	\N	1	1	-2497	\N	C	2019-12-20 22:13:53.799521+00	2283
2496	551	K215	\N	\N	1	1	-2496	\N	C	2019-12-20 22:13:53.799521+00	2284
2495	551	a14980	\N	\N	1	1	-2495	\N	C	2019-12-20 22:13:53.799521+00	2285
2494	551	hus 3	\N	\N	1	1	-2494	\N	C	2019-12-20 22:13:53.799521+00	2286
2493	551	stenålder	\N	\N	1	1	-2493	\N	C	2019-12-20 22:13:53.799521+00	2287
2492	551	hus 4	\N	\N	1	1	-2492	\N	C	2019-12-20 22:13:53.799521+00	2288
2491	551	hus 1	\N	\N	1	1	-2491	\N	C	2019-12-20 22:13:53.799521+00	2289
2490	551	Feature	\N	\N	1	1	-2490	\N	C	2019-12-20 22:13:53.799521+00	2290
2489	551	Feature	\N	\N	1	1	-2489	\N	C	2019-12-20 22:13:53.799521+00	2291
2488	551	35935	\N	\N	1	1	-2488	\N	C	2019-12-20 22:13:53.799521+00	2292
2487	551	33400	\N	\N	1	1	-2487	\N	C	2019-12-20 22:13:53.799521+00	2293
2486	551	10707	\N	\N	1	1	-2486	\N	C	2019-12-20 22:13:53.799521+00	2294
2485	551	7107	\N	\N	1	1	-2485	\N	C	2019-12-20 22:13:53.799521+00	2295
2484	551	7107	\N	\N	1	1	-2484	\N	C	2019-12-20 22:13:53.799521+00	2296
2483	551	lösfynd	\N	\N	1	1	-2483	\N	C	2019-12-20 22:13:53.799521+00	2297
2482	551	V1	\N	\N	1	1	-2482	\N	C	2019-12-20 22:13:53.799521+00	2298
2481	551	1A	\N	\N	1	1	-2481	\N	C	2019-12-20 22:13:53.799521+00	2299
2480	551	4C	\N	\N	1	1	-2480	\N	C	2019-12-20 22:13:53.799521+00	2300
2479	551	4A	\N	\N	1	1	-2479	\N	C	2019-12-20 22:13:53.799521+00	2301
2478	551	1D	\N	\N	1	1	-2478	\N	C	2019-12-20 22:13:53.799521+00	2302
2477	551	1C	\N	\N	1	1	-2477	\N	C	2019-12-20 22:13:53.799521+00	2303
2476	551	D-3	\N	\N	1	1	-2476	\N	C	2019-12-20 22:13:53.799521+00	2304
2475	551	D	\N	\N	1	1	-2475	\N	C	2019-12-20 22:13:53.799521+00	2305
2474	551	YTA	\N	\N	1	1	-2474	\N	C	2019-12-20 22:13:53.799521+00	2306
2473	551	D-1	\N	\N	1	1	-2473	\N	C	2019-12-20 22:13:53.799521+00	2307
2472	551	D-5	\N	\N	1	1	-2472	\N	C	2019-12-20 22:13:53.799521+00	2308
2471	551	U	\N	\N	1	1	-2471	\N	C	2019-12-20 22:13:53.799521+00	2309
2470	551	hus 2	\N	\N	1	1	-2470	\N	C	2019-12-20 22:13:53.799521+00	2310
2469	551	18	\N	\N	1	1	-2469	\N	C	2019-12-20 22:13:53.799521+00	2311
2468	551	30	\N	\N	1	1	-2468	\N	C	2019-12-20 22:13:53.799521+00	2312
2467	551	Feature	\N	\N	1	1	-2467	\N	C	2019-12-20 22:13:53.799521+00	2313
2466	567	Feature	\N	\N	1	1	-2466	\N	C	2019-12-20 22:13:53.799521+00	2314
2465	567	Feature	\N	\N	1	1	-2465	\N	C	2019-12-20 22:13:53.799521+00	2315
2464	567	Feature	\N	\N	1	1	-2464	\N	C	2019-12-20 22:13:53.799521+00	2316
2463	567	Feature	\N	\N	1	1	-2463	\N	C	2019-12-20 22:13:53.799521+00	2317
2462	551	Feature	\N	\N	1	1	-2462	\N	C	2019-12-20 22:13:53.799521+00	2318
2461	551	Feature	\N	\N	1	1	-2461	\N	C	2019-12-20 22:13:53.799521+00	2319
2460	551	Feature	\N	\N	1	1	-2460	\N	C	2019-12-20 22:13:53.799521+00	2320
2459	551	gr. 165	\N	\N	1	1	-2459	\N	C	2019-12-20 22:13:53.799521+00	2321
2458	551	Hus CT	\N	\N	1	1	-2458	\N	C	2019-12-20 22:13:53.799521+00	2322
2457	551	Hus Y	\N	\N	1	1	-2457	\N	C	2019-12-20 22:13:53.799521+00	2323
2456	550	Midden I	\N	\N	1	1	-2456	\N	C	2019-12-20 22:13:53.799521+00	2324
2455	550	Midden III	\N	\N	1	1	-2455	\N	C	2019-12-20 22:13:53.799521+00	2325
2454	550	Midden II	\N	\N	1	1	-2454	\N	C	2019-12-20 22:13:53.799521+00	2326
2453	567	Feature	\N	\N	1	1	-2453	\N	C	2019-12-20 22:13:53.799521+00	2327
2452	561	Feature	\N	\N	1	1	-2452	\N	C	2019-12-20 22:13:53.799521+00	2328
2451	561	Feature	\N	\N	1	1	-2451	\N	C	2019-12-20 22:13:53.799521+00	2329
2450	567	B11:9	\N	\N	1	1	-2450	\N	C	2019-12-20 22:13:53.799521+00	2330
2449	567	E11:8	\N	\N	1	1	-2449	\N	C	2019-12-20 22:13:53.799521+00	2331
2448	567	H11:6	\N	\N	1	1	-2448	\N	C	2019-12-20 22:13:53.799521+00	2332
2447	567	N14:3	\N	\N	1	1	-2447	\N	C	2019-12-20 22:13:53.799521+00	2333
2446	567	I11:3b	\N	\N	1	1	-2446	\N	C	2019-12-20 22:13:53.799521+00	2334
2445	567	F10:9	\N	\N	1	1	-2445	\N	C	2019-12-20 22:13:53.799521+00	2335
2444	567	F9:10	\N	\N	1	1	-2444	\N	C	2019-12-20 22:13:53.799521+00	2336
2443	567	C8:7	\N	\N	1	1	-2443	\N	C	2019-12-20 22:13:53.799521+00	2337
2442	567	A9:8	\N	\N	1	1	-2442	\N	C	2019-12-20 22:13:53.799521+00	2338
2441	567	P2:1	\N	\N	1	1	-2441	\N	C	2019-12-20 22:13:53.799521+00	2339
2440	567	G7:9	\N	\N	1	1	-2440	\N	C	2019-12-20 22:13:53.799521+00	2340
2439	567	E6:6	\N	\N	1	1	-2439	\N	C	2019-12-20 22:13:53.799521+00	2341
2438	567	D7:6	\N	\N	1	1	-2438	\N	C	2019-12-20 22:13:53.799521+00	2342
2437	567	C6:8	\N	\N	1	1	-2437	\N	C	2019-12-20 22:13:53.799521+00	2343
2436	567	C5:7	\N	\N	1	1	-2436	\N	C	2019-12-20 22:13:53.799521+00	2344
2435	567	C5:2	\N	\N	1	1	-2435	\N	C	2019-12-20 22:13:53.799521+00	2345
2434	567	I8:7	\N	\N	1	1	-2434	\N	C	2019-12-20 22:13:53.799521+00	2346
2433	567	F4:6	\N	\N	1	1	-2433	\N	C	2019-12-20 22:13:53.799521+00	2347
2432	567	D5;3	\N	\N	1	1	-2432	\N	C	2019-12-20 22:13:53.799521+00	2348
2431	567	B8:4	\N	\N	1	1	-2431	\N	C	2019-12-20 22:13:53.799521+00	2349
2430	567	D4:8	\N	\N	1	1	-2430	\N	C	2019-12-20 22:13:53.799521+00	2350
2429	567	C4:8	\N	\N	1	1	-2429	\N	C	2019-12-20 22:13:53.799521+00	2351
2428	567	E7:4	\N	\N	1	1	-2428	\N	C	2019-12-20 22:13:53.799521+00	2352
2427	567	G5:6	\N	\N	1	1	-2427	\N	C	2019-12-20 22:13:53.799521+00	2353
2426	567	G7:6	\N	\N	1	1	-2426	\N	C	2019-12-20 22:13:53.799521+00	2354
2425	567	B6:4	\N	\N	1	1	-2425	\N	C	2019-12-20 22:13:53.799521+00	2355
2424	567	E7:3	\N	\N	1	1	-2424	\N	C	2019-12-20 22:13:53.799521+00	2356
2423	567	G7:3	\N	\N	1	1	-2423	\N	C	2019-12-20 22:13:53.799521+00	2357
2422	567	I3:3	\N	\N	1	1	-2422	\N	C	2019-12-20 22:13:53.799521+00	2358
2421	567	I2:3	\N	\N	1	1	-2421	\N	C	2019-12-20 22:13:53.799521+00	2359
2420	567	C7:2	\N	\N	1	1	-2420	\N	C	2019-12-20 22:13:53.799521+00	2360
2419	567	E5:2	\N	\N	1	1	-2419	\N	C	2019-12-20 22:13:53.799521+00	2361
2418	557	Feature	\N	\N	1	1	-2418	\N	C	2019-12-20 22:13:53.799521+00	2362
2417	551	Feature	\N	\N	1	1	-2417	\N	C	2019-12-20 22:13:53.799521+00	2363
2416	551	Feature	\N	\N	1	1	-2416	\N	C	2019-12-20 22:13:53.799521+00	2364
2415	6	0	\N	\N	1	1	-2415	\N	C	2019-12-20 22:13:53.799521+00	2365
2414	551	88	\N	\N	1	1	-2414	\N	C	2019-12-20 22:13:53.799521+00	2366
2413	551	42	\N	\N	1	1	-2413	\N	C	2019-12-20 22:13:53.799521+00	2367
2412	551	38	\N	\N	1	1	-2412	\N	C	2019-12-20 22:13:53.799521+00	2368
2411	551	33	\N	\N	1	1	-2411	\N	C	2019-12-20 22:13:53.799521+00	2369
2410	551	0	\N	\N	1	1	-2410	\N	C	2019-12-20 22:13:53.799521+00	2370
2409	565	0	\N	\N	1	1	-2409	\N	C	2019-12-20 22:13:53.799521+00	2371
2408	551	42	\N	\N	1	1	-2408	\N	C	2019-12-20 22:13:53.799521+00	2372
2407	551	277	\N	\N	1	1	-2407	\N	C	2019-12-20 22:13:53.799521+00	2373
2406	551	260	\N	\N	1	1	-2406	\N	C	2019-12-20 22:13:53.799521+00	2374
2405	551	207	\N	\N	1	1	-2405	\N	C	2019-12-20 22:13:53.799521+00	2375
2404	551	194	\N	\N	1	1	-2404	\N	C	2019-12-20 22:13:53.799521+00	2376
2403	551	193	\N	\N	1	1	-2403	\N	C	2019-12-20 22:13:53.799521+00	2377
2402	551	101	\N	\N	1	1	-2402	\N	C	2019-12-20 22:13:53.799521+00	2378
2401	551	61	\N	\N	1	1	-2401	\N	C	2019-12-20 22:13:53.799521+00	2379
2400	551	50	\N	\N	1	1	-2400	\N	C	2019-12-20 22:13:53.799521+00	2380
2399	551	35	\N	\N	1	1	-2399	\N	C	2019-12-20 22:13:53.799521+00	2381
2398	551	34	\N	\N	1	1	-2398	\N	C	2019-12-20 22:13:53.799521+00	2382
2397	551	31	\N	\N	1	1	-2397	\N	C	2019-12-20 22:13:53.799521+00	2383
2396	551	27	\N	\N	1	1	-2396	\N	C	2019-12-20 22:13:53.799521+00	2384
2395	551	Feature	\N	\N	1	1	-2395	\N	C	2019-12-20 22:13:53.799521+00	2385
2394	551	Feature	\N	\N	1	1	-2394	\N	C	2019-12-20 22:13:53.799521+00	2386
2393	551	Feature	\N	\N	1	1	-2393	\N	C	2019-12-20 22:13:53.799521+00	2387
2392	551	Feature	\N	\N	1	1	-2392	\N	C	2019-12-20 22:13:53.799521+00	2388
2391	551	Feature	\N	\N	1	1	-2391	\N	C	2019-12-20 22:13:53.799521+00	2389
2390	555	Feature	\N	\N	1	1	-2390	\N	C	2019-12-20 22:13:53.799521+00	2390
2389	567	A - G   8	\N	\N	1	1	-2389	\N	C	2019-12-20 22:13:53.799521+00	2391
2388	567	A - G   11	\N	\N	1	1	-2388	\N	C	2019-12-20 22:13:53.799521+00	2392
2387	567	A - G  10	\N	\N	1	1	-2387	\N	C	2019-12-20 22:13:53.799521+00	2393
2386	567	G-E 18	\N	\N	1	1	-2386	\N	C	2019-12-20 22:13:53.799521+00	2394
2385	567	G-D 18	\N	\N	1	1	-2385	\N	C	2019-12-20 22:13:53.799521+00	2395
2384	567	G-C 18	\N	\N	1	1	-2384	\N	C	2019-12-20 22:13:53.799521+00	2396
2383	567	G-B 18	\N	\N	1	1	-2383	\N	C	2019-12-20 22:13:53.799521+00	2397
2382	567	G-A 18	\N	\N	1	1	-2382	\N	C	2019-12-20 22:13:53.799521+00	2398
2381	567	B-C 16	\N	\N	1	1	-2381	\N	C	2019-12-20 22:13:53.799521+00	2399
2380	567	B-B 16	\N	\N	1	1	-2380	\N	C	2019-12-20 22:13:53.799521+00	2400
2379	567	B-A 16	\N	\N	1	1	-2379	\N	C	2019-12-20 22:13:53.799521+00	2401
2378	567	D. 19	\N	\N	1	1	-2378	\N	C	2019-12-20 22:13:53.799521+00	2402
2377	567	V. 16	\N	\N	1	1	-2377	\N	C	2019-12-20 22:13:53.799521+00	2403
2376	567	A 16-2.B	\N	\N	1	1	-2376	\N	C	2019-12-20 22:13:53.799521+00	2404
2375	567	A 16-2.A	\N	\N	1	1	-2375	\N	C	2019-12-20 22:13:53.799521+00	2405
2374	567	A 16-1.B	\N	\N	1	1	-2374	\N	C	2019-12-20 22:13:53.799521+00	2406
2373	567	A 16-1.A	\N	\N	1	1	-2373	\N	C	2019-12-20 22:13:53.799521+00	2407
2372	567	Feature	\N	\N	1	1	-2372	\N	C	2019-12-20 22:13:53.799521+00	2408
2371	551	Feature	\N	\N	1	1	-2371	\N	C	2019-12-20 22:13:53.799521+00	2409
2370	557	3	\N	\N	1	1	-2370	\N	C	2019-12-20 22:13:53.799521+00	2410
2369	6	Feature	\N	\N	1	1	-2369	\N	C	2019-12-20 22:13:53.799521+00	2411
2368	6	7	\N	\N	1	1	-2368	\N	C	2019-12-20 22:13:53.799521+00	2412
2367	6	6	\N	\N	1	1	-2367	\N	C	2019-12-20 22:13:53.799521+00	2413
2366	6	5	\N	\N	1	1	-2366	\N	C	2019-12-20 22:13:53.799521+00	2414
2365	6	4	\N	\N	1	1	-2365	\N	C	2019-12-20 22:13:53.799521+00	2415
2364	6	2	\N	\N	1	1	-2364	\N	C	2019-12-20 22:13:53.799521+00	2416
2363	4	Feature	\N	\N	1	1	-2363	\N	C	2019-12-20 22:13:53.799521+00	2417
2362	573	Feature	\N	\N	1	1	-2362	\N	C	2019-12-20 22:13:53.799521+00	2418
2361	551	Feature	\N	\N	1	1	-2361	\N	C	2019-12-20 22:13:53.799521+00	2419
2360	551	Feature	\N	\N	1	1	-2360	\N	C	2019-12-20 22:13:53.799521+00	2420
2359	6	Feature	\N	\N	1	1	-2359	\N	C	2019-12-20 22:13:53.799521+00	2421
2358	570	Feature	\N	\N	1	1	-2358	\N	C	2019-12-20 22:13:53.799521+00	2422
2357	6	338 Ä1	\N	\N	1	1	-2357	\N	C	2019-12-20 22:13:53.799521+00	2423
2356	6	264	\N	\N	1	1	-2356	\N	C	2019-12-20 22:13:53.799521+00	2424
2355	6	197	\N	\N	1	1	-2355	\N	C	2019-12-20 22:13:53.799521+00	2425
2354	6	284	\N	\N	1	1	-2354	\N	C	2019-12-20 22:13:53.799521+00	2426
2353	6	240	\N	\N	1	1	-2353	\N	C	2019-12-20 22:13:53.799521+00	2427
2352	6	218	\N	\N	1	1	-2352	\N	C	2019-12-20 22:13:53.799521+00	2428
2351	6	1564	\N	\N	1	1	-2351	\N	C	2019-12-20 22:13:53.799521+00	2429
2350	6	717	\N	\N	1	1	-2350	\N	C	2019-12-20 22:13:53.799521+00	2430
2349	6	672	\N	\N	1	1	-2349	\N	C	2019-12-20 22:13:53.799521+00	2431
2348	6	1028	\N	\N	1	1	-2348	\N	C	2019-12-20 22:13:53.799521+00	2432
2347	6	957	\N	\N	1	1	-2347	\N	C	2019-12-20 22:13:53.799521+00	2433
2346	6	894	\N	\N	1	1	-2346	\N	C	2019-12-20 22:13:53.799521+00	2434
2345	6	540	\N	\N	1	1	-2345	\N	C	2019-12-20 22:13:53.799521+00	2435
2344	6	944	\N	\N	1	1	-2344	\N	C	2019-12-20 22:13:53.799521+00	2436
2343	6	650	\N	\N	1	1	-2343	\N	C	2019-12-20 22:13:53.799521+00	2437
2342	6	1774	\N	\N	1	1	-2342	\N	C	2019-12-20 22:13:53.799521+00	2438
2341	6	1371	\N	\N	1	1	-2341	\N	C	2019-12-20 22:13:53.799521+00	2439
2340	6	1337	\N	\N	1	1	-2340	\N	C	2019-12-20 22:13:53.799521+00	2440
2339	6	1048	\N	\N	1	1	-2339	\N	C	2019-12-20 22:13:53.799521+00	2441
2338	6	968B	\N	\N	1	1	-2338	\N	C	2019-12-20 22:13:53.799521+00	2442
2337	6	500	\N	\N	1	1	-2337	\N	C	2019-12-20 22:13:53.799521+00	2443
2336	6	623	\N	\N	1	1	-2336	\N	C	2019-12-20 22:13:53.799521+00	2444
2335	6	586B	\N	\N	1	1	-2335	\N	C	2019-12-20 22:13:53.799521+00	2445
2334	6	586A	\N	\N	1	1	-2334	\N	C	2019-12-20 22:13:53.799521+00	2446
2333	6	417B	\N	\N	1	1	-2333	\N	C	2019-12-20 22:13:53.799521+00	2447
2332	6	417A	\N	\N	1	1	-2332	\N	C	2019-12-20 22:13:53.799521+00	2448
2331	6	1911	\N	\N	1	1	-2331	\N	C	2019-12-20 22:13:53.799521+00	2449
2330	6	1532	\N	\N	1	1	-2330	\N	C	2019-12-20 22:13:53.799521+00	2450
2329	6	457	\N	\N	1	1	-2329	\N	C	2019-12-20 22:13:53.799521+00	2451
2328	6	425	\N	\N	1	1	-2328	\N	C	2019-12-20 22:13:53.799521+00	2452
2327	6	968	\N	\N	1	1	-2327	\N	C	2019-12-20 22:13:53.799521+00	2453
2326	6	599	\N	\N	1	1	-2326	\N	C	2019-12-20 22:13:53.799521+00	2454
2325	6	1239	\N	\N	1	1	-2325	\N	C	2019-12-20 22:13:53.799521+00	2455
2324	6	1670	\N	\N	1	1	-2324	\N	C	2019-12-20 22:13:53.799521+00	2456
2323	6	1921	\N	\N	1	1	-2323	\N	C	2019-12-20 22:13:53.799521+00	2457
2322	6	1116	\N	\N	1	1	-2322	\N	C	2019-12-20 22:13:53.799521+00	2458
2321	6	1865	\N	\N	1	1	-2321	\N	C	2019-12-20 22:13:53.799521+00	2459
2320	6	1154	\N	\N	1	1	-2320	\N	C	2019-12-20 22:13:53.799521+00	2460
2319	6	1346	\N	\N	1	1	-2319	\N	C	2019-12-20 22:13:53.799521+00	2461
2318	6	138.2	\N	\N	1	1	-2318	\N	C	2019-12-20 22:13:53.799521+00	2462
2317	6	712	\N	\N	1	1	-2317	\N	C	2019-12-20 22:13:53.799521+00	2463
2316	6	1560	\N	\N	1	1	-2316	\N	C	2019-12-20 22:13:53.799521+00	2464
2315	6	1944	\N	\N	1	1	-2315	\N	C	2019-12-20 22:13:53.799521+00	2465
2314	6	1209.5	\N	\N	1	1	-2314	\N	C	2019-12-20 22:13:53.799521+00	2466
2313	6	1740	\N	\N	1	1	-2313	\N	C	2019-12-20 22:13:53.799521+00	2467
2312	6	1079	\N	\N	1	1	-2312	\N	C	2019-12-20 22:13:53.799521+00	2468
2311	6	973	\N	\N	1	1	-2311	\N	C	2019-12-20 22:13:53.799521+00	2469
2310	6	940	\N	\N	1	1	-2310	\N	C	2019-12-20 22:13:53.799521+00	2470
2309	6	900	\N	\N	1	1	-2309	\N	C	2019-12-20 22:13:53.799521+00	2471
2308	6	805	\N	\N	1	1	-2308	\N	C	2019-12-20 22:13:53.799521+00	2472
2307	6	777	\N	\N	1	1	-2307	\N	C	2019-12-20 22:13:53.799521+00	2473
2306	6	484	\N	\N	1	1	-2306	\N	C	2019-12-20 22:13:53.799521+00	2474
2305	6	645	\N	\N	1	1	-2305	\N	C	2019-12-20 22:13:53.799521+00	2475
2304	6	572	\N	\N	1	1	-2304	\N	C	2019-12-20 22:13:53.799521+00	2476
2303	6	1763	\N	\N	1	1	-2303	\N	C	2019-12-20 22:13:53.799521+00	2477
2302	6	1414	\N	\N	1	1	-2302	\N	C	2019-12-20 22:13:53.799521+00	2478
2301	6	640	\N	\N	1	1	-2301	\N	C	2019-12-20 22:13:53.799521+00	2479
2300	6	561	\N	\N	1	1	-2300	\N	C	2019-12-20 22:13:53.799521+00	2480
2299	6	1011	\N	\N	1	1	-2299	\N	C	2019-12-20 22:13:53.799521+00	2481
2298	6	913	\N	\N	1	1	-2298	\N	C	2019-12-20 22:13:53.799521+00	2482
2297	6	848	\N	\N	1	1	-2297	\N	C	2019-12-20 22:13:53.799521+00	2483
2296	6	609	\N	\N	1	1	-2296	\N	C	2019-12-20 22:13:53.799521+00	2484
2295	6	673	\N	\N	1	1	-2295	\N	C	2019-12-20 22:13:53.799521+00	2485
2294	6	520	\N	\N	1	1	-2294	\N	C	2019-12-20 22:13:53.799521+00	2486
2293	6	625	\N	\N	1	1	-2293	\N	C	2019-12-20 22:13:53.799521+00	2487
2292	6	488	\N	\N	1	1	-2292	\N	C	2019-12-20 22:13:53.799521+00	2488
2291	6	1176	\N	\N	1	1	-2291	\N	C	2019-12-20 22:13:53.799521+00	2489
2290	6	1913	\N	\N	1	1	-2290	\N	C	2019-12-20 22:13:53.799521+00	2490
2289	6	986	\N	\N	1	1	-2289	\N	C	2019-12-20 22:13:53.799521+00	2491
2288	6	424	\N	\N	1	1	-2288	\N	C	2019-12-20 22:13:53.799521+00	2492
2287	6	449	\N	\N	1	1	-2287	\N	C	2019-12-20 22:13:53.799521+00	2493
2286	6	1015	\N	\N	1	1	-2286	\N	C	2019-12-20 22:13:53.799521+00	2494
2285	6	1046	\N	\N	1	1	-2285	\N	C	2019-12-20 22:13:53.799521+00	2495
2284	6	1461	\N	\N	1	1	-2284	\N	C	2019-12-20 22:13:53.799521+00	2496
2283	6	1195	\N	\N	1	1	-2283	\N	C	2019-12-20 22:13:53.799521+00	2497
2282	6	1490	\N	\N	1	1	-2282	\N	C	2019-12-20 22:13:53.799521+00	2498
2281	6	1875	\N	\N	1	1	-2281	\N	C	2019-12-20 22:13:53.799521+00	2499
2280	6	499	\N	\N	1	1	-2280	\N	C	2019-12-20 22:13:53.799521+00	2500
2279	6	459	\N	\N	1	1	-2279	\N	C	2019-12-20 22:13:53.799521+00	2501
2278	551	Feature	\N	\N	1	1	-2278	\N	C	2019-12-20 22:13:53.799521+00	2502
2277	551	Feature	\N	\N	1	1	-2277	\N	C	2019-12-20 22:13:53.799521+00	2503
2276	571	Feature	\N	\N	1	1	-2276	\N	C	2019-12-20 22:13:53.799521+00	2504
2275	571	Feature	\N	\N	1	1	-2275	\N	C	2019-12-20 22:13:53.799521+00	2505
2274	565	Feature	\N	\N	1	1	-2274	\N	C	2019-12-20 22:13:53.799521+00	2506
2273	6	A12689 grav	\N	\N	1	1	-2273	\N	C	2019-12-20 22:13:53.799521+00	2507
2272	6	A15486 skhög	\N	\N	1	1	-2272	\N	C	2019-12-20 22:13:53.799521+00	2508
2271	6	A14427 sts	\N	\N	1	1	-2271	\N	C	2019-12-20 22:13:53.799521+00	2509
2270	6	A3708 sts/kremeringsplats	\N	\N	1	1	-2270	\N	C	2019-12-20 22:13:53.799521+00	2510
2269	6	A9398 Flatmarksgrav 	\N	\N	1	1	-2269	\N	C	2019-12-20 22:13:53.799521+00	2511
2268	551	8	\N	\N	1	1	-2268	\N	C	2019-12-20 22:13:53.799521+00	2512
2267	551	1562	\N	\N	1	1	-2267	\N	C	2019-12-20 22:13:53.799521+00	2513
2266	565	Bäckfåra	\N	\N	1	1	-2266	\N	C	2019-12-20 22:13:53.799521+00	2514
2265	565	24289	\N	\N	1	1	-2265	\N	C	2019-12-20 22:13:53.799521+00	2515
2264	565	125	\N	\N	1	1	-2264	\N	C	2019-12-20 22:13:53.799521+00	2516
2263	551	118	\N	\N	1	1	-2263	\N	C	2019-12-20 22:13:53.799521+00	2517
2262	551	17272	\N	\N	1	1	-2262	\N	C	2019-12-20 22:13:53.799521+00	2518
2261	551	ej	\N	\N	1	1	-2261	\N	C	2019-12-20 22:13:53.799521+00	2519
2260	551	hus 2	\N	\N	1	1	-2260	\N	C	2019-12-20 22:13:53.799521+00	2520
2259	551	hus 1	\N	\N	1	1	-2259	\N	C	2019-12-20 22:13:53.799521+00	2521
2258	551	hus 13	\N	\N	1	1	-2258	\N	C	2019-12-20 22:13:53.799521+00	2522
2257	551	 hus 2	\N	\N	1	1	-2257	\N	C	2019-12-20 22:13:53.799521+00	2523
2256	6	Feature	\N	\N	1	1	-2256	\N	C	2019-12-20 22:13:53.799521+00	2524
2255	551	Feature	\N	\N	1	1	-2255	\N	C	2019-12-20 22:13:53.799521+00	2525
2254	551	Feature	\N	\N	1	1	-2254	\N	C	2019-12-20 22:13:53.799521+00	2526
2253	551	Feature	\N	\N	1	1	-2253	\N	C	2019-12-20 22:13:53.799521+00	2527
2252	551	1007	\N	\N	1	1	-2252	\N	C	2019-12-20 22:13:53.799521+00	2528
2251	551	1144	\N	\N	1	1	-2251	\N	C	2019-12-20 22:13:53.799521+00	2529
2250	551	807	\N	\N	1	1	-2250	\N	C	2019-12-20 22:13:53.799521+00	2530
2249	551	lerprov	\N	\N	1	1	-2249	\N	C	2019-12-20 22:13:53.799521+00	2531
2248	551	1336	\N	\N	1	1	-2248	\N	C	2019-12-20 22:13:53.799521+00	2532
2247	551	808	\N	\N	1	1	-2247	\N	C	2019-12-20 22:13:53.799521+00	2533
2246	551	327	\N	\N	1	1	-2246	\N	C	2019-12-20 22:13:53.799521+00	2534
2245	551	123	\N	\N	1	1	-2245	\N	C	2019-12-20 22:13:53.799521+00	2535
2244	551	122	\N	\N	1	1	-2244	\N	C	2019-12-20 22:13:53.799521+00	2536
2243	551	956	\N	\N	1	1	-2243	\N	C	2019-12-20 22:13:53.799521+00	2537
2242	551	ngborg?	\N	\N	1	1	-2242	\N	C	2019-12-20 22:13:53.799521+00	2538
2241	565	Feature	\N	\N	1	1	-2241	\N	C	2019-12-20 22:13:53.799521+00	2539
2240	551	kulturlager	\N	\N	1	1	-2240	\N	C	2019-12-20 22:13:53.799521+00	2540
2239	551	2054	\N	\N	1	1	-2239	\N	C	2019-12-20 22:13:53.799521+00	2541
2238	551	Hydda 6	\N	\N	1	1	-2238	\N	C	2019-12-20 22:13:53.799521+00	2542
2237	551	Feature	\N	\N	1	1	-2237	\N	C	2019-12-20 22:13:53.799521+00	2543
2236	551	915	\N	\N	1	1	-2236	\N	C	2019-12-20 22:13:53.799521+00	2544
2235	551	1470	\N	\N	1	1	-2235	\N	C	2019-12-20 22:13:53.799521+00	2545
2234	551	522	\N	\N	1	1	-2234	\N	C	2019-12-20 22:13:53.799521+00	2546
2233	551	367	\N	\N	1	1	-2233	\N	C	2019-12-20 22:13:53.799521+00	2547
2232	551	261	\N	\N	1	1	-2232	\N	C	2019-12-20 22:13:53.799521+00	2548
2231	567	Feature	\N	\N	1	1	-2231	\N	C	2019-12-20 22:13:53.799521+00	2549
2230	551	site 1, layer II	\N	\N	1	1	-2230	\N	C	2019-12-20 22:13:53.799521+00	2550
2229	6	XII	\N	\N	1	1	-2229	\N	C	2019-12-20 22:13:53.799521+00	2551
2228	565	Feature	\N	\N	1	1	-2228	\N	C	2019-12-20 22:13:53.799521+00	2552
2227	554	Feature	\N	\N	1	1	-2227	\N	C	2019-12-20 22:13:53.799521+00	2553
2226	551	Feature	\N	\N	1	1	-2226	\N	C	2019-12-20 22:13:53.799521+00	2554
2225	551	Feature	\N	\N	1	1	-2225	\N	C	2019-12-20 22:13:53.799521+00	2555
2224	6	19	\N	\N	1	1	-2224	\N	C	2019-12-20 22:13:53.799521+00	2556
2223	6	47	\N	\N	1	1	-2223	\N	C	2019-12-20 22:13:53.799521+00	2557
2222	6	2	\N	\N	1	1	-2222	\N	C	2019-12-20 22:13:53.799521+00	2558
2221	6	426	\N	\N	1	1	-2221	\N	C	2019-12-20 22:13:53.799521+00	2559
2220	6	417	\N	\N	1	1	-2220	\N	C	2019-12-20 22:13:53.799521+00	2560
2219	6	414	\N	\N	1	1	-2219	\N	C	2019-12-20 22:13:53.799521+00	2561
2218	551	Feature	\N	\N	1	1	-2218	\N	C	2019-12-20 22:13:53.799521+00	2562
2217	551	Feature	\N	\N	1	1	-2217	\N	C	2019-12-20 22:13:53.799521+00	2563
2216	551	Feature	\N	\N	1	1	-2216	\N	C	2019-12-20 22:13:53.799521+00	2564
2215	551	Feature	\N	\N	1	1	-2215	\N	C	2019-12-20 22:13:53.799521+00	2565
2214	6	Feature	\N	\N	1	1	-2214	\N	C	2019-12-20 22:13:53.799521+00	2566
2213	551	Feature	\N	\N	1	1	-2213	\N	C	2019-12-20 22:13:53.799521+00	2567
2212	564	Feature	\N	\N	1	1	-2212	\N	C	2019-12-20 22:13:53.799521+00	2568
2211	551	Feature	\N	\N	1	1	-2211	\N	C	2019-12-20 22:13:53.799521+00	2569
2210	551	Feature	\N	\N	1	1	-2210	\N	C	2019-12-20 22:13:53.799521+00	2570
2209	551	Feature	\N	\N	1	1	-2209	\N	C	2019-12-20 22:13:53.799521+00	2571
2208	551	Feature	\N	\N	1	1	-2208	\N	C	2019-12-20 22:13:53.799521+00	2572
2207	551	Feature	\N	\N	1	1	-2207	\N	C	2019-12-20 22:13:53.799521+00	2573
2206	551	Feature	\N	\N	1	1	-2206	\N	C	2019-12-20 22:13:53.799521+00	2574
2205	551	Feature	\N	\N	1	1	-2205	\N	C	2019-12-20 22:13:53.799521+00	2575
2204	551	Feature	\N	\N	1	1	-2204	\N	C	2019-12-20 22:13:53.799521+00	2576
2203	551	Feature	\N	\N	1	1	-2203	\N	C	2019-12-20 22:13:53.799521+00	2577
2202	551	Feature	\N	\N	1	1	-2202	\N	C	2019-12-20 22:13:53.799521+00	2578
2201	551	Feature	\N	\N	1	1	-2201	\N	C	2019-12-20 22:13:53.799521+00	2579
2200	551	Feature	\N	\N	1	1	-2200	\N	C	2019-12-20 22:13:53.799521+00	2580
2199	551	Feature	\N	\N	1	1	-2199	\N	C	2019-12-20 22:13:53.799521+00	2581
2198	551	Feature	\N	\N	1	1	-2198	\N	C	2019-12-20 22:13:53.799521+00	2582
2197	551	18	\N	\N	1	1	-2197	\N	C	2019-12-20 22:13:53.799521+00	2583
2196	551	B	\N	\N	1	1	-2196	\N	C	2019-12-20 22:13:53.799521+00	2584
2195	551	E	\N	\N	1	1	-2195	\N	C	2019-12-20 22:13:53.799521+00	2585
2194	551	F	\N	\N	1	1	-2194	\N	C	2019-12-20 22:13:53.799521+00	2586
2193	551	13	\N	\N	1	1	-2193	\N	C	2019-12-20 22:13:53.799521+00	2587
2192	551	12	\N	\N	1	1	-2192	\N	C	2019-12-20 22:13:53.799521+00	2588
2191	567	Feature	\N	\N	1	1	-2191	\N	C	2019-12-20 22:13:53.799521+00	2589
2190	567	Feature	\N	\N	1	1	-2190	\N	C	2019-12-20 22:13:53.799521+00	2590
2189	568	Feature	\N	\N	1	1	-2189	\N	C	2019-12-20 22:13:53.799521+00	2591
2188	567	Feature	\N	\N	1	1	-2188	\N	C	2019-12-20 22:13:53.799521+00	2592
2187	567	Feature	\N	\N	1	1	-2187	\N	C	2019-12-20 22:13:53.799521+00	2593
2186	567	Keramikugnar	\N	\N	1	1	-2186	\N	C	2019-12-20 22:13:53.799521+00	2594
2185	567	Feature	\N	\N	1	1	-2185	\N	C	2019-12-20 22:13:53.799521+00	2595
2184	567	Feature	\N	\N	1	1	-2184	\N	C	2019-12-20 22:13:53.799521+00	2596
2183	567	Feature	\N	\N	1	1	-2183	\N	C	2019-12-20 22:13:53.799521+00	2597
2182	552	Feature	\N	\N	1	1	-2182	\N	C	2019-12-20 22:13:53.799521+00	2598
2181	551	18.77	\N	\N	1	1	-2181	\N	C	2019-12-20 22:13:53.799521+00	2599
2180	551	6.77	\N	\N	1	1	-2180	\N	C	2019-12-20 22:13:53.799521+00	2600
2179	551	10.77	\N	\N	1	1	-2179	\N	C	2019-12-20 22:13:53.799521+00	2601
2178	551	3.77	\N	\N	1	1	-2178	\N	C	2019-12-20 22:13:53.799521+00	2602
2177	551	1.76	\N	\N	1	1	-2177	\N	C	2019-12-20 22:13:53.799521+00	2603
2176	6	Feature	\N	\N	1	1	-2176	\N	C	2019-12-20 22:13:53.799521+00	2604
2175	550	Feature	\N	\N	1	1	-2175	\N	C	2019-12-20 22:13:53.799521+00	2605
2174	6	Feature	\N	\N	1	1	-2174	\N	C	2019-12-20 22:13:53.799521+00	2606
2173	6	Feature	\N	\N	1	1	-2173	\N	C	2019-12-20 22:13:53.799521+00	2607
2172	6	Gr 1137	\N	\N	1	1	-2172	\N	C	2019-12-20 22:13:53.799521+00	2608
2171	550	Feature	\N	\N	1	1	-2171	\N	C	2019-12-20 22:13:53.799521+00	2609
2170	6	Feature	\N	\N	1	1	-2170	\N	C	2019-12-20 22:13:53.799521+00	2610
2169	6	Gr 731	\N	\N	1	1	-2169	\N	C	2019-12-20 22:13:53.799521+00	2611
2168	6	Feature	\N	\N	1	1	-2168	\N	C	2019-12-20 22:13:53.799521+00	2612
2167	6	Gr 369	\N	\N	1	1	-2167	\N	C	2019-12-20 22:13:53.799521+00	2613
2166	6	Gr 457	\N	\N	1	1	-2166	\N	C	2019-12-20 22:13:53.799521+00	2614
2165	6	Feature	\N	\N	1	1	-2165	\N	C	2019-12-20 22:13:53.799521+00	2615
2164	6	Feature	\N	\N	1	1	-2164	\N	C	2019-12-20 22:13:53.799521+00	2616
2163	562	Feature	\N	\N	1	1	-2163	\N	C	2019-12-20 22:13:53.799521+00	2617
2162	550	Feature	\N	\N	1	1	-2162	\N	C	2019-12-20 22:13:53.799521+00	2618
2161	6	Feature	\N	\N	1	1	-2161	\N	C	2019-12-20 22:13:53.799521+00	2619
2160	6	Feature	\N	\N	1	1	-2160	\N	C	2019-12-20 22:13:53.799521+00	2620
2159	6	Feature	\N	\N	1	1	-2159	\N	C	2019-12-20 22:13:53.799521+00	2621
2158	6	Feature	\N	\N	1	1	-2158	\N	C	2019-12-20 22:13:53.799521+00	2622
2157	567	Feature	\N	\N	1	1	-2157	\N	C	2019-12-20 22:13:53.799521+00	2623
2156	6	Feature	\N	\N	1	1	-2156	\N	C	2019-12-20 22:13:53.799521+00	2624
2155	567	Feature	\N	\N	1	1	-2155	\N	C	2019-12-20 22:13:53.799521+00	2625
2154	573	Feature	\N	\N	1	1	-2154	\N	C	2019-12-20 22:13:53.799521+00	2626
2153	573	Feature	\N	\N	1	1	-2153	\N	C	2019-12-20 22:13:53.799521+00	2627
2152	551	Feature	\N	\N	1	1	-2152	\N	C	2019-12-20 22:13:53.799521+00	2628
2151	572	Osäker proveniens	\N	\N	1	1	-2151	\N	C	2019-12-20 22:13:53.799521+00	2629
2150	6	grav	\N	\N	1	1	-2150	\N	C	2019-12-20 22:13:53.799521+00	2630
2149	6	Feature	\N	\N	1	1	-2149	\N	C	2019-12-20 22:13:53.799521+00	2631
2148	6	Gr 322	\N	\N	1	1	-2148	\N	C	2019-12-20 22:13:53.799521+00	2632
2147	6	Gr 308	\N	\N	1	1	-2147	\N	C	2019-12-20 22:13:53.799521+00	2633
2146	6	Gr 1c	\N	\N	1	1	-2146	\N	C	2019-12-20 22:13:53.799521+00	2634
2145	6	Gr 366	\N	\N	1	1	-2145	\N	C	2019-12-20 22:13:53.799521+00	2635
2144	6	Gr 911	\N	\N	1	1	-2144	\N	C	2019-12-20 22:13:53.799521+00	2636
2143	6	Gr 110	\N	\N	1	1	-2143	\N	C	2019-12-20 22:13:53.799521+00	2637
2142	6	Gr 1081	\N	\N	1	1	-2142	\N	C	2019-12-20 22:13:53.799521+00	2638
2141	6	Gr 1058	\N	\N	1	1	-2141	\N	C	2019-12-20 22:13:53.799521+00	2639
2140	6	Gr 825	\N	\N	1	1	-2140	\N	C	2019-12-20 22:13:53.799521+00	2640
2139	6	Gr 104	\N	\N	1	1	-2139	\N	C	2019-12-20 22:13:53.799521+00	2641
2138	6	Gr 456	\N	\N	1	1	-2138	\N	C	2019-12-20 22:13:53.799521+00	2642
2137	6	Gr 33	\N	\N	1	1	-2137	\N	C	2019-12-20 22:13:53.799521+00	2643
2136	6	Gr 86	\N	\N	1	1	-2136	\N	C	2019-12-20 22:13:53.799521+00	2644
2135	6	Gr 754	\N	\N	1	1	-2135	\N	C	2019-12-20 22:13:53.799521+00	2645
2134	6	Gr 492	\N	\N	1	1	-2134	\N	C	2019-12-20 22:13:53.799521+00	2646
2133	6	Gr 404	\N	\N	1	1	-2133	\N	C	2019-12-20 22:13:53.799521+00	2647
2132	6	Gr 937	\N	\N	1	1	-2132	\N	C	2019-12-20 22:13:53.799521+00	2648
2131	571	Feature	\N	\N	1	1	-2131	\N	C	2019-12-20 22:13:53.799521+00	2649
2130	6	Gr 599	\N	\N	1	1	-2130	\N	C	2019-12-20 22:13:53.799521+00	2650
2129	6	Gr 214	\N	\N	1	1	-2129	\N	C	2019-12-20 22:13:53.799521+00	2651
2128	6	Gr 585 	\N	\N	1	1	-2128	\N	C	2019-12-20 22:13:53.799521+00	2652
2127	6	Gr 20	\N	\N	1	1	-2127	\N	C	2019-12-20 22:13:53.799521+00	2653
2126	567	Feature	\N	\N	1	1	-2126	\N	C	2019-12-20 22:13:53.799521+00	2654
2125	6	Feature	\N	\N	1	1	-2125	\N	C	2019-12-20 22:13:53.799521+00	2655
2124	551	Feature	\N	\N	1	1	-2124	\N	C	2019-12-20 22:13:53.799521+00	2656
2123	6	Feature	\N	\N	1	1	-2123	\N	C	2019-12-20 22:13:53.799521+00	2657
2122	6	okänt	\N	\N	1	1	-2122	\N	C	2019-12-20 22:13:53.799521+00	2658
2121	6	Feature	\N	\N	1	1	-2121	\N	C	2019-12-20 22:13:53.799521+00	2659
2120	6	Feature	\N	\N	1	1	-2120	\N	C	2019-12-20 22:13:53.799521+00	2660
2119	6	Feature	\N	\N	1	1	-2119	\N	C	2019-12-20 22:13:53.799521+00	2661
2118	6	11	\N	\N	1	1	-2118	\N	C	2019-12-20 22:13:53.799521+00	2662
2117	6	2	\N	\N	1	1	-2117	\N	C	2019-12-20 22:13:53.799521+00	2663
2116	6	3	\N	\N	1	1	-2116	\N	C	2019-12-20 22:13:53.799521+00	2664
2115	6	4	\N	\N	1	1	-2115	\N	C	2019-12-20 22:13:53.799521+00	2665
2114	4	Feature	\N	\N	1	1	-2114	\N	C	2019-12-20 22:13:53.799521+00	2666
2113	551	Feature	\N	\N	1	1	-2113	\N	C	2019-12-20 22:13:53.799521+00	2667
2112	6	Feature	\N	\N	1	1	-2112	\N	C	2019-12-20 22:13:53.799521+00	2668
2111	6	50	\N	\N	1	1	-2111	\N	C	2019-12-20 22:13:53.799521+00	2669
2110	551	Feature	\N	\N	1	1	-2110	\N	C	2019-12-20 22:13:53.799521+00	2670
2109	6	Feature	\N	\N	1	1	-2109	\N	C	2019-12-20 22:13:53.799521+00	2671
2108	569	Feature	\N	\N	1	1	-2108	\N	C	2019-12-20 22:13:53.799521+00	2672
2107	573	Feature	\N	\N	1	1	-2107	\N	C	2019-12-20 22:13:53.799521+00	2673
2106	551	Feature	\N	\N	1	1	-2106	\N	C	2019-12-20 22:13:53.799521+00	2674
2105	551	Feature	\N	\N	1	1	-2105	\N	C	2019-12-20 22:13:53.799521+00	2675
2104	551	Feature	\N	\N	1	1	-2104	\N	C	2019-12-20 22:13:53.799521+00	2676
2103	551	Feature	\N	\N	1	1	-2103	\N	C	2019-12-20 22:13:53.799521+00	2677
2102	551	Feature	\N	\N	1	1	-2102	\N	C	2019-12-20 22:13:53.799521+00	2678
2101	551	Feature	\N	\N	1	1	-2101	\N	C	2019-12-20 22:13:53.799521+00	2679
2100	6	Feature	\N	\N	1	1	-2100	\N	C	2019-12-20 22:13:53.799521+00	2680
2099	551	Feature	\N	\N	1	1	-2099	\N	C	2019-12-20 22:13:53.799521+00	2681
2098	551	Feature	\N	\N	1	1	-2098	\N	C	2019-12-20 22:13:53.799521+00	2682
2097	6	Feature	\N	\N	1	1	-2097	\N	C	2019-12-20 22:13:53.799521+00	2683
2096	551	Feature	\N	\N	1	1	-2096	\N	C	2019-12-20 22:13:53.799521+00	2684
2095	551	Feature	\N	\N	1	1	-2095	\N	C	2019-12-20 22:13:53.799521+00	2685
2094	551	Feature	\N	\N	1	1	-2094	\N	C	2019-12-20 22:13:53.799521+00	2686
2093	551	Feature	\N	\N	1	1	-2093	\N	C	2019-12-20 22:13:53.799521+00	2687
2092	551	Feature	\N	\N	1	1	-2092	\N	C	2019-12-20 22:13:53.799521+00	2688
2091	551	Feature	\N	\N	1	1	-2091	\N	C	2019-12-20 22:13:53.799521+00	2689
2090	550	Feature	\N	\N	1	1	-2090	\N	C	2019-12-20 22:13:53.799521+00	2690
2089	551	Feature	\N	\N	1	1	-2089	\N	C	2019-12-20 22:13:53.799521+00	2691
2088	551	Feature	\N	\N	1	1	-2088	\N	C	2019-12-20 22:13:53.799521+00	2692
2087	551	Feature	\N	\N	1	1	-2087	\N	C	2019-12-20 22:13:53.799521+00	2693
2086	6	suchschnitt 7	\N	\N	1	1	-2086	\N	C	2019-12-20 22:13:53.799521+00	2694
2085	6	fläche 3	\N	\N	1	1	-2085	\N	C	2019-12-20 22:13:53.799521+00	2695
2084	6	Fläche 4	\N	\N	1	1	-2084	\N	C	2019-12-20 22:13:53.799521+00	2696
2083	6	härd 22	\N	\N	1	1	-2083	\N	C	2019-12-20 22:13:53.799521+00	2697
2082	551	Feature	\N	\N	1	1	-2082	\N	C	2019-12-20 22:13:53.799521+00	2698
2081	6	66	\N	\N	1	1	-2081	\N	C	2019-12-20 22:13:53.799521+00	2699
2080	6	6	\N	\N	1	1	-2080	\N	C	2019-12-20 22:13:53.799521+00	2700
2079	6	12	\N	\N	1	1	-2079	\N	C	2019-12-20 22:13:53.799521+00	2701
2078	6	40	\N	\N	1	1	-2078	\N	C	2019-12-20 22:13:53.799521+00	2702
2077	6	52	\N	\N	1	1	-2077	\N	C	2019-12-20 22:13:53.799521+00	2703
2076	6	35	\N	\N	1	1	-2076	\N	C	2019-12-20 22:13:53.799521+00	2704
2075	6	63	\N	\N	1	1	-2075	\N	C	2019-12-20 22:13:53.799521+00	2705
2074	569	Feature	\N	\N	1	1	-2074	\N	C	2019-12-20 22:13:53.799521+00	2706
2073	551	21	\N	\N	1	1	-2073	\N	C	2019-12-20 22:13:53.799521+00	2707
2072	551	109	\N	\N	1	1	-2072	\N	C	2019-12-20 22:13:53.799521+00	2708
2071	551	103	\N	\N	1	1	-2071	\N	C	2019-12-20 22:13:53.799521+00	2709
2070	570	Feature	\N	\N	1	1	-2070	\N	C	2019-12-20 22:13:53.799521+00	2710
2069	551	Feature	\N	\N	1	1	-2069	\N	C	2019-12-20 22:13:53.799521+00	2711
2068	6	Feature	\N	\N	1	1	-2068	\N	C	2019-12-20 22:13:53.799521+00	2712
2067	551	Feature	\N	\N	1	1	-2067	\N	C	2019-12-20 22:13:53.799521+00	2713
2066	6	Feature	\N	\N	1	1	-2066	\N	C	2019-12-20 22:13:53.799521+00	2714
2065	6	Feature	\N	\N	1	1	-2065	\N	C	2019-12-20 22:13:53.799521+00	2715
2064	6	Feature	\N	\N	1	1	-2064	\N	C	2019-12-20 22:13:53.799521+00	2716
2063	551	Feature	\N	\N	1	1	-2063	\N	C	2019-12-20 22:13:53.799521+00	2717
2062	551	Feature	\N	\N	1	1	-2062	\N	C	2019-12-20 22:13:53.799521+00	2718
2061	551	105	\N	\N	1	1	-2061	\N	C	2019-12-20 22:13:53.799521+00	2719
2060	551	14	\N	\N	1	1	-2060	\N	C	2019-12-20 22:13:53.799521+00	2720
2059	550	106	\N	\N	1	1	-2059	\N	C	2019-12-20 22:13:53.799521+00	2721
2058	570	Feature	\N	\N	1	1	-2058	\N	C	2019-12-20 22:13:53.799521+00	2722
2057	551	Feature	\N	\N	1	1	-2057	\N	C	2019-12-20 22:13:53.799521+00	2723
2056	551	Feature	\N	\N	1	1	-2056	\N	C	2019-12-20 22:13:53.799521+00	2724
2055	6	Feature	\N	\N	1	1	-2055	\N	C	2019-12-20 22:13:53.799521+00	2725
2054	551	Feature	\N	\N	1	1	-2054	\N	C	2019-12-20 22:13:53.799521+00	2726
2053	6	Feature	\N	\N	1	1	-2053	\N	C	2019-12-20 22:13:53.799521+00	2727
2052	6	gånggrift	\N	\N	1	1	-2052	\N	C	2019-12-20 22:13:53.799521+00	2728
2051	6	gånggrift	\N	\N	1	1	-2051	\N	C	2019-12-20 22:13:53.799521+00	2729
2050	6	gånggrift	\N	\N	1	1	-2050	\N	C	2019-12-20 22:13:53.799521+00	2730
2049	6	gånggrift	\N	\N	1	1	-2049	\N	C	2019-12-20 22:13:53.799521+00	2731
2048	551	Feature	\N	\N	1	1	-2048	\N	C	2019-12-20 22:13:53.799521+00	2732
2047	551	105	\N	\N	1	1	-2047	\N	C	2019-12-20 22:13:53.799521+00	2733
2046	551	Feature	\N	\N	1	1	-2046	\N	C	2019-12-20 22:13:53.799521+00	2734
2045	6	Feature	\N	\N	1	1	-2045	\N	C	2019-12-20 22:13:53.799521+00	2735
2044	6	Feature	\N	\N	1	1	-2044	\N	C	2019-12-20 22:13:53.799521+00	2736
2043	551	Feature	\N	\N	1	1	-2043	\N	C	2019-12-20 22:13:53.799521+00	2737
2042	551	Feature	\N	\N	1	1	-2042	\N	C	2019-12-20 22:13:53.799521+00	2738
2041	551	Feature	\N	\N	1	1	-2041	\N	C	2019-12-20 22:13:53.799521+00	2739
2040	551	Feature	\N	\N	1	1	-2040	\N	C	2019-12-20 22:13:53.799521+00	2740
2039	551	Feature	\N	\N	1	1	-2039	\N	C	2019-12-20 22:13:53.799521+00	2741
2038	551	Feature	\N	\N	1	1	-2038	\N	C	2019-12-20 22:13:53.799521+00	2742
2037	551	Feature	\N	\N	1	1	-2037	\N	C	2019-12-20 22:13:53.799521+00	2743
2036	551	Feature	\N	\N	1	1	-2036	\N	C	2019-12-20 22:13:53.799521+00	2744
2035	551	Feature	\N	\N	1	1	-2035	\N	C	2019-12-20 22:13:53.799521+00	2745
2034	551	Feature	\N	\N	1	1	-2034	\N	C	2019-12-20 22:13:53.799521+00	2746
2033	551	Feature	\N	\N	1	1	-2033	\N	C	2019-12-20 22:13:53.799521+00	2747
2032	551	Feature	\N	\N	1	1	-2032	\N	C	2019-12-20 22:13:53.799521+00	2748
2031	551	Feature	\N	\N	1	1	-2031	\N	C	2019-12-20 22:13:53.799521+00	2749
2030	551	Feature	\N	\N	1	1	-2030	\N	C	2019-12-20 22:13:53.799521+00	2750
2029	551	Feature	\N	\N	1	1	-2029	\N	C	2019-12-20 22:13:53.799521+00	2751
2028	551	Feature	\N	\N	1	1	-2028	\N	C	2019-12-20 22:13:53.799521+00	2752
2027	551	Feature	\N	\N	1	1	-2027	\N	C	2019-12-20 22:13:53.799521+00	2753
2026	551	Feature	\N	\N	1	1	-2026	\N	C	2019-12-20 22:13:53.799521+00	2754
2025	551	Feature	\N	\N	1	1	-2025	\N	C	2019-12-20 22:13:53.799521+00	2755
2024	551	Feature	\N	\N	1	1	-2024	\N	C	2019-12-20 22:13:53.799521+00	2756
2023	551	Feature	\N	\N	1	1	-2023	\N	C	2019-12-20 22:13:53.799521+00	2757
2022	551	Feature	\N	\N	1	1	-2022	\N	C	2019-12-20 22:13:53.799521+00	2758
561	27	feature	Open-air; Close to the coast	\N	4	1	-561	\N	C	2019-12-20 22:14:28.053842+00	3332
560	27	feature	Open-air; Close to the coast	\N	4	1	-560	\N	C	2019-12-20 22:14:28.053842+00	3333
559	27	feature	Open-air; Close to the coast	\N	4	1	-559	\N	C	2019-12-20 22:14:28.053842+00	3334
558	27	feature	Open-air; Close to the coast	\N	4	1	-558	\N	C	2019-12-20 22:14:28.053842+00	3335
557	27	feature	Open-air; Close to the coast	\N	4	1	-557	\N	C	2019-12-20 22:14:28.053842+00	3336
556	27	feature	Open-air; Close to the coast	\N	4	1	-556	\N	C	2019-12-20 22:14:28.053842+00	3337
555	27	feature	Open-air; Close to the coast	\N	4	1	-555	\N	C	2019-12-20 22:14:28.053842+00	3338
554	27	feature	Open-air; Close to the coast	\N	4	1	-554	\N	C	2019-12-20 22:14:28.053842+00	3339
553	27	feature	Open-air; Close to the coast	\N	4	1	-553	\N	C	2019-12-20 22:14:28.053842+00	3340
552	27	feature	Open-air; Close to the coast	\N	4	1	-552	\N	C	2019-12-20 22:14:28.053842+00	3341
551	27	feature	Open-air; Close to the coast	\N	4	1	-551	\N	C	2019-12-20 22:14:28.053842+00	3342
550	27	feature	Open-air; Close to the coast	\N	4	1	-550	\N	C	2019-12-20 22:14:28.053842+00	3343
549	27	feature	Open-air; Close to the coast	\N	4	1	-549	\N	C	2019-12-20 22:14:28.053842+00	3344
548	27	feature	Open-air; Close to the coast	\N	4	1	-548	\N	C	2019-12-20 22:14:28.053842+00	3345
547	27	feature	Open-air; Close to the coast	\N	4	1	-547	\N	C	2019-12-20 22:14:28.053842+00	3346
524	27	feature	Open-air; Close to the coast	\N	4	1	-524	\N	C	2019-12-20 22:14:28.053842+00	3369
523	27	feature	Open-air; Close to the coast	\N	4	1	-523	\N	C	2019-12-20 22:14:28.053842+00	3370
522	27	feature	Open-air; Close to the coast	\N	4	1	-522	\N	C	2019-12-20 22:14:28.053842+00	3371
521	27	feature	Open-air; Close to the coast	\N	4	1	-521	\N	C	2019-12-20 22:14:28.053842+00	3372
520	27	feature	Open-air; Close to the coast	\N	4	1	-520	\N	C	2019-12-20 22:14:28.053842+00	3373
519	27	feature	Open-air; Close to the coast	\N	4	1	-519	\N	C	2019-12-20 22:14:28.053842+00	3374
518	27	feature	Open-air; Close to the coast	\N	4	1	-518	\N	C	2019-12-20 22:14:28.053842+00	3375
517	27	feature	Open-air; Close to the coast	\N	4	1	-517	\N	C	2019-12-20 22:14:28.053842+00	3376
516	27	feature	Open-air; Close to the coast	\N	4	1	-516	\N	C	2019-12-20 22:14:28.053842+00	3377
515	27	feature	Open-air; Close to the coast	\N	4	1	-515	\N	C	2019-12-20 22:14:28.053842+00	3378
514	27	feature	Open-air; Close to the coast	\N	4	1	-514	\N	C	2019-12-20 22:14:28.053842+00	3379
513	27	feature	Open-air; Close to the coast	\N	4	1	-513	\N	C	2019-12-20 22:14:28.053842+00	3380
512	27	feature	Open-air; Close to the coast	\N	4	1	-512	\N	C	2019-12-20 22:14:28.053842+00	3381
511	27	feature	Open-air; Close to the coast	\N	4	1	-511	\N	C	2019-12-20 22:14:28.053842+00	3382
510	27	feature	Open-air; Close to the coast	\N	4	1	-510	\N	C	2019-12-20 22:14:28.053842+00	3383
509	27	feature	Open-air; Close to the coast	\N	4	1	-509	\N	C	2019-12-20 22:14:28.053842+00	3384
508	27	feature	Open-air; Close to the coast	\N	4	1	-508	\N	C	2019-12-20 22:14:28.053842+00	3385
507	27	feature	Open-air; Close to the coast	\N	4	1	-507	\N	C	2019-12-20 22:14:28.053842+00	3386
506	27	feature	Open-air; Close to the coast	\N	4	1	-506	\N	C	2019-12-20 22:14:28.053842+00	3387
505	27	feature	Open-air; Close to the coast	\N	4	1	-505	\N	C	2019-12-20 22:14:28.053842+00	3388
504	27	feature	Open-air; Close to the coast	\N	4	1	-504	\N	C	2019-12-20 22:14:28.053842+00	3389
503	27	feature	Open-air; Close to the coast	\N	4	1	-503	\N	C	2019-12-20 22:14:28.053842+00	3390
502	27	feature	Open-air; Close to the coast	\N	4	1	-502	\N	C	2019-12-20 22:14:28.053842+00	3391
501	27	feature	Open-air; Close to the coast	\N	4	1	-501	\N	C	2019-12-20 22:14:28.053842+00	3392
500	27	feature	Open-air; Close to the coast	\N	4	1	-500	\N	C	2019-12-20 22:14:28.053842+00	3393
499	27	feature	Open-air; Close to the coast	\N	4	1	-499	\N	C	2019-12-20 22:14:28.053842+00	3394
498	27	feature	Open-air; Close to the coast	\N	4	1	-498	\N	C	2019-12-20 22:14:28.053842+00	3395
497	27	feature	Open-air; Close to the coast	\N	4	1	-497	\N	C	2019-12-20 22:14:28.053842+00	3396
496	27	feature	Open-air; Close to the coast	\N	4	1	-496	\N	C	2019-12-20 22:14:28.053842+00	3397
495	27	feature	Open-air; Close to the coast	\N	4	1	-495	\N	C	2019-12-20 22:14:28.053842+00	3398
494	27	feature	Open-air; Close to the coast	\N	4	1	-494	\N	C	2019-12-20 22:14:28.053842+00	3399
493	27	feature	Open-air; Close to the coast	\N	4	1	-493	\N	C	2019-12-20 22:14:28.053842+00	3400
492	27	feature	Open-air; Inland	\N	4	1	-492	\N	C	2019-12-20 22:14:28.053842+00	3401
491	27	feature	Open-air; Inland	\N	4	1	-491	\N	C	2019-12-20 22:14:28.053842+00	3402
490	27	feature	Open-air; Inland	\N	4	1	-490	\N	C	2019-12-20 22:14:28.053842+00	3403
489	27	feature	Open-air; Lake shore	\N	4	1	-489	\N	C	2019-12-20 22:14:28.053842+00	3404
488	27	feature	Open-air; Inland	\N	4	1	-488	\N	C	2019-12-20 22:14:28.053842+00	3405
487	27	feature	Open-air; Inland	\N	4	1	-487	\N	C	2019-12-20 22:14:28.053842+00	3406
486	27	feature	Open-air; Inland	\N	4	1	-486	\N	C	2019-12-20 22:14:28.053842+00	3407
485	27	feature	Open-air; Inland	\N	4	1	-485	\N	C	2019-12-20 22:14:28.053842+00	3408
484	27	feature	Open-air; Inland	\N	4	1	-484	\N	C	2019-12-20 22:14:28.053842+00	3409
483	27	feature	Open-air; Inland	\N	4	1	-483	\N	C	2019-12-20 22:14:28.053842+00	3410
482	27	feature	Open-air; Inland	\N	4	1	-482	\N	C	2019-12-20 22:14:28.053842+00	3411
481	27	feature	Open-air; Inland	\N	4	1	-481	\N	C	2019-12-20 22:14:28.053842+00	3412
480	27	feature	Open-air; Inland	\N	4	1	-480	\N	C	2019-12-20 22:14:28.053842+00	3413
479	27	feature	Open-air; Inland	\N	4	1	-479	\N	C	2019-12-20 22:14:28.053842+00	3414
478	27	feature	Open-air; Inland	\N	4	1	-478	\N	C	2019-12-20 22:14:28.053842+00	3415
477	27	feature	Open-air; Inland	\N	4	1	-477	\N	C	2019-12-20 22:14:28.053842+00	3416
476	27	feature	Open-air; Inland	\N	4	1	-476	\N	C	2019-12-20 22:14:28.053842+00	3417
475	27	feature	Open-air; Inland	\N	4	1	-475	\N	C	2019-12-20 22:14:28.053842+00	3418
474	27	feature	Open-air; Inland	\N	4	1	-474	\N	C	2019-12-20 22:14:28.053842+00	3419
473	27	feature	Open-air; Inland	\N	4	1	-473	\N	C	2019-12-20 22:14:28.053842+00	3420
472	27	feature	Open-air; Inland	\N	4	1	-472	\N	C	2019-12-20 22:14:28.053842+00	3421
471	27	feature	Open-air; Inland	\N	4	1	-471	\N	C	2019-12-20 22:14:28.053842+00	3422
470	27	feature	Open-air; Inland	\N	4	1	-470	\N	C	2019-12-20 22:14:28.053842+00	3423
469	27	feature	Open-air; Inland	\N	4	1	-469	\N	C	2019-12-20 22:14:28.053842+00	3424
468	34	feature	Rock shelter/Cave; Inland	\N	4	1	-468	\N	C	2019-12-20 22:14:28.053842+00	3425
467	34	feature	Rock shelter/Cave; Inland	\N	4	1	-467	\N	C	2019-12-20 22:14:28.053842+00	3426
466	34	feature	Rock shelter/Cave; Inland	\N	4	1	-466	\N	C	2019-12-20 22:14:28.053842+00	3427
465	34	feature	Rock shelter/Cave; Inland	\N	4	1	-465	\N	C	2019-12-20 22:14:28.053842+00	3428
464	34	feature	Rock shelter/Cave; Inland	\N	4	1	-464	\N	C	2019-12-20 22:14:28.053842+00	3429
463	34	feature	Rock shelter/Cave; Inland	\N	4	1	-463	\N	C	2019-12-20 22:14:28.053842+00	3430
462	27	feature	Open-air; Inland	\N	4	1	-462	\N	C	2019-12-20 22:14:28.053842+00	3431
461	27	feature	Open-air; Inland	\N	4	1	-461	\N	C	2019-12-20 22:14:28.053842+00	3432
460	27	feature	Open-air; Inland	\N	4	1	-460	\N	C	2019-12-20 22:14:28.053842+00	3433
459	27	feature	Open-air; Inland	\N	4	1	-459	\N	C	2019-12-20 22:14:28.053842+00	3434
458	27	feature	Open-air; Inland	\N	4	1	-458	\N	C	2019-12-20 22:14:28.053842+00	3435
457	27	feature	Open-air; Inland	\N	4	1	-457	\N	C	2019-12-20 22:14:28.053842+00	3436
456	27	feature	Open-air; Inland	\N	4	1	-456	\N	C	2019-12-20 22:14:28.053842+00	3437
455	27	feature	Open-air; Inland	\N	4	1	-455	\N	C	2019-12-20 22:14:28.053842+00	3438
454	27	feature	Open-air; Inland	\N	4	1	-454	\N	C	2019-12-20 22:14:28.053842+00	3439
453	27	feature	Open-air; Inland	\N	4	1	-453	\N	C	2019-12-20 22:14:28.053842+00	3440
452	27	feature	Open-air; Inland	\N	4	1	-452	\N	C	2019-12-20 22:14:28.053842+00	3441
451	27	feature	Open-air; Inland	\N	4	1	-451	\N	C	2019-12-20 22:14:28.053842+00	3442
450	34	feature	Rock shelter/Cave; Inland	\N	4	1	-450	\N	C	2019-12-20 22:14:28.053842+00	3443
449	27	feature	Open-air; Close to the coast	\N	4	1	-449	\N	C	2019-12-20 22:14:28.053842+00	3444
448	27	feature	Open-air; Close to the coast	\N	4	1	-448	\N	C	2019-12-20 22:14:28.053842+00	3445
447	27	feature	Open-air; Close to the coast	\N	4	1	-447	\N	C	2019-12-20 22:14:28.053842+00	3446
446	27	feature	Open-air; Close to the coast	\N	4	1	-446	\N	C	2019-12-20 22:14:28.053842+00	3447
445	27	feature	Open-air; Close to the coast	\N	4	1	-445	\N	C	2019-12-20 22:14:28.053842+00	3448
444	27	feature	Open-air; Close to the coast	\N	4	1	-444	\N	C	2019-12-20 22:14:28.053842+00	3449
443	27	feature	Open-air; Inland	\N	4	1	-443	\N	C	2019-12-20 22:14:28.053842+00	3450
442	27	feature	Open-air; Inland	\N	4	1	-442	\N	C	2019-12-20 22:14:28.053842+00	3451
441	27	feature	Open-air; Inland	\N	4	1	-441	\N	C	2019-12-20 22:14:28.053842+00	3452
440	12	feature	Shell midden; Lake shore	\N	4	1	-440	\N	C	2019-12-20 22:14:28.053842+00	3453
439	12	feature	Shell midden; Lake shore	\N	4	1	-439	\N	C	2019-12-20 22:14:28.053842+00	3454
438	12	feature	Shell midden; Lake shore	\N	4	1	-438	\N	C	2019-12-20 22:14:28.053842+00	3455
437	27	feature	Open-air; Close to the coast	\N	4	1	-437	\N	C	2019-12-20 22:14:28.053842+00	3456
436	27	feature	Open-air; Close to the coast	\N	4	1	-436	\N	C	2019-12-20 22:14:28.053842+00	3457
435	27	feature	Open-air; Close to the coast	\N	4	1	-435	\N	C	2019-12-20 22:14:28.053842+00	3458
434	27	feature	Open-air; Close to the coast	\N	4	1	-434	\N	C	2019-12-20 22:14:28.053842+00	3459
433	27	feature	Open-air; Close to the coast	\N	4	1	-433	\N	C	2019-12-20 22:14:28.053842+00	3460
432	27	feature	Open-air; Close to the coast	\N	4	1	-432	\N	C	2019-12-20 22:14:28.053842+00	3461
431	27	feature	Open-air; Close to the coast	\N	4	1	-431	\N	C	2019-12-20 22:14:28.053842+00	3462
430	27	feature	Open-air; Close to the coast	\N	4	1	-430	\N	C	2019-12-20 22:14:28.053842+00	3463
429	27	feature	Open-air; Close to the coast	\N	4	1	-429	\N	C	2019-12-20 22:14:28.053842+00	3464
428	27	feature	Open-air; Close to the coast	\N	4	1	-428	\N	C	2019-12-20 22:14:28.053842+00	3465
427	27	feature	Open-air; Close to the coast	\N	4	1	-427	\N	C	2019-12-20 22:14:28.053842+00	3466
426	27	feature	Open-air; Close to the coast	\N	4	1	-426	\N	C	2019-12-20 22:14:28.053842+00	3467
425	27	feature	Open-air; Close to the coast	\N	4	1	-425	\N	C	2019-12-20 22:14:28.053842+00	3468
424	27	feature	Open-air; Close to the coast	\N	4	1	-424	\N	C	2019-12-20 22:14:28.053842+00	3469
423	27	feature	Open-air; Close to the coast	\N	4	1	-423	\N	C	2019-12-20 22:14:28.053842+00	3470
422	27	feature	Open-air; Close to the coast	\N	4	1	-422	\N	C	2019-12-20 22:14:28.053842+00	3471
421	27	feature	Open-air; Close to the coast	\N	4	1	-421	\N	C	2019-12-20 22:14:28.053842+00	3472
420	27	feature	Open-air; Close to the coast	\N	4	1	-420	\N	C	2019-12-20 22:14:28.053842+00	3473
419	27	feature	Open-air; Close to the coast	\N	4	1	-419	\N	C	2019-12-20 22:14:28.053842+00	3474
418	27	feature	Open-air; Close to the coast	\N	4	1	-418	\N	C	2019-12-20 22:14:28.053842+00	3475
417	27	feature	Open-air; Close to the coast	\N	4	1	-417	\N	C	2019-12-20 22:14:28.053842+00	3476
416	27	feature	Open-air; Close to the coast	\N	4	1	-416	\N	C	2019-12-20 22:14:28.053842+00	3477
415	27	feature	Open-air; Close to the coast	\N	4	1	-415	\N	C	2019-12-20 22:14:28.053842+00	3478
414	27	feature	Open-air; Close to the coast	\N	4	1	-414	\N	C	2019-12-20 22:14:28.053842+00	3479
413	27	feature	Open-air; Close to the coast	\N	4	1	-413	\N	C	2019-12-20 22:14:28.053842+00	3480
412	27	feature	Open-air; Close to the coast	\N	4	1	-412	\N	C	2019-12-20 22:14:28.053842+00	3481
411	27	feature	Open-air; Close to the coast	\N	4	1	-411	\N	C	2019-12-20 22:14:28.053842+00	3482
410	27	feature	Open-air; Close to the coast	\N	4	1	-410	\N	C	2019-12-20 22:14:28.053842+00	3483
409	27	feature	Open-air; Close to the coast	\N	4	1	-409	\N	C	2019-12-20 22:14:28.053842+00	3484
408	27	feature	Open-air; Close to the coast	\N	4	1	-408	\N	C	2019-12-20 22:14:28.053842+00	3485
407	27	feature	Open-air; Close to the coast	\N	4	1	-407	\N	C	2019-12-20 22:14:28.053842+00	3486
406	27	feature	Open-air; Close to the coast	\N	4	1	-406	\N	C	2019-12-20 22:14:28.053842+00	3487
405	27	feature	Open-air; Close to the coast	\N	4	1	-405	\N	C	2019-12-20 22:14:28.053842+00	3488
404	27	feature	Open-air; Close to the coast	\N	4	1	-404	\N	C	2019-12-20 22:14:28.053842+00	3489
403	27	feature	Open-air; Close to the coast	\N	4	1	-403	\N	C	2019-12-20 22:14:28.053842+00	3490
402	27	feature	Open-air; Close to the coast	\N	4	1	-402	\N	C	2019-12-20 22:14:28.053842+00	3491
401	27	feature	Open-air; Close to the coast	\N	4	1	-401	\N	C	2019-12-20 22:14:28.053842+00	3492
400	27	feature	Open-air; Close to the coast	\N	4	1	-400	\N	C	2019-12-20 22:14:28.053842+00	3493
399	27	feature	Open-air; Close to the coast	\N	4	1	-399	\N	C	2019-12-20 22:14:28.053842+00	3494
398	27	feature	Open-air; Close to the coast	\N	4	1	-398	\N	C	2019-12-20 22:14:28.053842+00	3495
397	27	feature	Open-air; Inland	\N	4	1	-397	\N	C	2019-12-20 22:14:28.053842+00	3496
396	27	feature	Open-air; Inland	\N	4	1	-396	\N	C	2019-12-20 22:14:28.053842+00	3497
395	27	feature	Open-air; Inland	\N	4	1	-395	\N	C	2019-12-20 22:14:28.053842+00	3498
394	27	feature	Open-air; Inland	\N	4	1	-394	\N	C	2019-12-20 22:14:28.053842+00	3499
393	27	feature	Open-air; Inland	\N	4	1	-393	\N	C	2019-12-20 22:14:28.053842+00	3500
392	27	feature	Open-air; Inland	\N	4	1	-392	\N	C	2019-12-20 22:14:28.053842+00	3501
391	27	feature	Open-air; Inland	\N	4	1	-391	\N	C	2019-12-20 22:14:28.053842+00	3502
390	27	feature	Open-air; Inland	\N	4	1	-390	\N	C	2019-12-20 22:14:28.053842+00	3503
389	27	feature	Open-air; Inland	\N	4	1	-389	\N	C	2019-12-20 22:14:28.053842+00	3504
388	27	feature	Open-air; Inland	\N	4	1	-388	\N	C	2019-12-20 22:14:28.053842+00	3505
387	27	feature	Open-air; Inland	\N	4	1	-387	\N	C	2019-12-20 22:14:28.053842+00	3506
386	27	feature	Open-air; Inland	\N	4	1	-386	\N	C	2019-12-20 22:14:28.053842+00	3507
385	27	feature	Open-air; Inland	\N	4	1	-385	\N	C	2019-12-20 22:14:28.053842+00	3508
384	27	feature	Open-air; Inland	\N	4	1	-384	\N	C	2019-12-20 22:14:28.053842+00	3509
383	27	feature	Open-air; Inland	\N	4	1	-383	\N	C	2019-12-20 22:14:28.053842+00	3510
382	27	feature	Open-air; Inland	\N	4	1	-382	\N	C	2019-12-20 22:14:28.053842+00	3511
381	27	feature	Open-air; Inland	\N	4	1	-381	\N	C	2019-12-20 22:14:28.053842+00	3512
380	27	feature	Open-air; Inland	\N	4	1	-380	\N	C	2019-12-20 22:14:28.053842+00	3513
379	27	feature	Open-air; Inland	\N	4	1	-379	\N	C	2019-12-20 22:14:28.053842+00	3514
378	27	feature	Open-air; Inland	\N	4	1	-378	\N	C	2019-12-20 22:14:28.053842+00	3515
377	27	feature	Open-air; Inland	\N	4	1	-377	\N	C	2019-12-20 22:14:28.053842+00	3516
376	27	feature	Open-air; Inland	\N	4	1	-376	\N	C	2019-12-20 22:14:28.053842+00	3517
375	27	feature	Open-air; Inland	\N	4	1	-375	\N	C	2019-12-20 22:14:28.053842+00	3518
374	27	feature	Open-air; Inland	\N	4	1	-374	\N	C	2019-12-20 22:14:28.053842+00	3519
373	27	feature	Open-air; Inland	\N	4	1	-373	\N	C	2019-12-20 22:14:28.053842+00	3520
372	27	feature	Open-air; Inland	\N	4	1	-372	\N	C	2019-12-20 22:14:28.053842+00	3521
371	27	feature	Open-air; Inland	\N	4	1	-371	\N	C	2019-12-20 22:14:28.053842+00	3522
370	27	feature	Open-air; Inland	\N	4	1	-370	\N	C	2019-12-20 22:14:28.053842+00	3523
369	27	feature	Open-air; Inland	\N	4	1	-369	\N	C	2019-12-20 22:14:28.053842+00	3524
368	27	feature	Open-air; Inland	\N	4	1	-368	\N	C	2019-12-20 22:14:28.053842+00	3525
367	27	feature	Open-air; Inland	\N	4	1	-367	\N	C	2019-12-20 22:14:28.053842+00	3526
366	27	feature	Open-air; Inland	\N	4	1	-366	\N	C	2019-12-20 22:14:28.053842+00	3527
365	27	feature	Open-air; Inland	\N	4	1	-365	\N	C	2019-12-20 22:14:28.053842+00	3528
364	27	feature	Open-air; Inland	\N	4	1	-364	\N	C	2019-12-20 22:14:28.053842+00	3529
363	27	feature	Open-air; Inland	\N	4	1	-363	\N	C	2019-12-20 22:14:28.053842+00	3530
362	27	feature	Open-air; Inland	\N	4	1	-362	\N	C	2019-12-20 22:14:28.053842+00	3531
361	27	feature	Open-air; Inland	\N	4	1	-361	\N	C	2019-12-20 22:14:28.053842+00	3532
360	27	feature	Open-air; Inland	\N	4	1	-360	\N	C	2019-12-20 22:14:28.053842+00	3533
359	27	feature	Open-air; Inland	\N	4	1	-359	\N	C	2019-12-20 22:14:28.053842+00	3534
358	27	feature	Open-air; Inland	\N	4	1	-358	\N	C	2019-12-20 22:14:28.053842+00	3535
357	12	feature	Shell midden; Lake shore	\N	4	1	-357	\N	C	2019-12-20 22:14:28.053842+00	3536
356	12	feature	Shell midden; Lake shore	\N	4	1	-356	\N	C	2019-12-20 22:14:28.053842+00	3537
355	12	feature	Shell midden; Lake shore	\N	4	1	-355	\N	C	2019-12-20 22:14:28.053842+00	3538
354	12	feature	Shell midden; Lake shore	\N	4	1	-354	\N	C	2019-12-20 22:14:28.053842+00	3539
353	12	feature	Shell midden; Lake shore	\N	4	1	-353	\N	C	2019-12-20 22:14:28.053842+00	3540
352	12	feature	Shell midden; Lake shore	\N	4	1	-352	\N	C	2019-12-20 22:14:28.053842+00	3541
351	12	feature	Shell midden; Lake shore	\N	4	1	-351	\N	C	2019-12-20 22:14:28.053842+00	3542
350	12	feature	Shell midden; Lake shore	\N	4	1	-350	\N	C	2019-12-20 22:14:28.053842+00	3543
349	12	feature	Shell midden; Lake shore	\N	4	1	-349	\N	C	2019-12-20 22:14:28.053842+00	3544
348	12	feature	Shell midden; Lake shore	\N	4	1	-348	\N	C	2019-12-20 22:14:28.053842+00	3545
347	27	feature	Open-air; Close to the coast	\N	4	1	-347	\N	C	2019-12-20 22:14:28.053842+00	3546
346	27	feature	Open-air; Close to the coast	\N	4	1	-346	\N	C	2019-12-20 22:14:28.053842+00	3547
345	27	feature	Open-air; Close to the coast	\N	4	1	-345	\N	C	2019-12-20 22:14:28.053842+00	3548
344	27	feature	Open-air; Close to the coast	\N	4	1	-344	\N	C	2019-12-20 22:14:28.053842+00	3549
343	27	feature	Open-air; Close to the coast	\N	4	1	-343	\N	C	2019-12-20 22:14:28.053842+00	3550
342	27	feature	Open-air; Inland	\N	4	1	-342	\N	C	2019-12-20 22:14:28.053842+00	3551
341	27	feature	Open-air; Inland	\N	4	1	-341	\N	C	2019-12-20 22:14:28.053842+00	3552
340	27	feature	Open-air; Inland	\N	4	1	-340	\N	C	2019-12-20 22:14:28.053842+00	3553
339	27	feature	Open-air; Inland	\N	4	1	-339	\N	C	2019-12-20 22:14:28.053842+00	3554
338	27	feature	Open-air; Inland	\N	4	1	-338	\N	C	2019-12-20 22:14:28.053842+00	3555
337	27	feature	Open-air; Inland	\N	4	1	-337	\N	C	2019-12-20 22:14:28.053842+00	3556
336	27	feature	Open-air; Inland	\N	4	1	-336	\N	C	2019-12-20 22:14:28.053842+00	3557
335	27	feature	Open-air; Inland	\N	4	1	-335	\N	C	2019-12-20 22:14:28.053842+00	3558
334	27	feature	Open-air; Inland	\N	4	1	-334	\N	C	2019-12-20 22:14:28.053842+00	3559
333	27	feature	Open-air; Inland	\N	4	1	-333	\N	C	2019-12-20 22:14:28.053842+00	3560
332	27	feature	Open-air; Inland	\N	4	1	-332	\N	C	2019-12-20 22:14:28.053842+00	3561
331	27	feature	Open-air; Inland	\N	4	1	-331	\N	C	2019-12-20 22:14:28.053842+00	3562
330	27	feature	Open-air; Inland	\N	4	1	-330	\N	C	2019-12-20 22:14:28.053842+00	3563
329	27	feature	Open-air; Inland	\N	4	1	-329	\N	C	2019-12-20 22:14:28.053842+00	3564
328	27	feature	Open-air; Inland	\N	4	1	-328	\N	C	2019-12-20 22:14:28.053842+00	3565
327	27	feature	Open-air; Inland	\N	4	1	-327	\N	C	2019-12-20 22:14:28.053842+00	3566
326	27	feature	Open-air; Inland	\N	4	1	-326	\N	C	2019-12-20 22:14:28.053842+00	3567
325	27	feature	Open-air; Inland	\N	4	1	-325	\N	C	2019-12-20 22:14:28.053842+00	3568
324	27	feature	Open-air; Inland	\N	4	1	-324	\N	C	2019-12-20 22:14:28.053842+00	3569
323	27	feature	Open-air; Inland	\N	4	1	-323	\N	C	2019-12-20 22:14:28.053842+00	3570
322	27	feature	Open-air; Inland	\N	4	1	-322	\N	C	2019-12-20 22:14:28.053842+00	3571
321	27	feature	Open-air; Inland	\N	4	1	-321	\N	C	2019-12-20 22:14:28.053842+00	3572
320	27	feature	Open-air; Inland	\N	4	1	-320	\N	C	2019-12-20 22:14:28.053842+00	3573
319	27	feature	Open-air; Inland	\N	4	1	-319	\N	C	2019-12-20 22:14:28.053842+00	3574
318	27	feature	Open-air; Inland	\N	4	1	-318	\N	C	2019-12-20 22:14:28.053842+00	3575
317	27	feature	Open-air; Inland	\N	4	1	-317	\N	C	2019-12-20 22:14:28.053842+00	3576
316	27	feature	Open-air; Inland	\N	4	1	-316	\N	C	2019-12-20 22:14:28.053842+00	3577
315	27	feature	Open-air; Inland	\N	4	1	-315	\N	C	2019-12-20 22:14:28.053842+00	3578
314	27	feature	Open-air; Inland	\N	4	1	-314	\N	C	2019-12-20 22:14:28.053842+00	3579
313	27	feature	Open-air; Inland	\N	4	1	-313	\N	C	2019-12-20 22:14:28.053842+00	3580
312	27	feature	Open-air; Inland	\N	4	1	-312	\N	C	2019-12-20 22:14:28.053842+00	3581
311	27	feature	Open-air; Inland	\N	4	1	-311	\N	C	2019-12-20 22:14:28.053842+00	3582
310	27	feature	Open-air; Inland	\N	4	1	-310	\N	C	2019-12-20 22:14:28.053842+00	3583
309	27	feature	Open-air; Inland	\N	4	1	-309	\N	C	2019-12-20 22:14:28.053842+00	3584
308	27	feature	Open-air; Inland	\N	4	1	-308	\N	C	2019-12-20 22:14:28.053842+00	3585
307	27	feature	Open-air; Inland	\N	4	1	-307	\N	C	2019-12-20 22:14:28.053842+00	3586
306	27	feature	Open-air; Inland	\N	4	1	-306	\N	C	2019-12-20 22:14:28.053842+00	3587
305	27	feature	Open-air; Inland	\N	4	1	-305	\N	C	2019-12-20 22:14:28.053842+00	3588
304	27	feature	Open-air; Inland	\N	4	1	-304	\N	C	2019-12-20 22:14:28.053842+00	3589
303	27	feature	Open-air; Inland	\N	4	1	-303	\N	C	2019-12-20 22:14:28.053842+00	3590
302	27	feature	Open-air; Inland	\N	4	1	-302	\N	C	2019-12-20 22:14:28.053842+00	3591
301	27	feature	Open-air; Inland	\N	4	1	-301	\N	C	2019-12-20 22:14:28.053842+00	3592
300	27	feature	Open-air; Inland	\N	4	1	-300	\N	C	2019-12-20 22:14:28.053842+00	3593
299	27	feature	Open-air; Inland	\N	4	1	-299	\N	C	2019-12-20 22:14:28.053842+00	3594
298	27	feature	Open-air; Inland	\N	4	1	-298	\N	C	2019-12-20 22:14:28.053842+00	3595
297	27	feature	Open-air; Inland	\N	4	1	-297	\N	C	2019-12-20 22:14:28.053842+00	3596
296	27	feature	Open-air; Inland	\N	4	1	-296	\N	C	2019-12-20 22:14:28.053842+00	3597
295	27	feature	Open-air; Inland	\N	4	1	-295	\N	C	2019-12-20 22:14:28.053842+00	3598
294	27	feature	Open-air; Inland	\N	4	1	-294	\N	C	2019-12-20 22:14:28.053842+00	3599
293	27	feature	Open-air; Inland	\N	4	1	-293	\N	C	2019-12-20 22:14:28.053842+00	3600
292	27	feature	Open-air; Inland	\N	4	1	-292	\N	C	2019-12-20 22:14:28.053842+00	3601
291	27	feature	Open-air; Inland	\N	4	1	-291	\N	C	2019-12-20 22:14:28.053842+00	3602
290	27	feature	Open-air; Inland	\N	4	1	-290	\N	C	2019-12-20 22:14:28.053842+00	3603
289	27	feature	Open-air; Inland	\N	4	1	-289	\N	C	2019-12-20 22:14:28.053842+00	3604
288	27	feature	Open-air; Inland	\N	4	1	-288	\N	C	2019-12-20 22:14:28.053842+00	3605
287	27	feature	Open-air; Inland	\N	4	1	-287	\N	C	2019-12-20 22:14:28.053842+00	3606
286	27	feature	Open-air; Inland	\N	4	1	-286	\N	C	2019-12-20 22:14:28.053842+00	3607
285	27	feature	Open-air; Inland	\N	4	1	-285	\N	C	2019-12-20 22:14:28.053842+00	3608
284	27	feature	Open-air; Inland	\N	4	1	-284	\N	C	2019-12-20 22:14:28.053842+00	3609
283	27	feature	Open-air; Inland	\N	4	1	-283	\N	C	2019-12-20 22:14:28.053842+00	3610
282	27	feature	Open-air; Inland	\N	4	1	-282	\N	C	2019-12-20 22:14:28.053842+00	3611
281	27	feature	Open-air; Inland	\N	4	1	-281	\N	C	2019-12-20 22:14:28.053842+00	3612
280	27	feature	Open-air; Inland	\N	4	1	-280	\N	C	2019-12-20 22:14:28.053842+00	3613
279	27	feature	Open-air; Inland	\N	4	1	-279	\N	C	2019-12-20 22:14:28.053842+00	3614
278	27	feature	Open-air; Inland	\N	4	1	-278	\N	C	2019-12-20 22:14:28.053842+00	3615
277	27	feature	Open-air; Inland	\N	4	1	-277	\N	C	2019-12-20 22:14:28.053842+00	3616
276	27	feature	Open-air; Inland	\N	4	1	-276	\N	C	2019-12-20 22:14:28.053842+00	3617
275	27	feature	Open-air; Inland	\N	4	1	-275	\N	C	2019-12-20 22:14:28.053842+00	3618
274	27	feature	Open-air; Inland	\N	4	1	-274	\N	C	2019-12-20 22:14:28.053842+00	3619
273	27	feature	Open-air; Inland	\N	4	1	-273	\N	C	2019-12-20 22:14:28.053842+00	3620
272	27	feature	Open-air; Inland	\N	4	1	-272	\N	C	2019-12-20 22:14:28.053842+00	3621
271	27	feature	Open-air; Inland	\N	4	1	-271	\N	C	2019-12-20 22:14:28.053842+00	3622
270	27	feature	Open-air; Inland	\N	4	1	-270	\N	C	2019-12-20 22:14:28.053842+00	3623
269	27	feature	Open-air; Inland	\N	4	1	-269	\N	C	2019-12-20 22:14:28.053842+00	3624
268	27	feature	Open-air; Inland	\N	4	1	-268	\N	C	2019-12-20 22:14:28.053842+00	3625
267	27	feature	Open-air; Inland	\N	4	1	-267	\N	C	2019-12-20 22:14:28.053842+00	3626
266	27	feature	Open-air; Inland	\N	4	1	-266	\N	C	2019-12-20 22:14:28.053842+00	3627
265	27	feature	Open-air; Inland	\N	4	1	-265	\N	C	2019-12-20 22:14:28.053842+00	3628
264	27	feature	Open-air; Inland	\N	4	1	-264	\N	C	2019-12-20 22:14:28.053842+00	3629
263	27	feature	Open-air; Inland	\N	4	1	-263	\N	C	2019-12-20 22:14:28.053842+00	3630
262	27	feature	Open-air; Inland	\N	4	1	-262	\N	C	2019-12-20 22:14:28.053842+00	3631
261	27	feature	Open-air; Inland	\N	4	1	-261	\N	C	2019-12-20 22:14:28.053842+00	3632
260	27	feature	Open-air; Inland	\N	4	1	-260	\N	C	2019-12-20 22:14:28.053842+00	3633
259	27	feature	Open-air; Inland	\N	4	1	-259	\N	C	2019-12-20 22:14:28.053842+00	3634
258	27	feature	Open-air; Inland	\N	4	1	-258	\N	C	2019-12-20 22:14:28.053842+00	3635
257	27	feature	Open-air; Inland	\N	4	1	-257	\N	C	2019-12-20 22:14:28.053842+00	3636
256	27	feature	Open-air; Inland	\N	4	1	-256	\N	C	2019-12-20 22:14:28.053842+00	3637
255	27	feature	Open-air; Inland	\N	4	1	-255	\N	C	2019-12-20 22:14:28.053842+00	3638
254	27	feature	Open-air; Inland	\N	4	1	-254	\N	C	2019-12-20 22:14:28.053842+00	3639
253	27	feature	Open-air; Inland	\N	4	1	-253	\N	C	2019-12-20 22:14:28.053842+00	3640
252	27	feature	Open-air; Inland	\N	4	1	-252	\N	C	2019-12-20 22:14:28.053842+00	3641
251	27	feature	Open-air; Inland	\N	4	1	-251	\N	C	2019-12-20 22:14:28.053842+00	3642
250	27	feature	Open-air; Inland	\N	4	1	-250	\N	C	2019-12-20 22:14:28.053842+00	3643
249	27	feature	Open-air; Inland	\N	4	1	-249	\N	C	2019-12-20 22:14:28.053842+00	3644
248	27	feature	Open-air; Inland	\N	4	1	-248	\N	C	2019-12-20 22:14:28.053842+00	3645
247	27	feature	Open-air; Inland	\N	4	1	-247	\N	C	2019-12-20 22:14:28.053842+00	3646
246	27	feature	Open-air; Inland	\N	4	1	-246	\N	C	2019-12-20 22:14:28.053842+00	3647
245	27	feature	Open-air; Inland	\N	4	1	-245	\N	C	2019-12-20 22:14:28.053842+00	3648
244	27	feature	Open-air; Inland	\N	4	1	-244	\N	C	2019-12-20 22:14:28.053842+00	3649
243	27	feature	Open-air; Inland	\N	4	1	-243	\N	C	2019-12-20 22:14:28.053842+00	3650
242	27	feature	Open-air; Inland	\N	4	1	-242	\N	C	2019-12-20 22:14:28.053842+00	3651
241	27	feature	Open-air; Inland	\N	4	1	-241	\N	C	2019-12-20 22:14:28.053842+00	3652
240	27	feature	Open-air; Inland	\N	4	1	-240	\N	C	2019-12-20 22:14:28.053842+00	3653
239	27	feature	Open-air; Inland	\N	4	1	-239	\N	C	2019-12-20 22:14:28.053842+00	3654
238	27	feature	Open-air; Mountainous	\N	4	1	-238	\N	C	2019-12-20 22:14:28.053842+00	3655
237	27	feature	Open-air; Mountainous	\N	4	1	-237	\N	C	2019-12-20 22:14:28.053842+00	3656
236	27	feature	Open-air; Mountainous	\N	4	1	-236	\N	C	2019-12-20 22:14:28.053842+00	3657
235	27	feature	Open-air; Mountainous	\N	4	1	-235	\N	C	2019-12-20 22:14:28.053842+00	3658
234	27	feature	Open-air; Mountainous	\N	4	1	-234	\N	C	2019-12-20 22:14:28.053842+00	3659
233	27	feature	Open-air; Mountainous	\N	4	1	-233	\N	C	2019-12-20 22:14:28.053842+00	3660
232	27	feature	Open-air; Mountainous	\N	4	1	-232	\N	C	2019-12-20 22:14:28.053842+00	3661
231	27	feature	Open-air; Mountainous	\N	4	1	-231	\N	C	2019-12-20 22:14:28.053842+00	3662
230	12	feature	Shell midden; Inland	\N	4	1	-230	\N	C	2019-12-20 22:14:28.053842+00	3663
229	12	feature	Shell midden; Inland	\N	4	1	-229	\N	C	2019-12-20 22:14:28.053842+00	3664
228	12	feature	Shell midden; Inland	\N	4	1	-228	\N	C	2019-12-20 22:14:28.053842+00	3665
227	12	feature	Shell midden; Inland	\N	4	1	-227	\N	C	2019-12-20 22:14:28.053842+00	3666
226	12	feature	Shell midden; Inland	\N	4	1	-226	\N	C	2019-12-20 22:14:28.053842+00	3667
225	12	feature	Shell midden; Inland	\N	4	1	-225	\N	C	2019-12-20 22:14:28.053842+00	3668
224	12	feature	Shell midden; Inland	\N	4	1	-224	\N	C	2019-12-20 22:14:28.053842+00	3669
223	12	feature	Shell midden; Inland	\N	4	1	-223	\N	C	2019-12-20 22:14:28.053842+00	3670
222	12	feature	Shell midden; Inland	\N	4	1	-222	\N	C	2019-12-20 22:14:28.053842+00	3671
221	12	feature	Shell midden; Inland	\N	4	1	-221	\N	C	2019-12-20 22:14:28.053842+00	3672
220	12	feature	Shell midden; Inland	\N	4	1	-220	\N	C	2019-12-20 22:14:28.053842+00	3673
219	12	feature	Shell midden; Inland	\N	4	1	-219	\N	C	2019-12-20 22:14:28.053842+00	3674
218	12	feature	Shell midden; Inland	\N	4	1	-218	\N	C	2019-12-20 22:14:28.053842+00	3675
217	12	feature	Shell midden; Inland	\N	4	1	-217	\N	C	2019-12-20 22:14:28.053842+00	3676
216	12	feature	Shell midden; Inland	\N	4	1	-216	\N	C	2019-12-20 22:14:28.053842+00	3677
215	12	feature	Shell midden; Inland	\N	4	1	-215	\N	C	2019-12-20 22:14:28.053842+00	3678
214	12	feature	Shell midden; Inland	\N	4	1	-214	\N	C	2019-12-20 22:14:28.053842+00	3679
213	12	feature	Shell midden; Inland	\N	4	1	-213	\N	C	2019-12-20 22:14:28.053842+00	3680
212	12	feature	Shell midden; Inland	\N	4	1	-212	\N	C	2019-12-20 22:14:28.053842+00	3681
211	12	feature	Shell midden; Inland	\N	4	1	-211	\N	C	2019-12-20 22:14:28.053842+00	3682
210	12	feature	Shell midden; Inland	\N	4	1	-210	\N	C	2019-12-20 22:14:28.053842+00	3683
209	12	feature	Shell midden; Inland	\N	4	1	-209	\N	C	2019-12-20 22:14:28.053842+00	3684
208	12	feature	Shell midden; Inland	\N	4	1	-208	\N	C	2019-12-20 22:14:28.053842+00	3685
207	12	feature	Shell midden; Inland	\N	4	1	-207	\N	C	2019-12-20 22:14:28.053842+00	3686
206	12	feature	Shell midden; Inland	\N	4	1	-206	\N	C	2019-12-20 22:14:28.053842+00	3687
205	12	feature	Shell midden; Inland	\N	4	1	-205	\N	C	2019-12-20 22:14:28.053842+00	3688
204	12	feature	Shell midden; Inland	\N	4	1	-204	\N	C	2019-12-20 22:14:28.053842+00	3689
203	12	feature	Shell midden; Inland	\N	4	1	-203	\N	C	2019-12-20 22:14:28.053842+00	3690
202	12	feature	Shell midden; Inland	\N	4	1	-202	\N	C	2019-12-20 22:14:28.053842+00	3691
201	12	feature	Shell midden; Inland	\N	4	1	-201	\N	C	2019-12-20 22:14:28.053842+00	3692
200	12	feature	Shell midden; Inland	\N	4	1	-200	\N	C	2019-12-20 22:14:28.053842+00	3693
199	12	feature	Shell midden; Inland	\N	4	1	-199	\N	C	2019-12-20 22:14:28.053842+00	3694
198	12	feature	Shell midden; Inland	\N	4	1	-198	\N	C	2019-12-20 22:14:28.053842+00	3695
197	12	feature	Shell midden; Inland	\N	4	1	-197	\N	C	2019-12-20 22:14:28.053842+00	3696
196	34	feature	Rock shelter/Cave; Mountainous	\N	4	1	-196	\N	C	2019-12-20 22:14:28.053842+00	3697
195	34	feature	Rock shelter/Cave; Mountainous	\N	4	1	-195	\N	C	2019-12-20 22:14:28.053842+00	3698
194	34	feature	Rock shelter/Cave; Mountainous	\N	4	1	-194	\N	C	2019-12-20 22:14:28.053842+00	3699
193	34	feature	Rock shelter/Cave; Mountainous	\N	4	1	-193	\N	C	2019-12-20 22:14:28.053842+00	3700
192	34	feature	Rock shelter/Cave; Mountainous	\N	4	1	-192	\N	C	2019-12-20 22:14:28.053842+00	3701
191	34	feature	Rock shelter/Cave; Mountainous	\N	4	1	-191	\N	C	2019-12-20 22:14:28.053842+00	3702
190	34	feature	Rock shelter/Cave; Mountainous	\N	4	1	-190	\N	C	2019-12-20 22:14:28.053842+00	3703
189	34	feature	Rock shelter/Cave; Mountainous	\N	4	1	-189	\N	C	2019-12-20 22:14:28.053842+00	3704
188	34	feature	Rock shelter/Cave; Mountainous	\N	4	1	-188	\N	C	2019-12-20 22:14:28.053842+00	3705
187	34	feature	Rock shelter/Cave; Mountainous	\N	4	1	-187	\N	C	2019-12-20 22:14:28.053842+00	3706
186	34	feature	Rock shelter/Cave; Mountainous	\N	4	1	-186	\N	C	2019-12-20 22:14:28.053842+00	3707
185	34	feature	Rock shelter/Cave; Mountainous	\N	4	1	-185	\N	C	2019-12-20 22:14:28.053842+00	3708
184	34	feature	Rock shelter/Cave; Mountainous	\N	4	1	-184	\N	C	2019-12-20 22:14:28.053842+00	3709
183	34	feature	Rock shelter/Cave; Mountainous	\N	4	1	-183	\N	C	2019-12-20 22:14:28.053842+00	3710
182	34	feature	Rock shelter/Cave; Mountainous	\N	4	1	-182	\N	C	2019-12-20 22:14:28.053842+00	3711
181	34	feature	Rock shelter/Cave; Inland	\N	4	1	-181	\N	C	2019-12-20 22:14:28.053842+00	3712
180	34	feature	Rock shelter/Cave; Inland	\N	4	1	-180	\N	C	2019-12-20 22:14:28.053842+00	3713
179	34	feature	Rock shelter/Cave; Inland	\N	4	1	-179	\N	C	2019-12-20 22:14:28.053842+00	3714
178	34	feature	Rock shelter/Cave; Inland	\N	4	1	-178	\N	C	2019-12-20 22:14:28.053842+00	3715
177	34	feature	Rock shelter/Cave; Inland	\N	4	1	-177	\N	C	2019-12-20 22:14:28.053842+00	3716
176	34	feature	Rock shelter/Cave; Inland	\N	4	1	-176	\N	C	2019-12-20 22:14:28.053842+00	3717
175	34	feature	Rock shelter/Cave; Inland	\N	4	1	-175	\N	C	2019-12-20 22:14:28.053842+00	3718
174	12	feature	Shell midden; Inland	\N	4	1	-174	\N	C	2019-12-20 22:14:28.053842+00	3719
173	12	feature	Shell midden; Inland	\N	4	1	-173	\N	C	2019-12-20 22:14:28.053842+00	3720
172	12	feature	Shell midden; Inland	\N	4	1	-172	\N	C	2019-12-20 22:14:28.053842+00	3721
171	12	feature	Shell midden; Inland	\N	4	1	-171	\N	C	2019-12-20 22:14:28.053842+00	3722
170	12	feature	Shell midden; Inland	\N	4	1	-170	\N	C	2019-12-20 22:14:28.053842+00	3723
169	12	feature	Shell midden; Inland	\N	4	1	-169	\N	C	2019-12-20 22:14:28.053842+00	3724
168	12	feature	Shell midden; Inland	\N	4	1	-168	\N	C	2019-12-20 22:14:28.053842+00	3725
167	12	feature	Shell midden; Inland	\N	4	1	-167	\N	C	2019-12-20 22:14:28.053842+00	3726
166	12	feature	Shell midden; Inland	\N	4	1	-166	\N	C	2019-12-20 22:14:28.053842+00	3727
165	12	feature	Shell midden; Inland	\N	4	1	-165	\N	C	2019-12-20 22:14:28.053842+00	3728
164	12	feature	Shell midden; Inland	\N	4	1	-164	\N	C	2019-12-20 22:14:28.053842+00	3729
163	12	feature	Shell midden; Inland	\N	4	1	-163	\N	C	2019-12-20 22:14:28.053842+00	3730
162	12	feature	Shell midden; Inland	\N	4	1	-162	\N	C	2019-12-20 22:14:28.053842+00	3731
161	34	feature	Rock shelter/Cave; Mountainous	\N	4	1	-161	\N	C	2019-12-20 22:14:28.053842+00	3732
160	34	feature	Rock shelter/Cave; Mountainous	\N	4	1	-160	\N	C	2019-12-20 22:14:28.053842+00	3733
159	34	feature	Rock shelter/Cave; Mountainous	\N	4	1	-159	\N	C	2019-12-20 22:14:28.053842+00	3734
158	34	feature	Rock shelter/Cave; Mountainous	\N	4	1	-158	\N	C	2019-12-20 22:14:28.053842+00	3735
157	34	feature	Rock shelter/Cave; Mountainous	\N	4	1	-157	\N	C	2019-12-20 22:14:28.053842+00	3736
156	34	feature	Rock shelter/Cave; Mountainous	\N	4	1	-156	\N	C	2019-12-20 22:14:28.053842+00	3737
155	34	feature	Rock shelter/Cave; Mountainous	\N	4	1	-155	\N	C	2019-12-20 22:14:28.053842+00	3738
154	34	feature	Rock shelter/Cave; Mountainous	\N	4	1	-154	\N	C	2019-12-20 22:14:28.053842+00	3739
153	34	feature	Rock shelter/Cave; Mountainous	\N	4	1	-153	\N	C	2019-12-20 22:14:28.053842+00	3740
152	34	feature	Rock shelter/Cave; Mountainous	\N	4	1	-152	\N	C	2019-12-20 22:14:28.053842+00	3741
151	34	feature	Rock shelter/Cave; Mountainous	\N	4	1	-151	\N	C	2019-12-20 22:14:28.053842+00	3742
150	34	feature	Rock shelter/Cave; Mountainous	\N	4	1	-150	\N	C	2019-12-20 22:14:28.053842+00	3743
149	34	feature	Rock shelter/Cave; Mountainous	\N	4	1	-149	\N	C	2019-12-20 22:14:28.053842+00	3744
148	34	feature	Rock shelter/Cave; Mountainous	\N	4	1	-148	\N	C	2019-12-20 22:14:28.053842+00	3745
147	34	feature	Rock shelter/Cave; Mountainous	\N	4	1	-147	\N	C	2019-12-20 22:14:28.053842+00	3746
146	34	feature	Rock shelter/Cave; Mountainous	\N	4	1	-146	\N	C	2019-12-20 22:14:28.053842+00	3747
145	34	feature	Rock shelter/Cave; Mountainous	\N	4	1	-145	\N	C	2019-12-20 22:14:28.053842+00	3748
144	34	feature	Rock shelter/Cave; Mountainous	\N	4	1	-144	\N	C	2019-12-20 22:14:28.053842+00	3749
143	34	feature	Rock shelter/Cave; Mountainous	\N	4	1	-143	\N	C	2019-12-20 22:14:28.053842+00	3750
142	34	feature	Rock shelter/Cave; Mountainous	\N	4	1	-142	\N	C	2019-12-20 22:14:28.053842+00	3751
141	34	feature	Rock shelter/Cave; Mountainous	\N	4	1	-141	\N	C	2019-12-20 22:14:28.053842+00	3752
140	34	feature	Rock shelter/Cave; Mountainous	\N	4	1	-140	\N	C	2019-12-20 22:14:28.053842+00	3753
139	34	feature	Rock shelter/Cave; Mountainous	\N	4	1	-139	\N	C	2019-12-20 22:14:28.053842+00	3754
138	34	feature	Rock shelter/Cave; Mountainous	\N	4	1	-138	\N	C	2019-12-20 22:14:28.053842+00	3755
137	34	feature	Rock shelter/Cave; Mountainous	\N	4	1	-137	\N	C	2019-12-20 22:14:28.053842+00	3756
136	34	feature	Rock shelter/Cave; Mountainous	\N	4	1	-136	\N	C	2019-12-20 22:14:28.053842+00	3757
135	34	feature	Rock shelter/Cave; Mountainous	\N	4	1	-135	\N	C	2019-12-20 22:14:28.053842+00	3758
134	34	feature	Rock shelter/Cave; Mountainous	\N	4	1	-134	\N	C	2019-12-20 22:14:28.053842+00	3759
133	34	feature	Rock shelter/Cave; Mountainous	\N	4	1	-133	\N	C	2019-12-20 22:14:28.053842+00	3760
132	34	feature	Rock shelter/Cave; Mountainous	\N	4	1	-132	\N	C	2019-12-20 22:14:28.053842+00	3761
131	34	feature	Rock shelter/Cave; Mountainous	\N	4	1	-131	\N	C	2019-12-20 22:14:28.053842+00	3762
130	34	feature	Rock shelter/Cave; Mountainous	\N	4	1	-130	\N	C	2019-12-20 22:14:28.053842+00	3763
129	34	feature	Rock shelter/Cave; Mountainous	\N	4	1	-129	\N	C	2019-12-20 22:14:28.053842+00	3764
128	34	feature	Rock shelter/Cave; Mountainous	\N	4	1	-128	\N	C	2019-12-20 22:14:28.053842+00	3765
127	34	feature	Rock shelter/Cave; Mountainous	\N	4	1	-127	\N	C	2019-12-20 22:14:28.053842+00	3766
126	34	feature	Rock shelter/Cave; Mountainous	\N	4	1	-126	\N	C	2019-12-20 22:14:28.053842+00	3767
125	34	feature	Rock shelter/Cave; Mountainous	\N	4	1	-125	\N	C	2019-12-20 22:14:28.053842+00	3768
124	34	feature	Rock shelter/Cave; Mountainous	\N	4	1	-124	\N	C	2019-12-20 22:14:28.053842+00	3769
123	34	feature	Rock shelter/Cave; Mountainous	\N	4	1	-123	\N	C	2019-12-20 22:14:28.053842+00	3770
122	34	feature	Rock shelter/Cave; Mountainous	\N	4	1	-122	\N	C	2019-12-20 22:14:28.053842+00	3771
121	34	feature	Rock shelter/Cave; Mountainous	\N	4	1	-121	\N	C	2019-12-20 22:14:28.053842+00	3772
120	34	feature	Rock shelter/Cave; Mountainous	\N	4	1	-120	\N	C	2019-12-20 22:14:28.053842+00	3773
119	34	feature	Rock shelter/Cave; Mountainous	\N	4	1	-119	\N	C	2019-12-20 22:14:28.053842+00	3774
118	34	feature	Rock shelter/Cave; Mountainous	\N	4	1	-118	\N	C	2019-12-20 22:14:28.053842+00	3775
117	27	feature	Open-air; Close to the coast	\N	4	1	-117	\N	C	2019-12-20 22:14:28.053842+00	3776
116	27	feature	Open-air; Close to the coast	\N	4	1	-116	\N	C	2019-12-20 22:14:28.053842+00	3777
115	27	feature	Open-air; Close to the coast	\N	4	1	-115	\N	C	2019-12-20 22:14:28.053842+00	3778
114	27	feature	Open-air; Close to the coast	\N	4	1	-114	\N	C	2019-12-20 22:14:28.053842+00	3779
113	27	feature	Open-air; Close to the coast	\N	4	1	-113	\N	C	2019-12-20 22:14:28.053842+00	3780
112	27	feature	Open-air; Close to the coast	\N	4	1	-112	\N	C	2019-12-20 22:14:28.053842+00	3781
111	27	feature	Open-air; Close to the coast	\N	4	1	-111	\N	C	2019-12-20 22:14:28.053842+00	3782
110	27	feature	Open-air; Close to the coast	\N	4	1	-110	\N	C	2019-12-20 22:14:28.053842+00	3783
109	27	feature	Open-air; Close to the coast	\N	4	1	-109	\N	C	2019-12-20 22:14:28.053842+00	3784
108	27	feature	Open-air; Close to the coast	\N	4	1	-108	\N	C	2019-12-20 22:14:28.053842+00	3785
107	27	feature	Open-air; Close to the coast	\N	4	1	-107	\N	C	2019-12-20 22:14:28.053842+00	3786
106	27	feature	Open-air; Close to the coast	\N	4	1	-106	\N	C	2019-12-20 22:14:28.053842+00	3787
105	27	feature	Open-air; Close to the coast	\N	4	1	-105	\N	C	2019-12-20 22:14:28.053842+00	3788
104	27	feature	Open-air; Close to the coast	\N	4	1	-104	\N	C	2019-12-20 22:14:28.053842+00	3789
103	27	feature	Open-air; Close to the coast	\N	4	1	-103	\N	C	2019-12-20 22:14:28.053842+00	3790
102	27	feature	Open-air; Close to the coast	\N	4	1	-102	\N	C	2019-12-20 22:14:28.053842+00	3791
101	27	feature	Open-air; Close to the coast	\N	4	1	-101	\N	C	2019-12-20 22:14:28.053842+00	3792
100	27	feature	Open-air; Close to the coast	\N	4	1	-100	\N	C	2019-12-20 22:14:28.053842+00	3793
99	27	feature	Open-air; Close to the coast	\N	4	1	-99	\N	C	2019-12-20 22:14:28.053842+00	3794
98	27	feature	Open-air; Close to the coast	\N	4	1	-98	\N	C	2019-12-20 22:14:28.053842+00	3795
97	27	feature	Open-air; Close to the coast	\N	4	1	-97	\N	C	2019-12-20 22:14:28.053842+00	3796
96	27	feature	Open-air; Close to the coast	\N	4	1	-96	\N	C	2019-12-20 22:14:28.053842+00	3797
95	27	feature	Open-air; Close to the coast	\N	4	1	-95	\N	C	2019-12-20 22:14:28.053842+00	3798
94	27	feature	Open-air; Close to the coast	\N	4	1	-94	\N	C	2019-12-20 22:14:28.053842+00	3799
93	27	feature	Open-air; Close to the coast	\N	4	1	-93	\N	C	2019-12-20 22:14:28.053842+00	3800
92	27	feature	Open-air; Close to the coast	\N	4	1	-92	\N	C	2019-12-20 22:14:28.053842+00	3801
91	27	feature	Open-air; Close to the coast	\N	4	1	-91	\N	C	2019-12-20 22:14:28.053842+00	3802
90	27	feature	Open-air; Close to the coast	\N	4	1	-90	\N	C	2019-12-20 22:14:28.053842+00	3803
89	27	feature	Open-air; Close to the coast	\N	4	1	-89	\N	C	2019-12-20 22:14:28.053842+00	3804
88	27	feature	Open-air; Close to the coast	\N	4	1	-88	\N	C	2019-12-20 22:14:28.053842+00	3805
87	27	feature	Open-air; Close to the coast	\N	4	1	-87	\N	C	2019-12-20 22:14:28.053842+00	3806
86	27	feature	Open-air; Close to the coast	\N	4	1	-86	\N	C	2019-12-20 22:14:28.053842+00	3807
85	27	feature	Open-air; Close to the coast	\N	4	1	-85	\N	C	2019-12-20 22:14:28.053842+00	3808
84	27	feature	Open-air; Close to the coast	\N	4	1	-84	\N	C	2019-12-20 22:14:28.053842+00	3809
83	27	feature	Open-air; Close to the coast	\N	4	1	-83	\N	C	2019-12-20 22:14:28.053842+00	3810
82	27	feature	Open-air; Close to the coast	\N	4	1	-82	\N	C	2019-12-20 22:14:28.053842+00	3811
81	27	feature	Open-air; Close to the coast	\N	4	1	-81	\N	C	2019-12-20 22:14:28.053842+00	3812
80	27	feature	Open-air; Close to the coast	\N	4	1	-80	\N	C	2019-12-20 22:14:28.053842+00	3813
79	27	feature	Open-air; Close to the coast	\N	4	1	-79	\N	C	2019-12-20 22:14:28.053842+00	3814
78	27	feature	Open-air; Close to the coast	\N	4	1	-78	\N	C	2019-12-20 22:14:28.053842+00	3815
77	27	feature	Open-air; Close to the coast	\N	4	1	-77	\N	C	2019-12-20 22:14:28.053842+00	3816
76	27	feature	Open-air; Close to the coast	\N	4	1	-76	\N	C	2019-12-20 22:14:28.053842+00	3817
75	27	feature	Open-air; Close to the coast	\N	4	1	-75	\N	C	2019-12-20 22:14:28.053842+00	3818
74	27	feature	Open-air; Close to the coast	\N	4	1	-74	\N	C	2019-12-20 22:14:28.053842+00	3819
73	27	feature	Open-air; Close to the coast	\N	4	1	-73	\N	C	2019-12-20 22:14:28.053842+00	3820
72	27	feature	Open-air; Close to the coast	\N	4	1	-72	\N	C	2019-12-20 22:14:28.053842+00	3821
71	27	feature	Open-air; Close to the coast	\N	4	1	-71	\N	C	2019-12-20 22:14:28.053842+00	3822
70	27	feature	Open-air; Close to the coast	\N	4	1	-70	\N	C	2019-12-20 22:14:28.053842+00	3823
69	27	feature	Open-air; Close to the coast	\N	4	1	-69	\N	C	2019-12-20 22:14:28.053842+00	3824
68	27	feature	Open-air; Close to the coast	\N	4	1	-68	\N	C	2019-12-20 22:14:28.053842+00	3825
67	27	feature	Open-air; Close to the coast	\N	4	1	-67	\N	C	2019-12-20 22:14:28.053842+00	3826
66	27	feature	Open-air; Close to the coast	\N	4	1	-66	\N	C	2019-12-20 22:14:28.053842+00	3827
65	27	feature	Open-air; Close to the coast	\N	4	1	-65	\N	C	2019-12-20 22:14:28.053842+00	3828
64	27	feature	Open-air; Close to the coast	\N	4	1	-64	\N	C	2019-12-20 22:14:28.053842+00	3829
45	27	feature	Open-air; Close to the coast	\N	4	1	-45	\N	C	2019-12-20 22:14:28.053842+00	3848
44	27	feature	Open-air; Close to the coast	\N	4	1	-44	\N	C	2019-12-20 22:14:28.053842+00	3849
43	27	feature	Open-air; Close to the coast	\N	4	1	-43	\N	C	2019-12-20 22:14:28.053842+00	3850
42	27	feature	Open-air; Close to the coast	\N	4	1	-42	\N	C	2019-12-20 22:14:28.053842+00	3851
41	27	feature	Open-air; Close to the coast	\N	4	1	-41	\N	C	2019-12-20 22:14:28.053842+00	3852
40	27	feature	Open-air; Close to the coast	\N	4	1	-40	\N	C	2019-12-20 22:14:28.053842+00	3853
39	27	feature	Open-air; Close to the coast	\N	4	1	-39	\N	C	2019-12-20 22:14:28.053842+00	3854
38	27	feature	Open-air; Close to the coast	\N	4	1	-38	\N	C	2019-12-20 22:14:28.053842+00	3855
37	27	feature	Open-air; Close to the coast	\N	4	1	-37	\N	C	2019-12-20 22:14:28.053842+00	3856
36	27	feature	Open-air; Close to the coast	\N	4	1	-36	\N	C	2019-12-20 22:14:28.053842+00	3857
35	27	feature	Open-air; Close to the coast	\N	4	1	-35	\N	C	2019-12-20 22:14:28.053842+00	3858
34	27	feature	Open-air; Close to the coast	\N	4	1	-34	\N	C	2019-12-20 22:14:28.053842+00	3859
33	27	feature	Open-air; Close to the coast	\N	4	1	-33	\N	C	2019-12-20 22:14:28.053842+00	3860
32	27	feature	Open-air; Close to the coast	\N	4	1	-32	\N	C	2019-12-20 22:14:28.053842+00	3861
31	27	feature	Open-air; Close to the coast	\N	4	1	-31	\N	C	2019-12-20 22:14:28.053842+00	3862
30	27	feature	Open-air; Close to the coast	\N	4	1	-30	\N	C	2019-12-20 22:14:28.053842+00	3863
29	27	feature	Open-air; Close to the coast	\N	4	1	-29	\N	C	2019-12-20 22:14:28.053842+00	3864
28	27	feature	Open-air; Close to the coast	\N	4	1	-28	\N	C	2019-12-20 22:14:28.053842+00	3865
27	27	feature	Open-air; Inland	\N	4	1	-27	\N	C	2019-12-20 22:14:28.053842+00	3866
26	27	feature	Open-air; Inland	\N	4	1	-26	\N	C	2019-12-20 22:14:28.053842+00	3867
25	27	feature	Open-air; Inland	\N	4	1	-25	\N	C	2019-12-20 22:14:28.053842+00	3868
24	27	feature	Open-air; Inland	\N	4	1	-24	\N	C	2019-12-20 22:14:28.053842+00	3869
23	27	feature	Open-air; Inland	\N	4	1	-23	\N	C	2019-12-20 22:14:28.053842+00	3870
22	27	feature	Open-air; Inland	\N	4	1	-22	\N	C	2019-12-20 22:14:28.053842+00	3871
21	27	feature	Open-air; Inland	\N	4	1	-21	\N	C	2019-12-20 22:14:28.053842+00	3872
20	27	feature	Open-air; Inland	\N	4	1	-20	\N	C	2019-12-20 22:14:28.053842+00	3873
19	27	feature	Open-air; Inland	\N	4	1	-19	\N	C	2019-12-20 22:14:28.053842+00	3874
18	27	feature	Open-air; Inland	\N	4	1	-18	\N	C	2019-12-20 22:14:28.053842+00	3875
17	27	feature	Open-air; Inland	\N	4	1	-17	\N	C	2019-12-20 22:14:28.053842+00	3876
16	27	feature	Open-air; Inland	\N	4	1	-16	\N	C	2019-12-20 22:14:28.053842+00	3877
15	27	feature	Open-air; Inland	\N	4	1	-15	\N	C	2019-12-20 22:14:28.053842+00	3878
14	27	feature	Open-air; Inland	\N	4	1	-14	\N	C	2019-12-20 22:14:28.053842+00	3879
13	27	feature	Open-air; Inland	\N	4	1	-13	\N	C	2019-12-20 22:14:28.053842+00	3880
12	27	feature	Open-air; Inland	\N	4	1	-12	\N	C	2019-12-20 22:14:28.053842+00	3881
11	27	feature	Open-air; Inland	\N	4	1	-11	\N	C	2019-12-20 22:14:28.053842+00	3882
10	27	feature	Open-air; Inland	\N	4	1	-10	\N	C	2019-12-20 22:14:28.053842+00	3883
9	27	feature	Open-air; Inland	\N	4	1	-9	\N	C	2019-12-20 22:14:28.053842+00	3884
8	27	feature	Open-air; Inland	\N	4	1	-8	\N	C	2019-12-20 22:14:28.053842+00	3885
7	27	feature	Open-air; Inland	\N	4	1	-7	\N	C	2019-12-20 22:14:28.053842+00	3886
6	27	feature	Open-air; Inland	\N	4	1	-6	\N	C	2019-12-20 22:14:28.053842+00	3887
5	27	feature	Open-air; Inland	\N	4	1	-5	\N	C	2019-12-20 22:14:28.053842+00	3888
4	27	feature	Open-air; Inland	\N	4	1	-4	\N	C	2019-12-20 22:14:28.053842+00	3889
3	27	feature	Open-air; Inland	\N	4	1	-3	\N	C	2019-12-20 22:14:28.053842+00	3890
2	27	feature	Open-air; Inland	\N	4	1	-2	\N	C	2019-12-20 22:14:28.053842+00	3891
1	27	feature	Open-air; Inland	\N	4	1	-1	\N	C	2019-12-20 22:14:28.053842+00	3892
