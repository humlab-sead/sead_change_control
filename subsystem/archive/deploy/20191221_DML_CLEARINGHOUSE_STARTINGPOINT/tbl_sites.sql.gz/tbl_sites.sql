11	\N	56.6700150000	16.3698260000	\N	DENDRO DATE: Det helt säkra daterade furuvirket (61377; 61379-80; 61382-83) visar att byggnaden är uppförd 1830/1831 eller något år senare beroende på eventuella lagringstider av virket; Granvirket (61372-61376 samt 61381) har inte med säkerhet daterats, trots att det användbara provantalet var sju stycken och att vår och sommarveden mättes var för sig så att tre tidsserier för varje prov skapades (för få årsringar i proverna). Det presenteras dock de ur dendrokronologisk synpunkt mest sannolika dateringarna för prov 7 (61375) och prov 9 (61376) men det uppmanas att dessa resultat inte styr de slutgiltiga tolkningarna av byggnadens ålder utan bara används som stöd för diskussion och presumtiva arbetshypoteser.	Gröna stugan	\N	\N	\N	2	1	-11	\N	C	2019-12-20 22:14:09.31687+00	2023
12	\N	58.0103660000	14.8469845000	Linderås 55:1	SITE ALIAS: Även kallad Göberga gård.	Göberga säteri	\N	\N	\N	2	1	-12	\N	C	2019-12-20 22:14:09.31687+00	2022
13	\N	56.5546310000	16.1766390000	Hagby 10:1	DENDRO DATE: Dendrokronologiskt sett är materialet mycket heterogent, ingen korsdatering inbördes mellan proverna. Två prover (75333, 75335) har bra årsringsantal och borde kompletteras med fler prover. Det bästa dateringen fås på prov 75333 som ger "efter 1375". Korrelationsnivån är för låg för att en datering kan fastställas.	Hagby kyrka	\N	\N	\N	2	1	-13	\N	C	2019-12-20 22:14:09.31687+00	2021
14	\N	57.9708380000	16.6290930000	\N	SITE ALIAS: Även kallad Hellerö gård. DENDRO DATE: Prov 75444 förefaller uppvisar vankant men eftersom ytdelen är brandskadad är detta inte helt säkert. En rimlig tolkning av fällningsåret för denna stock är endera V 1754/55 eller V 1759/60.	Hellerö säteri	\N	\N	\N	2	1	-14	\N	C	2019-12-20 22:14:09.31687+00	2020
15	\N	56.6577750000	14.8509890000	\N	DENDRO DATE: Proverna 74109-75118 kunde inte dateras eftersom de yttersta årsringarna saknades. Det tyder dock ingenting på att de inte kan vara avverkade under samma period som de daterade proverna 75119-75121 och 75125, alltså 1220-talet.	Jät kyrka	\N	\N	\N	2	1	-15	\N	C	2019-12-20 22:14:09.31687+00	2019
16	\N	57.0185010000	16.4383890000	Mönsterås 30:1	\N	Kronobäck klosterruin	\N	\N	\N	2	1	-16	\N	C	2019-12-20 22:14:09.31687+00	2018
17	\N	57.1113480000	16.9862830000	Källa 83:1	\N	Källa gamla kyrka	\N	\N	\N	2	1	-17	\N	C	2019-12-20 22:14:09.31687+00	2017
18	\N	56.9166140000	16.4306570000	Ålem 59:1	DENDRO DATE: Proverna 61402-61404 har samma avverkningsår X och bildar tillsammans en minikronologi på 53 årsringar.	Lagerhamnska gården i Pataholm	\N	\N	\N	2	1	-18	\N	C	2019-12-20 22:14:09.31687+00	2016
19	\N	57.8528390000	16.5862820000	\N	\N	Lilla Rätö gård	\N	\N	\N	2	1	-19	\N	C	2019-12-20 22:14:09.31687+00	2015
20	\N	56.5885480000	16.0847790000	\N	\N	Mortorp kyrka, tiondebod	\N	\N	\N	2	1	-20	\N	C	2019-12-20 22:14:09.31687+00	2014
21	\N	57.1672250000	15.3526090000	\N	Tillhörde ursprungligen kronogården Mocketorp; återuppfördes 1892 på Kulturen i Lund; DENDRO PROVENANCE: Bästa lokala kronologier som daterar virket är från Vetlanda-/Eksjö-området. DENDRO DATE: Prov 4, 6 och 7 har en starkt vikande tillväxt de sista 6-10 åren, vilket skulle kunna betyda att de är självdöda och avverkade senare som "torrfuror". Utan att avfärda den möjligheten utgår nedanstående tolkningar från att träden är avverkade i levande tillstånd. Mest sannolikt är virket prov 7 avverkat vinterhalvåret 1699/1700; vankanten i provet är dock inte helt säker. Prov 4 är odaterat men har vissa svaga korrelationer med virket som är avverkat omkring 1700.	Måcketorpsboden	\N	\N	\N	2	1	-21	\N	C	2019-12-20 22:14:09.31687+00	2013
22	\N	57.8374410000	14.8103640000	\N	Kan vara Norregården, Myresjö sn, Vetlanda kn som flyttades under 1990-talet till Ekotopia i Aneby.	Norregården	\N	\N	\N	2	1	-22	\N	C	2019-12-20 22:14:09.31687+00	2012
23	\N	57.4038810000	14.8889130000	\N	DENDRO DATE: Det finns ingenting som tyder på att de odaterade proverna catras 75094-97 samt 75099-104 är senare avverkade än prov 75098 (V 1181/82). I alla dessa prover saknas de yttersta årsringarna.	Nävelsjö kyrka	\N	\N	\N	2	1	-23	\N	C	2019-12-20 22:14:09.31687+00	2011
24	\N	57.4268390000	15.1232790000	\N	\N	Pärlhuset	\N	\N	\N	2	1	-24	\N	C	2019-12-20 22:14:09.31687+00	2010
25	\N	56.6659600000	16.3692390000	Kalmar 93:1	DENDRO PROVENANCE: Huvuddelen av virket i husväggen är avverkat vinterhalvåret 1753/54. Två daterade stockar avviker: prov 61468 är avverkat vinterhalvåret 1752/53, samma ståndort, vilket kan ge en föreställning om virkeshanteringen. Den andra avvikande stocken, prov 61468, är avverkad vinterhalvåret 1799/1800, troligtvis från en annan ståndort men inom samma region, norra halvan av Kalmar län.	Rackargården	\N	\N	\N	2	1	-25	\N	C	2019-12-20 22:14:09.31687+00	2009
26	\N	56.8284390000	16.6645340000	\N	\N	Räpplinge kyrka	\N	\N	\N	2	1	-26	\N	C	2019-12-20 22:14:09.31687+00	2008
27	\N	57.4184730000	15.9577080000	\N	DENDRO PROVENANCE: Sannolikt helt lokalt i förhållande till fastigheten.	Röda stugan	\N	\N	\N	2	1	-27	\N	C	2019-12-20 22:14:09.31687+00	2007
28	\N	57.5614185000	14.8632625000	\N	DENDRO PROVENANCE: Hög inbördes korrelation mellan proverna 75360 &amp; 75361, vilket antyder att de har vuxit i samma skog.	Rödjenäs herrgård	\N	\N	\N	2	1	-28	\N	C	2019-12-20 22:14:09.31687+00	2006
29	\N	57.0195250000	14.9605380000	\N	DENDRO PROVENANCE: Virket (75176-75189) uppvisar en stor variation i tillväxt och ålder. Virket kommer inte från samma bestånd utan är antagligen hämtade lite här och där i skogen.	Sjöhorven, Målajords soldattorp	\N	\N	\N	2	1	-29	\N	C	2019-12-20 22:14:09.31687+00	2005
30	\N	57.3634530000	16.3435930000	\N	\N	Skrikebo gård	\N	\N	\N	2	1	-30	\N	C	2019-12-20 22:14:09.31687+00	2004
31	\N	56.7257200000	14.5768690000	\N	DENDRO PROVENANCE: Catras nr 61362 samt 61385-61387; Trädens ståndorten bör vara gemensam eller närliggande. DENDRO DATE: Fyra av fem granprover (61362, 61385-61387) går att korsdateras. Årsringarnas tidsutbredning överlappar således. Trädens fällningsår kan vara samma och ståndorten bör vara gemensam eller närliggande. En viss osäkerhet råder dock om granens absoluta datering. Korrelationen med jämförande kronologier är något svag. Därför väljas att benämna granvirkets datering som sannolik. Sammanfattningsvis kan sägas att, om allt daterat virke i undersökningen (61362-61365, 61385-61387) är avverkat vid en säsong har detta skett vinterhalvåret 1830/31; Prov 4 (61364) uppvisar en avvikande tillväxt än prov 5 (61365) så att det inte går helt säkert fastställa en datering. Den yttersta årsringen dateras sannolikt till 1766, eftersom det saknas splintved i provet skall ett antal läggas till för att nå den ursprungliga vankanten (w), vilket samstämmer med fällningsåret för prov 5. Sammanfattningsvis kan sägas att, om allt daterat virke i undersökningen (61362-61365, 61385-61387) är avverkat vid en säsong har detta skett vinterhalvåret 1830/31.	Torps gård	\N	\N	\N	2	1	-31	\N	C	2019-12-20 22:14:09.31687+00	2003
32	\N	57.1217440000	15.6133060000	\N	Dackestuga; befinner sig idag på Kulturen i Lund. DENDRO PROVENANCE: Prov 61350, 61351 och rimligen 61349 avviker dendrokronologisk från de andra proverna i byggnaden (catras 61341-61348) och dateras bäst mot jämförelsematerial från sydost ifrån byggnadens placering. Det är dock väl vågat att peka ut en proveniens på grundval av två stockar; Proverna 61341-61348 är sannolikt tagna ur samma bestånd eller åtminstone samma område.	Uranäsboden	\N	\N	\N	2	1	-32	\N	C	2019-12-20 22:14:09.31687+00	2002
33	\N	56.6638130000	16.3659300000	Kalmar 45:1; Kalmar 93:1	DENDRO PROVENANCE: Proverna 1,2 och 4 är hämtade från en gemensam ståndort och bildar ryggraden i den lokala dateringskronologin. DENDRO DATE: Prov 5 har möjligen avverkats andra halvan av sommaren 1773. Detta antyder den onormalt ringa bildade sommarveden.	Wahlbomska huset	\N	\N	\N	2	1	-33	\N	C	2019-12-20 22:14:09.31687+00	2001
34	\N	57.1738730000	15.5243130000	\N	DENDRO PROVENANCE: Sannolikt samma växtplats som fem stockar i fastigheten Boktryckaren 9 i Eksjö (ref 20750003); Korrelerar med en kronologi från Eksjö, Boktryckaren 9-10. måste vara samma ståndort eller åtminstone samma område. DENDRO DATE: Prov 61333-61335 dateras till vinterhalvåret 1758/59, prov 61332 dateras till vinterhalvåret före. Av de nio byggnaderna som har daterats på Viggesbo har dessa dateringar inte förekommit. Virket utgör således beståndsdelar av en nu okänd byggnad; Prov 9 (catras 61340) dateras till vinterhalvåret 1806/07. Prov 8 (catras 61329) kan inte dendrokronologisk sammanföras med prov 9 eller någon annan jämförelsekronologi. Förhöjda korrelationer antyder avverkningstid 1814/15 eller 1866/67. Detta kan vara ett indicium för att byggnaden består av timmer med olika dateringar; Virket är avverkat vinterhalvåren 1850/51 respektive 1851/52. Inklusive prov 19b (catras 75628) blir fördelningen två vardera säsongen.	Viggesbo säteri	\N	\N	\N	2	1	-34	\N	C	2019-12-20 22:14:09.31687+00	2000
35	\N	58.0429740000	16.4086040000	\N	SITE ALIAS: Även kallad Vinäs gård. DENDRO DATE: Prov 17, K 10 och K21 passar dendrokronologiskt ihop så att de kan ha samma ursprung och eventuellt samma ålder, det saknas dock vankant i prov K21; Prov 2-6, 21 och 23 samt med en viss otydlighet K15-K19 uppvisar en tillväxtökning som närmast kan förklaras med ett virkesuttag 1827 (blädning; gallring). Det är därför mycket troligt att dessa är tagna ur gemensamt bestånd; Prov K20 har jämförts på lägre nivå än de gängse kronologier som normalt daterar prover, det vill säga små lokala kronologier. En sådan är bildad av prover från kvarteret Vaxblekaren i Eksjö, vilken ger den bästa korrelationen så att yttersta årsring blir 1703. Det valdes dock att inte fastställa detta dateringsföreslag eftersom det handlar om ett enstaka prov med ganska få årsringar och något för låg statistik och visuell korrelation. Förslagsvis kan det ses som ett indicium till en datering, inte mer.	Vinäs slott	\N	\N	\N	2	1	-35	\N	C	2019-12-20 22:14:09.31687+00	1999
36	\N	57.4126310000	14.3082620000	\N	Enligt tradition skall stugans väggplanker vara återanvänt virke från den medeltida Sanda kyrkan som låg vid Huskvarnaåns mynning. Yxhaga gammelstugan förvarades vid provtagningen 1987 på magasinet i Brunstorp, Huskvarna.	Yxenhaga Gammelstuga	\N	\N	\N	2	1	-36	\N	C	2019-12-20 22:14:09.31687+00	1998
37	\N	56.6510140000	16.3289640000	\N	DENDRO PROVENANCE: Kronologier från Mälardalen och Västergötland ger goda korrelationer, nästan lika höga som lokala kronologier. Dock sannolikt Småland.	Näset 	\N	\N	\N	2	1	-37	\N	C	2019-12-20 22:14:09.31687+00	1997
38	\N	57.6220900000	14.8988290000	\N	DENDRO PROVENANCE: Bästa korrelationerna med material från nordligaste Småland och Södra Östergötland. DENDRO DATE: Fem av sex bjälkar dateras entydigt till V 1842/43. Dessa är tagna ur samma bestånd något par av bjälkarna kan vara tagna ur samma tall. Prov 61127 kan få samma datering som ovanstående grupp, men mer troligt är att denna är avverkat på 1830-talet.	Övrabo	\N	\N	\N	2	1	-38	\N	C	2019-12-20 22:14:09.31687+00	1996
39	\N	56.5875930000	15.5844070000	\N	DENDRO PROVENANCE: Virket dateras med lokala dendrokronologiska serier. DENDRO DATE: Om flera prover från byggnaden analyseras skulle exakta fällningsår kunna fastställas.	Skäveryd	\N	\N	\N	2	1	-39	\N	C	2019-12-20 22:14:09.31687+00	1995
40	\N	57.6637820000	15.3931650000	\N	DENDRO DATE: Enligt dateringen är prov 61330 avverkat någon gång mellan år 1795 och 1825.	Slammarp	\N	\N	\N	2	1	-40	\N	C	2019-12-20 22:14:09.31687+00	1994
41	\N	56.6628320000	16.3627780000	Kalmar 93:1	DENDRO DATE: Samtliga granprover med exakt fällningstid (prov 61027-61040 samt 61049) är avverkade vinterhalvåret 1765/66. Övriga granprover (61044-61048) har rimligen avverkats samma tid.	Hattmakaren	\N	\N	\N	2	1	-41	\N	C	2019-12-20 22:14:09.31687+00	1993
42	\N	57.2102690000	15.6238950000	\N	\N	Axebo	\N	\N	\N	2	1	-42	\N	C	2019-12-20 22:14:09.31687+00	1992
43	\N	57.3033810000	16.3227950000	Döderhult 142:1	Skulptörens Axel Petterssons (Döderhultans) födelsegård. DENDRO DATE: Enligt analysrapporten var prov 75137 det enda provet där den yttersta årsringen kunde dateras. Trädet hade dock vuxit så långsamt att det kan vara möjligt att 1 eller 2 årsringar saknas. Proverna 75128-75138 är troligen alla avverkat under samma period. De undersökta träden har vuxit mycket långsamt under åren innan fällningen (genomsnittlig årsringsbredd lite över 0,1 mm). Med stöd av dateringen av prov 75129 och prov 75137 kan man anta att bostadshuset är från ca 1860; Proverna 75128-75138 är troligen alla avverkat under samma period. De undersökta träden har vuxit mycket långsamt under åren innan fällningen (genomsnittlig årsringsbredd lite över 0,1 mm). Med stöd av dateringen av prov 75129 och prov 75137 kan man anta att bostadshuset är från ca 1860.	Hagetorp	\N	\N	\N	2	1	-43	\N	C	2019-12-20 22:14:09.31687+00	1991
44	\N	57.6660240000	15.8561860000	Vimmerby 313:1	DENDRO DATE: Avverkningstiden för proverna 75164-75169 samt 75172-75173 borde vara V 1737/38; Eggertssons datering ändrades år 2000 efter införandet av Lindersons nya splintstatistik för skandinavisk ek.	Näktergalen	\N	\N	\N	2	1	-44	\N	C	2019-12-20 22:14:09.31687+00	1990
45	\N	57.3501980000	16.1339360000	\N	\N	R75220 Fallebotorp	\N	\N	\N	2	1	-45	\N	C	2019-12-20 22:14:09.31687+00	1989
46	\N	56.3781830000	14.3072670000	\N	\N	R75222 Edema	\N	\N	\N	2	1	-46	\N	C	2019-12-20 22:14:09.31687+00	1988
47	\N	56.8643915000	15.8495080000	\N	\N	Skedebäckshult	\N	\N	\N	2	1	-47	\N	C	2019-12-20 22:14:09.31687+00	1987
48	\N	56.6637610000	16.3657650000	Kalmar 41:1	DENDRO PROVENANCE: Proverna 75353-75357 har hög inbördes korrelation vilket antyder att de kommer från samma skog.	Rådmannen	\N	\N	\N	2	1	-48	\N	C	2019-12-20 22:14:09.31687+00	1986
49	\N	57.1877110000	13.3057200000	\N	DENDRO PROVENANCE: Proverna 75375 och 75376 kommer från samma skog men har inte samma fällningsår.	Hökagården	\N	\N	\N	2	1	-49	\N	C	2019-12-20 22:14:09.31687+00	1985
50	\N	56.9953920000	13.4883760000	\N	DENDRO DATE: Det bör inte saknas många årsringar i prov 75434. Detta ger en trolig datering på 1808-1828. Virket (75434-75436) som är från tre olika träd pekar mot ett gemensamt fällningsår.	Bökhult	\N	\N	\N	2	1	-50	\N	C	2019-12-20 22:14:09.31687+00	1984
51	\N	57.6659210000	15.8500490000	\N	DENDRO PROVENANCE: Tre stockar (75473, 75476 och 75477) bildar en relativt homogen grupp, vilket tyder på att de kommer från samma ståndort. Från detta område kommer sannolikt även en del stockar som används i fastigheten Ejdern 1 (Grankvistgården), Vimmerby (prov 75317, 75319, 75320, 75322-24, 75484 och 75485).	Ripan	\N	\N	\N	2	1	-51	\N	C	2019-12-20 22:14:09.31687+00	1983
52	\N	58.0440720000	14.3352700000	\N	Befinner sig enligt följebrevet i Brunstorp, Huskvarna. Exakt läge anges inte.	75001 Visingsö	\N	\N	\N	2	1	-52	\N	C	2019-12-20 22:14:09.31687+00	1982
53	\N	57.0942740000	14.0485540000	\N	\N	75304 Tånnö	\N	\N	\N	2	1	-53	\N	C	2019-12-20 22:14:09.31687+00	1981
54	\N	56.6820770000	15.3097540000	\N	\N	75377 Ljuder	\N	\N	\N	2	1	-54	\N	C	2019-12-20 22:14:09.31687+00	1980
5	\N	57.3546440164	14.2951760562	Hagshult 29:1	DENDRO DATE NOTE: Tre av de sju proverna (75458-75465) är möjliga att dendrokronologiskt datera. Dateringarna av stockarna är något spridda. Orsaken till detta är att ytlagret är något eroderat och årsringarna i yttersta delen av stockarna (prov 75464 och 75465) är tunna (snålvuxet). Prov 75459 respektive 75461 är huggna ur samma träd och ligger i skilda lagerskift. Dessa prover uppvisar således samma, dock okända, fällningsår. Detta tyder på att både övre och undre lagerskiftet är anlagda samtidigt. Allmänt om virket kan sägas att det är relativt snabbvuxet med enstaka tillväxtkolappser, detta har bidragit till att majoriteten av stockarna inte har varit möjliga att datera. Ett sådan årsringsvariation uppstår vanligen i områden med lågfrekventa men med kraftiga översvämningar, exempelvis i kanten av en våtmark/myrmark. Virket kan således vara taget direkt i anslutning till myren, vilket även den daterande referenskronologin antyder.	Hagshult 29:1	\N	\N	\N	3	1	-5	\N	C	2019-12-20 22:14:19.067462+00	2047
6	\N	57.7816256629	14.1669262200	Jönköping 137:1	DENDRO DATE NOTE: Samtliga prover (61486-61489) saknar inbördes dendrokronologiska samband, vilket indikerar att de är skilda åt i tid eller rum. Proverna 61486 och 61487 har inte med full säkerhet daterats, vilket beror på det lilla antal årsringar proven innehåller. Det bästa dateringsförslaget för prov 1 (61486) är vinterhalvåret 1619/20 och för prov 2 (61487), något mer säkert, är vinterhalvåret 1614/15. Samtliga prover (61486-61489) saknar inbördes dendrokronologiska samband, vilket indikerar att de är skilda åt i tid eller rum.	Jönköping 137:1	\N	\N	\N	3	1	-6	\N	C	2019-12-20 22:14:19.067462+00	2046
7	\N	57.7817797248	14.1712444928	Jönköping 50:1	DENDRO PROVENANCE: Catras 61463, 61465 och 61466 kan relateras sinsemellan och har liknande tillväxtkurvor. Deras ståndort är i närområdet.; DENDRO DATE NOTE: Den dendrokronologiska dateringen lyckades inte med de ordinarie dendrokronologiska serierna från regionen, utan med en dendrokronologisk serie från en stock från kvarteret Apeln med DENDRO-nummer 75769. Dessa träd har ett gemensamt särpräglat tillväxtmönster som visar att de har samma ståndort. Groddåret är bedömt för båda, omkring 1450-talet. En tillväxt kollaps är noterad (1571-1607), vilket tyder på en hastig grundvattenhöjning. Årtal för kollapsen anges med parentes eftersom dessa är något oklara i avseende på orsaken till tillväxtminskningen, den har exempelvis inte reducerats så mycket. Rimligen är det första året som är det viktigaste. Den senare avslutande gränsen kan visa när de hydrologiska förhållandena blir normala igen men kan även visa när träden har återhämtat sig, vilket kan har skett flera år efter de hydrologiska förhållandena blivit normala. Tolkningen grundar sig på att omgivningen på högre nivåer inom regionen inte uppvisar sådana tillväxtkollapser med i vissa fall kraftig återhämtning. Vidare så uppträder nedgången samtidigt på flera träd vid Jönköpingsområdet samtidigt som en förväntad årsringsbredd inte skulle vara tunnare. Orsakerna till de plötsligt (från ett år till ett annat) försämrade förhållandena och att de uppträder i just Jönköping förefaller var knutet till stadens unika placering. Vid södra delen av en stor lång-sträckt insjö med betydligt kraftigare landhöjning i sjöns norra del jämfört med den södra. Sjön ”tippar” mot söder så att sjöns yta tillsammans med grundvattenytan höjs successivt. När ett flertal faktorer sedan samverkar som extremt (tillfälligt) högvatten och en nordlig storm kan större landområde ställas under vatten. Måhända tillåter inte marken/geologin att vattnet dräneras så snabbt utan att trädens rötter lider av syrebrist och stora delar av rotsystemet dör. En annan möjlighet skulle kunna vara antropologen, till exempel invallning. Det som talar emot detta är att sällan uppträder i vårt stora dendrokronologiska material. Vi har sådana exempel från bergsbruksområde där man kan förvänta sig dämning av bäckar för vattenkraft etc. Spår efter en brand går att finna i proverna med CATRAS-nr 61055, 61064 och 61071. Brandtillfället har daterats till 1569 med hjälp av prov 61064. Om brandtillfället är det samma hos de tre proverna skulle 61055 och 61071 kunna daterats med hjälp av 61064. Tillväxtmönstren hos 61064 och 61071 överensstämmer så pass bra att det visuellt går att passa samman dem och datera provet. När det gäller tillväxtmönstret hos 61055 avviker det, vilket gör att provet inte med säkerhet kan dateras trots brandmärket.; Tre eller fyra skilda dateringar kan urskiljas från undersökningen. Prov 61368 och 61369 kan vara avverkade samtidigt åren 1699-1701. Prov 61370 är avverkat vinterhalvåret 1617/18 samt prov 61371 är avverkat någon gång under 1585-1589.	Jönköping 50:1	\N	\N	\N	3	1	-7	\N	C	2019-12-20 22:14:19.067462+00	2045
8	\N	56.6618090594	16.3569330827	Kalmar 93:1	DENDRO PROVENANCE: Hög inbördes korrelation mellan de daterade stockarna (75370-72 samt 75374) vilket antyder att de kommer från samma skogsbestånd.; DENDRO DATE NOTE: De två ekproverna (61358, 61361) är tagna från samma träd och är således av samma ålder och är sannolikt avverkat vinterhalvåret 1646/47. Den dendrokronologiska metodiken har en hög precision men kan få, vid otillräckligt underlag, en statistisk osäkerhet. Eftersom de båda ekproven är tagna från ett träd blir undersökningen baserat på detta enda träd. Även om det är 216 årsringar så blir variationsbredden svag, varje udda beteende som just detta trädet har gjort, får betydelse för möjligheterna att datera denna med jämförande kronologier som mer följer trädens medelvärde år från år i det aktuella geografiska området. När det gäller prov 61359 och 61361 är vi i gränslandet för en säker datering. Ovanstående förbehåll gäller även för proveniensbestämningen som är beräknad till Smålandsregionen.; Prov 61356 och 61360 korsdateras, även dessa med en viss osäkerhet (eftersom de har så få årsringar), så att de får ett gemensamt, dock okänt, fällningsår. Catras 61454 och 61456 uppvisar svag tillväxt de sista åren av levnad, så försiktigvis bedöms fällningstiden från vinterhalvåret 1682/83 till 1683/84.	Kalmar 93:1	\N	\N	\N	3	1	-8	\N	C	2019-12-20 22:14:19.067462+00	2044
9	\N	56.6638782818	16.3640888066	Kalmar 93:2	\N	Kalmar 93:2	\N	\N	\N	3	1	-9	\N	C	2019-12-20 22:14:19.067462+00	2043
10	\N	56.6594533912	16.3504694411	Kalmar 94:1	\N	Kalmar 94:1	\N	\N	\N	3	1	-10	\N	C	2019-12-20 22:14:19.067462+00	2042
11	\N	56.6946315285	16.3427964820	\N	\N	75343 Kalmar	\N	\N	\N	3	1	-11	\N	C	2019-12-20 22:14:19.067462+00	2041
12	\N	57.0183302249	16.4461903241	\N	DENDRO PROVENANCE: Ekarnas ståndort är sannolikt gemensam (61094-61099) och i förhållande till fyndplatsen inom ett närliggande område. DENDRO DATE NOTE: Samtliga daterade prover (61094-61099) pekar på en gemensam avverkningstid, vinterhalvåret 1099/1100. Prov 61098 visar den exakta fällningstidpunkten eftersom provet har vankant och till och med bark. En skada på samma prov tillsammans med en samtida tillväxttillväxtkollaps, som vara till trädets avverkning, tyder på att trädet hamlades eller på annat sätt gren/kronstam -beskars mellan augusti 1093 och maj 1094. En samtida tillväxttillväxtkollaps syns även på prov 61095. Påle 1 (prov 61094) uppvisar (enligt uppdrags¬givarens skiss) en sannolik läkning efter ett äldre toppbrott som måste har legat minst 2,5 meter över markytan. Möjligen är det så stammarna från prov 2 och 5 (61095, 61098) har behandlats. COMMENT: i direkt anslutning till RAÄ Mönsterås 31:1, 32:1, 32:2	61094 Kronobäck 	\N	\N	\N	3	1	-12	\N	C	2019-12-20 22:14:19.067462+00	2040
13	\N	57.3880753428	15.7859983534	Målilla 381	DENDRO DATE NOTE: X och Y representerar två (eller möjligen bara ett) specifika men okända fällningsår.	Målilla 381	\N	\N	\N	3	1	-13	\N	C	2019-12-20 22:14:19.067462+00	2039
14	\N	57.0615243093	16.5149384122	Mönsterås 376:1	DENDRO PROVENANCE: Proverna 75210-75215 har hög inbördes korrelation (kommer från samma skog).	Mönsterås 376:1	\N	\N	\N	3	1	-14	\N	C	2019-12-20 22:14:19.067462+00	2038
15	\N	57.6920752842	15.4937982090	Rumskulla 234:1	\N	Rumskulla 234:1	\N	\N	\N	3	1	-15	\N	C	2019-12-20 22:14:19.067462+00	2037
16	\N	57.0687527312	15.0425491175	\N	\N	75437 Sjösås	\N	\N	\N	3	1	-16	\N	C	2019-12-20 22:14:19.067462+00	2036
17	\N	57.7326464425	15.8214516130	Södra Vi 6:1	\N	Södra Vi 6:1	\N	\N	\N	3	1	-17	\N	C	2019-12-20 22:14:19.067462+00	2035
18	\N	56.8494238890	14.8554915766	Växjö 61:1	\N	Växjö 61:1	\N	\N	\N	3	1	-18	\N	C	2019-12-20 22:14:19.067462+00	2034
31	48.0000000000	36.3191666700	139.3933333000	\N	Open-air; Inland	Shimojuku	\N	\N	\N	4	1	-31	\N	C	2019-12-20 22:14:28.053842+00	2070
32	4.0000000000	39.3894400000	140.0592000000	\N	Shell midden; Close to the coast	Shobuzaki	\N	\N	\N	4	1	-32	\N	C	2019-12-20 22:14:28.053842+00	2069
33	97.0000000000	42.8069444400	143.1997222000	\N	Open-air; Inland	Taisho 3	\N	\N	\N	4	1	-33	\N	C	2019-12-20 22:14:28.053842+00	2068
34	92.0000000000	42.8233333300	143.2016667000	\N	Open-air; Inland	Taisho 6	\N	\N	\N	4	1	-34	\N	C	2019-12-20 22:14:28.053842+00	2067
35	95.0000000000	42.8080555600	143.1991667000	\N	Open-air; Inland	Taisho 7	\N	\N	\N	4	1	-35	\N	C	2019-12-20 22:14:28.053842+00	2066
36	97.0000000000	42.8080555600	143.1958333000	\N	Open-air; Inland	Taisho 8	\N	\N	\N	4	1	-36	\N	C	2019-12-20 22:14:28.053842+00	2065
37	209.0000000000	37.0513888900	138.6861111000	\N	Open-air; Inland	Tazawa	\N	\N	\N	4	1	-37	\N	C	2019-12-20 22:14:28.053842+00	2064
38	118.0000000000	32.2123600000	130.7740000000	\N	Open-air; Inland	Tendogao	\N	\N	\N	4	1	-38	\N	C	2019-12-20 22:14:28.053842+00	2063
39	13.0000000000	35.8775000000	140.4394444000	\N	Shell midden; Inland	Tokisaki	\N	\N	\N	4	1	-39	\N	C	2019-12-20 22:14:28.053842+00	2062
40	34.0000000000	32.7510000000	130.7917000000	\N	Open-air; Inland	Tonohira	\N	\N	\N	4	1	-40	\N	C	2019-12-20 22:14:28.053842+00	2061
41	4.0000000000	35.5545940000	135.9008760000	\N	Shell midden; Lake shore	Torihama	\N	\N	\N	4	1	-41	\N	C	2019-12-20 22:14:28.053842+00	2060
42	11.0000000000	35.7125000000	140.0136110000	\N	Shell midden; Inland	Torikake-Nishi	\N	\N	\N	4	1	-42	\N	C	2019-12-20 22:14:28.053842+00	2059
43	4.0000000000	43.3897222200	145.7488889000	\N	Open-air; Lake shore	Tosamupolo	\N	\N	\N	4	1	-43	\N	C	2019-12-20 22:14:28.053842+00	2058
44	259.0000000000	31.7108300000	130.8028000000	\N	Open-air; Close to the coast	Uenohara	\N	\N	\N	4	1	-44	\N	C	2019-12-20 22:14:28.053842+00	2057
45	211.0000000000	37.0488888900	138.6708333000	\N	Open-air; Inland	Unoki Minami	\N	\N	\N	4	1	-45	\N	C	2019-12-20 22:14:28.053842+00	2056
46	120.0000000000	36.5433330000	139.9725000000	\N	Open-air; Inland	Utsunomiya Seiryo highschool	\N	\N	\N	4	1	-46	\N	C	2019-12-20 22:14:28.053842+00	2055
47	278.0000000000	42.7208333300	142.9866667000	\N	Open-air; Inland	Yachiyo A	\N	\N	\N	4	1	-47	\N	C	2019-12-20 22:14:28.053842+00	2054
48	384.0000000000	36.5966670000	139.5966670000	\N	Open-air; Inland	Yamazaki-Kita	\N	\N	\N	4	1	-48	\N	C	2019-12-20 22:14:28.053842+00	2053
49	1534.0000000000	36.6228000000	138.4408000000	\N	Rock shelter/Cave; Mountainous	Yukura Cave	\N	\N	\N	4	1	-49	\N	C	2019-12-20 22:14:28.053842+00	2052
1	\N	57.7850820000	14.2826540000	Hakarp 27:1	\N	Appelbladska smedjan	\N	\N	\N	2	1	-1	\N	C	2019-12-20 22:14:09.31687+00	2033
2	\N	57.7598510000	16.6334030000	Västervik 58:1	DENDRO PROVENANCE: Hög inbördes korrelation mellan proverna 75387-75391 vilket antyder att de har vuxit i samma skog; Hög inbördes korrelation mellan proverna75384-386 vilket antyder att de har vuxit i samma skog. DENDRO DATE: Hög inbördes korrelation mellan proverna 75387-75391, fällningstid ca 1758.	Aspagården	\N	\N	\N	2	1	-2	\N	C	2019-12-20 22:14:09.31687+00	2032
3	\N	57.8223670000	14.2728570000	Hakarp 9:1	\N	Brunstorps gård	\N	\N	\N	2	1	-3	\N	C	2019-12-20 22:14:09.31687+00	2031
4	\N	57.6836530000	14.0941420000	\N	\N	Bråtens gård	\N	\N	\N	2	1	-4	\N	C	2019-12-20 22:14:09.31687+00	2030
5	\N	57.0123780000	15.1077760000	Dädesjö 501:1	\N	Dädesjö hembygdsgård	\N	\N	\N	2	1	-5	\N	C	2019-12-20 22:14:09.31687+00	2029
6	\N	57.0616860000	15.5916710000	Älghult 70:1	\N	Flöxhult säteri	\N	\N	\N	2	1	-6	\N	C	2019-12-20 22:14:09.31687+00	2028
7	\N	57.0125960000	16.8666740000	\N	DENDRO DATE: Ekproverna F1-F7 ser dendrokronologiskt likartat ut, vilket indikerar att de har samma ålder. Bästa anpassning mot daterat referensmaterial görs mot prov F7. detta leder förslagsvis till samma avverkningstid som prov F7. Virket är sannolikt tagit ur trädets krona i form av grövre grenar.	Föra kyrka	\N	\N	\N	2	1	-7	\N	C	2019-12-20 22:14:09.31687+00	2027
8	\N	57.8247120000	13.8613050000	\N	Ligger i Ryfors bruks skogar.	Försjö torp	\N	\N	\N	2	1	-8	\N	C	2019-12-20 22:14:09.31687+00	2026
9	\N	56.7765050000	13.8392550000	\N	DENDRO DATE: Proverna (76190-75202) är tagna utsprett i huset och kan representera flera byggperioder. För att öka möjligheten till en datering borde varje byggperiod representeras genom minst 10 prover. Virket kommer från träd som uppvisar en väldigt oregelbunden tillväxt. De har inte vuxit i ett regulärt skogsbestån utan måste vara avverkat på olika ställen.	Gamla gästgivaregården	\N	\N	\N	2	1	-9	\N	C	2019-12-20 22:14:09.31687+00	2025
10	\N	57.6658650000	15.8517570000	Vimmerby 199:1	DENDRO PROVENANCE: Prov 75484 och 75485 har höga korrelationer med 75317, 75319, 75320, 75322-75324 (Grankvistgården) samt 75473, 75476 och 75477 i byggnaden Ripan 10, vilket tyder på att de har vuxet i ett gemensamt skogsområde; Virket från den yngre byggfasen (75478-75480) dateras entydigt till vinterhalvåret 1821/22. Detta virke förfaller dock vara hämtat från olika ståndorter då det uppvisar låga korrelationer sinsemellan. De icke daterade proverna (75481, 75482, 75487) korrelera dendrokronologiskt inte alls, samtliga vinteravverkade. DENDRO DATE: Dateringen ändrades år 2000 efter införandet av Lindersons nya splintstatistik för skandinavisk ek.	Grankvistgården	\N	\N	\N	2	1	-10	\N	C	2019-12-20 22:14:09.31687+00	2024
4	\N	57.7231480591	16.4514961890	Gladhammar 277:1	DENDRO DATE NOTE: Prov 1 och 2 från schakt 1 (61352-61353) korrelerar väl sinsemellan samt mot kronologier från Småland och Östergötland och är därför sannolikt avverkade samtidigt mellan åren 1642 - 1662. Prov 61354-355 korrelerade inte med övriga prover eller några referenskronologier. ; COMMENT: I den arkeologiska undersökningen ingick även Raä 229 och 155.	Gladhammar 277:1	\N	\N	\N	3	1	-4	\N	C	2019-12-20 22:14:19.067462+00	2048
1	41.0000000000	42.9175000000	143.1888889000	\N	Open-air; Inland	Akatsuki	\N	\N	\N	4	1	-1	\N	C	2019-12-20 22:14:28.053842+00	2100
2	87.0000000000	34.9813900000	135.9078000000	\N	Shell midden; Lake shore	Awazu	\N	\N	\N	4	1	-2	\N	C	2019-12-20 22:14:28.053842+00	2099
3	142.0000000000	32.2527800000	130.8950000000	\N	Open-air; Inland	Haizuka	\N	\N	\N	4	1	-3	\N	C	2019-12-20 22:14:28.053842+00	2098
4	10.0000000000	33.3111111100	130.3011111000	\N	Shell midden; Inland	Higashimyou	\N	\N	\N	4	1	-4	\N	C	2019-12-20 22:14:28.053842+00	2097
5	57.0000000000	36.4002800000	140.0319400000	\N	Open-air; Inland	Ichinotsuka	\N	\N	\N	4	1	-5	\N	C	2019-12-20 22:14:28.053842+00	2096
1	\N	56.6446555568	15.5777878903	Algutsboda 79:1	\N	Algutsboda 79:1	\N	\N	\N	3	1	-1	\N	C	2019-12-20 22:14:19.067462+00	2051
2	\N	57.8995715462	16.4080337748	Gamleby 450:1	DENDRO DATE NOTE: Proverna 75140-149 har väldigt få årsringar men kunde alla dateras, de fördelar sig på 2 anläggningsperioder. Avverkningen V 1264/65 respektive V 1272/73. Det gick inte att datera proverna pga: 1) trädslag gran, 2) deformerade prover in situ.	Gamleby 450:1	\N	\N	\N	3	1	-2	\N	C	2019-12-20 22:14:19.067462+00	2050
3	\N	57.7189194287	16.4402462887	Gladhammar 155:1	DENDRO DATE NOTE: Catras 61446-61449 dateras till 1621-29 om man antar att de är avverkade samtidigt. Detta stärks av att virket har vuxit på ett gemensamt område. Prov 61446 kan avvila så mycket att det kan vara fällt så tidigt som 1590. COMMENT: I den arkeologiska undersökningen ingick även Raä 229 och 277	Gladhammar 155:1	\N	\N	\N	3	1	-3	\N	C	2019-12-20 22:14:19.067462+00	2049
6	586.0000000000	36.5458333300	138.6988889000	\N	Rock shelter/Cave; Mountainous	Ishihata	\N	\N	\N	4	1	-6	\N	C	2019-12-20 22:14:28.053842+00	2095
7	94.0000000000	34.9594444400	135.9086111000	\N	Shell midden; Lake shore	Ishiyama	\N	\N	\N	4	1	-7	\N	C	2019-12-20 22:14:28.053842+00	2094
8	207.0000000000	37.0516666700	138.6855556000	\N	Open-air; Inland	Jin	\N	\N	\N	4	1	-8	\N	C	2019-12-20 22:14:28.053842+00	2093
9	218.0000000000	31.6111100000	130.9583000000	\N	Open-air; Close to the coast	Jozuka	\N	\N	\N	4	1	-9	\N	C	2019-12-20 22:14:28.053842+00	2092
10	33.0000000000	41.9042300000	140.9746400000	\N	Open-air; Close to the coast	Kakkumi	\N	\N	\N	4	1	-10	\N	C	2019-12-20 22:14:28.053842+00	2091
11	146.0000000000	31.6488888900	130.5530556000	\N	Open-air; Close to the coast	Kakuriyama	\N	\N	\N	4	1	-11	\N	C	2019-12-20 22:14:28.053842+00	2090
12	429.0000000000	33.6136100000	132.9675000000	\N	Rock shelter/Cave; Inland	Kamikuroiwa	\N	\N	\N	4	1	-12	\N	C	2019-12-20 22:14:28.053842+00	2089
13	13.0000000000	31.7250000000	130.6150000000	\N	Open-air; Close to the coast	Kenshojo	\N	\N	\N	4	1	-13	\N	C	2019-12-20 22:14:28.053842+00	2088
14	291.0000000000	31.6780555600	130.9405556000	\N	Open-air; Close to the coast	Kiriki Mimitori	\N	\N	\N	4	1	-14	\N	C	2019-12-20 22:14:28.053842+00	2087
15	188.0000000000	37.5925000000	139.4052778000	\N	Rock shelter/Cave; Inland	Kosegasawa	\N	\N	\N	4	1	-15	\N	C	2019-12-20 22:14:28.053842+00	2086
16	160.0000000000	37.0733300000	138.7103000000	\N	Open-air; Inland	Kubodera Minami	\N	\N	\N	4	1	-16	\N	C	2019-12-20 22:14:28.053842+00	2085
17	137.0000000000	31.6097200000	130.4461000000	\N	Open-air; Close to the coast	Maebaru	\N	\N	\N	4	1	-17	\N	C	2019-12-20 22:14:28.053842+00	2084
18	103.0000000000	43.7925000000	142.3255556000	\N	Open-air; Inland	Midorimachi 1	\N	\N	\N	4	1	-18	\N	C	2019-12-20 22:14:28.053842+00	2083
19	55.0000000000	37.2980555600	138.8097222000	\N	Open-air; Inland	Motonakago	\N	\N	\N	4	1	-19	\N	C	2019-12-20 22:14:28.053842+00	2082
20	246.0000000000	37.5436111100	139.3622222000	\N	Rock shelter/Cave; Inland	Muroya Cave	\N	\N	\N	4	1	-20	\N	C	2019-12-20 22:14:28.053842+00	2081
21	116.0000000000	31.6144400000	130.3986000000	\N	Open-air; Close to the coast	Nagasakobira	\N	\N	\N	4	1	-21	\N	C	2019-12-20 22:14:28.053842+00	2080
22	670.0000000000	36.8330555600	138.2038889000	\N	Open-air; Inland	Nakamachi	\N	\N	\N	4	1	-22	\N	C	2019-12-20 22:14:28.053842+00	2079
23	25.0000000000	35.8936111100	140.3988889000	\N	Shell midden; Inland	Nishinojo	\N	\N	\N	4	1	-23	\N	C	2019-12-20 22:14:28.053842+00	2078
24	191.0000000000	44.4041666700	142.4833333000	\N	Open-air; Inland	Nisshin 3	\N	\N	\N	4	1	-24	\N	C	2019-12-20 22:14:28.053842+00	2077
25	159.0000000000	35.2361110000	138.5641670000	\N	Open-air; Close to the coast	Ohshikakubo	\N	\N	\N	4	1	-25	\N	C	2019-12-20 22:14:28.053842+00	2076
26	85.0000000000	37.2694444400	138.8486111000	\N	Open-air; Inland	Saigura	\N	\N	\N	4	1	-26	\N	C	2019-12-20 22:14:28.053842+00	2075
27	28.0000000000	30.5763888900	130.9502778000	\N	Open-air; Close to the coast	Sankakuyama I	\N	\N	\N	4	1	-27	\N	C	2019-12-20 22:14:28.053842+00	2074
28	675.0000000000	36.8311111100	138.1897222000	\N	Open-air; Inland	Seiko Sanso B	\N	\N	\N	4	1	-28	\N	C	2019-12-20 22:14:28.053842+00	2073
29	190.0000000000	32.8736111100	130.9269444000	\N	Open-air; Inland	Setakitsunezuka	\N	\N	\N	4	1	-29	\N	C	2019-12-20 22:14:28.053842+00	2072
30	728.0000000000	35.8361100000	138.4277800000	\N	Open-air; Mountainous	Shaguchi	\N	\N	\N	4	1	-30	\N	C	2019-12-20 22:14:28.053842+00	2071
3387	\N	59.4186334750	13.8322949528	Väse 531	\N	Östra Ve	\N	\N	Ancient monument	1	1	-3387	\N	C	2019-12-20 22:13:53.799521+00	1567
3386	\N	56.2879514518	13.3279141309	Örkelljunga 6	\N	Östra Spång	\N	\N	Ancient monument	1	1	-3386	\N	C	2019-12-20 22:13:53.799521+00	1568
3385	\N	57.7181041092	14.3790256531	Öggestorp 195?	\N	Öggestorp	\N	\N	Ancient monument	1	1	-3385	\N	C	2019-12-20 22:13:53.799521+00	1569
3384	\N	59.5908195477	17.9070979103	\N	\N	Ås-Husby	\N	\N	\N	1	1	-3384	\N	C	2019-12-20 22:13:53.799521+00	1570
3383	\N	56.0605211402	14.4660348079	Ivetofta 162	\N	Årups norre vång	\N	\N	Ancient monument	1	1	-3383	\N	C	2019-12-20 22:13:53.799521+00	1571
3382	\N	56.0627308134	14.4742592081	Ivetofta 207	\N	Årup (Skräbeån)	\N	\N	Ancient monument	1	1	-3382	\N	C	2019-12-20 22:13:53.799521+00	1572
3381	\N	59.0897381433	18.1786279464	\N	\N	Årsta	\N	\N	Poor	1	1	-3381	\N	C	2019-12-20 22:13:53.799521+00	1573
3380	\N	60.6822232925	15.0880178416	\N	\N	Ål 291	\N	\N	Poor	1	1	-3380	\N	C	2019-12-20 22:13:53.799521+00	1574
3379	\N	58.6634567680	16.1772440843	Kvillinge 36	\N	Åby	\N	\N	Ancient monument	1	1	-3379	\N	C	2019-12-20 22:13:53.799521+00	1575
3378	\N	60.0244244778	18.6063665051	Häverö 26	\N	Ytterby	\N	\N	Ancient monument	1	1	-3378	\N	C	2019-12-20 22:13:53.799521+00	1576
3377	\N	55.3930448650	13.1498252554	Trelleborg 42	\N	Västervång	\N	\N	Ancient monument	1	1	-3377	\N	C	2019-12-20 22:13:53.799521+00	1577
3376	\N	58.9209283539	17.4490501954	\N	\N	Västerljung Grav	\N	\N	Poor	1	1	-3376	\N	C	2019-12-20 22:13:53.799521+00	1578
3375	\N	53.8420950000	14.6152500000	\N	\N	Wolin	\N	\N	Poor	1	1	-3375	\N	C	2019-12-20 22:13:53.799521+00	1579
3374	\N	64.8647793587	16.7336253556	Vilhelmina 652?	\N	Vojmsjöns utlopp	\N	\N	Poor	1	1	-3374	\N	C	2019-12-20 22:13:53.799521+00	1580
3373	\N	64.8768240125	16.7313612395	Vilhelmina 938; Vilhelmina 933	\N	Vojmsjön	\N	\N	Approximate	1	1	-3373	\N	C	2019-12-20 22:13:53.799521+00	1581
3372	\N	58.3166922306	14.9618853709	Väderstad 35	\N	Vistad	\N	\N	Ancient monument	1	1	-3372	\N	C	2019-12-20 22:13:53.799521+00	1582
3371	\N	55.5544711134	12.9755594907	Bunkeflo 101	\N	Vintriediket	\N	\N	Ancient monument	1	1	-3371	\N	C	2019-12-20 22:13:53.799521+00	1583
3370	\N	55.6137376283	14.2879259394	Rörum 15	\N	Vik	\N	\N	Ancient monument	1	1	-3370	\N	C	2019-12-20 22:13:53.799521+00	1584
3369	\N	60.1191526511	18.1446141934	Alunda 1?	\N	Vettsta	\N	\N	Approximate	1	1	-3369	\N	C	2019-12-20 22:13:53.799521+00	1585
3368	\N	58.3509511955	15.2594751972	Veta 45	\N	Veta 45	\N	\N	Ancient monument	1	1	-3368	\N	C	2019-12-20 22:13:53.799521+00	1586
3367	\N	59.9709979975	17.6466146569	Ärentuna 325	\N	Vaxmyra	\N	\N	Ancient monument	1	1	-3367	\N	C	2019-12-20 22:13:53.799521+00	1587
3366	\N	55.9944577384	14.3472834655	\N	\N	Vanneberga	\N	\N	Poor	1	1	-3366	\N	C	2019-12-20 22:13:53.799521+00	1588
3365	\N	57.8819565197	11.9922636942	Ytterby 85	\N	Valtersberg	\N	\N	Ancient monument	1	1	-3365	\N	C	2019-12-20 22:13:53.799521+00	1589
3364	\N	64.7002525283	16.3891562684	Vilhelmina 234	\N	Vallviksvallen	\N	\N	Ancient monument	1	1	-3364	\N	C	2019-12-20 22:13:53.799521+00	1590
3363	\N	59.3613691005	15.0865799962	Kil 79; Kil 20	\N	Vallby	\N	\N	Approximate	1	1	-3363	\N	C	2019-12-20 22:13:53.799521+00	1591
3362	\N	56.0640559691	14.5528904401	Sölvesborg 49?	\N	Valje	\N	\N	Approximate	1	1	-3362	\N	C	2019-12-20 22:13:53.799521+00	1592
3361	\N	56.0560630000	12.2010400000	\N	\N	Valby	\N	\N	Poor	1	1	-3361	\N	C	2019-12-20 22:13:53.799521+00	1593
3360	\N	60.6304902634	16.9968297732	Valbo 412	\N	Valboön	\N	\N	Ancient monument	1	1	-3360	\N	C	2019-12-20 22:13:53.799521+00	1594
3359	\N	65.6483993174	18.3407217548	Arvidsjaur 54?	\N	V Sandudden	\N	\N	Approximate	1	1	-3359	\N	C	2019-12-20 22:13:53.799521+00	1595
3358	\N	55.6644396201	13.1681066727	Uppåkra 5	\N	Uppåkra	\N	\N	Ancient monument	1	1	-3358	\N	C	2019-12-20 22:13:53.799521+00	1596
3357	\N	65.5385000571	16.1164565045	Stensele 166	\N	Ullisjaur	\N	\N	Ancient monument	1	1	-3357	\N	C	2019-12-20 22:13:53.799521+00	1597
3356	\N	57.1065632606	18.3180837861	Grötlingbo 54?	\N	Uddvide	\N	\N	Approximate	1	1	-3356	\N	C	2019-12-20 22:13:53.799521+00	1598
3355	\N	59.2744150000	10.4035510000	\N	\N	Tønsberg, Teglhagen	\N	\N	Approximate	1	1	-3355	\N	C	2019-12-20 22:13:53.799521+00	1599
3354	\N	59.2683810000	10.4059950000	\N	\N	Tønsberg, Peterskirken	\N	\N	Approximate	1	1	-3354	\N	C	2019-12-20 22:13:53.799521+00	1600
3353	\N	59.2660140000	10.4094140000	\N	\N	Tønsberg, Essotomten	\N	\N	Approximate	1	1	-3353	\N	C	2019-12-20 22:13:53.799521+00	1601
3352	\N	59.2938779467	16.1413410195	\N	\N	Täby	\N	\N	Poor	1	1	-3352	\N	C	2019-12-20 22:13:53.799521+00	1602
3351	\N	55.3991926004	14.0940762635	Valleberga 30?	\N	Tygapil	\N	\N	Ancient monument	1	1	-3351	\N	C	2019-12-20 22:13:53.799521+00	1603
3350	\N	55.4654098438	13.9498724704	Stora Köpinge 120	\N	Trollasten	\N	\N	Ancient monument	1	1	-3350	\N	C	2019-12-20 22:13:53.799521+00	1604
3349	\N	58.5345800000	31.2841260000	\N	\N	Troitski	\N	\N	Poor	1	1	-3349	\N	C	2019-12-20 22:13:53.799521+00	1605
3348	\N	49.7539630000	6.6440110000	\N	\N	Trier	\N	\N	Poor	1	1	-3348	\N	C	2019-12-20 22:13:53.799521+00	1606
3347	\N	55.3769870556	13.1464553701	Trelleborg 19	\N	Trelleborg 19	\N	\N	Poor	1	1	-3347	\N	C	2019-12-20 22:13:53.799521+00	1607
3346	\N	60.3096532057	17.4877290289	Tierp 316	\N	Torslunda	\N	\N	Ancient monument	1	1	-3346	\N	C	2019-12-20 22:13:53.799521+00	1608
3345	\N	55.8583589589	12.9315616122	Tofta 39?	\N	Tofta 39	\N	\N	Ancient monument	1	1	-3345	\N	C	2019-12-20 22:13:53.799521+00	1609
3344	\N	55.8613309856	12.9180757959	Tofta 19	\N	Tofta 19	\N	\N	Ancient monument	1	1	-3344	\N	C	2019-12-20 22:13:53.799521+00	1610
3343	\N	60.3125550000	20.1617870000	\N	\N	Tjärnan	\N	\N	Poor	1	1	-3343	\N	C	2019-12-20 22:13:53.799521+00	1611
3342	\N	52.4146250000	0.7486550000	\N	\N	Thetford	\N	\N	Poor	1	1	-3342	\N	C	2019-12-20 22:13:53.799521+00	1612
3280	\N	50.8274780000	3.2624760000	\N	\N	Rijselestraat/Kasteelstraat	\N	\N	Approximate	1	1	-3280	\N	C	2019-12-20 22:13:53.799521+00	1674
3341	\N	58.4030694274	15.7009580259	Linköping 125; Linköping 123; Vårdsberg 267; Vårdsberg 19; Vårdsberg 18; Vårdsberg 17	\N	Tannefors	\N	\N	Poor	1	1	-3341	\N	C	2019-12-20 22:13:53.799521+00	1613
3340	\N	56.4592866705	16.0782357655	Söderåkra 342?	\N	Söderåkra (Eket)	\N	\N	Ancient monument	1	1	-3340	\N	C	2019-12-20 22:13:53.799521+00	1614
3339	\N	56.4518101707	16.0762879288	Söderåkra 285; Söderåkra 284	\N	Söderåkra	\N	\N	Ancient monument	1	1	-3339	\N	C	2019-12-20 22:13:53.799521+00	1615
3338	\N	59.8049127342	17.7595491137	Danmark 98	\N	Söderby	\N	\N	Ancient monument	1	1	-3338	\N	C	2019-12-20 22:13:53.799521+00	1616
3337	\N	58.6400517885	16.5984370666	Kvarsebo 79	\N	Säter	\N	\N	Ancient monument	1	1	-3337	\N	C	2019-12-20 22:13:53.799521+00	1617
3336	\N	55.8177808202	13.0748875974	Dagstorp 6	\N	Särslöv	\N	\N	Ancient monument	1	1	-3336	\N	C	2019-12-20 22:13:53.799521+00	1618
3335	\N	55.9063531786	12.8303871012	Säby 29?	\N	Säbyholm	\N	\N	Approximate	1	1	-3335	\N	C	2019-12-20 22:13:53.799521+00	1619
3334	\N	55.9045303022	12.8499433536	Säby 5	\N	Säby 5	\N	\N	Ancient monument	1	1	-3334	\N	C	2019-12-20 22:13:53.799521+00	1620
3333	\N	60.2847500000	20.1246000000	\N	\N	Syllöda	\N	\N	Poor	1	1	-3333	\N	C	2019-12-20 22:13:53.799521+00	1621
3332	\N	58.3827989492	14.8455975309	\N	\N	Svälinge, Tåkern	\N	\N	Poor	1	1	-3332	\N	C	2019-12-20 22:13:53.799521+00	1622
3331	\N	55.5468493119	12.9941183078	Bunkeflo 82	\N	Svågertorp 8B-C	\N	\N	Ancient monument	1	1	-3331	\N	C	2019-12-20 22:13:53.799521+00	1623
3330	\N	52.5673150000	5.6410930000	\N	\N	Swifterbant	\N	\N	Poor	1	1	-3330	\N	C	2019-12-20 22:13:53.799521+00	1624
3329	\N	55.7682158124	13.0656621037	Stävie 3	\N	Stävie 3:1	\N	\N	Ancient monument	1	1	-3329	\N	C	2019-12-20 22:13:53.799521+00	1625
3328	\N	63.4390824281	16.8872056190	Ådals-Liden 10?	\N	Ställverksboplatsen	\N	\N	Approximate	1	1	-3328	\N	C	2019-12-20 22:13:53.799521+00	1626
3327	\N	59.6168653169	17.7224306497	Sigtuna 195	\N	St. Gatan. Kv. Handelsmannen 8-9	\N	\N	Ancient monument	1	1	-3327	\N	C	2019-12-20 22:13:53.799521+00	1627
3326	\N	60.0355893976	17.4536866826	Skuttunge 251	\N	Sotmyra	\N	\N	Ancient monument	1	1	-3326	\N	C	2019-12-20 22:13:53.799521+00	1628
3325	\N	53.4779000000	22.5867440000	\N	\N	Soscnia	\N	\N	Poor	1	1	-3325	\N	C	2019-12-20 22:13:53.799521+00	1629
3324	\N	60.0810828871	17.5993343957	Viksta 211	\N	Sommaränge Skog	\N	\N	Ancient monument	1	1	-3324	\N	C	2019-12-20 22:13:53.799521+00	1630
3323	\N	55.1542980000	14.7541740000	\N	\N	Solheim	\N	\N	Poor	1	1	-3323	\N	C	2019-12-20 22:13:53.799521+00	1631
3322	\N	55.5897104075	12.9414976957	Hyllie 2	\N	Soldattorpet (Limhamn)	\N	\N	Ancient monument	1	1	-3322	\N	C	2019-12-20 22:13:53.799521+00	1632
3321	\N	58.4242057283	15.8771645851	Askeby 11?	\N	Solberga, Linköping	\N	\N	Ancient monument	1	1	-3321	\N	C	2019-12-20 22:13:53.799521+00	1633
3320	\N	56.0588566108	14.4531948768	Ivetofta 300	\N	Sockengränsen	\N	\N	Ancient monument	1	1	-3320	\N	C	2019-12-20 22:13:53.799521+00	1634
3319	\N	56.6390765233	12.9308154089	Snöstorp 106	\N	Snöstorp 106	\N	\N	Ancient monument	1	1	-3319	\N	C	2019-12-20 22:13:53.799521+00	1635
3318	\N	60.1737513200	17.5145672855	Vendel 291	\N	Snåret	\N	\N	Ancient monument	1	1	-3318	\N	C	2019-12-20 22:13:53.799521+00	1636
3317	\N	65.6575714708	18.3230108022	Arvidsjaur 21?	\N	Snotterholmen	\N	\N	Approximate	1	1	-3317	\N	C	2019-12-20 22:13:53.799521+00	1637
3316	\N	59.1566599447	17.8264367691	Grödinge 477	\N	Smällan	\N	\N	Ancient monument	1	1	-3316	\N	C	2019-12-20 22:13:53.799521+00	1638
3315	\N	57.2216104154	18.2375546116	Silte 49	\N	Smissarve	\N	\N	Ancient monument	1	1	-3315	\N	C	2019-12-20 22:13:53.799521+00	1639
3314	\N	60.1068567683	17.1996429863	Harbo 266	\N	Smedsbo	\N	\N	Ancient monument	1	1	-3314	\N	C	2019-12-20 22:13:53.799521+00	1640
3313	\N	66.0717732197	17.9467846379	\N	\N	Smalogava	\N	\N	Approximate	1	1	-3313	\N	C	2019-12-20 22:13:53.799521+00	1641
3312	\N	58.9934970000	9.3348550000	\N	\N	Sluppen/Sluppan	\N	\N	Poor	1	1	-3312	\N	C	2019-12-20 22:13:53.799521+00	1642
3311	\N	59.6588633511	17.1071191049	Vårfrukyrka 552	\N	Skälby	\N	\N	Approximate	1	1	-3311	\N	C	2019-12-20 22:13:53.799521+00	1643
3310	\N	56.3198756727	13.4229256424	Skånes-Fagerhult 125	\N	Skånes-Fagerhult 125	\N	\N	Ancient monument	1	1	-3310	\N	C	2019-12-20 22:13:53.799521+00	1644
3309	\N	59.3765721103	15.3849637001	Glanshammar 194	\N	Skumparberget	\N	\N	Ancient monument	1	1	-3309	\N	C	2019-12-20 22:13:53.799521+00	1645
3308	\N	56.4509794793	12.9534679856	Skummeslöv 26?	\N	Skummeslöv	\N	\N	Approximate	1	1	-3308	\N	C	2019-12-20 22:13:53.799521+00	1646
3307	\N	56.9039003636	12.5733134738	Skrea 106	\N	Skrea 106	\N	\N	Ancient monument	1	1	-3307	\N	C	2019-12-20 22:13:53.799521+00	1647
3306	\N	59.3809616620	15.5486308036	Fellingsbro 633	\N	Skogsmossen	\N	\N	Ancient monument	1	1	-3306	\N	C	2019-12-20 22:13:53.799521+00	1648
3305	\N	56.8530817165	16.7508906514	\N	\N	Skedemosse	\N	\N	Poor	1	1	-3305	\N	C	2019-12-20 22:13:53.799521+00	1649
3304	\N	56.0228937093	14.6077538519	Mjällby 61?	\N	Siretorp	\N	\N	Approximate	1	1	-3304	\N	C	2019-12-20 22:13:53.799521+00	1650
3303	\N	54.2603700000	11.0489750000	\N	\N	Siggeneben	\N	\N	Poor	1	1	-3303	\N	C	2019-12-20 22:13:53.799521+00	1651
3302	\N	57.6396964715	18.2951511080	Visby 107	\N	Schweitzergränd	\N	\N	Ancient monument	1	1	-3302	\N	C	2019-12-20 22:13:53.799521+00	1652
3301	\N	55.8478896616	12.9644832433	Saxtorp 63; Saxtorp 62; Saxtorp 61; Saxtorp 26	\N	Saxtorp (SU 8)	\N	\N	Ancient monument	1	1	-3301	\N	C	2019-12-20 22:13:53.799521+00	1653
3300	\N	57.6417257737	18.2983356792	Visby 107	\N	Santa Maria	\N	\N	Ancient monument	1	1	-3300	\N	C	2019-12-20 22:13:53.799521+00	1654
3299	\N	59.5083499561	17.9559991096	Fresta 147	\N	Sanda	\N	\N	Ancient monument	1	1	-3299	\N	C	2019-12-20 22:13:53.799521+00	1655
3298	\N	62.5532890000	6.0209560000	\N	\N	Rössvik	\N	\N	Approximate	1	1	-3298	\N	C	2019-12-20 22:13:53.799521+00	1656
3297	\N	58.2295448068	13.6062499925	Valtorp 2	\N	Rössberga Megalithic	\N	\N	Ancient monument	1	1	-3297	\N	C	2019-12-20 22:13:53.799521+00	1657
3296	\N	59.3399884260	18.0261870191	Stockholm 194	\N	Rörstrand, Bottna Herrgård	\N	\N	Ancient monument	1	1	-3296	\N	C	2019-12-20 22:13:53.799521+00	1658
3295	\N	59.0799430000	9.7912740000	\N	\N	Rørarød	\N	\N	Poor	1	1	-3295	\N	C	2019-12-20 22:13:53.799521+00	1659
3294	\N	56.1579219050	14.2143290696	Fjälkestad 117	\N	Röetved II	\N	\N	Ancient monument	1	1	-3294	\N	C	2019-12-20 22:13:53.799521+00	1660
3293	\N	59.0830590000	9.8180560000	\N	\N	Rødskjær/Halvarp	\N	\N	Poor	1	1	-3293	\N	C	2019-12-20 22:13:53.799521+00	1661
3292	\N	63.4673198700	16.8554086665	Ådals-Liden 123	\N	Råinget	\N	\N	Ancient monument	1	1	-3292	\N	C	2019-12-20 22:13:53.799521+00	1662
3291	\N	55.8835613054	12.9167576982	Asmundtorp 24	\N	Råga Hörstad	\N	\N	Ancient monument	1	1	-3291	\N	C	2019-12-20 22:13:53.799521+00	1663
3290	\N	58.4764480000	31.2973830000	\N	\N	Ryurik Gorodishche  	\N	\N	Poor	1	1	-3290	\N	C	2019-12-20 22:13:53.799521+00	1664
3289	\N	60.0223094737	17.6252835439	Tensta 435	\N	Ryssgärdet	\N	\N	Ancient monument	1	1	-3289	\N	C	2019-12-20 22:13:53.799521+00	1665
3288	\N	55.9794233169	12.7825512609	Kvistofta 111?	\N	Rya	\N	\N	Approximate	1	1	-3288	\N	C	2019-12-20 22:13:53.799521+00	1666
3287	\N	-19.2656370000	31.8696240000	\N	\N	Rukweza	\N	\N	Ancient monument	1	1	-3287	\N	C	2019-12-20 22:13:53.799521+00	1667
3286	\N	54.2532800000	11.0335680000	\N	\N	Rosenhof 	\N	\N	Poor	1	1	-3286	\N	C	2019-12-20 22:13:53.799521+00	1668
3285	\N	54.2532790000	11.0335670000	\N	\N	Rosenhof	\N	\N	Poor	1	1	-3285	\N	C	2019-12-20 22:13:53.799521+00	1669
3284	\N	59.0904160000	9.8013850000	\N	\N	Rognlien IV/Langangen	\N	\N	Poor	1	1	-3284	\N	C	2019-12-20 22:13:53.799521+00	1670
3283	\N	57.1065632606	18.3180837861	Grötlingbo 54?	\N	Roes	\N	\N	Approximate	1	1	-3283	\N	C	2019-12-20 22:13:53.799521+00	1671
3282	\N	56.0234510000	10.2597090000	\N	\N	Ringkloster	\N	\N	Poor	1	1	-3282	\N	C	2019-12-20 22:13:53.799521+00	1672
3281	\N	58.6315130140	16.1568613192	Kvillinge 6	\N	Ringeby	\N	\N	Ancient monument	1	1	-3281	\N	C	2019-12-20 22:13:53.799521+00	1673
3279	\N	66.0796031652	17.9193991018	Arjeplog 532	\N	Rappasundet	\N	\N	Ancient monument	1	1	-3279	\N	C	2019-12-20 22:13:53.799521+00	1675
3278	\N	56.8542622400	16.7248198551	\N	\N	Ramsättra 	\N	\N	Poor	1	1	-3278	\N	C	2019-12-20 22:13:53.799521+00	1676
3277	\N	55.4089171856	14.1716094028	Löderup 115	\N	Ramshög	\N	\N	Ancient monument	1	1	-3277	\N	C	2019-12-20 22:13:53.799521+00	1677
3276	\N	50.6666670000	6.1166670000	\N	\N	Raeren	\N	\N	Uncertain	1	1	-3276	\N	C	2019-12-20 22:13:53.799521+00	1678
3275	\N	-6.2329480000	-77.8607420000	\N	\N	Puka Rumi	\N	\N	Poor	1	1	-3275	\N	C	2019-12-20 22:13:53.799521+00	1679
3274	\N	60.0288075655	17.5466800928	Björklinge 41	\N	Prästgården	\N	\N	Ancient monument	1	1	-3274	\N	C	2019-12-20 22:13:53.799521+00	1680
3273	\N	58.6053722728	16.1289079804	Östra Eneby 166	\N	Pryssgården	\N	\N	Ancient monument	1	1	-3273	\N	C	2019-12-20 22:13:53.799521+00	1681
3272	\N	52.4063740000	16.9251680000	\N	\N	Poznan Settlement	\N	\N	Poor	1	1	-3272	\N	C	2019-12-20 22:13:53.799521+00	1682
3271	\N	43.1642610000	11.3904280000	\N	\N	Poggio Civitate	\N	\N	Poor	1	1	-3271	\N	C	2019-12-20 22:13:53.799521+00	1683
3270	\N	56.8885366286	16.7732816631	\N	\N	Pinnekulla	\N	\N	Poor	1	1	-3270	\N	C	2019-12-20 22:13:53.799521+00	1684
3269	\N	55.1712360000	14.8111080000	\N	\N	Pileskoven	\N	\N	Poor	1	1	-3269	\N	C	2019-12-20 22:13:53.799521+00	1685
3268	\N	61.1712000000	24.5596000000	\N	\N	Perkiö	\N	\N	Poor	1	1	-3268	\N	C	2019-12-20 22:13:53.799521+00	1686
3267	\N	56.2577790363	16.4154239294	\N	\N	Parboäng	\N	\N	Poor	1	1	-3267	\N	C	2019-12-20 22:13:53.799521+00	1687
3266	\N	61.1292760000	22.1640740000	\N	\N	Pappilanmäki	\N	\N	Poor	1	1	-3266	\N	C	2019-12-20 22:13:53.799521+00	1688
3265	\N	-6.2329480000	-77.8607420000	\N	\N	Papamarka	\N	\N	Poor	1	1	-3265	\N	C	2019-12-20 22:13:53.799521+00	1689
3264	\N	59.9975636047	17.3615351055	Bälinge 259	\N	Oxsätra, Anneberg	\N	\N	Ancient monument	1	1	-3264	\N	C	2019-12-20 22:13:53.799521+00	1690
3263	\N	55.5519036958	13.1003383787	Oxie 40	\N	Oxiegården	\N	\N	Ancient monument	1	1	-3263	\N	C	2019-12-20 22:13:53.799521+00	1691
3262	\N	59.9301440000	20.8810300000	\N	\N	Otterböte	\N	\N	Poor	1	1	-3262	\N	C	2019-12-20 22:13:53.799521+00	1692
3261	\N	56.2312599091	16.4093480592	Ås 40	\N	Ottenby	\N	\N	Ancient monument	1	1	-3261	\N	C	2019-12-20 22:13:53.799521+00	1693
3260	\N	52.0131300000	17.4402510000	\N	\N	Osiek, pow. Jarocin	\N	\N	Poor	1	1	-3260	\N	C	2019-12-20 22:13:53.799521+00	1694
3259	\N	56.6976711797	14.9855975611	Nöbbele 55	\N	Orraryd	\N	\N	Ancient monument	1	1	-3259	\N	C	2019-12-20 22:13:53.799521+00	1695
3258	\N	52.6446840000	16.8106620000	\N	\N	Oborniki, pow. Oborniki	\N	\N	Poor	1	1	-3258	\N	C	2019-12-20 22:13:53.799521+00	1696
3257	\N	55.7375244339	13.1442946794	Norra Nöbbelöv 13	\N	Nöbbelöv	\N	\N	Ancient monument	1	1	-3257	\N	C	2019-12-20 22:13:53.799521+00	1697
3256	\N	60.0189187641	17.5757477535	Björklinge 314	\N	Näsan (Sandbro)	\N	\N	Ancient monument	1	1	-3256	\N	C	2019-12-20 22:13:53.799521+00	1698
3255	\N	55.2033480000	10.4154730000	\N	\N	Nybölle 4	\N	\N	Poor	1	1	-3255	\N	C	2019-12-20 22:13:53.799521+00	1699
3254	\N	56.0234510000	10.2597090000	\N	\N	Norsminde	\N	\N	Poor	1	1	-3254	\N	C	2019-12-20 22:13:53.799521+00	1700
3253	\N	55.8447836057	13.1106107779	Norrvidinge 11?	\N	Norrvidinge	\N	\N	Ancient monument	1	1	-3253	\N	C	2019-12-20 22:13:53.799521+00	1701
3252	\N	59.5823823298	17.9006114213	Norrsunda 167	\N	Norrsunda 167	\N	\N	Ancient monument	1	1	-3252	\N	C	2019-12-20 22:13:53.799521+00	1702
3251	\N	57.1065632606	18.3180837861	Grötlingbo 54	\N	Norrkvie	\N	\N	Ancient monument	1	1	-3251	\N	C	2019-12-20 22:13:53.799521+00	1703
3250	\N	55.7375244339	13.1442946794	Norra Nöbbelöv 13	\N	Norra Nöbbelöv	\N	\N	Ancient monument	1	1	-3250	\N	C	2019-12-20 22:13:53.799521+00	1704
3249	\N	69.1660090000	29.2422220000	\N	\N	Noatun Neset	\N	\N	Approximate	1	1	-3249	\N	C	2019-12-20 22:13:53.799521+00	1705
3248	\N	66.4620000000	25.5977000000	\N	\N	Niskanperä	\N	\N	Poor	1	1	-3248	\N	C	2019-12-20 22:13:53.799521+00	1706
3247	\N	59.6483203386	16.9979235775	Tillinge 335	\N	Nibble	\N	\N	Ancient monument	1	1	-3247	\N	C	2019-12-20 22:13:53.799521+00	1707
3246	\N	-22.8459380000	35.1787770000	\N	\N	Nhacheque	\N	\N	Poor	1	1	-3246	\N	C	2019-12-20 22:13:53.799521+00	1708
3245	\N	54.7885100000	9.4292010000	\N	\N	Neukirchen-Bostholm	\N	\N	Poor	1	1	-3245	\N	C	2019-12-20 22:13:53.799521+00	1709
3244	\N	65.9296806316	22.8561489804	Töre 510	\N	Mötesstation Kosjärv	\N	\N	Ancient monument	1	1	-3244	\N	C	2019-12-20 22:13:53.799521+00	1710
3243	\N	56.6181953073	16.1539430666	Ljungby 336?	\N	Mören	\N	\N	Ancient monument	1	1	-3243	\N	C	2019-12-20 22:13:53.799521+00	1711
3242	\N	55.1526990000	10.7372390000	\N	\N	Møllegårdsmarken	\N	\N	Poor	1	1	-3242	\N	C	2019-12-20 22:13:53.799521+00	1712
3241	\N	56.5179494219	16.4406957949	Resmo 85	\N	Mysinge	\N	\N	Ancient monument	1	1	-3241	\N	C	2019-12-20 22:13:53.799521+00	1713
3240	\N	-6.8695360000	38.9377160000	\N	\N	Mpiji	\N	\N	Poor	1	1	-3240	\N	C	2019-12-20 22:13:53.799521+00	1714
3239	\N	63.2465951671	18.4410039506	Nätra 54	\N	Mjäla	\N	\N	Ancient monument	1	1	-3239	\N	C	2019-12-20 22:13:53.799521+00	1715
3238	\N	-7.3860870000	39.3144080000	\N	\N	Misasa	\N	\N	Poor	1	1	-3238	\N	C	2019-12-20 22:13:53.799521+00	1716
3237	\N	59.0333818016	17.9577919364	Ösmo 663	\N	Millingsmossen 1	\N	\N	Ancient monument	1	1	-3237	\N	C	2019-12-20 22:13:53.799521+00	1717
3236	\N	-25.9666670000	32.4666670000	\N	\N	Matola	\N	\N	Poor	1	1	-3236	\N	C	2019-12-20 22:13:53.799521+00	1718
3235	\N	-6.3562210000	38.4675450000	\N	\N	Masuguru	\N	\N	Poor	1	1	-3235	\N	C	2019-12-20 22:13:53.799521+00	1719
3234	\N	59.2443247603	17.8848770494	Huddinge 132?	\N	Masmo	\N	\N	Approximate	1	1	-3234	\N	C	2019-12-20 22:13:53.799521+00	1720
3233	\N	59.2465599320	15.2813768936	\N	\N	Mark	\N	\N	Poor	1	1	-3233	\N	C	2019-12-20 22:13:53.799521+00	1721
3232	\N	59.3252914013	18.0170898365	Stockholm 200	\N	Marieberg (Heby herrgård, Uppland)	\N	\N	Ancient monument	1	1	-3232	\N	C	2019-12-20 22:13:53.799521+00	1722
3231	\N	-22.1606190000	34.8606750000	\N	\N	Manyikeni	\N	\N	Poor	1	1	-3231	\N	C	2019-12-20 22:13:53.799521+00	1723
3230	\N	57.5935408406	18.5133963927	Ekeby 25	\N	Mangsarve	\N	\N	Ancient monument	1	1	-3230	\N	C	2019-12-20 22:13:53.799521+00	1724
3229	\N	55.5926550673	13.1244449390	Malmö 32	\N	Malmö 32	\N	\N	Ancient monument	1	1	-3229	\N	C	2019-12-20 22:13:53.799521+00	1725
3228	\N	59.1352959095	16.7303463557	Lilla Malma 49	\N	Malmahed	\N	\N	Ancient monument	1	1	-3228	\N	C	2019-12-20 22:13:53.799521+00	1726
3227	\N	64.6696322169	16.5107649579	Vilhelmina 268; Vilhelmina 525	\N	Maksjön	\N	\N	Approximate	1	1	-3227	\N	C	2019-12-20 22:13:53.799521+00	1727
3226	\N	59.8998399562	17.6530552591	Uppsala 531	\N	Lövstaholm	\N	\N	Ancient monument	1	1	-3226	\N	C	2019-12-20 22:13:53.799521+00	1728
3225	\N	55.1535630000	10.6811660000	\N	\N	Løkkebjerggård	\N	\N	Poor	1	1	-3225	\N	C	2019-12-20 22:13:53.799521+00	1729
3224	\N	55.4138962228	14.1905081365	Löderup 36?	\N	Löderup 36	\N	\N	Ancient monument	1	1	-3224	\N	C	2019-12-20 22:13:53.799521+00	1730
3223	\N	55.4117618327	14.1870925819	Löderup 3	\N	Löderup 3	\N	\N	Ancient monument	1	1	-3223	\N	C	2019-12-20 22:13:53.799521+00	1731
3222	\N	55.4130825453	14.1539255304	Löderup 27	\N	Löderup 27	\N	\N	Ancient monument	1	1	-3222	\N	C	2019-12-20 22:13:53.799521+00	1732
3221	\N	55.4070184609	14.1886429640	Löderup 21	\N	Löderup 21	\N	\N	Ancient monument	1	1	-3221	\N	C	2019-12-20 22:13:53.799521+00	1733
3220	\N	55.3947333561	14.1385603467	Löderup 103	\N	Löderup 103	\N	\N	Ancient monument	1	1	-3220	\N	C	2019-12-20 22:13:53.799521+00	1734
3219	\N	55.3942660175	14.1196242840	Löderup 5	\N	Löderup	\N	\N	Ancient monument	1	1	-3219	\N	C	2019-12-20 22:13:53.799521+00	1735
3218	\N	55.7327738858	12.9760863039	Löddeköpinge 8	\N	Löddesborg	\N	\N	Ancient monument	1	1	-3218	\N	C	2019-12-20 22:13:53.799521+00	1736
3217	\N	55.7597030669	13.0181722363	Löddeköpinge 69?	\N	Löddeköpinge	\N	\N	Poor	1	1	-3217	\N	C	2019-12-20 22:13:53.799521+00	1737
3216	\N	56.7500769524	12.7559140758	Harplinge 44	\N	Lyngåkra	\N	\N	Ancient monument	1	1	-3216	\N	C	2019-12-20 22:13:53.799521+00	1738
3215	\N	55.7821241478	12.9366720960	Barsebäck 14?	\N	Lundåkra	\N	\N	Poor	1	1	-3215	\N	C	2019-12-20 22:13:53.799521+00	1739
3214	\N	57.7831319901	14.1610560072	Jönköping 50	\N	Lundströms plats	\N	\N	Block	1	1	-3214	\N	C	2019-12-20 22:13:53.799521+00	1740
3213	\N	55.2033480000	10.4154730000	\N	\N	Lundehöj 26	\N	\N	Poor	1	1	-3213	\N	C	2019-12-20 22:13:53.799521+00	1741
3212	\N	55.1429420000	10.7822830000	\N	\N	Lundeborg II	\N	\N	Poor	1	1	-3212	\N	C	2019-12-20 22:13:53.799521+00	1742
3211	\N	55.1429420000	10.7822830000	\N	\N	Lundeborg I	\N	\N	Poor	1	1	-3211	\N	C	2019-12-20 22:13:53.799521+00	1743
3210	\N	59.3686002744	16.9530090902	Strängnäs 266	\N	Lunda omr. B	\N	\N	Ancient monument	1	1	-3210	\N	C	2019-12-20 22:13:53.799521+00	1744
3209	\N	55.5474961774	13.0123000965	Glostorp 66	\N	Lockarp 7A	\N	\N	Ancient monument	1	1	-3209	\N	C	2019-12-20 22:13:53.799521+00	1745
3208	\N	55.5418603382	13.0446497559	Lockarp 24	\N	Lockarp	\N	\N	Ancient monument	1	1	-3208	\N	C	2019-12-20 22:13:53.799521+00	1746
3207	\N	59.6398208741	17.2434797452	Litslena 561	\N	Litslena 561	\N	\N	Ancient monument	1	1	-3207	\N	C	2019-12-20 22:13:53.799521+00	1747
3206	\N	59.0284210617	17.9522932006	\N	\N	Lisseläng	\N	\N	Ancient monument	1	1	-3206	\N	C	2019-12-20 22:13:53.799521+00	1748
3205	\N	58.3974262500	15.6360396796	Linköping 188	\N	Linköping 188	\N	\N	Ancient monument	1	1	-3205	\N	C	2019-12-20 22:13:53.799521+00	1749
3204	\N	59.0665236311	17.5850182827	Överjärna 213; Överjärna 127	\N	Linga	\N	\N	Ancient monument	1	1	-3204	\N	C	2019-12-20 22:13:53.799521+00	1750
3203	\N	56.3829210993	12.7874546022	Grevie 362	\N	Lindab området	\N	\N	Ancient monument	1	1	-3203	\N	C	2019-12-20 22:13:53.799521+00	1751
3202	\N	55.0480400000	14.9103250000	\N	\N	Limensgård	\N	\N	Poor	1	1	-3202	\N	C	2019-12-20 22:13:53.799521+00	1752
3201	\N	-6.9096370000	39.0736800000	\N	\N	Limbo	\N	\N	Poor	1	1	-3201	\N	C	2019-12-20 22:13:53.799521+00	1753
3200	\N	59.2474249776	15.0600284814	Vintrosa 97	\N	Lilla Ulvgryt	\N	\N	Ancient monument	1	1	-3200	\N	C	2019-12-20 22:13:53.799521+00	1754
3199	\N	55.4317889627	13.7827217761	Hedeskoga 8	\N	Lilla Tvären	\N	\N	Ancient monument	1	1	-3199	\N	C	2019-12-20 22:13:53.799521+00	1755
3198	\N	55.3813999067	13.4456315785	Lilla Beddinge 1?	\N	Lilla Beddinge	\N	\N	Approximate	1	1	-3198	\N	C	2019-12-20 22:13:53.799521+00	1756
3197	\N	57.9346164533	13.4986479410	\N	\N	Liden under Storegården	\N	\N	Poor	1	1	-3197	\N	C	2019-12-20 22:13:53.799521+00	1757
3196	\N	57.7449302480	12.1316691989	Partille 24	\N	Lexby	\N	\N	Ancient monument	1	1	-3196	\N	C	2019-12-20 22:13:53.799521+00	1758
3195	\N	63.9159767382	16.2725933747	Bodum 104	\N	Lesjön	\N	\N	Poor	1	1	-3195	\N	C	2019-12-20 22:13:53.799521+00	1759
3194	\N	59.0764370000	9.7256380000	\N	\N	Lerstang	\N	\N	Approximate	1	1	-3194	\N	C	2019-12-20 22:13:53.799521+00	1760
3193	\N	59.3686114824	13.1111734847	Grums 20	\N	Leonardsberg	\N	\N	Ancient monument	1	1	-3193	\N	C	2019-12-20 22:13:53.799521+00	1761
3192	\N	65.3272155404	19.9479071528	Jörn 67	\N	Lappviken	\N	\N	Poor	1	1	-3192	\N	C	2019-12-20 22:13:53.799521+00	1762
3191	\N	64.6946607846	16.3930220382	Vilhelmina 29	\N	Lappvallen	\N	\N	Ancient monument	1	1	-3191	\N	C	2019-12-20 22:13:53.799521+00	1763
3190	\N	18.1586840000	102.8579580000	\N	\N	Lao Pako	\N	\N	Ancient monument	1	1	-3190	\N	C	2019-12-20 22:13:53.799521+00	1764
3189	\N	50.8934330000	6.2858180000	\N	\N	Langweiler 9	\N	\N	Poor	1	1	-3189	\N	C	2019-12-20 22:13:53.799521+00	1765
3188	\N	50.5766470000	4.0047760000	\N	\N	La Gue du Plantin	\N	\N	Poor	1	1	-3188	\N	C	2019-12-20 22:13:53.799521+00	1766
3187	\N	56.8808595397	16.7247647751	Köping 115	\N	Köpingsvik	\N	\N	Ancient monument	1	1	-3187	\N	C	2019-12-20 22:13:53.799521+00	1767
3186	\N	50.9380870000	6.9535980000	\N	\N	Köln	\N	\N	Poor	1	1	-3186	\N	C	2019-12-20 22:13:53.799521+00	1768
3185	\N	59.9619324400	17.6484353865	Ärentuna 56	\N	Kättsta	\N	\N	Ancient monument	1	1	-3185	\N	C	2019-12-20 22:13:53.799521+00	1769
3184	\N	56.7265579000	12.9178706946	Övraby 18	\N	Kärringsjön	\N	\N	Ancient monument	1	1	-3184	\N	C	2019-12-20 22:13:53.799521+00	1770
3183	\N	56.8754976437	16.7587486261	\N	\N	Källingemöre	\N	\N	Poor	1	1	-3183	\N	C	2019-12-20 22:13:53.799521+00	1771
3182	\N	59.9800875000	17.6409047348	Ärentuna 329; Ärentuna 328; Ärentuna 327	\N	Kyrsta	\N	\N	Approximate	1	1	-3182	\N	C	2019-12-20 22:13:53.799521+00	1772
3181	\N	55.6461066450	13.2715920476	Kyrkheddinge 6	\N	Kyrkheddinge	\N	\N	Ancient monument	1	1	-3181	\N	C	2019-12-20 22:13:53.799521+00	1773
3180	\N	58.4700491904	13.4782148146	Ledsjö 150	\N	Kyrkebo	\N	\N	Ancient monument	1	1	-3180	\N	C	2019-12-20 22:13:53.799521+00	1774
3179	\N	56.3166820098	16.4928983618	\N	\N	Kvinnsgröta	\N	\N	Approximate	1	1	-3179	\N	C	2019-12-20 22:13:53.799521+00	1775
3178	\N	57.6141820854	18.4609649831	\N	\N	Kvie	\N	\N	Poor	1	1	-3178	\N	C	2019-12-20 22:13:53.799521+00	1776
3177	\N	59.1426078909	17.6288234942	Tveta 45	\N	Kvedesta	\N	\N	Ancient monument	1	1	-3177	\N	C	2019-12-20 22:13:53.799521+00	1777
3176	\N	58.4415750789	14.9140626991	Vadstena 38	\N	Kvarnbacken/kv. Cisternen/Galgegärdsbacken	\N	\N	Ancient monument	1	1	-3176	\N	C	2019-12-20 22:13:53.799521+00	1778
3175	\N	59.6156751672	17.7196034236	Sigtuna 195	\N	kv. Trädgårdsmästaren	\N	\N	Ancient monument	1	1	-3175	\N	C	2019-12-20 22:13:53.799521+00	1779
3174	\N	57.6423694195	18.2943374631	Visby 107	\N	kv. Specksrum	\N	\N	Ancient monument	1	1	-3174	\N	C	2019-12-20 22:13:53.799521+00	1780
3173	\N	59.6089872248	16.5386155114	Västerås  232	\N	Kv. Kleopatra	\N	\N	Block	1	1	-3173	\N	C	2019-12-20 22:13:53.799521+00	1781
3172	\N	56.6748450000	12.8579450000	Halmstad 44	\N	Kv. Hjärtat	\N	\N	Ancient monument	1	1	-3172	\N	C	2019-12-20 22:13:53.799521+00	1782
3171	\N	57.7817481867	14.1609872027	Jönköping 50	\N	kv. Hemmet	\N	\N	Poor	1	1	-3171	\N	C	2019-12-20 22:13:53.799521+00	1783
3170	\N	56.6857290515	16.3359655674	Kalmar 117	\N	kv. Havren, Djurängen	\N	\N	Ancient monument	1	1	-3170	\N	C	2019-12-20 22:13:53.799521+00	1784
3169	\N	57.7817481867	14.1609872027	Jönköping 50	\N	kv. Gladan	\N	\N	Poor	1	1	-3169	\N	C	2019-12-20 22:13:53.799521+00	1785
3168	\N	57.7814057077	14.1635344017	Jönköping 50	\N	kv. Galeasen	\N	\N	Block	1	1	-3168	\N	C	2019-12-20 22:13:53.799521+00	1786
3167	\N	57.7877361900	14.2645885962	Hakarp 98	\N	kv. Elektronen	\N	\N	Ancient monument	1	1	-3167	\N	C	2019-12-20 22:13:53.799521+00	1787
3166	\N	57.7803345692	14.1824768820	Jönköping 50	\N	kv. Dromedaren	\N	\N	Ancient monument	1	1	-3166	\N	C	2019-12-20 22:13:53.799521+00	1788
3165	\N	57.7801326029	14.1776385425	Jönköping 50	\N	kv. Diplomaten	\N	\N	Block	1	1	-3165	\N	C	2019-12-20 22:13:53.799521+00	1789
3164	\N	55.5650588849	13.0425139125	Malmö 34	\N	kv. Bronsyxan	\N	\N	Ancient monument	1	1	-3164	\N	C	2019-12-20 22:13:53.799521+00	1790
3163	\N	57.7809344937	14.1766281681	Jönköping 50	\N	kv. Apeln	\N	\N	Poor	1	1	-3163	\N	C	2019-12-20 22:13:53.799521+00	1791
3162	\N	59.6156751672	17.7196034236	Sigtuna 195	\N	kv Trädgårdsmästaren	\N	\N	Ancient monument	1	1	-3162	\N	C	2019-12-20 22:13:53.799521+00	1792
3161	\N	55.9129932095	14.2711883377	Åhus 35	\N	kv Transval	\N	\N	Block	1	1	-3161	\N	C	2019-12-20 22:13:53.799521+00	1793
3160	\N	55.4266962053	13.7929601820	Ystad 6	\N	kv Tankbåten	\N	\N	Ancient monument	1	1	-3160	\N	C	2019-12-20 22:13:53.799521+00	1794
3159	\N	55.3760342637	13.1488201091	Trelleborg 19	\N	kv Kråkvinkeln	\N	\N	Ancient monument	1	1	-3159	\N	C	2019-12-20 22:13:53.799521+00	1795
3158	\N	55.3756295960	13.1458401693	Trelleborg 19	\N	kv Katten	\N	\N	Ancient monument	1	1	-3158	\N	C	2019-12-20 22:13:53.799521+00	1796
3157	\N	55.5551992037	13.0234541473	Fosie 57	\N	kv Kastanjegården	\N	\N	Ancient monument	1	1	-3157	\N	C	2019-12-20 22:13:53.799521+00	1797
3156	\N	55.3769870556	13.1464553701	Trelleborg 19	\N	kv Gröningen	\N	\N	Ancient monument	1	1	-3156	\N	C	2019-12-20 22:13:53.799521+00	1798
3155	\N	55.7035727385	13.1919791291	Lund 73	\N	kv Apotekaren	\N	\N	Ancient monument	1	1	-3155	\N	C	2019-12-20 22:13:53.799521+00	1799
3154	\N	59.4012816920	17.4989016198	\N	\N	Kunsta	\N	\N	Approximate	1	1	-3154	\N	C	2019-12-20 22:13:53.799521+00	1800
3153	\N	62.4055928970	17.2053946237	Selånger 87	\N	Kungsnäs	\N	\N	Ancient monument	1	1	-3153	\N	C	2019-12-20 22:13:53.799521+00	1801
3152	\N	58.5006165622	15.5356922244	Vreta Kloster 197?	\N	Kungsbro Motorcykel	\N	\N	Poor	1	1	-3152	\N	C	2019-12-20 22:13:53.799521+00	1802
3151	\N	56.0607212216	14.4583396069	Ivetofta 301	\N	Kråkeslätt	\N	\N	Ancient monument	1	1	-3151	\N	C	2019-12-20 22:13:53.799521+00	1803
3150	\N	55.5363945567	13.0849531327	\N	\N	Kristineberg (Oxie 15:1)	\N	\N	Poor	1	1	-3150	\N	C	2019-12-20 22:13:53.799521+00	1804
3149	\N	58.1504880000	7.9965400000	\N	\N	Kristiansand 	\N	\N	Poor	1	1	-3149	\N	C	2019-12-20 22:13:53.799521+00	1805
3148	\N	58.3997851642	15.0912249017	Skänninge 35; Skänninge 33	\N	Kriminalvårdsanstalten	\N	\N	Approximate	1	1	-3148	\N	C	2019-12-20 22:13:53.799521+00	1806
3147	\N	56.1946730000	9.4094600000	\N	\N	Kragelund	\N	\N	Poor	1	1	-3147	\N	C	2019-12-20 22:13:53.799521+00	1807
3146	\N	55.4617788533	13.1923840822	Lilla Slågarp 62	\N	Klörup-Aggarp	\N	\N	Ancient monument	1	1	-3146	\N	C	2019-12-20 22:13:53.799521+00	1808
3145	\N	59.3834313343	16.6724113310	Kjula 11	\N	Kjulaås	\N	\N	Ancient monument	1	1	-3145	\N	C	2019-12-20 22:13:53.799521+00	1809
3144	\N	60.5942950000	22.0841020000	\N	\N	Kivisillanmäki	\N	\N	Poor	1	1	-3144	\N	C	2019-12-20 22:13:53.799521+00	1810
3143	\N	-6.3665410000	38.5836310000	\N	\N	Kiwangwa	\N	\N	Poor	1	1	-3143	\N	C	2019-12-20 22:13:53.799521+00	1811
3142	\N	56.3845898779	12.7498551494	Grevie 360	\N	Killebäckstorp	\N	\N	Ancient monument	1	1	-3142	\N	C	2019-12-20 22:13:53.799521+00	1812
3141	\N	51.4456980000	6.0062380000	\N	\N	Kesseleyk	\N	\N	Poor	1	1	-3141	\N	C	2019-12-20 22:13:53.799521+00	1813
3140	\N	60.5886580000	22.3814830000	\N	\N	Kerola	\N	\N	Poor	1	1	-3140	\N	C	2019-12-20 22:13:53.799521+00	1814
3139	\N	57.6404316318	18.2955697837	Visby 57	\N	Katarina	\N	\N	Ancient monument	1	1	-3139	\N	C	2019-12-20 22:13:53.799521+00	1815
3138	\N	60.2328900000	20.0811830000	\N	\N	Kastelholm	\N	\N	Poor	1	1	-3138	\N	C	2019-12-20 22:13:53.799521+00	1816
3137	\N	59.5894210000	9.1774180000	\N	\N	Kasin/Ørvik	\N	\N	Poor	1	1	-3137	\N	C	2019-12-20 22:13:53.799521+00	1817
3136	\N	56.1608685358	15.5847708121	Karlskrona 77	\N	Karlskrona	\N	\N	Ancient monument	1	1	-3136	\N	C	2019-12-20 22:13:53.799521+00	1818
3135	\N	55.4847331698	13.9070741296	Stora Herrestad 33	\N	Karlsfält	\N	\N	Ancient monument	1	1	-3135	\N	C	2019-12-20 22:13:53.799521+00	1819
3134	\N	58.1528563033	13.6377627944	Karleby 55, 57 eller 59	\N	Karleby 57	\N	\N	Poor	1	1	-3134	\N	C	2019-12-20 22:13:53.799521+00	1820
3133	\N	-6.4626600000	38.9472670000	\N	\N	Kaole	\N	\N	Poor	1	1	-3133	\N	C	2019-12-20 22:13:53.799521+00	1821
3132	\N	60.8796480000	21.6945150000	\N	\N	Kansakoulunmäki	\N	\N	Poor	1	1	-3132	\N	C	2019-12-20 22:13:53.799521+00	1822
3131	\N	52.0577810000	20.9818740000	\N	\N	Kamionce-Nadbuznej	\N	\N	Poor	1	1	-3131	\N	C	2019-12-20 22:13:53.799521+00	1823
3130	\N	56.6592918435	16.3562389968	\N	\N	Kalmar slottsfjärd	\N	\N	Poor	1	1	-3130	\N	C	2019-12-20 22:13:53.799521+00	1824
3129	\N	55.5348436416	14.2804949899	Järrestad 45	\N	Järrestad SU2	\N	\N	Ancient monument	1	1	-3129	\N	C	2019-12-20 22:13:53.799521+00	1825
3128	\N	55.5353450009	14.2756056403	Järrestad 44	\N	Järrestad SU1	\N	\N	Ancient monument	1	1	-3128	\N	C	2019-12-20 22:13:53.799521+00	1826
3127	\N	55.5386383556	14.2927224111	\N	\N	Järrestad	\N	\N	Approximate	1	1	-3127	\N	C	2019-12-20 22:13:53.799521+00	1827
3126	\N	58.7565262035	16.7188454998	Lunda 108	\N	Jäder	\N	\N	Ancient monument	1	1	-3126	\N	C	2019-12-20 22:13:53.799521+00	1828
3125	\N	60.6031900000	26.9313860000	\N	\N	Juurikorpi	\N	\N	Poor	1	1	-3125	\N	C	2019-12-20 22:13:53.799521+00	1829
3124	\N	54.2568310000	18.6026440000	\N	\N	Juszkowo, pow. Pruszcz	\N	\N	Poor	1	1	-3124	\N	C	2019-12-20 22:13:53.799521+00	1830
3123	\N	56.0885117271	14.4645066099	Ivetofta 5?	\N	Ivetofta	\N	\N	Ancient monument	1	1	-3123	\N	C	2019-12-20 22:13:53.799521+00	1831
3122	\N	57.8345976669	18.6031426781	Hangvar 3	\N	Ire	\N	\N	Ancient monument	1	1	-3122	\N	C	2019-12-20 22:13:53.799521+00	1832
3121	\N	55.4209398021	14.0285645566	Ingelstorp 15	\N	Ingelstorp: Granhill	\N	\N	Ancient monument	1	1	-3121	\N	C	2019-12-20 22:13:53.799521+00	1833
3120	\N	55.4191368397	14.0369346669	Ingelstorp 1	\N	Ingelstorp: Cemetery 4	\N	\N	Ancient monument	1	1	-3120	\N	C	2019-12-20 22:13:53.799521+00	1834
3119	\N	55.4310318281	14.0423027173	Ingelstorp 7	\N	Ingelstorp: Cemetery 2	\N	\N	Ancient monument	1	1	-3119	\N	C	2019-12-20 22:13:53.799521+00	1835
3118	\N	55.4302139533	14.0468895814	Ingelstorp 8	\N	Ingelstorp 8	\N	\N	Ancient monument	1	1	-3118	\N	C	2019-12-20 22:13:53.799521+00	1836
3117	\N	55.4162743064	14.0351718095	Ingelstorp 14	\N	Ingelstorp 14	\N	\N	Ancient monument	1	1	-3117	\N	C	2019-12-20 22:13:53.799521+00	1837
3116	\N	55.4944327562	13.0775391121	Södra Åkarp 14	\N	Hötofta	\N	\N	Ancient monument	1	1	-3116	\N	C	2019-12-20 22:13:53.799521+00	1838
3115	\N	62.4011949944	17.2584923185	Selånger 1	\N	Högom	\N	\N	Ancient monument	1	1	-3115	\N	C	2019-12-20 22:13:53.799521+00	1839
3114	\N	59.3751155269	11.9281022166	Holmedal 197	\N	Hästholmen	\N	\N	Ancient monument	1	1	-3114	\N	C	2019-12-20 22:13:53.799521+00	1840
3113	\N	59.6556606765	17.2808209765	Litslena 237	\N	Hällby	\N	\N	Ancient monument	1	1	-3113	\N	C	2019-12-20 22:13:53.799521+00	1841
3112	\N	59.8373397267	17.5824619728	Uppsala 364	\N	Håga	\N	\N	Ancient monument	1	1	-3112	\N	C	2019-12-20 22:13:53.799521+00	1842
3111	\N	55.5652013575	12.9733263438	Hyllie 149	\N	Hyllie 149	\N	\N	Ancient monument	1	1	-3111	\N	C	2019-12-20 22:13:53.799521+00	1843
3110	\N	55.5675574832	12.9843075888	Malmö 106	\N	Hyllie 106	\N	\N	Ancient monument	1	1	-3110	\N	C	2019-12-20 22:13:53.799521+00	1844
3109	\N	59.4347995045	16.5561069216	Vallby 36	\N	Hyggby	\N	\N	Ancient monument	1	1	-3109	\N	C	2019-12-20 22:13:53.799521+00	1845
3108	\N	59.4237707482	16.9337467270	Vansö 59	\N	Husby, Ingjaldshögen	\N	\N	Ancient monument	1	1	-3108	\N	C	2019-12-20 22:13:53.799521+00	1846
3107	\N	59.3067302610	15.3765346176	Glanshammar 220; Glanshammar 219; Glanshammar 218; Glanshammar 33	\N	Husby	\N	\N	Ancient monument	1	1	-3107	\N	C	2019-12-20 22:13:53.799521+00	1847
3106	\N	56.0336937531	14.2638923860	Fjälkinge 76	\N	Hunneberget	\N	\N	Ancient monument	1	1	-3106	\N	C	2019-12-20 22:13:53.799521+00	1848
3105	\N	56.7200399504	12.9193096558	Enslöv 40	\N	Hune hall/Arlösa	\N	\N	Ancient monument	1	1	-3105	\N	C	2019-12-20 22:13:53.799521+00	1849
3104	\N	-6.2329480000	-77.8607420000	\N	\N	Huepon	\N	\N	Poor	1	1	-3104	\N	C	2019-12-20 22:13:53.799521+00	1850
3103	\N	59.6596582175	16.6149701020	Hubbo 147	\N	Hubbo	\N	\N	Ancient monument	1	1	-3103	\N	C	2019-12-20 22:13:53.799521+00	1851
3102	\N	-21.1574050000	33.9193020000	\N	\N	Hola-Hola	\N	\N	Poor	1	1	-3102	\N	C	2019-12-20 22:13:53.799521+00	1852
3101	\N	59.3368677640	15.1143608104	Eker 43	\N	Hjulberga 2	\N	\N	Ancient monument	1	1	-3101	\N	C	2019-12-20 22:13:53.799521+00	1853
3100	\N	59.3407215532	15.1128794848	Eker 1	\N	Hjulberga 1	\N	\N	Ancient monument	1	1	-3100	\N	C	2019-12-20 22:13:53.799521+00	1854
3099	\N	55.3749410000	12.2118560000	\N	\N	Himlingöje	\N	\N	Ancient monument	1	1	-3099	\N	C	2019-12-20 22:13:53.799521+00	1855
3098	\N	56.0232020000	12.1966410000	\N	\N	Helsinge	\N	\N	Poor	1	1	-3098	\N	C	2019-12-20 22:13:53.799521+00	1856
3097	\N	56.8197860000	9.9560330000	\N	\N	Hellum	\N	\N	Poor	1	1	-3097	\N	C	2019-12-20 22:13:53.799521+00	1857
3096	\N	57.9722469100	16.6431397144	\N	\N	Hellerö	\N	\N	Poor	1	1	-3096	\N	C	2019-12-20 22:13:53.799521+00	1858
3095	\N	59.2751215250	17.7048666706	Ekerö 119	\N	Helgö	\N	\N	Ancient monument	1	1	-3095	\N	C	2019-12-20 22:13:53.799521+00	1859
3094	\N	59.3280421196	18.0693505287	Stockholm 51	\N	Helgeandsholmen	\N	\N	Ancient monument	1	1	-3094	\N	C	2019-12-20 22:13:53.799521+00	1860
3093	\N	54.4918370000	9.5665460000	\N	\N	Hedeby	\N	\N	Poor	1	1	-3093	\N	C	2019-12-20 22:13:53.799521+00	1861
3092	\N	57.2162639536	18.3183396651	Hablingbo 32	\N	Havor Fort	\N	\N	Ancient monument	1	1	-3092	\N	C	2019-12-20 22:13:53.799521+00	1862
3091	\N	57.2156940511	18.2994724079	\N	\N	Havor Cemetery	\N	\N	Ancient monument	1	1	-3091	\N	C	2019-12-20 22:13:53.799521+00	1863
3090	\N	58.4278306536	13.2814309958	Hasslösa 8	\N	Hasslösa	\N	\N	Ancient monument	1	1	-3090	\N	C	2019-12-20 22:13:53.799521+00	1864
3089	\N	56.7180388840	12.7138599486	Harplinge 155	\N	Harplinge 155	\N	\N	Ancient monument	1	1	-3089	\N	C	2019-12-20 22:13:53.799521+00	1865
3088	\N	56.7137605358	12.7128449500	Harplinge 151	\N	Harplinge 151	\N	\N	Ancient monument	1	1	-3088	\N	C	2019-12-20 22:13:53.799521+00	1866
3087	\N	52.3803580000	4.6347460000	\N	\N	Harlem	\N	\N	Parish	1	1	-3087	\N	C	2019-12-20 22:13:53.799521+00	1867
3086	\N	59.5939573995	16.6092138172	Västerås 576	\N	Hamre	\N	\N	Ancient monument	1	1	-3086	\N	C	2019-12-20 22:13:53.799521+00	1868
3085	\N	57.7831578373	14.1663359689	Jönköping 50	\N	Hamnparken	\N	\N	Block	1	1	-3085	\N	C	2019-12-20 22:13:53.799521+00	1869
3084	\N	59.2536012527	17.8191650650	Botkyrka 69; Botkyrka 13	\N	Hallunda	\N	\N	Ancient monument	1	1	-3084	\N	C	2019-12-20 22:13:53.799521+00	1870
3083	\N	58.1523155571	13.4341113096	Gökhem 78	\N	Gökhem 78	\N	\N	Ancient monument	1	1	-3083	\N	C	2019-12-20 22:13:53.799521+00	1871
3082	\N	58.1592522693	13.4556125670	Gökhem 71	\N	Gökhem 71	\N	\N	Ancient monument	1	1	-3082	\N	C	2019-12-20 22:13:53.799521+00	1872
3081	\N	60.0496770632	17.6677705788	Tensta 50	\N	Gödåker	\N	\N	Ancient monument	1	1	-3081	\N	C	2019-12-20 22:13:53.799521+00	1873
3080	\N	55.1514180000	10.7076180000	\N	\N	Gudme great hall	\N	\N	Poor	1	1	-3080	\N	C	2019-12-20 22:13:53.799521+00	1874
3079	\N	55.1514180000	10.7076180000	\N	\N	Gudme	\N	\N	Poor	1	1	-3079	\N	C	2019-12-20 22:13:53.799521+00	1875
3078	\N	56.0423536211	14.4660770572	Gualöv  24	\N	Gualöv 24	\N	\N	Ancient monument	1	1	-3078	\N	C	2019-12-20 22:13:53.799521+00	1876
3077	\N	56.0475548946	14.4335923819	Gualöv 45	\N	Gualöv	\N	\N	Ancient monument	1	1	-3077	\N	C	2019-12-20 22:13:53.799521+00	1877
3076	\N	57.4421685362	18.3396382261	Väte 35?	\N	Gräne	\N	\N	Ancient monument	1	1	-3076	\N	C	2019-12-20 22:13:53.799521+00	1878
3075	\N	61.2667390000	11.5758140000	\N	\N	Gråfjell lokal Jfp. 	\N	\N	Approximate	1	1	-3075	\N	C	2019-12-20 22:13:53.799521+00	1879
3074	\N	55.1443700000	10.6938590000	\N	\N	Gryagervej	\N	\N	Poor	1	1	-3074	\N	C	2019-12-20 22:13:53.799521+00	1880
3073	\N	64.4425490705	21.6071325685	Lövånger 78	\N	Grundskatan	\N	\N	Ancient monument	1	1	-3073	\N	C	2019-12-20 22:13:53.799521+00	1881
3072	\N	53.9616340000	11.4849350000	\N	\N	Gross Strömkendorf (Reric)	\N	\N	Approximate	1	1	-3072	\N	C	2019-12-20 22:13:53.799521+00	1882
3071	\N	56.5327420000	21.1718680000	\N	\N	Grobin	\N	\N	Poor	1	1	-3071	\N	C	2019-12-20 22:13:53.799521+00	1883
3070	\N	57.1141181826	12.4294954263	Grimeton 139	\N	Grimeton k:a	\N	\N	Ancient monument	1	1	-3070	\N	C	2019-12-20 22:13:53.799521+00	1884
3069	\N	56.3699296725	12.8068788244	Grevie 365	\N	Grevie 365	\N	\N	Ancient monument	1	1	-3069	\N	C	2019-12-20 22:13:53.799521+00	1885
3068	\N	56.3632478676	12.7990216084	Grevie 363	\N	Grevie 363	\N	\N	Ancient monument	1	1	-3068	\N	C	2019-12-20 22:13:53.799521+00	1886
3067	\N	58.3435357571	19.2135690369	\N	\N	Gotska Sandön	\N	\N	Poor	1	1	-3067	\N	C	2019-12-20 22:13:53.799521+00	1887
3066	\N	59.1970259309	17.4262182633	Turinge 415	\N	Gläntan	\N	\N	Ancient monument	1	1	-3066	\N	C	2019-12-20 22:13:53.799521+00	1888
3065	\N	60.2005055974	17.4968905667	Tierp 86	\N	Glädjen	\N	\N	Ancient monument	1	1	-3065	\N	C	2019-12-20 22:13:53.799521+00	1889
3064	\N	55.4561811108	14.0248363532	Glemminge 6	\N	Glemminge	\N	\N	Ancient monument	1	1	-3064	\N	C	2019-12-20 22:13:53.799521+00	1890
3063	\N	63.2498906237	18.7052871436	Själevad 22	\N	Gene	\N	\N	Ancient monument	1	1	-3063	\N	C	2019-12-20 22:13:53.799521+00	1891
3062	\N	59.8972397790	17.6357879882	Gamla Uppsala 547	\N	Gamla Uppsala	\N	\N	Ancient monument	1	1	-3062	\N	C	2019-12-20 22:13:53.799521+00	1892
3061	\N	61.7915130563	14.6180877928	Los 68	\N	Fågelsjö	\N	\N	Ancient monument	1	1	-3061	\N	C	2019-12-20 22:13:53.799521+00	1893
3060	\N	58.5251751194	16.3895916066	\N	\N	Fristad	\N	\N	Poor	1	1	-3060	\N	C	2019-12-20 22:13:53.799521+00	1894
3059	\N	55.5666972007	13.0882208523	Malmö 88	\N	Fredriksberg 13E	\N	\N	Ancient monument	1	1	-3059	\N	C	2019-12-20 22:13:53.799521+00	1895
3058	\N	55.5601589807	13.0764550071	Oxie 35	\N	Fredriksberg 13D	\N	\N	Ancient monument	1	1	-3058	\N	C	2019-12-20 22:13:53.799521+00	1896
3057	\N	50.9106910000	6.8145640000	\N	\N	Frechen	\N	\N	Poor	1	1	-3057	\N	C	2019-12-20 22:13:53.799521+00	1897
3056	\N	55.5602926412	13.0283204272	Fosie 95?	\N	Fosie	\N	\N	Ancient monument	1	1	-3056	\N	C	2019-12-20 22:13:53.799521+00	1898
3055	\N	56.0356070000	10.1999940000	\N	\N	Flyndehage	\N	\N	Poor	1	1	-3055	\N	C	2019-12-20 22:13:53.799521+00	1899
3054	\N	57.4513558183	12.1846511914	Fjärås 486	\N	Fjärås 486	\N	\N	Ancient monument	1	1	-3054	\N	C	2019-12-20 22:13:53.799521+00	1900
3053	\N	58.6626320354	16.4144311908	Krokek 23	\N	Fagervik	\N	\N	Ancient monument	1	1	-3053	\N	C	2019-12-20 22:13:53.799521+00	1901
3052	\N	61.1271090000	22.1470340000	\N	\N	Eura Ä Karäjämäki	\N	\N	Poor	1	1	-3052	\N	C	2019-12-20 22:13:53.799521+00	1902
3051	\N	-26.3573150000	-65.9530940000	\N	\N	El Pichao	\N	\N	Poor	1	1	-3051	\N	C	2019-12-20 22:13:53.799521+00	1903
3050	\N	60.4979920000	25.7440410000	\N	\N	Eknäs	\N	\N	Poor	1	1	-3050	\N	C	2019-12-20 22:13:53.799521+00	1904
3049	\N	59.1885552299	17.9032000709	Botkyrka 254	\N	Eklundshov	\N	\N	Ancient monument	1	1	-3049	\N	C	2019-12-20 22:13:53.799521+00	1905
3048	\N	59.8415746933	17.5790769183	\N	\N	Ekeby	\N	\N	Poor	1	1	-3048	\N	C	2019-12-20 22:13:53.799521+00	1906
3047	\N	59.1233820000	9.6921450000	\N	\N	Eidanger Prestegård	\N	\N	Approximate	1	1	-3047	\N	C	2019-12-20 22:13:53.799521+00	1907
3046	\N	55.1420340000	10.7065800000	\N	\N	Egelygård	\N	\N	Poor	1	1	-3046	\N	C	2019-12-20 22:13:53.799521+00	1908
3045	\N	55.8203973334	13.0402615544	Västra Karaby 101	\N	Dösjebro (SU 19)	\N	\N	Ancient monument	1	1	-3045	\N	C	2019-12-20 22:13:53.799521+00	1909
3044	\N	-21.6491530000	35.4672370000	\N	\N	Dundo	\N	\N	Poor	1	1	-3044	\N	C	2019-12-20 22:13:53.799521+00	1910
3043	\N	59.9796541212	17.5797046104	Bälinge 86	\N	Dragby	\N	\N	Ancient monument	1	1	-3043	\N	C	2019-12-20 22:13:53.799521+00	1911
3042	\N	47.3882750000	22.7994750000	\N	\N	Dersida	\N	\N	Poor	1	1	-3042	\N	C	2019-12-20 22:13:53.799521+00	1912
3041	\N	59.7179456261	18.4872232051	Skederid 16	\N	Darsgärde	\N	\N	Ancient monument	1	1	-3041	\N	C	2019-12-20 22:13:53.799521+00	1913
3040	\N	59.8265858232	17.7422661074	Danmark 100?	\N	Danmarksby	\N	\N	Ancient monument	1	1	-3040	\N	C	2019-12-20 22:13:53.799521+00	1914
3039	\N	59.8333381886	16.5028862430	Kila 100	\N	Dalskarlstorp	\N	\N	Ancient monument	1	1	-3039	\N	C	2019-12-20 22:13:53.799521+00	1915
3038	\N	55.6653476548	13.3452641314	Dalby 40	\N	Dalby	\N	\N	Ancient monument	1	1	-3038	\N	C	2019-12-20 22:13:53.799521+00	1916
3037	\N	55.8188822611	13.0643297470	Dagstorp 16	\N	Dagstorp (SU 21)	\N	\N	Ancient monument	1	1	-3037	\N	C	2019-12-20 22:13:53.799521+00	1917
3036	\N	55.8231621926	13.0378076627	Dagstorp 11	\N	Dagstorp (SU 17)	\N	\N	Ancient monument	1	1	-3036	\N	C	2019-12-20 22:13:53.799521+00	1918
3035	\N	54.4376120000	-8.4299050000	\N	\N	Creevykeel	\N	\N	Poor	1	1	-3035	\N	C	2019-12-20 22:13:53.799521+00	1919
3034	\N	-6.2329480000	-77.8607420000	\N	\N	Cochabamba	\N	\N	Poor	1	1	-3034	\N	C	2019-12-20 22:13:53.799521+00	1920
3033	\N	46.7726600000	23.6205720000	\N	\N	Cluj-Napoca	\N	\N	Poor	1	1	-3033	\N	C	2019-12-20 22:13:53.799521+00	1921
3032	\N	52.9639480000	14.4288170000	\N	\N	Chojna Church	\N	\N	Poor	1	1	-3032	\N	C	2019-12-20 22:13:53.799521+00	1922
3031	\N	-20.1044880000	30.3015620000	\N	\N	Chivowa Hill	\N	\N	Poor	1	1	-3031	\N	C	2019-12-20 22:13:53.799521+00	1923
3030	\N	57.7910440589	13.1336652361	Rångedal 226	\N	Charlottendal	\N	\N	Ancient monument	1	1	-3030	\N	C	2019-12-20 22:13:53.799521+00	1924
3029	\N	54.1179020000	-8.6918880000	\N	\N	Carrowmore	\N	\N	Poor	1	1	-3029	\N	C	2019-12-20 22:13:53.799521+00	1925
3028	\N	54.4376120000	-8.4299050000	\N	\N	Carrowkeel	\N	\N	Poor	1	1	-3028	\N	C	2019-12-20 22:13:53.799521+00	1926
3027	\N	38.0249450000	14.4416790000	\N	\N	Caronia &amp; Caronia Marina	\N	\N	Poor	1	1	-3027	\N	C	2019-12-20 22:13:53.799521+00	1927
3026	\N	55.4138031246	14.1425526023	Löderup 29	\N	Carlshögen	\N	\N	Ancient monument	1	1	-3026	\N	C	2019-12-20 22:13:53.799521+00	1928
3025	\N	59.6105213849	16.4747040526	Lundby 307	\N	Bäckby	\N	\N	Ancient monument	1	1	-3025	\N	C	2019-12-20 22:13:53.799521+00	1929
3024	\N	57.1456028163	12.3493576875	Gödestad 27	\N	Båtsberg	\N	\N	Ancient monument	1	1	-3024	\N	C	2019-12-20 22:13:53.799521+00	1930
3023	\N	55.6336364936	13.1080299741	Burlöv 43	\N	Burlöv 20C	\N	\N	Ancient monument	1	1	-3023	\N	C	2019-12-20 22:13:53.799521+00	1931
3022	\N	55.5476445671	13.0048418226	Bunkeflo 68	\N	Bunkeflo 68	\N	\N	Ancient monument	1	1	-3022	\N	C	2019-12-20 22:13:53.799521+00	1932
3021	\N	60.3976060000	5.3235370000	\N	\N	Bryggen	\N	\N	Poor	1	1	-3021	\N	C	2019-12-20 22:13:53.799521+00	1933
3020	\N	51.2087300000	3.2261880000	\N	\N	Brügge	\N	\N	Parish	1	1	-3020	\N	C	2019-12-20 22:13:53.799521+00	1934
3019	\N	55.1165250000	10.6741990000	\N	\N	Brudager Settlement	\N	\N	Poor	1	1	-3019	\N	C	2019-12-20 22:13:53.799521+00	1935
3018	\N	55.1165250000	10.6741990000	\N	\N	Brudager Cemetery	\N	\N	Poor	1	1	-3018	\N	C	2019-12-20 22:13:53.799521+00	1936
3017	\N	57.1224545596	12.3945008421	Grimeton 3	\N	Broåsen	\N	\N	Ancient monument	1	1	-3017	\N	C	2019-12-20 22:13:53.799521+00	1937
3016	\N	56.7269567418	12.9418776008	Snöstorp 71?	\N	Brogård	\N	\N	Poor	1	1	-3016	\N	C	2019-12-20 22:13:53.799521+00	1938
3015	\N	58.3714890000	8.6189230000	\N	\N	Bringsvær	\N	\N	Poor	1	1	-3015	\N	C	2019-12-20 22:13:53.799521+00	1939
3014	\N	56.8686414604	16.6399051987	\N	\N	Borgholm	\N	\N	Poor	1	1	-3014	\N	C	2019-12-20 22:13:53.799521+00	1940
3013	\N	55.7505648796	13.0378850708	Borgeby 48	\N	Borgeby	\N	\N	Ancient monument	1	1	-3013	\N	C	2019-12-20 22:13:53.799521+00	1941
3012	\N	59.6696144591	16.7198857467	Tortuna 258	\N	Bollbacken	\N	\N	Ancient monument	1	1	-3012	\N	C	2019-12-20 22:13:53.799521+00	1942
3011	\N	55.8032892219	13.0230745659	Karaby 21?	\N	Björnstorp	\N	\N	Ancient monument	1	1	-3011	\N	C	2019-12-20 22:13:53.799521+00	1943
3010	\N	58.7846686810	12.4732681360	Skållerud 10	\N	Björkön	\N	\N	Ancient monument	1	1	-3010	\N	C	2019-12-20 22:13:53.799521+00	1944
3009	\N	60.0238821868	17.5658307313	Björklinge 67	\N	Björklinge 67	\N	\N	Ancient monument	1	1	-3009	\N	C	2019-12-20 22:13:53.799521+00	1945
3008	\N	56.1078818239	15.8110374181	\N	\N	Björkekärr	\N	\N	Poor	1	1	-3008	\N	C	2019-12-20 22:13:53.799521+00	1946
3007	\N	63.2174540340	18.4769625082	Nätra 321; Nätra 318; Nätra 307	\N	Bjästamon	\N	\N	Ancient monument	1	1	-3007	\N	C	2019-12-20 22:13:53.799521+00	1947
3006	\N	63.0055413423	17.8368904605	Bjärtrå 44	\N	Bjärtrå stronghold	\N	\N	Ancient monument	1	1	-3006	\N	C	2019-12-20 22:13:53.799521+00	1948
3005	\N	55.7258029158	13.0287762699	Flädie 9	\N	Bjärred	\N	\N	Ancient monument	1	1	-3005	\N	C	2019-12-20 22:13:53.799521+00	1949
3004	\N	55.4539044278	13.7400730712	Bjäresjö 46	\N	Bjäresjö	\N	\N	Ancient monument	1	1	-3004	\N	C	2019-12-20 22:13:53.799521+00	1950
3003	\N	64.4536979430	21.6040916694	\N	\N	Bjuröklubb	\N	\N	Poor	1	1	-3003	\N	C	2019-12-20 22:13:53.799521+00	1951
3002	\N	64.9992115511	21.0550224689	Byske 14	\N	Bjurselet	\N	\N	Ancient monument	1	1	-3002	\N	C	2019-12-20 22:13:53.799521+00	1952
3001	\N	59.3370196193	17.5507169936	Adelsö 118	\N	Birka, Settlement	\N	\N	Ancient monument	1	1	-3001	\N	C	2019-12-20 22:13:53.799521+00	1953
3000	\N	59.3356206619	17.5455298764	Adelsö 119	\N	Birka, Cemetery	\N	\N	Ancient monument	1	1	-3000	\N	C	2019-12-20 22:13:53.799521+00	1954
2999	\N	56.6371978921	16.2134803482	Hossmo 161; Hossmo 134	\N	Binga	\N	\N	Ancient monument	1	1	-2999	\N	C	2019-12-20 22:13:53.799521+00	1955
2998	\N	59.4219309046	16.3579273467	\N	\N	Berga	\N	\N	\N	1	1	-2998	\N	C	2019-12-20 22:13:53.799521+00	1956
2997	\N	59.2478788839	15.0683218771	Täby 34	\N	Bengtstorp	\N	\N	Ancient monument	1	1	-2997	\N	C	2019-12-20 22:13:53.799521+00	1957
2996	\N	55.3813999067	13.4456315785	Lilla Beddinge 1?	\N	Beddinge	\N	\N	Approximate	1	1	-2996	\N	C	2019-12-20 22:13:53.799521+00	1958
2995	\N	57.1065632606	18.3180837861	Grötlingbo 54	\N	Barshaldershed	\N	\N	Approximate	1	1	-2995	\N	C	2019-12-20 22:13:53.799521+00	1959
2994	\N	59.1642475694	16.6705314999	Dunker 50	\N	Barrsjö	\N	\N	Ancient monument	1	1	-2994	\N	C	2019-12-20 22:13:53.799521+00	1960
2993	\N	56.9804120000	9.5395990000	\N	\N	Barmer	\N	\N	Poor	1	1	-2993	\N	C	2019-12-20 22:13:53.799521+00	1961
2992	\N	63.8124177659	16.4061031358	\N	\N	Backarne	\N	\N	Poor	1	1	-2992	\N	C	2019-12-20 22:13:53.799521+00	1962
2991	\N	59.4032293793	12.1372490483	Silbodal 86	\N	Backa	\N	\N	Ancient monument	1	1	-2991	\N	C	2019-12-20 22:13:53.799521+00	1963
2990	\N	57.7687883904	14.0872375419	Sandseryd 338	\N	Axamo flygplats	\N	\N	Ancient monument	1	1	-2990	\N	C	2019-12-20 22:13:53.799521+00	1964
2989	\N	58.2040260000	7.9252620000	\N	\N	Augland	\N	\N	Poor	1	1	-2989	\N	C	2019-12-20 22:13:53.799521+00	1965
2988	\N	56.2078447356	15.6774392049	\N	\N	Augerum	\N	\N	Approximate	1	1	-2988	\N	C	2019-12-20 22:13:53.799521+00	1966
2987	\N	-6.2329480000	-77.8607420000	\N	\N	Atuen	\N	\N	Poor	1	1	-2987	\N	C	2019-12-20 22:13:53.799521+00	1967
2986	\N	37.5274560000	22.8744540000	\N	\N	Asine	\N	\N	Approximate	1	1	-2986	\N	C	2019-12-20 22:13:53.799521+00	1968
2985	\N	59.5945890000	17.4622820000	Övergran 260	\N	Apalle	\N	\N	Ancient monument	1	1	-2985	\N	C	2019-12-20 22:13:53.799521+00	1969
2984	\N	57.2277522941	18.3716316341	Hemse 51?	\N	Annexhemmanet	\N	\N	Ancient monument	1	1	-2984	\N	C	2019-12-20 22:13:53.799521+00	1970
2983	\N	55.8268344247	13.0062972237	Annelöv 13	\N	Annelöv	\N	\N	Ancient monument	1	1	-2983	\N	C	2019-12-20 22:13:53.799521+00	1971
2982	\N	58.2060432093	11.9102547484	Ljung 44?	\N	Anfasterö	\N	\N	Ancient monument	1	1	-2982	\N	C	2019-12-20 22:13:53.799521+00	1972
2981	\N	57.7142363439	11.7782901544	Torslanda 110	\N	Amhult	\N	\N	Ancient monument	1	1	-2981	\N	C	2019-12-20 22:13:53.799521+00	1973
2980	\N	58.2955658303	14.6483695136	Västra Tollstad 12	\N	Alvastra Megalithic	\N	\N	Ancient monument	1	1	-2980	\N	C	2019-12-20 22:13:53.799521+00	1974
2979	\N	55.5603451970	12.9450954079	Bunkeflo 24	\N	Almhov subarea 1	\N	\N	Ancient monument	1	1	-2979	\N	C	2019-12-20 22:13:53.799521+00	1975
2978	\N	56.4894623638	16.5763567902	Hulterstad 114?	\N	Alby	\N	\N	Poor	1	1	-2978	\N	C	2019-12-20 22:13:53.799521+00	1976
2977	\N	55.4051851535	14.1260145650	Löderup 31	\N	Albertshög	\N	\N	Ancient monument	1	1	-2977	\N	C	2019-12-20 22:13:53.799521+00	1977
1150	\N	58.2998488401	14.6750613418	Västra Tollstad 22	\N	Alvastra	\N	\N	Ancient monument	1	1	-1150	\N	C	2019-12-20 22:13:53.799521+00	1978
1053	\N	55.5483095632	13.0170149303	Glostorp 67	\N	Lockarp 7B	\N	\N	Ancient monument	1	1	-1053	\N	C	2019-12-20 22:13:53.799521+00	1979
