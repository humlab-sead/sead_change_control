
GRANT USAGE ON SCHEMA public TO humlab_read, sead_read, postgres;

GRANT SELECT ON ALL TABLES IN SCHEMA public TO humlab_read, sead_read, postgres;
GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA public TO humlab_read, sead_read, postgres;
GRANT SELECT ON ALL SEQUENCES IN SCHEMA public TO humlab_read, sead_read, postgres;

ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT ON TABLES TO humlab_read, sead_read, postgres;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT EXECUTE ON FUNCTIONS TO humlab_read, sead_read, postgres;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT ON SEQUENCES TO humlab_read, sead_read, postgres;

GRANT USAGE ON SCHEMA public TO mattias, johan;
GRAND sead_read TO mattias, johan;
