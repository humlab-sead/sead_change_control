1	2014-04-17 05:56:03.101+00	Indication that the date is approximate, with unspecified or unquantifiable errors.	Ca.
2	2014-04-17 05:56:03.101+00	(For radiometric dates only). Oldest possible age of sample, often representing open ended dating where only one extreme limit is known. Occasionally used as part of a >< pair to define approximate age range.	<
3	2014-04-17 05:56:03.101+00	(For radiometric dates only). Youngest possible age of sample, often representing open ended dating where only one extreme limit is known. Occasionally used as part of a >< pair to define approximate age range.	>
4	2014-04-17 05:56:03.101+00	Oldest possible age of sample, usually part of a from-to pair, but could be used to represent open ended dating.	From
5	2014-04-17 05:56:03.101+00	Youngest possible age of sample, usually part of a from-to pair, but could be used to represent open ended dating.	To
6	2014-04-17 05:56:03.101+00	Approximate oldest possible age of sample, usually part of a from-to pair, but could be used to represent open ended dating.	From ca.
7	2014-04-17 05:56:03.101+00	Approximate youngest possible age of sample, usually part of a from-to pair, but could be used to represent open ended dating.	To ca.
8	2014-04-17 05:56:03.101+00	Dating is disputable.	?
