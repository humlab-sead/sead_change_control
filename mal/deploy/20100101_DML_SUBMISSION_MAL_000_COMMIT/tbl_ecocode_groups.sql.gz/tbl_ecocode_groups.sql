1	2014-01-15 10:08:16.881383+00	All terms for this Scandinavian classification system are under a single group. Primarily used for grouping species on pollen diagrams.	1	All definitions for system	\N
2	2014-04-17 05:56:03.101+00	Bugs default group for BugsEcocodes.	2	Bugs	\N
3	2014-04-17 05:56:03.101+00	Koch default group for KochEcocodes.	3	KochGroup	\N
