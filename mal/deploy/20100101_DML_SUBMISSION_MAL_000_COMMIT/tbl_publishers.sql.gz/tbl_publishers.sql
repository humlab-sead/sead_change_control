57	2012-09-21 16:51:47.967181+00	Cairo	American University Press
58	2012-09-21 16:51:47.967181+00	Cairo	American University in Cairo Press
59	2012-09-21 16:51:47.967181+00	Amsterdam	Amsterdam University Press
60	2012-09-21 16:51:47.967181+00	London	Anit-Locust Research Centre
64	2012-09-21 16:51:47.967181+00	\N	Anthony Nelson
65	2012-09-21 16:51:47.967181+00	Stenstrup	Apollo Books
66	2012-09-21 16:51:47.967181+00	Saarijärvi	Archaeologia Medii Aevi Finlandiae
67	2012-09-21 16:51:47.967181+00	Chicago	Archaeological Institute of North America
69	2012-09-21 16:51:47.967181+00	Stockholm	Archaeological Research Laboratory, Stockholm University
70	2012-09-21 16:51:47.967181+00	Wakefield	Archaeological Services WYAS
72	2012-09-21 16:51:47.967181+00	Ottawa	Archaeological Survey of Canada
76	2012-09-21 16:51:47.967181+00	London	Archetype
78	2012-09-21 16:51:47.967181+00	Folkestone	Archon Books, Dawson
79	2012-09-21 16:51:47.967181+00	\N	Arctandria Press
80	2012-09-21 16:51:47.967181+00	Groningen	Arctic Centre, University of Groningen
81	2012-09-21 16:51:47.967181+00	Calgary	Arctic Institute of North America of the University of Calgary
83	2012-09-21 16:51:47.967181+00	London	Argonaut Press
84	2012-09-21 16:51:47.967181+00	Warminster	Aris & Phillips
85	2012-09-21 16:51:47.967181+00	Fayetteville	Arkansas Archaeological Survey
86	2012-09-21 16:51:47.967181+00	Paris	Armand Colin
87	2012-09-21 16:51:47.967181+00	London	Arnold
88	2012-09-21 16:51:47.967181+00	London	Arrow
89	2012-09-21 16:51:47.967181+00	Uppsala	ArtDatabanken SLU
90	2012-09-21 16:51:47.967181+00	Oslo	Aschehoug
91	2012-09-21 16:51:47.967181+00	Aldershot	Ashgate
92	2012-09-21 16:51:47.967181+00	London	Association of Archaeological Illustrators & Surveyors
93	2012-09-21 16:51:47.967181+00	Dublin	Association of Young Irish Archaeologists
94	2012-09-21 16:51:47.967181+00	London	Athlone Press
95	2012-09-21 16:51:47.967181+00	Cairo	Atlas Press
96	2012-09-21 16:51:47.967181+00	Nuuk & Copenhagen	Atuagkat
97	2012-09-21 16:51:47.967181+00	Arbroath	Authors
98	2012-09-21 16:51:47.967181+00	Aldershot	Avebury
99	2012-09-21 16:51:47.967181+00	Westport, Connecticut	Avi Publ. Co.
100	2012-09-21 16:51:47.967181+00	Oxford	BAR Internations Series
101	2012-09-21 16:51:47.967181+00	London	BCA
102	2012-09-21 16:51:47.967181+00	London	BGRG
103	2012-09-21 16:51:47.967181+00	London	BMNH
104	2012-09-21 16:51:47.967181+00	Cape Town	Balkema
105	2012-09-21 16:51:47.967181+00	Rotterdam	Balkema
106	2012-09-21 16:51:47.967181+00	Baltimore, USA	Baltimore Entomological Society
108	2012-09-21 16:51:47.967181+00	Totowa, New Jersey	Barnes & Noble
109	2012-09-21 16:51:47.967181+00	London	Batsford
110	2012-09-21 16:51:47.967181+00	London	Batsford/English Heritage
111	2012-09-21 16:51:47.967181+00	London	Batsford/Historic Scotland
112	2012-09-21 16:51:47.967181+00	London	Batsford/Scottish Heritage
113	2012-09-21 16:51:47.967181+00	Newcastle upon Tyne	Beaufort Press
114	2012-09-21 16:51:47.967181+00	London	Belhaven
115	2012-09-21 16:51:47.967181+00	London	Belhaven Press
116	2012-09-21 16:51:47.967181+00	London	Bell & Daldy
117	2012-09-21 16:51:47.967181+00	Colchester	Benham & Co.
118	2012-09-21 16:51:47.967181+00	London	Benn
119	2012-09-21 16:51:47.967181+00	Oxford	Berg
120	2012-09-21 16:51:47.967181+00	Edinburgh	Berlin Repr. (1994)
121	2012-09-21 16:51:47.967181+00	Paris	Bertrand
122	2012-09-21 16:51:47.967181+00	Monks Wood, Huntingdon	Biological Records Centre
123	2012-09-21 16:51:47.967181+00	Monks Wood, Abbots Ripton	Biological Reocrds Centre
28	2012-09-21 16:51:47.967181+00	Reading, Massachussetts	Addison-Wesley Module
55	2012-09-21 16:51:47.967181+00	Washington D. C.	American Geophysical Union
73	2012-09-21 16:51:47.967181+00	Canterbury	Dean & Chapter/Canterbury Archaeological Trust
74	2012-09-21 16:51:47.967181+00	London	Council for British Archaeology for Lincoln Archaeological Trust
77	2012-09-21 16:51:47.967181+00	Durham	Architectural and Archaeological Society of Durham and Northumberland
124	2012-09-21 16:51:47.967181+00	Ottawa	Biological Survey of Canada
125	2012-09-21 16:51:47.967181+00	Groningen	Biologisch-Archeologisch Instituut Rijkuniversiteit Groningen
126	2012-09-21 16:51:47.967181+00	Stockholm	Birka Project
1781	2012-09-21 16:51:47.967181+00	Leiden	Scandinavian Science Press
128	2012-09-21 16:51:47.967181+00	London	Birkbeck College
129	2012-09-21 16:51:47.967181+00	\N	Birlinn
130	2012-09-21 16:51:47.967181+00	Birmingham	Birmingham University Field Archaeology Unit
131	2012-09-21 16:51:47.967181+00	Honolulu	Bishop Museum Press
132	2012-09-21 16:51:47.967181+00	Reykjavík	Bjallan
133	2012-09-21 16:51:47.967181+00	London	Blackie & Sons
134	2012-09-21 16:51:47.967181+00	Belfast	Blackstaff Press
135	2012-09-21 16:51:47.967181+00	London	Blackwell
136	2012-09-21 16:51:47.967181+00	Oxford	Blackwell
1782	2012-09-21 16:51:47.967181+00	Leiden/Copenhagen	E. J. Brill/Scandinavian Science Press Ltd
143	2012-09-21 16:51:47.967181+00	London	Bloomsbury
146	2012-09-21 16:51:47.967181+00	London	Book Club Associates
149	2012-09-21 16:51:47.967181+00	Faringdon	Botanical Society & E. W. Classey
152	2012-09-21 16:51:47.967181+00	Woodbridge	Boydell
154	2012-09-21 16:51:47.967181+00	\N	Boydell Press
162	2012-09-21 16:51:47.967181+00	Leiden	Brill
168	2012-09-21 16:51:47.967181+00	London	British Academy
169	2012-09-21 16:51:47.967181+00	Cambridge	British Antarctic Survey
170	2012-09-21 16:51:47.967181+00	Cambridge	British Antarctic Survey, NERC
171	2012-09-21 16:51:47.967181+00	London	British Archaeological Association
161	2012-09-21 16:51:47.967181+00	Manchester	Dept. of Archaeology, University of Manchester
275	2012-09-21 16:51:47.967181+00	Glasgow	British Association
276	2012-09-21 16:51:47.967181+00	Sheffield	British Association
277	2012-09-21 16:51:47.967181+00	Southampton	British Association
278	2012-09-21 16:51:47.967181+00	Birmingham	British Association for the Advancement of Science
279	2012-09-21 16:51:47.967181+00	London	British Association for the Advancement of Science
280	2012-09-21 16:51:47.967181+00	Nottingham	British Association for the Advancement of Science
281	2012-09-21 16:51:47.967181+00	Sheffield	British Association for the Advancement of Science
282	2012-09-21 16:51:47.967181+00	\N	British Bryological Society
284	2012-09-21 16:51:47.967181+00	Oxford	British Ecological Society & Blackwell
286	2012-09-21 16:51:47.967181+00	Reading	British Entomological and Natural History Society
288	2012-09-21 16:51:47.967181+00	Keyworth	British Geological Survey
289	2012-09-21 16:51:47.967181+00	Nottingham	British Geological Survey
290	2012-09-21 16:51:47.967181+00	London	British Geological Survey, HMSO
291	2012-09-21 16:51:47.967181+00	London	British Museum
293	2012-09-21 16:51:47.967181+00	London	British Museum (Natural History)
298	2012-09-21 16:51:47.967181+00	\N	British Tourist Authority
301	2012-09-21 16:51:47.967181+00	Doncaster	Brooke, White & Hatfield Gazette Office
302	2012-09-21 16:51:47.967181+00	New York	Brooklyn Museum
304	2012-09-21 16:51:47.967181+00	Buffalo, NY	Buffalo Museum of Science
305	2012-09-21 16:51:47.967181+00	Uddevalla	Buhuslaningens Boktryckeri
306	2012-09-21 16:51:47.967181+00	Harvard	Bulletin of the Museum of Comparative Zoology
283	2012-09-21 16:51:47.967181+00	London	British Council
307	2012-09-21 16:51:47.967181+00	London	Burke
308	2012-09-21 16:51:47.967181+00	Edinburgh	Burlinn
309	2012-09-21 16:51:47.967181+00	London	Butterworth
310	2012-09-21 16:51:47.967181+00	Tórshavn	Bygdasavnið Gamli Skúli & Steffan Stummann Hansen
311	2012-09-21 16:51:47.967181+00	Reykjavík	Bókaútgáfa Menningarsjóðs
315	2012-09-21 16:51:47.967181+00	Wallingford	CAB
316	2012-09-21 16:51:47.967181+00	Abingdon	CAB International
317	2012-09-21 16:51:47.967181+00	Wallingford	CAB International
319	2012-09-21 16:51:47.967181+00	Wallingford	CABI
321	2012-09-21 16:51:47.967181+00	Dover	CIB
322	2012-09-21 16:51:47.967181+00	Boca Raton, USA	CRC Press
323	2012-09-21 16:51:47.967181+00	New York	CRC Press
324	2012-09-21 16:51:47.967181+00	Whitby	Caedmon
325	2012-09-21 16:51:47.967181+00	Cairo	Cairo University
326	2012-09-21 16:51:47.967181+00	Cairo	Cairo University Herbarium
327	2012-09-21 16:51:47.967181+00	Cardiff	Cambrian Archaeological Association
328	2012-09-21 16:51:47.967181+00	Aberystwyth	Cambrian News
337	2012-09-21 16:51:47.967181+00	Cambridge (rep. London)	Cambridge University Press (rep. Frank Cass & Co.)
338	2012-09-21 16:51:47.967181+00	Cambridge	Cambridgeshire County Council
339	2012-09-21 16:51:47.967181+00	Huddersfield	Cameo Books
340	2012-09-21 16:51:47.967181+00	Christiana	Cammermeyer
341	2012-09-21 16:51:47.967181+00	Cambridge	Camridge University Press
342	2012-09-21 16:51:47.967181+00	Ottawa	Canadian Museum of Nature
344	2012-09-21 16:51:47.967181+00	\N	Cape
345	2012-09-21 16:51:47.967181+00	Cardiff	Cardiff University
346	2012-09-21 16:51:47.967181+00	Cardiff	Cardiff University Extra-mural Department
285	2012-09-21 16:51:47.967181+00	\N	British Ecological Society
296	2012-09-21 16:51:47.967181+00	London	British Museum Press
297	2012-09-21 16:51:47.967181+00	London	British School at Athens
312	2012-09-21 16:51:47.967181+00	Copenhagen	C. A. Reitzel
313	2012-09-21 16:51:47.967181+00	Springfield	C. C.Thomas
314	2012-09-21 16:51:47.967181+00	Munich	C. H. Beck
320	2012-09-21 16:51:47.967181+00	London	CBA
330	2012-09-21 16:51:47.967181+00	Cambridge	Cambridge Philological Society
329	2012-09-21 16:51:47.967181+00	Cambridge	Cambridge University Press
343	2012-09-21 16:51:47.967181+00	Ottawa	Canadian Department of Agriculture
332	2012-09-21 16:51:47.967181+00	London	Cambridge University Press
349	2012-09-21 16:51:47.967181+00	\N	Carleton Library, McClelland & Stewart
350	2012-09-21 16:51:47.967181+00	Washington	Carnegie Institute
351	2012-09-21 16:51:47.967181+00	London	Cassell
352	2012-09-21 16:51:47.967181+00	Dalbeattie	Castlepoint Press
353	2012-09-21 16:51:47.967181+00	London	Centaur Press
356	2012-09-21 16:51:47.967181+00	Paris	Centre Nationale de la Recherche Scientifique
358	2012-09-21 16:51:47.967181+00	Monks Wood	Centre for Ecology & Hydrology
360	2012-09-21 16:51:47.967181+00	London	Chancellor
362	2012-09-21 16:51:47.967181+00	Dordrecht	Chapman & Hall
363	2012-09-21 16:51:47.967181+00	London	Chapman & Hall
366	2012-09-21 16:51:47.967181+00	Springfield	Charles C. Thomas
367	2012-09-21 16:51:47.967181+00	London	Chatto & Wilson
368	2012-09-21 16:51:47.967181+00	London	Chatto & Windus
369	2012-09-21 16:51:47.967181+00	New York	Checkmark Books
370	2012-09-21 16:51:47.967181+00	New York	Chemical Publishing Co
371	2012-09-21 16:51:47.967181+00	Chester	Cheshire Community Council
372	2012-09-21 16:51:47.967181+00	Chester	Cheshire County Council
373	2012-09-21 16:51:47.967181+00	Bristol	Chess Valley Archaeological & Historical Society
374	2012-09-21 16:51:47.967181+00	Chicago	Chicago University Press
376	2012-09-21 16:51:47.967181+00	Chichester	Chichester District Council
378	2012-09-21 16:51:47.967181+00	New York	City University of New York
380	2012-09-21 16:51:47.967181+00	London	City of London Polytechnic
382	2012-09-21 16:51:47.967181+00	Oxford	Clarendon
383	2012-09-21 16:51:47.967181+00	Oxford	Clarendon Press
386	2012-09-21 16:51:47.967181+00	Faringdon	Classey
387	2012-09-21 16:51:47.967181+00	London	Cleaver-Hume Press
388	2012-09-21 16:51:47.967181+00	Oxford	Cleveland Museum of Art & Oxford University Press
389	2012-09-21 16:51:47.967181+00	Mold	Clwyd County Council Archaeology Service
390	2012-09-21 16:51:47.967181+00	Colchester	Colchester Archaeological Group
391	2012-09-21 16:51:47.967181+00	London	Collins
394	2012-09-21 16:51:47.967181+00	New York	Columbia University Press
395	2012-09-21 16:51:47.967181+00	London	Constable
396	2012-09-21 16:51:47.967181+00	London	Constable & Co
397	2012-09-21 16:51:47.967181+00	\N	Conway Maritime Press
398	2012-09-21 16:51:47.967181+00	Manchester	Cooperative Printing Society
399	2012-09-21 16:51:47.967181+00	Cork	Cork University Press
400	2012-09-21 16:51:47.967181+00	Ithaca, NY	Cornell University
402	2012-09-21 16:51:47.967181+00	Ithaca, New York	Cornell University Press
404	2012-09-21 16:51:47.967181+00	Cirencester	Cotswold Archaeological Trust Ltd.
406	2012-09-21 16:51:47.967181+00	London	Council for British Archaeology
407	2012-09-21 16:51:47.967181+00	York	Council for British Archaeology
409	2012-09-21 16:51:47.967181+00	London	Council for British Archaeology & Trust for Lincolnshire Archaeology
410	2012-09-21 16:51:47.967181+00	London	Council for British Archaeology & York Archaeological Trust
411	2012-09-21 16:51:47.967181+00	York	Council for British Archaeology & York Archaeological Trust
357	2012-09-21 16:51:47.967181+00	Quebec	Centre d'etudes nordiques, University of Laval
375	2012-09-21 16:51:47.967181+00	Chichester	J. Wiley & Sons
385	2012-09-21 16:51:47.967181+00	New York	Clarkson N. Potter
408	2012-09-21 16:51:47.967181+00	York	Council for British Archaeology for York Archaeological Trust
458	2012-09-21 16:51:47.967181+00	London	Council for British Archaeology for York Archaeological Trust
464	2012-09-21 16:51:47.967181+00	Strasbourg	Council of Europe
465	2012-09-21 16:51:47.967181+00	Los Angeles	Creative Xpressions
466	2012-09-21 16:51:47.967181+00	Creswell	Creswell Crags Visitor Centre
467	2012-09-21 16:51:47.967181+00	London	Croom Helm
469	2012-09-21 16:51:47.967181+00	London	Crown Agents for CSO, Stanley
470	2012-09-21 16:51:47.967181+00	Glasgow	Cruithne Press
475	2012-09-21 16:51:47.967181+00	Whitehaven	Cumberland Geological Society
479	2012-09-21 16:51:47.967181+00	Clapham	Dalesman Publ. Co.
481	2012-09-21 16:51:47.967181+00	Copenhagen	Danish National Museum & Danish Polar Center
482	2012-09-21 16:51:47.967181+00	Copenhagen	Danish Polar Centre
483	2012-09-21 16:51:47.967181+00	Copenhagen	Danish Polar Centre & Danish National Museum
484	2012-09-21 16:51:47.967181+00	Copenhagen	Danmarks Geologiske Undersogelse
485	2012-09-21 16:51:47.967181+00	Copenhagen	Dansk Polar Center
486	2012-09-21 16:51:47.967181+00	Copenhagen	Dansk Polar Centre & Danish National Museum
487	2012-09-21 16:51:47.967181+00	Hanover (U.S.)	Dartmouth College
488	2012-09-21 16:51:47.967181+00	Hanover, New Hampshire	Dartmouth College Press
489	2012-09-21 16:51:47.967181+00	Stockholm	Databanken för hotade arter
491	2012-09-21 16:51:47.967181+00	Newton Abbott	David & Charles
492	2012-09-21 16:51:47.967181+00	London	David Hurst & Co.
493	2012-09-21 16:51:47.967181+00	London	Dawson
494	2012-09-21 16:51:47.967181+00	Neuchatel	Delachaux & Niestle
495	2012-09-21 16:51:47.967181+00	London	Dent
496	2012-09-21 16:51:47.967181+00	London	Department of the Environment, Transport and the Regions
500	2012-09-21 16:51:47.967181+00	Lund	Dept. of Animal Ecology, University of Lund
501	2012-09-21 16:51:47.967181+00	Sheffield	Dept. of Archaeology & Prehistory, University of Sheffield
504	2012-09-21 16:51:47.967181+00	Lampeter	Dept. of Archaeology, St David's University College, Lampeter
506	2012-09-21 16:51:47.967181+00	Nottingham	Dept. of Archaeology, University of Nottingham
508	2012-09-21 16:51:47.967181+00	Ottawa	Dept. of Energy, Mines and Resources
511	2012-09-21 16:51:47.967181+00	Birmingham	Dept. of Geography, University of Birmingham
514	2012-09-21 16:51:47.967181+00	Lund	Dept. of Quaternary Geology, University of Lund
516	2012-09-21 16:51:47.967181+00	Copenhagen	Det Danske Met. Inst.
518	2012-09-21 16:51:47.967181+00	Copenhagen	Det Kongelige Danske Geografiska Selskab and Kort & Matrikelstyrelsen
520	2012-09-21 16:51:47.967181+00	Oslo	Det Norske Videnskaps Akademi i Oslo
521	2012-09-21 16:51:47.967181+00	Berlin	Deutscher Verlag
522	2012-09-21 16:51:47.967181+00	Berlin	Deutsches Archäologisches Institut
523	2012-09-21 16:51:47.967181+00	Oxford	Discussions in Egyptology Special No.
524	2012-09-21 16:51:47.967181+00	\N	Dodd Mead
525	2012-09-21 16:51:47.967181+00	Edinburgh	Donald
526	2012-09-21 16:51:47.967181+00	Doncaster	Doncaster & District Ornithological Society
527	2012-09-21 16:51:47.967181+00	Doncaster	Doncaster Museum
528	2012-09-21 16:51:47.967181+00	Doncaster	Doncaster Museum & Art Gallery
531	2012-09-21 16:51:47.967181+00	Doncaster	Doncaster RDC
532	2012-09-21 16:51:47.967181+00	Doncaster	Doncaster Rural District Council
533	2012-09-21 16:51:47.967181+00	Dorchester	Dorset Natural History & Archaeological Society
535	2012-09-21 16:51:47.967181+00	Milborne Port	Dorset Publ. Co.
536	2012-09-21 16:51:47.967181+00	New York	Dover
538	2012-09-21 16:51:47.967181+00	Stroudsberg, Pennsylvania	Dowden, Hutchinson & Ross
539	2012-09-21 16:51:47.967181+00	Stroudsburg	Dowden, Hutchinson & Ross Inc.
540	2012-09-21 16:51:47.967181+00	The Hague	Dr. W. Junk
541	2012-09-21 16:51:47.967181+00	Assen	Drents Museum
542	2012-09-21 16:51:47.967181+00	Stavanger	Dreyer
543	2012-09-21 16:51:47.967181+00	London	Duckworth
544	2012-09-21 16:51:47.967181+00	London	Duckworth Press
545	2012-09-21 16:51:47.967181+00	Leiden	E. J. Brill
547	2012-09-21 16:51:47.967181+00	Faringdon	E. W. Classey
551	2012-09-21 16:51:47.967181+00	London	Earthscan
553	2012-09-21 16:51:47.967181+00	Hull	East Riding Local History Society
556	2012-09-21 16:51:47.967181+00	Edinburgh	Edinburgh University Press
557	2012-09-21 16:51:47.967181+00	Paris	Editions Plon
558	2012-09-21 16:51:47.967181+00	London	Edward Arnold
471	2012-09-21 16:51:47.967181+00	Carlisle	Cumberland & Westmoreland Antiquarian & Archaeological Society
474	2012-09-21 16:51:47.967181+00	Carlisle	Cumberland & Westmoreland Archaeological & Antiquarian Society
476	2012-09-21 16:51:47.967181+00	Dordrecht	D. Reidel
497	2012-09-21 16:51:47.967181+00	Glasgow	Dept. of Archaeology, University of Glasgow
498	2012-09-21 16:51:47.967181+00	Umeå	Dept. of Archaeology, University of Umeå
499	2012-09-21 16:51:47.967181+00	Aberdeen	Dept. of Geography, University of Aberdeen
503	2012-09-21 16:51:47.967181+00	Umeå	Dept. of Archaeology & Sámi Studies, University of Umeå
509	2012-09-21 16:51:47.967181+00	Cairo	Dept. of Geography, Cairo University
512	2012-09-21 16:51:47.967181+00	Newcastle-upon-Tyne	Dept. of Geography, University of Newcastle-upon-Tyne
550	2012-09-21 16:51:47.967181+00	Copenhagen	E. Munksgaard
559	2012-09-21 16:51:47.967181+00	London	Egypt Exploration Society
560	2012-09-21 16:51:47.967181+00	Cairo	Egyptian Geophysical Society
561	2012-09-21 16:51:47.967181+00	Cairo & Illinois	Egyptian Studies Association
563	2012-09-21 16:51:47.967181+00	Cairo	Egyptian University Faculty of Medicine
564	2012-09-21 16:51:47.967181+00	Tórshavn	Einars Prent
565	2012-09-21 16:51:47.967181+00	Winona Lake, Indiana	Eisenbrauns
566	2012-09-21 16:51:47.967181+00	Copenhagen	Ejnar Munksgaard
567	2012-09-21 16:51:47.967181+00	London	Elek
568	2012-09-21 16:51:47.967181+00	London	Eliot Stock
569	2012-09-21 16:51:47.967181+00	Amsterdam	Elsevier
571	2012-09-21 16:51:47.967181+00	Edinburgh	Endinburgh University Press
572	2012-09-21 16:51:47.967181+00	London	English Heritage
583	2012-09-21 16:51:47.967181+00	Peterborough	English Nature
587	2012-09-21 16:51:47.967181+00	Peterborough	English Nature Science
588	2012-09-21 16:51:47.967181+00	Cambridge	English Place Name Society
589	2012-09-21 16:51:47.967181+00	Nottingham	English Place-name Society
590	2012-09-21 16:51:47.967181+00	London	English Universities Press
592	2012-09-21 16:51:47.967181+00	Stockholm	Entomologiska Föreningen i Stockholm
593	2012-09-21 16:51:47.967181+00	Umeå	Environmental Archaeology Laboratory, Dept. of Archaeology & Sami Studies, University of Umeå
594	2012-09-21 16:51:47.967181+00	Umeå	Environmental Archaeology Laboratory, Dept. of Archaeology, University of Umeå
595	2012-09-21 16:51:47.967181+00	London	Ernest Benn
596	2012-09-21 16:51:47.967181+00	London	Evelyn, Adams & Mackay
597	2012-09-21 16:51:47.967181+00	London	Everyman
598	2012-09-21 16:51:47.967181+00	London	Everyman Library
600	2012-09-21 16:51:47.967181+00	Exeter	Exeter City Council
601	2012-09-21 16:51:47.967181+00	Exeter	Exeter University Press
602	2012-09-21 16:51:47.967181+00	London	Eyre & Spottiswoode
603	2012-09-21 16:51:47.967181+00	London	F. Warne & Co.
604	2012-09-21 16:51:47.967181+00	London	Faber
605	2012-09-21 16:51:47.967181+00	London	Faber & Faber
606	2012-09-21 16:51:47.967181+00	London	Falklands Conservation
607	2012-09-21 16:51:47.967181+00	Kathmandu	Farmer Managed Irrigation Systems Promotion Trust
608	2012-09-21 16:51:47.967181+00	Tórshavn	Faroe University Press
610	2012-09-21 16:51:47.967181+00	Preston Montfort	Field Studies Council
611	2012-09-21 16:51:47.967181+00	Taunton	Field Studies Council
613	2012-09-21 16:51:47.967181+00	\N	Finnish Forest Research Institute
614	2012-09-21 16:51:47.967181+00	Berlin	Fischer
616	2012-09-21 16:51:47.967181+00	Reykjavík	Fjölrit Náttúrufræðistofnunar 17
618	2012-09-21 16:51:47.967181+00	Malvern	Folly Publ.
619	2012-09-21 16:51:47.967181+00	London	Fontana
620	2012-09-21 16:51:47.967181+00	Edinburgh	Forestry Commission
622	2012-09-21 16:51:47.967181+00	Farnham	Forestry Commission, RSPB
623	2012-09-21 16:51:47.967181+00	Århus	Forlaget Hikuin og Afdeling for Middelalder-arkæologi
624	2012-09-21 16:51:47.967181+00	Cardigan	Forrest Text
625	2012-09-21 16:51:47.967181+00	Cairo	Fouad I University
626	2012-09-21 16:51:47.967181+00	London	Fourth Estate
627	2012-09-21 16:51:47.967181+00	London	Fourth Estate, Harper Collins
628	2012-09-21 16:51:47.967181+00	London	Frances Lincoln
629	2012-09-21 16:51:47.967181+00	\N	Frank Graham
630	2012-09-21 16:51:47.967181+00	London	Frederick Warne
631	2012-09-21 16:51:47.967181+00	London	Free Association Books
632	2012-09-21 16:51:47.967181+00	New York	Free Press
633	2012-09-21 16:51:47.967181+00	San Francisco	Freeman
634	2012-09-21 16:51:47.967181+00	San Francisco	Freeman & Co
635	2012-09-21 16:51:47.967181+00	Ambleside	Freshwater Biological Association
636	2012-09-21 16:51:47.967181+00	Windermere	Freshwater Biological Association
638	2012-09-21 16:51:47.967181+00	Frome	Frome Historical Research Group
639	2012-09-21 16:51:47.967181+00	Tórshavn	Føroya Fróðskaparfelag
640	2012-09-21 16:51:47.967181+00	\N	Føroya Skúlabókagunnur
641	2012-09-21 16:51:47.967181+00	Munich	G. Frey
642	2012-09-21 16:51:47.967181+00	Berlin	G. Uschmann
645	2012-09-21 16:51:47.967181+00	Paris	Gallia Suppl.
646	2012-09-21 16:51:47.967181+00	New York	Garland
647	2012-09-21 16:51:47.967181+00	Cairo	General Egyptian Book Organization
648	2012-09-21 16:51:47.967181+00	Norwich	Geo Abstracts
649	2012-09-21 16:51:47.967181+00	Norwich	Geoabstracts
650	2012-09-21 16:51:47.967181+00	Norwich	Geobooks
651	2012-09-21 16:51:47.967181+00	Sheffield	Geographical Association
666	2012-09-21 16:51:47.967181+00	Boulder	Geological Society of America
668	2012-09-21 16:51:47.967181+00	London	Geological Society of London
672	2012-09-21 16:51:47.967181+00	\N	Geological Survey of Great Britain
673	2012-09-21 16:51:47.967181+00	Copenhagen	Geological Survey of Greenland
674	2012-09-21 16:51:47.967181+00	Dublin	Geological Survey of Ireland
675	2012-09-21 16:51:47.967181+00	Nairobi	Geological Survey of Kenya
576	2012-09-21 16:51:47.967181+00	London	English Heritage, HBMC for England
591	2012-09-21 16:51:47.967181+00	Copenhagen	Entomological Society of Copenhagen
617	2012-09-21 16:51:47.967181+00	Tallahassee, FL	Florida State University
643	2012-09-21 16:51:47.967181+00	Stuttgart	G. Fischer
644	2012-09-21 16:51:47.967181+00	London	G. Routledge & Son
652	2012-09-21 16:51:47.967181+00	Nottingham	Geographical Field Group
653	2012-09-21 16:51:47.967181+00	London	Geological Society
662	2012-09-21 16:51:47.967181+00	Oxford	Geological Society, Blackwell
663	2012-09-21 16:51:47.967181+00	Bath	Geological Society
677	2012-09-21 16:51:47.967181+00	London	Geological Survey, HMSO
679	2012-09-21 16:51:47.967181+00	London	George Allen & Unwin
680	2012-09-21 16:51:47.967181+00	London	George G. Harrap
681	2012-09-21 16:51:47.967181+00	London	George Philip & Son
682	2012-09-21 16:51:47.967181+00	London	George Philip & Sons Ltd
683	2012-09-21 16:51:47.967181+00	London	George Routledge & Sons
684	2012-09-21 16:51:47.967181+00	Tucson, Arizona	Geoscience Press
685	2012-09-21 16:51:47.967181+00	London	Ginn & Co
686	2012-09-21 16:51:47.967181+00	Glasgow	Glasgow University Press
687	2012-09-21 16:51:47.967181+00	Glastonbury	Glastonbury Antiquarian Society
688	2012-09-21 16:51:47.967181+00	Krefeld	Goecke & Evers
689	2012-09-21 16:51:47.967181+00	\N	Gollanz
690	2012-09-21 16:51:47.967181+00	New York	Gordon & Breech
691	2012-09-21 16:51:47.967181+00	Bulaq	Government Press
692	2012-09-21 16:51:47.967181+00	Cairo	Government Press
693	2012-09-21 16:51:47.967181+00	Stanley	Government Printers
694	2012-09-21 16:51:47.967181+00	Nairobi	Government of Kenya
695	2012-09-21 16:51:47.967181+00	Naivasha	Government of Kenya, Ministry of Energy Geothermal Section
696	2012-09-21 16:51:47.967181+00	Tenerife	Graficas Tenerife
697	2012-09-21 16:51:47.967181+00	London	Grafton
698	2012-09-21 16:51:47.967181+00	London	Graham & Trotman
699	2012-09-21 16:51:47.967181+00	London	Granada
700	2012-09-21 16:51:47.967181+00	London	Granta Books
701	2012-09-21 16:51:47.967181+00	Copenhagen	Greenland National Museum and Archives & Danish Polar Centre
702	2012-09-21 16:51:47.967181+00	London	Greenwich Medical Media
703	2012-09-21 16:51:47.967181+00	\N	Gregg
704	2012-09-21 16:51:47.967181+00	New Windsor (NY)	Gretaf Macbeth
705	2012-09-21 16:51:47.967181+00	Croydon	Grubb
706	2012-09-21 16:51:47.967181+00	Copenhagen	Gr›nlands Geologiske Unders›gelse
707	2012-09-21 16:51:47.967181+00	\N	Guernsey Museum Monograph
708	2012-09-21 16:51:47.967181+00	London	Guild Publ.
709	2012-09-21 16:51:47.967181+00	London	Guild Publishing
710	2012-09-21 16:51:47.967181+00	London	Guildhall University
712	2012-09-21 16:51:47.967181+00	Stuttgart	Gustav Fischer
713	2012-09-21 16:51:47.967181+00	Copenhagen	Gyldendal
714	2012-09-21 16:51:47.967181+00	Copenhagen	Gyldendalske
717	2012-09-21 16:51:47.967181+00	Belfast	HMSO
718	2012-09-21 16:51:47.967181+00	Edinburgh	HMSO
719	2012-09-21 16:51:47.967181+00	London	HMSO
720	2012-09-21 16:51:47.967181+00	London	Hakluyt Society
722	2012-09-21 16:51:47.967181+00	London	Hale
723	2012-09-21 16:51:47.967181+00	Sheffield	Hallamshire Press
724	2012-09-21 16:51:47.967181+00	London	Hambledon
725	2012-09-21 16:51:47.967181+00	London	Hambledon Press
727	2012-09-21 16:51:47.967181+00	San Diego	Harcourt Academic Press
728	2012-09-21 16:51:47.967181+00	Colchester	Harley Books
729	2012-09-21 16:51:47.967181+00	Newcastle-upon-Tyne	Harold Hill & Son
730	2012-09-21 16:51:47.967181+00	New York	Harper & Row
731	2012-09-21 16:51:47.967181+00	London	Harper Collins
732	2012-09-21 16:51:47.967181+00	New York	Harper Collins
734	2012-09-21 16:51:47.967181+00	London	Hart-Davis
735	2012-09-21 16:51:47.967181+00	Cambridge, Mass.	Harvard University
736	2012-09-21 16:51:47.967181+00	Cambridge, Massachussetts	Harvard University Press
738	2012-09-21 16:51:47.967181+00	Lincoln	Harvey Miller/Lincoln Cathedral
739	2012-09-21 16:51:47.967181+00	Amsterdam	Harwood Academic
740	2012-09-21 16:51:47.967181+00	Hamar	Hedmarkmuseet og Domkirkeodden
741	2012-09-21 16:51:47.967181+00	London	Heinemann
742	2012-09-21 16:51:47.967181+00	London	Henry Bradshaw Society
743	2012-09-21 16:51:47.967181+00	London	Herbert Press
744	2012-09-21 16:51:47.967181+00	King's Lynn	Heritage Publ.
745	2012-09-21 16:51:47.967181+00	Reykjavík	Hid íslenzka bokmenntafélag og sogufélagid
746	2012-09-21 16:51:47.967181+00	Reykjavík	Hid íslenzka bókmenntafélag
747	2012-09-21 16:51:47.967181+00	\N	Highworth
748	2012-09-21 16:51:47.967181+00	New York	Hill & Wang
750	2012-09-21 16:51:47.967181+00	Reykjavík	Hin íslenska fornleifafélag & Þjóðminjasafn Íslands
751	2012-09-21 16:51:47.967181+00	Newcastle upon Tyne	Hindson & Andrew Reid
752	2012-09-21 16:51:47.967181+00	Reykjavik	Hins islenska Bokmenntafelag
753	2012-09-21 16:51:47.967181+00	Copenhagen	Hins íslenska frædafélags
754	2012-09-21 16:51:47.967181+00	Enfield	Hisarlik Press
755	2012-09-21 16:51:47.967181+00	Middlesex	Hisarlik Press
758	2012-09-21 16:51:47.967181+00	Lincoln	History of Lincolnshire Committee
759	2012-09-21 16:51:47.967181+00	Reykjavík	Hið Íslenzka Bókmenntaf
761	2012-09-21 16:51:47.967181+00	London	Hodder & Stoughton
762	2012-09-21 16:51:47.967181+00	London	Hodder Arnold
764	2012-09-21 16:51:47.967181+00	Lincoln	Honeywood Press
765	2012-09-21 16:51:47.967181+00	Hull	Hull University
766	2012-09-21 16:51:47.967181+00	Hull	Hull University Press
767	2012-09-21 16:51:47.967181+00	Hull	Humber Wetlands Project
768	2012-09-21 16:51:47.967181+00	Hull	Humber Wetlands Unit
769	2012-09-21 16:51:47.967181+00	Hull	Humberside County Council
770	2012-09-21 16:51:47.967181+00	Hull	Humberside Leisure Services
771	2012-09-21 16:51:47.967181+00	New York	Hunter College Bone Laboratory
772	2012-09-21 16:51:47.967181+00	London	Hutchinson
773	2012-09-21 16:51:47.967181+00	London	Hutchinson Radius
774	2012-09-21 16:51:47.967181+00	London	Hutchinson University Library
775	2012-09-21 16:51:47.967181+00	Copenhagen	Hölst & Son
776	2012-09-21 16:51:47.967181+00	Kyoto	INQUA
876	2012-09-21 16:51:47.967181+00	\N	Kluwer
778	2012-09-21 16:51:47.967181+00	Bruge	IV Atlantic Colloquium
780	2012-09-21 16:51:47.967181+00	Reykjavík	Iceland Review
781	2012-09-21 16:51:47.967181+00	Copenhagen	Icelandic Book Publ. Co.
782	2012-09-21 16:51:47.967181+00	Bloomington  & Indianapolis	Indiana University Press
783	2012-09-21 16:51:47.967181+00	Melbourne	Inkata Press
1059	2012-09-21 16:51:47.967181+00	\N	North London Polytechnic
784	2012-09-21 16:51:47.967181+00	London	Insitute of Geological Sciences, HMSO
785	2012-09-21 16:51:47.967181+00	Oxford	Institute for Archaeology
786	2012-09-21 16:51:47.967181+00	London	Institute of Archaeology
787	2012-09-21 16:51:47.967181+00	Warsaw	Institute of Archaeology & Ethnology, University of Warsaw
790	2012-09-21 16:51:47.967181+00	Prague	Institute of Archaeology, Czech Academy of Sciences
791	2012-09-21 16:51:47.967181+00	London	Institute of Archaeology, University College
793	2012-09-21 16:51:47.967181+00	London	Institute of Archaeology, University of London
795	2012-09-21 16:51:47.967181+00	London	Institute of Biology
796	2012-09-21 16:51:47.967181+00	London	Institute of British Geographers
715	2012-09-21 16:51:47.967181+00	Stockholm	Göteborgs Kungliga. Vetenskaps och Vitterhetø-Samhälle
716	2012-09-21 16:51:47.967181+00	London	H. W. Edwards
948	2012-09-21 16:51:47.967181+00	New York	MacMillan
726	2012-09-21 16:51:47.967181+00	Stroud	Hampshire Field Club & Archaeological Society
733	2012-09-21 16:51:47.967181+00	St. Helier	Harper Collins
749	2012-09-21 16:51:47.967181+00	Copenhagen	Hin Íslenzka fræðafélag (1913-1917)
756	2012-09-21 16:51:47.967181+00	St. Johns	Historic sites association of Newfoundland and Labrador
757	2012-09-21 16:51:47.967181+00	London	History Book Club
760	2012-09-21 16:51:47.967181+00	Reykjavík	Hið Íslenzka Bókmenntafélag
799	2012-09-21 16:51:47.967181+00	Oxford	Institute of British Geographers, Blackwell
800	2012-09-21 16:51:47.967181+00	Athens	Institute of Geology & Mineral Exploration & British School at Athens
801	2012-09-21 16:51:47.967181+00	Grange-over-Sands	Institute of Terrestrial Ecology
802	2012-09-21 16:51:47.967181+00	Huntingdon	Institute of Terrestrial Ecology
803	2012-09-21 16:51:47.967181+00	London	Institute of Terrestrial Ecology & Nature Conservancy Council
804	2012-09-21 16:51:47.967181+00	La Laguna	Instituto de Estudios Canarios
805	2012-09-21 16:51:47.967181+00	Andover	Intercept
806	2012-09-21 16:51:47.967181+00	Andover	Intercept Ltd.
808	2012-09-21 16:51:47.967181+00	Roskilde	International Association of Landscape Ecology
809	2012-09-21 16:51:47.967181+00	Netherlands	International Molinological Society
811	2012-09-21 16:51:47.967181+00	Cambridge	International Whaling Commission
812	2012-09-21 16:51:47.967181+00	London	Interscience
813	2012-09-21 16:51:47.967181+00	London	Interscience, Wiley & Sons
814	2012-09-21 16:51:47.967181+00	Iowa	Iowa University Press
815	2012-09-21 16:51:47.967181+00	Belfast	Irish Naturalists' Journal Special entomological supplement
816	2012-09-21 16:51:47.967181+00	Washington D. C.	Island Press
819	2012-09-21 16:51:47.967181+00	Jerusalem	Israel Program for Scientific Translations
820	2012-09-21 16:51:47.967181+00	Jerusalem	Israel University Press
829	2012-09-21 16:51:47.967181+00	London	J. Murray
830	2012-09-21 16:51:47.967181+00	Chichester	J. Wiley
834	2012-09-21 16:51:47.967181+00	New York	J. Wiley & Sons
839	2012-09-21 16:51:47.967181+00	Reykjavik	Jakob Benediktsson
840	2012-09-21 16:51:47.967181+00	London	James & James
841	2012-09-21 16:51:47.967181+00	Leeds	James Miles
842	2012-09-21 16:51:47.967181+00	Reykjavík	Jens Gudbjornsson
845	2012-09-21 16:51:47.967181+00	London	John Baker
847	2012-09-21 16:51:47.967181+00	Gloucester	John Bellows
848	2012-09-21 16:51:47.967181+00	Edinburgh	John Donald
849	2012-09-21 16:51:47.967181+00	\N	John Hopkins
850	2012-09-21 16:51:47.967181+00	London	John Hopkins University Press
851	2012-09-21 16:51:47.967181+00	\N	John Hopkins University Press
853	2012-09-21 16:51:47.967181+00	Doncaster	John Tomlinson
854	2012-09-21 16:51:47.967181+00	Chichester	John Wiley & Sons
855	2012-09-21 16:51:47.967181+00	New York	John Wiley & Sons
857	2012-09-21 16:51:47.967181+00	Baltimore	Johns Hopkins University Press
858	2012-09-21 16:51:47.967181+00	Peterborough	Joint Nature Conservancy Council
860	2012-09-21 16:51:47.967181+00	London	Jonathan Cape
862	2012-09-21 16:51:47.967181+00	Dordrecht	Junk
863	2012-09-21 16:51:47.967181+00	The Hague	Junk
864	2012-09-21 16:51:47.967181+00	Højbjerg	Jutland Archaeological Society
866	2012-09-21 16:51:47.967181+00	London	KPI
867	2012-09-21 16:51:47.967181+00	Zlin	Kabourek
868	2012-09-21 16:51:47.967181+00	London	Kegan Paul, Trench, Trubner & Co.
869	2012-09-21 16:51:47.967181+00	Manchester	Kelly
870	2012-09-21 16:51:47.967181+00	Maidstone	Kent Archaeological Society
872	2012-09-21 16:51:47.967181+00	\N	King's College, University of London
873	2012-09-21 16:51:47.967181+00	Kirkwall	Kirkwall Press
874	2012-09-21 16:51:47.967181+00	Dordrecht	Kluwer
875	2012-09-21 16:51:47.967181+00	New York	Kluwer
877	2012-09-21 16:51:47.967181+00	\N	Kluwer Academic
878	2012-09-21 16:51:47.967181+00	\N	Kluwer Academic Press
880	2012-09-21 16:51:47.967181+00	Dirdrecht	Kluwer Academic Publ.
881	2012-09-21 16:51:47.967181+00	Dordrecht	Kluwer Academic Publ.
882	2012-09-21 16:51:47.967181+00	Dordrecht	Kluwer Academic Publishers
885	2012-09-21 16:51:47.967181+00	New York	Kluwer Academic/Plenum
887	2012-09-21 16:51:47.967181+00	Amsterdam/New York	Kluwer/Plenum
888	2012-09-21 16:51:47.967181+00	Kopavógur	Kopavógskaupstaður
889	2012-09-21 16:51:47.967181+00	Kyoto	Koyo Shobo
890	2012-09-21 16:51:47.967181+00	London	Kyle Cathie
891	2012-09-21 16:51:47.967181+00	Marseille	Laboratoire de botanique historique et palynologie, URA, CNRS
892	2012-09-21 16:51:47.967181+00	Lancaster	Lancaster Imprints
893	2012-09-21 16:51:47.967181+00	Lancaster	Lancaster University & English Heritage
894	2012-09-21 16:51:47.967181+00	Lancaster	Lancaster University Archaeological Unit
896	2012-09-21 16:51:47.967181+00	Ashbourne	Landmark Publishing
898	2012-09-21 16:51:47.967181+00	Philadelphia	Lea & Febiger
899	2012-09-21 16:51:47.967181+00	Leicester	Leicester Archaeology Monograph 13
900	2012-09-21 16:51:47.967181+00	Leicester	Leicester University Press
901	2012-09-21 16:51:47.967181+00	London	Leicester University Press
904	2012-09-21 16:51:47.967181+00	Leuven	Leuven University Press
905	2012-09-21 16:51:47.967181+00	Copenhagen	Levin & Munksgaard
906	2012-09-21 16:51:47.967181+00	Paris	Librarie Arthème Fayard
907	2012-09-21 16:51:47.967181+00	Liege	Liege University
909	2012-09-21 16:51:47.967181+00	Lincoln	Lincoln Archaeological Trust
910	2012-09-21 16:51:47.967181+00	Lincoln	Lincoln Archaeological Unit
912	2012-09-21 16:51:47.967181+00	Lincoln	Lincolnshire County Council
913	2012-09-21 16:51:47.967181+00	Lincoln	Lincolnshire History & Archaeology
916	2012-09-21 16:51:47.967181+00	Lincoln	Linconshire County Offices
917	2012-09-21 16:51:47.967181+00	London	Linnaean Society
817	2012-09-21 16:51:47.967181+00	Jerusalem	Israel Exploration Society & Hebrew, University of Jerusalem
822	2012-09-21 16:51:47.967181+00	London	J. & A. Churchill
823	2012-09-21 16:51:47.967181+00	Sheffield	J. Collis Publ.
826	2012-09-21 16:51:47.967181+00	London	J. M. Dent & Sons
825	2012-09-21 16:51:47.967181+00	Sheffield	J. Collis Publications, University of Sheffield
836	2012-09-21 16:51:47.967181+00	London	J. B. Nichols
837	2012-09-21 16:51:47.967181+00	London	J. M. Dent
838	2012-09-21 16:51:47.967181+00	London	J. M. Dent & Co.
843	2012-09-21 16:51:47.967181+00	London	Museum of London & Southwark Archaeological Society
844	2012-09-21 16:51:47.967181+00	London	John Murray
865	2012-09-21 16:51:47.967181+00	Leipzig	K. W. Hiersmann
897	2012-09-21 16:51:47.967181+00	Sheffield	Landscape Conservation Forum
915	2012-09-21 16:51:47.967181+00	Lincoln	Lincolnshire Naturalist's Union
919	2012-09-21 16:51:47.967181+00	London	Little, Brown
920	2012-09-21 16:51:47.967181+00	Liverpool	Liverpool University Press
921	2012-09-21 16:51:47.967181+00	London	Liverpool University Press
922	2012-09-21 16:51:47.967181+00	London	Locomotive Publishing Co Ltd
923	2012-09-21 16:51:47.967181+00	Logaston, Herefords.	Logaston Press
924	2012-09-21 16:51:47.967181+00	Reykjavík	Logberg
925	2012-09-21 16:51:47.967181+00	London	London University Press
926	2012-09-21 16:51:47.967181+00	London	Longman
927	2012-09-21 16:51:47.967181+00	New York	Longman, Green & Co.
928	2012-09-21 16:51:47.967181+00	London	Longman, Green, Longman & Roberts
929	2012-09-21 16:51:47.967181+00	London	Longman, Hurst, Rees, Orme & Brown
930	2012-09-21 16:51:47.967181+00	London	Longman, Orme Brown, Green & Longmans
931	2012-09-21 16:51:47.967181+00	London	Longman, Rees Orme & Co.
932	2012-09-21 16:51:47.967181+00	London	Longman, Rees, Orme, Brown, Green & Longman
933	2012-09-21 16:51:47.967181+00	London	Longmans
934	2012-09-21 16:51:47.967181+00	London	Longmans, Green & Co.
936	2012-09-21 16:51:47.967181+00	Paris	Louis-Jean
937	2012-09-21 16:51:47.967181+00	Louth	Louth Naturalists' Antiquarian & Literary Society
939	2012-09-21 16:51:47.967181+00	Lund	Lund University
940	2012-09-21 16:51:47.967181+00	Lund	Lund University Press
942	2012-09-21 16:51:47.967181+00	Guildford	Lutterworth Press
945	2012-09-21 16:51:47.967181+00	Lancaster	MTP Press
946	2012-09-21 16:51:47.967181+00	Cambridge	MacDonald Institute for Archaeological Research
947	2012-09-21 16:51:47.967181+00	London	MacMillan
949	2012-09-21 16:51:47.967181+00	London	MacMillan & Co
950	2012-09-21 16:51:47.967181+00	London	MacMillan Press
951	2012-09-21 16:51:47.967181+00	Warrington	Mackie
953	2012-09-21 16:51:47.967181+00	Toronto	Macmillan
954	2012-09-21 16:51:47.967181+00	London	Macmillan & Co
955	2012-09-21 16:51:47.967181+00	Toronto	Macmillan & Co.
956	2012-09-21 16:51:47.967181+00	Lanham	Madison Books
957	2012-09-21 16:51:47.967181+00	Reykjavík	Mal og Menning
958	2012-09-21 16:51:47.967181+00	\N	Malet Lambert Local History Reprint
960	2012-09-21 16:51:47.967181+00	Manchester	Manchester Excavation Committee
961	2012-09-21 16:51:47.967181+00	Manchester	Manchester University Press
963	2012-09-21 16:51:47.967181+00	\N	Masonic Publishing Co.
964	2012-09-21 16:51:47.967181+00	Cambridge, Massachusetts	Massachusetts Institute of Technology
965	2012-09-21 16:51:47.967181+00	Paris	Masson
966	2012-09-21 16:51:47.967181+00	London	Max Parrish
968	2012-09-21 16:51:47.967181+00	Cambridge	McDonald Institute for Archaeological Research
970	2012-09-21 16:51:47.967181+00	Montreal	McGill-Queen's University Press
971	2012-09-21 16:51:47.967181+00	New York	McGraw Hill
972	2012-09-21 16:51:47.967181+00	London	McGraw-Hill
974	2012-09-21 16:51:47.967181+00	Toronto	McGraw-Hill Ryerson Ltd
975	2012-09-21 16:51:47.967181+00	Oregon	McMinnville
976	2012-09-21 16:51:47.967181+00	Oslo	Meddelelalder forlaget
983	2012-09-21 16:51:47.967181+00	London	Medieval Society
984	2012-09-21 16:51:47.967181+00	Inverness	Melven Press
986	2012-09-21 16:51:47.967181+00	\N	Memoires de la Societe Archeologique Champenoise
987	2012-09-21 16:51:47.967181+00	Cairo	Memoires presentes a l'Institut d'Egypte
992	2012-09-21 16:51:47.967181+00	St. Johns	Memorial University of Newfoundland
993	2012-09-21 16:51:47.967181+00	St Johns	Memorial University of St Johns
994	2012-09-21 16:51:47.967181+00	Reykjavik	Menningar og Minningararsjódur
996	2012-09-21 16:51:47.967181+00	Reykjavík	Menningarsjóður
997	2012-09-21 16:51:47.967181+00	Nairobi	Mercantile Printers
998	2012-09-21 16:51:47.967181+00	Liverpool	Merseyside County Council
999	2012-09-21 16:51:47.967181+00	Liverpool	Merseyside County Museums
1000	2012-09-21 16:51:47.967181+00	London	Methuen
1002	2012-09-21 16:51:47.967181+00	London	Methuen & Co.
1003	2012-09-21 16:51:47.967181+00	Feltham	Military Survey
1005	2012-09-21 16:51:47.967181+00	The Hague	Ministry of Agriculture, The Netherlands
1006	2012-09-21 16:51:47.967181+00	Nairobi	Ministry of Natural Resources, Kenya
1008	2012-09-21 16:51:47.967181+00	Moesgård	Moesgård Museum
1009	2012-09-21 16:51:47.967181+00	Bradford on Avon	Moonraker
1010	2012-09-21 16:51:47.967181+00	Ashbourne	Moorland Publ. Co.
1011	2012-09-21 16:51:47.967181+00	Ashbourne	Moorland Publishing
1012	2012-09-21 16:51:47.967181+00	The Hague	Moulton
1014	2012-09-21 16:51:47.967181+00	Copenhagen	Munksgaard
1015	2012-09-21 16:51:47.967181+00	Copenhagen	Munksgård
1016	2012-09-21 16:51:47.967181+00	Doncaster	Museum & Art Gallery
1017	2012-09-21 16:51:47.967181+00	Rotterdam	Museum Boymans
1018	2012-09-21 16:51:47.967181+00	Stavanger	Museum of Archaeology
1019	2012-09-21 16:51:47.967181+00	London	Museum of London Archaeology Service
1020	2012-09-21 16:51:47.967181+00	Tervuren	Musée Royal de l'Afrique Central
1021	2012-09-21 16:51:47.967181+00	Reykjavík	Mál og Menning
1024	2012-09-21 16:51:47.967181+00	Vitry-sur-Seine	NAP Editions
1026	2012-09-21 16:51:47.967181+00	Moscow	NAUKA
1027	2012-09-21 16:51:47.967181+00	London	NERC
1028	2012-09-21 16:51:47.967181+00	Monks Wood	NERC
1029	2012-09-21 16:51:47.967181+00	Swindon	NERC
1030	2012-09-21 16:51:47.967181+00	\N	NKS press
1031	2012-09-21 16:51:47.967181+00	London	Nathanial Lloyd & Co.
1033	2012-09-21 16:51:47.967181+00	Copenhagen	National Museum of Denmark
1034	2012-09-21 16:51:47.967181+00	Copenhagen	National Museum of Denmark, Nanortalik Museum, Narsaq Museum and Qaqortoq Museum
1036	2012-09-21 16:51:47.967181+00	Reykjavík	National Museum of Iceland
1038	2012-09-21 16:51:47.967181+00	Cardiff	National Museum of Wales
943	2012-09-21 16:51:47.967181+00	London	M. E. Sharpe
944	2012-09-21 16:51:47.967181+00	London	MOW, HMSO
962	2012-09-21 16:51:47.967181+00	London	National Maritime Museum
988	2012-09-21 16:51:47.967181+00	London	Geological Survey of England and Wales, HMSO
1004	2012-09-21 16:51:47.967181+00	London	Ministry of Agriculture and Fisheries
1007	2012-09-21 16:51:47.967181+00	London	Museum of London
1022	2012-09-21 16:51:47.967181+00	Chesterfield	N. Derbyshire Archaeological Trust
1023	2012-09-21 16:51:47.967181+00	Athens	N. P. Goulandris Foundation
1032	2012-09-21 16:51:47.967181+00	Edinburgh	National Museums of Scotland
1037	2012-09-21 16:51:47.967181+00	Ottawa	National Museum of Man
1040	2012-09-21 16:51:47.967181+00	Copenhagen	Nationalmuseets Arbejdsmark
1041	2012-09-21 16:51:47.967181+00	Copenhagen	Nationalmuseets Forlag
1042	2012-09-21 16:51:47.967181+00	London	Natural History Museum Publ.
1043	2012-09-21 16:51:47.967181+00	Los Angeles	Natural History Museum of Los Angeles County
1045	2012-09-21 16:51:47.967181+00	Peterborough	Nature Conservancy Council
1046	2012-09-21 16:51:47.967181+00	Stockholm	Naturhistoriska Riksmuseet
1047	2012-09-21 16:51:47.967181+00	\N	Naval Intelligence Division
1048	2012-09-21 16:51:47.967181+00	London	Nelson
1049	2012-09-21 16:51:47.967181+00	Cairo	Netherlands Foundation for Archaeological Research in Egypt
1051	2012-09-21 16:51:47.967181+00	St. John	New Brunswick Museum
1052	2012-09-21 16:51:47.967181+00	Lyndhurst	New Forest Ninth Centenary Trust
1057	2012-09-21 16:51:47.967181+00	Reykjavik	Nordahl Institute
1058	2012-09-21 16:51:47.967181+00	Copehagen	Nordic Council of Ministers
1060	2012-09-21 16:51:47.967181+00	Northampton	Northampton Development Corporation
1061	2012-09-21 16:51:47.967181+00	Norwich	Norvik Press
1062	2012-09-21 16:51:47.967181+00	Oslo	Norwegian Academy of Science and Letters
1063	2012-09-21 16:51:47.967181+00	Oslo	Norwegian Council for Science and the Humanities
1064	2012-09-21 16:51:47.967181+00	Norwich	Norwich Mercury
1065	2012-09-21 16:51:47.967181+00	Akureyri	Norðri
1066	2012-09-21 16:51:47.967181+00	Nottingham	Nottingham University Press
1067	2012-09-21 16:51:47.967181+00	\N	Nottinghamshire County Council
1069	2012-09-21 16:51:47.967181+00	Oxford	Oakwood Press
1070	2012-09-21 16:51:47.967181+00	London	Octopus
1071	2012-09-21 16:51:47.967181+00	London	Octopus Books
1073	2012-09-21 16:51:47.967181+00	Reykjavík	Oddi
1074	2012-09-21 16:51:47.967181+00	Odense	Odense University Press
1075	2012-09-21 16:51:47.967181+00	London	Odhams
1076	2012-09-21 16:51:47.967181+00	London	Odhams Press
1077	2012-09-21 16:51:47.967181+00	Athens	Ohio
1079	2012-09-21 16:51:47.967181+00	Edinburgh	Oliver & Boyd
1080	2012-09-21 16:51:47.967181+00	Edinburgh	Oliver & Boyd for University of Aberdeen
1081	2012-09-21 16:51:47.967181+00	Newcastle-upon-Tyne	Oriel Press
1083	2012-09-21 16:51:47.967181+00	Kirkwall	Orkney Press
1085	2012-09-21 16:51:47.967181+00	Oslo	Oslo University Press
1086	2012-09-21 16:51:47.967181+00	Oulu	Oulu University Press
1087	2012-09-21 16:51:47.967181+00	London	Overseas Development Administration
1088	2012-09-21 16:51:47.967181+00	Oxford	Oxbow
1089	2012-09-21 16:51:47.967181+00	Oxford	Oxbow Books
1111	2012-09-21 16:51:47.967181+00	Oxford	Oxford Science Publications
1112	2012-09-21 16:51:47.967181+00	Oxford	Oxford Universitry Press
1113	2012-09-21 16:51:47.967181+00	Oxford	Oxford University Centre for Archaeology
1114	2012-09-21 16:51:47.967181+00	Oxford	Oxford University Committee for Archaeology
1120	2012-09-21 16:51:47.967181+00	Oxford	Oxford University Dept. of Extra-mural Studies
1121	2012-09-21 16:51:47.967181+00	Oxford	Oxford University External Studies
1122	2012-09-21 16:51:47.967181+00	London	Oxford University Press
1123	2012-09-21 16:51:47.967181+00	Oxford	Oxford University Press
1124	2012-09-21 16:51:47.967181+00	Oxford	Oxford University Press for the British Academy
1125	2012-09-21 16:51:47.967181+00	Oxford	Oxford University School of Archaeology
1126	2012-09-21 16:51:47.967181+00	Oxford	Oxfordshire Archaeological Unit
1127	2012-09-21 16:51:47.967181+00	Copenhagen	P. Haase and Son
1128	2012-09-21 16:51:47.967181+00	Goteborg	P. Åstrom
1131	2012-09-21 16:51:47.967181+00	Rixensart	PACT
1132	2012-09-21 16:51:47.967181+00	\N	PELtrash Vanity Publications
1133	2012-09-21 16:51:47.967181+00	York	PLACE
1135	2012-09-21 16:51:47.967181+00	York	PLACE Research Centre
1136	2012-09-21 16:51:47.967181+00	York	PLACE Research Centre, Univ. College of Ripon and York St John
1138	2012-09-21 16:51:47.967181+00	London	Palgrave
1139	2012-09-21 16:51:47.967181+00	Chesterfield	Palmer & Edwards
1140	2012-09-21 16:51:47.967181+00	London	Pan Books
1141	2012-09-21 16:51:47.967181+00	London	Parkway Publ.
1142	2012-09-21 16:51:47.967181+00	Jarrow	Parochial Church Council of the Parish of Jarrow
1143	2012-09-21 16:51:47.967181+00	London	Past & Present Society
1144	2012-09-21 16:51:47.967181+00	London	Paul Elek
1145	2012-09-21 16:51:47.967181+00	Berne	Paul Haupt Publ.
1146	2012-09-21 16:51:47.967181+00	Stamford	Paul Watkins
1147	2012-09-21 16:51:47.967181+00	Nicosia	Paul Åström
1416	2012-09-21 16:51:47.967181+00	Nairobi	TILLMIAP
1148	2012-09-21 16:51:47.967181+00	Bakewell	Peak Park Joint Planning Board
1149	2012-09-21 16:51:47.967181+00	Bakewell	Peak Park Planning Board
1150	2012-09-21 16:51:47.967181+00	Harlow	Pearson Prentice Hall
1151	2012-09-21 16:51:47.967181+00	Louvain	Peeters
1152	2012-09-21 16:51:47.967181+00	Louvain	Peeters Press
1153	2012-09-21 16:51:47.967181+00	Harmondsworth	Penguin
1154	2012-09-21 16:51:47.967181+00	London	Penguin
1155	2012-09-21 16:51:47.967181+00	Harmondsworth	Penguin Books
1156	2012-09-21 16:51:47.967181+00	London	Penguin Books
1157	2012-09-21 16:51:47.967181+00	London	Pennsylvania State University Press
1158	2012-09-21 16:51:47.967181+00	London	Pergamon
1159	2012-09-21 16:51:47.967181+00	New York	Pergamon
1160	2012-09-21 16:51:47.967181+00	Oxford	Pergamon
1161	2012-09-21 16:51:47.967181+00	Oxford	Pergamon Press
1162	2012-09-21 16:51:47.967181+00	London	Peter Davis
1054	2012-09-21 16:51:47.967181+00	New York	New Rochelle
1055	2012-09-21 16:51:47.967181+00	Newcastle-upon-Tyne	Newcastle Antiquarian Society
1056	2012-09-21 16:51:47.967181+00	Newcastle-upon-Tyne	Newcastle University
1068	2012-09-21 16:51:47.967181+00	Oxford	OUCA
1084	2012-09-21 16:51:47.967181+00	Oslo	Oslo University Dept. of Botany & Museum
1108	2012-09-21 16:51:47.967181+00	Oxford	Oxford Archaeology
1110	2012-09-21 16:51:47.967181+00	Oxford	Oxford Commission for Archaeology
1164	2012-09-21 16:51:47.967181+00	London	Phelps
1165	2012-09-21 16:51:47.967181+00	Chichester	Philimore
1166	2012-09-21 16:51:47.967181+00	Chichester	Philimore Press
1167	2012-09-21 16:51:47.967181+00	Mainz am Rhein	Philipp von Zabern
1169	2012-09-21 16:51:47.967181+00	London	Phoenix
1170	2012-09-21 16:51:47.967181+00	London	Phoenix House
1171	2012-09-21 16:51:47.967181+00	London	Picador
1172	2012-09-21 16:51:47.967181+00	London	Pickering
1173	2012-09-21 16:51:47.967181+00	Cheltenham	Piston
1174	2012-09-21 16:51:47.967181+00	York	Place
1175	2012-09-21 16:51:47.967181+00	New York	Plenum
1176	2012-09-21 16:51:47.967181+00	London	Plenum Press
1177	2012-09-21 16:51:47.967181+00	New York	Plenum Press
1178	2012-09-21 16:51:47.967181+00	Plymouth	Plymouth University Press
1179	2012-09-21 16:51:47.967181+00	\N	Pogo Press
1180	2012-09-21 16:51:47.967181+00	Poznan	Polish Academy of Sciences
1181	2012-09-21 16:51:47.967181+00	Warsaw	Polish Scientific Publ.
1182	2012-09-21 16:51:47.967181+00	Poznan	Poznan Archaeological Museum
1184	2012-09-21 16:51:47.967181+00	Delhi	Pragati
1185	2012-09-21 16:51:47.967181+00	Chichester	Praxix
1186	2012-09-21 16:51:47.967181+00	Madison	Prehistory Press
1187	2012-09-21 16:51:47.967181+00	New Jersey	Prentice-Hall
1188	2012-09-21 16:51:47.967181+00	\N	Presses Universitaires de France
1193	2012-09-21 16:51:47.967181+00	Princeton, New Jersey	Princeton University Press
1197	2012-09-21 16:51:47.967181+00	Barnburgh	Privately Published
1198	2012-09-21 16:51:47.967181+00	Oxford	Privately Published
1199	2012-09-21 16:51:47.967181+00	\N	Privately Published
1202	2012-09-21 16:51:47.967181+00	Ely	Providence Press
1208	2012-09-21 16:51:47.967181+00	Sheffield	Published privately
1209	2012-09-21 16:51:47.967181+00	\N	Published privately
1211	2012-09-21 16:51:47.967181+00	Lund	Quaternary Geology, University of Lund
1623	2012-09-21 16:51:47.967181+00	The Hague	W. Junk
1212	2012-09-21 16:51:47.967181+00	Chichester	Quaternary Proceedings 5, Wiley & Sons
1213	2012-09-21 16:51:47.967181+00	Chichester	Quaternary Proceedings 7, J. Wiley & Sons
1214	2012-09-21 16:51:47.967181+00	Cambridge	Quaternary Research Association
1215	2012-09-21 16:51:47.967181+00	London	Quaternary Research Association
1216	2012-09-21 16:51:47.967181+00	Oxford	Quaternary Research Association
1217	2012-09-21 16:51:47.967181+00	\N	Queen's University, Belfast
1218	2012-09-21 16:51:47.967181+00	London	Quiller Press
1219	2012-09-21 16:51:47.967181+00	London	RCHM
1220	2012-09-21 16:51:47.967181+00	London	RCHME
1221	2012-09-21 16:51:47.967181+00	London	RCHME/HMSO
1222	2012-09-21 16:51:47.967181+00	London	RKP
1224	2012-09-21 16:51:47.967181+00	Tucson	Radiocarbon
1225	2012-09-21 16:51:47.967181+00	London	Reaktion Books
1226	2012-09-21 16:51:47.967181+00	Teddington	Redman Publishing
1227	2012-09-21 16:51:47.967181+00	Wiesbaden	Reichert
1228	2012-09-21 16:51:47.967181+00	Dordrecht	Reidel
1229	2012-09-21 16:51:47.967181+00	Rotterdam	Reidel
1243	2012-09-21 16:51:47.967181+00	Leiden	Research School of Asian, African and Amerindian studies, Leiden University
1244	2012-09-21 16:51:47.967181+00	Retford	Retford & District Historical & Archaeological Society
1245	2012-09-21 16:51:47.967181+00	Cologne	Rheinland
1246	2012-09-21 16:51:47.967181+00	Copenhagen	Rhodos
1247	2012-09-21 16:51:47.967181+00	Slough	Richmond Publishing Co. Ltd.
1248	2012-09-21 16:51:47.967181+00	London	Rivington
1249	2012-09-21 16:51:47.967181+00	New York	Rizzoli
1250	2012-09-21 16:51:47.967181+00	London	Rolls Series
1256	2012-09-21 16:51:47.967181+00	Romsey	Romsey Abbey Publications
1257	2012-09-21 16:51:47.967181+00	Rotherham	Rotherham Borough Council
1258	2012-09-21 16:51:47.967181+00	London	Routledge
1259	2012-09-21 16:51:47.967181+00	London	Routledge & Kegan Paul
1260	2012-09-21 16:51:47.967181+00	London	Routledge Curzon
1264	2012-09-21 16:51:47.967181+00	Lanham, USA	Rowman & Littlefield
1265	2012-09-21 16:51:47.967181+00	London	Royal Archaeological Institute
1266	2012-09-21 16:51:47.967181+00	Leeds	Royal Armouries Museum
1269	2012-09-21 16:51:47.967181+00	Swindon	Royal Commission on the Historical Monuments of England
1270	2012-09-21 16:51:47.967181+00	Copenhagen	Royal Danish Academy of Sciences and Letters
1271	2012-09-21 16:51:47.967181+00	London	Royal Entomological Society
1272	2012-09-21 16:51:47.967181+00	St. Albans	Royal Entomological Society
1273	2012-09-21 16:51:47.967181+00	London	Royal Entomological Society of London
1275	2012-09-21 16:51:47.967181+00	London	Royal Geographical Society
1189	2012-09-21 16:51:47.967181+00	Yellowknife	Prince of Wales Northern Heritage Centre
1196	2012-09-21 16:51:47.967181+00	Southborough	Privately Published
1200	2012-09-21 16:51:47.967181+00	Epworth	Privately Published
1201	2012-09-21 16:51:47.967181+00	Sheffield	Privately Published
1194	2012-09-21 16:51:47.967181+00	Hereford	Privately Published
1195	2012-09-21 16:51:47.967181+00	Nottingham	Privately Published
1203	2012-09-21 16:51:47.967181+00	York	Privately Published
1204	2012-09-21 16:51:47.967181+00	Malton	Privately Published
1210	2012-09-21 16:51:47.967181+00	New York	National Museum of Denmark, Nanortalik Museum, Narsaq Museum & Qaqortoq Museum
1231	2012-09-21 16:51:47.967181+00	London/Oxford	Society of Antiquaries of London
1268	2012-09-21 16:51:47.967181+00	London	Royal Commission on Historic Monuments
1267	2012-09-21 16:51:47.967181+00	Kew & Cairo	Royal Botanical Gardens, University of Cairo
1278	2012-09-21 16:51:47.967181+00	London	Royal Meteorological Society
1280	2012-09-21 16:51:47.967181+00	New York	Russell & Russell
1281	2012-09-21 16:51:47.967181+00	New Brunswick	Rutgers University Press
1284	2012-09-21 16:51:47.967181+00	Battelby, Perthshire	SNH
1285	2012-09-21 16:51:47.967181+00	London	SOAS, Centre of Near and Middle Eastern Studies & the Society for Libyan Studies
1286	2012-09-21 16:51:47.967181+00	York	Sampson
1287	2012-09-21 16:51:47.967181+00	York	Sampson Brothers
1288	2012-09-21 16:51:47.967181+00	London	Sampson Low
1289	2012-09-21 16:51:47.967181+00	Gainsville, Florida	Sandhill Crane Press
1290	2012-09-21 16:51:47.967181+00	Padova	Sargon
1295	2012-09-21 16:51:47.967181+00	Santa Fe, New Mexico	School of American Research
1297	2012-09-21 16:51:47.967181+00	Santa Fe	School of American Research Press
1298	2012-09-21 16:51:47.967181+00	Bradford	School of Archaeological Sciences, University of Bradford
1299	2012-09-21 16:51:47.967181+00	Dublin	School of Celtic Studies, Dublin Institute for Advanced Studies
1300	2012-09-21 16:51:47.967181+00	New York	Scientific American Library
1301	2012-09-21 16:51:47.967181+00	Qatar	Scientific and Applied Research Centre, University of Qatar
1302	2012-09-21 16:51:47.967181+00	Edinburgh	Scottish Academic Press
1304	2012-09-21 16:51:47.967181+00	Glasgow	Scottish Association of Geography Teachers & Scottish Natural Heritage
1305	2012-09-21 16:51:47.967181+00	Edinburgh	Scottish Cultural Press
1306	2012-09-21 16:51:47.967181+00	Battlleby, Perthshire	Scottish Natural Heritage
1307	2012-09-21 16:51:47.967181+00	Glasgow	Scottish Natural Heritage
1308	2012-09-21 16:51:47.967181+00	Edinburgh	Scottish Natural Heritage/HMSO
1309	2012-09-21 16:51:47.967181+00	Edinburgh	Scottish Society for Northern Studies
1310	2012-09-21 16:51:47.967181+00	Edinburgh	Scottish Trust for Archaeological Research
1313	2012-09-21 16:51:47.967181+00	Scunthorpe	Scunthorpe Museum
1314	2012-09-21 16:51:47.967181+00	London	Seaby
1315	2012-09-21 16:51:47.967181+00	London	Seeley, Service & Co.
1316	2012-09-21 16:51:47.967181+00	London	Seminar Press
1317	2012-09-21 16:51:47.967181+00	London	Senate
1318	2012-09-21 16:51:47.967181+00	York	Sessions
1319	2012-09-21 16:51:47.967181+00	Onchan, Isle of Man	Shearwater Press
1320	2012-09-21 16:51:47.967181+00	Sheffield	Sheffield Academic Press
1323	2012-09-21 16:51:47.967181+00	Sheffield	Sheffield City Museums
1324	2012-09-21 16:51:47.967181+00	Sheffield	Sheffield Museums
1325	2012-09-21 16:51:47.967181+00	Sheffield	Sheffield University
1326	2012-09-21 16:51:47.967181+00	Sheffield	Sheffield University Press
1327	2012-09-21 16:51:47.967181+00	Aylesbury	Shire Archaeology
1328	2012-09-21 16:51:47.967181+00	Exeter	Short Run Press
1330	2012-09-21 16:51:47.967181+00	London	Sidgewick & Jackson
1331	2012-09-21 16:51:47.967181+00	London	Simon & Schuster
1332	2012-09-21 16:51:47.967181+00	Vancouver	Simon Fraser University
1333	2012-09-21 16:51:47.967181+00	\N	Sixth Brixworth Lecture
1334	2012-09-21 16:51:47.967181+00	Washington	Smithsonian
1335	2012-09-21 16:51:47.967181+00	Washington	Smithsonian Institute
1336	2012-09-21 16:51:47.967181+00	Washington	Smithsonian Institution
1338	2012-09-21 16:51:47.967181+00	Washington DC	Smithsonian Institution Press
1339	2012-09-21 16:51:47.967181+00	Washington	Smithsonian Press
1340	2012-09-21 16:51:47.967181+00	Reykjavík	Societas Scientarum Islandica
1342	2012-09-21 16:51:47.967181+00	London	Society for Medieval Archaeology
1351	2012-09-21 16:51:47.967181+00	London	Society for the Promotion of Christian Knowledge
1352	2012-09-21 16:51:47.967181+00	London	Society for the Promotion of Roman Studies
1354	2012-09-21 16:51:47.967181+00	London	Society of Antiquaries of London
1359	2012-09-21 16:51:47.967181+00	Edinburgh	Society of Antiquaries of Scotland
1360	2012-09-21 16:51:47.967181+00	Glasgow	Society of Antiquaries of Scotland
1361	2012-09-21 16:51:47.967181+00	Edinburgh & Exeter	Society of Antiquaries of Scotland & Wetland Archaeology Research Project
1363	2012-09-21 16:51:47.967181+00	Reykjavík	Society of Icelandic Archaeologists
1366	2012-09-21 16:51:47.967181+00	Reykjavík	Sogufélag
1369	2012-09-21 16:51:47.967181+00	Sheffield	South Yorkshire Archaeological Service
1370	2012-09-21 16:51:47.967181+00	Sheffield	South Yorkshire Archaeology Service
1371	2012-09-21 16:51:47.967181+00	Sheffield	South Yorkshire County Council
1372	2012-09-21 16:51:47.967181+00	Southampton	Southampton University Archaeological Society
1373	2012-09-21 16:51:47.967181+00	Southampton	Southampton University Archaeology Society
1374	2012-09-21 16:51:47.967181+00	Dallas	Southern Methodist University Press
1375	2012-09-21 16:51:47.967181+00	Munich	Spektrum Academic
1376	2012-09-21 16:51:47.967181+00	London	Sphere
1377	2012-09-21 16:51:47.967181+00	Berlin	Springer
1378	2012-09-21 16:51:47.967181+00	Dordrecht	Springer
1379	2012-09-21 16:51:47.967181+00	London	Springer
1380	2012-09-21 16:51:47.967181+00	New York	Springer
1381	2012-09-21 16:51:47.967181+00	Vienna	Springer
1382	2012-09-21 16:51:47.967181+00	Berlin	Springer-Verlag
1384	2012-09-21 16:51:47.967181+00	Tórshavn	Sprotin
1387	2012-09-21 16:51:47.967181+00	York	St. Anthony's Press
1388	2012-09-21 16:51:47.967181+00	Flevoland	Staatsbosbeheer
1389	2012-09-21 16:51:47.967181+00	Stanford	Stanford University
1294	2012-09-21 16:51:47.967181+00	Scarborough	Scarborough & District Archaeological Society
1312	2012-09-21 16:51:47.967181+00	\N	Scottish Academic Press
1329	2012-09-21 16:51:47.967181+00	Shrewsbury	Shropshire Archaeological & Historical Society
1348	2012-09-21 16:51:47.967181+00	London	Society for Roman Studies
1350	2012-09-21 16:51:47.967181+00	Lincoln	Society for Medieval Archaeology
1385	2012-09-21 16:51:47.967181+00	London	St. James Press
1386	2012-09-21 16:51:47.967181+00	New York	St. Martin's Press
1391	2012-09-21 16:51:47.967181+00	Stanford, Cal.	Stanford University Press
1392	2012-09-21 16:51:47.967181+00	Dublin	Stationery Office
1393	2012-09-21 16:51:47.967181+00	York	Stonegate Press
1394	2012-09-21 16:51:47.967181+00	Birmingham	Stratford-upon-Avon Council
1397	2012-09-21 16:51:47.967181+00	\N	Studia Atlantica
1398	2012-09-21 16:51:47.967181+00	St Albans	Sumach Press
1399	2012-09-21 16:51:47.967181+00	London	Sunflower Books
1400	2012-09-21 16:51:47.967181+00	Cairo	Survey & Mines Department
1401	2012-09-21 16:51:47.967181+00	Brighton	Sussex
1402	2012-09-21 16:51:47.967181+00	Gloucester	Sutton
1403	2012-09-21 16:51:47.967181+00	Stroud	Sutton
1404	2012-09-21 16:51:47.967181+00	Stroud	Sutton Press
1405	2012-09-21 16:51:47.967181+00	Stroud	Sutton Publishing
1406	2012-09-21 16:51:47.967181+00	Uppsala	Svensk Natur
1407	2012-09-21 16:51:47.967181+00	Umea	Swedish University of Agricultural Sciences
1408	2012-09-21 16:51:47.967181+00	Lisse	Swets & Zeitlinger
1411	2012-09-21 16:51:47.967181+00	Reykjavík	Sögufélag
1414	2012-09-21 16:51:47.967181+00	London	T. Murby
1417	2012-09-21 16:51:47.967181+00	\N	Tanta University, Egypt
1418	2012-09-21 16:51:47.967181+00	Trondheim	Tapir Academic Press
1419	2012-09-21 16:51:47.967181+00	Cologne	Taschen
1420	2012-09-21 16:51:47.967181+00	London	Taylor & Francis
1423	2012-09-21 16:51:47.967181+00	Stroud	Tempus
1424	2012-09-21 16:51:47.967181+00	Oxford	Tempus Reparatum
1428	2012-09-21 16:51:47.967181+00	London	Thames & Hudson
1430	2012-09-21 16:51:47.967181+00	Stockholm	The Birka Project
1431	2012-09-21 16:51:47.967181+00	Hull	The East Yorkshire Local History Society
1433	2012-09-21 16:51:47.967181+00	London	The Geological Society
1434	2012-09-21 16:51:47.967181+00	London	The Herbert Press
1435	2012-09-21 16:51:47.967181+00	London	The National Trust
1436	2012-09-21 16:51:47.967181+00	Kirkwall	The Orkney Press
1437	2012-09-21 16:51:47.967181+00	Harmondsworth	The Penguin Press
1438	2012-09-21 16:51:47.967181+00	Sandy	The RSPB
1439	2012-09-21 16:51:47.967181+00	Ottawa	The Runge Press
1441	2012-09-21 16:51:47.967181+00	Powis Gardens	The Secret Academy
1442	2012-09-21 16:51:47.967181+00	Lerwick	The Shetland Times
1443	2012-09-21 16:51:47.967181+00	Harpenden	The Soil Survey
1444	2012-09-21 16:51:47.967181+00	Edinburgh	The Stationery Office
1445	2012-09-21 16:51:47.967181+00	Reykjavik	The Surtsey Research Society
1446	2012-09-21 16:51:47.967181+00	London	The Thera Foundation
1448	2012-09-21 16:51:47.967181+00	Roskilde	The Viking Ship Museum
1449	2012-09-21 16:51:47.967181+00	London	The Viking society for Northern Research
1450	2012-09-21 16:51:47.967181+00	Vindolanda	The Vindolanda Trust
1452	2012-09-21 16:51:47.967181+00	Springfield, Illinois	Thomas
1453	2012-09-21 16:51:47.967181+00	Doncaster	Thomas & Hunsley
1454	2012-09-21 16:51:47.967181+00	London	Thomas Cotes
1455	2012-09-21 16:51:47.967181+00	New York	Thomas Dunne
1456	2012-09-21 16:51:47.967181+00	Doncaster	Thorne & Hatfield Moors Conservation Forum
1457	2012-09-21 16:51:47.967181+00	Nottingham	Thoroton Society of Nottinghamshire
1458	2012-09-21 16:51:47.967181+00	Sandwick, Shetland	Thule Press
1459	2012-09-21 16:51:47.967181+00	Portland, Oregon	Timber Press
1460	2012-09-21 16:51:47.967181+00	Baarn, the Netherlands	Tirion
1461	2012-09-21 16:51:47.967181+00	Kendal	Titus Wilson
1463	2012-09-21 16:51:47.967181+00	\N	Toronto University Press
1464	2012-09-21 16:51:47.967181+00	Nottingham	Trent & Peak Archaeological Trust
1465	2012-09-21 16:51:47.967181+00	London	Triade Exploration
1467	2012-09-21 16:51:47.967181+00	Tromsø	Tromsø University Press
1468	2012-09-21 16:51:47.967181+00	Slough	Tropical Development and Research Institute
1469	2012-09-21 16:51:47.967181+00	Salisbury	Trust for Wessex Archaeology
1470	2012-09-21 16:51:47.967181+00	East Lothian	Tuckwell Press
1471	2012-09-21 16:51:47.967181+00	Gateshead	Tyne & Wear Museums
1472	2012-09-21 16:51:47.967181+00	Vancouver	UBC Press
1473	2012-09-21 16:51:47.967181+00	London	UCL Press
1474	2012-09-21 16:51:47.967181+00	Los Angeles	UCLA Press
1475	2012-09-21 16:51:47.967181+00	Peterborough	UK Joint Nature Conservation Committee
1476	2012-09-21 16:51:47.967181+00	Paris	UNESCO
1478	2012-09-21 16:51:47.967181+00	Washington, D. C.	US Department of Agriculture
1479	2012-09-21 16:51:47.967181+00	\N	US Geological Survey
1481	2012-09-21 16:51:47.967181+00	Belfast	Ulster Folk Museum - Institute of Irish Studies
1483	2012-09-21 16:51:47.967181+00	Umeå	Umeå University
1484	2012-09-21 16:51:47.967181+00	La Plata	Universidad Nacional de La Plata
1485	2012-09-21 16:51:47.967181+00	Oslo	Universitetet i Oslo
1493	2012-09-21 16:51:47.967181+00	\N	University College, Cork
1494	2012-09-21 16:51:47.967181+00	\N	University College, London
1495	2012-09-21 16:51:47.967181+00	Bergen	University Press
1496	2012-09-21 16:51:47.967181+00	Oxford	University Press
1497	2012-09-21 16:51:47.967181+00	Princeton	University Press
1498	2012-09-21 16:51:47.967181+00	Lanham	University Press of America
1499	2012-09-21 16:51:47.967181+00	\N	University of Aberdeen
1500	2012-09-21 16:51:47.967181+00	\N	University of Aberdeen, Aberdeen
1501	2012-09-21 16:51:47.967181+00	Edmonton	University of Alberta, Edmonton
1502	2012-09-21 16:51:47.967181+00	\N	University of Arizona
1503	2012-09-21 16:51:47.967181+00	Tucson	University of Arizona Press
1504	2012-09-21 16:51:47.967181+00	Athens	University of Athens
1163	2012-09-21 16:51:47.967181+00	Peterborough	Peterborough Museum
2	2012-09-21 16:51:47.967181+00	Rotterdam	A. A. Balkema
3	2012-09-21 16:51:47.967181+00	New York	A. A. Knopf
4	2012-09-21 16:51:47.967181+00	London	A. Brown & Sons
5	2012-09-21 16:51:47.967181+00	Shirebrook	A. Oswald
6	2012-09-21 16:51:47.967181+00	Stroud	A. Sutton
1279	2012-09-21 16:51:47.967181+00	Akureyri	Raektunarfelag Nordurlands
10	2012-09-21 16:51:47.967181+00	Uppsala	AUN no. 12
11	2012-09-21 16:51:47.967181+00	Aarhus	Aarhus University Press
14	2012-09-21 16:51:47.967181+00	Sandnes	Aase Grafiske A/S
15	2012-09-21 16:51:47.967181+00	Aberdeen	Aberdeen University Press
16	2012-09-21 16:51:47.967181+00	Budapest	Academe Kiado
17	2012-09-21 16:51:47.967181+00	London	Academic Press
18	2012-09-21 16:51:47.967181+00	New York	Academic Press
19	2012-09-21 16:51:47.967181+00	San Diego	Academic Press
20	2012-09-21 16:51:47.967181+00	New York	Academy Editions
22	2012-09-21 16:51:47.967181+00	London	Adam & Black
23	2012-09-21 16:51:47.967181+00	London	Adam & Charles Black
24	2012-09-21 16:51:47.967181+00	Bath	Adams & Dart
25	2012-09-21 16:51:47.967181+00	Hereford	Adams & Sons
26	2012-09-21 16:51:47.967181+00	Harlow	Addison Wesley Longman
27	2012-09-21 16:51:47.967181+00	Reading, Massachussetts	Addison-Wesley
29	2012-09-21 16:51:47.967181+00	Reykjavík	Agricultural Research Institute
31	2012-09-21 16:51:47.967181+00	Budapest	Akadémiai Kiadó
32	2012-09-21 16:51:47.967181+00	Akureyri	Akureyri Museum
33	2012-09-21 16:51:47.967181+00	Cairo	Al Hadara
34	2012-09-21 16:51:47.967181+00	Gloucester	Alan Sutton
35	2012-09-21 16:51:47.967181+00	Stroud	Alan Sutton
36	2012-09-21 16:51:47.967181+00	Chicago	Aldine
39	2012-09-21 16:51:47.967181+00	Chicago	Aldine Publishing Company.
40	2012-09-21 16:51:47.967181+00	London	Alecto
41	2012-09-21 16:51:47.967181+00	New York	Alfred A Knopf
44	2012-09-21 16:51:47.967181+00	Boston	Allen & Unwin
45	2012-09-21 16:51:47.967181+00	London	Allen & Unwin
46	2012-09-21 16:51:47.967181+00	London	Allen Lane
47	2012-09-21 16:51:47.967181+00	London	Allen Press
48	2012-09-21 16:51:47.967181+00	Reykjavík	Almenna Bókafélagið
49	2012-09-21 16:51:47.967181+00	Lund	Almqvist & Wiksell
50	2012-09-21 16:51:47.967181+00	Stockholm	Almqvist & Wiksell
51	2012-09-21 16:51:47.967181+00	\N	Alva
52	2012-09-21 16:51:47.967181+00	London	Amateur Entomologist Society
53	2012-09-21 16:51:47.967181+00	Dallas	American Association of Stratigraphic Palynologists Foundation
56	2012-09-21 16:51:47.967181+00	Sante Fe	American School of Historical Research
1505	2012-09-21 16:51:47.967181+00	\N	University of Bergen
1506	2012-09-21 16:51:47.967181+00	Birmingham	University of Birmingham
1510	2012-09-21 16:51:47.967181+00	Bradford	University of Bradford
1512	2012-09-21 16:51:47.967181+00	Bradford	University of Bradford & Yorkshire Archaeological Society
1513	2012-09-21 16:51:47.967181+00	\N	University of Cairo
1514	2012-09-21 16:51:47.967181+00	Berkeley	University of California
1515	2012-09-21 16:51:47.967181+00	Berkeley	University of California Press
1413	2012-09-21 16:51:47.967181+00	London	T. & A. D. Poyser
1410	2012-09-21 16:51:47.967181+00	Warsaw	Systems Research Unit, Polish Academy of Sciences
1425	2012-09-21 16:51:47.967181+00	Oxford	Tempus Reparatum/B.A.R.
1427	2012-09-21 16:51:47.967181+00	London	Texas A. & M. University Press & Chatham Publ.
1432	2012-09-21 16:51:47.967181+00	Cairo	The Egyptian Geographical Society
1440	2012-09-21 16:51:47.967181+00	Edinburgh	The Scottish Society for Northern Studies
1466	2012-09-21 16:51:47.967181+00	Dublin	Trinity College
1480	2012-09-21 16:51:47.967181+00	Cincinnati	US Environmental Protection Agency
1490	2012-09-21 16:51:47.967181+00	Aberystwyth	University College of Wales Aberystwyth
1509	2012-09-21 16:51:47.967181+00	Birmingham	University of Birmingham, Department of Geography
1516	2012-09-21 16:51:47.967181+00	Berkeley & Los Angeles	University of California Press
1517	2012-09-21 16:51:47.967181+00	Los Angeles	University of California Press
1519	2012-09-21 16:51:47.967181+00	Cambridge	University of Cambridge
1522	2012-09-21 16:51:47.967181+00	Chicago	University of Chicago
1524	2012-09-21 16:51:47.967181+00	Chicago	University of Chicago Press
1525	2012-09-21 16:51:47.967181+00	Boulder	University of Colorado
1526	2012-09-21 16:51:47.967181+00	\N	University of Columbia, New York
1527	2012-09-21 16:51:47.967181+00	\N	University of Connecticut
1528	2012-09-21 16:51:47.967181+00	Derby	University of Derby
1531	2012-09-21 16:51:47.967181+00	Norwich	University of East Anglia
1532	2012-09-21 16:51:47.967181+00	Edinburgh	University of Edinburgh
1535	2012-09-21 16:51:47.967181+00	Groningen	University of Groningen
1223	2012-09-21 16:51:47.967181+00	London	RKP/BCA
1426	2012-09-21 16:51:47.967181+00	\N	Texas A. & M. University
1537	2012-09-21 16:51:47.967181+00	Hong Kong	University of Hong Kong
1538	2012-09-21 16:51:47.967181+00	Hull	University of Hull
1541	2012-09-21 16:51:47.967181+00	Hull	University of Hull Press
1544	2012-09-21 16:51:47.967181+00	Innsbruck	University of Innsbruck Press
1545	2012-09-21 16:51:47.967181+00	Iowa City	University of Iowa
1546	2012-09-21 16:51:47.967181+00	Iowa City	University of Iowa Press
1547	2012-09-21 16:51:47.967181+00	Stoke on Trent	University of Keele
1550	2012-09-21 16:51:47.967181+00	Leeds	University of Leeds
1553	2012-09-21 16:51:47.967181+00	Leicester	University of Leicester
1555	2012-09-21 16:51:47.967181+00	Leicester	University of Leicester Archaeological Services
1557	2012-09-21 16:51:47.967181+00	Lund	University of Lund
1558	2012-09-21 16:51:47.967181+00	Winnipeg	University of Manitoba Press
1559	2012-09-21 16:51:47.967181+00	Ann Arbor	University of Michigan Center for Chinese Studies
1560	2012-09-21 16:51:47.967181+00	Minneapolis	University of Minneapolis Press
1561	2012-09-21 16:51:47.967181+00	Minneapolis	University of Minnesota Press
1562	2012-09-21 16:51:47.967181+00	\N	University of Nebraska Press
1563	2012-09-21 16:51:47.967181+00	Hanover, USA & London	University of New Hampshire Press
1564	2012-09-21 16:51:47.967181+00	Albuquerque	University of New Mexico Press
1565	2012-09-21 16:51:47.967181+00	Nottingham	University of Nottingham
1566	2012-09-21 16:51:47.967181+00	Oslo	University of Oslo
1567	2012-09-21 16:51:47.967181+00	Oulu	University of Oulu
1568	2012-09-21 16:51:47.967181+00	\N	University of Pennsylvania
1569	2012-09-21 16:51:47.967181+00	Philadelphia	University of Pennsylvania Press
1570	2012-09-21 16:51:47.967181+00	Reading	University of Reading
1573	2012-09-21 16:51:47.967181+00	Sheffield	University of Sheffield
1576	2012-09-21 16:51:47.967181+00	Sheffield	University of Sheffield/Medieval Archaeology Society
1577	2012-09-21 16:51:47.967181+00	\N	University of South Carolina Press
1578	2012-09-21 16:51:47.967181+00	Southampton	University of Southampton
1582	2012-09-21 16:51:47.967181+00	St. Andrews	University of St. Andrews
1583	2012-09-21 16:51:47.967181+00	Stirling	University of Stirling
1584	2012-09-21 16:51:47.967181+00	Sydney	University of Sydney
1585	2012-09-21 16:51:47.967181+00	Tokyo	University of Tokyo Press
1587	2012-09-21 16:51:47.967181+00	Toronto	University of Toronto Press
1588	2012-09-21 16:51:47.967181+00	Umeå	University of Umeå
1590	2012-09-21 16:51:47.967181+00	Uppsala	University of Uppsala
1591	2012-09-21 16:51:47.967181+00	Cardiff	University of Wales
1592	2012-09-21 16:51:47.967181+00	Cardiff	University of Wales (Cardiff)
1593	2012-09-21 16:51:47.967181+00	Cardiff	University of Wales Press
1595	2012-09-21 16:51:47.967181+00	Madison	University of Wisconsin Press
1596	2012-09-21 16:51:47.967181+00	York	University of York
1597	2012-09-21 16:51:47.967181+00	Tucson	Universiy of Arizona Press
1600	2012-09-21 16:51:47.967181+00	London	Unwin Hyman
1601	2012-09-21 16:51:47.967181+00	Uppsala	Uppsala University
1602	2012-09-21 16:51:47.967181+00	Uppsala	Uppsala University Press
1603	2012-09-21 16:51:47.967181+00	Leipzig	VEB Hermann Haack
1604	2012-09-21 16:51:47.967181+00	New York	Van Nostrand & Reinhold
1606	2012-09-21 16:51:47.967181+00	Vitry-sur-Seine	Verrières le Buisson
1607	2012-09-21 16:51:47.967181+00	Göttingen	Veröffentlichtungen des Max-Planck-Institut für Geschichte
1608	2012-09-21 16:51:47.967181+00	London	Victor Gollancz
1609	2012-09-21 16:51:47.967181+00	Harmondsworth	Viking
1610	2012-09-21 16:51:47.967181+00	Vindolanda	Vindolanda Trust
1611	2012-09-21 16:51:47.967181+00	London	Vintage
1612	2012-09-21 16:51:47.967181+00	New York	Vintage Books
1613	2012-09-21 16:51:47.967181+00	Reykjavík	Visindafelag Islendinga
1616	2012-09-21 16:51:47.967181+00	Highworth	Vorda
1618	2012-09-21 16:51:47.967181+00	Reykjavík	Vísindafélag Íslendinga
1619	2012-09-21 16:51:47.967181+00	Howden	W. F. Pratt
1620	2012-09-21 16:51:47.967181+00	Oxford	W. H. Freeman & Co
1621	2012-09-21 16:51:47.967181+00	Ulverston	W. Holmes
1622	2012-09-21 16:51:47.967181+00	Dordrecht	W. Junk
1624	2012-09-21 16:51:47.967181+00	Doncaster	W. Sheardown
1626	2012-09-21 16:51:47.967181+00	Exeter	WARP/Prehistoric Society
1627	2012-09-21 16:51:47.967181+00	Helsinki	WWF Finland
1629	2012-09-21 16:51:47.967181+00	Wageningen	Wageningen Agricultural University
1630	2012-09-21 16:51:47.967181+00	Wageningen	Wageningen University
1631	2012-09-21 16:51:47.967181+00	New York	Walker & Co.
1632	2012-09-21 16:51:47.967181+00	London	Warne & Sons
1633	2012-09-21 16:51:47.967181+00	Warsaw	Warsaw University Press
1634	2012-09-21 16:51:47.967181+00	Bradford	Watmough
1635	2012-09-21 16:51:47.967181+00	London	Watts & Co
1636	2012-09-21 16:51:47.967181+00	Prospect Heights, Illinois	Waveland Press
1529	2012-09-21 16:51:47.967181+00	Durham	University of Durham
1523	2012-09-21 16:51:47.967181+00	Chicago	University of Chicago, Dept. of Geography
1534	2012-09-21 16:51:47.967181+00	Glasgow	University of Glasgow
1543	2012-09-21 16:51:47.967181+00	Reykjavík	University of Iceland
1549	2012-09-21 16:51:47.967181+00	Lancaster	University of Lancaster
1556	2012-09-21 16:51:47.967181+00	London	University of London
1571	2012-09-21 16:51:47.967181+00	Salford	University of Salford
1580	2012-09-21 16:51:47.967181+00	Southampton	University of Southampton, Department of Archaeology
1586	2012-09-21 16:51:47.967181+00	Toronto	University of Toronto
1598	2012-09-21 16:51:47.967181+00	York	Unpublished
1599	2012-09-21 16:51:47.967181+00	Thorne	Unpublished
1617	2012-09-21 16:51:47.967181+00	Vuollerim	Vuollerim 6000 år
1637	2012-09-21 16:51:47.967181+00	London	Weidenfeld & Nicolson
1638	2012-09-21 16:51:47.967181+00	London	Weidenfled & Nicolson
1639	2012-09-21 16:51:47.967181+00	Wakefield	West Yorkshire Archaeology
1640	2012-09-21 16:51:47.967181+00	Leeds	West Yorkshire Archaeology Service
1641	2012-09-21 16:51:47.967181+00	Wakefield	West Yorkshire Archaeology Service
1642	2012-09-21 16:51:47.967181+00	Wakefield	West Yorkshire Metropolitan County
1643	2012-09-21 16:51:47.967181+00	Otley	Westbury
1645	2012-09-21 16:51:47.967181+00	Exeter	Wetland Archaeology Research Project
1646	2012-09-21 16:51:47.967181+00	Barnsley	Wharncliffe Publishing
1647	2012-09-21 16:51:47.967181+00	Barnsley	Wharncliffe Publishing Ltd
1648	2012-09-21 16:51:47.967181+00	Chichester	Wiley
1649	2012-09-21 16:51:47.967181+00	London	Wiley
1650	2012-09-21 16:51:47.967181+00	Chichester	Wiley & Sons
1651	2012-09-21 16:51:47.967181+00	London	Wiley & Sons
1652	2012-09-21 16:51:47.967181+00	New York	Wiley & Sons
1653	2012-09-21 16:51:47.967181+00	Chichester	Wiley & sons
1654	2012-09-21 16:51:47.967181+00	Edinburgh	William & Robert Chambers
1655	2012-09-21 16:51:47.967181+00	York	William Sessions
1656	2012-09-21 16:51:47.967181+00	London	Williams & Norgate
1657	2012-09-21 16:51:47.967181+00	Winchester	Winchester Excavation Committee
1658	2012-09-21 16:51:47.967181+00	Macclesfield	Windgather Press
1659	2012-09-21 16:51:47.967181+00	Hunstanton	Witley Press
1660	2012-09-21 16:51:47.967181+00	Leeds	Wool Industries Research Association
1661	2012-09-21 16:51:47.967181+00	Dublin	Wordwell
1662	2012-09-21 16:51:47.967181+00	Nottingham	Workers' Educational Association
1663	2012-09-21 16:51:47.967181+00	Worksop	Worksop Corporation
1664	2012-09-21 16:51:47.967181+00	Geneva	World Health Organisation
1666	2012-09-21 16:51:47.967181+00	Aldershot	Worldwide Archaeology
1667	2012-09-21 16:51:47.967181+00	London	Wykeham
1668	2012-09-21 16:51:47.967181+00	London	Yale University Press
1669	2012-09-21 16:51:47.967181+00	New Haven	Yale University Press
1671	2012-09-21 16:51:47.967181+00	York	York Archaeological Trust
1672	2012-09-21 16:51:47.967181+00	London	York Archaeological Trust & Council for British Archaeology
1673	2012-09-21 16:51:47.967181+00	York	York Medieval Press
1676	2012-09-21 16:51:47.967181+00	York	York University Press
1677	2012-09-21 16:51:47.967181+00	Leeds	Yorkshire Archaeological Society
1679	2012-09-21 16:51:47.967181+00	Leeds	Yorkshire Archaeological Society, Prehistory Section
1680	2012-09-21 16:51:47.967181+00	Leeds	Yorkshire Archaeological Society, Roman Antiquities Section
1681	2012-09-21 16:51:47.967181+00	Leeds	Yorkshire Archaeological Society, Roman Antiquities Section & East Riding Archaeological Society
1683	2012-09-21 16:51:47.967181+00	Leeds	Yorkshire Geological Society
1685	2012-09-21 16:51:47.967181+00	York	Yorkshire Philosophical Society
1686	2012-09-21 16:51:47.967181+00	Lund	Zoological Institute
1687	2012-09-21 16:51:47.967181+00	Athens	École Française d'Athènes
1688	2012-09-21 16:51:47.967181+00	Reykjavík	Íslenzkt fornbréfasafn
1689	2012-09-21 16:51:47.967181+00	Reykjavík	Örn & Örlygur
1690	2012-09-21 16:51:47.967181+00	Vienna	Österreichischen Akademie der Wissenschaften
1691	2012-09-21 16:51:47.967181+00	Reykjavík	Þjódminjasafn Íslands
1692	2012-09-21 16:51:47.967181+00	Reykjavík	Þjódsaga
1693	2012-09-21 16:51:47.967181+00	Reykjavík	Þjóðminjasafn Íslands
1644	2012-09-21 16:51:47.967181+00	Gloucester	Western Archaeological Trust
1675	2012-09-21 16:51:47.967181+00	York	York University
9	2012-09-21 16:51:47.967181+00	Ilfracombe	A. H. Stockwell
1783	2012-09-21 16:51:47.967181+00	test	test
1785	2014-05-26 14:27:00.936+00	New York	Houghton Mifflin
1786	2014-05-26 14:27:00.936+00	London	Council for British Archaeology&Trust for Lincolnshire Archaeology
1787	2014-05-26 14:27:00.936+00	York	York Archaeological Trust
1788	2014-05-26 14:27:00.936+00	London	HMSO
1789	2014-05-26 14:27:00.936+00	Harmondsworth	Penguin
1790	2014-05-26 14:27:00.936+00	Peterborough	English Nature
1791	2014-05-26 14:27:00.936+00	Cairo	Atlas Press
1792	2014-05-26 14:27:00.936+00	Oxford	Oxford Archaeology
1793	2014-05-26 14:27:00.936+00	Belfast	Irish Naturalists'Journal Special entomological supplement
1794	2014-05-26 14:27:00.936+00	Howden	W. F. Pratt
1795	2014-05-26 14:27:00.936+00	Sheffield	Sheffield Academic Press
1796	2014-05-26 14:27:00.936+00	Washington D. C.	\N
1797	2014-05-26 14:27:00.936+00	Cheltenham	\N
1798	2014-05-26 14:27:00.936+00	Cambridge	Cambridge University Press
1799	2014-05-26 14:27:00.936+00	London	British Museum
1800	2014-05-26 14:27:00.936+00	Paris	Paul Lechevalier
1801	2014-05-26 14:27:00.936+00	London	\N
1802	2014-05-26 14:27:00.936+00	Cairo	Survey&Mines Department
1803	2014-05-26 14:27:00.936+00	Chichester	Wiley-Blackwell
1804	2014-05-26 14:27:00.936+00	Toronto	University of Toronto (unpubl.)
1916	2014-05-26 14:27:00.936+00	York	Sessions
1805	2014-05-26 14:27:00.936+00	Uppsala	ArtDatabanken, Sveriges lantbraksuniversitet (SLU)
1806	2014-05-26 14:27:00.936+00	Tucson	Radiocarbon
1807	2014-05-26 14:27:00.936+00	London	Quaternary Research Association
1808	2014-05-26 14:27:00.936+00	Lewes	Sussex Archaeological Society
1809	2014-05-26 14:27:00.936+00	Oxford	British Archaeological Reports
1810	2014-05-26 14:27:00.936+00	Harlow	Pearson Prentice Hall
1811	2014-05-26 14:27:00.936+00	London	Collins
1812	2014-05-26 14:27:00.936+00	London	Collins
1813	2014-05-26 14:27:00.936+00	Leiden	Brill
1814	2014-05-26 14:27:00.936+00	Leiden	Brill
1815	2014-05-26 14:27:00.936+00	Cambridge	Cambridge University Press
1816	2014-05-26 14:27:00.936+00	Copenhagen	Atuagkat
1817	2014-05-26 14:27:00.936+00	Munich	C.H.Beck
1818	2014-05-26 14:27:00.936+00	Munich	Spektrum Academic
1819	2014-05-26 14:27:00.936+00	Oxford	Oxford University Press
1820	2014-05-26 14:27:00.936+00	Oxford	Blackwell
1821	2014-05-26 14:27:00.936+00	Bath	Geological Society Special Report
1822	2014-05-26 14:27:00.936+00	London	Hodder Arnold
1823	2014-05-26 14:27:00.936+00	London	Faber&Faber
1824	2014-05-26 14:27:00.936+00	\N	Birlinn
1825	2014-05-26 14:27:00.936+00	London	Collins
1826	2014-05-26 14:27:00.936+00	Lincoln	Society for medieval archaeology
1827	2014-05-26 14:27:00.936+00	Oxford	Privately Published
1828	2014-05-26 14:27:00.936+00	Oxford	British Archaeological Reports
1829	2014-05-26 14:27:00.936+00	London	Quaternary Research Association
1830	2014-05-26 14:27:00.936+00	Harvard	Bulletin of the Museum of Comparative Zoology
1831	2014-05-26 14:27:00.936+00	Lund	Carl Bloms
1832	2014-05-26 14:27:00.936+00	Melbourne	Inkata Press
1833	2014-05-26 14:27:00.936+00	London	Council for British Archaeology&York Archaeological Trust
1834	2014-05-26 14:27:00.936+00	Birmingham	Dept. of Geography, University of Birmingham
1835	2014-05-26 14:27:00.936+00	Oxford	British Archaeological Reports 148
1836	2014-05-26 14:27:00.936+00	Oxford	British Archaeological Reports
1837	2014-05-26 14:27:00.936+00	Umeå	Dept. of Archaeology&Sámi Studies, Umeå University
1838	2014-05-26 14:27:00.936+00	Cardiff	National Museum of Wales
1839	2014-05-26 14:27:00.936+00	London	Methuen
1840	2014-05-26 14:27:00.936+00	Fontainebleau	Association des Naturalistes de la Vallée du Loing et du Massif de Fontainebleau
1841	2014-05-26 14:27:00.936+00	Cologne	Rheinland
1842	2014-05-26 14:27:00.936+00	Nottingham	J&H Bell for Nottingham Naturalists'Society
1843	2014-05-26 14:27:00.936+00	Lampeter	Dept. of Archaeology, St David's University College, Lampeter
1844	2014-05-26 14:27:00.936+00	London	Council for British Archaeology Research Report
1845	2014-05-26 14:27:00.936+00	Thorne	\N
1846	2014-05-26 14:27:00.936+00	Oxford	British Archaeological Reports British Series
1847	2014-05-26 14:27:00.936+00	St Albans	Sumach Press
1848	2014-05-26 14:27:00.936+00	Newton Abbot	David&Charles
1849	2014-05-26 14:27:00.936+00	London	Quaternary Research Association
1850	2014-05-26 14:27:00.936+00	London	F. Warne&Co.
1851	2014-05-26 14:27:00.936+00	Amsterdam	Elsevier
1852	2014-05-26 14:27:00.936+00	Cambridge	Cambridge University Press
1853	2014-05-26 14:27:00.936+00	London	Methuen
1854	2014-05-26 14:27:00.936+00	London	British Museum (NH)
1855	2014-05-26 14:27:00.936+00	London	Blackwell
1856	2014-05-26 14:27:00.936+00	London	Faber&Faber
1857	2014-05-26 14:27:00.936+00	Hull	E. M. Cole
1858	2014-05-26 14:27:00.936+00	Chichester	Wiley
1859	2014-05-26 14:27:00.936+00	Klampenborg	Scandinavian Science Press
1860	2014-05-26 14:27:00.936+00	London	Methuen
1861	2014-05-26 14:27:00.936+00	Oxford	British Archaeological Reports
1862	2014-05-26 14:27:00.936+00	Leicester	University of Leicester Archaeological Services
1863	2014-05-26 14:27:00.936+00	London	Amateur Entomological Society
1864	2014-05-26 14:27:00.936+00	London	Amateur Entomologist Society
1865	2014-05-26 14:27:00.936+00	Newbury	Pisces
1866	2014-05-26 14:27:00.936+00	Edinburgh	Scottish Trust for Archaeological Research
1867	2014-05-26 14:27:00.936+00	New York	Hill&Wang
1868	2014-05-26 14:27:00.936+00	London	British Museum
1869	2014-05-26 14:27:00.936+00	London	Academic Press
1870	2014-05-26 14:27:00.936+00	London	Research Reports of the Society of Antiquaries of London
1871	2014-05-26 14:27:00.936+00	London	Research Reports of the Society of Antiquaries of London
1872	2014-05-26 14:27:00.936+00	\N	Society of Antiquaries of London Report
1873	2014-05-26 14:27:00.936+00	Cambridge	Quaternary Research Association
1874	2014-05-26 14:27:00.936+00	London	Collins
1875	2014-05-26 14:27:00.936+00	Paris	Masson
1876	2014-05-26 14:27:00.936+00	Oxford	British Archaeological Reports
1877	2014-05-26 14:27:00.936+00	London	Duckworth
1878	2014-05-26 14:27:00.936+00	Cambridge, Massachussetts	Harvard University Press
1879	2014-05-26 14:27:00.936+00	York	Council for British Archaeology Research Report
1880	2014-05-26 14:27:00.936+00	Cambridge	Cambridge University Press
1881	2014-05-26 14:27:00.936+00	London	Batsford
1882	2014-05-26 14:27:00.936+00	London	Batsford
1883	2014-05-26 14:27:00.936+00	York	The Yorkshire Museum
1884	2014-05-26 14:27:00.936+00	New York	Dover
1885	2014-05-26 14:27:00.936+00	Cambridge	Cambridge University Press
1886	2014-05-26 14:27:00.936+00	London	Archaeology of York 2/1. Council for British Archaeology for York Archaeological Trust
1887	2014-05-26 14:27:00.936+00	London	G.Routledge&Son
1888	2014-05-26 14:27:00.936+00	Cambridge	Cambridge University Press
1889	2014-05-26 14:27:00.936+00	Gainsville, Florida	Sandhill Crane Press
1890	2014-05-26 14:27:00.936+00	\N	Biological Records Centre
1891	2014-05-26 14:27:00.936+00	Lewes	Sussex Archaeological Society Monograph
1892	2014-05-26 14:27:00.936+00	Vitry-sur-Seine	NAP Editions
1893	2014-05-26 14:27:00.936+00	Vitry-sur-Seine	Verrières le Buisson
1894	2014-05-26 14:27:00.936+00	Scunthorpe	\N
1895	2014-05-26 14:27:00.936+00	Wells	Somerset Archaeological and Natural History Society
1896	2014-05-26 14:27:00.936+00	West Runton, Norfolk	A. G. Duff
1897	2014-05-26 14:27:00.936+00	Oxford	Blackwell
1898	2014-05-26 14:27:00.936+00	London	\N
1899	2014-05-26 14:27:00.936+00	Chichester	Quaternary Proceedings 7, J. Wiley&Sons
1900	2014-05-26 14:27:00.936+00	London	Academic Press
1901	2014-05-26 14:27:00.936+00	\N	Biological Records Centre
1902	2014-05-26 14:27:00.936+00	Stockholm	Artdatabanken
1903	2014-05-26 14:27:00.936+00	Ambleside	Freshwater Biological Association
1904	2014-05-26 14:27:00.936+00	New York	Garland
1905	2014-05-26 14:27:00.936+00	Slough	Richmond Publ. Co.
1906	2014-05-26 14:27:00.936+00	Sheffield	Sheffield University Press
1907	2014-05-26 14:27:00.936+00	London	British Museum (NH)
1908	2014-05-26 14:27:00.936+00	Stroud	Sutton
1909	2014-05-26 14:27:00.936+00	London	Paul Elek
1910	2014-05-26 14:27:00.936+00	London	Elek
1911	2014-05-26 14:27:00.936+00	London	BCA
1912	2014-05-26 14:27:00.936+00	London	Routledge
1913	2014-05-26 14:27:00.936+00	Dorchester	Dorset Natural History&Archaeological Society
1914	2014-05-26 14:27:00.936+00	London	Routledge
1915	2014-05-26 14:27:00.936+00	Birmingham	Stratford-upon-Avon Council
1917	2014-05-26 14:27:00.936+00	Slough	Richmond Publishing Co.
1918	2014-05-26 14:27:00.936+00	Peterborough	Joint Nature Conservancy Council
1919	2014-05-26 14:27:00.936+00	Peterborough	UK Joint Nature Conservation Committee
1920	2014-05-26 14:27:00.936+00	Preston Montfort	Field Studies Council for the Royal Entomological Society.
2229	2014-05-26 14:27:00.936+00	Andover	Intercept
1921	2014-05-26 14:27:00.936+00	London	Royal Entomological Society of London
1922	2014-05-26 14:27:00.936+00	Leeds	Yorkshire Archaeological Report
1923	2014-05-26 14:27:00.936+00	Krefeld	Goecke&Evers
1924	2014-05-26 14:27:00.936+00	Krefeld	Goecke&Evers Verlag
1925	2014-05-26 14:27:00.936+00	Krefeld	Goecke&Evers
1926	2014-05-26 14:27:00.936+00	Stanley	Report to the Deptartment of Agriculture, Falkland Islands Government
1927	2014-05-26 14:27:00.936+00	London	HMSO
1928	2014-05-26 14:27:00.936+00	Lund	Dept. of Quaternary Geology, Lund University
1929	2014-05-26 14:27:00.936+00	Monks Wood, Huntingdon	Biological Records Centre
1930	2014-05-26 14:27:00.936+00	Oxford	British Archaeological Reports 134
1931	2014-05-26 14:27:00.936+00	Cambridge	Cambridge University Press
1932	2014-05-26 14:27:00.936+00	Cambridge	Cambridge University Press
1933	2014-05-26 14:27:00.936+00	London	Batsford
1934	2014-05-26 14:27:00.936+00	Colchester	Benham&Co.
1935	2014-05-26 14:27:00.936+00	Oxford	\N
1936	2014-05-26 14:27:00.936+00	Cambridge	Cambridge University Press
1937	2014-05-26 14:27:00.936+00	Oxford	British Archaeological Reports
1938	2014-05-26 14:27:00.936+00	Lancaster	Lancaster University Archaeological Unit
1939	2014-05-26 14:27:00.936+00	Oxford	Oxford University Press
1940	2014-05-26 14:27:00.936+00	Edinburgh	HMSO
1941	2014-05-26 14:27:00.936+00	Leiden	Scandinavian Science Press
1942	2014-05-26 14:27:00.936+00	Stenstrup	Apollo Books
1943	2014-05-26 14:27:00.936+00	London	Octopus Books
1944	2014-05-26 14:27:00.936+00	Huntingdon	Institute of Terrestrial Ecology
1945	2014-05-26 14:27:00.936+00	London	Pelham Books
1946	2014-05-26 14:27:00.936+00	Oxford	British Archaeological Reports
1947	2014-05-26 14:27:00.936+00	\N	Brill
1948	2014-05-26 14:27:00.936+00	Oslo	Oslo University Press
1949	2014-05-26 14:27:00.936+00	Cambridge	Cambridge University Press
1950	2014-05-26 14:27:00.936+00	London	Hutchinson
1951	2014-05-26 14:27:00.936+00	Portland, Oregon	Timber Press
1952	2014-05-26 14:27:00.936+00	London	BMNH
1953	2014-05-26 14:27:00.936+00	Peterborough	English Nature
1954	2014-05-26 14:27:00.936+00	Reading	British Entomological and Natural History Society
1955	2014-05-26 14:27:00.936+00	London	Council for British Archaeology Research Report 33
1956	2014-05-26 14:27:00.936+00	Munich	G. Frey
1957	2014-05-26 14:27:00.936+00	Uberlingen-Bodensee	\N
1958	2014-05-26 14:27:00.936+00	Uberlingen-Bodensee	\N
1959	2014-05-26 14:27:00.936+00	London	A. Linde
1960	2014-05-26 14:27:00.936+00	\N	PELtrash Vanity Publications
1961	2014-05-26 14:27:00.936+00	Telford	Field Studies Council
1962	2014-05-26 14:27:00.936+00	Zlin	Kabourek
1963	2014-05-26 14:27:00.936+00	Zlín	Nakladatelstí Kabourek,
1964	2014-05-26 14:27:00.936+00	Oslo	Norwegian Council for Science and the Humanities
1965	2014-05-26 14:27:00.936+00	London	British Museum
1966	2014-05-26 14:27:00.936+00	Oxford	Blackwell
1967	2014-05-26 14:27:00.936+00	Birmingham	University of Birmingham
1968	2014-05-26 14:27:00.936+00	Cambridge	Cambridge University Press
1969	2014-05-26 14:27:00.936+00	Nuuk	Pinngortitaleriffi k, Grønlands, Naturinstitut
1970	2014-05-26 14:27:00.936+00	London	Council for British Archaeology
1971	2014-05-26 14:27:00.936+00	Southampton	Southampton University Archaeological Society
1972	2014-05-26 14:27:00.936+00	\N	Føroya Skúlabókagunnur
1973	2014-05-26 14:27:00.936+00	London	Academic Press
1974	2014-05-26 14:27:00.936+00	Oxford	Blackwell
1975	2014-05-26 14:27:00.936+00	London	Falklands Conservation
1976	2014-05-26 14:27:00.936+00	Stanley	Falklands Conservation/Darwin Initiative
1977	2014-05-26 14:27:00.936+00	Reading, Massachussetts	Addison-Wesley
1978	2014-05-26 14:27:00.936+00	London	Arnold
1979	2014-05-26 14:27:00.936+00	Oxford	Oxford University Committee for Archaeology
1980	2014-05-26 14:27:00.936+00	London	Chapman&Hall
1981	2014-05-26 14:27:00.936+00	London	Council for British Archaeology for York Archaeological Trust
1982	2014-05-26 14:27:00.936+00	London	Society of Antiquaries of London Research Report
1983	2014-05-26 14:27:00.936+00	Harmondsworth	Penguin
1984	2014-05-26 14:27:00.936+00	London	Adlard&Son
1985	2014-05-26 14:27:00.936+00	London	Pennsylvania State University Press
1986	2014-05-26 14:27:00.936+00	London	Longman, Green, Longman&Roberts
1987	2014-05-26 14:27:00.936+00	Stockport	\N
1988	2014-05-26 14:27:00.936+00	London	Royal Entomological Society of London
1989	2014-05-26 14:27:00.936+00	London	Royal Entomological Society of London
1990	2014-05-26 14:27:00.936+00	Nottingham	Trent&Peak Archaeological Trust
1991	2014-05-26 14:27:00.936+00	Newton Abbott	David&Charles
1992	2014-05-26 14:27:00.936+00	Harlow	Addison Wesley Longman
1993	2014-05-26 14:27:00.936+00	Stockholm	National Heritage Board
1994	2014-05-26 14:27:00.936+00	Zlin	Kabourek
1995	2014-05-26 14:27:00.936+00	London	BCA
1996	2014-05-26 14:27:00.936+00	Gloucester	Western Archaeological Trust Monograph
1997	2014-05-26 14:27:00.936+00	Hartlepool	\N
1998	2014-05-26 14:27:00.936+00	Lancaster	Lancaster University Archaeological Unit
1999	2014-05-26 14:27:00.936+00	Lancaster	\N
2000	2014-05-26 14:27:00.936+00	Oxford	Clarendon Press
2001	2014-05-26 14:27:00.936+00	Oxford	Oxbow Books
2002	2014-05-26 14:27:00.936+00	London	Royal Entomological Society of London
2003	2014-05-26 14:27:00.936+00	Helsinki	\N
2004	2014-05-26 14:27:00.936+00	London	Royal Entomological Society of London
2005	2014-05-26 14:27:00.936+00	Leiden	E.J.Brill
2006	2014-05-26 14:27:00.936+00	Krefeld	Goecke&Evers
2007	2014-05-26 14:27:00.936+00	Krefeld	Goecke&Evers
2008	2014-05-26 14:27:00.936+00	Krefeld	Goecke&Evers
2009	2014-05-26 14:27:00.936+00	Shrewsbury	Field Studies Council
2010	2014-05-26 14:27:00.936+00	London	Longman
2011	2014-05-26 14:27:00.936+00	Cincinnati	US environmental Protection Agency
2012	2014-05-26 14:27:00.936+00	Monks Wood	Centre for Ecology&Hydrology
2013	2014-05-26 14:27:00.936+00	St Albans	Royal Entomological Society of London&Field Studies Council
2014	2014-05-26 14:27:00.936+00	Stockholm	Naturhistoriska Riksmuseet
2015	2014-05-26 14:27:00.936+00	The Hague	Government Publications Office
2016	2014-05-26 14:27:00.936+00	Newcastle-upon-Tyne	Dept. of Geography, University of Newcastle-upon-Tyne Seminar Paper 55
2017	2014-05-26 14:27:00.936+00	London	Collins
2018	2014-05-26 14:27:00.936+00	The Hague	W. Junk
2019	2014-05-26 14:27:00.936+00	Newcastle upon Tyne	Newcastle University
2020	2014-05-26 14:27:00.936+00	London	British Museum Press
2021	2014-05-26 14:27:00.936+00	Reading	University of Reading
2022	2014-05-26 14:27:00.936+00	Colchester	Harley Books
2023	2014-05-26 14:27:00.936+00	Edinburgh	Berlin Repr. (1994)
2024	2014-05-26 14:27:00.936+00	Cardiff	National Museum of Wales
2025	2014-05-26 14:27:00.936+00	London	Routledge
2026	2014-05-26 14:27:00.936+00	Oxford	Blackwell
2027	2014-05-26 14:27:00.936+00	Cambridge	McDonald Institute Monograph
2028	2014-05-26 14:27:00.936+00	York	PLACE Occasional Paper 1, College of Ripon&York St. John
2029	2014-05-26 14:27:00.936+00	Oxford	British Archaeological Reports International Series
2030	2014-05-26 14:27:00.936+00	Doncaster	W. Sheardown
2031	2014-05-26 14:27:00.936+00	London	Geological Society of London Report 4
2032	2014-05-26 14:27:00.936+00	London	\N
2033	2014-05-26 14:27:00.936+00	London	British Museum (Natural History)
2034	2014-05-26 14:27:00.936+00	London	T.Murby
2035	2014-05-26 14:27:00.936+00	London	Royal Entomological Society of London
2036	2014-05-26 14:27:00.936+00	London	Royal Entomological Society of London
2037	2014-05-26 14:27:00.936+00	London	Royal Entomological Society&Field Studies Council
2038	2014-05-26 14:27:00.936+00	St Albans	Royal Entomological Society&Field Studies Council
2039	2014-05-26 14:27:00.936+00	London	Quaternary Research Association
2040	2014-05-26 14:27:00.936+00	Oxford	Pergamon Press
2041	2014-05-26 14:27:00.936+00	London	British Museum
2042	2014-05-26 14:27:00.936+00	Leiden	E. J. Brill
2043	2014-05-26 14:27:00.936+00	Philadelphia	Lea&Febiger
2044	2014-05-26 14:27:00.936+00	London	Octopus
2045	2014-05-26 14:27:00.936+00	Stroud	Sutton Publ.
2046	2014-05-26 14:27:00.936+00	York	Council for British Archaeology for York Archaeological Trust
2047	2014-05-26 14:27:00.936+00	Reykjavík	Fjölrit Náttúrufræðistofnunar 17
2048	2014-05-26 14:27:00.936+00	Reykjavík	Náttúrufrædistofnun Íslands
2049	2014-05-26 14:27:00.936+00	London	New Naturalist Series, Collins
2050	2014-05-26 14:27:00.936+00	Nottingham	Nottingham University Press
2051	2014-05-26 14:27:00.936+00	London	Longmans, Green&Co.
2052	2014-05-26 14:27:00.936+00	Folkestone	Archon Books, Dawson
2053	2014-05-26 14:27:00.936+00	London	English Universities Press
2054	2014-05-26 14:27:00.936+00	London	Council for British Archaeology
2055	2014-05-26 14:27:00.936+00	London.	Chapman and Hall
2056	2014-05-26 14:27:00.936+00	London	RCHME/HMSO
2057	2014-05-26 14:27:00.936+00	London	RCHME/HMSO
2058	2014-05-26 14:27:00.936+00	York	Publ. Privately
2059	2014-05-26 14:27:00.936+00	\N	Field Studies Council
2060	2014-05-26 14:27:00.936+00	Dordrecht	Chapman&Hall
2061	2014-05-26 14:27:00.936+00	Oxford	Discussions in Egyptology Special No.
2062	2014-05-26 14:27:00.936+00	Richmond	Richmond Publishing Co.
2063	2014-05-26 14:27:00.936+00	London	Council for British Archaeology Research Report
2064	2014-05-26 14:27:00.936+00	London	J M Dent&Sons
2065	2014-05-26 14:27:00.936+00	London	Harper Collins
2066	2014-05-26 14:27:00.936+00	London	Council for British Archaeology Research Report
2067	2014-05-26 14:27:00.936+00	London	Society for Medieval Archaeology Monograph 3
2068	2014-05-26 14:27:00.936+00	London	HMSO
2069	2014-05-26 14:27:00.936+00	London	HMSO
2070	2014-05-26 14:27:00.936+00	London	HMSO
2071	2014-05-26 14:27:00.936+00	London	MacMillan
2072	2014-05-26 14:27:00.936+00	Tucson	University of Arizona Press
2073	2014-05-26 14:27:00.936+00	London	Society of Antiquaries of London
2074	2014-05-26 14:27:00.936+00	Karlsruhe	LUBW Landesanstalt für Umwelt, Messungen und Naturschultz Baden-Württemberg
2075	2014-05-26 14:27:00.936+00	Oxford	University of Durham Ridell Memorial Lecture, Oxford University Press
2076	2014-05-26 14:27:00.936+00	Stroud	Sutton
2077	2014-05-26 14:27:00.936+00	Wakefield	West Yorkshire Archaeological Services
2078	2014-05-26 14:27:00.936+00	London	British Museum (NH)
2079	2014-05-26 14:27:00.936+00	Leeds	Yorkshire Archaeological Society
2080	2014-05-26 14:27:00.936+00	London	Batsford
2081	2014-05-26 14:27:00.936+00	Cambridge	Cambridge University Press
2082	2014-05-26 14:27:00.936+00	London.	Collins
2083	2014-05-26 14:27:00.936+00	Shrewbury	Field Studies Council
2084	2014-05-26 14:27:00.936+00	London	Duckworth
2085	2014-05-26 14:27:00.936+00	Cambridge	Cambnridge University Press
2086	2014-05-26 14:27:00.936+00	London	Collins
2087	2014-05-26 14:27:00.936+00	Oxford	\N
2088	2014-05-26 14:27:00.936+00	London	Quaternary Research Association
2089	2014-05-26 14:27:00.936+00	London	Allen&Unwin
2090	2014-05-26 14:27:00.936+00	London	Routledge
2091	2014-05-26 14:27:00.936+00	Peterborough	Nature Conservancy Council
2092	2014-05-26 14:27:00.936+00	London	Edward Arnold
2093	2014-05-26 14:27:00.936+00	Edinburgh	Edinburgh University Press
2094	2014-05-26 14:27:00.936+00	Dordrecht	W. Junk
2095	2014-05-26 14:27:00.936+00	Preston Mountford	Fields Study Council
2096	2014-05-26 14:27:00.936+00	Oxford	British Archaeological Reports
2097	2014-05-26 14:27:00.936+00	London	Academic Press
2098	2014-05-26 14:27:00.936+00	London	Geological Society of London
2099	2014-05-26 14:27:00.936+00	Oxford	British Archaeological Reports
2100	2014-05-26 14:27:00.936+00	London	British Museum (Natural History)
2101	2014-05-26 14:27:00.936+00	London	British Museum (NH)
2102	2014-05-26 14:27:00.936+00	London	Royal Entomological Society of London Handbooks for the Identification of British Insects
2103	2014-05-26 14:27:00.936+00	London	Royal Entomological Society of London
2104	2014-05-26 14:27:00.936+00	Buffalo, NY	Buffalo Museum of Science
2105	2014-05-26 14:27:00.936+00	London	Egypt Exploration Society
2106	2014-05-26 14:27:00.936+00	London	Batsford
2107	2014-05-26 14:27:00.936+00	London	Chapman&Hall
2108	2014-05-26 14:27:00.936+00	London	Chapman&Hall
2109	2014-05-26 14:27:00.936+00	London	Longmans
2110	2014-05-26 14:27:00.936+00	London	Bohn
2111	2014-05-26 14:27:00.936+00	Oxford	Oxford University Press
2112	2014-05-26 14:27:00.936+00	London	HMSO
2113	2014-05-26 14:27:00.936+00	Oxford	Oxbow
2114	2014-05-26 14:27:00.936+00	London	Longman, Orme Brown, Green&Longmans
2115	2014-05-26 14:27:00.936+00	Gillingham, Dorset	British Wildlife Publishing
2116	2014-05-26 14:27:00.936+00	Reading	British entomological and natural history society
2117	2014-05-26 14:27:00.936+00	\N	Chiswick Press
2118	2014-05-26 14:27:00.936+00	Oxford	Geological Society Special Publication 21, Blackwell
2119	2014-05-26 14:27:00.936+00	Oxford	OUCA Monograph
2120	2014-05-26 14:27:00.936+00	London	Society of Antiquaries of London
2121	2014-05-26 14:27:00.936+00	London	Duckworth
2122	2014-05-26 14:27:00.936+00	London	Collins
2123	2014-05-26 14:27:00.936+00	Baltimore, USA	Baltimore Entomological Society
2124	2014-05-26 14:27:00.936+00	London	Cambridge University  Press
2125	2014-05-26 14:27:00.936+00	London	Research Reports of the Society of Antiquaries of London 25
2126	2014-05-26 14:27:00.936+00	London	Longman
2127	2014-05-26 14:27:00.936+00	Warsaw	Natura optima dux
2128	2014-05-26 14:27:00.936+00	Cambridge	Cambridge University Press
2129	2014-05-26 14:27:00.936+00	Oxford	British Archaeological Reports
2130	2014-05-26 14:27:00.936+00	\N	Camerton Excavation Club
2131	2014-05-26 14:27:00.936+00	St. Albans	Royal Entomological Society&Field Studies Council
2132	2014-05-26 14:27:00.936+00	London	Quaternary Research Association
2133	2014-05-26 14:27:00.936+00	Aberdeen	Dept. of Geography, University of Aberdeen
2134	2014-05-26 14:27:00.936+00	Barnsley	Wharncliffe Publishing
2135	2014-05-26 14:27:00.936+00	Stroud	Tempus
2136	2014-05-26 14:27:00.936+00	Faversham	Kent Archaeological Field School
2137	2014-05-26 14:27:00.936+00	Tucson	University of Arizona Press
2138	2014-05-26 14:27:00.936+00	Cambridge	Cambridge University Press
2139	2014-05-26 14:27:00.936+00	Vienna	\N
2140	2014-05-26 14:27:00.936+00	Belfast	HMSO
2141	2014-05-26 14:27:00.936+00	London	T&A D Poyser
2142	2014-05-26 14:27:00.936+00	Prague	Academia
2143	2014-05-26 14:27:00.936+00	Moscow	Pensoft
2144	2014-05-26 14:27:00.936+00	Chichester	Wiley&Sons
2145	2014-05-26 14:27:00.936+00	Lund	Lundqua Report
2146	2014-05-26 14:27:00.936+00	London	Duckworth
2147	2014-05-26 14:27:00.936+00	London	Interscience
2148	2014-05-26 14:27:00.936+00	Oxford	British Archaeological Reports S410
2149	2014-05-26 14:27:00.936+00	Nairobi	TILLMIAP
2150	2014-05-26 14:27:00.936+00	Iowa	Iowa University Press
2151	2014-05-26 14:27:00.936+00	Glasgow	Dept of Archaeology, University of Glasgow
2152	2014-05-26 14:27:00.936+00	Oxford	Oxbow Monograph
2153	2014-05-26 14:27:00.936+00	Glasgow	Dept of Archaeology, University of Glasgow
2154	2014-05-26 14:27:00.936+00	Edinburgh	HMSO
2155	2014-05-26 14:27:00.936+00	Ottawa	Biological Survey of Canada (Terrestrial Arthropods)
2156	2014-05-26 14:27:00.936+00	Chichester	John Wiley&Sons
2157	2014-05-26 14:27:00.936+00	Oxford	Quaternary Research Association
2158	2014-05-26 14:27:00.936+00	Chichester	Wiley&Sons
2159	2014-05-26 14:27:00.936+00	Dordrecht	Springer
2160	2014-05-26 14:27:00.936+00	Aarhus	Aarhus University Press
2161	2014-05-26 14:27:00.936+00	Dordrecht	Junk
2162	2014-05-26 14:27:00.936+00	Edinburgh	Edinburgh University Press
2163	2014-05-26 14:27:00.936+00	Oxford	Blackwell
2164	2014-05-26 14:27:00.936+00	\N	Kluwer
2165	2014-05-26 14:27:00.936+00	Edinburgh	Edinburgh University Press
2166	2014-05-26 14:27:00.936+00	Edinburgh	Edinburgh University Press
2167	2014-05-26 14:27:00.936+00	Leicester	Leicester University Press
2168	2014-05-26 14:27:00.936+00	Oxford	Pergamon
2169	2014-05-26 14:27:00.936+00	Copenhagen	Dansk Polar Centre&Danish National Museum
2170	2014-05-26 14:27:00.936+00	Edinburgh	Edinburgh University Press
2171	2014-05-26 14:27:00.936+00	Stockholm	Entomologiska Föreningen i Stockholm
2172	2014-05-26 14:27:00.936+00	Oxford	British Archaeological Reports
2173	2014-05-26 14:27:00.936+00	Oxford	Oxbow Books
2174	2014-05-26 14:27:00.936+00	Liverpool	Merseyside County Council
2175	2014-05-26 14:27:00.936+00	Rotterdam	Balkema
2176	2014-05-26 14:27:00.936+00	Oxford	British Archaeological Reports,
2177	2014-05-26 14:27:00.936+00	Lincoln	\N
2178	2014-05-26 14:27:00.936+00	Oxford	Oxbow Monograph
2179	2014-05-26 14:27:00.936+00	Edinburgh	Society of Antiquaries of Scotland
2180	2014-05-26 14:27:00.936+00	London	Society for Medieval Archaeology Monograph
2181	2014-05-26 14:27:00.936+00	Peterborough	English Nature Research Report
2182	2014-05-26 14:27:00.936+00	Oxford	Institute of British Geographers, Blackwell
2183	2014-05-26 14:27:00.936+00	Hull	Hull University Press
2184	2014-05-26 14:27:00.936+00	Copenhagen	Danish National Museum&Danish Polar Centre
2185	2014-05-26 14:27:00.936+00	Oxford	Institute of British Geographers, Blackwell
2186	2014-05-26 14:27:00.936+00	Oxford	Oxbow Books
2187	2014-05-26 14:27:00.936+00	Tórshavn	Annales Societatis Scientiarum Færoensis Suppl.
2188	2014-05-26 14:27:00.936+00	Tórshavn	Faroe University Press
2189	2014-05-26 14:27:00.936+00	Umeå	Dept. of Archaeology&Sami Studies, University of Umeå
2190	2014-05-26 14:27:00.936+00	Chichester	J. Wiley&Sons
2191	2014-05-26 14:27:00.936+00	Glasgow	Dept of Archaeology, University of Glasgow
2192	2014-05-26 14:27:00.936+00	Delhi	Pragati
2193	2014-05-26 14:27:00.936+00	Oxford	Blackwell
2194	2014-05-26 14:27:00.936+00	Oxford	Oxbow
2195	2014-05-26 14:27:00.936+00	London	Chapman&Hall
2196	2014-05-26 14:27:00.936+00	London	Council for British Archaeology Research Report 21
2197	2014-05-26 14:27:00.936+00	Rotterdam	Balkema
2198	2014-05-26 14:27:00.936+00	London	Chapman&Hall
2199	2014-05-26 14:27:00.936+00	Liverpool	Liverpool University Press
2200	2014-05-26 14:27:00.936+00	London	British Museum (NH)
2201	2014-05-26 14:27:00.936+00	Poznan	Polish Academy of Sciences
2202	2014-05-26 14:27:00.936+00	Oxford	Clarendon Press
2203	2014-05-26 14:27:00.936+00	London	Royal Archaeological Institute
2204	2014-05-26 14:27:00.936+00	Cambridge	Cambridge University Press
2205	2014-05-26 14:27:00.936+00	London	Chatto&Windus
2206	2014-05-26 14:27:00.936+00	Odense	Odense University Press
2207	2014-05-26 14:27:00.936+00	Chicago	University of Chicago Press
2208	2014-05-26 14:27:00.936+00	London	Chapman&Hall
2209	2014-05-26 14:27:00.936+00	Oxford	Pergamon
2210	2014-05-26 14:27:00.936+00	Edinburgh	HMSO
2211	2014-05-26 14:27:00.936+00	Manchester	Manchester University Press
2212	2014-05-26 14:27:00.936+00	Cambridge	Quaternary Research Association
2213	2014-05-26 14:27:00.936+00	London	Interscience
2214	2014-05-26 14:27:00.936+00	Oxford	Oxbow Books
2215	2014-05-26 14:27:00.936+00	Sheffield	Sheffield Academic Press
2216	2014-05-26 14:27:00.936+00	Poznan	Poznan Archaeological Museum
2217	2014-05-26 14:27:00.936+00	Krefeld	Goecke&Evers
2218	2014-05-26 14:27:00.936+00	Doncaster	Doncaster RDC
2219	2014-05-26 14:27:00.936+00	Lancaster	MTP Press
2220	2014-05-26 14:27:00.936+00	Oxford	British Archaeological Reports S146
2221	2014-05-26 14:27:00.936+00	Glasgow	Cruithne Press
2222	2014-05-26 14:27:00.936+00	Sheffield	Sheffield Academic Press
2223	2014-05-26 14:27:00.936+00	Chichester	J. Wiley&Sons
2224	2014-05-26 14:27:00.936+00	Reykjavík	Visindfelag Islendinga
2225	2014-05-26 14:27:00.936+00	Reykjavík	Visindfelag Islendinga
2226	2014-05-26 14:27:00.936+00	London	Chapman&Hall
2227	2014-05-26 14:27:00.936+00	Andover	Intercept
2228	2014-05-26 14:27:00.936+00	Tucson	Radiocarbon
2230	2014-05-26 14:27:00.936+00	Dordtrecht	D.Reidel
2231	2014-05-26 14:27:00.936+00	London	Egypt Exploration Society
2232	2014-05-26 14:27:00.936+00	London	Royal Meteorological Society
2233	2014-05-26 14:27:00.936+00	Cambridge	Cambridge University Press
2234	2014-05-26 14:27:00.936+00	\N	Kluwer Academic Press
2235	2014-05-26 14:27:00.936+00	Rotterdam	A. A. Balkmene
2236	2014-05-26 14:27:00.936+00	New York	Academic Press
2237	2014-05-26 14:27:00.936+00	Maidstone	Kent Archaeological Society
2238	2014-05-26 14:27:00.936+00	Oxford	British Archaeological Reports
2239	2014-05-26 14:27:00.936+00	York	York University Archaeological Publ.
2240	2014-05-26 14:27:00.936+00	London	Council for British Archaeology Research Report
2241	2014-05-26 14:27:00.936+00	London	British Museum Press
2242	2014-05-26 14:27:00.936+00	Chichester	Philimore
2243	2014-05-26 14:27:00.936+00	Oxford	British Archaeological Reports
2244	2014-05-26 14:27:00.936+00	London	Council for British Archaeology Research Report
2245	2014-05-26 14:27:00.936+00	Oxford	British Archaeological Reports,
2246	2014-05-26 14:27:00.936+00	The Hague	Junk
2247	2014-05-26 14:27:00.936+00	Umeå	University of Umeå Environmental Archaeology Laboratory, Dept. of Archaeology&Sami Studies
2248	2014-05-26 14:27:00.936+00	Oxford	British Archaeological Reports
2249	2014-05-26 14:27:00.936+00	Rotterdam	Balkema
2250	2014-05-26 14:27:00.936+00	The Hague	Dr. W. Junk
2251	2014-05-26 14:27:00.936+00	York	William Sessions
2252	2014-05-26 14:27:00.936+00	Oxford	British Archaeological Reports S173
2253	2014-05-26 14:27:00.936+00	London	Council for British Archaeology for York Archaeological Trust
2254	2014-05-26 14:27:00.936+00	London	Council for British Archaeology for York Archaeological Trust.
2255	2014-05-26 14:27:00.936+00	\N	Elsevier
2256	2014-05-26 14:27:00.936+00	London	Systematics Association Special Volume
2257	2014-05-26 14:27:00.936+00	Los Angeles	University of California Press
2258	2014-05-26 14:27:00.936+00	Edinburgh	Edinburgh University Press
2259	2014-05-26 14:27:00.936+00	Oxford	British Archaeological Reports
2260	2014-05-26 14:27:00.936+00	Rotterdam	Balkema
2261	2014-05-26 14:27:00.936+00	London	Society for Medieval Archaeology
2262	2014-05-26 14:27:00.936+00	\N	Boydell Press
2263	2014-05-26 14:27:00.936+00	\N	Elsevier
2264	2014-05-26 14:27:00.936+00	Rotterdam	Balkema
2265	2014-05-26 14:27:00.936+00	London	Quaternary Research Association
2266	2014-05-26 14:27:00.936+00	Chichester	J. Wiley&Sons
2267	2014-05-26 14:27:00.936+00	Stockholm	\N
2268	2014-05-26 14:27:00.936+00	Oxford	British Archaeological Reports 196(ii)
2269	2014-05-26 14:27:00.936+00	\N	Kluwer Academic Publ
2270	2014-05-26 14:27:00.936+00	Carlisle	Cumberland&Westmoreland Antiquarian&Archaeological Society and Society of Antiquaries of Newcastle upon Tyne
2271	2014-05-26 14:27:00.936+00	Oxford	British Archaeological Reports
2272	2014-05-26 14:27:00.936+00	Rotterdam	A.A. Balkema
2273	2014-05-26 14:27:00.936+00	Krefeld	Goecke&Evers
2274	2014-05-26 14:27:00.936+00	Oxford	Oxbow Books
2275	2014-05-26 14:27:00.936+00	London	Council for British Archaeology for York Archaeological Trust
2276	2014-05-26 14:27:00.936+00	Oslo	\N
2277	2014-05-26 14:27:00.936+00	Oxford	British Archaeological Reports S266
2278	2014-05-26 14:27:00.936+00	York	Council for British Archaeology  for York Archaeological Trust
2279	2014-05-26 14:27:00.936+00	Edinburgh	Scottish Trust for Archaeological Research.
2280	2014-05-26 14:27:00.936+00	London	Council for British Archaeology Research Report
2281	2014-05-26 14:27:00.936+00	Jerusalem	Israel Exploration Society&Hebrew University of Jerusalem
2282	2014-05-26 14:27:00.936+00	London	Council for British Archaeology Research Report
2283	2014-05-26 14:27:00.936+00	Poznan	Poznan Archaeological Museum
2284	2014-05-26 14:27:00.936+00	Poznan	Poznan Archaeological Museum
2285	2014-05-26 14:27:00.936+00	The Hague	Junk
2286	2014-05-26 14:27:00.936+00	Stockholm	\N
2287	2014-05-26 14:27:00.936+00	Copenhagen	Det Danske Met. Inst.
2288	2014-05-26 14:27:00.936+00	Peterborough	English Nature
2289	2014-05-26 14:27:00.936+00	Lund	\N
2290	2014-05-26 14:27:00.936+00	Lund	Lund University Press
2291	2014-05-26 14:27:00.936+00	Umeå	Environmental Archaeology Laboratory, Dept. of Archaeology&Sami Studies, University of Umeå
2292	2014-05-26 14:27:00.936+00	Chichester	John Wiley&Sons
2293	2014-05-26 14:27:00.936+00	Oxford	Pergamon
2294	2014-05-26 14:27:00.936+00	Poznan	Poznan Archaeological Museum
2295	2014-05-26 14:27:00.936+00	Chichester	J. Wiley
2296	2014-05-26 14:27:00.936+00	London	Geological Society
2297	2014-05-26 14:27:00.936+00	Andover	Intercept
2298	2014-05-26 14:27:00.936+00	\N	Zookeys
2299	2014-05-26 14:27:00.936+00	Edinburgh	Edinburgh University Press
2300	2014-05-26 14:27:00.936+00	London	Routledge
2301	2014-05-26 14:27:00.936+00	Oulu	University of Oulu
2302	2014-05-26 14:27:00.936+00	Leiden	Brill
2303	2014-05-26 14:27:00.936+00	London	Cambridge University Press
2304	2014-05-26 14:27:00.936+00	Aberystwyth	University College of Wales Aberystwyth Memoranda 8
2305	2014-05-26 14:27:00.936+00	Aberystwyth	Cambrian News
2306	2014-05-26 14:27:00.936+00	Oxford	\N
2307	2014-05-26 14:27:00.936+00	Montreal	McGill-Queen's University Press
2308	2014-05-26 14:27:00.936+00	New York	John Wiley&Sons
2309	2014-05-26 14:27:00.936+00	Chicago	Aldine Publishing Company.
2310	2014-05-26 14:27:00.936+00	Leiden	E. J. Brill
2311	2014-05-26 14:27:00.936+00	London	Geological  Society
2312	2014-05-26 14:27:00.936+00	Cambridge	Cambridge University Press
2313	2014-05-26 14:27:00.936+00	Oxford	British Archaeological Reports International Series S227
2314	2014-05-26 14:27:00.936+00	Yellowknife	Prince of Wales Northern Heritage Centre Archaeological Report
2315	2014-05-26 14:27:00.936+00	Tórshavn	Annales Societatis Scientarum Færoensis Suppl. XLIV
2316	2014-05-26 14:27:00.936+00	Oxford	Pergamon
2317	2014-05-26 14:27:00.936+00	\N	Research Reports of the Society of Antiquaries of London 27
2318	2014-05-26 14:27:00.936+00	Oxford	British Archaeological Reports
2319	2014-05-26 14:27:00.936+00	Cardiff	University of Wales Press
2320	2014-05-26 14:27:00.936+00	Edinburgh	Edinburgh University Press
2321	2014-05-26 14:27:00.936+00	London	English Heritage
2322	2014-05-26 14:27:00.936+00	York	Council for British Archaeology Research Report
2323	2014-05-26 14:27:00.936+00	Oxford	Blackwell
2324	2014-05-26 14:27:00.936+00	London	Egypt Exploration Society
2325	2014-05-26 14:27:00.936+00	Aberystwyth	Cambrian News
2326	2014-05-26 14:27:00.936+00	Leeds	Yorkshire Geological Society
2433	2014-05-26 14:27:00.936+00	Stenstrup	Apollo books
2327	2014-05-26 14:27:00.936+00	Edinburgh	The Scottish Society for Northern Studies. Occasional Publications 2
2328	2014-05-26 14:27:00.936+00	Monks Wood	NERC
2329	2014-05-26 14:27:00.936+00	London	Council for British Archaeology
2330	2014-05-26 14:27:00.936+00	London	Egypt Exploration Society
2331	2014-05-26 14:27:00.936+00	\N	SEESOIL 3
2332	2014-05-26 14:27:00.936+00	Oxford	British Archaeological Reports 48
2333	2014-05-26 14:27:00.936+00	Oxford	British Archaeological Reports
2334	2014-05-26 14:27:00.936+00	York	Council for British Archaeology Research Report
2335	2014-05-26 14:27:00.936+00	Oxford	Oxbow Monographs
2336	2014-05-26 14:27:00.936+00	London	English Heritage Archaeological Report
2337	2014-05-26 14:27:00.936+00	Oxford	Oxbow Books
2338	2014-05-26 14:27:00.936+00	London	British Museum
2339	2014-05-26 14:27:00.936+00	Oxford	Oxford Archaeology, Thames Valley landscapes Monograph
2340	2014-05-26 14:27:00.936+00	London	Council for British Archaeology Research Report
2341	2014-05-26 14:27:00.936+00	London	Council for British Archaeology Research Report 32
2342	2014-05-26 14:27:00.936+00	Oxford	British Archaeological Reports
2343	2014-05-26 14:27:00.936+00	London	British Museum Press
2344	2014-05-26 14:27:00.936+00	Chichester	Wiley&sons
2345	2014-05-26 14:27:00.936+00	London	British Archaeological Association Transactions
2346	2014-05-26 14:27:00.936+00	Sheffield	Sheffield Academic Press
2347	2014-05-26 14:27:00.936+00	London	Academic Press
2348	2014-05-26 14:27:00.936+00	Chichester	J. Wiley&Sons
2349	2014-05-26 14:27:00.936+00	Andover	Intercept
2350	2014-05-26 14:27:00.936+00	Rotterdam	Balkema
2351	2014-05-26 14:27:00.936+00	Oxford	British Archaeological Reports
2352	2014-05-26 14:27:00.936+00	Cambridge	Cambridge University Press
2353	2014-05-26 14:27:00.936+00	Oxford	British Archaeological Reports S146
2354	2014-05-26 14:27:00.936+00	Oxford	Oxbow Monographs
2355	2014-05-26 14:27:00.936+00	London	Council for British Archaeology Research Report 21
2356	2014-05-26 14:27:00.936+00	Oxford	Pergamon Press
2357	2014-05-26 14:27:00.936+00	Oxford	Blackwell
2358	2014-05-26 14:27:00.936+00	London	British Museum
2359	2014-05-26 14:27:00.936+00	London	Cambridge University Press
2360	2014-05-26 14:27:00.936+00	London	Council for British Archaeology Research Report 11
2361	2014-05-26 14:27:00.936+00	Oxford	British Archaeological Reports 89
2362	2014-05-26 14:27:00.936+00	Oxford	Oxbow Books
2363	2014-05-26 14:27:00.936+00	York	Council for British Archaeology Research Report
2364	2014-05-26 14:27:00.936+00	Oxford	British Archaeological Reports 158
2365	2014-05-26 14:27:00.936+00	London	Academic Press
2366	2014-05-26 14:27:00.936+00	Andover	Intercept Ltd.
2367	2014-05-26 14:27:00.936+00	Oxford	Clarendon Press
2368	2014-05-26 14:27:00.936+00	Wakefield	Yorkshire Archaeology 3. West Yorkshire Archaeology Service
2369	2014-05-26 14:27:00.936+00	Reykjavík	Þjóðminjasafn Íslands
2370	2014-05-26 14:27:00.936+00	London	Institute of Biology
2371	2014-05-26 14:27:00.936+00	Boston	\N
2372	2014-05-26 14:27:00.936+00	Lisbon	\N
2373	2014-05-26 14:27:00.936+00	Dordrecht	D. Reidel
2374	2014-05-26 14:27:00.936+00	Aarhus	Aarhus University press
2375	2014-05-26 14:27:00.936+00	Warsaw	\N
2376	2014-05-26 14:27:00.936+00	London	Duckworth
2377	2014-05-26 14:27:00.936+00	Rahden, Westphalia	Marie Leidorf
2378	2014-05-26 14:27:00.936+00	Dordrecht	Springer
2379	2014-05-26 14:27:00.936+00	Rotterdam	Balkema
2380	2014-05-26 14:27:00.936+00	Chichester	J Wiley&Sons
2381	2014-05-26 14:27:00.936+00	London	Academic Press
2382	2014-05-26 14:27:00.936+00	Oxford	Oxbow Books
2383	2014-05-26 14:27:00.936+00	London	Academic Press
2384	2014-05-26 14:27:00.936+00	Rotterdam	A. A. Balkema
2385	2014-05-26 14:27:00.936+00	Edinburgh	Forestry Commission Technical Paper
2386	2014-05-26 14:27:00.936+00	Copenhagen	Hölst&Son
2387	2014-05-26 14:27:00.936+00	Chichester	John Wiley&Sons
2388	2014-05-26 14:27:00.936+00	Rotterdam	A.A.Balkema
2389	2014-05-26 14:27:00.936+00	Oxford	Blackwell
2390	2014-05-26 14:27:00.936+00	\N	Netherlands Foundation for Archaeological Research, Egypt
2391	2014-05-26 14:27:00.936+00	Glasgow	Dept. of Archaeology, University of Glasgow
2392	2014-05-26 14:27:00.936+00	\N	Kluwer Academic
2393	2014-05-26 14:27:00.936+00	Stockholm	Birka Project
2394	2014-05-26 14:27:00.936+00	London	Geological Society
2395	2014-05-26 14:27:00.936+00	Sofia	Pensoft
2396	2014-05-26 14:27:00.936+00	Heidelberg	Spektrum Akademischer
2397	2014-05-26 14:27:00.936+00	London	Leicester University Press
2398	2014-05-26 14:27:00.936+00	Chichester	J Wiley&Sons
2399	2014-05-26 14:27:00.936+00	Oxford	Oxbow Books
2400	2014-05-26 14:27:00.936+00	London	Quaternary Research Association
2401	2014-05-26 14:27:00.936+00	Oxford	Oxbow Books
2402	2014-05-26 14:27:00.936+00	Oxford	British Archaeological Reports
2403	2014-05-26 14:27:00.936+00	Lancaster	Lancaster Imprints
2404	2014-05-26 14:27:00.936+00	Oxford	British Archaeological Reports
2405	2014-05-26 14:27:00.936+00	Leicester	Leicester Archaeology Monograph
2406	2014-05-26 14:27:00.936+00	Lancaster	Lancaster Imprints
2407	2014-05-26 14:27:00.936+00	Wells	A. G. Duff
2408	2014-05-26 14:27:00.936+00	Iver	Pemberley Books
2409	2014-05-26 14:27:00.936+00	Oxford	Tempus Reparatum / B.A.R. British Series
2410	2014-05-26 14:27:00.936+00	Krefeld	Goecke&Evers
2411	2014-05-26 14:27:00.936+00	Krefeld	Goecke&Evers
2412	2014-05-26 14:27:00.936+00	Krefeld	Goecke&Evers
2413	2014-05-26 14:27:00.936+00	Krefeld	Goecke&Evers
2414	2014-05-26 14:27:00.936+00	Krefeld	Goecke&Evers
2415	2014-05-26 14:27:00.936+00	Krefeld	Goecke&Evers
2416	2014-05-26 14:27:00.936+00	Krefeld	Goecke&Evers
2417	2014-05-26 14:27:00.936+00	Krefeld	Goecke&Evers
2418	2014-05-26 14:27:00.936+00	Krefeld	Goecke&Evers
2419	2014-05-26 14:27:00.936+00	Krefeld	Goecke&Evers
2420	2014-05-26 14:27:00.936+00	Krefeld	Goecke&Evers
2421	2014-05-26 14:27:00.936+00	Krefeld	Goecke&Evers
2422	2014-05-26 14:27:00.936+00	Uppsala	ArtDatabanken SLU
2423	2014-05-26 14:27:00.936+00	Sheffield	Sheffield Academic Press
2424	2014-05-26 14:27:00.936+00	New York	Academic Press
2425	2014-05-26 14:27:00.936+00	London	Edward Arnold
2426	2014-05-26 14:27:00.936+00	Oxford	British Archaeological Reports
2427	2014-05-26 14:27:00.936+00	Nicosia	\N
2428	2014-05-26 14:27:00.936+00	Oxford	Oxford University External Studies
2429	2014-05-26 14:27:00.936+00	London	Geological Society
2430	2014-05-26 14:27:00.936+00	Stenstrup	Apollo Books
2431	2014-05-26 14:27:00.936+00	Stenstrup	Apollo Books
2432	2014-05-26 14:27:00.936+00	Stenstrup	Apollo Books
2434	2014-05-26 14:27:00.936+00	Stenstrup	Apollo Books
2435	2014-05-26 14:27:00.936+00	Stenstrup	Apollo Books
2436	2014-05-26 14:27:00.936+00	Stenstrup	Apollo Books
2437	2014-05-26 14:27:00.936+00	Stenstrup	Apollo Books
2438	2014-05-26 14:27:00.936+00	Krefeld	Goecke&Evers
2439	2014-05-26 14:27:00.936+00	Leeds	Yorkshire Archaeological Society
2440	2014-05-26 14:27:00.936+00	Moscow	KMK Press
2441	2014-05-26 14:27:00.936+00	Stenstrup	Apollo Books
2442	2014-05-26 14:27:00.936+00	Stenstrup	Apollo Books
2443	2014-05-26 14:27:00.936+00	Uppsala	University of Uppsala
2444	2014-05-26 14:27:00.936+00	Oxford	British Archaeological Reports
2445	2014-05-26 14:27:00.936+00	London	Duckworth
2446	2014-05-26 14:27:00.936+00	New York	Columbia University Press
2447	2014-05-26 14:27:00.936+00	Minneapolis	University of Minnesota Press
2448	2014-05-26 14:27:00.936+00	Gentbrugge	\N
2449	2014-05-26 14:27:00.936+00	Sheffield	Sorby Natural History Society
2450	2014-05-26 14:27:00.936+00	Cambridge	Cambridge University Press
2451	2014-05-26 14:27:00.936+00	Oxford	Oxbow Books
2452	2014-05-26 14:27:00.936+00	Cambridge	Cambridge University Press
2453	2014-05-26 14:27:00.936+00	Waltham, Massuchussetts	\N
2454	2014-05-26 14:27:00.936+00	Peterborough	English Nature Research Report
2455	2014-05-26 14:27:00.936+00	Battlleby, Perthshire	Scottish Natural Heritage
2456	2014-05-26 14:27:00.936+00	London	Engish Heritage
2457	2014-05-26 14:27:00.936+00	Peterborough	English Nature Research Report
2458	2014-05-26 14:27:00.936+00	Shefffield	University of Sheffield
2459	2014-05-26 14:27:00.936+00	Peterborough	English Nature
2460	2014-05-26 14:27:00.936+00	Berkeley	University of California
2461	2014-05-26 14:27:00.936+00	Cambridge	University of Cambridge
2462	2014-05-26 14:27:00.936+00	Ann Arbor	University of Minnesota
2463	2014-05-26 14:27:00.936+00	\N	University of Durham
2464	2014-05-26 14:27:00.936+00	\N	University of Lancaster, Lancaster
2465	2014-05-26 14:27:00.936+00	London	Guildhall University
2466	2014-05-26 14:27:00.936+00	\N	University of Groningen
2467	2014-05-26 14:27:00.936+00	Hull	University of Hull
2468	2014-05-26 14:27:00.936+00	Sheffield	University of Sheffield
2469	2014-05-26 14:27:00.936+00	\N	University of Sheffield
2470	2014-05-26 14:27:00.936+00	Sheffield	University of Sheffield
2471	2014-05-26 14:27:00.936+00	\N	University of Aberdeen
2472	2014-05-26 14:27:00.936+00	\N	University of Aberdeen
2473	2014-05-26 14:27:00.936+00	Leeds	University of Leeds
2474	2014-05-26 14:27:00.936+00	\N	University of Cambridge
2475	2014-05-26 14:27:00.936+00	\N	Queen's University, Belfast
2476	2014-05-26 14:27:00.936+00	Birmingham	University of Birmingham
2477	2014-05-26 14:27:00.936+00	Derby	University of Derby
2478	2014-05-26 14:27:00.936+00	Bradford	University of Bradford
2479	2014-05-26 14:27:00.936+00	\N	University of Pennsylvania
2480	2014-05-26 14:27:00.936+00	\N	University College of Wales Aberystwyth
2481	2014-05-26 14:27:00.936+00	\N	King's College, University of London
2482	2014-05-26 14:27:00.936+00	\N	University of Birmingham, Birmingham
2483	2014-05-26 14:27:00.936+00	Athens	University of Athens
2484	2014-05-26 14:27:00.936+00	\N	University of Bergen
2485	2014-05-26 14:27:00.936+00	\N	University of Durham
2486	2014-05-26 14:27:00.936+00	Birmingham	Birmingham University
2487	2014-05-26 14:27:00.936+00	Hull	University of Hull
2488	2014-05-26 14:27:00.936+00	Birmingham	University of Birmingham
2489	2014-05-26 14:27:00.936+00	Umeå	Sveriges Landsbruk Universitet
2490	2014-05-26 14:27:00.936+00	Tromsø	University of Tromsø
2491	2014-05-26 14:27:00.936+00	\N	University of Sheffield
2492	2014-05-26 14:27:00.936+00	\N	University of London
2493	2014-05-26 14:27:00.936+00	London	City of London Polytechnic
2494	2014-05-26 14:27:00.936+00	Groningen	University of Groningen
2495	2014-05-26 14:27:00.936+00	Cambridge	University of Cambridge
2496	2014-05-26 14:27:00.936+00	\N	University of London
2497	2014-05-26 14:27:00.936+00	Cardiff	University of Wales (Cardiff)
