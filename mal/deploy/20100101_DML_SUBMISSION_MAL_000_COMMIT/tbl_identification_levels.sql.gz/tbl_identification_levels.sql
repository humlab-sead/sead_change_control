4	\N	Family	Uncertainty at the family level	2012-09-21 16:51:47.967181+00
5	\N	Genus	Uncertainty at the genus level	2012-09-21 16:51:47.967181+00
6	\N	Species	Uncertainty at the species level	2012-09-21 16:51:47.967181+00
1	\N	c.f. Family	Uncertainty at the family level	2012-09-21 16:51:47.967181+00
2	\N	c.f. Genus	Uncertainty at the genus level	2012-09-21 16:51:47.967181+00
3	\N	c.f. Species	Uncertainty at the species level	2012-09-21 16:51:47.967181+00
