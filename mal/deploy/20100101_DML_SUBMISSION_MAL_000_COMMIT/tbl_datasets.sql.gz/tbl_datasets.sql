1	\N	8	33	\N	\N	\N	Survey	2013-05-13 09:29:56.070308+00
2	\N	6	8	\N	\N	\N	Features[Plants & pollen]	2013-05-13 09:29:56.070308+00
3	\N	8	32	\N	\N	\N	Survey	2013-05-13 09:29:56.070308+00
4	\N	5	33	\N	\N	\N	Survey	2013-05-13 09:29:56.070308+00
5	\N	5	33	\N	\N	\N	Survey	2013-05-13 09:29:56.070308+00
6	\N	5	74	\N	\N	\N	Survey	2013-05-13 09:29:56.070308+00
7	\N	5	33	\N	\N	\N	A5518	2013-05-13 09:29:56.070308+00
8	\N	5	8	\N	\N	\N	Feature 2628 [Plants & pollen]	2013-05-13 09:29:56.070308+00
9	\N	5	8	\N	\N	\N	Features[Plants & pollen]	2013-05-13 09:29:56.070308+00
10	\N	5	8	\N	\N	\N	Features[Plants & pollen]	2013-05-13 09:29:56.070308+00
11	\N	5	74	\N	\N	\N	Survey	2013-05-13 09:29:56.070308+00
12	\N	8	74	\N	\N	\N	Survey	2013-05-13 09:29:56.070308+00
13	\N	5	32	\N	\N	\N	Survey	2013-05-13 09:29:56.070308+00
14	\N	8	37	\N	\N	\N	Features	2013-05-13 09:29:56.070308+00
15	\N	8	37	\N	\N	\N	Features	2013-05-13 09:29:56.070308+00
16	\N	5	8	\N	\N	\N	Features[Plants & pollen]	2013-05-13 09:29:56.070308+00
17	\N	5	37	\N	\N	\N	Survey	2013-05-13 09:29:56.070308+00
18	\N	5	37	\N	\N	\N	Stratigraphy	2013-05-13 09:29:56.070308+00
19	\N	8	37	\N	\N	\N	Survey	2013-05-13 09:29:56.070308+00
20	\N	5	8	\N	\N	\N	Post holes[Plants & pollen]	2013-05-13 09:29:56.070308+00
21	\N	5	33	\N	\N	\N	Stratigraphy	2013-05-13 09:29:56.070308+00
22	\N	8	33	\N	\N	\N	Features	2013-05-13 09:29:56.070308+00
23	\N	8	32	\N	\N	\N	Features	2013-05-13 09:29:56.070308+00
24	\N	5	37	\N	\N	\N	S66	2013-05-13 09:29:56.070308+00
25	\N	5	32	\N	\N	\N	Survey	2013-05-13 09:29:56.070308+00
26	\N	5	8	\N	\N	\N	House 5[Plants & pollen]	2013-05-13 09:29:56.070308+00
27	\N	8	33	\N	\N	\N	Features	2013-05-13 09:29:56.070308+00
28	\N	5	33	\N	\N	\N	S66	2013-05-13 09:29:56.070308+00
29	\N	5	8	\N	\N	\N	House 9[Plants & pollen]	2013-05-13 09:29:56.070308+00
30	\N	8	106	\N	\N	\N	MS loop survey	2013-05-13 09:29:56.070308+00
31	\N	5	74	\N	\N	\N	S66	2013-05-13 09:29:56.070308+00
32	\N	5	8	\N	\N	\N	House 10[Plants & pollen]	2013-05-13 09:29:56.070308+00
33	\N	5	8	\N	\N	\N	House 2[Plants & pollen]	2013-05-13 09:29:56.070308+00
34	\N	5	8	\N	\N	\N	House 11[Plants & pollen]	2013-05-13 09:29:56.070308+00
35	\N	5	8	\N	\N	\N	Pits[Plants & pollen]	2013-05-13 09:29:56.070308+00
36	\N	5	37	\N	\N	\N	Survey	2013-05-13 09:29:56.070308+00
37	\N	8	37	\N	\N	\N	Survey	2013-05-13 09:29:56.070308+00
38	\N	5	32	\N	\N	\N	A5518	2013-05-13 09:29:56.070308+00
39	\N	5	74	\N	\N	\N	A5518	2013-05-13 09:29:56.070308+00
40	\N	5	37	\N	\N	\N	Features	2013-05-13 09:29:56.070308+00
41	\N	5	8	\N	\N	\N	Sample group 1[Plants & pollen]	2013-05-13 09:29:56.070308+00
42	\N	5	33	\N	\N	\N	Survey	2013-05-13 09:29:56.070308+00
43	\N	8	33	\N	\N	\N	Survey	2013-05-13 09:29:56.070308+00
44	\N	5	37	\N	\N	\N	A5518	2013-05-13 09:29:56.070308+00
45	\N	5	8	\N	\N	\N	Features[Plants & pollen]	2013-05-13 09:29:56.070308+00
46	\N	5	8	\N	\N	\N	Features[Plants & pollen]	2013-05-13 09:29:56.070308+00
47	\N	8	32	\N	\N	\N	Survey	2013-05-13 09:29:56.070308+00
48	\N	8	74	\N	\N	\N	Survey	2013-05-13 09:29:56.070308+00
49	\N	8	107	\N	\N	\N	Survey	2013-05-13 09:29:56.070308+00
50	\N	8	109	\N	\N	\N	Survey	2013-05-13 09:29:56.070308+00
51	\N	5	74	\N	\N	\N	Features	2013-05-13 09:29:56.070308+00
52	\N	5	8	\N	\N	\N	House 5[Plants & pollen]	2013-05-13 09:29:56.070308+00
53	\N	5	33	\N	\N	\N	Features	2013-05-13 09:29:56.070308+00
54	\N	8	74	\N	\N	\N	Features	2013-05-13 09:29:56.070308+00
55	\N	5	32	\N	\N	\N	Features	2013-05-13 09:29:56.070308+00
56	\N	5	8	\N	\N	\N	Cooking pits[Plants & pollen]	2013-05-13 09:29:56.070308+00
57	\N	5	32	\N	\N	\N	S66	2013-05-13 09:29:56.070308+00
58	\N	5	109	\N	\N	\N	S66	2013-05-13 09:29:56.070308+00
59	\N	5	110	\N	\N	\N	S66	2013-05-13 09:29:56.070308+00
60	\N	5	8	\N	\N	\N	Kv. Drottning Kristina 19[Plants & pollen]	2013-05-13 09:29:56.070308+00
61	\N	5	107	\N	\N	\N	S66	2013-05-13 09:29:56.070308+00
62	\N	5	8	\N	\N	\N	Sample group 1[Plants & pollen]	2013-05-13 09:29:56.070308+00
63	\N	5	37	\N	\N	\N	Sample group 1	2013-05-13 09:29:56.070308+00
64	\N	5	8	\N	\N	\N	House 3[Plants & pollen]	2013-05-13 09:29:56.070308+00
65	\N	5	8	\N	\N	\N	House 3[Plants & pollen]	2013-05-13 09:29:56.070308+00
66	\N	5	32	\N	\N	\N	A7208	2013-05-13 09:29:56.070308+00
67	\N	5	33	\N	\N	\N	A7208	2013-05-13 09:29:56.070308+00
68	\N	5	8	\N	\N	\N	House 1[Plants & pollen]	2013-05-13 09:29:56.070308+00
69	\N	10	8	\N	\N	\N	Burial mound	2013-05-13 09:29:56.070308+00
70	\N	5	37	\N	\N	\N	Survey	2013-05-13 09:29:56.070308+00
71	\N	5	8	\N	\N	\N	Burial mound[Plants & pollen]	2013-05-13 09:29:56.070308+00
72	\N	5	74	\N	\N	\N	Profile B1	2013-05-13 09:29:56.070308+00
73	\N	5	33	\N	\N	\N	Profile B1	2013-05-13 09:29:56.070308+00
74	\N	6	8	\N	\N	\N	House 10[Plants & pollen]	2013-05-13 09:29:56.070308+00
75	\N	5	8	\N	\N	\N	House 7[Plants & pollen]	2013-05-13 09:29:56.070308+00
76	\N	6	8	\N	\N	\N	Features presence	2013-05-13 09:29:56.070308+00
77	\N	5	32	\N	\N	\N	Profile B1	2013-05-13 09:29:56.070308+00
78	\N	5	8	\N	\N	\N	House 11[Plants & pollen]	2013-05-13 09:29:56.070308+00
79	\N	5	8	\N	\N	\N	Features[Plants & pollen]	2013-05-13 09:29:56.070308+00
80	\N	5	37	\N	\N	\N	Profile B1	2013-05-13 09:29:56.070308+00
81	\N	5	8	\N	\N	\N	Hearths[Plants & pollen]	2013-05-13 09:29:56.070308+00
82	\N	5	8	\N	\N	\N	Sample group 1[Plants & pollen]	2013-05-13 09:29:56.070308+00
83	\N	5	32	\N	\N	\N	Sample group 1	2013-05-13 09:29:56.070308+00
84	\N	5	33	\N	\N	\N	Sample group 1	2013-05-13 09:29:56.070308+00
85	\N	5	74	\N	\N	\N	Sample group 1	2013-05-13 09:29:56.070308+00
86	\N	5	8	\N	\N	\N	House 3[Plants & pollen]	2013-05-13 09:29:56.070308+00
87	\N	5	8	\N	\N	\N	Features[Plants & pollen]	2013-05-13 09:29:56.070308+00
88	\N	10	8	\N	\N	\N	Sample group 1[Plants & pollen]	2013-05-13 09:29:56.070308+00
89	\N	5	8	\N	\N	\N	House 2b[Plants & pollen]	2013-05-13 09:29:56.070308+00
90	\N	5	8	\N	\N	\N	House 1[Plants & pollen]	2013-05-13 09:29:56.070308+00
91	\N	5	74	\N	\N	\N	Profile B3	2013-05-13 09:29:56.070308+00
92	\N	5	32	\N	\N	\N	Profile B3	2013-05-13 09:29:56.070308+00
93	\N	5	33	\N	\N	\N	Profile B3	2013-05-13 09:29:56.070308+00
94	\N	8	37	\N	\N	\N	Stratigraphy M1	2013-05-13 09:29:56.070308+00
95	\N	5	33	\N	\N	\N	Profile B4	2013-05-13 09:29:56.070308+00
96	\N	8	74	\N	\N	\N	Stratigraphy M1	2013-05-13 09:29:56.070308+00
97	\N	5	74	\N	\N	\N	Profile B4	2013-05-13 09:29:56.070308+00
98	\N	8	32	\N	\N	\N	Stratigraphy M1	2013-05-13 09:29:56.070308+00
99	\N	8	33	\N	\N	\N	Stratigraphy M1	2013-05-13 09:29:56.070308+00
100	\N	5	37	\N	\N	\N	Survey	2013-05-13 09:29:56.070308+00
101	\N	5	33	\N	\N	\N	Survey	2013-05-13 09:29:56.070308+00
102	\N	5	32	\N	\N	\N	Profile B4	2013-05-13 09:29:56.070308+00
103	\N	5	111	\N	\N	\N	House 1	2013-05-13 09:29:56.070308+00
104	\N	5	32	\N	\N	\N	Profile B2	2013-05-13 09:29:56.070308+00
105	\N	5	74	\N	\N	\N	Profile B2	2013-05-13 09:29:56.070308+00
106	\N	6	8	\N	\N	\N	House 7[Plants & pollen]	2013-05-13 09:29:56.070308+00
107	\N	5	8	\N	\N	\N	House 7[Plants & pollen]	2013-05-13 09:29:56.070308+00
108	\N	5	33	\N	\N	\N	Profile B2	2013-05-13 09:29:56.070308+00
109	\N	6	8	\N	\N	\N	House 6 presence	2013-05-13 09:29:56.070308+00
110	\N	5	8	\N	\N	\N	House 9[Plants & pollen]	2013-05-13 09:29:56.070308+00
111	\N	5	8	\N	\N	\N	House 10[Plants & pollen]	2013-05-13 09:29:56.070308+00
112	\N	5	8	\N	\N	\N	House 8[Plants & pollen]	2013-05-13 09:29:56.070308+00
113	\N	6	8	\N	\N	\N	House 8[Plants & pollen]	2013-05-13 09:29:56.070308+00
114	\N	5	8	\N	\N	\N	House 12[Plants & pollen]	2013-05-13 09:29:56.070308+00
115	\N	5	8	\N	\N	\N	House 11[Plants & pollen]	2013-05-13 09:29:56.070308+00
116	\N	6	8	\N	\N	\N	House 11[Plants & pollen]	2013-05-13 09:29:56.070308+00
117	\N	6	8	\N	\N	\N	House 14[Plants & pollen]	2013-05-13 09:29:56.070308+00
118	\N	5	8	\N	\N	\N	House 14[Plants & pollen]	2013-05-13 09:29:56.070308+00
119	\N	5	74	\N	\N	\N	Profile B6	2013-05-13 09:29:56.070308+00
120	\N	5	32	\N	\N	\N	Profile B6	2013-05-13 09:29:56.070308+00
121	\N	5	8	\N	\N	\N	House 13[Plants & pollen]	2013-05-13 09:29:56.070308+00
122	\N	5	33	\N	\N	\N	Profile B6	2013-05-13 09:29:56.070308+00
123	\N	8	33	\N	\N	\N	Post holes	2013-05-13 09:29:56.070308+00
124	\N	5	74	\N	\N	\N	A7208	2013-05-13 09:29:56.070308+00
125	\N	5	37	\N	\N	\N	A7208	2013-05-13 09:29:56.070308+00
126	\N	8	37	\N	\N	\N	Post holes	2013-05-13 09:29:56.070308+00
127	\N	8	74	\N	\N	\N	Post holes	2013-05-13 09:29:56.070308+00
128	\N	5	32	\N	\N	\N	Profile B5	2013-05-13 09:29:56.070308+00
129	\N	5	33	\N	\N	\N	Profile B5	2013-05-13 09:29:56.070308+00
130	\N	5	8	\N	\N	\N	Wall trench[Plants & pollen]	2013-05-13 09:29:56.070308+00
131	\N	5	8	\N	\N	\N	A934[Plants & pollen]	2013-05-13 09:29:56.070308+00
132	\N	5	8	\N	\N	\N	Features[Plants & pollen]	2013-05-13 09:29:56.070308+00
133	\N	5	74	\N	\N	\N	Profile B5	2013-05-13 09:29:56.070308+00
134	\N	8	32	\N	\N	\N	Post holes	2013-05-13 09:29:56.070308+00
135	\N	8	74	\N	\N	\N	Stratigraphy M2	2013-05-13 09:29:56.070308+00
136	\N	8	37	\N	\N	\N	Stratigraphy M2	2013-05-13 09:29:56.070308+00
137	\N	8	33	\N	\N	\N	Stratigraphy M2	2013-05-13 09:29:56.070308+00
138	\N	8	32	\N	\N	\N	Stratigraphy M2	2013-05-13 09:29:56.070308+00
139	\N	5	37	\N	\N	\N	Profile B6	2013-05-13 09:29:56.070308+00
140	\N	5	37	\N	\N	\N	Profile B5	2013-05-13 09:29:56.070308+00
141	\N	5	37	\N	\N	\N	Profile B4	2013-05-13 09:29:56.070308+00
142	\N	5	37	\N	\N	\N	Profile B3	2013-05-13 09:29:56.070308+00
143	\N	5	8	\N	\N	\N	House 2[Plants & pollen]	2013-05-13 09:29:56.070308+00
144	\N	5	8	\N	\N	\N	House 3[Plants & pollen]	2013-05-13 09:29:56.070308+00
145	\N	5	37	\N	\N	\N	Profile B2	2013-05-13 09:29:56.070308+00
146	\N	5	8	\N	\N	\N	House 4[Plants & pollen]	2013-05-13 09:29:56.070308+00
147	\N	5	8	\N	\N	\N	House 6[Plants & pollen]	2013-05-13 09:29:56.070308+00
196	\N	8	33	\N	\N	\N	Soil chemistry	2013-05-16 08:39:58.584644+00
199	\N	8	32	\N	\N	\N	Soil chemistry	2013-05-16 08:39:58.584644+00
200	\N	8	32	\N	\N	\N	Soil chemistry	2013-05-16 08:39:58.584644+00
201	\N	8	74	\N	\N	\N	Soil chemistry	2013-05-16 08:39:58.584644+00
203	\N	8	37	\N	\N	\N	Soil chemistry	2013-05-16 08:39:58.584644+00
204	\N	8	37	\N	\N	\N	03_0053	2013-05-16 08:39:58.584644+00
205	\N	8	37	\N	\N	\N	Soil chemistry	2013-05-16 08:39:58.584644+00
206	\N	8	74	\N	\N	\N	03_0053	2013-05-16 08:39:58.584644+00
207	\N	8	32	\N	\N	\N	Soil chemistry	2013-05-16 08:39:58.584644+00
208	\N	8	33	\N	\N	\N	03_0053	2013-05-16 08:39:58.584644+00
209	\N	8	33	\N	\N	\N	Soil chemistry	2013-05-16 08:39:58.584644+00
210	\N	5	8	\N	\N	\N	Hogstorp 327 [Plants & pollen]	2013-05-16 08:39:58.584644+00
211	\N	8	32	\N	\N	\N	03_0053	2013-05-16 08:39:58.584644+00
212	\N	5	8	\N	\N	\N	Sample group 1[Plants & pollen]	2013-05-16 08:39:58.584644+00
213	\N	8	37	\N	\N	\N	03_0065	2013-05-16 08:39:58.584644+00
214	\N	8	74	\N	\N	\N	Soil chemistry	2013-05-16 08:39:58.584644+00
215	\N	8	74	\N	\N	\N	03_0065	2013-05-16 08:39:58.584644+00
216	\N	8	33	\N	\N	\N	03_0065	2013-05-16 08:39:58.584644+00
217	\N	8	33	\N	\N	\N	Soil chemistry	2013-05-16 08:39:58.584644+00
218	\N	8	32	\N	\N	\N	Soil chemistry	2013-05-16 08:39:58.584644+00
219	\N	5	8	\N	\N	\N	Features[Plants & pollen]	2013-05-16 08:39:58.584644+00
220	\N	8	37	\N	\N	\N	Soil chemistry	2013-05-16 08:39:58.584644+00
221	\N	8	74	\N	\N	\N	Soil chemistry	2013-05-16 08:39:58.584644+00
222	\N	8	33	\N	\N	\N	Soil chemistry	2013-05-16 08:39:58.584644+00
223	\N	5	8	\N	\N	\N	Skee 1593[Plants & pollen]	2013-05-16 08:39:58.584644+00
224	\N	6	8	\N	\N	\N	Dammen[Plants & pollen]	2013-05-16 08:39:58.584644+00
225	\N	5	8	\N	\N	\N	Dammen[Plants & pollen]	2013-05-16 08:39:58.584644+00
226	\N	8	8	\N	\N	\N	Stare 1:13[Plants & pollen]	2013-05-16 08:39:58.584644+00
228	\N	5	8	\N	\N	\N	Features[Plants & pollen]	2013-05-16 08:39:58.584644+00
229	\N	5	8	\N	\N	\N	1996 Features[Plants & pollen]	2013-05-16 08:39:58.584644+00
230	\N	5	8	\N	\N	\N	1998 Features[Plants & pollen]	2013-05-16 08:39:58.584644+00
231	\N	5	8	\N	\N	\N	Ytterby 4[Plants & pollen]	2013-05-16 08:39:58.584644+00
232	\N	5	8	\N	\N	\N	Hogdal 444 + 445[Plants & pollen]	2013-05-16 08:39:58.584644+00
233	\N	8	33	\N	\N	\N	Soil chemistry	2013-05-16 08:39:58.584644+00
234	\N	6	8	\N	\N	\N	1996 Features[Plants & pollen]	2013-05-16 08:39:58.584644+00
235	\N	8	74	\N	\N	\N	Soil chemistry	2013-05-16 08:39:58.584644+00
236	\N	8	37	\N	\N	\N	Soil chemistry	2013-05-16 08:39:58.584644+00
237	\N	8	32	\N	\N	\N	Soil chemistry	2013-05-16 08:39:58.584644+00
238	\N	5	8	\N	\N	\N	Features[Plants & pollen]	2013-05-16 08:39:58.584644+00
239	\N	5	8	\N	\N	\N	Sample group 1[Plants & pollen]	2013-05-16 08:39:58.584644+00
240	\N	8	74	\N	\N	\N	Soil chemistry	2013-05-16 08:39:58.584644+00
241	\N	8	37	\N	\N	\N	Soil chemistry	2013-05-16 08:39:58.584644+00
242	\N	8	33	\N	\N	\N	Survey House 1	2013-11-13 14:33:32.218+00
243	\N	8	32	\N	\N	\N	Old wetland stratigraphy 	2013-11-13 14:33:32.218+00
244	\N	8	74	\N	\N	\N	Stratigraphy 12442 	2013-11-13 14:33:32.218+00
245	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
246	\N	8	36	\N	\N	\N	Survey K5	2013-11-13 14:33:32.218+00
247	\N	8	33	\N	\N	\N	Stratigraphy 10	2013-11-13 14:33:32.218+00
248	\N	8	33	\N	\N	\N	Final investigation survey MHM12875 	2013-11-13 14:33:32.218+00
249	\N	8	74	\N	\N	\N	Final investigation survey 	2013-11-13 14:33:32.218+00
250	\N	8	74	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
251	\N	8	33	\N	\N	\N	Final investigation features 	2013-11-13 14:33:32.218+00
252	\N	8	32	\N	\N	\N	Final investigation survey 	2013-11-13 14:33:32.218+00
253	\N	8	37	\N	\N	\N	Final investigation survey	2013-11-13 14:33:32.218+00
254	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
255	\N	8	37	\N	\N	\N	Final investigation features 	2013-11-13 14:33:32.218+00
256	\N	8	32	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
257	\N	8	94	\N	\N	\N	Stratigraphy 43303 	2013-11-13 14:33:32.218+00
258	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
259	\N	8	74	\N	\N	\N	Final investigation survey 	2013-11-13 14:33:32.218+00
260	\N	6	8	\N	\N	\N	House 2	2013-11-13 14:33:32.218+00
261	\N	8	35	\N	\N	\N	Survey K5	2013-11-13 14:33:32.218+00
262	\N	8	74	\N	\N	\N	Hearth	2013-11-13 14:33:32.218+00
263	\N	8	37	\N	\N	\N	Survey MHM12524 	2013-11-13 14:33:32.218+00
264	\N	8	33	\N	\N	\N	1996 House 3	2013-11-13 14:33:32.218+00
265	\N	8	33	\N	\N	\N	Preliminary investigation survey 	2013-11-13 14:33:32.218+00
266	\N	8	32	\N	\N	\N	Survey MHM12524 	2013-11-13 14:33:32.218+00
267	\N	8	32	\N	\N	\N	Survey MHM12748 	2013-11-13 14:33:32.218+00
268	\N	8	74	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
269	\N	8	74	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
270	\N	8	32	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
272	\N	5	8	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
273	\N	8	74	\N	\N	\N	Preliminary investigation survey MHM12747 	2013-11-13 14:33:32.218+00
274	\N	8	32	\N	\N	\N	Final investigation survey MHM12875 	2013-11-13 14:33:32.218+00
275	\N	8	32	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
276	\N	5	8	\N	\N	\N	R5876 profile	2013-11-13 14:33:32.218+00
277	\N	8	37	\N	\N	\N	1996 Survey	2013-11-13 14:33:32.218+00
278	\N	8	33	\N	\N	\N	Final investigation survey 	2013-11-13 14:33:32.218+00
279	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
280	\N	8	74	\N	\N	\N	Survey MHM12524 	2013-11-13 14:33:32.218+00
281	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
282	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
283	\N	8	32	\N	\N	\N	Final investigation survey area A	2013-11-13 14:33:32.218+00
284	\N	8	32	\N	\N	\N	A18958 Survey 	2013-11-13 14:33:32.218+00
285	\N	8	37	\N	\N	\N	A437 Survey 	2013-11-13 14:33:32.218+00
286	\N	8	32	\N	\N	\N	Stratigraphy 6436 	2013-11-13 14:33:32.218+00
287	\N	8	33	\N	\N	\N	Final investigation survey area A	2013-11-13 14:33:32.218+00
288	\N	8	33	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
289	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
290	\N	8	33	\N	\N	\N	Survey MHM12524 	2013-11-13 14:33:32.218+00
291	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
292	\N	8	33	\N	\N	\N	Stratigraphy 100:5 	2013-11-13 14:33:32.218+00
293	\N	8	33	\N	\N	\N	Survey 2003	2013-11-13 14:33:32.218+00
294	\N	8	74	\N	\N	\N	Survey MHM12748 	2013-11-13 14:33:32.218+00
295	\N	8	74	\N	\N	\N	Final investigation survey 	2013-11-13 14:33:32.218+00
297	\N	8	32	\N	\N	\N	House 29 post holes 	2013-11-13 14:33:32.218+00
298	\N	5	8	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
299	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
300	\N	8	33	\N	\N	\N	A37083 Survey 	2013-11-13 14:33:32.218+00
301	\N	8	37	\N	\N	\N	Survey 2003	2013-11-13 14:33:32.218+00
302	\N	8	32	\N	\N	\N	Final investigation survey MK85 	2013-11-13 14:33:32.218+00
303	\N	8	33	\N	\N	\N	Survey House 2	2013-11-13 14:33:32.218+00
304	\N	5	8	\N	\N	\N	 pollen]	2013-11-13 14:33:32.218+00
305	\N	8	33	\N	\N	\N	Final investigation survey 	2013-11-13 14:33:32.218+00
306	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
307	\N	8	33	\N	\N	\N	Stratigraphy A111 	2013-11-13 14:33:32.218+00
308	\N	5	8	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
309	\N	8	33	\N	\N	\N	1996 Survey	2013-11-13 14:33:32.218+00
310	\N	8	74	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
311	\N	8	32	\N	\N	\N	A478 stratigraphy 	2013-11-13 14:33:32.218+00
312	\N	8	37	\N	\N	\N	MK8 Stratigraphy 	2013-11-13 14:33:32.218+00
313	\N	8	74	\N	\N	\N	Stratigraphy 28013 	2013-11-13 14:33:32.218+00
314	\N	8	32	\N	\N	\N	Final investigation stratigraphy 120082 	2013-11-13 14:33:32.218+00
315	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
316	\N	8	32	\N	\N	\N	1998 House 8	2013-11-13 14:33:32.218+00
317	\N	8	74	\N	\N	\N	Final investigation survey MHM12875 	2013-11-13 14:33:32.218+00
318	\N	8	32	\N	\N	\N	Stratigraphy 2:1 	2013-11-13 14:33:32.218+00
319	\N	8	33	\N	\N	\N	1996 House 1	2013-11-13 14:33:32.218+00
320	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
321	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
322	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
323	\N	8	33	\N	\N	\N	A18958 Survey 	2013-11-13 14:33:32.218+00
324	\N	8	32	\N	\N	\N	1998 Survey	2013-11-13 14:33:32.218+00
325	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
326	\N	8	74	\N	\N	\N	1998 Features	2013-11-13 14:33:32.218+00
327	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
328	\N	8	37	\N	\N	\N	Survey S30	2013-11-13 14:33:32.218+00
329	\N	8	33	\N	\N	\N	Preliminary investigation survey MHM12747 	2013-11-13 14:33:32.218+00
330	\N	8	33	\N	\N	\N	A20207	2013-11-13 14:33:32.218+00
331	\N	8	74	\N	\N	\N	Trapping pit stratigraphy 4, PJ3497 	2013-11-13 14:33:32.218+00
332	\N	8	74	\N	\N	\N	Preliminary investigation survey 	2013-11-13 14:33:32.218+00
333	\N	8	74	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
334	\N	8	33	\N	\N	\N	Final investigation survey 	2013-11-13 14:33:32.218+00
335	\N	8	33	\N	\N	\N	A10000 Stratigraphy 25 	2013-11-13 14:33:32.218+00
336	\N	8	37	\N	\N	\N	A10000 Stratigraphy 20 	2013-11-13 14:33:32.218+00
337	\N	8	37	\N	\N	\N	Stratigraphy A111 	2013-11-13 14:33:32.218+00
338	\N	8	37	\N	\N	\N	House 1	2013-11-13 14:33:32.218+00
339	\N	8	74	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
340	\N	8	32	\N	\N	\N	Final investigation survey 	2013-11-13 14:33:32.218+00
341	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
342	\N	8	74	\N	\N	\N	A37083 Survey 	2013-11-13 14:33:32.218+00
343	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
344	\N	8	74	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
345	\N	8	74	\N	\N	\N	Survey 2003	2013-11-13 14:33:32.218+00
346	\N	8	33	\N	\N	\N	Survey S15	2013-11-13 14:33:32.218+00
347	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
348	\N	8	32	\N	\N	\N	Stratigraphy 6 	2013-11-13 14:33:32.218+00
349	\N	8	37	\N	\N	\N	Preliminary investigation stratigraphy	2013-11-13 14:33:32.218+00
350	\N	5	8	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
351	\N	8	33	\N	\N	\N	Stratigraphy 2:6 	2013-11-13 14:33:32.218+00
352	\N	5	8	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
353	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
354	\N	5	8	\N	\N	\N	1996	2013-11-13 14:33:32.218+00
355	\N	8	74	\N	\N	\N	Stratigraphy 1 	2013-11-13 14:33:32.218+00
356	\N	8	33	\N	\N	\N	Stratigraphy 102, unit 1, Area A 	2013-11-13 14:33:32.218+00
357	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
358	\N	8	32	\N	\N	\N	A10000 Stratigraphy 25 	2013-11-13 14:33:32.218+00
359	\N	8	37	\N	\N	\N	Preliminary investigation survey MHM12747 	2013-11-13 14:33:32.218+00
360	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
361	\N	8	32	\N	\N	\N	House 7 post holes	2013-11-13 14:33:32.218+00
362	\N	8	33	\N	\N	\N	Stratigraphy 43303 	2013-11-13 14:33:32.218+00
363	\N	8	33	\N	\N	\N	Final investigation survey	2013-11-13 14:33:32.218+00
364	\N	8	74	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
365	\N	8	74	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
366	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
367	\N	8	33	\N	\N	\N	A437 Survey 	2013-11-13 14:33:32.218+00
368	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
369	\N	8	37	\N	\N	\N	A18958 Survey 	2013-11-13 14:33:32.218+00
370	\N	8	32	\N	\N	\N	Final investigation stratigraphy 120176 	2013-11-13 14:33:32.218+00
371	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
372	\N	8	37	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
373	\N	8	33	\N	\N	\N	Final investigation survey area C	2013-11-13 14:33:32.218+00
374	\N	8	74	\N	\N	\N	Final investigation survey area C	2013-11-13 14:33:32.218+00
375	\N	8	33	\N	\N	\N	Stratigraphy 3 	2013-11-13 14:33:32.218+00
376	\N	8	33	\N	\N	\N	Survey S32	2013-11-13 14:33:32.218+00
377	\N	8	32	\N	\N	\N	Survey S32	2013-11-13 14:33:32.218+00
378	\N	8	74	\N	\N	\N	Stratigraphy P4B 	2013-11-13 14:33:32.218+00
379	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
380	\N	8	74	\N	\N	\N	Final investigation stratigraphy S6 	2013-11-13 14:33:32.218+00
381	\N	8	74	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
382	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
383	\N	8	32	\N	\N	\N	Stratigraphy 16 	2013-11-13 14:33:32.218+00
384	\N	8	32	\N	\N	\N	Final investigation survey 	2013-11-13 14:33:32.218+00
385	\N	8	37	\N	\N	\N	Final investigation survey 	2013-11-13 14:33:32.218+00
386	\N	8	74	\N	\N	\N	Preliminary investigation survey 	2013-11-13 14:33:32.218+00
387	\N	8	35	\N	\N	\N	Vaterland 1	2013-11-13 14:33:32.218+00
388	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
389	\N	8	33	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
390	\N	8	32	\N	\N	\N	MK8 Stratigraphy 	2013-11-13 14:33:32.218+00
391	\N	8	33	\N	\N	\N	Survey house 5	2013-11-13 14:33:32.218+00
392	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
393	\N	8	37	\N	\N	\N	Stratigraphy 100:3 	2013-11-13 14:33:32.218+00
394	\N	8	74	\N	\N	\N	Tuft 1	2013-11-13 14:33:32.218+00
395	\N	8	32	\N	\N	\N	Stratigraphy 100:4 	2013-11-13 14:33:32.218+00
396	\N	8	74	\N	\N	\N	Stratigraphy 3	2013-11-13 14:33:32.218+00
397	\N	8	32	\N	\N	\N	Survey 2003	2013-11-13 14:33:32.218+00
398	\N	8	33	\N	\N	\N	Stratigraphy 1:1 	2013-11-13 14:33:32.218+00
399	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
400	\N	5	8	\N	\N	\N	 pollen]	2013-11-13 14:33:32.218+00
401	\N	8	37	\N	\N	\N	Preliminary investigation survey	2013-11-13 14:33:32.218+00
402	\N	8	33	\N	\N	\N	A10000 Stratigraphy 17 	2013-11-13 14:33:32.218+00
403	\N	8	33	\N	\N	\N	1996 House 5	2013-11-13 14:33:32.218+00
404	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
405	\N	8	37	\N	\N	\N	Survey house 1	2013-11-13 14:33:32.218+00
406	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
407	\N	8	32	\N	\N	\N	1996	2013-11-13 14:33:32.218+00
408	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
409	\N	8	32	\N	\N	\N	Stratigraphy P4B 	2013-11-13 14:33:32.218+00
410	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
411	\N	8	32	\N	\N	\N	House 5 post holes	2013-11-13 14:33:32.218+00
412	\N	8	37	\N	\N	\N	House 7 post holes	2013-11-13 14:33:32.218+00
413	\N	8	33	\N	\N	\N	Preliminary investigation survey	2013-11-13 14:33:32.218+00
414	\N	8	32	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
415	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
416	\N	8	37	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
417	\N	8	74	\N	\N	\N	Stratigraphy 28014 	2013-11-13 14:33:32.218+00
418	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
419	\N	5	8	\N	\N	\N	House 1	2013-11-13 14:33:32.218+00
420	\N	8	37	\N	\N	\N	Survey House 1	2013-11-13 14:33:32.218+00
421	\N	8	74	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
422	\N	8	33	\N	\N	\N	Stratigraphy 4 	2013-11-13 14:33:32.218+00
423	\N	8	33	\N	\N	\N	Soil chemistry features 	2013-11-13 14:33:32.218+00
424	\N	8	32	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
425	\N	8	32	\N	\N	\N	Preliminary investigation survey 	2013-11-13 14:33:32.218+00
426	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
427	\N	5	8	\N	\N	\N	House 2	2013-11-13 14:33:32.218+00
428	\N	8	32	\N	\N	\N	MK845 Stratigraphy 	2013-11-13 14:33:32.218+00
429	\N	8	33	\N	\N	\N	Stratigraphy A6060	2013-11-13 14:33:32.218+00
430	\N	8	33	\N	\N	\N	Final investigation stratigraphy 50096 	2013-11-13 14:33:32.218+00
431	\N	8	117	\N	\N	\N	Trapping pit stratigraphy 3, PJ3495 	2013-11-13 14:33:32.218+00
432	\N	8	74	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
433	\N	8	74	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
434	\N	8	37	\N	\N	\N	Survey Cooking pit 	2013-11-13 14:33:32.218+00
435	\N	8	37	\N	\N	\N	Trapping pit stratigraphy 3, PJ3495 	2013-11-13 14:33:32.218+00
436	\N	8	33	\N	\N	\N	Survey Cooking pit 	2013-11-13 14:33:32.218+00
437	\N	8	33	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
438	\N	8	37	\N	\N	\N	Stratigraphy 3916 	2013-11-13 14:33:32.218+00
439	\N	8	33	\N	\N	\N	A10000 Stratigraphy 23 	2013-11-13 14:33:32.218+00
440	\N	8	33	\N	\N	\N	Final investigation stratigraphy S8 	2013-11-13 14:33:32.218+00
441	\N	8	32	\N	\N	\N	Preliminary investigation survey 	2013-11-13 14:33:32.218+00
442	\N	8	37	\N	\N	\N	Preliminary investigation survey 	2013-11-13 14:33:32.218+00
443	\N	8	37	\N	\N	\N	Survey House 2	2013-11-13 14:33:32.218+00
444	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
445	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
446	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
447	\N	8	33	\N	\N	\N	Stratigraphy 11	2013-11-13 14:33:32.218+00
448	\N	8	74	\N	\N	\N	Stratigraphy 28015 	2013-11-13 14:33:32.218+00
449	\N	8	37	\N	\N	\N	Stratigraphy 4:2 	2013-11-13 14:33:32.218+00
450	\N	8	33	\N	\N	\N	Stratigraphy 5315 	2013-11-13 14:33:32.218+00
451	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
452	\N	8	33	\N	\N	\N	Stratigraphy 15 	2013-11-13 14:33:32.218+00
453	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
454	\N	8	74	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
455	\N	8	74	\N	\N	\N	Stratigraphy P1	2013-11-13 14:33:32.218+00
456	\N	8	32	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
457	\N	8	33	\N	\N	\N	Preliminary investigation survey 	2013-11-13 14:33:32.218+00
458	\N	8	33	\N	\N	\N	Stratigraphy A2 	2013-11-13 14:33:32.218+00
459	\N	8	32	\N	\N	\N	1996 Survey	2013-11-13 14:33:32.218+00
460	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
461	\N	6	8	\N	\N	\N	Charcoal samples	2013-11-13 14:33:32.218+00
462	\N	8	94	\N	\N	\N	A1469 stratigraphy 	2013-11-13 14:33:32.218+00
463	\N	8	37	\N	\N	\N	Preliminary investigation survey 	2013-11-13 14:33:32.218+00
464	\N	8	37	\N	\N	\N	Stratigraphy A2817	2013-11-13 14:33:32.218+00
465	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
466	\N	5	8	\N	\N	\N	1998 House 6	2013-11-13 14:33:32.218+00
467	\N	8	33	\N	\N	\N	Final investigation stratigraphy 120119 	2013-11-13 14:33:32.218+00
468	\N	8	33	\N	\N	\N	Preliminary investigation survey 	2013-11-13 14:33:32.218+00
469	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
470	\N	8	74	\N	\N	\N	House 29 post holes 	2013-11-13 14:33:32.218+00
471	\N	8	37	\N	\N	\N	Final investigation survey area B	2013-11-13 14:33:32.218+00
472	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
473	\N	8	74	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
474	\N	5	8	\N	\N	\N	2007 investigation	2013-11-13 14:33:32.218+00
475	\N	5	8	\N	\N	\N	2006	2013-11-13 14:33:32.218+00
476	\N	8	32	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
477	\N	5	8	\N	\N	\N	 pollen]	2013-11-13 14:33:32.218+00
478	\N	8	32	\N	\N	\N	Stratigraphy A972 	2013-11-13 14:33:32.218+00
479	\N	8	74	\N	\N	\N	1996 Survey	2013-11-13 14:33:32.218+00
480	\N	8	37	\N	\N	\N	Final investigation stratigraphy 120011 	2013-11-13 14:33:32.218+00
481	\N	8	32	\N	\N	\N	Trapping pit stratigraphy 4, PJ3497 	2013-11-13 14:33:32.218+00
902	\N	8	33	\N	\N	\N	2007	2013-11-13 14:33:32.218+00
482	\N	8	74	\N	\N	\N	Preliminary investigation survey 	2013-11-13 14:33:32.218+00
483	\N	8	94	\N	\N	\N	Stratigraphy 12438 	2013-11-13 14:33:32.218+00
484	\N	8	33	\N	\N	\N	Stratigraphy 3	2013-11-13 14:33:32.218+00
485	\N	8	37	\N	\N	\N	Stratigraphy 7 	2013-11-13 14:33:32.218+00
486	\N	8	33	\N	\N	\N	1996	2013-11-13 14:33:32.218+00
487	\N	8	33	\N	\N	\N	Stratigraphy B, unit 2, Area B 	2013-11-13 14:33:32.218+00
488	\N	8	33	\N	\N	\N	Stratigraphy 12438 	2013-11-13 14:33:32.218+00
489	\N	8	74	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
490	\N	5	8	\N	\N	\N	1996 House 3	2013-11-13 14:33:32.218+00
491	\N	5	8	\N	\N	\N	 pollen]	2013-11-13 14:33:32.218+00
492	\N	8	33	\N	\N	\N	Survey MHM12748 	2013-11-13 14:33:32.218+00
493	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
494	\N	8	32	\N	\N	\N	Preliminary investigation survey MHM12747 	2013-11-13 14:33:32.218+00
495	\N	8	32	\N	\N	\N	Stratigraphy 1:1 	2013-11-13 14:33:32.218+00
496	\N	8	37	\N	\N	\N	Survey house 3	2013-11-13 14:33:32.218+00
497	\N	8	32	\N	\N	\N	Final investigation stratigraphy 120158 	2013-11-13 14:33:32.218+00
498	\N	8	33	\N	\N	\N	1999 Straigraphy 3045	2013-11-13 14:33:32.218+00
499	\N	8	94	\N	\N	\N	Old wetland stratigraphy 	2013-11-13 14:33:32.218+00
500	\N	8	32	\N	\N	\N	Preliminary investigation survey	2013-11-13 14:33:32.218+00
501	\N	5	8	\N	\N	\N	Final investigation features 	2013-11-13 14:33:32.218+00
502	\N	5	8	\N	\N	\N	Gamlestaden 740:142 Preliminary investigation 2010	2013-11-13 14:33:32.218+00
503	\N	8	37	\N	\N	\N	Survey K5	2013-11-13 14:33:32.218+00
504	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
505	\N	8	33	\N	\N	\N	Stratigraphy 2:2 	2013-11-13 14:33:32.218+00
506	\N	8	33	\N	\N	\N	Final investigation stratigraphy 120176 	2013-11-13 14:33:32.218+00
507	\N	8	74	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
508	\N	8	33	\N	\N	\N	Survey S31	2013-11-13 14:33:32.218+00
509	\N	8	37	\N	\N	\N	MK19 Stratigraphy 	2013-11-13 14:33:32.218+00
510	\N	8	32	\N	\N	\N	Trapping pit 1, Stratigraphy 2 	2013-11-13 14:33:32.218+00
511	\N	8	32	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
512	\N	8	74	\N	\N	\N	Additional survey	2013-11-13 14:33:32.218+00
513	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
514	\N	8	37	\N	\N	\N	Trapping pit 1, Stratigraphy 2 	2013-11-13 14:33:32.218+00
515	\N	8	33	\N	\N	\N	1998 House 8	2013-11-13 14:33:32.218+00
516	\N	8	37	\N	\N	\N	Preliminary investigation survey	2013-11-13 14:33:32.218+00
517	\N	8	33	\N	\N	\N	Final investigation survey MK85 	2013-11-13 14:33:32.218+00
518	\N	8	32	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
519	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
520	\N	8	33	\N	\N	\N	Survey S30	2013-11-13 14:33:32.218+00
521	\N	8	74	\N	\N	\N	Stratigraphy 12438 	2013-11-13 14:33:32.218+00
522	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
523	\N	5	8	\N	\N	\N	Features 	2013-11-13 14:33:32.218+00
524	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
525	\N	8	33	\N	\N	\N	Stratigraphy 2 	2013-11-13 14:33:32.218+00
526	\N	8	74	\N	\N	\N	Final investigation stratigraphy 120020 	2013-11-13 14:33:32.218+00
527	\N	8	33	\N	\N	\N	Stratigraphy P2	2013-11-13 14:33:32.218+00
528	\N	8	32	\N	\N	\N	Stratigraphy 11 	2013-11-13 14:33:32.218+00
529	\N	8	32	\N	\N	\N	Stratigraphy	2013-11-13 14:33:32.218+00
530	\N	8	74	\N	\N	\N	A10000 Stratigraphy 22 	2013-11-13 14:33:32.218+00
531	\N	8	37	\N	\N	\N	Preliminary investigation survey 	2013-11-13 14:33:32.218+00
532	\N	8	74	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
533	\N	8	74	\N	\N	\N	Stratigraphy 16 	2013-11-13 14:33:32.218+00
534	\N	8	33	\N	\N	\N	Final investigation stratigraphy S6 	2013-11-13 14:33:32.218+00
535	\N	8	37	\N	\N	\N	Survey S32	2013-11-13 14:33:32.218+00
536	\N	8	33	\N	\N	\N	House 2	2013-11-13 14:33:32.218+00
537	\N	5	8	\N	\N	\N	Smple group 1	2013-11-13 14:33:32.218+00
538	\N	8	32	\N	\N	\N	Stratigraphy 4 	2013-11-13 14:33:32.218+00
539	\N	8	33	\N	\N	\N	Stratigraphy 6292 	2013-11-13 14:33:32.218+00
540	\N	8	37	\N	\N	\N	Profile 2	2013-11-13 14:33:32.218+00
541	\N	8	74	\N	\N	\N	Survey S32	2013-11-13 14:33:32.218+00
542	\N	8	37	\N	\N	\N	Final investigation features	2013-11-13 14:33:32.218+00
543	\N	8	33	\N	\N	\N	1999 Features	2013-11-13 14:33:32.218+00
544	\N	8	37	\N	\N	\N	Final investigation survey MK85 	2013-11-13 14:33:32.218+00
545	\N	8	118	\N	\N	\N	Trapping pit stratigraphy 3, PJ3495 	2013-11-13 14:33:32.218+00
546	\N	8	74	\N	\N	\N	Stratigraphy 12 	2013-11-13 14:33:32.218+00
547	\N	8	74	\N	\N	\N	Preliminary investigation stratigraphy 00_0082_3 	2013-11-13 14:33:32.218+00
548	\N	8	32	\N	\N	\N	Final investigation features 	2013-11-13 14:33:32.218+00
549	\N	8	32	\N	\N	\N	Final investigation stratigraphy 120131 	2013-11-13 14:33:32.218+00
550	\N	8	37	\N	\N	\N	Survey MHM12748 	2013-11-13 14:33:32.218+00
551	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
552	\N	8	32	\N	\N	\N	Stratigraphy A2817	2013-11-13 14:33:32.218+00
553	\N	8	37	\N	\N	\N	Stratigraphy 5:3 	2013-11-13 14:33:32.218+00
554	\N	8	37	\N	\N	\N	Stratigraphy 5:1 	2013-11-13 14:33:32.218+00
555	\N	8	32	\N	\N	\N	Stratigraphy 100:3 	2013-11-13 14:33:32.218+00
556	\N	8	74	\N	\N	\N	Final investigation stratigraphy S7 	2013-11-13 14:33:32.218+00
557	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
558	\N	8	119	\N	\N	\N	Trapping pit stratigraphy 3, PJ3495 	2013-11-13 14:33:32.218+00
559	\N	8	33	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
560	\N	8	37	\N	\N	\N	Additional survey	2013-11-13 14:33:32.218+00
561	\N	5	8	\N	\N	\N	House 3	2013-11-13 14:33:32.218+00
562	\N	6	8	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
563	\N	8	74	\N	\N	\N	Final investigation stratigraphy S8 	2013-11-13 14:33:32.218+00
564	\N	8	33	\N	\N	\N	Stratigraphy 100:7 	2013-11-13 14:33:32.218+00
565	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
566	\N	8	33	\N	\N	\N	House 6 post holes 	2013-11-13 14:33:32.218+00
567	\N	8	33	\N	\N	\N	Stratigraphy 6 	2013-11-13 14:33:32.218+00
568	\N	8	37	\N	\N	\N	A10000 Stratigraphy 24 	2013-11-13 14:33:32.218+00
569	\N	8	32	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
570	\N	8	74	\N	\N	\N	Preliminary investigation features 	2013-11-13 14:33:32.218+00
571	\N	8	94	\N	\N	\N	Stratigraphy 12439 	2013-11-13 14:33:32.218+00
572	\N	8	37	\N	\N	\N	Stratigraphy 12445 	2013-11-13 14:33:32.218+00
573	\N	8	74	\N	\N	\N	Stratigraphy 1	2013-11-13 14:33:32.218+00
574	\N	8	33	\N	\N	\N	Stratigraphy 28013 	2013-11-13 14:33:32.218+00
575	\N	6	8	\N	\N	\N	1993 investigation	2013-11-13 14:33:32.218+00
576	\N	8	32	\N	\N	\N	Stratigraphy P8 	2013-11-13 14:33:32.218+00
577	\N	8	37	\N	\N	\N	Final investigation survey 	2013-11-13 14:33:32.218+00
578	\N	8	32	\N	\N	\N	Stratigraphy	2013-11-13 14:33:32.218+00
579	\N	8	32	\N	\N	\N	A1469 stratigraphy 	2013-11-13 14:33:32.218+00
580	\N	8	37	\N	\N	\N	Final investigation survey MHM12875 	2013-11-13 14:33:32.218+00
581	\N	5	8	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
582	\N	8	32	\N	\N	\N	Stratigraphy 2:5 	2013-11-13 14:33:32.218+00
583	\N	8	37	\N	\N	\N	Stratigraphy 7	2013-11-13 14:33:32.218+00
903	\N	8	74	\N	\N	\N	Tuft 6	2013-11-13 14:33:32.218+00
584	\N	8	33	\N	\N	\N	Trapping pit stratigraphy 3, PJ3495 	2013-11-13 14:33:32.218+00
585	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
586	\N	8	32	\N	\N	\N	Preliminary investigation features 	2013-11-13 14:33:32.218+00
587	\N	8	33	\N	\N	\N	Stratigraphy 2	2013-11-13 14:33:32.218+00
588	\N	8	32	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
589	\N	8	33	\N	\N	\N	Stratigraphy 5:1 	2013-11-13 14:33:32.218+00
590	\N	8	37	\N	\N	\N	Final investigation stratigraphy 120119 	2013-11-13 14:33:32.218+00
591	\N	8	37	\N	\N	\N	Survey S15	2013-11-13 14:33:32.218+00
592	\N	8	36	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
593	\N	8	74	\N	\N	\N	Survey S31	2013-11-13 14:33:32.218+00
594	\N	8	32	\N	\N	\N	Stratigraphy 53 	2013-11-13 14:33:32.218+00
595	\N	8	32	\N	\N	\N	Stratigraphy P3B 	2013-11-13 14:33:32.218+00
596	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
597	\N	5	8	\N	\N	\N	 pollen]	2013-11-13 14:33:32.218+00
598	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
599	\N	8	37	\N	\N	\N	Stratigraphy 6 	2013-11-13 14:33:32.218+00
600	\N	5	8	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
601	\N	8	33	\N	\N	\N	Stratigraphy A2817	2013-11-13 14:33:32.218+00
602	\N	8	33	\N	\N	\N	MK14 Stratigraphy 	2013-11-13 14:33:32.218+00
603	\N	8	74	\N	\N	\N	A1469 stratigraphy 	2013-11-13 14:33:32.218+00
604	\N	8	33	\N	\N	\N	House 1	2013-11-13 14:33:32.218+00
605	\N	8	33	\N	\N	\N	Stratigraphy 12442 	2013-11-13 14:33:32.218+00
606	\N	8	32	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
607	\N	8	74	\N	\N	\N	Stratigraphy A6060	2013-11-13 14:33:32.218+00
608	\N	8	74	\N	\N	\N	MHM 12747 Features 	2013-11-13 14:33:32.218+00
609	\N	5	8	\N	\N	\N	 pollen]	2013-11-13 14:33:32.218+00
610	\N	6	8	\N	\N	\N	2007	2013-11-13 14:33:32.218+00
611	\N	5	8	\N	\N	\N	1996 House 1	2013-11-13 14:33:32.218+00
612	\N	8	37	\N	\N	\N	Final investigation stratigraphy 120346 	2013-11-13 14:33:32.218+00
613	\N	8	33	\N	\N	\N	MK18 Stratigraphy 	2013-11-13 14:33:32.218+00
614	\N	8	74	\N	\N	\N	Sample group 1	2013-11-13 14:33:32.218+00
615	\N	8	74	\N	\N	\N	Stratigraphy 15 	2013-11-13 14:33:32.218+00
616	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
617	\N	8	74	\N	\N	\N	A478 stratigraphy 	2013-11-13 14:33:32.218+00
618	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
619	\N	8	33	\N	\N	\N	Additional survey	2013-11-13 14:33:32.218+00
620	\N	8	37	\N	\N	\N	Final investigation survey area A	2013-11-13 14:33:32.218+00
621	\N	8	33	\N	\N	\N	Preliminary investigation stratigraphy 00_0115	2013-11-13 14:33:32.218+00
622	\N	8	74	\N	\N	\N	Profile 1	2013-11-13 14:33:32.218+00
623	\N	8	32	\N	\N	\N	Stratigraphy 3 	2013-11-13 14:33:32.218+00
624	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
625	\N	5	8	\N	\N	\N	House 3	2013-11-13 14:33:32.218+00
626	\N	8	33	\N	\N	\N	Stratigraphy 12 	2013-11-13 14:33:32.218+00
627	\N	8	74	\N	\N	\N	House 14 post holes 	2013-11-13 14:33:32.218+00
628	\N	8	74	\N	\N	\N	Preliminary investigation survey	2013-11-13 14:33:32.218+00
629	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
630	\N	8	74	\N	\N	\N	Final investigation features	2013-11-13 14:33:32.218+00
631	\N	8	74	\N	\N	\N	Stratigraphy 5:2 	2013-11-13 14:33:32.218+00
632	\N	7	33	\N	\N	\N	Stratigraphy 10 	2013-11-13 14:33:32.218+00
633	\N	8	94	\N	\N	\N	Stratigraphy A6060	2013-11-13 14:33:32.218+00
634	\N	8	33	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
635	\N	8	74	\N	\N	\N	A18958 Survey 	2013-11-13 14:33:32.218+00
636	\N	8	37	\N	\N	\N	Stratigraphy 3:1 	2013-11-13 14:33:32.218+00
637	\N	8	37	\N	\N	\N	A10000 Stratigraphy 22 	2013-11-13 14:33:32.218+00
638	\N	8	37	\N	\N	\N	Final investigation stratigraphy S7 	2013-11-13 14:33:32.218+00
639	\N	5	8	\N	\N	\N	Final investigation features	2013-11-13 14:33:32.218+00
640	\N	8	32	\N	\N	\N	Stratigraphy 28015 	2013-11-13 14:33:32.218+00
641	\N	8	33	\N	\N	\N	Trapping pit stratigraphy 4, PJ3497 	2013-11-13 14:33:32.218+00
642	\N	8	32	\N	\N	\N	Stratigraphy 5 	2013-11-13 14:33:32.218+00
643	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
644	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
645	\N	8	33	\N	\N	\N	Stratigraphy 12672 	2013-11-13 14:33:32.218+00
646	\N	5	8	\N	\N	\N	 pollen]	2013-11-13 14:33:32.218+00
647	\N	8	37	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
648	\N	8	32	\N	\N	\N	Stratigraphy P4 	2013-11-13 14:33:32.218+00
649	\N	8	32	\N	\N	\N	A20207	2013-11-13 14:33:32.218+00
650	\N	8	74	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
651	\N	8	33	\N	\N	\N	Preliminary investigation features 	2013-11-13 14:33:32.218+00
652	\N	8	32	\N	\N	\N	House 14 post holes 	2013-11-13 14:33:32.218+00
653	\N	8	32	\N	\N	\N	1996 House 3	2013-11-13 14:33:32.218+00
654	\N	8	37	\N	\N	\N	Stratigraphy P4 	2013-11-13 14:33:32.218+00
655	\N	8	32	\N	\N	\N	Stratigraphy A6060	2013-11-13 14:33:32.218+00
656	\N	7	74	\N	\N	\N	Stratigraphy 10 	2013-11-13 14:33:32.218+00
657	\N	8	37	\N	\N	\N	House 2	2013-11-13 14:33:32.218+00
658	\N	8	74	\N	\N	\N	MK9 Stratigraphy 	2013-11-13 14:33:32.218+00
659	\N	8	33	\N	\N	\N	Survey house 1	2013-11-13 14:33:32.218+00
660	\N	8	74	\N	\N	\N	House 1	2013-11-13 14:33:32.218+00
661	\N	8	32	\N	\N	\N	Final investigation stratigraphy 120128 	2013-11-13 14:33:32.218+00
662	\N	8	37	\N	\N	\N	Final investigation stratigraphy 50096 	2013-11-13 14:33:32.218+00
663	\N	8	33	\N	\N	\N	Stratigraphy	2013-11-13 14:33:32.218+00
664	\N	8	32	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
665	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
666	\N	8	33	\N	\N	\N	1999 Stratigraphy 3043	2013-11-13 14:33:32.218+00
667	\N	8	33	\N	\N	\N	MK6 Stratigraphy 	2013-11-13 14:33:32.218+00
668	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
669	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
670	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
671	\N	8	32	\N	\N	\N	Trapping pit 1, Stratigraphy 1 	2013-11-13 14:33:32.218+00
672	\N	8	33	\N	\N	\N	R6733 profile	2013-11-13 14:33:32.218+00
673	\N	8	33	\N	\N	\N	Stratigraphy 2:5 	2013-11-13 14:33:32.218+00
674	\N	8	35	\N	\N	\N	Survey K4	2013-11-13 14:33:32.218+00
675	\N	5	32	\N	\N	\N	Preliminary investigation features	2013-11-13 14:33:32.218+00
676	\N	8	32	\N	\N	\N	Stratigraphy P7 	2013-11-13 14:33:32.218+00
677	\N	8	33	\N	\N	\N	Stratigraphy 12439 	2013-11-13 14:33:32.218+00
678	\N	8	37	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
679	\N	5	8	\N	\N	\N	1998 Features	2013-11-13 14:33:32.218+00
680	\N	8	74	\N	\N	\N	Old wetland stratigraphy 	2013-11-13 14:33:32.218+00
681	\N	8	33	\N	\N	\N	Old wetland stratigraphy 	2013-11-13 14:33:32.218+00
682	\N	8	32	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
683	\N	8	32	\N	\N	\N	Final investigation stratigraphy 50096 	2013-11-13 14:33:32.218+00
684	\N	8	33	\N	\N	\N	1999 Stratigraphy 3046	2013-11-13 14:33:32.218+00
685	\N	8	33	\N	\N	\N	R6728 profile	2013-11-13 14:33:32.218+00
686	\N	8	74	\N	\N	\N	Final investigation stratigraphy 50096 	2013-11-13 14:33:32.218+00
687	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
688	\N	8	32	\N	\N	\N	Stratigraphy P9 	2013-11-13 14:33:32.218+00
689	\N	5	8	\N	\N	\N	2010 investigation	2013-11-13 14:33:32.218+00
690	\N	8	37	\N	\N	\N	Preliminary investigation survey 	2013-11-13 14:33:32.218+00
691	\N	8	32	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
692	\N	5	8	\N	\N	\N	Egnellska huset 2010	2013-11-13 14:33:32.218+00
693	\N	8	94	\N	\N	\N	Stratigraphy 12444 	2013-11-13 14:33:32.218+00
694	\N	8	74	\N	\N	\N	Final investigation survey MK85 	2013-11-13 14:33:32.218+00
695	\N	8	37	\N	\N	\N	Preliminary investigation survey	2013-11-13 14:33:32.218+00
696	\N	8	33	\N	\N	\N	Gamlestaden 740:142 Preliminary investigation 2010	2013-11-13 14:33:32.218+00
697	\N	8	37	\N	\N	\N	Survey K4	2013-11-13 14:33:32.218+00
698	\N	8	33	\N	\N	\N	Survey 2001	2013-11-13 14:33:32.218+00
699	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
700	\N	8	32	\N	\N	\N	Stratigraphy 28014 	2013-11-13 14:33:32.218+00
701	\N	8	74	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
702	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
703	\N	8	74	\N	\N	\N	Stratigraphy 3:1 	2013-11-13 14:33:32.218+00
704	\N	8	32	\N	\N	\N	Stratigraphy A114 	2013-11-13 14:33:32.218+00
705	\N	8	37	\N	\N	\N	Stratigraphy 12444 	2013-11-13 14:33:32.218+00
706	\N	8	32	\N	\N	\N	Stratigraphy 5:1 	2013-11-13 14:33:32.218+00
707	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
708	\N	8	37	\N	\N	\N	Sample group 1	2013-11-13 14:33:32.218+00
709	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
710	\N	8	33	\N	\N	\N	Stratigraphy 5 	2013-11-13 14:33:32.218+00
711	\N	8	74	\N	\N	\N	Stratigraphy 7	2013-11-13 14:33:32.218+00
712	\N	8	74	\N	\N	\N	Stratigraphy 6436 	2013-11-13 14:33:32.218+00
713	\N	8	74	\N	\N	\N	House 6 post holes 	2013-11-13 14:33:32.218+00
714	\N	8	74	\N	\N	\N	A676 stratigraphy 	2013-11-13 14:33:32.218+00
715	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
716	\N	8	74	\N	\N	\N	Final investigation stratigraphy 120158 	2013-11-13 14:33:32.218+00
717	\N	8	37	\N	\N	\N	Stratigraphy 5 	2013-11-13 14:33:32.218+00
718	\N	8	32	\N	\N	\N	Final investigation stratigraphy 120355 	2013-11-13 14:33:32.218+00
719	\N	8	33	\N	\N	\N	1998 Survey	2013-11-13 14:33:32.218+00
720	\N	8	32	\N	\N	\N	Stratigraphy 12436 	2013-11-13 14:33:32.218+00
721	\N	8	33	\N	\N	\N	Stratigraphy 43304 	2013-11-13 14:33:32.218+00
722	\N	8	32	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
723	\N	8	74	\N	\N	\N	Final investigation features	2013-11-13 14:33:32.218+00
724	\N	5	8	\N	\N	\N	1998 House 8	2013-11-13 14:33:32.218+00
725	\N	6	8	\N	\N	\N	Vaterland 1	2013-11-13 14:33:32.218+00
726	\N	8	33	\N	\N	\N	Stratigraphy A972 	2013-11-13 14:33:32.218+00
727	\N	8	37	\N	\N	\N	Stratigraphy C, unit 2, Area B/D 	2013-11-13 14:33:32.218+00
728	\N	8	36	\N	\N	\N	Survey K8	2013-11-13 14:33:32.218+00
729	\N	8	33	\N	\N	\N	Stratigraphy A114 	2013-11-13 14:33:32.218+00
730	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
731	\N	8	74	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
732	\N	8	33	\N	\N	\N	Trapping pit 1, Stratigraphy 2 	2013-11-13 14:33:32.218+00
733	\N	8	32	\N	\N	\N	Final investigation stratigraphy 120029 	2013-11-13 14:33:32.218+00
734	\N	8	32	\N	\N	\N	Stratigraphy 12440 	2013-11-13 14:33:32.218+00
735	\N	8	74	\N	\N	\N	Stratigraphy A2526 	2013-11-13 14:33:32.218+00
736	\N	8	37	\N	\N	\N	Final investigation stratigraphy S10 	2013-11-13 14:33:32.218+00
737	\N	8	32	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
738	\N	8	37	\N	\N	\N	Stratigraphy 13 	2013-11-13 14:33:32.218+00
739	\N	8	32	\N	\N	\N	Stratigraphy 3:2 	2013-11-13 14:33:32.218+00
740	\N	8	74	\N	\N	\N	Stratigraphy 3	2013-11-13 14:33:32.218+00
741	\N	5	111	\N	\N	\N	Sample group 1	2013-11-13 14:33:32.218+00
856	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
742	\N	8	33	\N	\N	\N	Long barrow stratigraphy "Lennart" 	2013-11-13 14:33:32.218+00
743	\N	8	33	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
744	\N	8	33	\N	\N	\N	Stratigraphy 9 	2013-11-13 14:33:32.218+00
745	\N	8	32	\N	\N	\N	Stratigraphy 43303 	2013-11-13 14:33:32.218+00
746	\N	8	33	\N	\N	\N	House 29 post holes 	2013-11-13 14:33:32.218+00
747	\N	8	37	\N	\N	\N	Stratigraphy A1921 	2013-11-13 14:33:32.218+00
748	\N	8	32	\N	\N	\N	Stratigraphy 2:2 	2013-11-13 14:33:32.218+00
749	\N	8	33	\N	\N	\N	Long barrow stratigraphy "Nisse" 	2013-11-13 14:33:32.218+00
750	\N	8	33	\N	\N	\N	Stratigraphy 3916 	2013-11-13 14:33:32.218+00
751	\N	8	74	\N	\N	\N	1998 Survey	2013-11-13 14:33:32.218+00
752	\N	8	32	\N	\N	\N	Final investigation features	2013-11-13 14:33:32.218+00
753	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
754	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
755	\N	8	33	\N	\N	\N	House 3	2013-11-13 14:33:32.218+00
756	\N	8	32	\N	\N	\N	House 6 post holes 	2013-11-13 14:33:32.218+00
757	\N	8	33	\N	\N	\N	MK9 Stratigraphy 	2013-11-13 14:33:32.218+00
758	\N	8	33	\N	\N	\N	Stratigraphy 28014 	2013-11-13 14:33:32.218+00
759	\N	8	74	\N	\N	\N	Final investigation survey area B	2013-11-13 14:33:32.218+00
760	\N	8	74	\N	\N	\N	Survey 2001	2013-11-13 14:33:32.218+00
761	\N	8	74	\N	\N	\N	Stratigraphy 5 	2013-11-13 14:33:32.218+00
762	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
763	\N	8	74	\N	\N	\N	Stratigraphy 3:3 	2013-11-13 14:33:32.218+00
764	\N	8	33	\N	\N	\N	Stratigraphy 100:3 	2013-11-13 14:33:32.218+00
765	\N	6	8	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
766	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
767	\N	8	74	\N	\N	\N	Stratigraphy 1:3 	2013-11-13 14:33:32.218+00
768	\N	8	74	\N	\N	\N	Stratigraphy P2	2013-11-13 14:33:32.218+00
769	\N	8	74	\N	\N	\N	Final investigation features 	2013-11-13 14:33:32.218+00
770	\N	5	8	\N	\N	\N	Archaeobotany features 	2013-11-13 14:33:32.218+00
771	\N	8	37	\N	\N	\N	Stratigraphy 12439 	2013-11-13 14:33:32.218+00
772	\N	5	8	\N	\N	\N	1996 House 2	2013-11-13 14:33:32.218+00
773	\N	8	32	\N	\N	\N	Stratigraphy P1	2013-11-13 14:33:32.218+00
774	\N	8	32	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
775	\N	8	32	\N	\N	\N	Final investigation stratigraphy S4 	2013-11-13 14:33:32.218+00
776	\N	8	74	\N	\N	\N	Stratigraphy 2	2013-11-13 14:33:32.218+00
777	\N	8	33	\N	\N	\N	House 2 post holes	2013-11-13 14:33:32.218+00
778	\N	8	33	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
779	\N	8	32	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
780	\N	5	8	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
781	\N	8	33	\N	\N	\N	Stratigraphy A, unit 2, Area B 	2013-11-13 14:33:32.218+00
782	\N	8	32	\N	\N	\N	Survey S15	2013-11-13 14:33:32.218+00
783	\N	6	8	\N	\N	\N	Grundsunda Raä 121	2013-11-13 14:33:32.218+00
784	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
785	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
786	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
787	\N	8	37	\N	\N	\N	Stratigraphy 7070 	2013-11-13 14:33:32.218+00
788	\N	8	74	\N	\N	\N	Long barrow stratigraphy "Lennart" 	2013-11-13 14:33:32.218+00
789	\N	8	33	\N	\N	\N	Stratigraphy 7	2013-11-13 14:33:32.218+00
790	\N	8	32	\N	\N	\N	Stratigraphy 9 	2013-11-13 14:33:32.218+00
791	\N	8	37	\N	\N	\N	MK6 Stratigraphy 	2013-11-13 14:33:32.218+00
792	\N	8	33	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
793	\N	8	37	\N	\N	\N	1996 House 1	2013-11-13 14:33:32.218+00
794	\N	8	94	\N	\N	\N	Stratigraphy 12436 	2013-11-13 14:33:32.218+00
795	\N	8	74	\N	\N	\N	Preliminary investigation stratigraphy 00_0117	2013-11-13 14:33:32.218+00
796	\N	8	94	\N	\N	\N	Stratigraphy A2 	2013-11-13 14:33:32.218+00
797	\N	8	74	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
798	\N	5	8	\N	\N	\N	 pollen]	2013-11-13 14:33:32.218+00
799	\N	8	33	\N	\N	\N	Final investigation stratigraphy S10 	2013-11-13 14:33:32.218+00
800	\N	8	33	\N	\N	\N	Stratigraphy 12437 	2013-11-13 14:33:32.218+00
801	\N	8	74	\N	\N	\N	Stratigraphy 100:2 	2013-11-13 14:33:32.218+00
802	\N	8	33	\N	\N	\N	Survey of possible house	2013-11-13 14:33:32.218+00
803	\N	8	32	\N	\N	\N	Stratigraphy 2	2013-11-13 14:33:32.218+00
804	\N	8	33	\N	\N	\N	Stratigraphy 2:4 	2013-11-13 14:33:32.218+00
805	\N	8	37	\N	\N	\N	Stratigraphy 2	2013-11-13 14:33:32.218+00
806	\N	8	33	\N	\N	\N	A10000 Stratigraphy 20 	2013-11-13 14:33:32.218+00
807	\N	8	33	\N	\N	\N	2007 investigation	2013-11-13 14:33:32.218+00
808	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
809	\N	8	33	\N	\N	\N	Stratigraphy A2526 	2013-11-13 14:33:32.218+00
810	\N	8	37	\N	\N	\N	2007	2013-11-13 14:33:32.218+00
811	\N	8	37	\N	\N	\N	House 1	2013-11-13 14:33:32.218+00
812	\N	8	32	\N	\N	\N	Stratigraphy 10	2013-11-13 14:33:32.218+00
813	\N	6	8	\N	\N	\N	Sample group 1	2013-11-13 14:33:32.218+00
814	\N	8	37	\N	\N	\N	Stratigraphy 2:3 	2013-11-13 14:33:32.218+00
815	\N	8	37	\N	\N	\N	Survey K8	2013-11-13 14:33:32.218+00
816	\N	8	37	\N	\N	\N	Stratigraphy A972 	2013-11-13 14:33:32.218+00
817	\N	8	32	\N	\N	\N	1996 House 1	2013-11-13 14:33:32.218+00
818	\N	8	33	\N	\N	\N	Stratigraphy 1:3 	2013-11-13 14:33:32.218+00
819	\N	8	74	\N	\N	\N	Final investigation survey area A	2013-11-13 14:33:32.218+00
820	\N	8	33	\N	\N	\N	Final investigation survey area B	2013-11-13 14:33:32.218+00
821	\N	8	37	\N	\N	\N	A676 stratigraphy 	2013-11-13 14:33:32.218+00
822	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
823	\N	8	37	\N	\N	\N	MK12 Stratigraphy 	2013-11-13 14:33:32.218+00
824	\N	8	32	\N	\N	\N	Gamlestaden 740:142 Preliminary investigation 2010	2013-11-13 14:33:32.218+00
825	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
826	\N	8	33	\N	\N	\N	Stratigraphy 12436 	2013-11-13 14:33:32.218+00
827	\N	8	37	\N	\N	\N	A37083 Survey 	2013-11-13 14:33:32.218+00
828	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
829	\N	8	32	\N	\N	\N	Stratigraphy P6 	2013-11-13 14:33:32.218+00
830	\N	8	74	\N	\N	\N	Stratigraphy A2817	2013-11-13 14:33:32.218+00
831	\N	8	32	\N	\N	\N	1996 House 2	2013-11-13 14:33:32.218+00
832	\N	8	35	\N	\N	\N	Burial chamber	2013-11-13 14:33:32.218+00
833	\N	8	33	\N	\N	\N	Final investigation stratigraphy 120158 	2013-11-13 14:33:32.218+00
834	\N	8	33	\N	\N	\N	A1469 stratigraphy 	2013-11-13 14:33:32.218+00
835	\N	8	37	\N	\N	\N	Sample group 1	2013-11-13 14:33:32.218+00
836	\N	8	74	\N	\N	\N	Stratigraphy 8444 	2013-11-13 14:33:32.218+00
837	\N	8	33	\N	\N	\N	Stratigraphy 12443 	2013-11-13 14:33:32.218+00
838	\N	5	8	\N	\N	\N	Sample group 1	2013-11-13 14:33:32.218+00
839	\N	8	74	\N	\N	\N	1996 House 1	2013-11-13 14:33:32.218+00
840	\N	8	33	\N	\N	\N	Stratigraphy 71932 	2013-11-13 14:33:32.218+00
841	\N	8	33	\N	\N	\N	Stratigraphy 4:1 	2013-11-13 14:33:32.218+00
842	\N	8	74	\N	\N	\N	Stratigraphy 2 	2013-11-13 14:33:32.218+00
843	\N	8	33	\N	\N	\N	MK845 Stratigraphy 	2013-11-13 14:33:32.218+00
844	\N	8	37	\N	\N	\N	Stratigraphy 100:6 	2013-11-13 14:33:32.218+00
845	\N	8	32	\N	\N	\N	Soil chemistry features 	2013-11-13 14:33:32.218+00
846	\N	8	33	\N	\N	\N	Final investigation features	2013-11-13 14:33:32.218+00
847	\N	8	33	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
848	\N	8	74	\N	\N	\N	Stratigraphy 4 	2013-11-13 14:33:32.218+00
849	\N	8	33	\N	\N	\N	Stratigraphy 2:3 	2013-11-13 14:33:32.218+00
850	\N	8	33	\N	\N	\N	Preliminary investigation survey 	2013-11-13 14:33:32.218+00
851	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
852	\N	8	118	\N	\N	\N	Trapping pit stratigraphy 4, PJ3497 	2013-11-13 14:33:32.218+00
853	\N	8	74	\N	\N	\N	Stratigraphy 2 	2013-11-13 14:33:32.218+00
854	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
855	\N	8	33	\N	\N	\N	Stratigraphy 53 	2013-11-13 14:33:32.218+00
857	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
858	\N	8	33	\N	\N	\N	A286 Stratigraphy 	2013-11-13 14:33:32.218+00
859	\N	8	33	\N	\N	\N	Features house 1	2013-11-13 14:33:32.218+00
860	\N	8	74	\N	\N	\N	MK6 Stratigraphy 	2013-11-13 14:33:32.218+00
861	\N	5	8	\N	\N	\N	Sample group 2	2013-11-13 14:33:32.218+00
862	\N	8	32	\N	\N	\N	Stratigraphy depression 	2013-11-13 14:33:32.218+00
863	\N	8	32	\N	\N	\N	House 8 post holes	2013-11-13 14:33:32.218+00
864	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
865	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
866	\N	8	37	\N	\N	\N	R6733 profile	2013-11-13 14:33:32.218+00
867	\N	8	32	\N	\N	\N	Stratigraphy 100:1 	2013-11-13 14:33:32.218+00
868	\N	8	74	\N	\N	\N	Stratigraphy 6 	2013-11-13 14:33:32.218+00
869	\N	8	74	\N	\N	\N	MK11 Stratigraphy 	2013-11-13 14:33:32.218+00
870	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
871	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
872	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
873	\N	8	33	\N	\N	\N	A676 stratigraphy 	2013-11-13 14:33:32.218+00
874	\N	8	32	\N	\N	\N	Stratigraphy 43304 	2013-11-13 14:33:32.218+00
875	\N	8	37	\N	\N	\N	Stratigraphy 11 	2013-11-13 14:33:32.218+00
876	\N	8	33	\N	\N	\N	House 4	2013-11-13 14:33:32.218+00
877	\N	8	74	\N	\N	\N	Stratigraphy 3916 	2013-11-13 14:33:32.218+00
878	\N	8	32	\N	\N	\N	A37083 Survey 	2013-11-13 14:33:32.218+00
879	\N	8	32	\N	\N	\N	Survey P3	2013-11-13 14:33:32.218+00
880	\N	5	8	\N	\N	\N	Refuse pit	2013-11-13 14:33:32.218+00
881	\N	8	33	\N	\N	\N	Final investigation features	2013-11-13 14:33:32.218+00
882	\N	8	74	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
883	\N	8	74	\N	\N	\N	1999 Features	2013-11-13 14:33:32.218+00
884	\N	8	32	\N	\N	\N	Stratigraphy 5315 	2013-11-13 14:33:32.218+00
885	\N	8	37	\N	\N	\N	Stratigraphy 43304 	2013-11-13 14:33:32.218+00
886	\N	8	37	\N	\N	\N	1998 House 7	2013-11-13 14:33:32.218+00
887	\N	8	74	\N	\N	\N	Final investigation stratigraphy 120176 	2013-11-13 14:33:32.218+00
889	\N	8	37	\N	\N	\N	1996 House 2	2013-11-13 14:33:32.218+00
890	\N	8	74	\N	\N	\N	Trapping pit stratigraphy 3, PJ3495 	2013-11-13 14:33:32.218+00
891	\N	8	32	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
892	\N	8	32	\N	\N	\N	Survey S30	2013-11-13 14:33:32.218+00
893	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
894	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
895	\N	8	37	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
896	\N	5	8	\N	\N	\N	Sample group 1	2013-11-13 14:33:32.218+00
897	\N	8	74	\N	\N	\N	Stratigraphy 101, unit 1, Area A 	2013-11-13 14:33:32.218+00
898	\N	8	33	\N	\N	\N	Stratigraphy	2013-11-13 14:33:32.218+00
899	\N	8	37	\N	\N	\N	Stratigraphy 2	2013-11-13 14:33:32.218+00
900	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
901	\N	8	32	\N	\N	\N	Stratigraphy A111 	2013-11-13 14:33:32.218+00
904	\N	8	74	\N	\N	\N	1998 House 9	2013-11-13 14:33:32.218+00
905	\N	8	32	\N	\N	\N	Final investigation stratigraphy 120070 	2013-11-13 14:33:32.218+00
906	\N	5	8	\N	\N	\N	1993 investigation	2013-11-13 14:33:32.218+00
907	\N	8	32	\N	\N	\N	Survey S31	2013-11-13 14:33:32.218+00
908	\N	8	32	\N	\N	\N	Preliminary investigation stratigraphy 00_0082_3 	2013-11-13 14:33:32.218+00
909	\N	8	33	\N	\N	\N	Stratigraphy A1921 	2013-11-13 14:33:32.218+00
910	\N	8	33	\N	\N	\N	Stratigraphy 3:1 	2013-11-13 14:33:32.218+00
911	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
912	\N	8	33	\N	\N	\N	Stratigraphy 6436 	2013-11-13 14:33:32.218+00
913	\N	8	94	\N	\N	\N	Stratigraphy A111 	2013-11-13 14:33:32.218+00
914	\N	8	33	\N	\N	\N	Final investigation stratigraphy 120020 	2013-11-13 14:33:32.218+00
915	\N	8	33	\N	\N	\N	A10000 Stratigraphy 18 	2013-11-13 14:33:32.218+00
916	\N	8	37	\N	\N	\N	Stratigraphy 2:1 	2013-11-13 14:33:32.218+00
917	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
918	\N	8	37	\N	\N	\N	Stratigraphy 5 	2013-11-13 14:33:32.218+00
919	\N	5	8	\N	\N	\N	 pollen]	2013-11-13 14:33:32.218+00
920	\N	8	74	\N	\N	\N	Stratigraphy 1 	2013-11-13 14:33:32.218+00
921	\N	8	32	\N	\N	\N	Stratigraphy A, unit 2, Area B 	2013-11-13 14:33:32.218+00
922	\N	8	36	\N	\N	\N	Survey K4	2013-11-13 14:33:32.218+00
923	\N	8	33	\N	\N	\N	1998 House 6	2013-11-13 14:33:32.218+00
924	\N	8	32	\N	\N	\N	Preliminary investigation stratigraphy 00_0082_1 	2013-11-13 14:33:32.218+00
925	\N	8	37	\N	\N	\N	Final investigation stratigraphy 120185 	2013-11-13 14:33:32.218+00
926	\N	8	74	\N	\N	\N	Stratigraphy 2:5 	2013-11-13 14:33:32.218+00
927	\N	8	110	\N	\N	\N	R6733 profile	2013-11-13 14:33:32.218+00
928	\N	8	37	\N	\N	\N	1996 House 3	2013-11-13 14:33:32.218+00
929	\N	8	32	\N	\N	\N	Stratigraphy 71933 	2013-11-13 14:33:32.218+00
930	\N	8	74	\N	\N	\N	MK2 Stratigraphy 	2013-11-13 14:33:32.218+00
931	\N	8	33	\N	\N	\N	Stratigraphy 12445 	2013-11-13 14:33:32.218+00
932	\N	8	32	\N	\N	\N	Preliminary investigation stratigraphy 00_0117	2013-11-13 14:33:32.218+00
933	\N	8	74	\N	\N	\N	Stratigraphy 6 	2013-11-13 14:33:32.218+00
934	\N	8	33	\N	\N	\N	House 8 post holes	2013-11-13 14:33:32.218+00
935	\N	8	37	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
936	\N	8	37	\N	\N	\N	Preliminary investigation stratigraphy 00_0115	2013-11-13 14:33:32.218+00
937	\N	8	33	\N	\N	\N	House 2	2013-11-13 14:33:32.218+00
938	\N	8	74	\N	\N	\N	Stratigraphy A111 	2013-11-13 14:33:32.218+00
939	\N	8	33	\N	\N	\N	Sample group 1	2013-11-13 14:33:32.218+00
940	\N	8	32	\N	\N	\N	Stratigraphy 2:6 	2013-11-13 14:33:32.218+00
941	\N	8	74	\N	\N	\N	Survey S15	2013-11-13 14:33:32.218+00
942	\N	8	37	\N	\N	\N	Stratigraphy 100:5 	2013-11-13 14:33:32.218+00
943	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
944	\N	8	32	\N	\N	\N	A10000 Stratigraphy 18 	2013-11-13 14:33:32.218+00
945	\N	8	74	\N	\N	\N	A286 Stratigraphy 	2013-11-13 14:33:32.218+00
946	\N	5	8	\N	\N	\N	Grave 9	2013-11-13 14:33:32.218+00
947	\N	8	37	\N	\N	\N	Survey of possible house	2013-11-13 14:33:32.218+00
948	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
949	\N	6	8	\N	\N	\N	1993 investigation	2013-11-13 14:33:32.218+00
950	\N	8	37	\N	\N	\N	Stratigraphy depression 	2013-11-13 14:33:32.218+00
951	\N	8	37	\N	\N	\N	Preliminary investigation stratigraphy 00_0082_3 	2013-11-13 14:33:32.218+00
952	\N	8	74	\N	\N	\N	A10000 Stratigraphy 21 	2013-11-13 14:33:32.218+00
953	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
954	\N	8	32	\N	\N	\N	Final investigation survey area C	2013-11-13 14:33:32.218+00
955	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
956	\N	8	37	\N	\N	\N	Stratigraphy 8 	2013-11-13 14:33:32.218+00
957	\N	8	32	\N	\N	\N	House 2	2013-11-13 14:33:32.218+00
958	\N	8	33	\N	\N	\N	Preliminary investigation stratigraphy 00_0082_2 	2013-11-13 14:33:32.218+00
959	\N	5	8	\N	\N	\N	 pollen]	2013-11-13 14:33:32.218+00
960	\N	8	32	\N	\N	\N	1999 Stratigraphy 3047	2013-11-13 14:33:32.218+00
961	\N	5	8	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
962	\N	8	32	\N	\N	\N	Sample group 1	2013-11-13 14:33:32.218+00
963	\N	8	74	\N	\N	\N	Stratigraphy 2:3 	2013-11-13 14:33:32.218+00
964	\N	8	32	\N	\N	\N	Stratigraphy A2 	2013-11-13 14:33:32.218+00
965	\N	8	74	\N	\N	\N	House 3	2013-11-13 14:33:32.218+00
966	\N	8	37	\N	\N	\N	Sample group 1	2013-11-13 14:33:32.218+00
967	\N	8	32	\N	\N	\N	Final investigation stratigraphy 120346 	2013-11-13 14:33:32.218+00
968	\N	8	33	\N	\N	\N	Stratigraphy 1	2013-11-13 14:33:32.218+00
969	\N	8	74	\N	\N	\N	MK12 Stratigraphy 	2013-11-13 14:33:32.218+00
970	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
971	\N	8	37	\N	\N	\N	Stratigraphy 8445 	2013-11-13 14:33:32.218+00
972	\N	8	32	\N	\N	\N	House 1	2013-11-13 14:33:32.218+00
973	\N	8	32	\N	\N	\N	Trapping pit stratigraphy 3, PJ3495 	2013-11-13 14:33:32.218+00
974	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
975	\N	5	8	\N	\N	\N	1996-01	2013-11-13 14:33:32.218+00
976	\N	8	32	\N	\N	\N	Final investigation survey area B	2013-11-13 14:33:32.218+00
977	\N	8	74	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
978	\N	8	35	\N	\N	\N	Survey K8	2013-11-13 14:33:32.218+00
979	\N	8	33	\N	\N	\N	1998 House 9	2013-11-13 14:33:32.218+00
980	\N	8	37	\N	\N	\N	Stratigraphy 3:3 	2013-11-13 14:33:32.218+00
981	\N	8	32	\N	\N	\N	Stratigraphy 11	2013-11-13 14:33:32.218+00
982	\N	8	32	\N	\N	\N	Stratigraphy 2 	2013-11-13 14:33:32.218+00
983	\N	8	37	\N	\N	\N	Stratigraphy 28015 	2013-11-13 14:33:32.218+00
984	\N	8	33	\N	\N	\N	Stratigraphy 4	2013-11-13 14:33:32.218+00
985	\N	8	37	\N	\N	\N	Long barrow stratigraphy "Nisse" 	2013-11-13 14:33:32.218+00
986	\N	8	33	\N	\N	\N	A10000 Stratigraphy 22 	2013-11-13 14:33:32.218+00
987	\N	8	33	\N	\N	\N	Preliminary investigation survey	2013-11-13 14:33:32.218+00
988	\N	8	32	\N	\N	\N	Stratigraphy 71932 	2013-11-13 14:33:32.218+00
989	\N	8	33	\N	\N	\N	Preliminary investigation survey	2013-11-13 14:33:32.218+00
990	\N	8	74	\N	\N	\N	Stratigraphy 3 	2013-11-13 14:33:32.218+00
991	\N	8	32	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
992	\N	8	74	\N	\N	\N	House 8 post holes	2013-11-13 14:33:32.218+00
993	\N	8	74	\N	\N	\N	Stratigraphy 11	2013-11-13 14:33:32.218+00
994	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
995	\N	8	32	\N	\N	\N	Stratigraphy 7 	2013-11-13 14:33:32.218+00
996	\N	8	33	\N	\N	\N	MK13 Stratigraphy 	2013-11-13 14:33:32.218+00
997	\N	8	32	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
998	\N	8	32	\N	\N	\N	Stratigraphy 15 	2013-11-13 14:33:32.218+00
999	\N	8	33	\N	\N	\N	MHM 12747 Features 	2013-11-13 14:33:32.218+00
1000	\N	8	32	\N	\N	\N	MK6 Stratigraphy 	2013-11-13 14:33:32.218+00
1001	\N	8	32	\N	\N	\N	Stratigraphy 3	2013-11-13 14:33:32.218+00
1002	\N	8	37	\N	\N	\N	A10000 Stratigraphy 17 	2013-11-13 14:33:32.218+00
1003	\N	8	33	\N	\N	\N	R5876 profile	2013-11-13 14:33:32.218+00
1004	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1005	\N	8	37	\N	\N	\N	Final investigation stratigraphy 120128 	2013-11-13 14:33:32.218+00
1006	\N	8	37	\N	\N	\N	Sample group 1	2013-11-13 14:33:32.218+00
1007	\N	8	32	\N	\N	\N	Stratigraphy 2	2013-11-13 14:33:32.218+00
1008	\N	8	74	\N	\N	\N	Stratigraphy 12445 	2013-11-13 14:33:32.218+00
1009	\N	8	32	\N	\N	\N	Stratigraphy 12672 	2013-11-13 14:33:32.218+00
1010	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1011	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1012	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1013	\N	8	33	\N	\N	\N	Final investigation stratigraphy 120070 	2013-11-13 14:33:32.218+00
1014	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1015	\N	8	33	\N	\N	\N	1998 House 10	2013-11-13 14:33:32.218+00
1016	\N	8	37	\N	\N	\N	Final investigation survey area C	2013-11-13 14:33:32.218+00
1017	\N	8	33	\N	\N	\N	MK11 Stratigraphy 	2013-11-13 14:33:32.218+00
1018	\N	8	33	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
1019	\N	8	32	\N	\N	\N	Stratigraphy 12439 	2013-11-13 14:33:32.218+00
1020	\N	5	8	\N	\N	\N	Grundsunda Raä 121	2013-11-13 14:33:32.218+00
1021	\N	8	32	\N	\N	\N	A676 stratigraphy 	2013-11-13 14:33:32.218+00
1022	\N	8	37	\N	\N	\N	Stratigraphy 100:4 	2013-11-13 14:33:32.218+00
1023	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1024	\N	8	74	\N	\N	\N	Stratigraphy 8445 	2013-11-13 14:33:32.218+00
1025	\N	8	32	\N	\N	\N	R5876 profile	2013-11-13 14:33:32.218+00
1026	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1027	\N	8	32	\N	\N	\N	1998 Features	2013-11-13 14:33:32.218+00
1028	\N	6	8	\N	\N	\N	House 1	2013-11-13 14:33:32.218+00
1029	\N	8	32	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1030	\N	8	33	\N	\N	\N	Stratigraphy 6 	2013-11-13 14:33:32.218+00
1031	\N	5	8	\N	\N	\N	1998 House 10	2013-11-13 14:33:32.218+00
1032	\N	8	37	\N	\N	\N	Final investigation stratigraphy S6 	2013-11-13 14:33:32.218+00
1033	\N	8	74	\N	\N	\N	R5876 profile	2013-11-13 14:33:32.218+00
1034	\N	8	33	\N	\N	\N	Stratigraphy 8 	2013-11-13 14:33:32.218+00
1035	\N	8	37	\N	\N	\N	Stratigraphy 12440 	2013-11-13 14:33:32.218+00
1036	\N	5	8	\N	\N	\N	Vaterland 1	2013-11-13 14:33:32.218+00
1037	\N	8	33	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
1038	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1039	\N	8	37	\N	\N	\N	Final investigation survey 	2013-11-13 14:33:32.218+00
1040	\N	8	33	\N	\N	\N	Preliminary investigation stratigraphy 00_0117	2013-11-13 14:33:32.218+00
1041	\N	8	33	\N	\N	\N	Stratigraphy C, unit 2, Area B/D 	2013-11-13 14:33:32.218+00
1042	\N	8	74	\N	\N	\N	Stratigraphy 3:2 	2013-11-13 14:33:32.218+00
1043	\N	8	33	\N	\N	\N	Stratigraphy 7070 	2013-11-13 14:33:32.218+00
1044	\N	8	33	\N	\N	\N	1996 House 2	2013-11-13 14:33:32.218+00
1045	\N	8	32	\N	\N	\N	Stratigraphy 6 	2013-11-13 14:33:32.218+00
1046	\N	8	32	\N	\N	\N	Final investigation stratigraphy S9 	2013-11-13 14:33:32.218+00
1047	\N	8	74	\N	\N	\N	Soil chemistry features 	2013-11-13 14:33:32.218+00
1048	\N	8	74	\N	\N	\N	Stratigraphy 100:3 	2013-11-13 14:33:32.218+00
1049	\N	8	37	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
1050	\N	8	37	\N	\N	\N	A10000 Stratigraphy 23 	2013-11-13 14:33:32.218+00
1051	\N	8	33	\N	\N	\N	House 1	2013-11-13 14:33:32.218+00
1052	\N	8	33	\N	\N	\N	Tuft 6	2013-11-13 14:33:32.218+00
1053	\N	8	37	\N	\N	\N	Stratigraphy 53 	2013-11-13 14:33:32.218+00
1054	\N	8	74	\N	\N	\N	House 2 post holes	2013-11-13 14:33:32.218+00
1055	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1056	\N	5	8	\N	\N	\N	1999 House 11	2013-11-13 14:33:32.218+00
1057	\N	8	33	\N	\N	\N	1998 Features	2013-11-13 14:33:32.218+00
1058	\N	8	32	\N	\N	\N	Stratigraphy 5:2 	2013-11-13 14:33:32.218+00
1059	\N	8	33	\N	\N	\N	Stratigraphy 1:2 	2013-11-13 14:33:32.218+00
1060	\N	8	33	\N	\N	\N	Stratigraphy depression 	2013-11-13 14:33:32.218+00
1061	\N	8	37	\N	\N	\N	Trapping pit stratigraphy 4, PJ3497 	2013-11-13 14:33:32.218+00
1062	\N	8	32	\N	\N	\N	Stratigraphy 4:2 	2013-11-13 14:33:32.218+00
1063	\N	8	33	\N	\N	\N	Stratigraphy P5 	2013-11-13 14:33:32.218+00
1064	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1065	\N	8	33	\N	\N	\N	Final investigation stratigraphy 120011 	2013-11-13 14:33:32.218+00
1066	\N	8	74	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
1067	\N	8	94	\N	\N	\N	Stratigraphy 5315 	2013-11-13 14:33:32.218+00
1068	\N	8	37	\N	\N	\N	Stratigraphy A2526 	2013-11-13 14:33:32.218+00
1069	\N	8	74	\N	\N	\N	Final investigation stratigraphy 120131 	2013-11-13 14:33:32.218+00
1070	\N	8	33	\N	\N	\N	Sample group 1	2013-11-13 14:33:32.218+00
1071	\N	8	33	\N	\N	\N	Lok 2	2013-11-13 14:33:32.218+00
1072	\N	8	74	\N	\N	\N	1999 House 12	2013-11-13 14:33:32.218+00
1073	\N	8	32	\N	\N	\N	Stratigraphy 8754 	2013-11-13 14:33:32.218+00
1074	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1076	\N	8	33	\N	\N	\N	1999 House 12	2013-11-13 14:33:32.218+00
1077	\N	8	37	\N	\N	\N	Stratigraphy 101, unit 1, Area A 	2013-11-13 14:33:32.218+00
1078	\N	6	8	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
1079	\N	8	37	\N	\N	\N	House 2	2013-11-13 14:33:32.218+00
1080	\N	5	8	\N	\N	\N	1995	2013-11-13 14:33:32.218+00
1081	\N	8	74	\N	\N	\N	Stratigraphy 43304 	2013-11-13 14:33:32.218+00
1082	\N	8	33	\N	\N	\N	Tuft 2	2013-11-13 14:33:32.218+00
1083	\N	8	33	\N	\N	\N	Stratigraphy 1 	2013-11-13 14:33:32.218+00
1084	\N	8	74	\N	\N	\N	Stratigraphy 8754 	2013-11-13 14:33:32.218+00
1085	\N	8	74	\N	\N	\N	1998 House 7	2013-11-13 14:33:32.218+00
1086	\N	8	33	\N	\N	\N	Stratigraphy 12671 	2013-11-13 14:33:32.218+00
1087	\N	8	33	\N	\N	\N	Stratigraphy P4B 	2013-11-13 14:33:32.218+00
1088	\N	8	33	\N	\N	\N	Trapping pit 1, Stratigraphy 1 	2013-11-13 14:33:32.218+00
1089	\N	8	74	\N	\N	\N	Stratigraphy 12440 	2013-11-13 14:33:32.218+00
1090	\N	8	74	\N	\N	\N	Stratigraphy A, unit 2, Area B 	2013-11-13 14:33:32.218+00
1091	\N	8	74	\N	\N	\N	Stratigraphy 7 	2013-11-13 14:33:32.218+00
1092	\N	8	37	\N	\N	\N	Trapping pit 1, Stratigraphy 1 	2013-11-13 14:33:32.218+00
1093	\N	8	33	\N	\N	\N	A478 stratigraphy 	2013-11-13 14:33:32.218+00
1094	\N	8	74	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1095	\N	8	74	\N	\N	\N	Profile 2	2013-11-13 14:33:32.218+00
1096	\N	8	37	\N	\N	\N	Stratigraphy P7 	2013-11-13 14:33:32.218+00
1097	\N	8	32	\N	\N	\N	Stratigraphy 3 	2013-11-13 14:33:32.218+00
1098	\N	8	32	\N	\N	\N	Stratigraphy 3:3 	2013-11-13 14:33:32.218+00
1099	\N	7	37	\N	\N	\N	Stratigraphy 10 	2013-11-13 14:33:32.218+00
1100	\N	8	33	\N	\N	\N	Stratigraphy 101, unit 1, Area A 	2013-11-13 14:33:32.218+00
1101	\N	8	33	\N	\N	\N	Preliminary investigation stratigraphy 00_0082_3 	2013-11-13 14:33:32.218+00
1102	\N	8	32	\N	\N	\N	Long barrow stratigraphy "Nisse" 	2013-11-13 14:33:32.218+00
1103	\N	8	32	\N	\N	\N	Stratigraphy 100:5 	2013-11-13 14:33:32.218+00
1104	\N	6	8	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
1105	\N	8	37	\N	\N	\N	Final investigation stratigraphy 120146 	2013-11-13 14:33:32.218+00
1106	\N	8	74	\N	\N	\N	Stratigraphy 12439 	2013-11-13 14:33:32.218+00
1107	\N	8	74	\N	\N	\N	Stratigraphy 8 	2013-11-13 14:33:32.218+00
1108	\N	8	37	\N	\N	\N	Stratigraphy B, unit 2, Area B 	2013-11-13 14:33:32.218+00
1109	\N	6	8	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
1110	\N	8	74	\N	\N	\N	Stratigraphy 11 	2013-11-13 14:33:32.218+00
1111	\N	8	32	\N	\N	\N	Final investigation features	2013-11-13 14:33:32.218+00
1112	\N	8	37	\N	\N	\N	Stratigraphy	2013-11-13 14:33:32.218+00
1113	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1114	\N	8	74	\N	\N	\N	Stratigraphy 1:2 	2013-11-13 14:33:32.218+00
1115	\N	8	33	\N	\N	\N	1999 Stratigraphy 3044	2013-11-13 14:33:32.218+00
1116	\N	8	74	\N	\N	\N	Stratigraphy	2013-11-13 14:33:32.218+00
1117	\N	8	74	\N	\N	\N	Burial chamber	2013-11-13 14:33:32.218+00
1118	\N	8	32	\N	\N	\N	Stratigraphy 13 	2013-11-13 14:33:32.218+00
1119	\N	8	33	\N	\N	\N	Stratigraphy 4 	2013-11-13 14:33:32.218+00
1120	\N	8	33	\N	\N	\N	Stratigraphy 16 	2013-11-13 14:33:32.218+00
1121	\N	8	33	\N	\N	\N	House 1	2013-11-13 14:33:32.218+00
1122	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1123	\N	8	32	\N	\N	\N	Stratigraphy 12445 	2013-11-13 14:33:32.218+00
1124	\N	8	37	\N	\N	\N	Preliminary investigation features 	2013-11-13 14:33:32.218+00
1125	\N	8	33	\N	\N	\N	Stratigraphy 2 	2013-11-13 14:33:32.218+00
1126	\N	8	32	\N	\N	\N	Final investigation stratigraphy S8 	2013-11-13 14:33:32.218+00
1127	\N	8	32	\N	\N	\N	A10000 Stratigraphy 22 	2013-11-13 14:33:32.218+00
1128	\N	8	74	\N	\N	\N	House 5 post holes	2013-11-13 14:33:32.218+00
1129	\N	8	32	\N	\N	\N	House 4 post holes	2013-11-13 14:33:32.218+00
1130	\N	5	8	\N	\N	\N	Sample group 1	2013-11-13 14:33:32.218+00
1131	\N	8	33	\N	\N	\N	Final investigation stratigraphy 120082 	2013-11-13 14:33:32.218+00
1132	\N	8	74	\N	\N	\N	2007	2013-11-13 14:33:32.218+00
1133	\N	8	37	\N	\N	\N	Stratigraphy 8753 	2013-11-13 14:33:32.218+00
1134	\N	8	74	\N	\N	\N	Long barrow stratigraphy "Nisse" 	2013-11-13 14:33:32.218+00
1135	\N	8	32	\N	\N	\N	Stratigraphy 6	2013-11-13 14:33:32.218+00
1136	\N	8	74	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
1137	\N	8	33	\N	\N	\N	Final investigation stratigraphy 120185 	2013-11-13 14:33:32.218+00
1138	\N	8	74	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1139	\N	8	74	\N	\N	\N	Stratigraphy 12672 	2013-11-13 14:33:32.218+00
1140	\N	8	33	\N	\N	\N	Stratigraphy P4 	2013-11-13 14:33:32.218+00
1141	\N	5	8	\N	\N	\N	1996-04	2013-11-13 14:33:32.218+00
1142	\N	8	33	\N	\N	\N	House 14 post holes 	2013-11-13 14:33:32.218+00
1143	\N	8	74	\N	\N	\N	House 1	2013-11-13 14:33:32.218+00
1144	\N	8	33	\N	\N	\N	House 9 post holes	2013-11-13 14:33:32.218+00
1145	\N	8	37	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
1146	\N	8	37	\N	\N	\N	Tuft 1	2013-11-13 14:33:32.218+00
1147	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1148	\N	8	74	\N	\N	\N	Stratigraphy 100:6 	2013-11-13 14:33:32.218+00
1149	\N	8	33	\N	\N	\N	MK8 Stratigraphy 	2013-11-13 14:33:32.218+00
1150	\N	8	37	\N	\N	\N	Stratigraphy 71933 	2013-11-13 14:33:32.218+00
1151	\N	5	8	\N	\N	\N	Grundsunda Raä 126	2013-11-13 14:33:32.218+00
1152	\N	8	37	\N	\N	\N	House 3	2013-11-13 14:33:32.218+00
1153	\N	8	32	\N	\N	\N	Final investigation stratigraphy 120119 	2013-11-13 14:33:32.218+00
1154	\N	6	8	\N	\N	\N	 pollen]	2013-11-13 14:33:32.218+00
1155	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1156	\N	8	74	\N	\N	\N	Stratigraphy 5:3 	2013-11-13 14:33:32.218+00
1157	\N	8	74	\N	\N	\N	Sample group 1	2013-11-13 14:33:32.218+00
1158	\N	8	33	\N	\N	\N	Stratigraphy 8445 	2013-11-13 14:33:32.218+00
1159	\N	8	32	\N	\N	\N	A21146 Stratigraphy 	2013-11-13 14:33:32.218+00
1160	\N	8	74	\N	\N	\N	A10000 Stratigraphy 20 	2013-11-13 14:33:32.218+00
1161	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1162	\N	8	32	\N	\N	\N	Stratigraphy 6292 	2013-11-13 14:33:32.218+00
1163	\N	8	74	\N	\N	\N	Stratigraphy P6 	2013-11-13 14:33:32.218+00
1164	\N	8	37	\N	\N	\N	Stratigraphy 9 	2013-11-13 14:33:32.218+00
1165	\N	8	74	\N	\N	\N	MK13 Stratigraphy 	2013-11-13 14:33:32.218+00
1166	\N	8	32	\N	\N	\N	MK9 Stratigraphy 	2013-11-13 14:33:32.218+00
1167	\N	8	33	\N	\N	\N	Stratigraphy 8753 	2013-11-13 14:33:32.218+00
1168	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1169	\N	8	32	\N	\N	\N	1998 House 10	2013-11-13 14:33:32.218+00
1170	\N	5	8	\N	\N	\N	1996 House 4	2013-11-13 14:33:32.218+00
1171	\N	8	32	\N	\N	\N	1998 House 6	2013-11-13 14:33:32.218+00
1172	\N	8	37	\N	\N	\N	Stratigraphy 4	2013-11-13 14:33:32.218+00
1173	\N	8	37	\N	\N	\N	MK2 Stratigraphy 	2013-11-13 14:33:32.218+00
1174	\N	8	32	\N	\N	\N	Stratigraphy 3916 	2013-11-13 14:33:32.218+00
1175	\N	8	33	\N	\N	\N	Final investigation stratigraphy 120131 	2013-11-13 14:33:32.218+00
1176	\N	8	74	\N	\N	\N	Stratigraphy A972 	2013-11-13 14:33:32.218+00
1177	\N	8	74	\N	\N	\N	Stratigraphy 2:1 	2013-11-13 14:33:32.218+00
1178	\N	8	33	\N	\N	\N	Final investigation stratigraphy 120364 	2013-11-13 14:33:32.218+00
1179	\N	8	32	\N	\N	\N	MK11 Stratigraphy 	2013-11-13 14:33:32.218+00
1180	\N	8	32	\N	\N	\N	MK844 Stratigraphy 	2013-11-13 14:33:32.218+00
1181	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1182	\N	8	74	\N	\N	\N	House 3 post holes 	2013-11-13 14:33:32.218+00
1183	\N	8	33	\N	\N	\N	A10000 Stratigraphy 21 	2013-11-13 14:33:32.218+00
1184	\N	8	37	\N	\N	\N	Stratigraphy 3:2 	2013-11-13 14:33:32.218+00
1185	\N	8	33	\N	\N	\N	House 3	2013-11-13 14:33:32.218+00
1186	\N	8	32	\N	\N	\N	Stratigraphy 1:2 	2013-11-13 14:33:32.218+00
1187	\N	8	37	\N	\N	\N	Stratigraphy 6292 	2013-11-13 14:33:32.218+00
1188	\N	8	74	\N	\N	\N	1999 Stratigraphy 3046	2013-11-13 14:33:32.218+00
1189	\N	5	8	\N	\N	\N	Stratigraphy	2013-11-13 14:33:32.218+00
1190	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1191	\N	8	37	\N	\N	\N	1999 House 11	2013-11-13 14:33:32.218+00
1192	\N	8	74	\N	\N	\N	Stratigraphy 5315 	2013-11-13 14:33:32.218+00
1193	\N	8	37	\N	\N	\N	Stratigraphy 1:3 	2013-11-13 14:33:32.218+00
1194	\N	8	32	\N	\N	\N	Stratigraphy 12671 	2013-11-13 14:33:32.218+00
1195	\N	7	32	\N	\N	\N	Stratigraphy 10 	2013-11-13 14:33:32.218+00
1196	\N	8	33	\N	\N	\N	Stratigraphy 7 	2013-11-13 14:33:32.218+00
1197	\N	8	37	\N	\N	\N	MK18 Stratigraphy 	2013-11-13 14:33:32.218+00
1198	\N	8	33	\N	\N	\N	MK10 Stratigraphy 	2013-11-13 14:33:32.218+00
1199	\N	8	37	\N	\N	\N	Stratigraphy P1	2013-11-13 14:33:32.218+00
1200	\N	5	8	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
1201	\N	8	37	\N	\N	\N	Stratigraphy 8754 	2013-11-13 14:33:32.218+00
1202	\N	8	32	\N	\N	\N	House 3 post holes 	2013-11-13 14:33:32.218+00
1203	\N	8	33	\N	\N	\N	Profile 2	2013-11-13 14:33:32.218+00
1204	\N	8	37	\N	\N	\N	1999 House 15	2013-11-13 14:33:32.218+00
1205	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1206	\N	8	32	\N	\N	\N	Survey 2001	2013-11-13 14:33:32.218+00
1207	\N	8	33	\N	\N	\N	Stratigraphy 3:3 	2013-11-13 14:33:32.218+00
1208	\N	8	74	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
1209	\N	8	32	\N	\N	\N	Stratigraphy A2526 	2013-11-13 14:33:32.218+00
1210	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1211	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1212	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1213	\N	8	33	\N	\N	\N	1999 Stratigraphy 3047	2013-11-13 14:33:32.218+00
1214	\N	8	33	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
1215	\N	8	33	\N	\N	\N	1996 House 5	2013-11-13 14:33:32.218+00
1216	\N	8	74	\N	\N	\N	A10000 Stratigraphy 23 	2013-11-13 14:33:32.218+00
1217	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1218	\N	8	33	\N	\N	\N	Sample group 1	2013-11-13 14:33:32.218+00
1219	\N	6	8	\N	\N	\N	Preliminary investigation features 	2013-11-13 14:33:32.218+00
1220	\N	8	32	\N	\N	\N	MK7 Stratigraphy 	2013-11-13 14:33:32.218+00
1221	\N	8	32	\N	\N	\N	Stratigraphy 8444 	2013-11-13 14:33:32.218+00
1222	\N	8	32	\N	\N	\N	Preliminary investigation survey 	2013-11-13 14:33:32.218+00
1223	\N	8	94	\N	\N	\N	Stratigraphy 12440 	2013-11-13 14:33:32.218+00
1224	\N	8	33	\N	\N	\N	A21146 Stratigraphy 	2013-11-13 14:33:32.218+00
1225	\N	8	74	\N	\N	\N	Stratigraphy 12671 	2013-11-13 14:33:32.218+00
1226	\N	5	33	\N	\N	\N	Preliminary investigation features	2013-11-13 14:33:32.218+00
1227	\N	5	8	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
1228	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1229	\N	8	33	\N	\N	\N	Stratigraphy 8754 	2013-11-13 14:33:32.218+00
1230	\N	8	32	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
1231	\N	8	37	\N	\N	\N	Stratigraphy 10	2013-11-13 14:33:32.218+00
1232	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1233	\N	8	32	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
1234	\N	5	8	\N	\N	\N	A30	2013-11-13 14:33:32.218+00
1235	\N	8	74	\N	\N	\N	Stratigraphy 100:4 	2013-11-13 14:33:32.218+00
1236	\N	8	32	\N	\N	\N	Final investigation stratigraphy 120011 	2013-11-13 14:33:32.218+00
1237	\N	8	74	\N	\N	\N	Stratigraphy 12436 	2013-11-13 14:33:32.218+00
1238	\N	8	32	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1239	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1240	\N	5	8	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
1241	\N	8	74	\N	\N	\N	A10000 Stratigraphy 25 	2013-11-13 14:33:32.218+00
1242	\N	8	37	\N	\N	\N	1998 House 9	2013-11-13 14:33:32.218+00
1243	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1244	\N	8	32	\N	\N	\N	Stratigraphy P5 	2013-11-13 14:33:32.218+00
1245	\N	8	32	\N	\N	\N	Karleby 105:1	2013-11-13 14:33:32.218+00
1246	\N	8	74	\N	\N	\N	Stratigraphy 4:1 	2013-11-13 14:33:32.218+00
1247	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1248	\N	8	33	\N	\N	\N	Stratigraphy 12444 	2013-11-13 14:33:32.218+00
1249	\N	8	32	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
1250	\N	8	33	\N	\N	\N	Final investigation stratigraphy 120346 	2013-11-13 14:33:32.218+00
1251	\N	8	33	\N	\N	\N	Stratigraphy 3:2 	2013-11-13 14:33:32.218+00
1252	\N	8	35	\N	\N	\N	Hearth	2013-11-13 14:33:32.218+00
1253	\N	8	32	\N	\N	\N	1999 Stratigraphy 3044	2013-11-13 14:33:32.218+00
1254	\N	8	74	\N	\N	\N	1996 House 5	2013-11-13 14:33:32.218+00
1255	\N	8	32	\N	\N	\N	Final investigation stratigraphy S10 	2013-11-13 14:33:32.218+00
1256	\N	8	37	\N	\N	\N	Stratigraphy 12438 	2013-11-13 14:33:32.218+00
1257	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1258	\N	8	74	\N	\N	\N	Stratigraphy 3 	2013-11-13 14:33:32.218+00
1259	\N	8	37	\N	\N	\N	Stratigraphy 43303 	2013-11-13 14:33:32.218+00
1260	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1261	\N	8	32	\N	\N	\N	Long barrow stratigraphy "Lennart" 	2013-11-13 14:33:32.218+00
1262	\N	8	33	\N	\N	\N	Final investigation stratigraphy 120146 	2013-11-13 14:33:32.218+00
1263	\N	8	33	\N	\N	\N	Stratigraphy 3	2013-11-13 14:33:32.218+00
1264	\N	8	33	\N	\N	\N	Survey house 3	2013-11-13 14:33:32.218+00
1265	\N	8	74	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
1266	\N	8	74	\N	\N	\N	Stratigraphy 2:4 	2013-11-13 14:33:32.218+00
1267	\N	8	33	\N	\N	\N	Stratigraphy 11 	2013-11-13 14:33:32.218+00
1268	\N	8	37	\N	\N	\N	Stratigraphy 28014 	2013-11-13 14:33:32.218+00
1269	\N	8	32	\N	\N	\N	A10000 Stratigraphy 23 	2013-11-13 14:33:32.218+00
1270	\N	8	74	\N	\N	\N	Sample group 1	2013-11-13 14:33:32.218+00
1271	\N	8	33	\N	\N	\N	Tuft 1	2013-11-13 14:33:32.218+00
1272	\N	8	32	\N	\N	\N	Stratigraphy 1:3 	2013-11-13 14:33:32.218+00
1273	\N	8	32	\N	\N	\N	Stratigraphy 1 	2013-11-13 14:33:32.218+00
1274	\N	8	37	\N	\N	\N	Stratigraphy 1:1 	2013-11-13 14:33:32.218+00
1275	\N	8	33	\N	\N	\N	MK7 Stratigraphy 	2013-11-13 14:33:32.218+00
1276	\N	8	37	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
1277	\N	8	32	\N	\N	\N	Stratigraphy 100:2 	2013-11-13 14:33:32.218+00
1278	\N	8	74	\N	\N	\N	A21146 Stratigraphy 	2013-11-13 14:33:32.218+00
1279	\N	8	32	\N	\N	\N	Sample group 1	2013-11-13 14:33:32.218+00
1280	\N	8	117	\N	\N	\N	Trapping pit stratigraphy 4, PJ3497 	2013-11-13 14:33:32.218+00
1281	\N	8	33	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
1282	\N	8	94	\N	\N	\N	Stratigraphy 12443 	2013-11-13 14:33:32.218+00
1283	\N	8	33	\N	\N	\N	House 6 post holes	2013-11-13 14:33:32.218+00
1284	\N	8	74	\N	\N	\N	Final investigation stratigraphy 120128 	2013-11-13 14:33:32.218+00
1285	\N	8	74	\N	\N	\N	Stratigraphy 1:1 	2013-11-13 14:33:32.218+00
1286	\N	8	32	\N	\N	\N	MK19 Stratigraphy 	2013-11-13 14:33:32.218+00
1287	\N	8	32	\N	\N	\N	Preliminary investigation stratigraphy	2013-11-13 14:33:32.218+00
1288	\N	8	33	\N	\N	\N	Stratigraphy 4:2 	2013-11-13 14:33:32.218+00
1289	\N	8	74	\N	\N	\N	Features house 1	2013-11-13 14:33:32.218+00
1290	\N	8	33	\N	\N	\N	Final investigation stratigraphy 120029 	2013-11-13 14:33:32.218+00
1291	\N	6	8	\N	\N	\N	 pollen]	2013-11-13 14:33:32.218+00
1292	\N	8	33	\N	\N	\N	1998 House 7	2013-11-13 14:33:32.218+00
1293	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1294	\N	8	32	\N	\N	\N	MHM 12747 Features 	2013-11-13 14:33:32.218+00
1295	\N	8	37	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
1296	\N	8	33	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
1297	\N	8	37	\N	\N	\N	1998 Survey	2013-11-13 14:33:32.218+00
1298	\N	8	32	\N	\N	\N	Stratigraphy 28013 	2013-11-13 14:33:32.218+00
1299	\N	8	32	\N	\N	\N	Stratigraphy 12444 	2013-11-13 14:33:32.218+00
1300	\N	8	74	\N	\N	\N	1999 Stratigraphy 3043	2013-11-13 14:33:32.218+00
1301	\N	8	37	\N	\N	\N	Final investigation stratigraphy 120176 	2013-11-13 14:33:32.218+00
1302	\N	5	8	\N	\N	\N	1999 House 12	2013-11-13 14:33:32.218+00
1303	\N	8	33	\N	\N	\N	Stratigraphy 1 	2013-11-13 14:33:32.218+00
1304	\N	8	33	\N	\N	\N	Final excavation	2013-11-13 14:33:32.218+00
1305	\N	8	33	\N	\N	\N	1999 House 15	2013-11-13 14:33:32.218+00
1306	\N	8	37	\N	\N	\N	Stratigraphy A2 	2013-11-13 14:33:32.218+00
1307	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1308	\N	8	33	\N	\N	\N	MK19 Stratigraphy 	2013-11-13 14:33:32.218+00
1309	\N	8	37	\N	\N	\N	1999 Stratigraphy 3042	2013-11-13 14:33:32.218+00
1310	\N	8	74	\N	\N	\N	1996	2013-11-13 14:33:32.218+00
1311	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1312	\N	8	109	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1313	\N	8	32	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
1314	\N	8	33	\N	\N	\N	Karleby 105:1	2013-11-13 14:33:32.218+00
1315	\N	8	32	\N	\N	\N	Post holes	2013-11-13 14:33:32.218+00
1316	\N	8	74	\N	\N	\N	1996 House 2	2013-11-13 14:33:32.218+00
1317	\N	8	37	\N	\N	\N	1998 Features	2013-11-13 14:33:32.218+00
1318	\N	8	37	\N	\N	\N	Survey house 4	2013-11-13 14:33:32.218+00
1319	\N	8	74	\N	\N	\N	Stratigraphy 5:1 	2013-11-13 14:33:32.218+00
1320	\N	8	37	\N	\N	\N	Burial chamber	2013-11-13 14:33:32.218+00
1321	\N	8	33	\N	\N	\N	Stratigraphy P6 	2013-11-13 14:33:32.218+00
1322	\N	8	74	\N	\N	\N	Stratigraphy P7 	2013-11-13 14:33:32.218+00
1323	\N	8	74	\N	\N	\N	Stratigraphy 71932 	2013-11-13 14:33:32.218+00
1324	\N	8	33	\N	\N	\N	Stratigraphy 100:6 	2013-11-13 14:33:32.218+00
1325	\N	8	74	\N	\N	\N	Stratigraphy 71933 	2013-11-13 14:33:32.218+00
1326	\N	8	74	\N	\N	\N	1998 House 8	2013-11-13 14:33:32.218+00
1327	\N	8	33	\N	\N	\N	Preliminary investigation features 	2013-11-13 14:33:32.218+00
1328	\N	8	37	\N	\N	\N	MHM 12747 Features 	2013-11-13 14:33:32.218+00
1329	\N	8	32	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
1330	\N	8	33	\N	\N	\N	Preliminary investigation stratigraphy 00_0082_1 	2013-11-13 14:33:32.218+00
1331	\N	8	33	\N	\N	\N	Stratigraphy 12440 	2013-11-13 14:33:32.218+00
1332	\N	8	32	\N	\N	\N	Tuft 6	2013-11-13 14:33:32.218+00
1333	\N	8	37	\N	\N	\N	1996	2013-11-13 14:33:32.218+00
1334	\N	8	74	\N	\N	\N	Final investigation stratigraphy 120346 	2013-11-13 14:33:32.218+00
1335	\N	8	33	\N	\N	\N	Preliminary investigation stratigraphy	2013-11-13 14:33:32.218+00
1336	\N	5	8	\N	\N	\N	House 2	2013-11-13 14:33:32.218+00
1337	\N	8	32	\N	\N	\N	Additional survey	2013-11-13 14:33:32.218+00
1338	\N	8	74	\N	\N	\N	Stratigraphy 12441 	2013-11-13 14:33:32.218+00
1339	\N	8	37	\N	\N	\N	A46091 Survey 	2013-11-13 14:33:32.218+00
1340	\N	8	74	\N	\N	\N	Stratigraphy 9 	2013-11-13 14:33:32.218+00
1341	\N	8	33	\N	\N	\N	House 5 post holes	2013-11-13 14:33:32.218+00
1342	\N	8	74	\N	\N	\N	R6733 profile	2013-11-13 14:33:32.218+00
1343	\N	8	37	\N	\N	\N	Stratigraphy 100:7 	2013-11-13 14:33:32.218+00
1344	\N	5	8	\N	\N	\N	Preliminary investigation	2013-11-13 14:33:32.218+00
1345	\N	8	74	\N	\N	\N	Stratigraphy 12437 	2013-11-13 14:33:32.218+00
1346	\N	8	33	\N	\N	\N	MK844 Stratigraphy 	2013-11-13 14:33:32.218+00
1347	\N	8	37	\N	\N	\N	Features house 10	2013-11-13 14:33:32.218+00
1348	\N	8	32	\N	\N	\N	Stratigraphy 2 	2013-11-13 14:33:32.218+00
1349	\N	8	74	\N	\N	\N	Stratigraphy 2:2 	2013-11-13 14:33:32.218+00
1350	\N	8	37	\N	\N	\N	Survey 2001	2013-11-13 14:33:32.218+00
1351	\N	8	74	\N	\N	\N	Preliminary investigation stratigraphy	2013-11-13 14:33:32.218+00
1352	\N	8	33	\N	\N	\N	Final investigation stratigraphy S9 	2013-11-13 14:33:32.218+00
1353	\N	8	94	\N	\N	\N	Stratigraphy 12437 	2013-11-13 14:33:32.218+00
1354	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1355	\N	8	32	\N	\N	\N	Sample group 1	2013-11-13 14:33:32.218+00
1356	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1357	\N	8	33	\N	\N	\N	Stratigraphy 12441 	2013-11-13 14:33:32.218+00
1358	\N	8	37	\N	\N	\N	Stratigraphy 12442 	2013-11-13 14:33:32.218+00
1359	\N	8	33	\N	\N	\N	Stratigraphy 2	2013-11-13 14:33:32.218+00
1360	\N	5	8	\N	\N	\N	Clearance cairns	2013-11-13 14:33:32.218+00
1361	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1362	\N	8	32	\N	\N	\N	MK2 Stratigraphy 	2013-11-13 14:33:32.218+00
1363	\N	8	37	\N	\N	\N	Soil chemistry features 	2013-11-13 14:33:32.218+00
1364	\N	8	37	\N	\N	\N	Stratigraphy 11	2013-11-13 14:33:32.218+00
1365	\N	8	37	\N	\N	\N	Stratigraphy	2013-11-13 14:33:32.218+00
1366	\N	8	37	\N	\N	\N	1998 House 8	2013-11-13 14:33:32.218+00
1367	\N	8	37	\N	\N	\N	Survey Cooking pit 	2013-11-13 14:33:32.218+00
1368	\N	5	8	\N	\N	\N	Preliminary investigation features 	2013-11-13 14:33:32.218+00
1369	\N	8	37	\N	\N	\N	Survey Cooking pit 	2013-11-13 14:33:32.218+00
1370	\N	8	32	\N	\N	\N	Stratigraphy 8445 	2013-11-13 14:33:32.218+00
1371	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1372	\N	8	74	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
1373	\N	8	32	\N	\N	\N	Stratigraphy 12438 	2013-11-13 14:33:32.218+00
1374	\N	8	32	\N	\N	\N	R6728 profile	2013-11-13 14:33:32.218+00
1375	\N	8	74	\N	\N	\N	Stratigraphy depression 	2013-11-13 14:33:32.218+00
1376	\N	8	74	\N	\N	\N	Final investigation stratigraphy S9 	2013-11-13 14:33:32.218+00
1377	\N	8	74	\N	\N	\N	Final investigation stratigraphy 120070 	2013-11-13 14:33:32.218+00
1378	\N	8	33	\N	\N	\N	Final investigation stratigraphy S4 	2013-11-13 14:33:32.218+00
1379	\N	8	37	\N	\N	\N	A20207	2013-11-13 14:33:32.218+00
1380	\N	8	37	\N	\N	\N	Stratigraphy 15 	2013-11-13 14:33:32.218+00
1381	\N	8	32	\N	\N	\N	Stratigraphy A1921 	2013-11-13 14:33:32.218+00
1382	\N	8	37	\N	\N	\N	Stratigraphy 5315 	2013-11-13 14:33:32.218+00
1383	\N	8	32	\N	\N	\N	Burial chamber	2013-11-13 14:33:32.218+00
1384	\N	8	37	\N	\N	\N	Stratigraphy P4B 	2013-11-13 14:33:32.218+00
1385	\N	8	74	\N	\N	\N	Preliminary investigation features	2013-11-13 14:33:32.218+00
1386	\N	8	74	\N	\N	\N	Stratigraphy 13 	2013-11-13 14:33:32.218+00
1387	\N	8	37	\N	\N	\N	Stratigraphy 12672 	2013-11-13 14:33:32.218+00
1388	\N	8	33	\N	\N	\N	Stratigraphy P9 	2013-11-13 14:33:32.218+00
1389	\N	8	33	\N	\N	\N	Final investigation stratigraphy 120355 	2013-11-13 14:33:32.218+00
1390	\N	8	37	\N	\N	\N	Stratigraphy 12 	2013-11-13 14:33:32.218+00
1391	\N	8	32	\N	\N	\N	Final investigation stratigraphy S7 	2013-11-13 14:33:32.218+00
1392	\N	8	74	\N	\N	\N	Stratigraphy 4	2013-11-13 14:33:32.218+00
1393	\N	8	37	\N	\N	\N	A478 stratigraphy 	2013-11-13 14:33:32.218+00
1394	\N	8	74	\N	\N	\N	Stratigraphy 10	2013-11-13 14:33:32.218+00
1395	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1396	\N	8	74	\N	\N	\N	Stratigraphy B, unit 2, Area B 	2013-11-13 14:33:32.218+00
1397	\N	8	74	\N	\N	\N	1998 House 10	2013-11-13 14:33:32.218+00
1398	\N	8	74	\N	\N	\N	1996 House 5	2013-11-13 14:33:32.218+00
1399	\N	8	33	\N	\N	\N	1999 House 11	2013-11-13 14:33:32.218+00
1400	\N	8	74	\N	\N	\N	Trapping pit 1, Stratigraphy 2 	2013-11-13 14:33:32.218+00
1401	\N	8	37	\N	\N	\N	Stratigraphy 12671 	2013-11-13 14:33:32.218+00
1402	\N	8	37	\N	\N	\N	R5876 profile	2013-11-13 14:33:32.218+00
1403	\N	8	74	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
1404	\N	8	37	\N	\N	\N	House 29 post holes 	2013-11-13 14:33:32.218+00
1405	\N	5	8	\N	\N	\N	Post holes	2013-11-13 14:33:32.218+00
1406	\N	8	74	\N	\N	\N	A10000 Stratigraphy 26 	2013-11-13 14:33:32.218+00
1407	\N	8	33	\N	\N	\N	Post holes	2013-11-13 14:33:32.218+00
1408	\N	8	74	\N	\N	\N	Stratigraphy A2 	2013-11-13 14:33:32.218+00
1409	\N	8	37	\N	\N	\N	Stratigraphy P6 	2013-11-13 14:33:32.218+00
1410	\N	8	37	\N	\N	\N	Old wetland stratigraphy 	2013-11-13 14:33:32.218+00
1411	\N	8	74	\N	\N	\N	Trapping pit 1, Stratigraphy 1 	2013-11-13 14:33:32.218+00
1412	\N	8	37	\N	\N	\N	Stratigraphy 14 	2013-11-13 14:33:32.218+00
1413	\N	8	33	\N	\N	\N	Stratigraphy 28015 	2013-11-13 14:33:32.218+00
1414	\N	8	32	\N	\N	\N	Final investigation stratigraphy S6 	2013-11-13 14:33:32.218+00
1415	\N	8	32	\N	\N	\N	1998 House 7	2013-11-13 14:33:32.218+00
1416	\N	8	32	\N	\N	\N	Stratigraphy 7	2013-11-13 14:33:32.218+00
1417	\N	8	37	\N	\N	\N	Stratigraphy 3 	2013-11-13 14:33:32.218+00
1418	\N	8	32	\N	\N	\N	A10000 Stratigraphy 20 	2013-11-13 14:33:32.218+00
1419	\N	8	74	\N	\N	\N	Stratigraphy	2013-11-13 14:33:32.218+00
1420	\N	8	74	\N	\N	\N	MK845 Stratigraphy 	2013-11-13 14:33:32.218+00
1421	\N	8	37	\N	\N	\N	Survey house 5	2013-11-13 14:33:32.218+00
1422	\N	8	74	\N	\N	\N	Stratigraphy 2	2013-11-13 14:33:32.218+00
1423	\N	8	32	\N	\N	\N	Stratigraphy 3:1 	2013-11-13 14:33:32.218+00
1424	\N	8	32	\N	\N	\N	A10000 Stratigraphy 21 	2013-11-13 14:33:32.218+00
1425	\N	8	74	\N	\N	\N	A10000 Stratigraphy 18 	2013-11-13 14:33:32.218+00
1539	\N	8	37	\N	\N	\N	1998 House 6	2013-11-13 14:33:32.218+00
1426	\N	8	32	\N	\N	\N	Preliminary investigation features 	2013-11-13 14:33:32.218+00
1427	\N	8	37	\N	\N	\N	Stratigraphy P8 	2013-11-13 14:33:32.218+00
1428	\N	8	110	\N	\N	\N	R6728 profile	2013-11-13 14:33:32.218+00
1429	\N	8	37	\N	\N	\N	House 3 post holes 	2013-11-13 14:33:32.218+00
1430	\N	8	94	\N	\N	\N	Stratigraphy 43304 	2013-11-13 14:33:32.218+00
1431	\N	8	33	\N	\N	\N	Stratigraphy 3 	2013-11-13 14:33:32.218+00
1432	\N	8	74	\N	\N	\N	Stratigraphy 102, unit 1, Area A 	2013-11-13 14:33:32.218+00
1433	\N	8	37	\N	\N	\N	Final investigation stratigraphy 120020 	2013-11-13 14:33:32.218+00
1434	\N	8	107	\N	\N	\N	R6733 profile	2013-11-13 14:33:32.218+00
1435	\N	8	32	\N	\N	\N	Final investigation stratigraphy 120146 	2013-11-13 14:33:32.218+00
1436	\N	8	32	\N	\N	\N	1996 House 5	2013-11-13 14:33:32.218+00
1437	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1438	\N	8	32	\N	\N	\N	Stratigraphy 12 	2013-11-13 14:33:32.218+00
1439	\N	5	8	\N	\N	\N	1998 House 7	2013-11-13 14:33:32.218+00
1440	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1441	\N	8	33	\N	\N	\N	Survey house 2	2013-11-13 14:33:32.218+00
1442	\N	8	33	\N	\N	\N	1999 Stratigraphy 3042	2013-11-13 14:33:32.218+00
1443	\N	8	37	\N	\N	\N	A10000 Stratigraphy 21 	2013-11-13 14:33:32.218+00
1444	\N	8	74	\N	\N	\N	Stratigraphy 2:6 	2013-11-13 14:33:32.218+00
1445	\N	8	74	\N	\N	\N	House 4 post holes	2013-11-13 14:33:32.218+00
1446	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1447	\N	8	32	\N	\N	\N	Stratigraphy B, unit 2, Area B 	2013-11-13 14:33:32.218+00
1448	\N	8	74	\N	\N	\N	Final investigation stratigraphy S5 	2013-11-13 14:33:32.218+00
1449	\N	6	8	\N	\N	\N	Refuse pit	2013-11-13 14:33:32.218+00
1450	\N	8	74	\N	\N	\N	A20207	2013-11-13 14:33:32.218+00
1451	\N	8	74	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
1452	\N	6	8	\N	\N	\N	Grundsunda Raä 126	2013-11-13 14:33:32.218+00
1453	\N	8	33	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
1454	\N	6	8	\N	\N	\N	Archaeobotany features 	2013-11-13 14:33:32.218+00
1455	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1456	\N	5	8	\N	\N	\N	1998 House 9	2013-11-13 14:33:32.218+00
1457	\N	5	8	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
1458	\N	8	37	\N	\N	\N	Stratigraphy 3	2013-11-13 14:33:32.218+00
1459	\N	8	33	\N	\N	\N	Stratigraphy 100:2 	2013-11-13 14:33:32.218+00
1460	\N	8	32	\N	\N	\N	R6733 profile	2013-11-13 14:33:32.218+00
1461	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1462	\N	8	33	\N	\N	\N	Final investigation stratigraphy S7 	2013-11-13 14:33:32.218+00
1463	\N	8	37	\N	\N	\N	Stratigraphy A6060	2013-11-13 14:33:32.218+00
1464	\N	8	37	\N	\N	\N	Long barrow stratigraphy "Lennart" 	2013-11-13 14:33:32.218+00
1465	\N	8	74	\N	\N	\N	Survey S30	2013-11-13 14:33:32.218+00
1466	\N	8	32	\N	\N	\N	Stratigraphy 12443 	2013-11-13 14:33:32.218+00
1467	\N	6	8	\N	\N	\N	Preliminary investigation	2013-11-13 14:33:32.218+00
1468	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1469	\N	5	8	\N	\N	\N	1999 House 15	2013-11-13 14:33:32.218+00
1470	\N	8	37	\N	\N	\N	A10000 Stratigraphy 25 	2013-11-13 14:33:32.218+00
1471	\N	8	74	\N	\N	\N	A10000 Stratigraphy 17 	2013-11-13 14:33:32.218+00
1472	\N	8	37	\N	\N	\N	Final investigation stratigraphy 120158 	2013-11-13 14:33:32.218+00
1473	\N	8	33	\N	\N	\N	MK12 Stratigraphy 	2013-11-13 14:33:32.218+00
1474	\N	8	74	\N	\N	\N	MK844 Stratigraphy 	2013-11-13 14:33:32.218+00
1475	\N	8	32	\N	\N	\N	Final investigation stratigraphy 120364 	2013-11-13 14:33:32.218+00
1476	\N	8	37	\N	\N	\N	MK845 Stratigraphy 	2013-11-13 14:33:32.218+00
1477	\N	8	37	\N	\N	\N	Stratigraphy A, unit 2, Area B 	2013-11-13 14:33:32.218+00
1478	\N	8	37	\N	\N	\N	Stratigraphy 4:1 	2013-11-13 14:33:32.218+00
1479	\N	8	33	\N	\N	\N	House 4 post holes	2013-11-13 14:33:32.218+00
1480	\N	8	32	\N	\N	\N	Stratigraphy 5 	2013-11-13 14:33:32.218+00
1481	\N	8	32	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
1482	\N	8	33	\N	\N	\N	Stratigraphy 71933 	2013-11-13 14:33:32.218+00
1483	\N	8	37	\N	\N	\N	Final investigation features	2013-11-13 14:33:32.218+00
1484	\N	8	37	\N	\N	\N	House 6 post holes 	2013-11-13 14:33:32.218+00
1485	\N	8	32	\N	\N	\N	A286 Stratigraphy 	2013-11-13 14:33:32.218+00
1486	\N	8	33	\N	\N	\N	Sample group 1	2013-11-13 14:33:32.218+00
1487	\N	5	8	\N	\N	\N	 pollen]	2013-11-13 14:33:32.218+00
1488	\N	8	32	\N	\N	\N	Stratigraphy 4 	2013-11-13 14:33:32.218+00
1489	\N	8	32	\N	\N	\N	Stratigraphy 14 	2013-11-13 14:33:32.218+00
1490	\N	8	37	\N	\N	\N	Vaterland 1	2013-11-13 14:33:32.218+00
1491	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1492	\N	8	33	\N	\N	\N	MK2 Stratigraphy 	2013-11-13 14:33:32.218+00
1493	\N	8	33	\N	\N	\N	Stratigraphy 100:4 	2013-11-13 14:33:32.218+00
1494	\N	8	33	\N	\N	\N	A46091 Survey 	2013-11-13 14:33:32.218+00
1495	\N	8	32	\N	\N	\N	Stratigraphy 8 	2013-11-13 14:33:32.218+00
1496	\N	8	37	\N	\N	\N	Stratigraphy 6 	2013-11-13 14:33:32.218+00
1497	\N	8	37	\N	\N	\N	Stratigraphy 6436 	2013-11-13 14:33:32.218+00
1498	\N	8	32	\N	\N	\N	2007 investigation	2013-11-13 14:33:32.218+00
1499	\N	8	32	\N	\N	\N	Stratigraphy C, unit 2, Area B/D 	2013-11-13 14:33:32.218+00
1500	\N	8	33	\N	\N	\N	Stratigraphy 13 	2013-11-13 14:33:32.218+00
1501	\N	8	74	\N	\N	\N	1999 Stratigraphy 3047	2013-11-13 14:33:32.218+00
1502	\N	8	37	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
1503	\N	8	37	\N	\N	\N	A286 Stratigraphy 	2013-11-13 14:33:32.218+00
1504	\N	8	32	\N	\N	\N	Stratigraphy 1 	2013-11-13 14:33:32.218+00
1505	\N	8	32	\N	\N	\N	Features house 1	2013-11-13 14:33:32.218+00
1506	\N	8	32	\N	\N	\N	Stratigraphy 1	2013-11-13 14:33:32.218+00
1507	\N	8	37	\N	\N	\N	Stratigraphy 1 	2013-11-13 14:33:32.218+00
1508	\N	5	8	\N	\N	\N	Preliminary investigation features	2013-11-13 14:33:32.218+00
1509	\N	8	33	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
1510	\N	8	37	\N	\N	\N	Stratigraphy 8444 	2013-11-13 14:33:32.218+00
1511	\N	8	74	\N	\N	\N	Stratigraphy A1921 	2013-11-13 14:33:32.218+00
1512	\N	8	74	\N	\N	\N	Stratigraphy 8753 	2013-11-13 14:33:32.218+00
1513	\N	8	33	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
1514	\N	8	32	\N	\N	\N	1999 Stratigraphy 3042	2013-11-13 14:33:32.218+00
1515	\N	6	8	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
1516	\N	8	32	\N	\N	\N	MK14 Stratigraphy 	2013-11-13 14:33:32.218+00
1517	\N	5	8	\N	\N	\N	 pollen]	2013-11-13 14:33:32.218+00
1518	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1519	\N	8	32	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
1520	\N	8	74	\N	\N	\N	Final investigation stratigraphy 120082 	2013-11-13 14:33:32.218+00
1521	\N	8	32	\N	\N	\N	Final investigation stratigraphy S5 	2013-11-13 14:33:32.218+00
1522	\N	8	32	\N	\N	\N	Stratigraphy 7070 	2013-11-13 14:33:32.218+00
1523	\N	8	37	\N	\N	\N	Preliminary investigation stratigraphy 00_0117	2013-11-13 14:33:32.218+00
1524	\N	8	32	\N	\N	\N	Stratigraphy 2:3 	2013-11-13 14:33:32.218+00
1525	\N	8	33	\N	\N	\N	Gastropod samples 	2013-11-13 14:33:32.218+00
1526	\N	8	32	\N	\N	\N	Tuft 1	2013-11-13 14:33:32.218+00
1527	\N	8	37	\N	\N	\N	A10000 Stratigraphy 18 	2013-11-13 14:33:32.218+00
1528	\N	8	37	\N	\N	\N	Stratigraphy 12437 	2013-11-13 14:33:32.218+00
1529	\N	8	74	\N	\N	\N	1999 House 15	2013-11-13 14:33:32.218+00
1530	\N	5	8	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
1531	\N	8	119	\N	\N	\N	Trapping pit stratigraphy 4, PJ3497 	2013-11-13 14:33:32.218+00
1532	\N	8	33	\N	\N	\N	Stratigraphy 100:1 	2013-11-13 14:33:32.218+00
1533	\N	8	74	\N	\N	\N	Stratigraphy 4 	2013-11-13 14:33:32.218+00
1534	\N	5	8	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
1535	\N	8	74	\N	\N	\N	1999 House 13	2013-11-13 14:33:32.218+00
1536	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1537	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1538	\N	8	36	\N	\N	\N	Vaterland 1	2013-11-13 14:33:32.218+00
1540	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1541	\N	5	8	\N	\N	\N	1999 Features	2013-11-13 14:33:32.218+00
1542	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1543	\N	8	74	\N	\N	\N	MK18 Stratigraphy 	2013-11-13 14:33:32.218+00
1544	\N	8	37	\N	\N	\N	Stratigraphy 3 	2013-11-13 14:33:32.218+00
1545	\N	8	32	\N	\N	\N	Final excavation	2013-11-13 14:33:32.218+00
1546	\N	8	74	\N	\N	\N	Lok 1	2013-11-13 14:33:32.218+00
1547	\N	8	32	\N	\N	\N	House 2 post holes	2013-11-13 14:33:32.218+00
1548	\N	8	32	\N	\N	\N	MK10 Stratigraphy 	2013-11-13 14:33:32.218+00
1549	\N	8	32	\N	\N	\N	Features house 10	2013-11-13 14:33:32.218+00
1550	\N	6	8	\N	\N	\N	Cellar	2013-11-13 14:33:32.218+00
1551	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1552	\N	8	74	\N	\N	\N	Stratigraphy 100:1 	2013-11-13 14:33:32.218+00
1553	\N	8	94	\N	\N	\N	Stratigraphy 12441 	2013-11-13 14:33:32.218+00
1554	\N	8	74	\N	\N	\N	Stratigraphy A114 	2013-11-13 14:33:32.218+00
1555	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1556	\N	8	32	\N	\N	\N	Final investigation stratigraphy 120185 	2013-11-13 14:33:32.218+00
1557	\N	8	37	\N	\N	\N	1999 Straigraphy 3045	2013-11-13 14:33:32.218+00
1558	\N	8	32	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
1559	\N	8	37	\N	\N	\N	Survey house 2	2013-11-13 14:33:32.218+00
1560	\N	8	74	\N	\N	\N	Stratigraphy 53 	2013-11-13 14:33:32.218+00
1561	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1562	\N	8	37	\N	\N	\N	Survey S31	2013-11-13 14:33:32.218+00
1563	\N	8	74	\N	\N	\N	Final investigation stratigraphy 120011 	2013-11-13 14:33:32.218+00
1564	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1565	\N	8	37	\N	\N	\N	House 2 post holes	2013-11-13 14:33:32.218+00
1566	\N	8	74	\N	\N	\N	2007 investigation	2013-11-13 14:33:32.218+00
1567	\N	8	33	\N	\N	\N	Stratigraphy 5 	2013-11-13 14:33:32.218+00
1568	\N	8	33	\N	\N	\N	Features house 10	2013-11-13 14:33:32.218+00
1569	\N	8	32	\N	\N	\N	Preliminary investigation stratigraphy 00_0115	2013-11-13 14:33:32.218+00
1570	\N	5	8	\N	\N	\N	Sample group 1	2013-11-13 14:33:32.218+00
1571	\N	8	37	\N	\N	\N	House 1	2013-11-13 14:33:32.218+00
1572	\N	8	37	\N	\N	\N	Preliminary investigation features	2013-11-13 14:33:32.218+00
1573	\N	8	74	\N	\N	\N	Preliminary investigation stratigraphy 00_0115	2013-11-13 14:33:32.218+00
1574	\N	8	74	\N	\N	\N	Final investigation stratigraphy 120029 	2013-11-13 14:33:32.218+00
1575	\N	8	37	\N	\N	\N	Final investigation stratigraphy S8 	2013-11-13 14:33:32.218+00
1576	\N	5	8	\N	\N	\N	Road embankment	2013-11-13 14:33:32.218+00
1577	\N	5	8	\N	\N	\N	1993 investigation	2013-11-13 14:33:32.218+00
1578	\N	5	8	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
1579	\N	8	37	\N	\N	\N	Features house 1	2013-11-13 14:33:32.218+00
1580	\N	8	33	\N	\N	\N	Lok 1	2013-11-13 14:33:32.218+00
1581	\N	8	37	\N	\N	\N	MK11 Stratigraphy 	2013-11-13 14:33:32.218+00
1582	\N	8	33	\N	\N	\N	Stratigraphy 5:2 	2013-11-13 14:33:32.218+00
1583	\N	8	33	\N	\N	\N	Profile 1	2013-11-13 14:33:32.218+00
1584	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1585	\N	8	32	\N	\N	\N	Stratigraphy 12437 	2013-11-13 14:33:32.218+00
1586	\N	8	74	\N	\N	\N	House 9 post holes	2013-11-13 14:33:32.218+00
1587	\N	8	37	\N	\N	\N	Stratigraphy 4 	2013-11-13 14:33:32.218+00
1588	\N	8	32	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
1589	\N	8	33	\N	\N	\N	Stratigraphy 14 	2013-11-13 14:33:32.218+00
1590	\N	8	33	\N	\N	\N	Stratigraphy 6	2013-11-13 14:33:32.218+00
1591	\N	8	37	\N	\N	\N	1996 House 5	2013-11-13 14:33:32.218+00
1592	\N	5	8	\N	\N	\N	1994 investigation	2013-11-13 14:33:32.218+00
1593	\N	8	37	\N	\N	\N	Stratigraphy 100:2 	2013-11-13 14:33:32.218+00
1594	\N	8	32	\N	\N	\N	Stratigraphy 8753 	2013-11-13 14:33:32.218+00
1595	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1596	\N	8	74	\N	\N	\N	MK7 Stratigraphy 	2013-11-13 14:33:32.218+00
1597	\N	8	37	\N	\N	\N	A1469 stratigraphy 	2013-11-13 14:33:32.218+00
1598	\N	8	37	\N	\N	\N	Stratigraphy 28013 	2013-11-13 14:33:32.218+00
1599	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1600	\N	8	74	\N	\N	\N	Survey P3	2013-11-13 14:33:32.218+00
1601	\N	8	32	\N	\N	\N	Profile 1	2013-11-13 14:33:32.218+00
1602	\N	8	37	\N	\N	\N	Stratigraphy 2:2 	2013-11-13 14:33:32.218+00
1603	\N	8	37	\N	\N	\N	House 9 post holes	2013-11-13 14:33:32.218+00
1604	\N	8	37	\N	\N	\N	1999 House 12	2013-11-13 14:33:32.218+00
1605	\N	8	37	\N	\N	\N	Stratigraphy 16 	2013-11-13 14:33:32.218+00
1606	\N	8	74	\N	\N	\N	Stratigraphy P5 	2013-11-13 14:33:32.218+00
1607	\N	5	8	\N	\N	\N	Preliminary investigation features 	2013-11-13 14:33:32.218+00
1608	\N	8	37	\N	\N	\N	MK7 Stratigraphy 	2013-11-13 14:33:32.218+00
1609	\N	8	74	\N	\N	\N	Stratigraphy 12443 	2013-11-13 14:33:32.218+00
1610	\N	8	33	\N	\N	\N	A11216	2013-11-13 14:33:32.218+00
1611	\N	5	8	\N	\N	\N	 pollen]	2013-11-13 14:33:32.218+00
1612	\N	8	74	\N	\N	\N	MK19 Stratigraphy 	2013-11-13 14:33:32.218+00
1613	\N	8	37	\N	\N	\N	House 3	2013-11-13 14:33:32.218+00
1614	\N	8	33	\N	\N	\N	House 3 post holes 	2013-11-13 14:33:32.218+00
1615	\N	8	32	\N	\N	\N	Stratigraphy 12442 	2013-11-13 14:33:32.218+00
1616	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1617	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1618	\N	8	37	\N	\N	\N	House 4	2013-11-13 14:33:32.218+00
1619	\N	8	37	\N	\N	\N	1999 Features	2013-11-13 14:33:32.218+00
1620	\N	8	37	\N	\N	\N	Stratigraphy A114 	2013-11-13 14:33:32.218+00
1621	\N	5	8	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
1622	\N	8	37	\N	\N	\N	Stratigraphy 2:4 	2013-11-13 14:33:32.218+00
1623	\N	8	32	\N	\N	\N	Stratigraphy 12441 	2013-11-13 14:33:32.218+00
1624	\N	8	74	\N	\N	\N	MK8 Stratigraphy 	2013-11-13 14:33:32.218+00
1625	\N	5	8	\N	\N	\N	Cellar	2013-11-13 14:33:32.218+00
1626	\N	8	32	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
1627	\N	8	74	\N	\N	\N	Stratigraphy C, unit 2, Area B/D 	2013-11-13 14:33:32.218+00
1628	\N	8	33	\N	\N	\N	Stratigraphy 2:1 	2013-11-13 14:33:32.218+00
1629	\N	8	74	\N	\N	\N	Stratigraphy 14 	2013-11-13 14:33:32.218+00
1630	\N	8	37	\N	\N	\N	Stratigraphy 100:1 	2013-11-13 14:33:32.218+00
1631	\N	8	37	\N	\N	\N	MK13 Stratigraphy 	2013-11-13 14:33:32.218+00
1632	\N	8	74	\N	\N	\N	Stratigraphy 12444 	2013-11-13 14:33:32.218+00
1633	\N	8	74	\N	\N	\N	MK14 Stratigraphy 	2013-11-13 14:33:32.218+00
1634	\N	5	8	\N	\N	\N	A54	2013-11-13 14:33:32.218+00
1635	\N	8	74	\N	\N	\N	Final investigation stratigraphy 120355 	2013-11-13 14:33:32.218+00
1636	\N	8	37	\N	\N	\N	Cave	2013-11-13 14:33:32.218+00
1637	\N	8	74	\N	\N	\N	Stratigraphy 7070 	2013-11-13 14:33:32.218+00
1638	\N	8	32	\N	\N	\N	Stratigraphy 4	2013-11-13 14:33:32.218+00
1848	\N	8	32	\N	\N	\N	A11216	2013-11-13 14:33:32.218+00
1639	\N	8	37	\N	\N	\N	Final investigation stratigraphy 120082 	2013-11-13 14:33:32.218+00
1640	\N	8	32	\N	\N	\N	Stratigraphy P2	2013-11-13 14:33:32.218+00
1641	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1642	\N	8	32	\N	\N	\N	1999 House 11	2013-11-13 14:33:32.218+00
1643	\N	8	33	\N	\N	\N	Survey Cooking pit 	2013-11-13 14:33:32.218+00
1644	\N	8	33	\N	\N	\N	Final investigation stratigraphy 120128 	2013-11-13 14:33:32.218+00
1645	\N	8	74	\N	\N	\N	Stratigraphy P9 	2013-11-13 14:33:32.218+00
1646	\N	8	32	\N	\N	\N	MK18 Stratigraphy 	2013-11-13 14:33:32.218+00
1761	\N	8	37	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
1647	\N	6	8	\N	\N	\N	Preliminary investigation	2013-11-13 14:33:32.218+00
1648	\N	8	32	\N	\N	\N	Stratigraphy 102, unit 1, Area A 	2013-11-13 14:33:32.218+00
1649	\N	8	37	\N	\N	\N	Profile 1	2013-11-13 14:33:32.218+00
1650	\N	8	32	\N	\N	\N	Final investigation stratigraphy 120020 	2013-11-13 14:33:32.218+00
1651	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1652	\N	8	33	\N	\N	\N	A10000 Stratigraphy 26 	2013-11-13 14:33:32.218+00
1884	\N	8	37	\N	\N	\N	Trench 6	2013-11-13 14:33:32.218+00
1653	\N	8	37	\N	\N	\N	Stratigraphy 2:6 	2013-11-13 14:33:32.218+00
1654	\N	8	37	\N	\N	\N	Stratigraphy 6	2013-11-13 14:33:32.218+00
1655	\N	8	74	\N	\N	\N	Karleby 105:1	2013-11-13 14:33:32.218+00
1656	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1657	\N	8	94	\N	\N	\N	Stratigraphy A114 	2013-11-13 14:33:32.218+00
1658	\N	8	32	\N	\N	\N	Stratigraphy 5:3 	2013-11-13 14:33:32.218+00
1659	\N	8	32	\N	\N	\N	1999 House 12	2013-11-13 14:33:32.218+00
1660	\N	8	33	\N	\N	\N	Final investigation stratigraphy S5 	2013-11-13 14:33:32.218+00
1661	\N	8	37	\N	\N	\N	Stratigraphy 3	2013-11-13 14:33:32.218+00
1662	\N	8	37	\N	\N	\N	Stratigraphy 2:5 	2013-11-13 14:33:32.218+00
1663	\N	8	37	\N	\N	\N	Stratigraphy P3B 	2013-11-13 14:33:32.218+00
1664	\N	8	32	\N	\N	\N	Stratigraphy 4:1 	2013-11-13 14:33:32.218+00
1665	\N	5	8	\N	\N	\N	House 4	2013-11-13 14:33:32.218+00
1666	\N	8	74	\N	\N	\N	Stratigraphy P4 	2013-11-13 14:33:32.218+00
1667	\N	8	74	\N	\N	\N	1998 House 6	2013-11-13 14:33:32.218+00
1668	\N	8	109	\N	\N	\N	R6728 profile	2013-11-13 14:33:32.218+00
1669	\N	8	37	\N	\N	\N	Preliminary investigation stratigraphy 00_0082_1 	2013-11-13 14:33:32.218+00
1670	\N	8	37	\N	\N	\N	Stratigraphy 5:2 	2013-11-13 14:33:32.218+00
1671	\N	8	32	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
1672	\N	5	8	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
1673	\N	8	33	\N	\N	\N	Stratigraphy 8444 	2013-11-13 14:33:32.218+00
1674	\N	8	74	\N	\N	\N	House 2	2013-11-13 14:33:32.218+00
1675	\N	8	37	\N	\N	\N	R6728 profile	2013-11-13 14:33:32.218+00
1676	\N	8	33	\N	\N	\N	Stratigraphy P8 	2013-11-13 14:33:32.218+00
1677	\N	8	37	\N	\N	\N	Stratigraphy 71932 	2013-11-13 14:33:32.218+00
1678	\N	8	37	\N	\N	\N	MK9 Stratigraphy 	2013-11-13 14:33:32.218+00
1679	\N	8	37	\N	\N	\N	Final investigation stratigraphy S5 	2013-11-13 14:33:32.218+00
1680	\N	8	32	\N	\N	\N	Stratigraphy 2:4 	2013-11-13 14:33:32.218+00
1681	\N	8	37	\N	\N	\N	A21146 Stratigraphy 	2013-11-13 14:33:32.218+00
1682	\N	8	32	\N	\N	\N	Stratigraphy 100:7 	2013-11-13 14:33:32.218+00
1683	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1684	\N	8	37	\N	\N	\N	Post holes	2013-11-13 14:33:32.218+00
1685	\N	8	37	\N	\N	\N	Stratigraphy 12443 	2013-11-13 14:33:32.218+00
1686	\N	8	37	\N	\N	\N	MK14 Stratigraphy 	2013-11-13 14:33:32.218+00
1687	\N	8	74	\N	\N	\N	Stratigraphy 4:2 	2013-11-13 14:33:32.218+00
1688	\N	5	8	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
1689	\N	8	32	\N	\N	\N	House 1	2013-11-13 14:33:32.218+00
1690	\N	8	33	\N	\N	\N	Stratigraphy P1	2013-11-13 14:33:32.218+00
1691	\N	8	37	\N	\N	\N	Stratigraphy 12441 	2013-11-13 14:33:32.218+00
1692	\N	8	74	\N	\N	\N	Stratigraphy 100:5 	2013-11-13 14:33:32.218+00
1693	\N	8	74	\N	\N	\N	Stratigraphy 43303 	2013-11-13 14:33:32.218+00
1694	\N	8	37	\N	\N	\N	1999 Stratigraphy 3047	2013-11-13 14:33:32.218+00
1695	\N	8	74	\N	\N	\N	R6728 profile	2013-11-13 14:33:32.218+00
1696	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1697	\N	8	33	\N	\N	\N	Stratigraphy 5:3 	2013-11-13 14:33:32.218+00
1698	\N	8	37	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
1699	\N	8	74	\N	\N	\N	Stratigraphy P3B 	2013-11-13 14:33:32.218+00
1700	\N	8	37	\N	\N	\N	House 14 post holes 	2013-11-13 14:33:32.218+00
1701	\N	8	37	\N	\N	\N	Final investigation stratigraphy 120355 	2013-11-13 14:33:32.218+00
1702	\N	5	8	\N	\N	\N	1993 investigation	2013-11-13 14:33:32.218+00
1703	\N	8	37	\N	\N	\N	1999 Stratigraphy 3044	2013-11-13 14:33:32.218+00
1704	\N	8	74	\N	\N	\N	Tuft 2	2013-11-13 14:33:32.218+00
1705	\N	8	74	\N	\N	\N	Sample group 1	2013-11-13 14:33:32.218+00
1706	\N	8	37	\N	\N	\N	Tuft 2	2013-11-13 14:33:32.218+00
1707	\N	8	74	\N	\N	\N	Superimposed topsoil 	2013-11-13 14:33:32.218+00
1708	\N	8	33	\N	\N	\N	Survey Cooking pit 	2013-11-13 14:33:32.218+00
1709	\N	8	74	\N	\N	\N	1999 House 11	2013-11-13 14:33:32.218+00
1710	\N	8	33	\N	\N	\N	A10000 Stratigraphy 24 	2013-11-13 14:33:32.218+00
1711	\N	8	37	\N	\N	\N	Survey P3	2013-11-13 14:33:32.218+00
1712	\N	8	37	\N	\N	\N	1998 House 10	2013-11-13 14:33:32.218+00
1713	\N	8	37	\N	\N	\N	Final investigation stratigraphy 120131 	2013-11-13 14:33:32.218+00
1714	\N	8	32	\N	\N	\N	Tuft 2	2013-11-13 14:33:32.218+00
1715	\N	8	32	\N	\N	\N	Profile 2	2013-11-13 14:33:32.218+00
1716	\N	8	33	\N	\N	\N	Superimposed topsoil 	2013-11-13 14:33:32.218+00
1717	\N	5	8	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
1718	\N	5	8	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
1719	\N	8	33	\N	\N	\N	Survey house 4	2013-11-13 14:33:32.218+00
1720	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1721	\N	8	74	\N	\N	\N	Stratigraphy 6	2013-11-13 14:33:32.218+00
1722	\N	8	74	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
1723	\N	8	37	\N	\N	\N	Stratigraphy 2 	2013-11-13 14:33:32.218+00
1724	\N	8	33	\N	\N	\N	Stratigraphy P3B 	2013-11-13 14:33:32.218+00
1725	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1726	\N	8	37	\N	\N	\N	House 5 post holes	2013-11-13 14:33:32.218+00
1727	\N	8	74	\N	\N	\N	Stratigraphy P8 	2013-11-13 14:33:32.218+00
1728	\N	8	74	\N	\N	\N	1996 House 3	2013-11-13 14:33:32.218+00
1729	\N	8	74	\N	\N	\N	House 7 post holes	2013-11-13 14:33:32.218+00
1730	\N	6	8	\N	\N	\N	1993 investigation	2013-11-13 14:33:32.218+00
1731	\N	8	32	\N	\N	\N	Vaterland 1	2013-11-13 14:33:32.218+00
1732	\N	6	8	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
1733	\N	8	32	\N	\N	\N	Stratigraphy 101, unit 1, Area A 	2013-11-13 14:33:32.218+00
1734	\N	8	32	\N	\N	\N	1999 Straigraphy 3045	2013-11-13 14:33:32.218+00
1735	\N	8	37	\N	\N	\N	Tuft 6	2013-11-13 14:33:32.218+00
1736	\N	8	32	\N	\N	\N	MK12 Stratigraphy 	2013-11-13 14:33:32.218+00
1737	\N	8	37	\N	\N	\N	2007 investigation	2013-11-13 14:33:32.218+00
1738	\N	6	8	\N	\N	\N	 pollen]	2013-11-13 14:33:32.218+00
1739	\N	8	94	\N	\N	\N	Survey MHM12748 	2013-11-13 14:33:32.218+00
1740	\N	8	32	\N	\N	\N	Stratigraphy 3	2013-11-13 14:33:32.218+00
1741	\N	8	32	\N	\N	\N	1998 House 9	2013-11-13 14:33:32.218+00
1742	\N	8	32	\N	\N	\N	1996 House 5	2013-11-13 14:33:32.218+00
1743	\N	8	32	\N	\N	\N	A10000 Stratigraphy 24 	2013-11-13 14:33:32.218+00
1744	\N	5	8	\N	\N	\N	House 9	2013-11-13 14:33:32.218+00
1745	\N	8	37	\N	\N	\N	Lok 2	2013-11-13 14:33:32.218+00
1746	\N	8	33	\N	\N	\N	Stratigraphy P7 	2013-11-13 14:33:32.218+00
1747	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1748	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1749	\N	8	74	\N	\N	\N	Final investigation stratigraphy 120146 	2013-11-13 14:33:32.218+00
1750	\N	8	37	\N	\N	\N	Final investigation stratigraphy S9 	2013-11-13 14:33:32.218+00
1751	\N	8	37	\N	\N	\N	House 6 post holes	2013-11-13 14:33:32.218+00
1752	\N	8	37	\N	\N	\N	1999 Stratigraphy 3043	2013-11-13 14:33:32.218+00
1753	\N	5	8	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
1754	\N	8	74	\N	\N	\N	Final investigation stratigraphy 120364 	2013-11-13 14:33:32.218+00
1755	\N	5	8	\N	\N	\N	1993 investigation	2013-11-13 14:33:32.218+00
1756	\N	8	74	\N	\N	\N	Final investigation stratigraphy S4 	2013-11-13 14:33:32.218+00
1757	\N	8	74	\N	\N	\N	Stratigraphy 6292 	2013-11-13 14:33:32.218+00
1758	\N	8	74	\N	\N	\N	1999 Straigraphy 3045	2013-11-13 14:33:32.218+00
1759	\N	8	74	\N	\N	\N	Final investigation stratigraphy 120119 	2013-11-13 14:33:32.218+00
1760	\N	8	37	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
1762	\N	8	109	\N	\N	\N	R6733 profile	2013-11-13 14:33:32.218+00
1763	\N	8	37	\N	\N	\N	Preliminary investigation stratigraphy 00_0082_2 	2013-11-13 14:33:32.218+00
1764	\N	8	74	\N	\N	\N	Stratigraphy 100:7 	2013-11-13 14:33:32.218+00
1765	\N	8	37	\N	\N	\N	MK844 Stratigraphy 	2013-11-13 14:33:32.218+00
1766	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1767	\N	5	8	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
1768	\N	8	32	\N	\N	\N	A10000 Stratigraphy 17 	2013-11-13 14:33:32.218+00
1769	\N	6	8	\N	\N	\N	Gamlestaden 740:142 Preliminary investigation 2010	2013-11-13 14:33:32.218+00
1770	\N	8	74	\N	\N	\N	1999 Stratigraphy 3042	2013-11-13 14:33:32.218+00
1771	\N	8	32	\N	\N	\N	House 3	2013-11-13 14:33:32.218+00
1772	\N	8	74	\N	\N	\N	A75	2013-11-13 14:33:32.218+00
1773	\N	5	8	\N	\N	\N	1993 investigation	2013-11-13 14:33:32.218+00
1774	\N	8	37	\N	\N	\N	Karleby 105:1	2013-11-13 14:33:32.218+00
1775	\N	8	33	\N	\N	\N	Survey P3	2013-11-13 14:33:32.218+00
1776	\N	8	74	\N	\N	\N	Final investigation stratigraphy S10 	2013-11-13 14:33:32.218+00
1777	\N	8	37	\N	\N	\N	Stratigraphy 2 	2013-11-13 14:33:32.218+00
1778	\N	5	8	\N	\N	\N	1996 House 5	2013-11-13 14:33:32.218+00
1779	\N	8	37	\N	\N	\N	Stratigraphy P2	2013-11-13 14:33:32.218+00
1780	\N	8	33	\N	\N	\N	Cave	2013-11-13 14:33:32.218+00
1781	\N	5	8	\N	\N	\N	Trench 6	2013-11-13 14:33:32.218+00
1782	\N	8	32	\N	\N	\N	House 9 post holes	2013-11-13 14:33:32.218+00
1783	\N	8	74	\N	\N	\N	A10000 Stratigraphy 24 	2013-11-13 14:33:32.218+00
1784	\N	6	8	\N	\N	\N	Sample group 1	2013-11-13 14:33:32.218+00
1785	\N	8	33	\N	\N	\N	Survey house 6	2013-11-13 14:33:32.218+00
1786	\N	8	37	\N	\N	\N	MK10 Stratigraphy 	2013-11-13 14:33:32.218+00
1787	\N	8	37	\N	\N	\N	1999 Stratigraphy 3046	2013-11-13 14:33:32.218+00
1788	\N	8	37	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
1789	\N	8	37	\N	\N	\N	Stratigraphy 1:2 	2013-11-13 14:33:32.218+00
1790	\N	8	74	\N	\N	\N	Post holes	2013-11-13 14:33:32.218+00
1791	\N	8	74	\N	\N	\N	MK10 Stratigraphy 	2013-11-13 14:33:32.218+00
1792	\N	8	37	\N	\N	\N	Gastropod samples 	2013-11-13 14:33:32.218+00
1793	\N	8	37	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
1794	\N	8	74	\N	\N	\N	Final investigation stratigraphy 120185 	2013-11-13 14:33:32.218+00
1795	\N	8	32	\N	\N	\N	1999 Features	2013-11-13 14:33:32.218+00
1796	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1797	\N	8	37	\N	\N	\N	Final investigation stratigraphy 120070 	2013-11-13 14:33:32.218+00
1798	\N	8	37	\N	\N	\N	A75	2013-11-13 14:33:32.218+00
1799	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1800	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1801	\N	8	37	\N	\N	\N	Final investigation stratigraphy S4 	2013-11-13 14:33:32.218+00
1802	\N	8	74	\N	\N	\N	House 4	2013-11-13 14:33:32.218+00
1803	\N	8	74	\N	\N	\N	House 6 post holes	2013-11-13 14:33:32.218+00
1804	\N	8	37	\N	\N	\N	A10000 Stratigraphy 26 	2013-11-13 14:33:32.218+00
1805	\N	8	74	\N	\N	\N	Stratigraphy 5 	2013-11-13 14:33:32.218+00
1806	\N	5	8	\N	\N	\N	Sample group 1	2013-11-13 14:33:32.218+00
1807	\N	8	74	\N	\N	\N	Lok 2	2013-11-13 14:33:32.218+00
1808	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1809	\N	8	33	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1810	\N	8	37	\N	\N	\N	Final excavation	2013-11-13 14:33:32.218+00
1811	\N	8	37	\N	\N	\N	Stratigraphy 12436 	2013-11-13 14:33:32.218+00
1812	\N	8	74	\N	\N	\N	1999 Stratigraphy 3044	2013-11-13 14:33:32.218+00
1813	\N	5	8	\N	\N	\N	Karleby 105:1	2013-11-13 14:33:32.218+00
1814	\N	8	37	\N	\N	\N	1999 House 13	2013-11-13 14:33:32.218+00
1815	\N	8	32	\N	\N	\N	Stratigraphy 100:6 	2013-11-13 14:33:32.218+00
1816	\N	8	37	\N	\N	\N	Stratigraphy P5 	2013-11-13 14:33:32.218+00
1817	\N	8	37	\N	\N	\N	Preliminary investigation features 	2013-11-13 14:33:32.218+00
1818	\N	8	74	\N	\N	\N	Vaterland 1	2013-11-13 14:33:32.218+00
1819	\N	8	37	\N	\N	\N	Hearth	2013-11-13 14:33:32.218+00
1820	\N	8	32	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
1821	\N	8	32	\N	\N	\N	MK13 Stratigraphy 	2013-11-13 14:33:32.218+00
1822	\N	8	32	\N	\N	\N	Superimposed topsoil 	2013-11-13 14:33:32.218+00
1823	\N	8	32	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
1824	\N	8	32	\N	\N	\N	Lok 1	2013-11-13 14:33:32.218+00
1825	\N	5	8	\N	\N	\N	1999 House 12	2013-11-13 14:33:32.218+00
1826	\N	5	8	\N	\N	\N	 pollen]	2013-11-13 14:33:32.218+00
1827	\N	8	37	\N	\N	\N	House 4 post holes	2013-11-13 14:33:32.218+00
1828	\N	8	37	\N	\N	\N	Stratigraphy P9 	2013-11-13 14:33:32.218+00
1829	\N	6	8	\N	\N	\N	House 3	2013-11-13 14:33:32.218+00
1830	\N	5	8	\N	\N	\N	Preliminary investigation	2013-11-13 14:33:32.218+00
1831	\N	8	74	\N	\N	\N	Preliminary investigation stratigraphy 00_0082_1 	2013-11-13 14:33:32.218+00
1832	\N	8	107	\N	\N	\N	R6728 profile	2013-11-13 14:33:32.218+00
1833	\N	8	37	\N	\N	\N	Survey house 6	2013-11-13 14:33:32.218+00
1834	\N	8	74	\N	\N	\N	Preliminary investigation features 	2013-11-13 14:33:32.218+00
1835	\N	5	8	\N	\N	\N	1994 investigation	2013-11-13 14:33:32.218+00
1836	\N	8	37	\N	\N	\N	Stratigraphy 1	2013-11-13 14:33:32.218+00
1837	\N	8	37	\N	\N	\N	Stratigraphy 102, unit 1, Area A 	2013-11-13 14:33:32.218+00
1838	\N	10	8	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
1839	\N	5	8	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
1840	\N	8	32	\N	\N	\N	1999 House 15	2013-11-13 14:33:32.218+00
1841	\N	8	37	\N	\N	\N	House 8 post holes	2013-11-13 14:33:32.218+00
1842	\N	8	32	\N	\N	\N	House 6 post holes	2013-11-13 14:33:32.218+00
1843	\N	8	37	\N	\N	\N	Stratigraphy 1 	2013-11-13 14:33:32.218+00
1844	\N	8	37	\N	\N	\N	Superimposed topsoil 	2013-11-13 14:33:32.218+00
1845	\N	6	8	\N	\N	\N	Egnellska huset 2010	2013-11-13 14:33:32.218+00
1846	\N	5	8	\N	\N	\N	 pollen]	2013-11-13 14:33:32.218+00
2917	\N	5	8	\N	\N	\N	Features	2014-02-19 14:28:44.312+00
1847	\N	8	37	\N	\N	\N	Final investigation stratigraphy 120364 	2013-11-13 14:33:32.218+00
1849	\N	8	33	\N	\N	\N	1999 House 13	2013-11-13 14:33:32.218+00
1850	\N	8	74	\N	\N	\N	Features house 10	2013-11-13 14:33:32.218+00
1851	\N	8	32	\N	\N	\N	Hearth	2013-11-13 14:33:32.218+00
1852	\N	6	8	\N	\N	\N	House 4	2013-11-13 14:33:32.218+00
1853	\N	8	74	\N	\N	\N	Final excavation	2013-11-13 14:33:32.218+00
1854	\N	5	8	\N	\N	\N	A75	2013-11-13 14:33:32.218+00
1855	\N	5	8	\N	\N	\N	House 1	2013-11-13 14:33:32.218+00
1856	\N	8	32	\N	\N	\N	Lok 2	2013-11-13 14:33:32.218+00
1857	\N	8	37	\N	\N	\N	Stratigraphy 4 	2013-11-13 14:33:32.218+00
1858	\N	8	74	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
1859	\N	6	8	\N	\N	\N	1988-1989 investigation	2013-11-13 14:33:32.218+00
1860	\N	8	33	\N	\N	\N	A75	2013-11-13 14:33:32.218+00
1861	\N	8	37	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
1862	\N	8	37	\N	\N	\N	Survey	2013-11-13 14:33:32.218+00
1863	\N	5	8	\N	\N	\N	Hearths	2013-11-13 14:33:32.218+00
1864	\N	8	37	\N	\N	\N	Lok 1	2013-11-13 14:33:32.218+00
1865	\N	8	32	\N	\N	\N	1999 House 13	2013-11-13 14:33:32.218+00
1866	\N	8	32	\N	\N	\N	1999 Stratigraphy 3043	2013-11-13 14:33:32.218+00
1867	\N	8	37	\N	\N	\N	1996 House 5	2013-11-13 14:33:32.218+00
1868	\N	8	33	\N	\N	\N	Trench 6	2013-11-13 14:33:32.218+00
1869	\N	8	37	\N	\N	\N	Final investigation stratigraphy 120029 	2013-11-13 14:33:32.218+00
1870	\N	8	32	\N	\N	\N	House 4	2013-11-13 14:33:32.218+00
1871	\N	8	33	\N	\N	\N	Preliminary investigation features	2013-11-13 14:33:32.218+00
1872	\N	8	32	\N	\N	\N	Gastropod samples 	2013-11-13 14:33:32.218+00
1873	\N	5	8	\N	\N	\N	House 4	2013-11-13 14:33:32.218+00
1874	\N	8	74	\N	\N	\N	Gastropod samples 	2013-11-13 14:33:32.218+00
1875	\N	8	33	\N	\N	\N	House 7 post holes	2013-11-13 14:33:32.218+00
1876	\N	8	32	\N	\N	\N	A10000 Stratigraphy 26 	2013-11-13 14:33:32.218+00
1877	\N	8	37	\N	\N	\N	Sample group 1	2013-11-13 14:33:32.218+00
1878	\N	5	8	\N	\N	\N	Features	2013-11-13 14:33:32.218+00
1879	\N	8	74	\N	\N	\N	A11216	2013-11-13 14:33:32.218+00
1880	\N	5	8	\N	\N	\N	Preliminary investigation	2013-11-13 14:33:32.218+00
1881	\N	8	32	\N	\N	\N	1999 Stratigraphy 3046	2013-11-13 14:33:32.218+00
1882	\N	5	8	\N	\N	\N	1988-1989 investigation	2013-11-13 14:33:32.218+00
1883	\N	5	8	\N	\N	\N	 pollen]	2013-11-13 14:33:32.218+00
1885	\N	5	8	\N	\N	\N	Final excavation	2013-11-13 14:33:32.218+00
1886	\N	8	32	\N	\N	\N	A75	2013-11-13 14:33:32.218+00
1887	\N	8	37	\N	\N	\N	A11216	2013-11-13 14:33:32.218+00
1888	\N	8	37	\N	\N	\N	CTdo Hotelltomten Survey	2014-02-19 14:28:44.312+00
1889	\N	8	74	\N	\N	\N	Ägglösen	2014-02-19 14:28:44.312+00
1890	\N	8	33	\N	\N	\N	Citytunnelprojektet Hyllie 155 Survey	2014-02-19 14:28:44.312+00
1891	\N	8	74	\N	\N	\N	Gåsinge-Dillnäs 94 Survey Ekhagen	2014-02-19 14:28:44.312+00
1892	\N	8	32	\N	\N	\N	Arvidsjaur 633 Survey	2014-02-19 14:28:44.312+00
1893	\N	8	33	\N	\N	\N	Nederluleå 330 unit 10b survey	2014-02-19 14:28:44.312+00
1894	\N	8	33	\N	\N	\N	Björlanda 459	2014-02-19 14:28:44.312+00
1895	\N	8	32	\N	\N	\N	Soil chemistry 	2014-02-19 14:28:44.312+00
1896	\N	8	33	\N	\N	\N	CTdo7 Final investigation survey	2014-02-19 14:28:44.312+00
1897	\N	8	33	\N	\N	\N	CT do6 Preliminary investigation survey	2014-02-19 14:28:44.312+00
1898	\N	8	33	\N	\N	\N	Laforsen 2007	2014-02-19 14:28:44.312+00
1899	\N	8	33	\N	\N	\N	Arvidsjaur 3941 Survey 2003	2014-02-19 14:28:44.312+00
1900	\N	8	33	\N	\N	\N	CTdo6 Final investigation survey	2014-02-19 14:28:44.312+00
1901	\N	8	33	\N	\N	\N	Nederluleå 601 Survey	2014-02-19 14:28:44.312+00
1902	\N	8	33	\N	\N	\N	Citytunnelprojektet Hyllie 155 Strat 3	2014-02-19 14:28:44.312+00
1903	\N	5	8	\N	\N	\N	Norrsunda 185	2014-02-19 14:28:44.312+00
1904	\N	8	33	\N	\N	\N	CTdo Hotelltomten A2500 Strat	2014-02-19 14:28:44.312+00
1905	\N	8	33	\N	\N	\N	CTdo7 Stratigraphy A277a Stratigraphy	2014-02-19 14:28:44.312+00
1906	\N	5	8	\N	\N	\N	Tuna 328:1 Pits	2014-02-19 14:28:44.312+00
1907	\N	8	32	\N	\N	\N	Gåsinge-Dillnäs 94 Survey Ekhagen	2014-02-19 14:28:44.312+00
1908	\N	8	32	\N	\N	\N	Citytunnelprojektet Hyllie 155 Survey	2014-02-19 14:28:44.312+00
1909	\N	5	8	\N	\N	\N	Västra Skälby	2014-02-19 14:28:44.312+00
1910	\N	8	37	\N	\N	\N	Töre Raä 341	2014-02-19 14:28:44.312+00
1911	\N	8	33	\N	\N	\N	CTdo7 Stratigraphy 59	2014-02-19 14:28:44.312+00
1912	\N	8	32	\N	\N	\N	CT do6 Preliminary investigation survey	2014-02-19 14:28:44.312+00
1913	\N	8	33	\N	\N	\N	Nederluleå 330 Unit 8 strat N profile	2014-02-19 14:28:44.312+00
1914	\N	5	8	\N	\N	\N	Svarteborg 593 Sample group 1	2014-02-19 14:28:44.312+00
1915	\N	8	32	\N	\N	\N	Arvidsjaur 3941 Survey 2003	2014-02-19 14:28:44.312+00
1916	\N	8	33	\N	\N	\N	Töre 318 DE	2014-02-19 14:28:44.312+00
1917	\N	8	33	\N	\N	\N	Lockarp 8:4 Survey	2014-02-19 14:28:44.312+00
1918	\N	8	37	\N	\N	\N	Björlanda 459	2014-02-19 14:28:44.312+00
1919	\N	6	8	\N	\N	\N	Tuna 328:1 Pits 	2014-02-19 14:28:44.312+00
1920	\N	8	37	\N	\N	\N	Citytunnelprojektet Hyllie 155 Survey	2014-02-19 14:28:44.312+00
1921	\N	8	36	\N	\N	\N	Nyköping 231 SG1	2014-02-19 14:28:44.312+00
1922	\N	8	74	\N	\N	\N	CTdo7 Stratigraphy 625	2014-02-19 14:28:44.312+00
1923	\N	5	8	\N	\N	\N	Trogsta 71 Hus A	2014-02-19 14:28:44.312+00
1924	\N	5	8	\N	\N	\N	Svarteborg 593 Hearth/Oven/Cooking pit	2014-02-19 14:28:44.312+00
1925	\N	8	74	\N	\N	\N	Gåsinge Dillnäs 94 Survey Storeken	2014-02-19 14:28:44.312+00
1926	\N	8	33	\N	\N	\N	Soil chemistry p15	2014-02-19 14:28:44.312+00
1927	\N	8	74	\N	\N	\N	Björlanda 459	2014-02-19 14:28:44.312+00
1928	\N	8	33	\N	\N	\N	Arvidsjaur 633 Survey	2014-02-19 14:28:44.312+00
1929	\N	8	74	\N	\N	\N	Stratigraphy 1	2014-02-19 14:28:44.312+00
1930	\N	8	37	\N	\N	\N	Soil chemistry Foss	2014-02-19 14:28:44.312+00
1931	\N	8	33	\N	\N	\N	Gåsinge-Dillnäs 94 Survey Ekhagen	2014-02-19 14:28:44.312+00
1932	\N	8	32	\N	\N	\N	CTdo Hotelltomten Stratigraphy 7	2014-02-19 14:28:44.312+00
1933	\N	8	37	\N	\N	\N	Soil chemistry Herrestad	2014-02-19 14:28:44.312+00
1934	\N	8	37	\N	\N	\N	CTdo7 Stratigraphy A277a Stratigraphy	2014-02-19 14:28:44.312+00
1935	\N	8	37	\N	\N	\N	Arvidsjaur3941 Ref sampl 2003	2014-02-19 14:28:44.312+00
1936	\N	8	33	\N	\N	\N	Töre 405:2 Monolith	2014-02-19 14:28:44.312+00
1937	\N	8	32	\N	\N	\N	Norra Småholmen Roller grinded samples	2014-02-19 14:28:44.312+00
1938	\N	8	33	\N	\N	\N	Gåsinge-Dillnäs 94 Survey Vallen	2014-02-19 14:28:44.312+00
1939	\N	8	74	\N	\N	\N	Gåsinge Dillnäs Survey Pörtkullen 	2014-02-19 14:28:44.312+00
1940	\N	8	33	\N	\N	\N	Soil chemistry Tanum	2014-02-19 14:28:44.312+00
2326	\N	8	109	\N	\N	\N	CTdo8 K2056	2014-02-19 14:28:44.312+00
1941	\N	8	74	\N	\N	\N	CTdo7 Final investigation survey	2014-02-19 14:28:44.312+00
1942	\N	8	37	\N	\N	\N	Soil chemistry Forshälla	2014-02-19 14:28:44.312+00
1943	\N	8	37	\N	\N	\N	Soil chemistry	2014-02-19 14:28:44.312+00
1944	\N	8	32	\N	\N	\N	CTdo7 Stratigraphy 459	2014-02-19 14:28:44.312+00
1945	\N	8	33	\N	\N	\N	Töre 408 	2014-02-19 14:28:44.312+00
1946	\N	8	74	\N	\N	\N	Citytunnelprojektet Hyllie 155 Survey	2014-02-19 14:28:44.312+00
1947	\N	8	74	\N	\N	\N	CT do6 Preliminary investigation survey	2014-02-19 14:28:44.312+00
1948	\N	8	32	\N	\N	\N	Björlanda 459	2014-02-19 14:28:44.312+00
1949	\N	5	8	\N	\N	\N	Trogsta 	2014-02-19 14:28:44.312+00
1950	\N	8	33	\N	\N	\N	CTdo Hotelltomten Survey	2014-02-19 14:28:44.312+00
1951	\N	8	33	\N	\N	\N	Soil chemistry Foss	2014-02-19 14:28:44.312+00
1952	\N	8	33	\N	\N	\N	CTdo Hotelltomten A3184 Strat	2014-02-19 14:28:44.312+00
1953	\N	8	32	\N	\N	\N	Gåsinge-Dillnäs 94 Survey Hästhagen	2014-02-19 14:28:44.312+00
1954	2	5	8	\N	\N	\N	Tillinge 314 Wells	2014-02-19 14:28:44.312+00
1955	\N	8	33	\N	\N	\N	Södra Hee	2014-02-19 14:28:44.312+00
1956	\N	5	8	\N	\N	\N	Tanum 1229	2014-02-19 14:28:44.312+00
1957	\N	8	32	\N	\N	\N	Solberga Hearths	2014-02-19 14:28:44.312+00
1958	\N	8	37	\N	\N	\N	CTdo6 Final investigation survey	2014-02-19 14:28:44.312+00
1959	\N	8	33	\N	\N	\N	Gåsinge-Dillnäs 94 Survey Hästhagen	2014-02-19 14:28:44.312+00
1960	\N	5	8	\N	\N	\N	Torö 75	2014-02-19 14:28:44.312+00
1961	\N	8	32	\N	\N	\N	CTdo7 Stratigraphy 452	2014-02-19 14:28:44.312+00
1962	\N	8	33	\N	\N	\N	Undersåker Survey A1	2014-02-19 14:28:44.312+00
1963	\N	8	37	\N	\N	\N	Arvidsjaur 3941 Survey 2003	2014-02-19 14:28:44.312+00
1964	\N	8	32	\N	\N	\N	Arvidsjaur 1877 Survey	2014-02-19 14:28:44.312+00
1965	\N	8	74	\N	\N	\N	Töre Raä 341	2014-02-19 14:28:44.312+00
1966	\N	8	33	\N	\N	\N	Gåsinge Dillnäs Survey Pörtkullen 	2014-02-19 14:28:44.312+00
1967	\N	8	74	\N	\N	\N	Töre 405:2 Monolith	2014-02-19 14:28:44.312+00
1968	\N	8	32	\N	\N	\N	CTdo7 Stratigraphy A277a Stratigraphy	2014-02-19 14:28:44.312+00
1969	\N	5	8	\N	\N	\N	Ytterby 22	2014-02-19 14:28:44.312+00
1970	\N	8	33	\N	\N	\N	Arvidsjaur 1877 Survey	2014-02-19 14:28:44.312+00
1971	\N	5	8	\N	\N	\N	Uppsala 499	2014-02-19 14:28:44.312+00
1972	\N	8	37	\N	\N	\N	Svarteborg 593 House 4	2014-02-19 14:28:44.312+00
1973	\N	8	35	\N	\N	\N	Laforsen 2009	2014-02-19 14:28:44.312+00
1974	\N	8	33	\N	\N	\N	Citytunnelprojektet Hyllie 155 Survey 2	2014-02-19 14:28:44.312+00
1975	\N	8	33	\N	\N	\N	Soil chemistry	2014-02-19 14:28:44.312+00
1976	\N	8	37	\N	\N	\N	Soil chem Torsby	2014-02-19 14:28:44.312+00
1977	\N	8	37	\N	\N	\N	CTdo7 Stratigraphy 453	2014-02-19 14:28:44.312+00
1978	\N	5	8	\N	\N	\N	Nyköping 231 SG 1	2014-02-19 14:28:44.312+00
1979	\N	8	37	\N	\N	\N	Arvidsjaur 3913 Strat R1	2014-02-19 14:28:44.312+00
1980	\N	8	33	\N	\N	\N	CTdo Hotelltomten A1293 Strat	2014-02-19 14:28:44.312+00
1981	\N	8	33	\N	\N	\N	Svarteborg 585	2014-02-19 14:28:44.312+00
1982	2	8	37	\N	\N	\N	Fåröarna Mortared samples	2014-02-19 14:28:44.312+00
1983	\N	8	37	\N	\N	\N	CTdo6Strat A1094	2014-02-19 14:28:44.312+00
1984	\N	8	33	\N	\N	\N	Lockarp 8:4 Well Kubiena 2	2014-02-19 14:28:44.312+00
1985	\N	8	33	\N	\N	\N	CTdo Vintrie IP House 5 survey	2014-02-19 14:28:44.312+00
1986	\N	8	33	\N	\N	\N	Vänge 88:1 Väsby Ö Soil chem	2014-02-19 14:28:44.312+00
1987	\N	8	74	\N	\N	\N	Töre 408 	2014-02-19 14:28:44.312+00
1988	\N	8	33	\N	\N	\N	Töre Raä 341	2014-02-19 14:28:44.312+00
1989	\N	8	74	\N	\N	\N	Soil chemistry Tanum	2014-02-19 14:28:44.312+00
1990	\N	8	33	\N	\N	\N	Citytunnelprojektet Hyllie 155 Strat 10	2014-02-19 14:28:44.312+00
1991	\N	8	32	\N	\N	\N	Gåsinge Dillnäs 94 Survey Skärvstenshögen	2014-02-19 14:28:44.312+00
1992	\N	8	37	\N	\N	\N	Arvidsjaur 3913 Survey	2014-02-19 14:28:44.312+00
1993	\N	8	33	\N	\N	\N	Arvidsjaur3941 Ref sampl 2003	2014-02-19 14:28:44.312+00
1994	\N	8	33	\N	\N	\N	Torslanda soil chemistry	2014-02-19 14:28:44.312+00
1995	\N	8	32	\N	\N	\N	CTdo7 A250 survey	2014-02-19 14:28:44.312+00
1996	\N	8	33	\N	\N	\N	Soil chemistry Features	2014-02-19 14:28:44.312+00
1997	\N	8	32	\N	\N	\N	Torslanda soil chemistry	2014-02-19 14:28:44.312+00
1998	\N	8	33	\N	\N	\N	Stratigraphy 1	2014-02-19 14:28:44.312+00
1999	\N	8	32	\N	\N	\N	CTdo7 Stratigraphy 626	2014-02-19 14:28:44.312+00
2000	\N	8	33	\N	\N	\N	CTdo Vintrie IP A57	2014-02-19 14:28:44.312+00
2001	\N	8	33	\N	\N	\N	Citytunnelprojektet Hyllie 155 Strat 4	2014-02-19 14:28:44.312+00
2002	\N	8	37	\N	\N	\N	Norrala 177 Survey	2014-02-19 14:28:44.312+00
2003	\N	8	33	\N	\N	\N	Gåsinge Dillnäs 94 Survey Skärvstenshögen	2014-02-19 14:28:44.312+00
2004	\N	8	33	\N	\N	\N	Arvidsjaur 3913 Survey	2014-02-19 14:28:44.312+00
2005	\N	8	33	\N	\N	\N	Soil chemistry Herrestad	2014-02-19 14:28:44.312+00
2006	\N	5	8	\N	\N	\N	Örtedalen Earliest land use	2014-02-19 14:28:44.312+00
2007	\N	8	32	\N	\N	\N	CTdo7 Stratigraphy 59	2014-02-19 14:28:44.312+00
2008	\N	8	8	\N	\N	\N	Svarteborg 116	2014-02-19 14:28:44.312+00
2009	\N	8	33	\N	\N	\N	Soil chemistry p6	2014-02-19 14:28:44.312+00
2010	\N	8	33	\N	\N	\N	Soil chemistry 	2014-02-19 14:28:44.312+00
2011	\N	8	32	\N	\N	\N	Gåsinge Dillnäs Survey Pörtkullen 	2014-02-19 14:28:44.312+00
2012	\N	8	33	\N	\N	\N	Soil chemistry Tossene	2014-02-19 14:28:44.312+00
2013	\N	8	74	\N	\N	\N	CTdo6 Final investigation survey	2014-02-19 14:28:44.312+00
2014	\N	8	74	\N	\N	\N	Citytunnelprojektet Hyllie 155 Survey 2	2014-02-19 14:28:44.312+00
2015	\N	5	8	\N	\N	\N	Strängnäs 443 Sunken hut floor	2014-02-19 14:28:44.312+00
2016	\N	8	33	\N	\N	\N	CTdo Hotelltomten Survey	2014-02-19 14:28:44.312+00
2017	\N	8	33	\N	\N	\N	Undersåker Survey A2	2014-02-19 14:28:44.312+00
2018	\N	5	8	\N	\N	\N	Knivsta 16 Sample group 1	2014-02-19 14:28:44.312+00
2019	\N	5	8	\N	\N	\N	Örtedalen Oven and stove	2014-02-19 14:28:44.312+00
2020	\N	5	8	\N	\N	\N	Örtedalen Road	2014-02-19 14:28:44.312+00
2021	\N	8	74	\N	\N	\N	Soil chemistry Foss	2014-02-19 14:28:44.312+00
2022	\N	8	32	\N	\N	\N	Svarteborg 593 Pits	2014-02-19 14:28:44.312+00
2023	\N	8	74	\N	\N	\N	Soil chemistry Ytterbu 2010	2014-02-19 14:28:44.312+00
2024	\N	8	36	\N	\N	\N	Laforsen 2009	2014-02-19 14:28:44.312+00
2025	\N	8	33	\N	\N	\N	Arvidsjaur 633:4 Survey	2014-02-19 14:28:44.312+00
2026	\N	8	74	\N	\N	\N	Arvidsjaur 3941 Survey 2003	2014-02-19 14:28:44.312+00
2027	\N	8	74	\N	\N	\N	Arvidsjaur 3913 Survey	2014-02-19 14:28:44.312+00
2028	\N	8	37	\N	\N	\N	Torslanda soil chemistry	2014-02-19 14:28:44.312+00
2029	\N	8	33	\N	\N	\N	CTdo hotelltomten Extended survey	2014-02-19 14:28:44.312+00
2030	\N	8	33	\N	\N	\N	CTdo7 Stratigraphy 468	2014-02-19 14:28:44.312+00
2031	\N	8	33	\N	\N	\N	Töre 408 AC	2014-02-19 14:28:44.312+00
2032	\N	8	74	\N	\N	\N	Gåsinge-Dillnäs 94 Survey Vallen	2014-02-19 14:28:44.312+00
2033	\N	8	32	\N	\N	\N	CTdo Hotelltomten A1293 Strat	2014-02-19 14:28:44.312+00
2034	\N	8	74	\N	\N	\N	Lockarp 8:4 Well Kubiena1 	2014-02-19 14:28:44.312+00
2035	\N	8	74	\N	\N	\N	CTdo Hotelltomten Survey	2014-02-19 14:28:44.312+00
2036	\N	8	33	\N	\N	\N	CTdo7 Stratigraphy 624	2014-02-19 14:28:44.312+00
2037	\N	8	32	\N	\N	\N	Arvidsjaur 3913 Survey	2014-02-19 14:28:44.312+00
2038	\N	8	74	\N	\N	\N	Soil chemistry p5	2014-02-19 14:28:44.312+00
2039	\N	8	32	\N	\N	\N	CTdo Hotelltomten A718 Strat	2014-02-19 14:28:44.312+00
2040	\N	8	37	\N	\N	\N	Soil chemistry 	2014-02-19 14:28:44.312+00
2041	\N	8	37	\N	\N	\N	Hagen, Bäve	2014-02-19 14:28:44.312+00
2042	\N	8	74	\N	\N	\N	Citytunnelprojektet Hyllie 155 Strat 7	2014-02-19 14:28:44.312+00
2043	\N	5	8	\N	\N	\N	Knivsta 16 Structure 2	2014-02-19 14:28:44.312+00
2044	\N	8	32	\N	\N	\N	CTdo Hotelltomten A2500 Strat	2014-02-19 14:28:44.312+00
2045	\N	5	8	\N	\N	\N	Svarteborg 585	2014-02-19 14:28:44.312+00
2046	\N	8	37	\N	\N	\N	Nederluleå 601 Survey	2014-02-19 14:28:44.312+00
2047	\N	8	37	\N	\N	\N	Arvidsjaur 633 Survey	2014-02-19 14:28:44.312+00
2048	\N	5	8	\N	\N	\N	Macrofossils 1989 Forsa	2014-02-19 14:28:44.312+00
2049	\N	8	32	\N	\N	\N	CTdo7 Stratigraphy 465	2014-02-19 14:28:44.312+00
2050	\N	8	32	\N	\N	\N	CTdoHotelltomten Stratigraphy 1	2014-02-19 14:28:44.312+00
2051	\N	8	37	\N	\N	\N	Laforsen 2007	2014-02-19 14:28:44.312+00
2052	\N	8	33	\N	\N	\N	Norrala 177 Survey	2014-02-19 14:28:44.312+00
2053	\N	8	33	\N	\N	\N	Bergskärit 	2014-02-19 14:28:44.312+00
2054	\N	8	37	\N	\N	\N	CT do6 Preliminary investigation survey	2014-02-19 14:28:44.312+00
2055	\N	8	74	\N	\N	\N	Soil chemistry 	2014-02-19 14:28:44.312+00
2056	\N	8	37	\N	\N	\N	Svarteborg 593 Sample group 1	2014-02-19 14:28:44.312+00
2057	\N	8	74	\N	\N	\N	CTdo Hotelltomten A992 Survey	2014-02-19 14:28:44.312+00
2058	\N	8	33	\N	\N	\N	CTdo Vintrie IP A50	2014-02-19 14:28:44.312+00
2059	\N	8	74	\N	\N	\N	CTdo6 House 1 post holes	2014-02-19 14:28:44.312+00
2060	\N	8	33	\N	\N	\N	CTdo7 Stratigraphy 622	2014-02-19 14:28:44.312+00
2061	\N	8	32	\N	\N	\N	CTdo7 Extended survey	2014-02-19 14:28:44.312+00
2062	\N	8	33	\N	\N	\N	CTdo Hotelltomten A992 Survey	2014-02-19 14:28:44.312+00
2063	\N	8	33	\N	\N	\N	Soil chemistry Forshälla	2014-02-19 14:28:44.312+00
2064	\N	8	32	\N	\N	\N	CTdo7 Final investigation survey	2014-02-19 14:28:44.312+00
2065	\N	8	37	\N	\N	\N	Töre 320 Survey	2014-02-19 14:28:44.312+00
2066	\N	8	33	\N	\N	\N	CTdo6 House 1 post holes	2014-02-19 14:28:44.312+00
2067	\N	8	33	\N	\N	\N	Citytunnelprojektet Hyllie 155	2014-02-19 14:28:44.312+00
2068	\N	8	33	\N	\N	\N	CTdo7 Preliminary investigation survey	2014-02-19 14:28:44.312+00
2069	\N	8	74	\N	\N	\N	Soil chemistry	2014-02-19 14:28:44.312+00
2070	\N	8	33	\N	\N	\N	CTdo Hotelltomten Stratigraphy 3a	2014-02-19 14:28:44.312+00
2071	\N	8	32	\N	\N	\N	Lockarp 8:4 Well Kubiena 2	2014-02-19 14:28:44.312+00
2072	\N	8	37	\N	\N	\N	Soil chemistry Features	2014-02-19 14:28:44.312+00
2073	\N	8	32	\N	\N	\N	Nederluleå 330 unit 10b survey	2014-02-19 14:28:44.312+00
2074	\N	8	33	\N	\N	\N	CTdo Hotelltomten A1759 Strat	2014-02-19 14:28:44.312+00
2075	\N	6	8	\N	\N	\N	Örtedalen Oven and stove	2014-02-19 14:28:44.312+00
2076	\N	8	33	\N	\N	\N	Survey H9801	2014-02-19 14:28:44.312+00
2077	\N	8	32	\N	\N	\N	Undersåker Survey settlement area	2014-02-19 14:28:44.312+00
2078	\N	8	37	\N	\N	\N	Survey settlement area	2014-02-19 14:28:44.312+00
2079	\N	6	8	\N	\N	\N	Final investigation 2004[Plants & pollen]	2014-02-19 14:28:44.312+00
2080	\N	8	33	\N	\N	\N	Soil chemistry Foss 438	2014-02-19 14:28:44.312+00
2081	\N	8	37	\N	\N	\N	Laforsen 2009	2014-02-19 14:28:44.312+00
2082	\N	8	74	\N	\N	\N	Survey H9802	2014-02-19 14:28:44.312+00
2083	\N	8	37	\N	\N	\N	Älvsbyn 958 Survey	2014-02-19 14:28:44.312+00
2084	\N	8	37	\N	\N	\N	CTdo7 Stratigraphy 59	2014-02-19 14:28:44.312+00
2085	\N	8	37	\N	\N	\N	Lockarp 8:4 Survey	2014-02-19 14:28:44.312+00
2086	\N	8	74	\N	\N	\N	Survey corral 	2014-02-19 14:28:44.312+00
2087	\N	5	33	\N	\N	\N	Nederluleå 330 Archaeobotany	2014-02-19 14:28:44.312+00
2088	\N	8	32	\N	\N	\N	Soil chemistry	2014-02-19 14:28:44.312+00
2089	\N	8	33	\N	\N	\N	Arvidsjaur 3941 R3	2014-02-19 14:28:44.312+00
2090	\N	8	33	\N	\N	\N	CTdo7 A250 survey	2014-02-19 14:28:44.312+00
2091	\N	5	8	\N	\N	\N	Svarteborg 593 Wells	2014-02-19 14:28:44.312+00
2092	\N	8	37	\N	\N	\N	CTdo7 Preliminary investigation survey	2014-02-19 14:28:44.312+00
2093	\N	8	33	\N	\N	\N	Vilhelmina 1647	2014-02-19 14:28:44.312+00
2094	\N	8	33	\N	\N	\N	Gåsinge-Dillnäs 94 Survey Åkerkant	2014-02-19 14:28:44.312+00
2095	\N	8	74	\N	\N	\N	Survey H9801	2014-02-19 14:28:44.312+00
2096	\N	8	74	\N	\N	\N	CTdo Hotelltomten A718 Strat	2014-02-19 14:28:44.312+00
2097	\N	8	32	\N	\N	\N	Hagen, Bäve	2014-02-19 14:28:44.312+00
2098	\N	8	74	\N	\N	\N	CTdo7 Stratigraphy 620	2014-02-19 14:28:44.312+00
2099	\N	8	37	\N	\N	\N	Citytunnelprojektet Hyllie 155 Strat 8	2014-02-19 14:28:44.312+00
2100	\N	8	74	\N	\N	\N	Citytunnelprojektet Hyllie 155 Strat wetland layer	2014-02-19 14:28:44.312+00
2101	\N	8	74	\N	\N	\N	Undersåker Survey A1	2014-02-19 14:28:44.312+00
2102	\N	5	8	\N	\N	\N	Odensala 402 Vessels	2014-02-19 14:28:44.312+00
2103	\N	5	8	\N	\N	\N	Odensala 402 House 100	2014-02-19 14:28:44.312+00
2104	\N	5	8	\N	\N	\N	Odensala 6 Sample group 2	2014-02-19 14:28:44.312+00
2105	\N	8	33	\N	\N	\N	CTdo6 Strat K275	2014-02-19 14:28:44.312+00
2106	\N	5	8	\N	\N	\N	Knivsta 16 Pits	2014-02-19 14:28:44.312+00
2107	\N	5	8	\N	\N	\N	Torslanda 220	2014-02-19 14:28:44.312+00
2108	\N	5	8	\N	\N	\N	Nederluleå 330 Västerv. 19	2014-02-19 14:28:44.312+00
2109	\N	8	33	\N	\N	\N	CTdo Hotelltomten Stratigraphy 5a	2014-02-19 14:28:44.312+00
2110	\N	8	33	\N	\N	\N	CTdo Vintrie IP A16847	2014-02-19 14:28:44.312+00
2111	\N	8	74	\N	\N	\N	Nederluleå 330 Unit 8 survey	2014-02-19 14:28:44.312+00
2112	\N	8	74	\N	\N	\N	Arvidsjaur 1877 Survey	2014-02-19 14:28:44.312+00
2113	\N	8	33	\N	\N	\N	CTdo6 Strat K267	2014-02-19 14:28:44.312+00
2114	\N	8	32	\N	\N	\N	Undersåker Survey A1	2014-02-19 14:28:44.312+00
2115	\N	8	106	\N	\N	\N	Enånger 146 Msloop	2014-02-19 14:28:44.312+00
2116	\N	8	32	\N	\N	\N	Nickösörarna	2014-02-19 14:28:44.312+00
2117	\N	8	32	\N	\N	\N	Nederluleå 330 Unit 8 survey	2014-02-19 14:28:44.312+00
2118	\N	8	33	\N	\N	\N	Björlanda 459	2014-02-19 14:28:44.312+00
2119	\N	8	74	\N	\N	\N	CTdo7 Stratigraphy 468	2014-02-19 14:28:44.312+00
2120	\N	8	33	\N	\N	\N	Svarteborg 589	2014-02-19 14:28:44.312+00
2121	\N	8	74	\N	\N	\N	Gåsinge-Dillnäs 94 Survey Åkerkant	2014-02-19 14:28:44.312+00
2122	\N	8	74	\N	\N	\N	Citytunnelprojektet Hyllie 155 Strat 4	2014-02-19 14:28:44.312+00
2123	\N	5	8	\N	\N	\N	Hogstorp 327 [Plants & pollen]	2014-02-19 14:28:44.312+00
2124	\N	6	8	\N	\N	\N	Dammen[Plants & pollen]	2014-02-19 14:28:44.312+00
2125	\N	5	8	\N	\N	\N	Svarteborg 592	2014-02-19 14:28:44.312+00
2126	\N	5	8	\N	\N	\N	Knivsta 16 Structure 11	2014-02-19 14:28:44.312+00
2127	\N	8	32	\N	\N	\N	Arvidsjaur 633:4 Survey	2014-02-19 14:28:44.312+00
2128	\N	6	8	\N	\N	\N	Norrsunda 185	2014-02-19 14:28:44.312+00
2129	\N	8	37	\N	\N	\N	CTdo7 Stratigraphy 460	2014-02-19 14:28:44.312+00
2130	\N	8	37	\N	\N	\N	Soil chemistry Hällekind	2014-02-19 14:28:44.312+00
2131	\N	5	8	\N	\N	\N	Knivsta 16 Hearths	2014-02-19 14:28:44.312+00
2132	\N	8	74	\N	\N	\N	Vilhelmina 1647	2014-02-19 14:28:44.312+00
2133	\N	8	37	\N	\N	\N	CTdo7 Final investigation survey	2014-02-19 14:28:44.312+00
2134	\N	8	33	\N	\N	\N	CTdo7 Extended survey	2014-02-19 14:28:44.312+00
2135	\N	8	74	\N	\N	\N	Nederkalix 722 	2014-02-19 14:28:44.312+00
2136	\N	8	32	\N	\N	\N	CTdo7 Preliminary investigation survey	2014-02-19 14:28:44.312+00
2137	\N	8	32	\N	\N	\N	Citytunnelprojektet Hyllie 155 Strat wetland layer	2014-02-19 14:28:44.312+00
2138	\N	5	8	\N	\N	\N	Skederid 190 Structure 3	2014-02-19 14:28:44.312+00
2139	\N	8	32	\N	\N	\N	Soil chemistry Foss 438	2014-02-19 14:28:44.312+00
2140	\N	8	33	\N	\N	\N	Survey H9802	2014-02-19 14:28:44.312+00
2141	\N	8	8	\N	\N	\N	Svarteborg 590	2014-02-19 14:28:44.312+00
2142	\N	5	8	\N	\N	\N	Odensala 6	2014-02-19 14:28:44.312+00
2143	\N	8	32	\N	\N	\N	Citytunnelprojektet Hyllie 155 Survey 2	2014-02-19 14:28:44.312+00
2144	\N	8	32	\N	\N	\N	CTdo7 Stratigraphy 624	2014-02-19 14:28:44.312+00
2145	\N	8	33	\N	\N	\N	Soil chem Torsby	2014-02-19 14:28:44.312+00
2146	\N	6	8	\N	\N	\N	Odensala 6 sample group 1	2014-02-19 14:28:44.312+00
2147	\N	8	74	\N	\N	\N	CTdo Vintrie IP A50	2014-02-19 14:28:44.312+00
2148	\N	8	74	\N	\N	\N	Soil chemistry Foss 438	2014-02-19 14:28:44.312+00
2149	\N	8	33	\N	\N	\N	CTdo7 Stratigraphy 628	2014-02-19 14:28:44.312+00
2150	\N	6	8	\N	\N	\N	Sample group 1[Plants & pollen]	2014-02-19 14:28:44.312+00
2151	\N	8	74	\N	\N	\N	Solberga Building	2014-02-19 14:28:44.312+00
2152	\N	8	32	\N	\N	\N	Svarteborg 593 Sample group 1	2014-02-19 14:28:44.312+00
2153	\N	8	37	\N	\N	\N	Gåsinge Dillnäs 94 Survey Vallen 3	2014-02-19 14:28:44.312+00
2154	\N	8	33	\N	\N	\N	Soil chemistry Torsby	2014-02-19 14:28:44.312+00
2155	\N	8	74	\N	\N	\N	Undersåker Survey A2	2014-02-19 14:28:44.312+00
2156	\N	8	74	\N	\N	\N	Arvidsjaur 633:4 Survey	2014-02-19 14:28:44.312+00
2157	\N	8	33	\N	\N	\N	CTdi Hotelltomten A3474 Strat	2014-02-19 14:28:44.312+00
2158	\N	8	74	\N	\N	\N	CTdo Hotelltomten A2500 Strat	2014-02-19 14:28:44.312+00
2159	\N	8	33	\N	\N	\N	Vaksala Raä 300 Soil chemistry	2014-02-19 14:28:44.312+00
2160	\N	8	32	\N	\N	\N	Soil chemistry Features	2014-02-19 14:28:44.312+00
2161	\N	8	33	\N	\N	\N	Citytunnelprojektet Hyllie 155 Strat 9	2014-02-19 14:28:44.312+00
2162	\N	6	8	\N	\N	\N	Svarteborg 590	2014-02-19 14:28:44.312+00
2163	\N	5	8	\N	\N	\N	Nyköping 231 SG2	2014-02-19 14:28:44.312+00
2164	\N	8	32	\N	\N	\N	CTdo Hotelltomten A2052 Strat	2014-02-19 14:28:44.312+00
2165	\N	8	33	\N	\N	\N	Gåsinge Dillnäs 94 Survey Storeken	2014-02-19 14:28:44.312+00
2166	\N	8	32	\N	\N	\N	Soil chemistry p6	2014-02-19 14:28:44.312+00
2167	\N	8	33	\N	\N	\N	CTdo Hotelltomten Stratigraphy 6b	2014-02-19 14:28:44.312+00
2168	\N	8	109	\N	\N	\N	CTdo Vintrie IP House 5 survey	2014-02-19 14:28:44.312+00
2169	\N	8	33	\N	\N	\N	Undersåker Survey settlement area	2014-02-19 14:28:44.312+00
2170	\N	8	37	\N	\N	\N	Citytunnelprojektet Hyllie 155 Survey 2	2014-02-19 14:28:44.312+00
2171	\N	8	32	\N	\N	\N	CTdo Vintrie IP A57	2014-02-19 14:28:44.312+00
2172	\N	8	33	\N	\N	\N	Töre 408 CD	2014-02-19 14:28:44.312+00
2173	\N	8	37	\N	\N	\N	Åssjiejávrátje Survey 	2014-02-19 14:28:44.312+00
2174	\N	8	32	\N	\N	\N	CTdo Vintrie IP A16847	2014-02-19 14:28:44.312+00
2175	\N	8	37	\N	\N	\N	Enånger Survey	2014-02-19 14:28:44.312+00
2176	\N	5	8	\N	\N	\N	Sundsvall raä 5:1	2014-02-19 14:28:44.312+00
2177	\N	8	74	\N	\N	\N	CTdo Hotelltomten Stratigraphy 2	2014-02-19 14:28:44.312+00
2178	\N	8	37	\N	\N	\N	Strängnäs 443 House 2	2014-02-19 14:28:44.312+00
2179	\N	8	32	\N	\N	\N	Gåsinge-Dillnäs 94 Survey Vallen	2014-02-19 14:28:44.312+00
2180	\N	8	74	\N	\N	\N	Ripkallhögen	2014-02-19 14:28:44.312+00
2181	\N	8	33	\N	\N	\N	Citytunnelprojektet Hyllie 155 Strat wetland layer	2014-02-19 14:28:44.312+00
2182	\N	8	33	\N	\N	\N	Svarteborg 593 Wells	2014-02-19 14:28:44.312+00
2183	\N	8	37	\N	\N	\N	CTdo7 Stratigraphy 465	2014-02-19 14:28:44.312+00
2184	\N	8	33	\N	\N	\N	Citytunnelprojektet Hyllie 155 Strat 8	2014-02-19 14:28:44.312+00
2185	\N	8	74	\N	\N	\N	CTdo Hotelltomten Stratigraphy 4	2014-02-19 14:28:44.312+00
2186	\N	8	33	\N	\N	\N	Töre 318 CD	2014-02-19 14:28:44.312+00
2187	\N	8	74	\N	\N	\N	CTdo Hotelltomten Stratigraphy 7	2014-02-19 14:28:44.312+00
2188	\N	8	37	\N	\N	\N	Södra Hee Feature sample	2014-02-19 14:28:44.312+00
2189	\N	8	33	\N	\N	\N	Töre 318	2014-02-19 14:28:44.312+00
2190	\N	8	33	\N	\N	\N	CTdo Hotelltomten A718 Strat	2014-02-19 14:28:44.312+00
2191	\N	8	32	\N	\N	\N	CTdo Hotelltomten Stratigraphy 4	2014-02-19 14:28:44.312+00
2192	\N	8	33	\N	\N	\N	Survey settlement area	2014-02-19 14:28:44.312+00
2193	\N	8	37	\N	\N	\N	Älvsbyn 958 strat 2	2014-02-19 14:28:44.312+00
2194	\N	8	32	\N	\N	\N	Töre Raä 341	2014-02-19 14:28:44.312+00
2195	\N	5	8	\N	\N	\N	Knivsta 16 Heaps of fire cracked stone	2014-02-19 14:28:44.312+00
2196	\N	8	37	\N	\N	\N	Stratigraphy 1	2014-02-19 14:28:44.312+00
2197	\N	5	8	\N	\N	\N	Västerhaninhe 479 Sample group 2	2014-02-19 14:28:44.312+00
2198	\N	8	33	\N	\N	\N	Själstuga Sg 1	2014-02-19 14:28:44.312+00
2199	\N	8	37	\N	\N	\N	Själstuga Sg 1	2014-02-19 14:28:44.312+00
2200	\N	5	8	\N	\N	\N	Knivsta 16 Postholes not...	2014-02-19 14:28:44.312+00
2201	\N	8	33	\N	\N	\N	CTdo7 Stratigraphy 453	2014-02-19 14:28:44.312+00
2202	\N	8	37	\N	\N	\N	Nederluleå 330 unit 10b survey	2014-02-19 14:28:44.312+00
2203	\N	8	37	\N	\N	\N	Södra Hee	2014-02-19 14:28:44.312+00
2204	\N	8	32	\N	\N	\N	CTdo7 Stratigraphy 453	2014-02-19 14:28:44.312+00
2205	\N	8	32	\N	\N	\N	Citytunnelprojektet Hyllie 155 Strat 10	2014-02-19 14:28:44.312+00
2206	\N	8	74	\N	\N	\N	CTdo Hotelltomten A1293 Strat	2014-02-19 14:28:44.312+00
2207	\N	8	33	\N	\N	\N	CTdo7 Stratigraphy 620	2014-02-19 14:28:44.312+00
2208	\N	8	33	\N	\N	\N	CTdo Hotelltomten A3023 Strat	2014-02-19 14:28:44.312+00
2209	\N	5	8	\N	\N	\N	Macrofossils 1992 Forsa	2014-02-19 14:28:44.312+00
2210	\N	8	33	\N	\N	\N	Soil chemistry Naverstad	2014-02-19 14:28:44.312+00
2211	\N	8	37	\N	\N	\N	CTdo7 A250 survey	2014-02-19 14:28:44.312+00
2212	\N	5	8	\N	\N	\N	Svarteborg 403	2014-02-19 14:28:44.312+00
2213	\N	8	32	\N	\N	\N	Töre 405:2 Monolith	2014-02-19 14:28:44.312+00
2214	\N	8	32	\N	\N	\N	Soil chemistry p2	2014-02-19 14:28:44.312+00
2215	\N	8	33	\N	\N	\N	Torö 75 	2014-02-19 14:28:44.312+00
2216	\N	8	74	\N	\N	\N	CTdo Vintrie IP A16847	2014-02-19 14:28:44.312+00
2217	\N	8	37	\N	\N	\N	Arvidsjaur 1877 Survey	2014-02-19 14:28:44.312+00
2218	\N	8	33	\N	\N	\N	Strängnäs 443 Sunken hut floor	2014-02-19 14:28:44.312+00
2219	\N	8	37	\N	\N	\N	Gåsinge-Dillnäs 94 Survey Ekhagen	2014-02-19 14:28:44.312+00
2220	\N	8	33	\N	\N	\N	CTdo6Strat A1094	2014-02-19 14:28:44.312+00
2221	\N	8	74	\N	\N	\N	Citytunnelprojektet Hyllie 155 Strat 8	2014-02-19 14:28:44.312+00
2222	\N	8	32	\N	\N	\N	Svarteborg 590	2014-02-19 14:28:44.312+00
2223	\N	8	32	\N	\N	\N	Final excavation 2006	2014-02-19 14:28:44.312+00
2224	\N	8	33	\N	\N	\N	CTdo Vintrie IP A58	2014-02-19 14:28:44.312+00
2225	\N	8	32	\N	\N	\N	CTdo Vintrie IP A11023 	2014-02-19 14:28:44.312+00
2226	\N	8	33	\N	\N	\N	CT do6 House 2 post holes	2014-02-19 14:28:44.312+00
2227	\N	8	74	\N	\N	\N	Gåsinge-Dillnäs 94 Survey Hästhagen	2014-02-19 14:28:44.312+00
2228	\N	8	33	\N	\N	\N	CTdo7 Stratigraphy 455	2014-02-19 14:28:44.312+00
2229	\N	5	8	\N	\N	\N	Forskningsparken Huddinge	2014-02-19 14:28:44.312+00
2230	\N	8	33	\N	\N	\N	Älvsbyn 958 Survey	2014-02-19 14:28:44.312+00
2231	\N	8	37	\N	\N	\N	Strängnäs 443 House 3	2014-02-19 14:28:44.312+00
2232	\N	8	37	\N	\N	\N	CTdo7 Extended survey	2014-02-19 14:28:44.312+00
2233	\N	5	8	\N	\N	\N	Högom grav 2 Secondary cult layer	2014-02-19 14:28:44.312+00
2234	\N	8	32	\N	\N	\N	Nederluleå 601 Survey	2014-02-19 14:28:44.312+00
2235	\N	8	32	\N	\N	\N	Survey area near sami hut	2014-02-19 14:28:44.312+00
2621	\N	8	37	\N	\N	\N	Töre 408 	2014-02-19 14:28:44.312+00
2236	\N	8	32	\N	\N	\N	CTdo6 Final investigation survey	2014-02-19 14:28:44.312+00
2237	\N	8	32	\N	\N	\N	Soil chemistry Tanum	2014-02-19 14:28:44.312+00
2238	2	8	37	\N	\N	\N	Mjölingsören	2014-02-19 14:28:44.312+00
2239	\N	8	74	\N	\N	\N	CTdo Hotelltomten A1759 Strat	2014-02-19 14:28:44.312+00
2240	\N	8	74	\N	\N	\N	Stora Halmören	2014-02-19 14:28:44.312+00
2241	\N	8	32	\N	\N	\N	CTdo7 A277b Stratigraphy	2014-02-19 14:28:44.312+00
2242	\N	8	32	\N	\N	\N	CTdo Vintrie IP A50	2014-02-19 14:28:44.312+00
2243	\N	8	33	\N	\N	\N	CTdo6 Strat K270	2014-02-19 14:28:44.312+00
2244	\N	8	33	\N	\N	\N	CTdo6 Strat K272	2014-02-19 14:28:44.312+00
2245	\N	8	74	\N	\N	\N	Gåsinge Dillnäs 94 Survey Vallen forts	2014-02-19 14:28:44.312+00
2246	\N	5	8	\N	\N	\N	Final investigation 2004[Plants & pollen]	2014-02-19 14:28:44.312+00
2247	\N	8	74	\N	\N	\N	Svarteborg 590	2014-02-19 14:28:44.312+00
2248	\N	8	37	\N	\N	\N	CTdo7 Stratigraphy 459	2014-02-19 14:28:44.312+00
2249	\N	8	33	\N	\N	\N	CTdo7 Stratigraphy 463	2014-02-19 14:28:44.312+00
2250	\N	8	74	\N	\N	\N	Svarteborg 589	2014-02-19 14:28:44.312+00
2251	\N	5	8	\N	\N	\N	Ytterby 22	2014-02-19 14:28:44.312+00
2252	\N	8	74	\N	\N	\N	Vänge 88:1 Väsby Ö Soil chem	2014-02-19 14:28:44.312+00
2253	\N	8	37	\N	\N	\N	Arvidsjaur 633:4 Survey	2014-02-19 14:28:44.312+00
2254	\N	8	32	\N	\N	\N	Töre 318 CD	2014-02-19 14:28:44.312+00
2255	\N	8	74	\N	\N	\N	Norra Ryssmasterna Roller grinded samples	2014-02-19 14:28:44.312+00
2256	\N	8	74	\N	\N	\N	CTdo7 Stratigraphy 622	2014-02-19 14:28:44.312+00
2257	\N	8	33	\N	\N	\N	Norra Ryssmasterna Roller grinded samples	2014-02-19 14:28:44.312+00
2258	\N	8	33	\N	\N	\N	Soil chemistry Ytterbu 2010	2014-02-19 14:28:44.312+00
2259	\N	8	32	\N	\N	\N	CTdo6 Strat K269	2014-02-19 14:28:44.312+00
2260	\N	8	33	\N	\N	\N	Arvidsjaur 3913 Strt R14	2014-02-19 14:28:44.312+00
2261	\N	8	37	\N	\N	\N	Åkroken	2014-02-19 14:28:44.312+00
2262	\N	8	37	\N	\N	\N	Björlanda 459	2014-02-19 14:28:44.312+00
2263	\N	8	74	\N	\N	\N	CTdo6 Strat K272	2014-02-19 14:28:44.312+00
2264	\N	8	33	\N	\N	\N	CTdo7 Stratigraphy 460	2014-02-19 14:28:44.312+00
2265	\N	8	37	\N	\N	\N	Mjölingsören 	2014-02-19 14:28:44.312+00
2266	\N	5	8	\N	\N	\N	Tillinge 314 House 2	2014-02-19 14:28:44.312+00
2267	\N	8	33	\N	\N	\N	Survey area near sami hut	2014-02-19 14:28:44.312+00
2268	\N	8	37	\N	\N	\N	Nyköping 231 SG1	2014-02-19 14:28:44.312+00
2269	\N	8	37	\N	\N	\N	Undersåker Survey A2	2014-02-19 14:28:44.312+00
2270	\N	8	74	\N	\N	\N	CTdo7 Stratigraphy 627	2014-02-19 14:28:44.312+00
2271	\N	8	37	\N	\N	\N	Åssjiejávrátje 	2014-02-19 14:28:44.312+00
2272	\N	8	37	\N	\N	\N	CTdo6 Strat K274	2014-02-19 14:28:44.312+00
2273	\N	8	33	\N	\N	\N	Hagen, Bäve	2014-02-19 14:28:44.312+00
2274	\N	5	8	\N	\N	\N	Trogsta macrofossils hus h	2014-02-19 14:28:44.312+00
2275	\N	8	74	\N	\N	\N	Svarteborg 593 House 2	2014-02-19 14:28:44.312+00
2276	\N	8	37	\N	\N	\N	Nyköping 231 SG2	2014-02-19 14:28:44.312+00
2277	\N	8	33	\N	\N	\N	CTdo7 Stratigraphy 623	2014-02-19 14:28:44.312+00
2278	\N	8	33	\N	\N	\N	CTdo Vintrie IP A11023 	2014-02-19 14:28:44.312+00
2279	\N	8	37	\N	\N	\N	Gåsinge-Dillnäs 94 Survey Åkerkant	2014-02-19 14:28:44.312+00
2280	\N	8	74	\N	\N	\N	Arvidsjaur 633 Survey	2014-02-19 14:28:44.312+00
2281	\N	8	33	\N	\N	\N	CTdo Hotelltomten Stratigraphy 5b	2014-02-19 14:28:44.312+00
2282	\N	8	32	\N	\N	\N	Soil chemistry Ytterbu 2010	2014-02-19 14:28:44.312+00
2283	\N	8	33	\N	\N	\N	Gåsinge-Dillnäs Raä 94. Ullevi Hästhagen	2014-02-19 14:28:44.312+00
2284	\N	8	74	\N	\N	\N	CTdo7 Preliminary investigation survey	2014-02-19 14:28:44.312+00
2285	\N	8	37	\N	\N	\N	CTdo6 Strat K270	2014-02-19 14:28:44.312+00
2286	\N	8	32	\N	\N	\N	Töre 408 	2014-02-19 14:28:44.312+00
2287	\N	8	33	\N	\N	\N	Svarteborg 590	2014-02-19 14:28:44.312+00
2288	\N	8	74	\N	\N	\N	Torslanda soil chemistry	2014-02-19 14:28:44.312+00
2289	\N	8	37	\N	\N	\N	CTdo Vintrie IP House 5 survey	2014-02-19 14:28:44.312+00
2290	\N	8	33	\N	\N	\N	Survey corral 	2014-02-19 14:28:44.312+00
2291	\N	8	33	\N	\N	\N	CTdo7 Stratigraphy 465	2014-02-19 14:28:44.312+00
2292	\N	8	32	\N	\N	\N	Nyköping 231 SG2	2014-02-19 14:28:44.312+00
2293	\N	8	74	\N	\N	\N	Vänge 88:1 Väsby V Soil chem	2014-02-19 14:28:44.312+00
2294	\N	8	32	\N	\N	\N	CTdo Hotelltomten Stratigraphy 3a	2014-02-19 14:28:44.312+00
2295	\N	8	33	\N	\N	\N	Stora Halmören	2014-02-19 14:28:44.312+00
2296	\N	8	37	\N	\N	\N	CTdo7 Stratigraphy 622	2014-02-19 14:28:44.312+00
2297	\N	8	37	\N	\N	\N	Soil chemistry Naverstad	2014-02-19 14:28:44.312+00
2298	2	8	74	\N	\N	\N	Marskärskobben Roller grinded samples	2014-02-19 14:28:44.312+00
2299	\N	8	37	\N	\N	\N	CTdo7 Stratigraphy 455	2014-02-19 14:28:44.312+00
2300	2	8	32	\N	\N	\N	Fåröarna Mortared samples	2014-02-19 14:28:44.312+00
2301	\N	8	37	\N	\N	\N	Bergskärit 	2014-02-19 14:28:44.312+00
2302	\N	5	8	\N	\N	\N	Skederid 190 Hearths	2014-02-19 14:28:44.312+00
2303	\N	8	32	\N	\N	\N	CTdo7 Stratigraphy 622	2014-02-19 14:28:44.312+00
2304	\N	8	32	\N	\N	\N	Survey settlement area	2014-02-19 14:28:44.312+00
2305	\N	8	32	\N	\N	\N	Töre 408 BD	2014-02-19 14:28:44.312+00
2306	\N	8	37	\N	\N	\N	Töre 405:2 Monolith	2014-02-19 14:28:44.312+00
2307	\N	8	37	\N	\N	\N	Citytunnelprojektet Hyllie 155 Strat 7	2014-02-19 14:28:44.312+00
2308	\N	8	74	\N	\N	\N	CTdo6Strat A1094	2014-02-19 14:28:44.312+00
2309	\N	8	74	\N	\N	\N	Nyköpingshus	2014-02-19 14:28:44.312+00
2310	\N	8	32	\N	\N	\N	CTdo Hotelltomten A1759 Strat	2014-02-19 14:28:44.312+00
2311	\N	8	37	\N	\N	\N	CTdo Hotelltomten Stratigraphy 6a	2014-02-19 14:28:44.312+00
2312	\N	8	74	\N	\N	\N	Survey area near sami hut	2014-02-19 14:28:44.312+00
2313	\N	8	33	\N	\N	\N	CTdo Hotelltomten Stratigraphy 7	2014-02-19 14:28:44.312+00
2314	\N	8	37	\N	\N	\N	Undersåker Survey A1	2014-02-19 14:28:44.312+00
2315	\N	8	33	\N	\N	\N	CTdo7 Stratigraphy 625	2014-02-19 14:28:44.312+00
2316	\N	8	33	\N	\N	\N	Soil chemistry Hällekind	2014-02-19 14:28:44.312+00
2317	\N	8	32	\N	\N	\N	Soil chemistry Foss	2014-02-19 14:28:44.312+00
2318	\N	8	37	\N	\N	\N	CTdo Hotelltomten A992 Survey	2014-02-19 14:28:44.312+00
2319	\N	8	37	\N	\N	\N	Survey H9802	2014-02-19 14:28:44.312+00
2320	\N	8	32	\N	\N	\N	Gåsinge Dillnäs 94 Survey Vallen forts	2014-02-19 14:28:44.312+00
2321	\N	8	33	\N	\N	\N	Nederluleå 330 unit 8 strat E prof	2014-02-19 14:28:44.312+00
2322	\N	8	37	\N	\N	\N	CTdo Vintrie IP A11023 	2014-02-19 14:28:44.312+00
2323	\N	8	74	\N	\N	\N	Hagen, Bäve	2014-02-19 14:28:44.312+00
2324	\N	5	8	\N	\N	\N	Skederid 190 Structure 4	2014-02-19 14:28:44.312+00
2325	\N	8	33	\N	\N	\N	Norra Småholmen Roller grinded samples	2014-02-19 14:28:44.312+00
2327	\N	5	8	\N	\N	\N	Skederid 190 structure 1	2014-02-19 14:28:44.312+00
2328	\N	8	32	\N	\N	\N	Töre 318	2014-02-19 14:28:44.312+00
2329	\N	6	8	\N	\N	\N	Kosjärv	2014-02-19 14:28:44.312+00
2330	\N	8	74	\N	\N	\N	Töre 318	2014-02-19 14:28:44.312+00
2331	\N	8	32	\N	\N	\N	CTdo7 Stratigraphy 468	2014-02-19 14:28:44.312+00
2332	\N	8	32	\N	\N	\N	Gåsinge-Dillnäs 94 Survey Åkerkant	2014-02-19 14:28:44.312+00
2333	\N	8	74	\N	\N	\N	Undersåker Survey settlement area	2014-02-19 14:28:44.312+00
2334	\N	8	37	\N	\N	\N	Lockarp 8:4 Well Kubiena1 	2014-02-19 14:28:44.312+00
2335	\N	8	37	\N	\N	\N	Soil chemistry p5	2014-02-19 14:28:44.312+00
2336	\N	8	74	\N	\N	\N	CTdo Hotelltomten Stratigraphy 3a	2014-02-19 14:28:44.312+00
2337	\N	8	74	\N	\N	\N	Lövleforsen	2014-02-19 14:28:44.312+00
2338	\N	8	33	\N	\N	\N	Arvidsjaur 3913 Strt R13	2014-02-19 14:28:44.312+00
2339	\N	8	33	\N	\N	\N	Soil chemistry p16	2014-02-19 14:28:44.312+00
2340	2	8	33	\N	\N	\N	Marskärskobben Mortared samples	2014-02-19 14:28:44.312+00
2341	\N	8	32	\N	\N	\N	Soil chemistry Features	2014-02-19 14:28:44.312+00
2342	\N	5	8	\N	\N	\N	Svarteborg 593 Pits	2014-02-19 14:28:44.312+00
2343	\N	8	74	\N	\N	\N	Norra Ryssmasterna Mortared samples	2014-02-19 14:28:44.312+00
2344	\N	8	74	\N	\N	\N	Nederluleå 330 Unit 8 strat N profile	2014-02-19 14:28:44.312+00
2345	\N	5	8	\N	\N	\N	Knivsta Structure 3	2014-02-19 14:28:44.312+00
2346	\N	8	33	\N	\N	\N	Soil chemistry p11	2014-02-19 14:28:44.312+00
2347	\N	8	37	\N	\N	\N	CTdo Vintrie IP A50	2014-02-19 14:28:44.312+00
2348	\N	8	37	\N	\N	\N	Undersåker Survey settlement area	2014-02-19 14:28:44.312+00
2349	\N	8	37	\N	\N	\N	CTdo6 Strat K269	2014-02-19 14:28:44.312+00
2350	\N	8	37	\N	\N	\N	CTdo hotelltomten Extended survey	2014-02-19 14:28:44.312+00
2351	\N	8	32	\N	\N	\N	CTdo6Strat A1094	2014-02-19 14:28:44.312+00
2352	\N	8	32	\N	\N	\N	CTdo Hotelltomten A992 Survey	2014-02-19 14:28:44.312+00
2353	\N	8	33	\N	\N	\N	Soil chemistry p13	2014-02-19 14:28:44.312+00
2354	\N	8	32	\N	\N	\N	Svarteborg 88	2014-02-19 14:28:44.312+00
2355	\N	8	32	\N	\N	\N	Survey H9802	2014-02-19 14:28:44.312+00
2356	\N	8	37	\N	\N	\N	Töre 318	2014-02-19 14:28:44.312+00
2357	\N	8	32	\N	\N	\N	Ripkallhögen	2014-02-19 14:28:44.312+00
2358	\N	8	32	\N	\N	\N	Gåsinge Dillnäs 94 Survey Storeken	2014-02-19 14:28:44.312+00
2359	\N	8	74	\N	\N	\N	CTdo7 Stratigraphy A277a Stratigraphy	2014-02-19 14:28:44.312+00
2360	\N	8	32	\N	\N	\N	Nederluleå 330 Unit 10b east profile	2014-02-19 14:28:44.312+00
2361	\N	8	74	\N	\N	\N	Citytunnelprojektet Hyllie 155 Strat 9	2014-02-19 14:28:44.312+00
2362	\N	8	37	\N	\N	\N	CTdo7 Stratigraphy 468	2014-02-19 14:28:44.312+00
2363	\N	8	74	\N	\N	\N	Bergskärit 	2014-02-19 14:28:44.312+00
2364	\N	8	33	\N	\N	\N	Ägglösen	2014-02-19 14:28:44.312+00
2365	\N	8	37	\N	\N	\N	CTdo Vintrie IP A57	2014-02-19 14:28:44.312+00
2366	\N	8	32	\N	\N	\N	Töre 318 DE	2014-02-19 14:28:44.312+00
2367	\N	8	74	\N	\N	\N	Soil chemistry Features	2014-02-19 14:28:44.312+00
2368	\N	8	37	\N	\N	\N	Vänge 88:1 Väsby Ö Soil chem	2014-02-19 14:28:44.312+00
2369	\N	8	32	\N	\N	\N	Gåsinge-Dillnäs Raä 94. Ullevi Hästhagen	2014-02-19 14:28:44.312+00
2370	\N	8	37	\N	\N	\N	CTdo Hotelltomten A2500 Strat	2014-02-19 14:28:44.312+00
2371	\N	8	33	\N	\N	\N	CTdo Hotelltomten A3312 Strat	2014-02-19 14:28:44.312+00
2372	\N	8	33	\N	\N	\N	CTdo7 A277b Stratigraphy	2014-02-19 14:28:44.312+00
2373	\N	8	74	\N	\N	\N	CTdo6 Stratigraphy K268	2014-02-19 14:28:44.312+00
2374	\N	8	33	\N	\N	\N	Svarteborg 593 Hearth/Oven/Cooking pits	2014-02-19 14:28:44.312+00
2375	\N	8	32	\N	\N	\N	Lockarp 8:4 Grav 3 profil AB 	2014-02-19 14:28:44.312+00
2376	\N	8	33	\N	\N	\N	Åssjiejávrátje 	2014-02-19 14:28:44.312+00
2377	\N	6	8	\N	\N	\N	Snarsmon[Plants & pollen]	2014-02-19 14:28:44.312+00
2378	\N	8	33	\N	\N	\N	Svarteborg 116	2014-02-19 14:28:44.312+00
2379	\N	8	32	\N	\N	\N	Gåsinge Dillnäs 94 Survey vallen 2	2014-02-19 14:28:44.312+00
2380	\N	5	8	\N	\N	\N	Strängnäs 443 House 3	2014-02-19 14:28:44.312+00
2381	\N	8	37	\N	\N	\N	Vaksala Raä 300 Soil chemistry	2014-02-19 14:28:44.312+00
2382	\N	5	8	\N	\N	\N	Örtedalen Latrine?	2014-02-19 14:28:44.312+00
2383	\N	8	37	\N	\N	\N	Soil chemistry Features	2014-02-19 14:28:44.312+00
2384	\N	8	33	\N	\N	\N	Soil chemistry Torsby	2014-02-19 14:28:44.312+00
2385	\N	8	74	\N	\N	\N	CTdo Vintrie IP A57	2014-02-19 14:28:44.312+00
2386	\N	5	8	\N	\N	\N	Selånger 136 1994	2014-02-19 14:28:44.312+00
2387	\N	8	74	\N	\N	\N	Svarteborg 593 Pits	2014-02-19 14:28:44.312+00
2388	\N	8	32	\N	\N	\N	CTdo Hotelltomten A3023 Strat	2014-02-19 14:28:44.312+00
2389	\N	5	8	\N	\N	\N	Tanum 544	2014-02-19 14:28:44.312+00
2390	\N	8	33	\N	\N	\N	Soil chemistry Herrestad	2014-02-19 14:28:44.312+00
2391	\N	8	37	\N	\N	\N	Gåsinge Dillnäs 94 Survey Skärvstenshögen	2014-02-19 14:28:44.312+00
2392	\N	8	32	\N	\N	\N	CTdo Hotelltomten Stratigraphy 6b	2014-02-19 14:28:44.312+00
2393	\N	8	74	\N	\N	\N	CTdo Hotelltomten A3023 Strat	2014-02-19 14:28:44.312+00
2394	\N	5	8	\N	\N	\N	Gåsinge Dillnäs 94:6 makro	2014-02-19 14:28:44.312+00
2395	\N	8	37	\N	\N	\N	Arvidsjaur 3913 Strt R3	2014-02-19 14:28:44.312+00
2396	\N	8	37	\N	\N	\N	Soil chemistry Tanum	2014-02-19 14:28:44.312+00
2397	2	8	32	\N	\N	\N	Mjölingsören	2014-02-19 14:28:44.312+00
2398	\N	5	8	\N	\N	\N	Högon grav 2 Trench bottom	2014-02-19 14:28:44.312+00
2399	\N	8	33	\N	\N	\N	Soil chemistry Naverstad	2014-02-19 14:28:44.312+00
2400	\N	8	32	\N	\N	\N	CTdo Hotelltomten Stratigraphy 2	2014-02-19 14:28:44.312+00
2401	\N	8	33	\N	\N	\N	CTdo6 Strat K73	2014-02-19 14:28:44.312+00
2402	\N	8	32	\N	\N	\N	Lockarp 8:4 Well Kubiena1 	2014-02-19 14:28:44.312+00
2403	\N	8	74	\N	\N	\N	CTdo hotelltomten Extended survey	2014-02-19 14:28:44.312+00
2717	\N	8	33	\N	\N	\N	Töre 422	2014-02-19 14:28:44.312+00
2404	2	5	8	\N	\N	\N	Rönnby-Skultuna Sample group 1	2014-02-19 14:28:44.312+00
2405	\N	8	37	\N	\N	\N	CTdo7 A277b Stratigraphy	2014-02-19 14:28:44.312+00
2406	\N	8	32	\N	\N	\N	Ctdo6 Strat K271	2014-02-19 14:28:44.312+00
2407	\N	8	37	\N	\N	\N	CTdo6 House 1 post holes	2014-02-19 14:28:44.312+00
2408	\N	8	37	\N	\N	\N	Soil chemistry Foss 438	2014-02-19 14:28:44.312+00
2409	\N	5	8	\N	\N	\N	Tuna 330 macrofossil	2014-02-19 14:28:44.312+00
2410	\N	8	37	\N	\N	\N	Citytunneln Hyllie 155 Strat 1	2014-02-19 14:28:44.312+00
2411	\N	8	74	\N	\N	\N	CTdo6 Strat K269	2014-02-19 14:28:44.312+00
2412	\N	8	33	\N	\N	\N	Gåsinge-Dillnäs 94 Täby boplatsläge	2014-02-19 14:28:44.312+00
2413	\N	8	37	\N	\N	\N	CTdo Hotelltomten A3184 Strat	2014-02-19 14:28:44.312+00
2414	\N	8	33	\N	\N	\N	Töre 408 BD	2014-02-19 14:28:44.312+00
2415	\N	8	37	\N	\N	\N	Svarteborg 590	2014-02-19 14:28:44.312+00
2416	\N	8	33	\N	\N	\N	Arvidsjaur 3913 Strat R2	2014-02-19 14:28:44.312+00
2417	\N	8	33	\N	\N	\N	CTdo Vintrie IP A10855	2014-02-19 14:28:44.312+00
2418	\N	8	33	\N	\N	\N	Svarteborg 593 Pits	2014-02-19 14:28:44.312+00
2419	\N	8	37	\N	\N	\N	Ctdo6 Strat K271	2014-02-19 14:28:44.312+00
2420	\N	8	32	\N	\N	\N	Nederluleå 330 Unit 8 strat N profile	2014-02-19 14:28:44.312+00
2421	\N	5	8	\N	\N	\N	Features	2014-02-19 14:28:44.312+00
2422	\N	5	8	\N	\N	\N	Örtedalen Cultivation area	2014-02-19 14:28:44.312+00
2520	\N	8	33	\N	\N	\N	Kall 599:3	2014-02-19 14:28:44.312+00
2423	\N	8	32	\N	\N	\N	Stratigraphy 1	2014-02-19 14:28:44.312+00
2424	\N	8	37	\N	\N	\N	Svarteborg 585	2014-02-19 14:28:44.312+00
2425	\N	8	74	\N	\N	\N	CTdo7 Stratigraphy 59	2014-02-19 14:28:44.312+00
2426	\N	8	33	\N	\N	\N	CTdo Hotelltomten A2052 Strat	2014-02-19 14:28:44.312+00
2427	\N	8	32	\N	\N	\N	Citytunnelprojektet Hyllie 155 Strat 4	2014-02-19 14:28:44.312+00
2428	\N	8	32	\N	\N	\N	Soil chemistry p16	2014-02-19 14:28:44.312+00
2429	\N	8	33	\N	\N	\N	CTdo Hotelltomten Stratigraphy 3b	2014-02-19 14:28:44.312+00
2430	\N	8	74	\N	\N	\N	Nickösörarna	2014-02-19 14:28:44.312+00
2431	\N	5	8	\N	\N	\N	Björlanda 348	2014-02-19 14:28:44.312+00
2432	\N	8	33	\N	\N	\N	Soil chemistry Features	2014-02-19 14:28:44.312+00
2433	\N	8	37	\N	\N	\N	CTdo6 Stratigraphy K268	2014-02-19 14:28:44.312+00
2434	\N	8	74	\N	\N	\N	Soil chemistry p2	2014-02-19 14:28:44.312+00
2435	\N	8	32	\N	\N	\N	Svarteborg 116	2014-02-19 14:28:44.312+00
2436	\N	8	37	\N	\N	\N	Nederluleå 330 Unit 10b east profile	2014-02-19 14:28:44.312+00
2437	\N	8	37	\N	\N	\N	CTdo Vintrie IP A58	2014-02-19 14:28:44.312+00
2438	\N	8	37	\N	\N	\N	CTdo Hotelltomten Stratigraphy 3a	2014-02-19 14:28:44.312+00
2439	\N	8	74	\N	\N	\N	CTdo6 Strat K274	2014-02-19 14:28:44.312+00
2440	\N	8	37	\N	\N	\N	Solberga Hearths	2014-02-19 14:28:44.312+00
2441	\N	8	37	\N	\N	\N	Svarteborg 116	2014-02-19 14:28:44.312+00
2442	\N	8	32	\N	\N	\N	Nederluleå 330 unit 8 strat E prof	2014-02-19 14:28:44.312+00
2443	\N	5	8	\N	\N	\N	Sample group 1[Plants & pollen]	2014-02-19 14:28:44.312+00
2444	\N	8	33	\N	\N	\N	Soil chemistry p8	2014-02-19 14:28:44.312+00
2445	\N	8	35	\N	\N	\N	Nyköping 231 SG2	2014-02-19 14:28:44.312+00
2446	\N	8	37	\N	\N	\N	Citytunnelprojektet Hyllie 155 Strat 10	2014-02-19 14:28:44.312+00
2447	\N	8	33	\N	\N	\N	Södra Hee Feature sample	2014-02-19 14:28:44.312+00
2448	\N	8	33	\N	\N	\N	Lockarp 8:4 Well Kubiena1 	2014-02-19 14:28:44.312+00
2449	\N	8	37	\N	\N	\N	CTdo6 Strat K275	2014-02-19 14:28:44.312+00
2450	\N	8	37	\N	\N	\N	Gåsinge Dillnäs Survey Pörtkullen 	2014-02-19 14:28:44.312+00
2451	\N	8	74	\N	\N	\N	Svarteborg 88	2014-02-19 14:28:44.312+00
2452	\N	8	32	\N	\N	\N	CTdo Vintrie IP A58	2014-02-19 14:28:44.312+00
2453	\N	8	74	\N	\N	\N	Södra Hee Feature sample	2014-02-19 14:28:44.312+00
2454	\N	8	74	\N	\N	\N	CTdo7 Stratigraphy 624	2014-02-19 14:28:44.312+00
2455	\N	10	8	\N	\N	\N	Åkroken makro	2014-02-19 14:28:44.312+00
2456	\N	8	74	\N	\N	\N	Gåsinge Dillnäs 94 Survey vallen 2	2014-02-19 14:28:44.312+00
2457	\N	5	8	\N	\N	\N	Knivsta Structure 10	2014-02-19 14:28:44.312+00
2458	\N	8	32	\N	\N	\N	Svarteborg 589	2014-02-19 14:28:44.312+00
2459	\N	8	74	\N	\N	\N	Ctdo6 Strat K271	2014-02-19 14:28:44.312+00
2460	\N	8	74	\N	\N	\N	CTdo7 Stratigraphy 455	2014-02-19 14:28:44.312+00
2461	\N	8	37	\N	\N	\N	Citytunnelprojektet Hyllie 155 Strat 9	2014-02-19 14:28:44.312+00
2462	\N	8	37	\N	\N	\N	CTdi Hotelltomten A3474 Strat	2014-02-19 14:28:44.312+00
2463	\N	8	74	\N	\N	\N	Gåsinge Dillnäs 94 Survey Skärvstenshögen	2014-02-19 14:28:44.312+00
2464	\N	8	74	\N	\N	\N	Svarteborg 593 Hearth/Oven/Cooking pits	2014-02-19 14:28:44.312+00
2465	\N	8	33	\N	\N	\N	CTdo7 Stratigraphy 452	2014-02-19 14:28:44.312+00
2466	\N	8	37	\N	\N	\N	Citytunnelprojektet Hyllie 155 Strat 12	2014-02-19 14:28:44.312+00
2467	\N	8	37	\N	\N	\N	CT do6 House 2 post holes	2014-02-19 14:28:44.312+00
2468	\N	8	33	\N	\N	\N	Citytunnelprojektet Hyllie 155 Strat 6	2014-02-19 14:28:44.312+00
2469	\N	5	8	\N	\N	\N	Features	2014-02-19 14:28:44.312+00
2470	\N	8	32	\N	\N	\N	CTdo Hotelltomten Survey	2014-02-19 14:28:44.312+00
2471	\N	8	33	\N	\N	\N	CTdo7 Stratigraphy 619	2014-02-19 14:28:44.312+00
2472	\N	8	37	\N	\N	\N	CTdo8 K2056	2014-02-19 14:28:44.312+00
2473	\N	8	74	\N	\N	\N	CTdo7 Stratigraphy 459	2014-02-19 14:28:44.312+00
2474	\N	5	8	\N	\N	\N	Knivsta 16 Structure 4	2014-02-19 14:28:44.312+00
2475	\N	8	37	\N	\N	\N	Vilhelmina 1647	2014-02-19 14:28:44.312+00
2476	\N	8	32	\N	\N	\N	Töre 408 CD	2014-02-19 14:28:44.312+00
2477	\N	8	37	\N	\N	\N	Gåsinge-Dillnäs 94 Survey Hästhagen	2014-02-19 14:28:44.312+00
2478	2	8	74	\N	\N	\N	Uppsala 499	2014-02-19 14:28:44.312+00
2479	\N	8	33	\N	\N	\N	Citytunnelprojektet Hyllie 155 Strat 12	2014-02-19 14:28:44.312+00
2480	\N	8	37	\N	\N	\N	Lockarp 8:4 Grav 3 profil AB 	2014-02-19 14:28:44.312+00
2481	\N	8	32	\N	\N	\N	Södra Hee Feature sample	2014-02-19 14:28:44.312+00
2482	\N	8	33	\N	\N	\N	Svarteborg 592	2014-02-19 14:28:44.312+00
2483	\N	8	74	\N	\N	\N	Soil chemistry Naverstad	2014-02-19 14:28:44.312+00
2484	\N	5	8	\N	\N	\N	Knivsta 16 Structure 1	2014-02-19 14:28:44.312+00
2485	\N	8	74	\N	\N	\N	CTdo7 A250 survey	2014-02-19 14:28:44.312+00
2486	\N	8	32	\N	\N	\N	Undersåker Survey A2	2014-02-19 14:28:44.312+00
2487	\N	8	33	\N	\N	\N	Ctdo6 Strat K271	2014-02-19 14:28:44.312+00
2488	\N	8	74	\N	\N	\N	Åssjiejávrátje Survey 	2014-02-19 14:28:44.312+00
2489	\N	8	37	\N	\N	\N	CTdo Hotelltomten A1759 Strat	2014-02-19 14:28:44.312+00
2490	\N	8	74	\N	\N	\N	CTdo7 Stratigraphy 452	2014-02-19 14:28:44.312+00
2491	\N	8	32	\N	\N	\N	Stora Träskär	2014-02-19 14:28:44.312+00
2492	\N	5	8	\N	\N	\N	Tossene 446	2014-02-19 14:28:44.312+00
2493	\N	8	74	\N	\N	\N	Citytunnelprojektet Hyllie 155	2014-02-19 14:28:44.312+00
2494	\N	8	32	\N	\N	\N	Norra Ryssmasterna Roller grinded samples	2014-02-19 14:28:44.312+00
2495	\N	6	8	\N	\N	\N	Turinge 415 1997	2014-02-19 14:28:44.312+00
2496	\N	8	32	\N	\N	\N	CTdo6 Strat K274	2014-02-19 14:28:44.312+00
2497	\N	8	33	\N	\N	\N	Soil chemistry Foss	2014-02-19 14:28:44.312+00
2498	\N	8	37	\N	\N	\N	Älvsbyn 958 Strat 3	2014-02-19 14:28:44.312+00
2499	\N	8	33	\N	\N	\N	CTdo6 Strat K269	2014-02-19 14:28:44.312+00
2500	\N	8	37	\N	\N	\N	Ägglösen	2014-02-19 14:28:44.312+00
2501	\N	5	8	\N	\N	\N	Svarteborg 593 House 4	2014-02-19 14:28:44.312+00
2502	\N	8	33	\N	\N	\N	Nederluleå 330 Unit 8 survey	2014-02-19 14:28:44.312+00
2503	\N	8	32	\N	\N	\N	Torö 75 	2014-02-19 14:28:44.312+00
2504	\N	8	37	\N	\N	\N	Nederluleå 330 Unit 8 strat N profile	2014-02-19 14:28:44.312+00
2505	\N	8	37	\N	\N	\N	CTdo7 Stratigraphy 625	2014-02-19 14:28:44.312+00
2506	\N	8	33	\N	\N	\N	CTdo Hotelltomten Stratigraphy 4	2014-02-19 14:28:44.312+00
2507	\N	8	32	\N	\N	\N	CTdo hotelltomten Extended survey	2014-02-19 14:28:44.312+00
2508	\N	8	33	\N	\N	\N	Gåsinge Dillnäs 94 Survey vallen 2	2014-02-19 14:28:44.312+00
2509	\N	8	37	\N	\N	\N	Soil chemistry Features	2014-02-19 14:28:44.312+00
2510	\N	8	37	\N	\N	\N	Citytunnelprojektet Hyllie 155 Strat 3	2014-02-19 14:28:44.312+00
2511	\N	8	35	\N	\N	\N	Åkroken	2014-02-19 14:28:44.312+00
2512	\N	8	74	\N	\N	\N	CTdo Vintrie IP A11023 	2014-02-19 14:28:44.312+00
2513	\N	8	74	\N	\N	\N	CTdo7 Stratigraphy 463	2014-02-19 14:28:44.312+00
2514	\N	8	35	\N	\N	\N	Töre random samples	2014-02-19 14:28:44.312+00
2515	\N	8	32	\N	\N	\N	CTdi Hotelltomten A3474 Strat	2014-02-19 14:28:44.312+00
2516	\N	8	74	\N	\N	\N	Soil chemistry Torsby	2014-02-19 14:28:44.312+00
2517	\N	8	33	\N	\N	\N	Borgsjö 165	2014-02-19 14:28:44.312+00
2518	\N	8	33	\N	\N	\N	Soil chemistry p10	2014-02-19 14:28:44.312+00
2519	\N	8	32	\N	\N	\N	CTdo7 Stratigraphy 455	2014-02-19 14:28:44.312+00
2521	\N	8	74	\N	\N	\N	CTdo7 Stratigraphy 453	2014-02-19 14:28:44.312+00
2522	\N	5	8	\N	\N	\N	Österhaninge 72	2014-02-19 14:28:44.312+00
2523	\N	8	37	\N	\N	\N	Nickösörarna	2014-02-19 14:28:44.312+00
2524	\N	8	74	\N	\N	\N	CTdo6 Strat K267	2014-02-19 14:28:44.312+00
2525	\N	8	37	\N	\N	\N	Arvidsjaur 3913 Strat R2	2014-02-19 14:28:44.312+00
2526	\N	8	32	\N	\N	\N	Björlanda 459	2014-02-19 14:28:44.312+00
2527	\N	8	74	\N	\N	\N	Gåsinge-Dillnäs 94 Täby boplatsläge	2014-02-19 14:28:44.312+00
2528	\N	8	33	\N	\N	\N	Svarteborg 88	2014-02-19 14:28:44.312+00
2529	\N	8	74	\N	\N	\N	CTdo Hotelltomten Stratigraphy 6a	2014-02-19 14:28:44.312+00
2530	\N	8	32	\N	\N	\N	CTdo Hotelltomten A3184 Strat	2014-02-19 14:28:44.312+00
2531	\N	8	37	\N	\N	\N	Ripkallhögen	2014-02-19 14:28:44.312+00
2532	\N	8	33	\N	\N	\N	Arvidsjaur 3913 Strt R3	2014-02-19 14:28:44.312+00
2533	\N	8	33	\N	\N	\N	Soil chemistry Features	2014-02-19 14:28:44.312+00
2534	\N	8	32	\N	\N	\N	CTdo7 Stratigraphy 470	2014-02-19 14:28:44.312+00
2535	\N	8	32	\N	\N	\N	Survey H9801	2014-02-19 14:28:44.312+00
2536	\N	8	37	\N	\N	\N	CTdo Hotelltomten Stratigraphy 7	2014-02-19 14:28:44.312+00
2537	\N	8	32	\N	\N	\N	Citytunnelprojektet Hyllie 155 Strat 9	2014-02-19 14:28:44.312+00
2538	\N	8	74	\N	\N	\N	CTdo6 Strat K275	2014-02-19 14:28:44.312+00
2539	\N	8	37	\N	\N	\N	Gåsinge Dillnäs 94 Survey Storeken	2014-02-19 14:28:44.312+00
2540	\N	5	8	\N	\N	\N	Skederid 106	2014-02-19 14:28:44.312+00
2541	\N	8	37	\N	\N	\N	Nederluleå 330 Unit 8 survey	2014-02-19 14:28:44.312+00
2542	\N	8	74	\N	\N	\N	Björlanda 459	2014-02-19 14:28:44.312+00
2543	\N	6	8	\N	\N	\N	Sample group 1[Plants & pollen]	2014-02-19 14:28:44.312+00
2544	\N	6	8	\N	\N	\N	Nyköpin 231 SG2	2014-02-19 14:28:44.312+00
2545	\N	8	37	\N	\N	\N	CTdo7 Stratigraphy 452	2014-02-19 14:28:44.312+00
2546	\N	5	8	\N	\N	\N	Tuna 328:1 Sample group 1	2014-02-19 14:28:44.312+00
2547	\N	8	33	\N	\N	\N	Stora Träskär	2014-02-19 14:28:44.312+00
2548	\N	8	74	\N	\N	\N	Citytunnelprojektet Hyllie 155 Strat 10	2014-02-19 14:28:44.312+00
2549	\N	8	33	\N	\N	\N	Citytunnelprojektet Hyllie 155 Strat 5	2014-02-19 14:28:44.312+00
2550	\N	5	8	\N	\N	\N	Sample group 1[Plants & pollen]	2014-02-19 14:28:44.312+00
2551	\N	8	32	\N	\N	\N	CTdo6 Strat K272	2014-02-19 14:28:44.312+00
2552	\N	8	33	\N	\N	\N	Lövleforsen	2014-02-19 14:28:44.312+00
2553	\N	5	32	\N	\N	\N	Nederluleå 330 Archaeobotany	2014-02-19 14:28:44.312+00
2554	\N	8	33	\N	\N	\N	Ripkallhögen	2014-02-19 14:28:44.312+00
2555	\N	8	37	\N	\N	\N	Stora Halmören	2014-02-19 14:28:44.312+00
2556	\N	8	74	\N	\N	\N	Citytunnelprojektet Hyllie 155 Strat 12	2014-02-19 14:28:44.312+00
2557	\N	5	8	\N	\N	\N	Örtedalen Cultural layer in house	2014-02-19 14:28:44.312+00
2558	\N	8	74	\N	\N	\N	Soil chemistry p15	2014-02-19 14:28:44.312+00
2559	\N	8	37	\N	\N	\N	CTdo7 Stratigraphy 627	2014-02-19 14:28:44.312+00
2560	\N	8	36	\N	\N	\N	Nyköping 231 SG2	2014-02-19 14:28:44.312+00
2561	\N	8	74	\N	\N	\N	Citytunneln Hyllie 155 Strat 1	2014-02-19 14:28:44.312+00
2562	\N	8	37	\N	\N	\N	Survey corral 	2014-02-19 14:28:44.312+00
2563	\N	8	37	\N	\N	\N	Själstuga Sg 2	2014-02-19 14:28:44.312+00
2564	\N	8	33	\N	\N	\N	Solberga Building	2014-02-19 14:28:44.312+00
2565	2	8	32	\N	\N	\N	Fåröarna roller grinded samples	2014-02-19 14:28:44.312+00
2566	\N	8	74	\N	\N	\N	Nyköping 231 SG2	2014-02-19 14:28:44.312+00
2567	\N	8	37	\N	\N	\N	CTdo Hotelltomten A1293 Strat	2014-02-19 14:28:44.312+00
2568	\N	8	74	\N	\N	\N	Soil chemistry p6	2014-02-19 14:28:44.312+00
2569	\N	8	32	\N	\N	\N	Citytunnelprojektet Hyllie 155 Strat 12	2014-02-19 14:28:44.312+00
2570	\N	5	8	\N	\N	\N	Högom grav 2 Primary cult layer	2014-02-19 14:28:44.312+00
2571	\N	13	8	\N	\N	\N	Knivsta 16 Structure 4	2014-02-19 14:28:44.312+00
2572	\N	5	8	\N	\N	\N	Västerhaninge 201 	2014-02-19 14:28:44.312+00
2573	\N	8	37	\N	\N	\N	Svarteborg 592	2014-02-19 14:28:44.312+00
2574	\N	8	74	\N	\N	\N	CTdo Vintrie IP A58	2014-02-19 14:28:44.312+00
2575	\N	8	37	\N	\N	\N	CTdo Hotelltomten Stratigraphy 5b	2014-02-19 14:28:44.312+00
2576	\N	8	37	\N	\N	\N	CTdo Hotelltomten A718 Strat	2014-02-19 14:28:44.312+00
2577	\N	5	8	\N	\N	\N	Hedningsgärdet	2014-02-19 14:28:44.312+00
2578	\N	8	37	\N	\N	\N	CTdo Vintrie IP A16847	2014-02-19 14:28:44.312+00
2579	\N	8	33	\N	\N	\N	Gåsinge Dillnäs 94 Survey Vallen 3	2014-02-19 14:28:44.312+00
2580	\N	8	32	\N	\N	\N	Citytunnelprojektet Hyllie 155 Strat 8	2014-02-19 14:28:44.312+00
2581	\N	8	33	\N	\N	\N	Citytunnelprojektet Hyllie 155 Strat 7	2014-02-19 14:28:44.312+00
2582	\N	8	32	\N	\N	\N	Citytunneln Hyllie 155 Strat 1	2014-02-19 14:28:44.312+00
2583	\N	8	74	\N	\N	\N	CT do6 House 2 post holes	2014-02-19 14:28:44.312+00
2584	\N	8	74	\N	\N	\N	CTdo7 Stratigraphy 623	2014-02-19 14:28:44.312+00
2585	\N	8	33	\N	\N	\N	Arvidsjaur 3941 Strat R10	2014-02-19 14:28:44.312+00
2586	\N	8	32	\N	\N	\N	CTdo6 Strat K270	2014-02-19 14:28:44.312+00
2587	\N	5	8	\N	\N	\N	Knivsta 16 Cultural layers	2014-02-19 14:28:44.312+00
2588	\N	8	37	\N	\N	\N	Soil chemistry Torsby	2014-02-19 14:28:44.312+00
2589	\N	8	74	\N	\N	\N	Töre 422	2014-02-19 14:28:44.312+00
2590	\N	8	32	\N	\N	\N	CTdo Hotelltomten Stratigraphy 5a	2014-02-19 14:28:44.312+00
2591	\N	8	74	\N	\N	\N	Nyköping 231 SG1	2014-02-19 14:28:44.312+00
2592	\N	8	32	\N	\N	\N	CT do6 House 2 post holes	2014-02-19 14:28:44.312+00
2593	\N	8	33	\N	\N	\N	CTdo7 Stratigraphy 627	2014-02-19 14:28:44.312+00
2594	\N	6	8	\N	\N	\N	Älgtjärn, Jåvan. Charcoal samples	2014-02-19 14:28:44.312+00
2595	\N	5	8	\N	\N	\N	Solberg	2014-02-19 14:28:44.312+00
2596	2	8	33	\N	\N	\N	Uppsala 499	2014-02-19 14:28:44.312+00
2597	\N	8	37	\N	\N	\N	CTdo Hotelltomten A3312 Strat	2014-02-19 14:28:44.312+00
2598	\N	8	37	\N	\N	\N	Arvidsjaur 3913 Strt R14	2014-02-19 14:28:44.312+00
2599	\N	8	74	\N	\N	\N	Borgsjö 165	2014-02-19 14:28:44.312+00
2600	\N	8	33	\N	\N	\N	Soil chemistry p4	2014-02-19 14:28:44.312+00
2601	\N	8	37	\N	\N	\N	CTdo Hotelltomten Survey	2014-02-19 14:28:44.312+00
2602	\N	8	37	\N	\N	\N	CTdo6 Strat K73	2014-02-19 14:28:44.312+00
2603	\N	8	74	\N	\N	\N	Nederluleå 330 unit 10b survey	2014-02-19 14:28:44.312+00
2604	\N	8	74	\N	\N	\N	Citytunnelprojektet Hyllie 155 Strat 5	2014-02-19 14:28:44.312+00
2605	\N	8	37	\N	\N	\N	Citytunnelprojektet Hyllie 155	2014-02-19 14:28:44.312+00
2606	\N	5	8	\N	\N	\N	Knivsta Structure 8	2014-02-19 14:28:44.312+00
2607	\N	8	74	\N	\N	\N	Åkroken	2014-02-19 14:28:44.312+00
2608	\N	8	33	\N	\N	\N	Ägglösen	2014-02-19 14:28:44.312+00
2609	\N	8	33	\N	\N	\N	Lockarp 8:4 Grav 3 profil AB 	2014-02-19 14:28:44.312+00
2610	\N	8	33	\N	\N	\N	CTdo7 Stratigraphy 621	2014-02-19 14:28:44.312+00
2611	\N	8	33	\N	\N	\N	Final excavation 2006	2014-02-19 14:28:44.312+00
2612	\N	8	74	\N	\N	\N	Citytunnelprojektet Hyllie 155 Strat 6	2014-02-19 14:28:44.312+00
2824	\N	8	32	\N	\N	\N	Åkroken	2014-02-19 14:28:44.312+00
2613	2	8	37	\N	\N	\N	Fåröarna roller grinded samples	2014-02-19 14:28:44.312+00
2614	\N	8	37	\N	\N	\N	CTdo7 Stratigraphy 470	2014-02-19 14:28:44.312+00
2615	\N	8	33	\N	\N	\N	Citytunneln Hyllie 155 Strat 1	2014-02-19 14:28:44.312+00
2616	\N	8	74	\N	\N	\N	CTdo Hotelltomten Stratigraphy 5b	2014-02-19 14:28:44.312+00
2617	\N	8	32	\N	\N	\N	Svarteborg 585	2014-02-19 14:28:44.312+00
2618	\N	8	74	\N	\N	\N	CTdo7 Stratigraphy 470	2014-02-19 14:28:44.312+00
2619	\N	8	74	\N	\N	\N	CTdo7 Stratigraphy 621	2014-02-19 14:28:44.312+00
2620	\N	8	37	\N	\N	\N	Töre 320 Elemen analysis	2014-02-19 14:28:44.312+00
2622	\N	8	32	\N	\N	\N	CTdo7 Stratigraphy 628	2014-02-19 14:28:44.312+00
2623	\N	8	33	\N	\N	\N	Gåsinge Dillnäs 94 Survey Vallen forts	2014-02-19 14:28:44.312+00
2624	\N	8	33	\N	\N	\N	Mjölingsören 	2014-02-19 14:28:44.312+00
2625	\N	8	32	\N	\N	\N	CTdo7 Stratigraphy 623	2014-02-19 14:28:44.312+00
2626	\N	5	8	\N	\N	\N	Österhaninge 238	2014-02-19 14:28:44.312+00
2627	\N	8	37	\N	\N	\N	Svarteborg 593 House 2	2014-02-19 14:28:44.312+00
2628	\N	8	33	\N	\N	\N	CTdo7 Stratigraphy 626	2014-02-19 14:28:44.312+00
2629	\N	8	74	\N	\N	\N	Svarteborg 116	2014-02-19 14:28:44.312+00
2630	\N	8	32	\N	\N	\N	Soil chemistry Herrestad	2014-02-19 14:28:44.312+00
2631	\N	8	37	\N	\N	\N	Gåsinge-Dillnäs 94 Täby boplatsläge	2014-02-19 14:28:44.312+00
2632	\N	8	37	\N	\N	\N	Citytunnelprojektet Hyllie 155 Strat wetland layer	2014-02-19 14:28:44.312+00
2633	\N	8	33	\N	\N	\N	Svarteborg 593 Sample group 1	2014-02-19 14:28:44.312+00
2634	\N	8	33	\N	\N	\N	Soil chemistry A300	2014-02-19 14:28:44.312+00
2635	\N	8	74	\N	\N	\N	CTdo6 Strat K73	2014-02-19 14:28:44.312+00
2636	2	8	32	\N	\N	\N	Marskärskobben Roller grinded samples	2014-02-19 14:28:44.312+00
2637	\N	8	74	\N	\N	\N	Svarteborg 593 House 4	2014-02-19 14:28:44.312+00
2638	\N	8	74	\N	\N	\N	Survey settlement area	2014-02-19 14:28:44.312+00
2639	\N	8	33	\N	\N	\N	Norra Småholmen Mortared	2014-02-19 14:28:44.312+00
2640	\N	5	8	\N	\N	\N	Svarteborg 593 House 2	2014-02-19 14:28:44.312+00
2641	\N	8	74	\N	\N	\N	CTdo Hotelltomten A3312 Strat	2014-02-19 14:28:44.312+00
2642	\N	8	32	\N	\N	\N	CTdo7 Stratigraphy 463	2014-02-19 14:28:44.312+00
2643	\N	8	74	\N	\N	\N	CTdo6 Strat K270	2014-02-19 14:28:44.312+00
2644	\N	8	37	\N	\N	\N	Soil chemistry p6	2014-02-19 14:28:44.312+00
2645	\N	8	37	\N	\N	\N	Survey area near sami hut	2014-02-19 14:28:44.312+00
2646	\N	8	33	\N	\N	\N	CTdo7 Stratigraphy 459	2014-02-19 14:28:44.312+00
2647	\N	6	8	\N	\N	\N	Österhaninge 238	2014-02-19 14:28:44.312+00
2648	\N	8	33	\N	\N	\N	CTdo7 Stratigraphy 470	2014-02-19 14:28:44.312+00
2649	\N	8	33	\N	\N	\N	Själstuga Sg 2	2014-02-19 14:28:44.312+00
2650	\N	5	8	\N	\N	\N	Österhaninge 230	2014-02-19 14:28:44.312+00
2651	\N	8	74	\N	\N	\N	CTdoHotelltomten Stratigraphy 1	2014-02-19 14:28:44.312+00
2652	\N	8	32	\N	\N	\N	Citytunnelprojektet Hyllie 155 Strat 5	2014-02-19 14:28:44.312+00
2653	\N	8	74	\N	\N	\N	Soil chemistry p4	2014-02-19 14:28:44.312+00
2654	\N	8	74	\N	\N	\N	Norra Småholmen Roller grinded samples	2014-02-19 14:28:44.312+00
2655	\N	8	37	\N	\N	\N	Svarteborg 589	2014-02-19 14:28:44.312+00
2656	\N	8	74	\N	\N	\N	Soil chemistry Features	2014-02-19 14:28:44.312+00
2657	\N	8	32	\N	\N	\N	Gåsinge Dillnäs 94 Survey Vallen 3	2014-02-19 14:28:44.312+00
2658	\N	8	37	\N	\N	\N	Solberga Building	2014-02-19 14:28:44.312+00
2659	\N	8	74	\N	\N	\N	Soil chemistry Foss 166	2014-02-19 14:28:44.312+00
2660	\N	5	8	\N	\N	\N	Selånger 136 1995	2014-02-19 14:28:44.312+00
2661	\N	8	37	\N	\N	\N	Survey H9801	2014-02-19 14:28:44.312+00
2662	\N	8	33	\N	\N	\N	Nyköpingshus	2014-02-19 14:28:44.312+00
2663	\N	8	32	\N	\N	\N	Svarteborg 593 Hearth/Oven/Cooking pits	2014-02-19 14:28:44.312+00
2664	\N	8	32	\N	\N	\N	CTdo Hotelltomten Stratigraphy 5b	2014-02-19 14:28:44.312+00
2665	\N	8	37	\N	\N	\N	Gåsinge Dillnäs 94 Survey vallen 2	2014-02-19 14:28:44.312+00
2666	\N	8	33	\N	\N	\N	CTdo Hotelltomten Stratigraphy 6a	2014-02-19 14:28:44.312+00
2667	\N	8	33	\N	\N	\N	Soil chemistry Foss 166	2014-02-19 14:28:44.312+00
2668	\N	8	32	\N	\N	\N	Citytunnelprojektet Hyllie 155 Strat 3	2014-02-19 14:28:44.312+00
2669	\N	8	37	\N	\N	\N	Arvidsjaur 3913 Strt R4	2014-02-19 14:28:44.312+00
2670	\N	8	32	\N	\N	\N	CTdo6 Strat K73	2014-02-19 14:28:44.312+00
2671	\N	8	74	\N	\N	\N	Soil chemistry p13	2014-02-19 14:28:44.312+00
2672	\N	8	33	\N	\N	\N	Nickösörarna	2014-02-19 14:28:44.312+00
2673	2	8	33	\N	\N	\N	Fåröarna roller grinded samples	2014-02-19 14:28:44.312+00
2674	\N	8	37	\N	\N	\N	Soil chemistry Ytterbu 2010	2014-02-19 14:28:44.312+00
2675	\N	8	74	\N	\N	\N	Torö 75 	2014-02-19 14:28:44.312+00
2676	\N	8	32	\N	\N	\N	Survey corral 	2014-02-19 14:28:44.312+00
2677	\N	8	37	\N	\N	\N	CTdo6 Strat K267	2014-02-19 14:28:44.312+00
2678	\N	8	32	\N	\N	\N	Svarteborg 593 House 2	2014-02-19 14:28:44.312+00
2679	\N	8	33	\N	\N	\N	CTdo6 Stratigraphy K268	2014-02-19 14:28:44.312+00
2680	\N	8	37	\N	\N	\N	CTdo7 Stratigraphy 624	2014-02-19 14:28:44.312+00
2681	\N	8	32	\N	\N	\N	Soil chemistry Tanum 59	2014-02-19 14:28:44.312+00
2682	\N	5	8	\N	\N	\N	Örtedalen Trench	2014-02-19 14:28:44.312+00
2683	\N	8	74	\N	\N	\N	Lockarp 8:4 Grav 3 profil AB 	2014-02-19 14:28:44.312+00
2684	\N	8	74	\N	\N	\N	Soil chemistry A300	2014-02-19 14:28:44.312+00
2685	\N	8	37	\N	\N	\N	Vänge 88:1 Väsby V Soil chem	2014-02-19 14:28:44.312+00
2686	\N	8	74	\N	\N	\N	CTdo7 Extended survey	2014-02-19 14:28:44.312+00
2687	\N	8	32	\N	\N	\N	Solberga Building	2014-02-19 14:28:44.312+00
2688	\N	8	37	\N	\N	\N	Norra Småholmen Roller grinded samples	2014-02-19 14:28:44.312+00
2689	\N	8	74	\N	\N	\N	Lockarp 8:4 Well Kubiena 2	2014-02-19 14:28:44.312+00
2690	\N	8	33	\N	\N	\N	Nederluleå 330 Unit 10b east profile	2014-02-19 14:28:44.312+00
2691	\N	6	8	\N	\N	\N	Njurunda 838	2014-02-19 14:28:44.312+00
2692	\N	8	32	\N	\N	\N	Kall 599:3	2014-02-19 14:28:44.312+00
2693	\N	8	37	\N	\N	\N	Svarteborg 593 Hearth/Oven/Cooking pits	2014-02-19 14:28:44.312+00
2694	\N	6	8	\N	\N	\N	Kall 599:3	2014-02-19 14:28:44.312+00
2695	\N	8	32	\N	\N	\N	Strängnäs 443 Sunken hut floor	2014-02-19 14:28:44.312+00
2696	\N	8	74	\N	\N	\N	Soil chemistry Torsby	2014-02-19 14:28:44.312+00
2697	\N	8	32	\N	\N	\N	CTdo Vintrie IP A10855	2014-02-19 14:28:44.312+00
2698	\N	5	8	\N	\N	\N	Features	2014-02-19 14:28:44.312+00
2699	\N	8	33	\N	\N	\N	Norrala 	2014-02-19 14:28:44.312+00
2700	\N	5	8	\N	\N	\N	Njurunda 125	2014-02-19 14:28:44.312+00
2701	\N	8	33	\N	\N	\N	CTdoHotelltomten Stratigraphy 1	2014-02-19 14:28:44.312+00
2702	\N	8	32	\N	\N	\N	CTdo6 House 1 post holes	2014-02-19 14:28:44.312+00
2703	2	8	74	\N	\N	\N	Fåröarna Mortared samples	2014-02-19 14:28:44.312+00
2704	\N	8	32	\N	\N	\N	Soil chemistry Naverstad	2014-02-19 14:28:44.312+00
2705	\N	8	37	\N	\N	\N	Norra Ryssmasterna Roller grinded samples	2014-02-19 14:28:44.312+00
2706	\N	8	32	\N	\N	\N	Nyköpingshus	2014-02-19 14:28:44.312+00
2707	\N	8	32	\N	\N	\N	Töre 422	2014-02-19 14:28:44.312+00
2708	2	8	33	\N	\N	\N	Mjölingsören	2014-02-19 14:28:44.312+00
2709	\N	8	32	\N	\N	\N	Citytunnelprojektet Hyllie 155 Strat 6	2014-02-19 14:28:44.312+00
2710	\N	5	8	\N	\N	\N	Gammelstad, Luleå 	2014-02-19 14:28:44.312+00
2711	2	8	33	\N	\N	\N	Marskärskobben Roller grinded samples	2014-02-19 14:28:44.312+00
2712	\N	8	74	\N	\N	\N	Citytunnelprojektet Hyllie 155 Strat 3	2014-02-19 14:28:44.312+00
2713	\N	8	32	\N	\N	\N	Soil chemistry Foss 166	2014-02-19 14:28:44.312+00
2714	\N	8	32	\N	\N	\N	CTdo6 Strat K267	2014-02-19 14:28:44.312+00
2715	\N	8	37	\N	\N	\N	Arvidsjaur 3941 R3	2014-02-19 14:28:44.312+00
2716	\N	8	74	\N	\N	\N	Solberga Depressed feature	2014-02-19 14:28:44.312+00
2718	\N	8	37	\N	\N	\N	Soil chemistry p4	2014-02-19 14:28:44.312+00
2719	\N	8	74	\N	\N	\N	CTdo Vintrie IP A10855	2014-02-19 14:28:44.312+00
2720	\N	5	8	\N	\N	\N	Svarteborg 88	2014-02-19 14:28:44.312+00
2721	\N	6	8	\N	\N	\N	Forskningsparken Huddinge	2014-02-19 14:28:44.312+00
2722	\N	8	37	\N	\N	\N	Soil chemistry Herrestad	2014-02-19 14:28:44.312+00
2723	\N	8	33	\N	\N	\N	Vänge 88:1 Väsby V Soil chem	2014-02-19 14:28:44.312+00
2724	\N	8	33	\N	\N	\N	Arvidsjaur 3941 Strat R11	2014-02-19 14:28:44.312+00
2725	\N	8	74	\N	\N	\N	Stora Träskär	2014-02-19 14:28:44.312+00
2726	\N	8	33	\N	\N	\N	CTdo8 K2056	2014-02-19 14:28:44.312+00
2727	\N	8	33	\N	\N	\N	CTdo Hotelltomten Stratigraphy 2	2014-02-19 14:28:44.312+00
2728	\N	8	32	\N	\N	\N	Soil chemistry Torsby	2014-02-19 14:28:44.312+00
2729	\N	8	74	\N	\N	\N	CTdi Hotelltomten A3474 Strat	2014-02-19 14:28:44.312+00
2730	\N	8	32	\N	\N	\N	CTdo Hotelltomten Survey	2014-02-19 14:28:44.312+00
2731	\N	8	37	\N	\N	\N	Gåsinge-Dillnäs 94 Survey Vallen	2014-02-19 14:28:44.312+00
2732	\N	8	33	\N	\N	\N	Älvsbyn 958 Strat 1	2014-02-19 14:28:44.312+00
2733	\N	8	32	\N	\N	\N	CTdo7 Stratigraphy 619	2014-02-19 14:28:44.312+00
2734	\N	8	37	\N	\N	\N	Stora Träskär	2014-02-19 14:28:44.312+00
2735	\N	5	8	\N	\N	\N	Södra Hee	2014-02-19 14:28:44.312+00
2736	\N	5	8	\N	\N	\N	Sample group 1[Plants & pollen]	2014-02-19 14:28:44.312+00
2737	\N	8	37	\N	\N	\N	Svarteborg 593 Pits	2014-02-19 14:28:44.312+00
2738	\N	8	94	\N	\N	\N	CTdo8 K2056	2014-02-19 14:28:44.312+00
2739	\N	5	8	\N	\N	\N	Tanum 1209	2014-02-19 14:28:44.312+00
2740	\N	8	33	\N	\N	\N	CTdo6 Strat K274	2014-02-19 14:28:44.312+00
2741	\N	8	37	\N	\N	\N	CTdo Hotelltomten A3023 Strat	2014-02-19 14:28:44.312+00
2742	\N	8	33	\N	\N	\N	Älvsbyn 958 Strat 3	2014-02-19 14:28:44.312+00
2743	\N	8	32	\N	\N	\N	CTdo7 Stratigraphy 627	2014-02-19 14:28:44.312+00
2744	\N	8	74	\N	\N	\N	Mjölingsören 	2014-02-19 14:28:44.312+00
2745	2	8	37	\N	\N	\N	Marskärskobben Roller grinded samples	2014-02-19 14:28:44.312+00
2746	\N	8	37	\N	\N	\N	CTdo7 Stratigraphy 623	2014-02-19 14:28:44.312+00
2747	\N	5	8	\N	\N	\N	Tanum 539	2014-02-19 14:28:44.312+00
2748	\N	8	32	\N	\N	\N	Strängnäs 443 House 3	2014-02-19 14:28:44.312+00
2749	\N	8	33	\N	\N	\N	Norra Ryssmasterna Mortared samples	2014-02-19 14:28:44.312+00
2750	2	8	32	\N	\N	\N	Uppsala 499	2014-02-19 14:28:44.312+00
2751	\N	5	8	\N	\N	\N	Solberga Depressed feature	2014-02-19 14:28:44.312+00
2752	2	8	37	\N	\N	\N	Marskärskobben Mortared samples	2014-02-19 14:28:44.312+00
2753	\N	8	37	\N	\N	\N	CTdo Vintrie IP A10855	2014-02-19 14:28:44.312+00
2754	\N	8	33	\N	\N	\N	Arvidsjaur 3913 Strt R4	2014-02-19 14:28:44.312+00
2755	\N	8	37	\N	\N	\N	CTdo7 Stratigraphy 621	2014-02-19 14:28:44.312+00
2756	\N	8	74	\N	\N	\N	Soil chemistry Norum 291	2014-02-19 14:28:44.312+00
2757	2	8	74	\N	\N	\N	Fåröarna roller grinded samples	2014-02-19 14:28:44.312+00
2758	\N	8	32	\N	\N	\N	CTdo7 Stratigraphy 621	2014-02-19 14:28:44.312+00
2759	\N	8	37	\N	\N	\N	CTdo Hotelltomten Stratigraphy 5a	2014-02-19 14:28:44.312+00
2760	\N	8	37	\N	\N	\N	CTdo Hotelltomten Stratigraphy 3b	2014-02-19 14:28:44.312+00
2761	\N	8	32	\N	\N	\N	Soil chemistry Naverstad	2014-02-19 14:28:44.312+00
2762	\N	8	74	\N	\N	\N	CTdo7 Stratigraphy 619	2014-02-19 14:28:44.312+00
2763	\N	8	74	\N	\N	\N	Svarteborg 592	2014-02-19 14:28:44.312+00
2764	\N	8	32	\N	\N	\N	CTdo7 Stratigraphy 620	2014-02-19 14:28:44.312+00
2765	\N	8	32	\N	\N	\N	Soil chemistry Torsby	2014-02-19 14:28:44.312+00
2766	\N	8	37	\N	\N	\N	Citytunnelprojektet Hyllie 155 Strat 4	2014-02-19 14:28:44.312+00
2767	\N	8	33	\N	\N	\N	Soil chemistry Torsby	2014-02-19 14:28:44.312+00
2768	\N	8	33	\N	\N	\N	Svarteborg 593 House 2	2014-02-19 14:28:44.312+00
2769	\N	5	8	\N	\N	\N	Lillberget	2014-02-19 14:28:44.312+00
2770	\N	5	8	\N	\N	\N	Svarteborg 589	2014-02-19 14:28:44.312+00
2771	\N	5	8	\N	\N	\N	Arboga 65:1	2014-02-19 14:28:44.312+00
2772	\N	8	33	\N	\N	\N	Soil chemistry p1	2014-02-19 14:28:44.312+00
2773	\N	8	32	\N	\N	\N	Nederkalix 722 	2014-02-19 14:28:44.312+00
2774	\N	8	33	\N	\N	\N	Solberga Hearths	2014-02-19 14:28:44.312+00
2775	\N	8	37	\N	\N	\N	Soil chemistry p13	2014-02-19 14:28:44.312+00
2776	\N	8	37	\N	\N	\N	Soil chemistry Foss	2014-02-19 14:28:44.312+00
2777	\N	8	74	\N	\N	\N	CTdo Hotelltomten Survey	2014-02-19 14:28:44.312+00
2778	\N	8	37	\N	\N	\N	CTdo Hotelltomten Stratigraphy 2	2014-02-19 14:28:44.312+00
2779	\N	8	32	\N	\N	\N	Svarteborg 593 House 4	2014-02-19 14:28:44.312+00
2780	\N	8	32	\N	\N	\N	CTdo6 Strat K275	2014-02-19 14:28:44.312+00
2781	\N	8	74	\N	\N	\N	Strängnäs 443 Sunken hut floor	2014-02-19 14:28:44.312+00
2782	\N	8	32	\N	\N	\N	Soil chemistry macro	2014-02-19 14:28:44.312+00
2783	\N	5	8	\N	\N	\N	Kolbäck Raä 355 	2014-02-19 14:28:44.312+00
2784	\N	8	33	\N	\N	\N	Soil chemistry p5	2014-02-19 14:28:44.312+00
2785	\N	8	74	\N	\N	\N	Soil chemistry p8	2014-02-19 14:28:44.312+00
2786	\N	8	33	\N	\N	\N	Soil chemistry p2	2014-02-19 14:28:44.312+00
2787	\N	8	37	\N	\N	\N	Soil chemistry p8	2014-02-19 14:28:44.312+00
2788	\N	8	74	\N	\N	\N	Soil chemistry Features	2014-02-19 14:28:44.312+00
2789	\N	8	32	\N	\N	\N	Citytunnelprojektet Hyllie 155 Strat 7	2014-02-19 14:28:44.312+00
2790	\N	5	8	\N	\N	\N	Högom grav 2 In the long profile	2014-02-19 14:28:44.312+00
2791	\N	5	8	\N	\N	\N	Solberga hearths 	2014-02-19 14:28:44.312+00
2792	\N	8	74	\N	\N	\N	Svarteborg 593 Sample group 1	2014-02-19 14:28:44.312+00
2793	\N	5	8	\N	\N	\N	Trogsta hus F postholes	2014-02-19 14:28:44.312+00
2794	\N	5	8	\N	\N	\N	Nyköping 231 SG3	2014-02-19 14:28:44.312+00
2795	\N	5	8	\N	\N	\N	Njurunda 837 2011	2014-02-19 14:28:44.312+00
2796	\N	8	37	\N	\N	\N	CTdo Hotelltomten Stratigraphy 6b	2014-02-19 14:28:44.312+00
2797	\N	8	37	\N	\N	\N	Arvidsjaur 3941 Strat R2	2014-02-19 14:28:44.312+00
2798	\N	5	8	\N	\N	\N	Nyköpingshus	2014-02-19 14:28:44.312+00
2799	\N	8	37	\N	\N	\N	Nederkalix 722 	2014-02-19 14:28:44.312+00
2800	\N	8	37	\N	\N	\N	Arvidsjaur 3913 Strt R13	2014-02-19 14:28:44.312+00
2801	\N	6	8	\N	\N	\N	Odensala 6 Sample group 2	2014-02-19 14:28:44.312+00
2802	\N	8	32	\N	\N	\N	Vänge 88:1 Väsby Ö Soil chem	2014-02-19 14:28:44.312+00
2803	\N	8	37	\N	\N	\N	Norra Ryssmasterna Sample group 1	2014-02-19 14:28:44.312+00
2804	\N	8	37	\N	\N	\N	Arvidsjaur 3941 Strat R11	2014-02-19 14:28:44.312+00
2805	\N	5	8	\N	\N	\N	Nederluleå 330 Archaeobotany	2014-02-19 14:28:44.312+00
2806	\N	8	33	\N	\N	\N	Nederkalix 722 	2014-02-19 14:28:44.312+00
2807	\N	8	74	\N	\N	\N	Soil chemistry p11	2014-02-19 14:28:44.312+00
2808	\N	8	74	\N	\N	\N	Gåsinge Dillnäs 94 Survey Vallen 3	2014-02-19 14:28:44.312+00
2809	\N	9	8	\N	\N	\N	Österhaninge 72	2014-02-19 14:28:44.312+00
2810	\N	8	74	\N	\N	\N	CTdo Hotelltomten A3184 Strat	2014-02-19 14:28:44.312+00
2811	\N	8	37	\N	\N	\N	CTdo6 Strat K272	2014-02-19 14:28:44.312+00
2812	\N	8	32	\N	\N	\N	Soil chemistry p11	2014-02-19 14:28:44.312+00
2813	\N	8	37	\N	\N	\N	CTdo7 Stratigraphy 620	2014-02-19 14:28:44.312+00
2814	\N	6	8	\N	\N	\N	Njurunda 837 2011	2014-02-19 14:28:44.312+00
2815	\N	8	8	\N	\N	\N	Håby 4:1 	2014-02-19 14:28:44.312+00
2816	\N	8	35	\N	\N	\N	Nyköping 231 SG1	2014-02-19 14:28:44.312+00
2817	\N	8	36	\N	\N	\N	Töre 320 Elemen analysis	2014-02-19 14:28:44.312+00
2818	\N	8	32	\N	\N	\N	CTdo Hotelltomten A3312 Strat	2014-02-19 14:28:44.312+00
2819	\N	8	32	\N	\N	\N	CTdo Hotelltomten Stratigraphy 3b	2014-02-19 14:28:44.312+00
2820	\N	8	8	\N	\N	\N	Lohärad 167	2014-02-19 14:28:44.312+00
2821	\N	8	37	\N	\N	\N	CTdo Hotelltomten Stratigraphy 4	2014-02-19 14:28:44.312+00
2822	\N	8	74	\N	\N	\N	Vaksala Raä 300 Soil chemistry	2014-02-19 14:28:44.312+00
2823	\N	5	8	\N	\N	\N	Knivsta 16 Well	2014-02-19 14:28:44.312+00
2825	\N	5	8	\N	\N	\N	Bergskärit 	2014-02-19 14:28:44.312+00
2826	\N	8	33	\N	\N	\N	Lohärad 167	2014-02-19 14:28:44.312+00
2827	\N	8	37	\N	\N	\N	Soil chemistry p2	2014-02-19 14:28:44.312+00
2828	\N	8	32	\N	\N	\N	CTdo Hotelltomten Stratigraphy 6a	2014-02-19 14:28:44.312+00
2829	\N	8	37	\N	\N	\N	CTdo Hotelltomten A2052 Strat	2014-02-19 14:28:44.312+00
2830	\N	8	37	\N	\N	\N	Kall 599:3	2014-02-19 14:28:44.312+00
2831	\N	8	32	\N	\N	\N	Vänge 88:1 Väsby V Soil chem	2014-02-19 14:28:44.312+00
2832	\N	8	74	\N	\N	\N	CTdo7 Stratigraphy 628	2014-02-19 14:28:44.312+00
2833	\N	8	74	\N	\N	\N	CTdo7 Stratigraphy 465	2014-02-19 14:28:44.312+00
2834	\N	8	37	\N	\N	\N	Final excavation 2006	2014-02-19 14:28:44.312+00
2835	\N	8	37	\N	\N	\N	Arvidsjaur 3941 Strat R10	2014-02-19 14:28:44.312+00
2836	\N	8	37	\N	\N	\N	Norrala 	2014-02-19 14:28:44.312+00
2837	\N	5	8	\N	\N	\N	Dammen[Plants & pollen]	2014-02-19 14:28:44.312+00
2838	\N	5	37	\N	\N	\N	Nederluleå 330 Archaeobotany	2014-02-19 14:28:44.312+00
2839	\N	8	32	\N	\N	\N	Citytunnelprojektet Hyllie 155	2014-02-19 14:28:44.312+00
2840	\N	8	37	\N	\N	\N	Soil chemistry A300	2014-02-19 14:28:44.312+00
2841	\N	8	74	\N	\N	\N	Solberga Hearths	2014-02-19 14:28:44.312+00
2842	\N	8	37	\N	\N	\N	CTdo7 Stratigraphy 626	2014-02-19 14:28:44.312+00
2843	\N	8	37	\N	\N	\N	CTdo7 Stratigraphy 628	2014-02-19 14:28:44.312+00
2844	\N	8	32	\N	\N	\N	Soil chemistry p13	2014-02-19 14:28:44.312+00
2845	\N	8	37	\N	\N	\N	Svarteborg 593 Wells	2014-02-19 14:28:44.312+00
2846	\N	8	37	\N	\N	\N	CTdo7 Stratigraphy 463	2014-02-19 14:28:44.312+00
2847	\N	8	74	\N	\N	\N	Nederluleå 330 unit 8 strat E prof	2014-02-19 14:28:44.312+00
2848	\N	8	33	\N	\N	\N	Arvidsjaur 3913 Strt R20	2014-02-19 14:28:44.312+00
2849	\N	8	33	\N	\N	\N	Älvsbyn 958 strat 2	2014-02-19 14:28:44.312+00
2850	\N	8	74	\N	\N	\N	Soil chemistry Norum 5	2014-02-19 14:28:44.312+00
2851	\N	8	33	\N	\N	\N	Solberga Depressed feature	2014-02-19 14:28:44.312+00
2852	\N	8	33	\N	\N	\N	Arvidsjaur 3913 Strat R1	2014-02-19 14:28:44.312+00
2853	\N	8	33	\N	\N	\N	Arvidsjaur 3913 Strat R10	2014-02-19 14:28:44.312+00
2854	\N	8	37	\N	\N	\N	Arvidsjaur 3941	2014-02-19 14:28:44.312+00
2855	\N	8	32	\N	\N	\N	Stora Halmören	2014-02-19 14:28:44.312+00
2856	\N	8	33	\N	\N	\N	Nicksörarna Morated	2014-02-19 14:28:44.312+00
2857	\N	8	74	\N	\N	\N	Soil chemistry Tanum 59	2014-02-19 14:28:44.312+00
2858	\N	8	74	\N	\N	\N	CTdo8 K2056	2014-02-19 14:28:44.312+00
2859	\N	8	33	\N	\N	\N	Soil chemistry Norum 291	2014-02-19 14:28:44.312+00
2860	\N	8	74	\N	\N	\N	Soil chemistry p10	2014-02-19 14:28:44.312+00
2861	2	8	37	\N	\N	\N	Uppsala 499	2014-02-19 14:28:44.312+00
2862	\N	8	37	\N	\N	\N	Lockarp 8:4 Well Kubiena 2	2014-02-19 14:28:44.312+00
2863	\N	5	8	\N	\N	\N	Fresta 87:3	2014-02-19 14:28:44.312+00
2864	\N	8	109	\N	\N	\N	Åkroken	2014-02-19 14:28:44.312+00
2865	\N	8	37	\N	\N	\N	Soil chemistry p1	2014-02-19 14:28:44.312+00
2866	\N	8	74	\N	\N	\N	Norra Ryssmasterna Sample group 1	2014-02-19 14:28:44.312+00
2867	\N	8	37	\N	\N	\N	Lövleforsen	2014-02-19 14:28:44.312+00
2868	\N	8	32	\N	\N	\N	CTdo7 Stratigraphy 460	2014-02-19 14:28:44.312+00
2869	\N	8	32	\N	\N	\N	Norra Ryssmasterna Mortared samples	2014-02-19 14:28:44.312+00
2870	\N	8	74	\N	\N	\N	Ägglösen	2014-02-19 14:28:44.312+00
2871	\N	8	32	\N	\N	\N	Vaksala Raä 300 Soil chemistry	2014-02-19 14:28:44.312+00
2872	\N	8	74	\N	\N	\N	Soil chemistry p1	2014-02-19 14:28:44.312+00
2873	\N	5	8	\N	\N	\N	Tillinge 314 House 1	2014-02-19 14:28:44.312+00
2874	\N	8	74	\N	\N	\N	CTdo7 A277b Stratigraphy	2014-02-19 14:28:44.312+00
2875	\N	8	74	\N	\N	\N	Nicksörarna Morated	2014-02-19 14:28:44.312+00
2876	\N	8	33	\N	\N	\N	Arvidsjaur 3941	2014-02-19 14:28:44.312+00
2877	\N	5	8	\N	\N	\N	Odensala 402 House 101	2014-02-19 14:28:44.312+00
2878	\N	8	33	\N	\N	\N	Svarteborg 593 House 4	2014-02-19 14:28:44.312+00
2879	\N	8	37	\N	\N	\N	Soil chemistry p11	2014-02-19 14:28:44.312+00
2880	\N	8	74	\N	\N	\N	Soil chemistry Naverstad	2014-02-19 14:28:44.312+00
2881	\N	8	33	\N	\N	\N	Strängnäs 443 Hearths	2014-02-19 14:28:44.312+00
2882	\N	8	37	\N	\N	\N	CTdo7 Stratigraphy 619	2014-02-19 14:28:44.312+00
2883	\N	5	8	\N	\N	\N	Öredalen Byre	2014-02-19 14:28:44.312+00
2884	\N	8	37	\N	\N	\N	Svarteborg 88	2014-02-19 14:28:44.312+00
2885	2	8	33	\N	\N	\N	Fåröarna Mortared samples	2014-02-19 14:28:44.312+00
2886	\N	8	74	\N	\N	\N	CTdo7 Stratigraphy 460	2014-02-19 14:28:44.312+00
2887	\N	8	74	\N	\N	\N	Strängnäs 443 House 3	2014-02-19 14:28:44.312+00
2888	\N	8	32	\N	\N	\N	CTdo8 K2056	2014-02-19 14:28:44.312+00
2889	\N	8	37	\N	\N	\N	Nyköpingshus	2014-02-19 14:28:44.312+00
2890	\N	8	37	\N	\N	\N	Arvidsjaur 3913 Strt R11	2014-02-19 14:28:44.312+00
2891	\N	8	32	\N	\N	\N	CTdo7 Stratigraphy 625	2014-02-19 14:28:44.312+00
2892	\N	8	32	\N	\N	\N	Norra Småholmen Mortared	2014-02-19 14:28:44.312+00
2893	\N	8	32	\N	\N	\N	Nyköping 231 SG1	2014-02-19 14:28:44.312+00
2894	\N	8	74	\N	\N	\N	CTdo Hotelltomten A2052 Strat	2014-02-19 14:28:44.312+00
2895	\N	8	37	\N	\N	\N	Arvidsjaur 3913 Strt R12	2014-02-19 14:28:44.312+00
2896	\N	6	8	\N	\N	\N	Gammelstad, Luleå 	2014-02-19 14:28:44.312+00
2897	\N	8	74	\N	\N	\N	CTdo Hotelltomten Stratigraphy 5a	2014-02-19 14:28:44.312+00
2898	\N	8	33	\N	\N	\N	Arvidsjaur 3913 Strt R11	2014-02-19 14:28:44.312+00
2899	\N	8	33	\N	\N	\N	Strängnäs 443 House 2	2014-02-19 14:28:44.312+00
2900	\N	8	37	\N	\N	\N	Soil chemistry Tossene	2014-02-19 14:28:44.312+00
2901	\N	8	74	\N	\N	\N	Strängnäs 443 House 2	2014-02-19 14:28:44.312+00
2902	\N	5	8	\N	\N	\N	Torslanda 108 macro	2014-02-19 14:28:44.312+00
2903	\N	8	37	\N	\N	\N	Älvsbyn 958 Strat 1	2014-02-19 14:28:44.312+00
2904	\N	5	8	\N	\N	\N	Tyndeö 27	2014-02-19 14:28:44.312+00
2905	\N	8	74	\N	\N	\N	Soil chemistry Torsby	2014-02-19 14:28:44.312+00
2906	\N	8	32	\N	\N	\N	Soil chemistry p4	2014-02-19 14:28:44.312+00
2907	\N	8	32	\N	\N	\N	Gåsinge-Dillnäs 94 Täby boplatsläge	2014-02-19 14:28:44.312+00
2908	\N	8	32	\N	\N	\N	Soil chemistry p1	2014-02-19 14:28:44.312+00
2909	\N	8	32	\N	\N	\N	Soil chemistry p10	2014-02-19 14:28:44.312+00
2910	\N	8	37	\N	\N	\N	Soil chemistry Naverstad	2014-02-19 14:28:44.312+00
2911	\N	5	8	\N	\N	\N	Västerhaninge 479 Sample group 1	2014-02-19 14:28:44.312+00
2912	\N	5	8	\N	\N	\N	Strängnäs 443 House 2 makro	2014-02-19 14:28:44.312+00
2913	\N	8	32	\N	\N	\N	Bergskärit 	2014-02-19 14:28:44.312+00
2914	\N	8	37	\N	\N	\N	Gåsinge Dillnäs 94 Survey Vallen forts	2014-02-19 14:28:44.312+00
2915	\N	8	33	\N	\N	\N	Soil chemistry Tanum 59	2014-02-19 14:28:44.312+00
2916	\N	8	74	\N	\N	\N	Lohärad 167	2014-02-19 14:28:44.312+00
2918	\N	8	33	\N	\N	\N	Strängnäs 443 House 3	2014-02-19 14:28:44.312+00
2919	\N	8	32	\N	\N	\N	Soil chemistry Tossene	2014-02-19 14:28:44.312+00
2920	\N	8	37	\N	\N	\N	Arvidsjaur 3941 Strat R20	2014-02-19 14:28:44.312+00
2921	\N	8	74	\N	\N	\N	Nederluleå 330 Unit 10b east profile	2014-02-19 14:28:44.312+00
2922	\N	6	8	\N	\N	\N	Solberga Building	2014-02-19 14:28:44.312+00
2923	\N	8	33	\N	\N	\N	Arvidsjaur 3941 Strat R2	2014-02-19 14:28:44.312+00
2924	\N	8	32	\N	\N	\N	Soil chemistry p5	2014-02-19 14:28:44.312+00
2925	\N	5	8	\N	\N	\N	Vänge 88:1 Väsby Ö	2014-02-19 14:28:44.312+00
2926	\N	8	37	\N	\N	\N	Nicksörarna Morated	2014-02-19 14:28:44.312+00
2927	\N	8	74	\N	\N	\N	CTdo Hotelltomten Stratigraphy 6b	2014-02-19 14:28:44.312+00
2928	2	8	74	\N	\N	\N	Mjölingsören	2014-02-19 14:28:44.312+00
2929	\N	8	74	\N	\N	\N	CTdo Hotelltomten Stratigraphy 3b	2014-02-19 14:28:44.312+00
2930	\N	8	37	\N	\N	\N	Arvidsjaur 3941 Strat R1	2014-02-19 14:28:44.312+00
2931	\N	8	37	\N	\N	\N	Soil chemistry p16	2014-02-19 14:28:44.312+00
2932	\N	8	32	\N	\N	\N	Solberga Depressed feature	2014-02-19 14:28:44.312+00
2933	\N	8	32	\N	\N	\N	Soil chemistry Features	2014-02-19 14:28:44.312+00
2934	\N	8	33	\N	\N	\N	Soil chemistry macro	2014-02-19 14:28:44.312+00
2935	\N	5	8	\N	\N	\N	Medåker Raä 176	2014-02-19 14:28:44.312+00
2936	\N	8	74	\N	\N	\N	Soil chemistry Tossene	2014-02-19 14:28:44.312+00
2937	\N	8	37	\N	\N	\N	Arvidsjaur 3913 Strt R20	2014-02-19 14:28:44.312+00
2938	\N	8	74	\N	\N	\N	Svarteborg 593 Wells	2014-02-19 14:28:44.312+00
2939	\N	8	37	\N	\N	\N	CTdoHotelltomten Stratigraphy 1	2014-02-19 14:28:44.312+00
2940	\N	8	37	\N	\N	\N	Töre random samples	2014-02-19 14:28:44.312+00
2941	\N	8	37	\N	\N	\N	Nederluleå 330 unit 8 strat E prof	2014-02-19 14:28:44.312+00
2942	\N	5	8	\N	\N	\N	Skederid 190 Structure 3	2014-02-19 14:28:44.312+00
2943	\N	8	37	\N	\N	\N	Töre 422	2014-02-19 14:28:44.312+00
2944	\N	8	32	\N	\N	\N	Strängnäs 443 House 2	2014-02-19 14:28:44.312+00
2945	\N	8	32	\N	\N	\N	Vilhelmina 1647	2014-02-19 14:28:44.312+00
2946	\N	10	8	\N	\N	\N	Örtedalen Byre 	2014-02-19 14:28:44.312+00
2947	\N	8	37	\N	\N	\N	Citytunnelprojektet Hyllie 155 Strat 6	2014-02-19 14:28:44.312+00
2948	\N	8	37	\N	\N	\N	Soil chemistry Torsby	2014-02-19 14:28:44.312+00
2949	\N	8	107	\N	\N	\N	CTdo8 K2056	2014-02-19 14:28:44.312+00
2950	2	8	74	\N	\N	\N	Marskärskobben Mortared samples	2014-02-19 14:28:44.312+00
2951	\N	5	8	\N	\N	\N	Tanum 546	2014-02-19 14:28:44.312+00
2952	\N	8	32	\N	\N	\N	Soil chemistry p8	2014-02-19 14:28:44.312+00
2953	\N	8	74	\N	\N	\N	Svarteborg 585	2014-02-19 14:28:44.312+00
2954	\N	8	32	\N	\N	\N	Töre 408 AC	2014-02-19 14:28:44.312+00
2955	\N	8	37	\N	\N	\N	Torö 75 	2014-02-19 14:28:44.312+00
2956	\N	8	32	\N	\N	\N	Strängnäs 443 Hearths	2014-02-19 14:28:44.312+00
2957	\N	8	32	\N	\N	\N	Norra Ryssmasterna Sample group 1	2014-02-19 14:28:44.312+00
2958	\N	8	74	\N	\N	\N	Soil chemistry macro	2014-02-19 14:28:44.312+00
2959	\N	5	74	\N	\N	\N	Nederluleå 330 Archaeobotany	2014-02-19 14:28:44.312+00
2960	\N	8	37	\N	\N	\N	Citytunnelprojektet Hyllie 155 Strat 5	2014-02-19 14:28:44.312+00
2961	\N	8	74	\N	\N	\N	CTdo7 Stratigraphy 626	2014-02-19 14:28:44.312+00
2962	\N	8	74	\N	\N	\N	Kall 599:3	2014-02-19 14:28:44.312+00
2963	\N	6	8	\N	\N	\N	Råneå 414	2014-02-19 14:28:44.312+00
2964	\N	6	8	\N	\N	\N	Tuna 328:1 Sample group 1	2014-02-19 14:28:44.312+00
2965	\N	8	32	\N	\N	\N	CTdo6 Stratigraphy K268	2014-02-19 14:28:44.312+00
2966	\N	5	8	\N	\N	\N	Features[Plants & pollen]	2014-02-19 14:28:44.312+00
2967	\N	6	8	\N	\N	\N	Tåme	2014-02-19 14:28:44.312+00
2968	\N	8	37	\N	\N	\N	Soil chemistry p10	2014-02-19 14:28:44.312+00
2969	\N	8	32	\N	\N	\N	Lövleforsen	2014-02-19 14:28:44.312+00
2970	\N	8	32	\N	\N	\N	Soil chemistry Torsby	2014-02-19 14:28:44.312+00
2971	\N	8	74	\N	\N	\N	Strängnäs 443 Hearths	2014-02-19 14:28:44.312+00
2972	\N	5	8	\N	\N	\N	Lövleforsen	2014-02-19 14:28:44.312+00
2973	\N	8	37	\N	\N	\N	Soil chemistry Foss 166	2014-02-19 14:28:44.312+00
2974	\N	5	8	\N	\N	\N	Odlaren 1:1	2014-02-19 14:28:44.312+00
2975	\N	8	37	\N	\N	\N	Soil chemistry p15	2014-02-19 14:28:44.312+00
2976	\N	8	74	\N	\N	\N	Final excavation 2006	2014-02-19 14:28:44.312+00
2977	\N	8	37	\N	\N	\N	Borgsjö 165	2014-02-19 14:28:44.312+00
2978	\N	8	35	\N	\N	\N	Töre 320 Elemen analysis	2014-02-19 14:28:44.312+00
2979	\N	5	8	\N	\N	\N	Vänge 88:1 Väsby V	2014-02-19 14:28:44.312+00
2980	\N	8	33	\N	\N	\N	Arvidsjaur 3913 Strt R12	2014-02-19 14:28:44.312+00
2981	\N	8	74	\N	\N	\N	Gåsinge-Dillnäs Raä 94. Ullevi Hästhagen	2014-02-19 14:28:44.312+00
2982	\N	8	37	\N	\N	\N	Soil chemistry Norum 291	2014-02-19 14:28:44.312+00
2983	\N	5	8	\N	\N	\N	Skön 164	2014-02-19 14:28:44.312+00
2984	\N	8	32	\N	\N	\N	Svarteborg 593 Wells	2014-02-19 14:28:44.312+00
2985	\N	8	32	\N	\N	\N	Ägglösen	2014-02-19 14:28:44.312+00
2986	\N	8	32	\N	\N	\N	Nicksörarna Morated	2014-02-19 14:28:44.312+00
2987	\N	8	37	\N	\N	\N	Strängnäs 443 Sunken hut floor	2014-02-19 14:28:44.312+00
2988	\N	8	74	\N	\N	\N	Soil chemistry Herrestad	2014-02-19 14:28:44.312+00
2989	\N	5	8	\N	\N	\N	Morlanda 367	2014-02-19 14:28:44.312+00
2990	\N	8	33	\N	\N	\N	Arvidsjaur 3941 Strat R1	2014-02-19 14:28:44.312+00
2991	\N	8	32	\N	\N	\N	Soil chemistry A300	2014-02-19 14:28:44.312+00
2992	\N	5	8	\N	\N	\N	Österhaninge 239	2014-02-19 14:28:44.312+00
2993	\N	6	8	\N	\N	\N	Svarteborg 589	2014-02-19 14:28:44.312+00
2994	\N	8	32	\N	\N	\N	Soil chemistry p15	2014-02-19 14:28:44.312+00
2995	\N	8	37	\N	\N	\N	Norra Småholmen Mortared	2014-02-19 14:28:44.312+00
2996	\N	8	74	\N	\N	\N	Soil chemistry p16	2014-02-19 14:28:44.312+00
2997	\N	8	37	\N	\N	\N	Gåsinge-Dillnäs Raä 94. Ullevi Hästhagen	2014-02-19 14:28:44.312+00
2998	\N	8	37	\N	\N	\N	Soil chemistry Torsby	2014-02-19 14:28:44.312+00
2999	\N	8	37	\N	\N	\N	Arvidsjaur 3913 Strat R10	2014-02-19 14:28:44.312+00
3000	\N	5	8	\N	\N	\N	Skederid 190 Structure 2	2014-02-19 14:28:44.312+00
3001	\N	8	37	\N	\N	\N	Ägglösen	2014-02-19 14:28:44.312+00
3002	\N	8	37	\N	\N	\N	Soil chemistry Norum 5	2014-02-19 14:28:44.312+00
3003	\N	8	33	\N	\N	\N	Arvidsjaur 3941 Strat R20	2014-02-19 14:28:44.312+00
3004	\N	6	8	\N	\N	\N	Skederid 190 Structure 4	2014-02-19 14:28:44.312+00
3005	\N	5	8	\N	\N	\N	Strängnäs 443 hearths	2014-02-19 14:28:44.312+00
3006	\N	5	8	\N	\N	\N	Snarsmon[Plants & pollen]	2014-02-19 14:28:44.312+00
3007	\N	8	37	\N	\N	\N	Norra Ryssmasterna Mortared samples	2014-02-19 14:28:44.312+00
3008	\N	6	8	\N	\N	\N	Norum 291	2014-02-19 14:28:44.312+00
3009	2	8	32	\N	\N	\N	Marskärskobben Mortared samples	2014-02-19 14:28:44.312+00
3010	\N	8	33	\N	\N	\N	Soil chemistry Norum 5	2014-02-19 14:28:44.312+00
3011	\N	8	37	\N	\N	\N	Soil chemistry Tanum 59	2014-02-19 14:28:44.312+00
3012	\N	6	8	\N	\N	\N	Övertorneå 427	2014-02-19 14:28:44.312+00
3013	\N	8	33	\N	\N	\N	Norra Ryssmasterna Sample group 1	2014-02-19 14:28:44.312+00
3014	\N	8	32	\N	\N	\N	Borgsjö 165	2014-02-19 14:28:44.312+00
3015	\N	8	37	\N	\N	\N	Soil chemistry macro	2014-02-19 14:28:44.312+00
3016	\N	8	32	\N	\N	\N	Mjölingsören 	2014-02-19 14:28:44.312+00
3017	\N	8	32	\N	\N	\N	Lohärad 167	2014-02-19 14:28:44.312+00
3018	\N	8	32	\N	\N	\N	Ägglösen	2014-02-19 14:28:44.312+00
3019	\N	8	37	\N	\N	\N	Strängnäs 443 Hearths	2014-02-19 14:28:44.312+00
3020	\N	8	37	\N	\N	\N	Lohärad 167	2014-02-19 14:28:44.312+00
3021	\N	8	74	\N	\N	\N	Norra Småholmen Mortared	2014-02-19 14:28:44.312+00
3022	\N	8	36	\N	\N	\N	Töre random samples	2014-02-19 14:28:44.312+00
3023	\N	8	37	\N	\N	\N	Solberga Depressed feature	2014-02-19 14:28:44.312+00
