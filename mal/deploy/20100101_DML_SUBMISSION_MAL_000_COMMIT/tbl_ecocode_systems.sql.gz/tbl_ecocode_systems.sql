1	\N	2014-01-15 10:05:29.5582+00	General pollen grouping system used at the Environmental Archaeology Lab, Umeå (MAL). A combination of natural, taxonomic and anthropocentric classes used to facilitate rapid overview of changes in Scandinavian pollen taxa.	MAL General Pollen Scandinavia	System developed and used by Jan-Erik Wallin at Pollenlaboratoriet i Umeå AB <pollenlaboratoriet@ume.se> for Scandinavian pollen analyses.
2	\N	2014-04-17 05:56:03.101+00	\N	Bugs Ecocodes	\N
3	\N	2014-04-17 05:56:03.101+00	\N	Koch Ecology Codes	\N
