1	2012-12-19 14:42:33.136344+00	Chief characteristics and result: Biological activity, organic matter accumulation, weathering sometimes with mineral accumulation or loss	A	100
3	2012-12-19 14:45:56.119075+00	Chief characteristics and result: Weathered, poorly to unconsolidated parent material (sometimes with minor losses and additions).	C	100
4	2012-12-19 14:46:57.74186+00	Chief characteristics and result: Unweathered hard bedrock.	R	100
2	2012-12-19 14:44:04.888955+00	Chief characteristics and result: Often breakdown of primary minerals and formation of new ones; biological mixing; vertical additions from other horizons and/or losses to other horizon; vertical or lateral additions or subtractions by groundwater or throughflow.	B	100
5	2012-12-19 14:54:38.725615+00	Chief characteristics and result: Leaching and translocation of clay/humus/sesquioxides	A2	100
6	2012-12-19 14:54:55.981639+00	Chief characteristics and result: Clay enrichment	Bt	100
7	2012-12-19 14:55:15.453319+00	Chief characteristics and result: Humus enrichment	Bh	100
8	2012-12-19 14:56:42.083956+00	Chief characteristics and result: Sesquioxide enrichment	Bs	100
10	2012-12-20 07:16:12.764782+00	(http://www.fao.org) O horizons or layers: Layers dominated by organic material, consisting of undecomposed or partially decomposed litter, such as leaves, needles, twigs, moss, and lichens, which has accumulated on the surface; they may be on top of either mineral or organic soils. O horizons are not saturated with water for prolonged periods. The mineral fraction of such material is only a small percentage of the volume of the material and generally is much less than half of the weight.\r\nAn O layer may be at the surface of a mineral soil or at any depth beneath the surface if it is buried. An horizon formed by illuviation of organic material into a mineral subsoil is not an O horizon, though some horizons formed in this manner contain much organic matter.	O	98
9	2012-12-20 07:15:17.069918+00	(http://www.fao.org) Layers dominated by organic material, formed from accumulations of undecomposed or partially decomposed organic material at the soil surface which may be underwater. All H horizons are saturated with water for prolonged periods or were once saturated but are now artificially drained. An H horizon may be on top of mineral soils or at any depth beneath the surface if it is buried (http://www.fao.org).	H	98
11	2012-12-20 07:18:53.434794+00	(http://www.fao.org) A horizons: Mineral horizons which formed at the surface or below an O horizon, in which all or much of the original rock structure has been obliterated and which are characterized by one or more of the following:\r\n    - an accumulation of humified organic matter intimately mixed with the mineral fraction and not displaying properties characteristic of E or B horizons (see below);\r\n    - properties resulting from cultivation, pasturing, or similar kinds of disturbance; or\r\n    - a morphology which is different from the underlying B or C horizon, resulting from processes related to the surface.	A	98
13	2012-12-20 07:19:14.921461+00	(http://www.fao.org) E horizons: Mineral horizons in which the main feature is loss of silicate clay, iron, aluminum, or some combination of these, leaving a concentration of sand and silt particles, and in which all or much of the original rock structure has been obliterated.	E	98
14	2012-12-20 07:23:52.678051+00	(http://www.fao.org) B horizons: Horizons that formed below an A, E, O or H horizon, and in which the dominant features are the obliteration of all or much of the original rock structure, together with one or a combination of the following:\r\n    - illuvial concentration, alone or in combination, of silicate clay, iron, aluminum, humus, carbonates, gypsum or silica;\r\n    - evidence of removal of carbonates;\r\n    - residual concentration of sesquioxides;\r\n    - coatings of sesquioxides that make the horizon conspicuously lower in value, higher in chrome, or redder in hue than overlying and underlying horizons without apparent illuviation of iron;\r\n    - alteration that forms silicate clay or liberates oxides or both and that forms a granular, blocky, or prismatic structure if volume changes accompany changes in moisture content; or\r\n    - brittleness.	B	98
15	2012-12-20 07:25:06.228129+00	(http://www.fao.org) C horizons or layers: Horizons or layers, excluding hard bedrock, that are little affected by pedogenetic processes and lack properties of H. O. A, E, or B horizons. Most are mineral layers, but some siliceous and calcareous layers such as shells, coral and diatomaceous earth, are included. The material of C layers may be either like or unlike that from which the solum presumably formed. A C horizon may have been modified even if there is no evidence of pedogenesis. Plant roots can penetrate C horizons, which provide an important growing medium.	C	98
16	2012-12-20 07:25:30.283265+00	(http://www.fao.org) R layers: Hard bedrock underlying the soil.	R	98
17	2013-05-13 09:29:56.070308+00	plowed	Ap	104
18	2013-05-13 09:29:56.070308+00	B\t	B 	104
19	2013-05-13 09:29:56.070308+00	plowed, fossil	Apf	104
20	2013-05-13 09:29:56.070308+00	Bh	Bh 	104
21	2013-05-13 09:29:56.070308+00	\N	Ap/C	104
22	2013-05-13 09:29:56.070308+00	\N	A 	104
23	2013-05-13 09:29:56.070308+00	\N	A2f	104
24	2013-05-13 09:29:56.070308+00	\N	B2	104
25	2013-05-13 09:29:56.070308+00	\N	Ap/A2	104
26	2013-05-13 09:29:56.070308+00	\N	A2 	104
27	2013-05-13 09:29:56.070308+00	\N	A1/A2	104
28	2013-05-13 09:29:56.070308+00	\N	C 	104
29	2013-05-13 09:29:56.070308+00	\N	Ap/B	104
30	2013-05-13 09:29:56.070308+00	\N	B/C	104
31	2013-05-13 09:29:56.070308+00	\N	Subsoil	101
34	2013-05-16 08:39:58.584644+00	\N	lager 3	104
35	2013-05-16 08:39:58.584644+00	\N	lager 3 a	104
36	2013-11-13 14:33:32.218+00	\N	Ah	104
37	2013-11-13 14:33:32.218+00	\N	A2/B	104
38	2013-11-13 14:33:32.218+00	\N	A/C	104
39	2013-11-13 14:33:32.218+00	\N	A/B	104
40	2013-11-13 14:33:32.218+00	\N	Bb	104
41	2013-11-13 14:33:32.218+00	\N	Ah/B	104
42	2013-11-13 14:33:32.218+00	\N	B1	104
43	2013-11-13 14:33:32.218+00	\N	Ahb	104
44	2013-11-13 14:33:32.218+00	\N	R 	104
45	2013-11-13 14:33:32.218+00	\N	Apk	104
46	2013-11-13 14:33:32.218+00	\N	Topsoil	101
47	2013-11-13 14:33:32.218+00	\N	A2b	104
48	2013-11-13 14:33:32.218+00	\N	Topsoil	101
49	2013-11-13 14:33:32.218+00	\N	A2h 	104
50	2013-11-13 14:33:32.218+00	\N	A2h/B	104
51	2013-11-13 14:33:32.218+00	\N	Hg	104
52	2013-11-13 14:33:32.218+00	\N	Topsoil	101
53	2013-11-13 14:33:32.218+00	\N	A0 	104
54	2013-11-13 14:33:32.218+00	\N	Topsoil	101
55	2013-11-13 14:33:32.218+00	\N	Apr	104
56	2013-11-13 14:33:32.218+00	\N	Topsoil	101
57	2013-11-13 14:33:32.218+00	\N	Topsoil	101
58	2013-11-13 14:33:32.218+00	\N	Bg	104
59	2013-11-13 14:33:32.218+00	\N	A2/B1	104
60	2013-11-13 14:33:32.218+00	\N	Topsoil	101
61	2013-11-13 14:33:32.218+00	\N	Topsoil	101
62	2013-11-13 14:33:32.218+00	\N	Topsoil	101
63	2013-11-13 14:33:32.218+00	\N	Bkf	104
64	2013-11-13 14:33:32.218+00	\N	Bg	104
65	2013-11-13 14:33:32.218+00	\N	Topsoil	101
66	2013-11-13 14:33:32.218+00	\N	Topsoil	101
67	2013-11-13 14:33:32.218+00	\N	Topsoil	101
68	2013-11-13 14:33:32.218+00	\N	Bg	104
69	2013-11-13 14:33:32.218+00	\N	Br	104
70	2013-11-13 14:33:32.218+00	\N	Topsoil	101
71	2013-11-13 14:33:32.218+00	\N	Topsoil	101
72	2013-11-13 14:33:32.218+00	\N	Hg	104
73	2013-11-13 14:33:32.218+00	\N	Ah/C	104
74	2013-11-13 14:33:32.218+00	\N	Bk	104
75	2013-11-13 14:33:32.218+00	\N	Topsoil	101
76	2013-11-13 14:33:32.218+00	\N	Topsoil	101
77	2013-11-13 14:33:32.218+00	\N	C1	104
78	2013-11-13 14:33:32.218+00	\N	Topsoil	101
79	2013-11-13 14:33:32.218+00	\N	Bg	104
80	2013-11-13 14:33:32.218+00	\N	A2/Ah	104
81	2013-11-13 14:33:32.218+00	\N	Topsoil	101
82	2013-11-13 14:33:32.218+00	\N	A1 	104
83	2013-11-13 14:33:32.218+00	\N	Topsoil	101
84	2013-11-13 14:33:32.218+00	\N	Topsoil	101
85	2013-11-13 14:33:32.218+00	\N	Bg	104
86	2013-11-13 14:33:32.218+00	\N	Ah/B3	104
87	2013-11-13 14:33:32.218+00	\N	Br	104
88	2013-11-13 14:33:32.218+00	\N	Topsoil	101
89	2013-11-13 14:33:32.218+00	\N	Topsoil	101
90	2013-11-13 14:33:32.218+00	\N	Topsoil	101
91	2013-11-13 14:33:32.218+00	\N	Topsoil	101
92	2013-11-13 14:33:32.218+00	\N	Topsoil	101
93	2013-11-13 14:33:32.218+00	\N	Bf	104
94	2013-11-13 14:33:32.218+00	\N	Topsoil	101
95	2013-11-13 14:33:32.218+00	\N	Bg	104
96	2013-11-13 14:33:32.218+00	\N	Topsoil	101
97	2013-11-13 14:33:32.218+00	\N	Topsoil	101
98	2013-11-13 14:33:32.218+00	\N	Topsoil	101
99	2013-11-13 14:33:32.218+00	\N	Topsoil	101
100	2013-11-13 14:33:32.218+00	\N	Bhg	104
101	2013-11-13 14:33:32.218+00	\N	Topsoil	101
102	2013-11-13 14:33:32.218+00	\N	Topsoil	101
103	2013-11-13 14:33:32.218+00	\N	Topsoil	101
104	2013-11-13 14:33:32.218+00	\N	A2/C	104
105	2013-11-13 14:33:32.218+00	\N	Topsoil	101
106	2013-11-13 14:33:32.218+00	\N	Topsoil	101
107	2013-11-13 14:33:32.218+00	\N	Topsoil	101
108	2013-11-13 14:33:32.218+00	\N	Topsoil	101
109	2013-11-13 14:33:32.218+00	\N	Topsoil	101
110	2013-11-13 14:33:32.218+00	\N	Topsoil	101
111	2014-02-19 14:28:44.312+00	\N	Br	104
112	2014-02-19 14:28:44.312+00	\N	Ah	104
113	2014-02-19 14:28:44.312+00	\N	Apr	104
114	2014-02-19 14:28:44.312+00	\N	A/C	104
115	2014-02-19 14:28:44.312+00	\N	B?	104
116	2014-02-19 14:28:44.312+00	\N	lager 3	104
117	2014-02-19 14:28:44.312+00	\N	Ahp	104
118	2014-02-19 14:28:44.312+00	\N	Apr	104
119	2014-02-19 14:28:44.312+00	\N	Ap2	104
120	2014-02-19 14:28:44.312+00	\N	Apr	104
121	2014-02-19 14:28:44.312+00	\N	Apr	104
122	2014-02-19 14:28:44.312+00	\N	Layer 7	101
123	2014-02-19 14:28:44.312+00	\N	Apr	104
124	2014-02-19 14:28:44.312+00	\N	lager 3 a	104
125	2014-02-19 14:28:44.312+00	\N	Transition to C	104
