5	2012-09-21 16:51:47.967181+00	v	Sample volume	Volume	3	14
6	2012-09-21 16:51:47.967181+00	d	Diameter of core	Core diameter	1	14
4	2012-09-21 16:51:47.967181+00	h	Height of sample	Height	1	14
1	2012-09-21 16:51:47.967181+00	w	Sample weight	Weight	2	14
19	2012-09-21 16:51:47.967181+00	\N	Positive values denote depth of upper sample/unit/core etc boundary from ground or water surface in metres.	Positive boundary depth from surface upper	1	14
7	2012-09-21 16:51:47.967181+00	X/N	X coordinate or Northing in metres. Negative values are south of the origin (zero coordinate).	X/North	1	17
9	2012-09-21 16:51:47.967181+00	X/N	X coordinate or Northing in intrinsic units. Negative values are south of the origin (zero coordinate).	X/North	5	17
10	2012-09-21 16:51:47.967181+00	X/E	X coordinate or Easting in metres. Negative values are west of the meridian or origin (the origin (0/0)).	X/East	1	17
11	2012-09-21 16:51:47.967181+00	X/E	X coordinate or Easting in intrinsic units. Negative values are west of the meridian or origin (zero coordinate).	X/East	5	17
16	2012-09-21 16:51:47.967181+00	Y/N	Y coordinate or Northing in decimal degrees. Negative values are west of the meridian or origin (zero coordinate).	Y/North	4	17
25	2012-09-21 16:51:47.967181+00	\N	Positive values denote depth of lower sample/unit/core etc boundary from reference line (e.g. profile line, core top), reference point or datum, in metres.	Lower boundary depth (positive) from reference	1	14
26	2012-09-21 16:51:47.967181+00	\N	Negative values denote depth of lower sample/unit/core etc boundary from reference line (e.g. profile line, core top), reference point or datum, in metres.	Lower boundary depth (negative) from reference	1	14
27	2012-09-21 16:51:47.967181+00	\N	Depth of upper sample boundary from unknown or unspecified reference level	Upper boundary depth from unknown reference	1	14
2	2012-09-21 16:51:47.967181+00	\N	Depth of lower sample boundary from unknown or unspecified reference level	Lower boundary depth from unknown reference	1	14
3	2012-09-21 16:51:47.967181+00	\N	Width of entire sample or (square) core width	Sample/core width	1	14
20	2012-09-21 16:51:47.967181+00	\N	Negative values denote depth of upper sample/unit/core etc boundary from ground or water surface in metres.	Upper boundary depth (negative) from surface	1	14
21	2012-09-21 16:51:47.967181+00	\N	Positive values denote depth of lower sample/unit/core etc boundary from ground or water surface in metres.	Lower boundary depth (positive) from surface	1	14
22	2012-09-21 16:51:47.967181+00	\N	Negative values denote depth of lower sample/unit/core etc boundary from ground or water surface in metres.	Lower boundary depth (negative) from surface	1	14
23	2012-09-21 16:51:47.967181+00	\N	Positive values denote depth of upper sample/unit/core etc boundary from reference line (e.g. profile line, core top), reference point or datum, in metres.	Upper boundary depth (positive) from reference	1	14
24	2012-09-21 16:51:47.967181+00	\N	Negative values denote depth of upper sample/unit/core etc boundary from reference line (e.g. profile line, core top), reference point or datum, in metres.	Upper boundary depth (negative) from reference	1	14
28	2012-10-11 11:57:09.884896+00	h	Vessel height	Vessel height	1	14
29	2012-10-11 12:15:42.832005+00	\N	Minimum firing temperature required for creation of ceramic object	Firing temperature (min)	9	14
30	2012-10-11 12:52:37.369854+00	\N	Vessel base diameter	Base diameter	1	14
31	2012-10-11 12:58:13.876777+00	\N	Vessel rim diameter	Rim diameter	1	14
32	2012-10-11 13:08:44.323651+00	\N	Approximate ceramics melting point	Melting point	9	14
33	2012-10-11 13:10:04.787486+00	\N	Temperature at which ceramic vessel melting point was measured but not achieved. E.g. >1350	Melting point higher than	9	14
12	2012-09-21 16:51:47.967181+00	X/E	X coordinate or Easting in decimal degrees. Negative values are west of the meridian or origin (zero coordinate).	X/East	4	17
13	2012-09-21 16:51:47.967181+00	Y/N	Y coordinate or Northing in metres. Negative values are south of the origin (zero coordinate).	Y/North	1	17
14	2012-09-21 16:51:47.967181+00	Y/N	Y coordinate or Northing in intrinsic units. Negative values are south of the origin (zero coordinate).	Y/North	5	17
18	2012-09-21 16:51:47.967181+00	Z/Alt	Z coordinate or Altitude in metres.	Z/Altitude	1	17
15	2012-10-18 11:20:16.290443+00	Y/E	Y coordinate or Easting in metres. Negative values are west of the meridian or origin (zero coordinate).	Y/East	1	17
17	2012-10-18 11:20:16.290443+00	Y/E	Y coordinate or Easting in intrinsic units. Negative values are west of the meridian or origin (zero coordinate).	Y/East	5	17
