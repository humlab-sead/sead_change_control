1	Archaeological site	Samples from archaeological sites.	1	2012-09-21 16:51:47.967181+00
5	Stratigraphic sequence	Series of samples from any vertical sequence, includes cores, monoliths and off site archaeological stratigraphies.	2	2012-09-21 16:51:47.967181+00
3	Other palaeo	Palaeo samples collected under other circumstances or for other purposes.	3	2012-09-21 16:51:47.967181+00
4	Pitfall traps	Samples from pitfall trap captures.	4	2012-09-21 16:51:47.967181+00
7	Insect hunting	Samples collected from living moss surfaces.	5	2012-09-21 16:51:47.967181+00
11	Other quantitative insect survey	Numerical insect/arthropod survey data.	6	2012-09-21 16:51:47.967181+00
10	Quantitative vegetation survey	Vegetation survey where species/individuals are counted.	7	2012-09-21 16:51:47.967181+00
8	Qualitative vegetation survey	General vegetation descriptions or estimations, mainly categorical data.	8	2012-09-21 16:51:47.967181+00
9	Lake surface sediment samples	Grab samples of upper sediment layers in water bodies.	9	2012-09-21 16:51:47.967181+00
6	Moss polsters	Samples collected from living moss surfaces.	10	2012-09-21 16:51:47.967181+00
2	Other modern	Modern samples collected under other circumstances or for other purposes.	11	2012-09-21 16:51:47.967181+00
12	Dendrochronological investigation	Investigation of wood for age determination	0	2012-10-11 11:20:10.224715+00
13	Ceramics	Investigation of properties of ceramic materials.	0	2012-10-11 11:23:08.909708+00
14	Geoarchaeological field prospection	Spatial survey using geoarchaeological methods (e.g. soil chemistry/properties, metal detector, magnetometer, MS-loop)	0	2013-04-23 09:00:48.038425+00
