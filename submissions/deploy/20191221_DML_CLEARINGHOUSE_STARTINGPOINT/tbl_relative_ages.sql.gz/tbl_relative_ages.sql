1	1	Early Jomon Period	Jeapanese mesolithic timeperiod in years BP	7900.00000	5100.00000	\N	\N	years BP	\N	\N	\N	4	1	-1	\N	C	2019-12-20 22:14:28.053842+00	529
2	1	Incipent Jomon Period	Jeapanese mesolithic timeperiod in years BP	13800.00000	10900.00000	\N	\N	years BP	\N	\N	\N	4	1	-2	\N	C	2019-12-20 22:14:28.053842+00	528
3	1	Initial Jomon Period	Jeapanese mesolithic timeperiod in years BP	11100.00000	8000.00000	\N	\N	years BP	\N	\N	\N	4	1	-3	\N	C	2019-12-20 22:14:28.053842+00	527
