1	-25	barockmålningar på väggar och tak i bottenvåningen	\N	2	1	-1	\N	C	2019-12-20 22:14:09.31687+00	6
2	-4	knuttimrat stenkista i källaren som murstocksfundament	\N	2	1	-2	\N	C	2019-12-20 22:14:09.31687+00	5
3	-14	lerklining; tapeter	\N	2	1	-3	\N	C	2019-12-20 22:14:09.31687+00	4
4	-3	rester av tapet och tidningspapper på några ställen	\N	2	1	-4	\N	C	2019-12-20 22:14:09.31687+00	3
5	-29	tapet i tjocka lager i alla rum som dateras från 1830-1970-talet.	\N	2	1	-5	\N	C	2019-12-20 22:14:09.31687+00	2
6	-47	åstak	\N	2	1	-6	\N	C	2019-12-20 22:14:09.31687+00	1
1	-143	Stolpe i hägnad som markerar gräns mellan tomt 1 och 2.	\N	3	1	-1	\N	C	2019-12-20 22:14:19.067462+00	53
2	-144	Rustbädd utlagd inför den första etablering på tomten.	\N	3	1	-2	\N	C	2019-12-20 22:14:19.067462+00	52
3	-145	Stock i gränsdike - vret.	\N	3	1	-3	\N	C	2019-12-20 22:14:19.067462+00	51
4	-146	Hägnad/gränsmärkning på tomt 8.	\N	3	1	-4	\N	C	2019-12-20 22:14:19.067462+00	50
5	-147	Kanske rustbädd till stallbyggnad.	\N	3	1	-5	\N	C	2019-12-20 22:14:19.067462+00	49
6	-148	Syll till byggnad, möjligen stall.	\N	3	1	-6	\N	C	2019-12-20 22:14:19.067462+00	48
7	-129	Björkstam i det blöta svarta lagret på berget under (0,8 m) rost Ho 101.	\N	3	1	-7	\N	C	2019-12-20 22:14:19.067462+00	47
8	-133	Stock från rännan.	\N	3	1	-8	\N	C	2019-12-20 22:14:19.067462+00	46
9	-135	Stock. 	\N	3	1	-9	\N	C	2019-12-20 22:14:19.067462+00	45
10	-136	Stock. 	\N	3	1	-10	\N	C	2019-12-20 22:14:19.067462+00	44
11	-138	Stock. Kärnveden dock ej bevarad. 	\N	3	1	-11	\N	C	2019-12-20 22:14:19.067462+00	43
12	-138	Stock. 	\N	3	1	-12	\N	C	2019-12-20 22:14:19.067462+00	42
13	-139	Störkonstruktion.	\N	3	1	-13	\N	C	2019-12-20 22:14:19.067462+00	41
14	-140	Störkonstruktion.	\N	3	1	-14	\N	C	2019-12-20 22:14:19.067462+00	40
15	-141	Spåntanläggning.	\N	3	1	-15	\N	C	2019-12-20 22:14:19.067462+00	39
16	-142	Spåntanläggning.	\N	3	1	-16	\N	C	2019-12-20 22:14:19.067462+00	38
17	-113	Konstruktionen har tolkats som en kista för att göra byggnation möjligt i en mycket sank och blöt mark.	\N	3	1	-17	\N	C	2019-12-20 22:14:19.067462+00	37
21	-117	Bottenstock/tröskelstock till en källare.	\N	3	1	-21	\N	C	2019-12-20 22:14:19.067462+00	33
18	-119	Rester av timrade rustbäddar; bestående av plankgolv, timmerkistor och pålar nedkilade i marken.	\N	3	1	-18	\N	C	2019-12-20 22:14:19.067462+00	36
19	-120	Rester av timrade rustbäddar; bestående av plankgolv, timmerkistor och pålar nedkilade i marken.	\N	3	1	-19	\N	C	2019-12-20 22:14:19.067462+00	35
20	-118	Provet är taget från en större stolpe. Stolpen är en av flera stolpar med stabiliserande funktion i området ut mot statsmuren och bastionen Carolus Nonus.	\N	3	1	-20	\N	C	2019-12-20 22:14:19.067462+00	34
22	-114	Sågad träplanka på torvlagret under slaggdeponin.	\N	3	1	-22	\N	C	2019-12-20 22:14:19.067462+00	32
23	-114	Stor träplanka på torvlagret under slaggdeponin.	\N	3	1	-23	\N	C	2019-12-20 22:14:19.067462+00	31
24	-114	Sågat trä ovanpå torvlagret under slaggdeponin.	\N	3	1	-24	\N	C	2019-12-20 22:14:19.067462+00	30
25	-114	Trästubbe (avverkad) från ursprunglig markyta.	\N	3	1	-25	\N	C	2019-12-20 22:14:19.067462+00	29
26	-4	Stolpe i syllen.	\N	3	1	-26	\N	C	2019-12-20 22:14:19.067462+00	28
27	-9	Mullbänkshuset 1700-tal.	\N	3	1	-27	\N	C	2019-12-20 22:14:19.067462+00	27
28	-10	Gjuteriet.	\N	3	1	-28	\N	C	2019-12-20 22:14:19.067462+00	26
29	-13	Bostad 1600-tal.	\N	3	1	-29	\N	C	2019-12-20 22:14:19.067462+00	25
30	-14	Bostad 1600-tal.	\N	3	1	-30	\N	C	2019-12-20 22:14:19.067462+00	24
31	-15	Äldsta huset?	\N	3	1	-31	\N	C	2019-12-20 22:14:19.067462+00	23
32	-18	Stall? 1600-tal	\N	3	1	-32	\N	C	2019-12-20 22:14:19.067462+00	22
33	-20	Bostad? 1600-tal.	\N	3	1	-33	\N	C	2019-12-20 22:14:19.067462+00	21
34	-24	Stolpfundament i gjuteriet.	\N	3	1	-34	\N	C	2019-12-20 22:14:19.067462+00	20
35	-26	Stolpfundament i gjuteriet.	\N	3	1	-35	\N	C	2019-12-20 22:14:19.067462+00	19
36	-154	Påle.	\N	3	1	-36	\N	C	2019-12-20 22:14:19.067462+00	18
37	-156	Virke från brokista som utgjorde brons underkonstruktion.	\N	3	1	-37	\N	C	2019-12-20 22:14:19.067462+00	17
38	-157	Stolpe från pålverk.	\N	3	1	-38	\N	C	2019-12-20 22:14:19.067462+00	16
39	-158	Stolpe från avspärrning för de utfyllnadsarbeten som givit Kalmar dess topografiska uttseende det har idag, proverna är påträffade på den sida där det nya Kalmar anlades på 1640-talet.	\N	3	1	-39	\N	C	2019-12-20 22:14:19.067462+00	15
40	-159	Stolpen kan ha ingått i en medeltida bryggkonstruktion.	\N	3	1	-40	\N	C	2019-12-20 22:14:19.067462+00	14
41	-160	Bropåle.	\N	3	1	-41	\N	C	2019-12-20 22:14:19.067462+00	13
42	-161	Kanske del av en källare.	\N	3	1	-42	\N	C	2019-12-20 22:14:19.067462+00	12
43	-162	Troligen kavelbro.	\N	3	1	-43	\N	C	2019-12-20 22:14:19.067462+00	11
44	-164	Träskoningen från en kallkälla invid stranden (i sjön) vid det medeltida fästet Rostockaholme.	\N	3	1	-44	\N	C	2019-12-20 22:14:19.067462+00	10
45	-165	Fyndomständigheter kunde inte dokumenteras	\N	3	1	-45	\N	C	2019-12-20 22:14:19.067462+00	9
46	-166	Söndergrävt brädverk i ursprungligt läge.	\N	3	1	-46	\N	C	2019-12-20 22:14:19.067462+00	8
47	-168	Bropåle.	\N	3	1	-47	\N	C	2019-12-20 22:14:19.067462+00	7
