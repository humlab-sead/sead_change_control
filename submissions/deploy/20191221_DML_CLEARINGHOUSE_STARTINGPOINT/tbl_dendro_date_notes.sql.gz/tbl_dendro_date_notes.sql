1	-5	Får den äldsta dateringen i denna undersökning 1560-1600, mest sannolikt är virket avverkat på 1560- eller 1570-talen. Detta virke avviker något från det övriga daterade virket och kan därför ha en annan ståndort.	\N	3	1	-1	\N	C	2019-12-20 22:14:19.067462+00	97
2	-55	Brand 1661 och 1711.	\N	3	1	-2	\N	C	2019-12-20 22:14:19.067462+00	96
3	-69	Tillväxtkollaps 1771.	\N	3	1	-3	\N	C	2019-12-20 22:14:19.067462+00	95
4	-95	Tillväxtkollaps 1627.	\N	3	1	-4	\N	C	2019-12-20 22:14:19.067462+00	94
5	-96	Tillväxtkollaps 1544.	\N	3	1	-5	\N	C	2019-12-20 22:14:19.067462+00	93
6	-97	Möjligen avverkat sensommaren 1802.	\N	3	1	-6	\N	C	2019-12-20 22:14:19.067462+00	92
7	-117	Tillväxtkollaps 1700 ± 2.	\N	3	1	-7	\N	C	2019-12-20 22:14:19.067462+00	91
1	-4	dåligt statistiskt underlag, huvudsakligen visuell bedömning	\N	2	1	-1	\N	C	2019-12-20 22:14:09.31687+00	56
2	-6	dåligt statistiskt underlag, huvudsakligen visuell bedömning	\N	2	1	-2	\N	C	2019-12-20 22:14:09.31687+00	55
3	-7	dåligt statistiskt underlag, huvudsakligen visuell bedömning	\N	2	1	-3	\N	C	2019-12-20 22:14:09.31687+00	54
4	-14	trol. avverkat V 1778/79, som alla andra prover i undersökningen	\N	2	1	-4	\N	C	2019-12-20 22:14:09.31687+00	53
5	-33	borde enligt Hans Linderson / Lund vara S 1801; varför det anges som V 1800/1801 kan i nuläget inte avgöras.	\N	2	1	-5	\N	C	2019-12-20 22:14:09.31687+00	52
6	-109	Ett svårdaterat prov, kunde endast dateras med  grannfastigheten "Rådmannen 2", vilket därtill skilde ut sig med att vara granvirke. Samma virkesförsäljare?	\N	2	1	-6	\N	C	2019-12-20 22:14:09.31687+00	51
7	-139	Dateras men saknar vankant. 	\N	2	1	-7	\N	C	2019-12-20 22:14:09.31687+00	50
8	-140	Dateras men saknar vankant. 	\N	2	1	-8	\N	C	2019-12-20 22:14:09.31687+00	49
9	-141	Dateras men saknar vankant. 	\N	2	1	-9	\N	C	2019-12-20 22:14:09.31687+00	48
10	-142	Dateras men saknar vankant. 	\N	2	1	-10	\N	C	2019-12-20 22:14:09.31687+00	47
11	-200	kan också vara en E 1785-datering, se labprotokollet	\N	2	1	-11	\N	C	2019-12-20 22:14:09.31687+00	46
12	-202	kan också vara en E 1785-datering, se labprotokollet	\N	2	1	-12	\N	C	2019-12-20 22:14:09.31687+00	45
13	-260	Osäker vankant, kan vara avverkat V 1859/60. 	\N	2	1	-13	\N	C	2019-12-20 22:14:09.31687+00	44
14	-299	Oklart om vankant finns med i provet, kanske datering till V 1804/05	\N	2	1	-14	\N	C	2019-12-20 22:14:09.31687+00	43
15	-300	Oklart om vankant finns med i provet, kanske datering till V 1844/45	\N	2	1	-15	\N	C	2019-12-20 22:14:09.31687+00	42
16	-301	Oklart om vankant finns med i provet, kanske datering till V 1845/46	\N	2	1	-16	\N	C	2019-12-20 22:14:09.31687+00	41
17	-302	Oklart om vankant finns med i provet, kanske datering till V 1844/45	\N	2	1	-17	\N	C	2019-12-20 22:14:09.31687+00	40
18	-303	Oklart om vankant finns med i provet, kanske datering till V 1844/45	\N	2	1	-18	\N	C	2019-12-20 22:14:09.31687+00	39
19	-304	Oklart om vankant finns med i provet, kanske datering till V 1831/32	\N	2	1	-19	\N	C	2019-12-20 22:14:09.31687+00	38
20	-306	Svårt att mäta de sista ringarna, de var extremt små därför kan fällningsåret inte fastställas exakt. 	\N	2	1	-20	\N	C	2019-12-20 22:14:09.31687+00	37
21	-329	Har fällts under växtperioden, troligen tidigt sommar eller vår	\N	2	1	-21	\N	C	2019-12-20 22:14:09.31687+00	36
22	-330	Har fällts under växtperioden, troligen tidigt sommar eller vår	\N	2	1	-22	\N	C	2019-12-20 22:14:09.31687+00	35
23	-331	Har fällts under växtperioden, troligen tidigt sommar eller vår	\N	2	1	-23	\N	C	2019-12-20 22:14:09.31687+00	34
24	-332	Har fällts under växtperioden, troligen tidigt sommar eller vår	\N	2	1	-24	\N	C	2019-12-20 22:14:09.31687+00	33
25	-333	Har fällts under växtperioden, troligen tidigt sommar eller vår	\N	2	1	-25	\N	C	2019-12-20 22:14:09.31687+00	32
26	-334	Provet gick inte att klistra ihop, men enligt den höga korrelationen med de andra proverna (75353-357) har det förmodligen samma fällningstid som de övriga.	\N	2	1	-26	\N	C	2019-12-20 22:14:09.31687+00	31
27	-397	maj-juni 1816	\N	2	1	-27	\N	C	2019-12-20 22:14:09.31687+00	30
8	-143	Tillväxtkollaps 1603.	\N	3	1	-8	\N	C	2019-12-20 22:14:19.067462+00	90
28	-423	provet saknar vankant men korrelerar mycket väl med prov 75485, troligen avverkat samma säsong (V 1738/39).	\N	2	1	-28	\N	C	2019-12-20 22:14:09.31687+00	29
29	-429	dåligt statistiskt underlag, huvudsakligen visuell bedömning	\N	2	1	-29	\N	C	2019-12-20 22:14:09.31687+00	28
30	-431	dåligt statistiskt underlag, huvudsakligen visuell bedömning	\N	2	1	-30	\N	C	2019-12-20 22:14:09.31687+00	27
31	-432	dåligt statistiskt underlag, huvudsakligen visuell bedömning	\N	2	1	-31	\N	C	2019-12-20 22:14:09.31687+00	26
32	-439	trol. avverkat V 1778/79, som alla andra prover i undersökningen	\N	2	1	-32	\N	C	2019-12-20 22:14:09.31687+00	25
33	-458	borde enligt Hans Linderson / Lund vara S 1801; varför det anges som V 1800/1801 kan i nuläget inte avgöras.	\N	2	1	-33	\N	C	2019-12-20 22:14:09.31687+00	24
34	-534	Ett svårdaterat prov, kunde endast dateras med  grannfastigheten "Rådmannen 2", vilket därtill skilde ut sig med att vara granvirke. Samma virkesförsäljare?	\N	2	1	-34	\N	C	2019-12-20 22:14:09.31687+00	23
35	-564	Dateras men saknar vankant. 	\N	2	1	-35	\N	C	2019-12-20 22:14:09.31687+00	22
36	-565	Dateras men saknar vankant. 	\N	2	1	-36	\N	C	2019-12-20 22:14:09.31687+00	21
37	-566	Dateras men saknar vankant. 	\N	2	1	-37	\N	C	2019-12-20 22:14:09.31687+00	20
38	-567	Dateras men saknar vankant. 	\N	2	1	-38	\N	C	2019-12-20 22:14:09.31687+00	19
39	-625	kan också vara en E 1785-datering, se labprotokollet	\N	2	1	-39	\N	C	2019-12-20 22:14:09.31687+00	18
40	-627	kan också vara en E 1785-datering, se labprotokollet	\N	2	1	-40	\N	C	2019-12-20 22:14:09.31687+00	17
41	-685	Osäker vankant, kan vara avverkat V 1859/60. 	\N	2	1	-41	\N	C	2019-12-20 22:14:09.31687+00	16
42	-724	Oklart om vankant finns med i provet, kanske datering till V 1804/05	\N	2	1	-42	\N	C	2019-12-20 22:14:09.31687+00	15
43	-725	Oklart om vankant finns med i provet, kanske datering till V 1844/45	\N	2	1	-43	\N	C	2019-12-20 22:14:09.31687+00	14
44	-726	Oklart om vankant finns med i provet, kanske datering till V 1845/46	\N	2	1	-44	\N	C	2019-12-20 22:14:09.31687+00	13
45	-727	Oklart om vankant finns med i provet, kanske datering till V 1844/45	\N	2	1	-45	\N	C	2019-12-20 22:14:09.31687+00	12
46	-728	Oklart om vankant finns med i provet, kanske datering till V 1844/45	\N	2	1	-46	\N	C	2019-12-20 22:14:09.31687+00	11
47	-729	Oklart om vankant finns med i provet, kanske datering till V 1831/32	\N	2	1	-47	\N	C	2019-12-20 22:14:09.31687+00	10
48	-731	Svårt att mäta de sista ringarna, de var extremt små därför kan fällningsåret inte fastställas exakt. 	\N	2	1	-48	\N	C	2019-12-20 22:14:09.31687+00	9
49	-754	Har fällts under växtperioden, troligen tidigt sommar eller vår	\N	2	1	-49	\N	C	2019-12-20 22:14:09.31687+00	8
50	-755	Har fällts under växtperioden, troligen tidigt sommar eller vår	\N	2	1	-50	\N	C	2019-12-20 22:14:09.31687+00	7
51	-756	Har fällts under växtperioden, troligen tidigt sommar eller vår	\N	2	1	-51	\N	C	2019-12-20 22:14:09.31687+00	6
52	-757	Har fällts under växtperioden, troligen tidigt sommar eller vår	\N	2	1	-52	\N	C	2019-12-20 22:14:09.31687+00	5
53	-758	Har fällts under växtperioden, troligen tidigt sommar eller vår	\N	2	1	-53	\N	C	2019-12-20 22:14:09.31687+00	4
54	-759	Provet gick inte att klistra ihop, men enligt den höga korrelationen med de andra proverna (75353-357) har det förmodligen samma fällningstid som de övriga.	\N	2	1	-54	\N	C	2019-12-20 22:14:09.31687+00	3
55	-822	maj-juni 1816	\N	2	1	-55	\N	C	2019-12-20 22:14:09.31687+00	2
56	-848	provet saknar vankant men korrelerar mycket väl med prov 75485, troligen avverkat samma säsong (V 1738/39).	\N	2	1	-56	\N	C	2019-12-20 22:14:09.31687+00	1
9	-174	Årsringssekvensen tyder på att trädet är självdött dvs trädet kan långt senare avverkas som torrfura.	\N	3	1	-9	\N	C	2019-12-20 22:14:19.067462+00	89
10	-176	Mest sannolik datering 1630  ± 4. Tillväxtkollaps 1501-17, 1583-1626. 	\N	3	1	-10	\N	C	2019-12-20 22:14:19.067462+00	88
11	-177	Tillväxtkollaps (1545-47). 	\N	3	1	-11	\N	C	2019-12-20 22:14:19.067462+00	87
12	-181	Tillväxtkollaps (1724-27).	\N	3	1	-12	\N	C	2019-12-20 22:14:19.067462+00	86
13	-184	Tillväxtkollaps 1562-65,1594-98.	\N	3	1	-13	\N	C	2019-12-20 22:14:19.067462+00	85
14	-187	Tillväxtkollaps (1584-1588). 	\N	3	1	-14	\N	C	2019-12-20 22:14:19.067462+00	84
15	-196	Tillväxtkollaps 1596-1597.	\N	3	1	-15	\N	C	2019-12-20 22:14:19.067462+00	83
16	-198	Inte helt säker datering pga fåtal årsringar. Precisionen dock hög, juni ± ½ månad år 1625	\N	3	1	-16	\N	C	2019-12-20 22:14:19.067462+00	82
17	-203	Virket bedöms vara avverkat kort tid efter 1388.	\N	3	1	-17	\N	C	2019-12-20 22:14:19.067462+00	81
18	-204	Det var svårt att avgöra om de yttersta årsringarna fanns med i provet, i så fall vare avverkningsåret  V 1374/75. Dateringen bekräfter den tidigare dateringen av proverna 75070 och 71.	\N	3	1	-18	\N	C	2019-12-20 22:14:19.067462+00	80
19	-205	Det var svårt att avgöra om de yttersta årsringarna fanns med i provet, i så fall vare avverkningsåret  V 1374/75. Dateringen bekräfter den tidigare dateringen av proverna 75070 och 71.	\N	3	1	-19	\N	C	2019-12-20 22:14:19.067462+00	79
20	-231	Verkar vara brandskadat, ingen bark och vankant.	\N	3	1	-20	\N	C	2019-12-20 22:14:19.067462+00	78
21	-239	Ej säker om alla årsringar dvs vankanten är med i provet, fällningstid därför strax efter 1337 eller V 1337/38.	\N	3	1	-21	\N	C	2019-12-20 22:14:19.067462+00	77
22	-257	Får den äldsta dateringen i denna undersökning 1560-1600, mest sannolikt är virket avverkat på 1560- eller 1570-talen. Detta virke avviker något från det övriga daterade virket och kan därför ha en annan ståndort.	\N	3	1	-22	\N	C	2019-12-20 22:14:19.067462+00	76
23	-335	Brand 1661 och 1711.	\N	3	1	-23	\N	C	2019-12-20 22:14:19.067462+00	75
24	-353	Tillväxtkollaps 1771.	\N	3	1	-24	\N	C	2019-12-20 22:14:19.067462+00	74
25	-384	Tillväxtkollaps 1627.	\N	3	1	-25	\N	C	2019-12-20 22:14:19.067462+00	73
26	-385	Tillväxtkollaps 1544.	\N	3	1	-26	\N	C	2019-12-20 22:14:19.067462+00	72
27	-386	Möjligen avverkat sensommaren 1802.	\N	3	1	-27	\N	C	2019-12-20 22:14:19.067462+00	71
28	-387	Möjligen avverkat sensommaren 1802.	\N	3	1	-28	\N	C	2019-12-20 22:14:19.067462+00	70
29	-415	Tillväxtkollaps 1700 ± 2.	\N	3	1	-29	\N	C	2019-12-20 22:14:19.067462+00	69
30	-454	Tillväxtkollaps 1603.	\N	3	1	-30	\N	C	2019-12-20 22:14:19.067462+00	68
31	-455	Tillväxtkollaps 1603.	\N	3	1	-31	\N	C	2019-12-20 22:14:19.067462+00	67
32	-494	Årsringssekvensen tyder på att trädet är självdött dvs trädet kan långt senare avverkas som torrfura.	\N	3	1	-32	\N	C	2019-12-20 22:14:19.067462+00	66
33	-495	Årsringssekvensen tyder på att trädet är självdött dvs trädet kan långt senare avverkas som torrfura.	\N	3	1	-33	\N	C	2019-12-20 22:14:19.067462+00	65
34	-497	Mest sannolik datering 1630  ± 4. Tillväxtkollaps 1501-17, 1583-1626. 	\N	3	1	-34	\N	C	2019-12-20 22:14:19.067462+00	64
35	-498	Tillväxtkollaps (1545-47). 	\N	3	1	-35	\N	C	2019-12-20 22:14:19.067462+00	63
36	-503	Tillväxtkollaps (1724-27).	\N	3	1	-36	\N	C	2019-12-20 22:14:19.067462+00	62
37	-507	Tillväxtkollaps 1562-65,1594-98.	\N	3	1	-37	\N	C	2019-12-20 22:14:19.067462+00	61
38	-508	Tillväxtkollaps 1562-65,1594-98.	\N	3	1	-38	\N	C	2019-12-20 22:14:19.067462+00	60
39	-512	Tillväxtkollaps (1584-1588). 	\N	3	1	-39	\N	C	2019-12-20 22:14:19.067462+00	59
40	-527	Tillväxtkollaps 1596-1597.	\N	3	1	-40	\N	C	2019-12-20 22:14:19.067462+00	58
41	-528	Tillväxtkollaps 1596-1597.	\N	3	1	-41	\N	C	2019-12-20 22:14:19.067462+00	57
