30	Construction purpose	Used to describe the function of a construction using wider umbrella terms. i.e. whether it is is/was used for housing, worship, etc.  (e.g. outbuilding, church, shed)	\N	2	1	-30	\N	C	2019-12-20 22:14:09.31687+00	62
31	Construction function	Specification of a construction's function; what fuction did, or does, it serve? (e.g. a residential house could be a croft or fishing cabin, an outbuilding a smithy, and an outbuilding a cellar)	\N	2	1	-31	\N	C	2019-12-20 22:14:09.31687+00	61
32	Construction type	Specification of the building plan, shape and specific construction . (e.g. sacristy, loft shed, porch, log cabin)	\N	2	1	-32	\N	C	2019-12-20 22:14:09.31687+00	60
33	Construction levels	Specification of how many levels a structure has (in the case of churches and other complex buildings the building parts are entered). 	\N	2	1	-33	\N	C	2019-12-20 22:14:09.31687+00	59
34	Framework material	Specification of the material used for the framework of the structure. (e.g. "wood, lying timber", "masonry)	\N	2	1	-34	\N	C	2019-12-20 22:14:09.31687+00	58
35	Framework technique	Specification of the technique used for the framework of the structure. (e.g. fyrkanttimmer med utknut)	\N	2	1	-35	\N	C	2019-12-20 22:14:09.31687+00	57
36	Framework facade	Specification of the technique and material used for the facade. (e.g. "wood panel, standing")	\N	2	1	-36	\N	C	2019-12-20 22:14:09.31687+00	56
37	Roof type	Specification of the roof type (e.g. purlin roof). 	\N	2	1	-37	\N	C	2019-12-20 22:14:09.31687+00	55
38	Roof material	Specification of the roof material, that is what the the outer part is covered with  (e.g. clay tiles, grass, concrete). 	\N	2	1	-38	\N	C	2019-12-20 22:14:09.31687+00	54
39	Structure event	Descriptions of events which have affected a structure. 	\N	2	1	-39	\N	C	2019-12-20 22:14:09.31687+00	53
40	Alias	Different types of alias; mainly used for the buildings in dendro related data.	\N	2	1	-40	\N	C	2019-12-20 22:14:09.31687+00	52
