989	Open-air; Close to the coast	3	\N	-45	4	1	-989	\N	C	2019-12-20 22:14:28.053842+00	1350
7	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-7	4	1	-7	\N	C	2019-12-20 22:14:28.053842+00	2332
6	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-6	4	1	-6	\N	C	2019-12-20 22:14:28.053842+00	2333
5	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-5	4	1	-5	\N	C	2019-12-20 22:14:28.053842+00	2334
4	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-4	4	1	-4	\N	C	2019-12-20 22:14:28.053842+00	2335
3	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-3	4	1	-3	\N	C	2019-12-20 22:14:28.053842+00	2336
2	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-2	4	1	-2	\N	C	2019-12-20 22:14:28.053842+00	2337
1	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-1	4	1	-1	\N	C	2019-12-20 22:14:28.053842+00	2338
10	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-10	4	1	-10	\N	C	2019-12-20 22:14:28.053842+00	2329
9	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-9	4	1	-9	\N	C	2019-12-20 22:14:28.053842+00	2330
8	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-8	4	1	-8	\N	C	2019-12-20 22:14:28.053842+00	2331
450	Nybyggnad (efter 1848). Rättarbostaden uppvisar med provmaterialet ingen enhetlig dateringsbild. Det senast fällda timret är från vinterhalvåret 1848/49, vilket utgör den äldsta möjliga dateringen för byggnaden. Prov 75456 är således en återanvänd stock, vilken avverkades vintern 1769/70. 	-39	\N	-71	2	1	-450	\N	C	2019-12-20 22:14:09.31687+00	1
449	Mansardtak	-37	\N	-71	2	1	-449	\N	C	2019-12-20 22:14:09.31687+00	2
448	Trä, liggtimmer	-34	\N	-71	2	1	-448	\N	C	2019-12-20 22:14:09.31687+00	3
447	1,5 Plan	-33	\N	-71	2	1	-447	\N	C	2019-12-20 22:14:09.31687+00	4
446	Rättarbostad	-31	\N	-71	2	1	-446	\N	C	2019-12-20 22:14:09.31687+00	5
445	Bostadshus	-30	\N	-71	2	1	-445	\N	C	2019-12-20 22:14:09.31687+00	6
444	Nybyggnad (efter 1803). Den dendrokronologiska analysen visar att  huvudbyggnaden är byggd 1803 eller något år senare. Köksdelen är uppförd 1852 eller något år senare. 	-39	\N	-70	2	1	-444	\N	C	2019-12-20 22:14:09.31687+00	7
443	Mansardtak	-37	\N	-70	2	1	-443	\N	C	2019-12-20 22:14:09.31687+00	8
442	Trä, liggtimmer	-34	\N	-70	2	1	-442	\N	C	2019-12-20 22:14:09.31687+00	9
441	1 Plan, Vindsvåning; Tillbyggt Kök	-33	\N	-70	2	1	-441	\N	C	2019-12-20 22:14:09.31687+00	10
440	Huvudbyggnad	-31	\N	-70	2	1	-440	\N	C	2019-12-20 22:14:09.31687+00	11
439	Bostadshus	-30	\N	-70	2	1	-439	\N	C	2019-12-20 22:14:09.31687+00	12
389	Trä, liggtimmer	-34	\N	-62	2	1	-389	\N	C	2019-12-20 22:14:09.31687+00	62
388	2 Plan	-33	\N	-62	2	1	-388	\N	C	2019-12-20 22:14:09.31687+00	63
387	Borgarhus	-31	\N	-62	2	1	-387	\N	C	2019-12-20 22:14:09.31687+00	64
438	Nybyggnad (1800-talet).  En stock är provtagen i bränneriet vilken indikerar på att byggnaden är uppförd 1809 eller senare. Då provmängderna är små och fällningsåren varierar såsom i bränneriet och rättarbostaden bör man var något försiktig med att uttala sig om byggnadens uppförande. Bevisligen har man använt återanvänt virke i rättarbostaden. 	-39	\N	-69	2	1	-438	\N	C	2019-12-20 22:14:09.31687+00	13
437	Trä, liggtimmer	-34	\N	-69	2	1	-437	\N	C	2019-12-20 22:14:09.31687+00	14
436	1 Plan	-33	\N	-69	2	1	-436	\N	C	2019-12-20 22:14:09.31687+00	15
435	Bränneri	-31	\N	-69	2	1	-435	\N	C	2019-12-20 22:14:09.31687+00	16
434	Ekonomibyggnad	-30	\N	-69	2	1	-434	\N	C	2019-12-20 22:14:09.31687+00	17
433	tidigare Rådmannen 6	-40	\N	-68	2	1	-433	\N	C	2019-12-20 22:14:09.31687+00	18
432	Nybyggnad (efter 1731). Fastigheten Rådmannen 6 på Kvarnholmen bebyggdes troligen första gången vid 1660-talet. Det nyvarande huset är dock från 1730-talet. Dendroanalysen visade att bottenvåningens stockar är fällda vinterhalvåret 1731/32, alltså kort efter rådhusbranden i juni 1731. Det kan  med stor sannolikhet antas att rådhusbranden även drabbade denna fastighet eftersom branden började i grannhuset till rådhuset som även var granne till  fastigheten Rådmannen 6.	-39	\N	-68	2	1	-432	\N	C	2019-12-20 22:14:09.31687+00	19
431	Takpannor, enkupiga lertegel	-38	\N	-68	2	1	-431	\N	C	2019-12-20 22:14:09.31687+00	20
430	Mansardtak; valmat	-37	\N	-68	2	1	-430	\N	C	2019-12-20 22:14:09.31687+00	21
429	Revetering	-36	\N	-68	2	1	-429	\N	C	2019-12-20 22:14:09.31687+00	22
428	Trä, liggtimmer	-34	\N	-68	2	1	-428	\N	C	2019-12-20 22:14:09.31687+00	23
427	2 Plan	-33	\N	-68	2	1	-427	\N	C	2019-12-20 22:14:09.31687+00	24
426	Bostadshus	-31	\N	-68	2	1	-426	\N	C	2019-12-20 22:14:09.31687+00	25
425	Bostadshus	-30	\N	-68	2	1	-425	\N	C	2019-12-20 22:14:09.31687+00	26
424	Nybyggnad (medeltiden). Uppgifter kopplar samman Dackestugan med den småländske upprorsledaren Nils Dacke, som ska ha övernattat i boden under upproret mot den svenska centralmakten och Gustav Wasa 1542 till 1543. 	-39	\N	-67	2	1	-424	\N	C	2019-12-20 22:14:09.31687+00	27
423	Åsar; rundstörar; björknäver; torv	-38	\N	-67	2	1	-423	\N	C	2019-12-20 22:14:09.31687+00	28
422	Sadeltak	-37	\N	-67	2	1	-422	\N	C	2019-12-20 22:14:09.31687+00	29
421	Knuttimrat; delvis skiftesverk	-35	\N	-67	2	1	-421	\N	C	2019-12-20 22:14:09.31687+00	30
420	Trä, liggtimmer	-34	\N	-67	2	1	-420	\N	C	2019-12-20 22:14:09.31687+00	31
419	2 Plan	-33	\N	-67	2	1	-419	\N	C	2019-12-20 22:14:09.31687+00	32
418	Loftbod med svalgång	-32	\N	-67	2	1	-418	\N	C	2019-12-20 22:14:09.31687+00	33
417	Bod; Sovbod; Förråd	-31	\N	-67	2	1	-417	\N	C	2019-12-20 22:14:09.31687+00	34
416	Bod	-30	\N	-67	2	1	-416	\N	C	2019-12-20 22:14:09.31687+00	35
415	Nybyggnad (efter 1834). Stocken från bottenvåningen (catras 75433) daterades till V 1834/35, stocken från övervåningen (catras 75367) till V 1835/36. De båda dateringarna pekar på samma byggtillfälle. Huset uppfördes 1835/36 eller något år senare. Huset var med stor sannolikhet redan från början i 2 våningar.	-39	\N	-66	2	1	-415	\N	C	2019-12-20 22:14:09.31687+00	36
414	Trä, liggtimmer	-34	\N	-66	2	1	-414	\N	C	2019-12-20 22:14:09.31687+00	37
413	2 Plan	-33	\N	-66	2	1	-413	\N	C	2019-12-20 22:14:09.31687+00	38
412	Huvudbyggnad	-31	\N	-66	2	1	-412	\N	C	2019-12-20 22:14:09.31687+00	39
411	Bostadshus	-30	\N	-66	2	1	-411	\N	C	2019-12-20 22:14:09.31687+00	40
410	Okänt (efter 1746). Fler prover och bättre beskrivning av byggnaden behövs för att kunna uttala sig om byggnadens historia.	-39	\N	-65	2	1	-410	\N	C	2019-12-20 22:14:09.31687+00	41
409	Okänt (1870). Huset byggdes enligt uppdragsgivaren på platsen 1870 men mycket talar för att huset då flyttades från annan plats.  Det daterade virket (2 prover) är från 2 olika  perioder, V 1833/34 och kring 1730. Fler prover och bättre beskrivning av byggnaden behövs för att kunna uttala sig om byggnadens historia.	-39	\N	-64	2	1	-409	\N	C	2019-12-20 22:14:09.31687+00	42
408	Sadeltak	-37	\N	-64	2	1	-408	\N	C	2019-12-20 22:14:09.31687+00	43
407	Trä, liggtimmer	-34	\N	-64	2	1	-407	\N	C	2019-12-20 22:14:09.31687+00	44
406	Huvudbyggnad	-31	\N	-64	2	1	-406	\N	C	2019-12-20 22:14:09.31687+00	45
405	Bostadshus	-30	\N	-64	2	1	-405	\N	C	2019-12-20 22:14:09.31687+00	46
404	Källa ödekyrka	-40	\N	-63	2	1	-404	\N	C	2019-12-20 22:14:09.31687+00	47
403	Nybyggnad (1150-1250). En första träkyrka byggdes i Källa under 1000-talet. Under 1100-talets andra hälft började ombyggnaden till försvarskyrka, men till skillnad mot många andra kyrkor på Öland omvandlades Källa kyrka inte till en klövsadelkyrka. Först byggdes ett försvarstorn av sten, betydligt högre än de bevarade rester av det nuvarande västtornet. Antagligen under 1200-talets första decennium ersattes träkyrkan med en enkel stenkyrka, med ett nästan fönsterlöst långhus och ett kort kor med triumfbåge och absid. Men hotet från Östersjön ökade och kyrkan blev mer och mer en tillflyktsort. Nu revs absidkoret och triumfbågen, ett bredare kor uppfördes och en profanvåning som skyddsrum byggdes i våningen ovanpå långhuset. Därefter påbyggdes ytterligen en våning, en skyttevåning, och tornets översta våningar avkortades, så att tornet och långhuset fick samma höjd. Hela byggnaden fick en krenelerad murkrona med gavlar i öster och väster samt ett tak i två sektioner med en takryttare. Med vapenhusets tillkomst på långhusets södra sida stod fästningskyrkan troligen i 1200-talets mitt klar.  Långhusportalen tillhör kyrkans äldsta delar av trä. Den består av tre breda furuplankor och virket är på vapenhusets sida tämligen väderbiten. Enligt Ragnhild Boström har den antagligen varit utsatt för vädret mellan 25 och 50 år innan det skyddande vapenhuset byggdes. Virket till portalen avverkades omkring 1150. 	-39	\N	-63	2	1	-403	\N	C	2019-12-20 22:14:09.31687+00	48
402	Spån; kalksten	-38	\N	-63	2	1	-402	\N	C	2019-12-20 22:14:09.31687+00	49
401	Sadeltak	-37	\N	-63	2	1	-401	\N	C	2019-12-20 22:14:09.31687+00	50
400	Puts	-36	\N	-63	2	1	-400	\N	C	2019-12-20 22:14:09.31687+00	51
399	Murverk, natursten	-34	\N	-63	2	1	-399	\N	C	2019-12-20 22:14:09.31687+00	52
398	Långhus; Vapenhus; Sakristia	-33	\N	-63	2	1	-398	\N	C	2019-12-20 22:14:09.31687+00	53
397	Salkyrka	-32	\N	-63	2	1	-397	\N	C	2019-12-20 22:14:09.31687+00	54
396	Kyrka	-31	\N	-63	2	1	-396	\N	C	2019-12-20 22:14:09.31687+00	55
395	Kyrka	-30	\N	-63	2	1	-395	\N	C	2019-12-20 22:14:09.31687+00	56
394	Nybyggnad (efter 1740). Dateringen tyder på att huset uppfördes tidigast 1740	-39	\N	-62	2	1	-394	\N	C	2019-12-20 22:14:09.31687+00	57
393	Takpannor, lertegel	-38	\N	-62	2	1	-393	\N	C	2019-12-20 22:14:09.31687+00	58
392	Sadeltak	-37	\N	-62	2	1	-392	\N	C	2019-12-20 22:14:09.31687+00	59
391	Träpanel, stående	-36	\N	-62	2	1	-391	\N	C	2019-12-20 22:14:09.31687+00	60
390	Fyrkanttimmer med slätknut	-35	\N	-62	2	1	-390	\N	C	2019-12-20 22:14:09.31687+00	61
386	Bostadshus	-30	\N	-62	2	1	-386	\N	C	2019-12-20 22:14:09.31687+00	65
385	Nybyggnad (efter 1775/76). Mejeriet representeras av bara ett dendrokronologiskt prov. Är detta representativt för byggnaden så är mejeriet i sin nyvarande utformning den äldsta byggnaden på Viggesbo säteri.	-39	\N	-61	2	1	-385	\N	C	2019-12-20 22:14:09.31687+00	66
384	Trä, liggtimmer	-34	\N	-61	2	1	-384	\N	C	2019-12-20 22:14:09.31687+00	67
383	1 Plan	-33	\N	-61	2	1	-383	\N	C	2019-12-20 22:14:09.31687+00	68
382	Mejeriet	-31	\N	-61	2	1	-382	\N	C	2019-12-20 22:14:09.31687+00	69
381	Ekonomibyggnad	-30	\N	-61	2	1	-381	\N	C	2019-12-20 22:14:09.31687+00	70
380	Nybyggnad (efter 1850). Östra ladan uppfördes 1851 eller något år senare.	-39	\N	-60	2	1	-380	\N	C	2019-12-20 22:14:09.31687+00	71
379	Sadeltak	-37	\N	-60	2	1	-379	\N	C	2019-12-20 22:14:09.31687+00	72
378	Målat, faluröd 	-36	\N	-60	2	1	-378	\N	C	2019-12-20 22:14:09.31687+00	73
377	Fyrkanttimmer med utknut	-35	\N	-60	2	1	-377	\N	C	2019-12-20 22:14:09.31687+00	74
376	Trä, liggtimmer	-34	\N	-60	2	1	-376	\N	C	2019-12-20 22:14:09.31687+00	75
375	2 Plan	-33	\N	-60	2	1	-375	\N	C	2019-12-20 22:14:09.31687+00	76
374	Lada	-31	\N	-60	2	1	-374	\N	C	2019-12-20 22:14:09.31687+00	77
373	Ekonomibyggnad	-30	\N	-60	2	1	-373	\N	C	2019-12-20 22:14:09.31687+00	78
372	Nybyggnad (efter 1851). Västra ladan uppfördes 1852 eller något år senare. 	-39	\N	-59	2	1	-372	\N	C	2019-12-20 22:14:09.31687+00	79
371	Trä, liggtimmer	-34	\N	-59	2	1	-371	\N	C	2019-12-20 22:14:09.31687+00	80
370	Lada	-31	\N	-59	2	1	-370	\N	C	2019-12-20 22:14:09.31687+00	81
369	Ekonomibyggnad	-30	\N	-59	2	1	-369	\N	C	2019-12-20 22:14:09.31687+00	82
368	Nybyggnad (efter 1844). Snickarboden uppfördes 1845 eller något år senare.	-39	\N	-58	2	1	-368	\N	C	2019-12-20 22:14:09.31687+00	83
367	Trä, liggtimmer	-34	\N	-58	2	1	-367	\N	C	2019-12-20 22:14:09.31687+00	84
366	Snickarbod	-31	\N	-58	2	1	-366	\N	C	2019-12-20 22:14:09.31687+00	85
365	Ekonomibyggnad	-30	\N	-58	2	1	-365	\N	C	2019-12-20 22:14:09.31687+00	86
364	Nybyggnad (efter 1846). Magasinets nyvarande utseende är från slutet av 1840-talet. Två av fyra prover dateras dock till vinterhalvåret 1739/40. De utgör det äldsta virket som analyserades vid undersökningen av Viggesbo säteri. Om magasinet under 1840-talets slut endast ombyggdes eller om den nybyggdes under återanvändning av äldre virke framgår inte ur materialet. Ett karakteristika över dateringen som återkommer för varje byggnad på Viggesbo säteri är att dateringen sträcker sig över flera år. Man har alltså lagrat virke i upp till fem år innan man har satt igång med byggandet.	-39	\N	-57	2	1	-364	\N	C	2019-12-20 22:14:09.31687+00	87
363	Mansardtak	-37	\N	-57	2	1	-363	\N	C	2019-12-20 22:14:09.31687+00	88
362	Träpanel, stående	-36	\N	-57	2	1	-362	\N	C	2019-12-20 22:14:09.31687+00	89
361	Fyrkanttimmer med utknut	-35	\N	-57	2	1	-361	\N	C	2019-12-20 22:14:09.31687+00	90
360	Trä, liggtimmer	-34	\N	-57	2	1	-360	\N	C	2019-12-20 22:14:09.31687+00	91
359	1,5 Plan	-33	\N	-57	2	1	-359	\N	C	2019-12-20 22:14:09.31687+00	92
358	Magasin	-31	\N	-57	2	1	-358	\N	C	2019-12-20 22:14:09.31687+00	93
357	Ekonomibyggnad	-30	\N	-57	2	1	-357	\N	C	2019-12-20 22:14:09.31687+00	94
356	Nybyggnad (efter 1708/09). Det daterade virket från den dendrokronologiskt undersökta fastigheten, kvarter Ripan 10, får alla samma fällningstid, vinterhalvåret 1708/09. 	-39	\N	-56	2	1	-356	\N	C	2019-12-20 22:14:09.31687+00	95
355	Sadeltak	-37	\N	-56	2	1	-355	\N	C	2019-12-20 22:14:09.31687+00	96
354	Revetering	-36	\N	-56	2	1	-354	\N	C	2019-12-20 22:14:09.31687+00	97
353	Fyrkanttimmer med slätknut	-35	\N	-56	2	1	-353	\N	C	2019-12-20 22:14:09.31687+00	98
352	Trä, liggtimmer	-34	\N	-56	2	1	-352	\N	C	2019-12-20 22:14:09.31687+00	99
351	2 Plan	-33	\N	-56	2	1	-351	\N	C	2019-12-20 22:14:09.31687+00	100
350	Borgarhus	-31	\N	-56	2	1	-350	\N	C	2019-12-20 22:14:09.31687+00	101
349	Bostadshus	-30	\N	-56	2	1	-349	\N	C	2019-12-20 22:14:09.31687+00	102
348	Nybyggnad (1760-talet). Erfarenhet, när det gäller att lagra virket för uppförandet av byggnader, är att det lagras vanligen mindre än fem år. Den gemensamma åldern av avverkningen tyder på ett icke långvarigt samlade virke och därmed ännu kortare lagringstid. Byggnaden är således sannolikt uppförd under de allra första åren på 1760-talet.	-39	\N	-55	2	1	-348	\N	C	2019-12-20 22:14:09.31687+00	103
347	Huvudbyggnad	-31	\N	-55	2	1	-347	\N	C	2019-12-20 22:14:09.31687+00	104
346	Bostadshus	-30	\N	-55	2	1	-346	\N	C	2019-12-20 22:14:09.31687+00	105
345	Nybyggnad (efter 1806). 1806 förstörde en brand den ursprungliga stugan från 1680-talet , stugan återuppbyggdes med stor sannolikhet redan samma år som låg ryggåsstuga.	-39	\N	-54	2	1	-345	\N	C	2019-12-20 22:14:09.31687+00	106
344	Takpannor, betong	-38	\N	-54	2	1	-344	\N	C	2019-12-20 22:14:09.31687+00	107
343	Sadeltak	-37	\N	-54	2	1	-343	\N	C	2019-12-20 22:14:09.31687+00	108
342	Träpanel, stående	-36	\N	-54	2	1	-342	\N	C	2019-12-20 22:14:09.31687+00	109
341	Fyrkanttimmer med utknut	-35	\N	-54	2	1	-341	\N	C	2019-12-20 22:14:09.31687+00	110
340	Trä, liggtimmer	-34	\N	-54	2	1	-340	\N	C	2019-12-20 22:14:09.31687+00	111
339	1 Plan	-33	\N	-54	2	1	-339	\N	C	2019-12-20 22:14:09.31687+00	112
338	Enkelstuga, senare tillbyggd sängkammare på östra sidan	-32	\N	-54	2	1	-338	\N	C	2019-12-20 22:14:09.31687+00	113
337	Soldattorp	-31	\N	-54	2	1	-337	\N	C	2019-12-20 22:14:09.31687+00	114
336	Bostadshus	-30	\N	-54	2	1	-336	\N	C	2019-12-20 22:14:09.31687+00	115
335	Okänt (efter 1786). Enligt fastighetsägaren skall huset vara byggt under 1600-talet. De 2 undersökta stockarna från takets golvbjälklag daterades till V 1786/87. För att kunna bedöma om dessa är sekundärt använda eller är utbytta stockar av senare datum skulle det behövas fler prover av olika byggnadsdelar i huset.	-39	\N	-53	2	1	-335	\N	C	2019-12-20 22:14:09.31687+00	116
334	Takpannor	-38	\N	-53	2	1	-334	\N	C	2019-12-20 22:14:09.31687+00	117
333	Sadeltak	-37	\N	-53	2	1	-333	\N	C	2019-12-20 22:14:09.31687+00	118
332	Huvudbyggnad	-31	\N	-53	2	1	-332	\N	C	2019-12-20 22:14:09.31687+00	119
331	Bostadshus	-30	\N	-53	2	1	-331	\N	C	2019-12-20 22:14:09.31687+00	120
330	Nybyggnad (efter 1808). Den dendrokronologiska analysen visar att  huset är byggt efter 1808. Enligt den erfarenhet av antal årsringar i splint för tall under de här förhållanderna, bör det inte saknas många årsringar i prov 75434. Detta ger en trolig datering på 1808-1828.	-39	\N	-52	2	1	-330	\N	C	2019-12-20 22:14:09.31687+00	121
329	Trä, liggtimmer	-34	\N	-52	2	1	-329	\N	C	2019-12-20 22:14:09.31687+00	122
328	2 Plan	-33	\N	-52	2	1	-328	\N	C	2019-12-20 22:14:09.31687+00	123
327	Bostadshus	-31	\N	-52	2	1	-327	\N	C	2019-12-20 22:14:09.31687+00	124
326	Bostadshus	-30	\N	-52	2	1	-326	\N	C	2019-12-20 22:14:09.31687+00	125
325	Okänt (efter 1740). Det daterade virket till östra flygeln är avverkat V 1740/41. Information om provtagningspunkter saknas och det är därför inte möjligt att uttala sig om byggnadens ålder. Enligt Riksantikvarieämbetets bebyggelseregister skall flyglarna vara samtida med huvudbyggnaden alltså från 1660-talet.	-39	\N	-51	2	1	-325	\N	C	2019-12-20 22:14:09.31687+00	126
324	Sadeltak, valmat	-37	\N	-51	2	1	-324	\N	C	2019-12-20 22:14:09.31687+00	127
323	Träpanel, stående	-36	\N	-51	2	1	-323	\N	C	2019-12-20 22:14:09.31687+00	128
322	Trä, liggtimmer	-34	\N	-51	2	1	-322	\N	C	2019-12-20 22:14:09.31687+00	129
321	1 Plan	-33	\N	-51	2	1	-321	\N	C	2019-12-20 22:14:09.31687+00	130
320	Flygel	-31	\N	-51	2	1	-320	\N	C	2019-12-20 22:14:09.31687+00	131
319	Bostadshus	-30	\N	-51	2	1	-319	\N	C	2019-12-20 22:14:09.31687+00	132
318	Nybyggnad (efter 1665). Byggnaden är sannolikt uppförd omkring 1660. Virket till huvudbyggnadens bottenvåning avverkades under 2 perioder: virket till den "äldre" perioden  avverkades ca. 1665, virket till den "yngre" perioden avverkades V 1754/55. Virket till den nya takstolen fälldes V 1754/55, virket till lanterninen V 1665/66. 	-39	\N	-50	2	1	-318	\N	C	2019-12-20 22:14:09.31687+00	133
317	Mansardtak, valmat med lanternin	-37	\N	-50	2	1	-317	\N	C	2019-12-20 22:14:09.31687+00	134
316	Träpanel, stående	-36	\N	-50	2	1	-316	\N	C	2019-12-20 22:14:09.31687+00	135
315	Trä, liggtimmer	-34	\N	-50	2	1	-315	\N	C	2019-12-20 22:14:09.31687+00	136
314	1 Plan	-33	\N	-50	2	1	-314	\N	C	2019-12-20 22:14:09.31687+00	137
313	Huvudbyggnad	-31	\N	-50	2	1	-313	\N	C	2019-12-20 22:14:09.31687+00	138
312	Bostadshus	-30	\N	-50	2	1	-312	\N	C	2019-12-20 22:14:09.31687+00	139
311	Takpannor, enkupiga lertegel	-38	\N	-49	2	1	-311	\N	C	2019-12-20 22:14:09.31687+00	140
310	Sadeltak	-37	\N	-49	2	1	-310	\N	C	2019-12-20 22:14:09.31687+00	141
309	Träpanel, stående	-36	\N	-49	2	1	-309	\N	C	2019-12-20 22:14:09.31687+00	142
308	Fyrkanttimmer med utknut	-35	\N	-49	2	1	-308	\N	C	2019-12-20 22:14:09.31687+00	143
307	Trä, liggtimmer	-34	\N	-49	2	1	-307	\N	C	2019-12-20 22:14:09.31687+00	144
306	2 Plan	-33	\N	-49	2	1	-306	\N	C	2019-12-20 22:14:09.31687+00	145
305	Loftbod med svalgång	-32	\N	-49	2	1	-305	\N	C	2019-12-20 22:14:09.31687+00	146
304	Bostadshus	-31	\N	-49	2	1	-304	\N	C	2019-12-20 22:14:09.31687+00	147
303	Bostadshus	-30	\N	-49	2	1	-303	\N	C	2019-12-20 22:14:09.31687+00	148
302	Takpannor, enkupiga lertegel	-38	\N	-48	2	1	-302	\N	C	2019-12-20 22:14:09.31687+00	149
301	Sadeltak	-37	\N	-48	2	1	-301	\N	C	2019-12-20 22:14:09.31687+00	150
300	Träpanel, stående	-36	\N	-48	2	1	-300	\N	C	2019-12-20 22:14:09.31687+00	151
299	Fyrkanttimmer med utknut	-35	\N	-48	2	1	-299	\N	C	2019-12-20 22:14:09.31687+00	152
298	Trä, liggtimmer	-34	\N	-48	2	1	-298	\N	C	2019-12-20 22:14:09.31687+00	153
297	1 Plan 	-33	\N	-48	2	1	-297	\N	C	2019-12-20 22:14:09.31687+00	154
296	Bagarstuga	-31	\N	-48	2	1	-296	\N	C	2019-12-20 22:14:09.31687+00	155
295	Uthus	-30	\N	-48	2	1	-295	\N	C	2019-12-20 22:14:09.31687+00	156
294	"Den s.k. Aspagården består av ett tvåvånigt, panelat timmerhus med inklädd svale. Sammanbyggd med huset är en envånings visthusbod och i dess förlängning en bagarstuga, där boningshusets stora spis med bakugn är förlagd. Byggnaden användes tidigare som bostad, varvid en del förändringar gjordes. 1950 rustades huset upp. På tomten finns också ett tvåvånings panelat trähus med enkelstuguplan, troligen uppfört på 1700-talet. Gården inrymmer numera verkstäder för konsthantverkare."	-39	\N	-47	2	1	-294	\N	C	2019-12-20 22:14:09.31687+00	157
293	Takpannor, enkupiga lertegel	-38	\N	-47	2	1	-293	\N	C	2019-12-20 22:14:09.31687+00	158
292	Sadeltak	-37	\N	-47	2	1	-292	\N	C	2019-12-20 22:14:09.31687+00	159
291	Träpanel, stående	-36	\N	-47	2	1	-291	\N	C	2019-12-20 22:14:09.31687+00	160
290	Fyrkantimmer med utknut	-35	\N	-47	2	1	-290	\N	C	2019-12-20 22:14:09.31687+00	161
289	Trä, liggtimmer	-34	\N	-47	2	1	-289	\N	C	2019-12-20 22:14:09.31687+00	162
288	1 Plan 	-33	\N	-47	2	1	-288	\N	C	2019-12-20 22:14:09.31687+00	163
287	Visthusbod	-31	\N	-47	2	1	-287	\N	C	2019-12-20 22:14:09.31687+00	164
286	Bod	-30	\N	-47	2	1	-286	\N	C	2019-12-20 22:14:09.31687+00	165
285	Klockstapel	-31	\N	-46	2	1	-285	\N	C	2019-12-20 22:14:09.31687+00	166
284	Kyrka	-30	\N	-46	2	1	-284	\N	C	2019-12-20 22:14:09.31687+00	167
283	Okänt (efter 1859). Fler prover och bättre beskrivning av byggnaden behövs för att kunna uttala sig om byggnadens historia.	-39	\N	-45	2	1	-283	\N	C	2019-12-20 22:14:09.31687+00	168
282	Stuga	-31	\N	-45	2	1	-282	\N	C	2019-12-20 22:14:09.31687+00	169
281	Bostadshus	-30	\N	-45	2	1	-281	\N	C	2019-12-20 22:14:09.31687+00	170
280	Nybyggnad (efter 1866). Stugan är troligen uppfört 1866 eller något år senare.	-39	\N	-44	2	1	-280	\N	C	2019-12-20 22:14:09.31687+00	171
279	Torpstuga	-31	\N	-44	2	1	-279	\N	C	2019-12-20 22:14:09.31687+00	172
278	Bostadshus	-30	\N	-44	2	1	-278	\N	C	2019-12-20 22:14:09.31687+00	173
277	Okänt (efter 1812). 2 prover tagna i en innervägg på flygelns bottenvåning daterades till V 1812/13. Fler prover och bättre beskrivning av byggnaden behövs för att kunna uttala sig om byggnadens historia.	-39	\N	-43	2	1	-277	\N	C	2019-12-20 22:14:09.31687+00	174
276	Takpannor	-38	\N	-43	2	1	-276	\N	C	2019-12-20 22:14:09.31687+00	175
275	Sadeltak	-37	\N	-43	2	1	-275	\N	C	2019-12-20 22:14:09.31687+00	176
274	Träpanel, stående	-36	\N	-43	2	1	-274	\N	C	2019-12-20 22:14:09.31687+00	177
273	Trä, liggtimmer	-34	\N	-43	2	1	-273	\N	C	2019-12-20 22:14:09.31687+00	178
272	1 Plan	-33	\N	-43	2	1	-272	\N	C	2019-12-20 22:14:09.31687+00	179
271	Flygel	-31	\N	-43	2	1	-271	\N	C	2019-12-20 22:14:09.31687+00	180
270	Bostadshus	-30	\N	-43	2	1	-270	\N	C	2019-12-20 22:14:09.31687+00	181
269	Okänt (efter 1787). Fler prover och bättre beskrivning av byggnaden behövs för att kunna uttala sig om byggnadens historia.	-39	\N	-42	2	1	-269	\N	C	2019-12-20 22:14:09.31687+00	182
268	Sadeltak	-37	\N	-42	2	1	-268	\N	C	2019-12-20 22:14:09.31687+00	183
267	Bostadshus	-31	\N	-42	2	1	-267	\N	C	2019-12-20 22:14:09.31687+00	184
266	Bostadshus	-30	\N	-42	2	1	-266	\N	C	2019-12-20 22:14:09.31687+00	185
265	Nybyggnad (1700-1799). Byggnaderna uppfördes under 1700-talet och är, liksom de intilliggande husen, representativa för tidens borgarhus - ett panelat trähus i två våningar under brutet tak.	-39	\N	-41	2	1	-265	\N	C	2019-12-20 22:14:09.31687+00	186
264	Takpannor, enkupiga lertegel	-38	\N	-41	2	1	-264	\N	C	2019-12-20 22:14:09.31687+00	187
263	Mansardtak, valmad spets	-37	\N	-41	2	1	-263	\N	C	2019-12-20 22:14:09.31687+00	188
262	Träpanel, stående	-36	\N	-41	2	1	-262	\N	C	2019-12-20 22:14:09.31687+00	189
261	Trä, liggtimmer	-34	\N	-41	2	1	-261	\N	C	2019-12-20 22:14:09.31687+00	190
260	2 Plan	-33	\N	-41	2	1	-260	\N	C	2019-12-20 22:14:09.31687+00	191
259	Borgarhus	-31	\N	-41	2	1	-259	\N	C	2019-12-20 22:14:09.31687+00	192
258	Bostadshus	-30	\N	-41	2	1	-258	\N	C	2019-12-20 22:14:09.31687+00	193
257	Spån	-38	\N	-40	2	1	-257	\N	C	2019-12-20 22:14:09.31687+00	194
256	Kägeltak, sadeltak	-37	\N	-40	2	1	-256	\N	C	2019-12-20 22:14:09.31687+00	195
255	Puts	-36	\N	-40	2	1	-255	\N	C	2019-12-20 22:14:09.31687+00	196
254	Murverk, natursten	-34	\N	-40	2	1	-254	\N	C	2019-12-20 22:14:09.31687+00	197
253	3 Plan	-33	\N	-40	2	1	-253	\N	C	2019-12-20 22:14:09.31687+00	198
252	Rundhus, absid, vapenhus, sakristia, klockstapel	-32	\N	-40	2	1	-252	\N	C	2019-12-20 22:14:09.31687+00	199
251	Kyrka	-31	\N	-40	2	1	-251	\N	C	2019-12-20 22:14:09.31687+00	200
250	Kyrka	-30	\N	-40	2	1	-250	\N	C	2019-12-20 22:14:09.31687+00	201
249	Okänt (efter 1839). Fler prover och bättre beskrivning av byggnaden behövs för att kunna uttala sig om byggnadens historia.	-39	\N	-39	2	1	-249	\N	C	2019-12-20 22:14:09.31687+00	202
248	Loftbod	-31	\N	-39	2	1	-248	\N	C	2019-12-20 22:14:09.31687+00	203
247	Bod	-30	\N	-39	2	1	-247	\N	C	2019-12-20 22:14:09.31687+00	204
246	Nybyggnad, Ombyggnad, Flyttning (efter 1806). Det undersökta timret daterades till V 1806/07. Om proverna är tagna i byggnadens äldsta delar så är huset uppfört 1807 eller några år senare. Enligt följebrev utflyttades huset vid skifte 1848.	-39	\N	-38	2	1	-246	\N	C	2019-12-20 22:14:09.31687+00	205
245	Sadeltak	-37	\N	-38	2	1	-245	\N	C	2019-12-20 22:14:09.31687+00	206
244	Trä, liggtimmer	-34	\N	-38	2	1	-244	\N	C	2019-12-20 22:14:09.31687+00	207
243	2 Plan	-33	\N	-38	2	1	-243	\N	C	2019-12-20 22:14:09.31687+00	208
242	Enkelstuga	-32	\N	-38	2	1	-242	\N	C	2019-12-20 22:14:09.31687+00	209
241	Stuga	-31	\N	-38	2	1	-241	\N	C	2019-12-20 22:14:09.31687+00	210
240	Bostadshus	-30	\N	-38	2	1	-240	\N	C	2019-12-20 22:14:09.31687+00	211
239	Sadeltak	-37	\N	-36	2	1	-239	\N	C	2019-12-20 22:14:09.31687+00	212
238	Trä, liggtimmer	-34	\N	-36	2	1	-238	\N	C	2019-12-20 22:14:09.31687+00	213
237	2 Plan	-33	\N	-36	2	1	-237	\N	C	2019-12-20 22:14:09.31687+00	214
236	Parstuga, senare tillbyggd	-32	\N	-36	2	1	-236	\N	C	2019-12-20 22:14:09.31687+00	215
235	Gästgivaregård	-31	\N	-36	2	1	-235	\N	C	2019-12-20 22:14:09.31687+00	216
234	Bostadshus	-30	\N	-36	2	1	-234	\N	C	2019-12-20 22:14:09.31687+00	217
233	Nybyggnad (efter 1806). 1806 förstörde en brand den ursprungliga stugan från 1680-talet , stugan återuppbyggdes med stor sannolikhet redan samma år som låg ryggåsstuga.	-39	\N	-35	2	1	-233	\N	C	2019-12-20 22:14:09.31687+00	218
232	Takpannor, betong	-38	\N	-35	2	1	-232	\N	C	2019-12-20 22:14:09.31687+00	219
231	Sadeltak	-37	\N	-35	2	1	-231	\N	C	2019-12-20 22:14:09.31687+00	220
230	Träpanel, stående	-36	\N	-35	2	1	-230	\N	C	2019-12-20 22:14:09.31687+00	221
229	Fyrkanttimmer med utknut	-35	\N	-35	2	1	-229	\N	C	2019-12-20 22:14:09.31687+00	222
228	Trä, liggtimmer	-34	\N	-35	2	1	-228	\N	C	2019-12-20 22:14:09.31687+00	223
227	1 Plan	-33	\N	-35	2	1	-227	\N	C	2019-12-20 22:14:09.31687+00	224
226	Enkelstuga, senare tillbyggd sängkammare på östra sidan	-32	\N	-35	2	1	-226	\N	C	2019-12-20 22:14:09.31687+00	225
225	Soldattorp	-31	\N	-35	2	1	-225	\N	C	2019-12-20 22:14:09.31687+00	226
224	Bostadshus	-30	\N	-35	2	1	-224	\N	C	2019-12-20 22:14:09.31687+00	227
223	Nybyggnad (efter 1738). Huset byggdes cirka 1740 med timrade väggar i ett plan. Alla rummen fick ett omfattande inredningsmåleri och större delen av de ursprungliga vägg- och takmålningarna finns ännu bevarade. Mantalslängden vittnar om att huset ägts av välbeställda borgare som rådmän, stadsfiskal och lantmätare.	-39	\N	-34	2	1	-223	\N	C	2019-12-20 22:14:09.31687+00	228
222	Sadeltak	-37	\N	-34	2	1	-222	\N	C	2019-12-20 22:14:09.31687+00	229
221	Träpanel, stående	-36	\N	-34	2	1	-221	\N	C	2019-12-20 22:14:09.31687+00	230
220	Fyrkanttimmer med utknut	-35	\N	-34	2	1	-220	\N	C	2019-12-20 22:14:09.31687+00	231
219	Trä, liggtimmer	-34	\N	-34	2	1	-219	\N	C	2019-12-20 22:14:09.31687+00	232
218	Borgarhus	-31	\N	-34	2	1	-218	\N	C	2019-12-20 22:14:09.31687+00	233
217	Bostadshus	-30	\N	-34	2	1	-217	\N	C	2019-12-20 22:14:09.31687+00	234
216	Nybyggnad, Ombyggnad (efter 1659). Det daterade virket till takets murremmar avverkades vinterhalvåret 1659/60. Utgår man från att virket till taket inte är återanvänt så är bostadshuset senast uppfört någon gång under 1660-talet.	-39	\N	-33	2	1	-216	\N	C	2019-12-20 22:14:09.31687+00	235
215	Sadeltak	-37	\N	-33	2	1	-215	\N	C	2019-12-20 22:14:09.31687+00	236
214	Bostadshus	-31	\N	-33	2	1	-214	\N	C	2019-12-20 22:14:09.31687+00	237
213	Bostadshus	-30	\N	-33	2	1	-213	\N	C	2019-12-20 22:14:09.31687+00	238
212	Nybyggnad (efter 1773). Det gamla färhuset torde vara uppfört 1774. 	-39	\N	-32	2	1	-212	\N	C	2019-12-20 22:14:09.31687+00	239
211	Sadeltak	-37	\N	-32	2	1	-211	\N	C	2019-12-20 22:14:09.31687+00	240
210	Träpanel, stående	-36	\N	-32	2	1	-210	\N	C	2019-12-20 22:14:09.31687+00	241
209	Fyrkanttimmer med utknut; urskålade hakväggar i knutarna	-35	\N	-32	2	1	-209	\N	C	2019-12-20 22:14:09.31687+00	242
208	Trä, liggtimmer	-34	\N	-32	2	1	-208	\N	C	2019-12-20 22:14:09.31687+00	243
207	Fähus	-31	\N	-32	2	1	-207	\N	C	2019-12-20 22:14:09.31687+00	244
206	Ekonomibyggnad	-30	\N	-32	2	1	-206	\N	C	2019-12-20 22:14:09.31687+00	245
205	Nybyggnad (efter 1860). Med stöd av dateringen av prov 75129 och prov 75137 kan man anta att bostadshuset är från ca 1860.	-39	\N	-31	2	1	-205	\N	C	2019-12-20 22:14:09.31687+00	246
204	Sadeltak	-37	\N	-31	2	1	-204	\N	C	2019-12-20 22:14:09.31687+00	247
203	Fykanttimmer med utknut	-35	\N	-31	2	1	-203	\N	C	2019-12-20 22:14:09.31687+00	248
202	Trä, liggtimmer	-34	\N	-31	2	1	-202	\N	C	2019-12-20 22:14:09.31687+00	249
201	Bostadshus	-31	\N	-31	2	1	-201	\N	C	2019-12-20 22:14:09.31687+00	250
200	Bostadshus	-30	\N	-31	2	1	-200	\N	C	2019-12-20 22:14:09.31687+00	251
150	Bod	-30	\N	-24	2	1	-150	\N	C	2019-12-20 22:14:09.31687+00	301
149	Nybyggnad, Ombyggnad (efter 17585). Tre av nio daterade prover daterades till vinterhalvåret 1785/86, sex prover dateras till vinterhalvåret 1786/87. Loftets södra gavel samt svalgång dateras därmed  till 1786/87 eller några år senare. 	-39	\N	-23	2	1	-149	\N	C	2019-12-20 22:14:09.31687+00	302
148	Trä, liggtimmer	-34	\N	-23	2	1	-148	\N	C	2019-12-20 22:14:09.31687+00	303
147	2 Plan	-33	\N	-23	2	1	-147	\N	C	2019-12-20 22:14:09.31687+00	304
146	Loftbod med svalgång	-32	\N	-23	2	1	-146	\N	C	2019-12-20 22:14:09.31687+00	305
145	Bod	-31	\N	-23	2	1	-145	\N	C	2019-12-20 22:14:09.31687+00	306
199	Nybyggnad, Ombyggnad (efter 1224). Jäts gamla kyrka är pastoratets äldsta kyrka. Den började uppföras redan i slutet av 1100-talet i romansk stil. Den är byggd i gråsten och har under århundradena fått behålla sin ursprungliga grundplan. En triumfbåge skiljer långhuset från koret. På korets norra sida finns en rödfärgad sakristia i liggande timmer, byggd 1733. Sakristians välbevarade väggmålningar tillkom 1735. Det nuvarande vapenhuset är från 1796. Även det är uppfört i liggande timmer. Under koret finns en gravkammare med tio mer eller mindre välbevarade kistor. De rymmer kvarlevorna efter familjer som varit ägare till Helgåkra säteri och Jätsberg. Man hittar namn som Boije, von Dobrikowsky, Uggla, Rudebeck och Gyllenskog. Dessutom lär det finnas en mumifierad kvinnokropp som går under benämningen fröken Eketrä. Läs mera i Anita Liepes bok: Jäts kyrkor. Kyrkan togs ur bruk 1910 då Jäts nya kyrka stod färdig. Men den gamla kyrkan undgick att läggas i ruin. I stället restaurerades den 1959 och 1969-74. Numera används den som gudstjänstlokal under sommaren.\n	-39	\N	-30	2	1	-199	\N	C	2019-12-20 22:14:09.31687+00	252
198	Spån, kluven	-38	\N	-30	2	1	-198	\N	C	2019-12-20 22:14:09.31687+00	253
197	Sadeltak	-37	\N	-30	2	1	-197	\N	C	2019-12-20 22:14:09.31687+00	254
196	Puts; spån	-36	\N	-30	2	1	-196	\N	C	2019-12-20 22:14:09.31687+00	255
195	Murverk, natursten; Trä, liggtimmer	-34	\N	-30	2	1	-195	\N	C	2019-12-20 22:14:09.31687+00	256
194	Långhus, Sakristia, Vapenhus, Klockstapel	-33	\N	-30	2	1	-194	\N	C	2019-12-20 22:14:09.31687+00	257
193	Salkyrka	-32	\N	-30	2	1	-193	\N	C	2019-12-20 22:14:09.31687+00	258
192	Kyrka	-31	\N	-30	2	1	-192	\N	C	2019-12-20 22:14:09.31687+00	259
191	Kyrka	-30	\N	-30	2	1	-191	\N	C	2019-12-20 22:14:09.31687+00	260
190	Nybyggnad, Ombyggnad (efter 1182). Första delen av den nuvarande kyrkan, långhuset, är från 1100-talet. Kyrkdörren låg alltid i söder. Takkonstruktionen öppen med snidade takbjälkar. Altaret stod tidigare, med en absid, där dopfunten står idag åt öster. Till vänster fanns ett sidoaltare med en Mariabild, och mittemot ännu ett sidoaltare med en St Olofsbild. Vi vet att man byggde ut kyrkan omkring år 1182 mot väst. Man har hittat bitar av en takbjälke och med C-14 metoden har man fastställt att den är från 1182. Dörren i söder flyttades till höger om nuvarande altaret. Dörren finns numera på Historiska museet, och dörröppningen är numera igenmurad. Skulpturer förställande Madonnan och S:t Olof, stod på ett sidoaltare till vänster om det nuvarande altaret. Ursprungligen fanns plats för ungefär 60-70 personer, men inga bänkar så man fick stå. För att få plats var man tvungen att stå väldigt tätt. 	-39	\N	-29	2	1	-190	\N	C	2019-12-20 22:14:09.31687+00	261
189	Plåt	-38	\N	-29	2	1	-189	\N	C	2019-12-20 22:14:09.31687+00	262
188	Valmtak; sadeltak	-37	\N	-29	2	1	-188	\N	C	2019-12-20 22:14:09.31687+00	263
187	Puts	-36	\N	-29	2	1	-187	\N	C	2019-12-20 22:14:09.31687+00	264
186	Murverk, natursten	-34	\N	-29	2	1	-186	\N	C	2019-12-20 22:14:09.31687+00	265
185	Långhus; Nordlig Korsarm; Sakristia; Klockstapel	-33	\N	-29	2	1	-185	\N	C	2019-12-20 22:14:09.31687+00	266
184	Salkyrka	-32	\N	-29	2	1	-184	\N	C	2019-12-20 22:14:09.31687+00	267
183	Kyrka	-31	\N	-29	2	1	-183	\N	C	2019-12-20 22:14:09.31687+00	268
182	Kyrka	-30	\N	-29	2	1	-182	\N	C	2019-12-20 22:14:09.31687+00	269
181	Nybyggnad (efter 1714). Loftboden är uppförd av virke som avverkades vinterhalvåret 1714/15. Boden tillhör Dädesjö gamla prästgården. Prästgårdens huvudbyggnad  lär ha uppförts under 1700-talet men har enligt hembygdsföreningen troligen  ännu äldre delar. 	-39	\N	-28	2	1	-181	\N	C	2019-12-20 22:14:09.31687+00	270
180	Gräs	-38	\N	-28	2	1	-180	\N	C	2019-12-20 22:14:09.31687+00	271
179	Sadeltak	-37	\N	-28	2	1	-179	\N	C	2019-12-20 22:14:09.31687+00	272
178	Fyrkanttimmer med utknut	-35	\N	-28	2	1	-178	\N	C	2019-12-20 22:14:09.31687+00	273
177	Trä, liggtimmer	-34	\N	-28	2	1	-177	\N	C	2019-12-20 22:14:09.31687+00	274
176	2 Plan	-33	\N	-28	2	1	-176	\N	C	2019-12-20 22:14:09.31687+00	275
175	Loftbod	-31	\N	-28	2	1	-175	\N	C	2019-12-20 22:14:09.31687+00	276
174	Bod	-30	\N	-28	2	1	-174	\N	C	2019-12-20 22:14:09.31687+00	277
173	Nybyggnad, Ombyggnad (efter 1826). 3 av 10 prover kunde dateras till vinterhalvåret 1826/27, de andra proverna är odaterade. Information saknas om provtagningspunkten, därför är det inte möjligt att uttala sig om byggnadens ålder och tillkommst. Appelbladska smedjan är del av Huskvarnas Smedby, som består av 9 st bostadshus och 3 smedjor. Det första huset byggdes redan under 1700-talet. Smedjorna är byggda i två våningar. På första våningen är själva smedjan inrymd, medan den övre tjänstgjorde som bostad. 	-39	\N	-27	2	1	-173	\N	C	2019-12-20 22:14:09.31687+00	278
172	Takpannor, lertegel	-38	\N	-27	2	1	-172	\N	C	2019-12-20 22:14:09.31687+00	279
171	Sadeltak	-37	\N	-27	2	1	-171	\N	C	2019-12-20 22:14:09.31687+00	280
170	Trä, liggtimmer	-34	\N	-27	2	1	-170	\N	C	2019-12-20 22:14:09.31687+00	281
169	2 Plan	-33	\N	-27	2	1	-169	\N	C	2019-12-20 22:14:09.31687+00	282
168	Smedja	-31	\N	-27	2	1	-168	\N	C	2019-12-20 22:14:09.31687+00	283
167	Bostadshus/Verkstad	-30	\N	-27	2	1	-167	\N	C	2019-12-20 22:14:09.31687+00	284
166	Nybyggnad (1670-1688). Det daterade virket avverkades under 2 perioder kring 1669/70 och kring 1688. Om de odaterade proverna tillhör Sanda kyrka, Jönköping län är fortfarande oklart, men analyset 2012 visade att materialet är betydligt äldre än de daterade proverna. 	-39	\N	-26	2	1	-166	\N	C	2019-12-20 22:14:09.31687+00	285
165	Stuga	-31	\N	-26	2	1	-165	\N	C	2019-12-20 22:14:09.31687+00	286
164	Bostadshus	-30	\N	-26	2	1	-164	\N	C	2019-12-20 22:14:09.31687+00	287
163	Nybyggnad (efter 1723). Analysen visade att virket till loftboden huvudsakligen är avverkat under 4 säsonger: V 1722/23, V 23/24, V 25/26 och V 26/27. Det anses därför vara sannolikt att loften stod klart någon gång under slutet av 1720-talet. 	-39	\N	-25	2	1	-163	\N	C	2019-12-20 22:14:09.31687+00	288
162	Trä, liggtimmer	-34	\N	-25	2	1	-162	\N	C	2019-12-20 22:14:09.31687+00	289
161	Loftbod	-32	\N	-25	2	1	-161	\N	C	2019-12-20 22:14:09.31687+00	290
160	Bod	-31	\N	-25	2	1	-160	\N	C	2019-12-20 22:14:09.31687+00	291
159	Bod	-30	\N	-25	2	1	-159	\N	C	2019-12-20 22:14:09.31687+00	292
158	Takpannor, enkupiga lertegel	-38	\N	-24	2	1	-158	\N	C	2019-12-20 22:14:09.31687+00	293
157	Sadeltak	-37	\N	-24	2	1	-157	\N	C	2019-12-20 22:14:09.31687+00	294
156	Delvis träpanel, stående	-36	\N	-24	2	1	-156	\N	C	2019-12-20 22:14:09.31687+00	295
155	Fyrkanttimmer med utknut	-35	\N	-24	2	1	-155	\N	C	2019-12-20 22:14:09.31687+00	296
154	Trä, liggtimmer	-34	\N	-24	2	1	-154	\N	C	2019-12-20 22:14:09.31687+00	297
153	2 Plan	-33	\N	-24	2	1	-153	\N	C	2019-12-20 22:14:09.31687+00	298
152	Loftbod med svalgång	-32	\N	-24	2	1	-152	\N	C	2019-12-20 22:14:09.31687+00	299
151	Bod	-31	\N	-24	2	1	-151	\N	C	2019-12-20 22:14:09.31687+00	300
144	Bod	-30	\N	-23	2	1	-144	\N	C	2019-12-20 22:14:09.31687+00	307
143	Nybyggnad (efter 1464-1470). Den dendrokronologisk undersökningen visar att virket till takstolarna till bårhuset med stor sannolikhet är avverkat under åren 1464 till 1470. Resultatet bekräftar tidigare antaganden/bedömningar att byggnaden har medeltida ursprung. 	-39	\N	-22	2	1	-143	\N	C	2019-12-20 22:14:09.31687+00	308
142	Spån	-38	\N	-22	2	1	-142	\N	C	2019-12-20 22:14:09.31687+00	309
141	Sadeltak	-37	\N	-22	2	1	-141	\N	C	2019-12-20 22:14:09.31687+00	310
140	Puts	-36	\N	-22	2	1	-140	\N	C	2019-12-20 22:14:09.31687+00	311
139	Murverk, natursten	-34	\N	-22	2	1	-139	\N	C	2019-12-20 22:14:09.31687+00	312
138	1 Plan	-33	\N	-22	2	1	-138	\N	C	2019-12-20 22:14:09.31687+00	313
137	Tiondebod; Bårhus	-31	\N	-22	2	1	-137	\N	C	2019-12-20 22:14:09.31687+00	314
136	Bod	-30	\N	-22	2	1	-136	\N	C	2019-12-20 22:14:09.31687+00	315
135	Nybyggnad; Ombyggnad (1699-1794). Genom dendroanalys 2012 framkom två skilda dateringar: mellanväggen och nordvästra väggen (under 5:e timmervarv) dateras till vinterhalvåret 1793/94.  Sydvästra inre väggen och möjligen delar av nordvästra yttervägg dateras till 1699-1703. 	-39	\N	-21	2	1	-135	\N	C	2019-12-20 22:14:09.31687+00	316
134	Slanor; björknäver; gräs; torv	-38	\N	-21	2	1	-134	\N	C	2019-12-20 22:14:09.31687+00	317
133	Sadeltak	-37	\N	-21	2	1	-133	\N	C	2019-12-20 22:14:09.31687+00	318
132	Fyrkanttimmer med utknut	-35	\N	-21	2	1	-132	\N	C	2019-12-20 22:14:09.31687+00	319
131	Trä, liggtimmer	-34	\N	-21	2	1	-131	\N	C	2019-12-20 22:14:09.31687+00	320
130	1,5 Plan	-33	\N	-21	2	1	-130	\N	C	2019-12-20 22:14:09.31687+00	321
129	Loftbod med svalgång	-32	\N	-21	2	1	-129	\N	C	2019-12-20 22:14:09.31687+00	322
128	Visthusbod; Sommarbostad; Gästrum	-31	\N	-21	2	1	-128	\N	C	2019-12-20 22:14:09.31687+00	323
127	Bod	-30	\N	-21	2	1	-127	\N	C	2019-12-20 22:14:09.31687+00	324
126	Nybyggnad; Tillbyggnad (efter 1822). "Stocken är enligt uppdragsgivaren troligen tagen från översta varvet i en mellanvägg. Under 1800-talet är det inte ovanligt att man höjde takhöjden med något eller några timmervarv. Man kan därför inte utesluta att stugan är äldre och att dateringen visar på denna höjningen av takhöjden. Dateringen visar under alla omständigheter byggnadens minsta ålder." (Linderson 2012)	-39	\N	-20	2	1	-126	\N	C	2019-12-20 22:14:09.31687+00	325
125	Trä, liggtimmer	-34	\N	-20	2	1	-125	\N	C	2019-12-20 22:14:09.31687+00	326
124	Parstuga	-32	\N	-20	2	1	-124	\N	C	2019-12-20 22:14:09.31687+00	327
123	Torp	-31	\N	-20	2	1	-123	\N	C	2019-12-20 22:14:09.31687+00	328
122	Bostadshus	-30	\N	-20	2	1	-122	\N	C	2019-12-20 22:14:09.31687+00	329
121	Nybyggnad (efter 1807). Enligt fastighetsägaren låg byn från början på annat plats men utflyttades efter en brand under 1700-talets slut till sin nuvarande plats. Det aktuella huset uppfördes antagligen med detta samband och tillhör därmed den nya byns äldsta bebyggelse. Det gemensamt fällningsåret till huset virke tyder på att uppförandet av byggnaden ligger nära avverkningsåret, det är därför troligt att byggnaden är uppförd 1808 eller möjligen 1809. 	-39	\N	-19	2	1	-121	\N	C	2019-12-20 22:14:09.31687+00	330
120	Takpannor, enkupiga lertegel	-38	\N	-19	2	1	-120	\N	C	2019-12-20 22:14:09.31687+00	331
119	Sadeltak	-37	\N	-19	2	1	-119	\N	C	2019-12-20 22:14:09.31687+00	332
118	Träpanel, stående	-36	\N	-19	2	1	-118	\N	C	2019-12-20 22:14:09.31687+00	333
117	Fyrkanttimmer med utknut	-35	\N	-19	2	1	-117	\N	C	2019-12-20 22:14:09.31687+00	334
116	Trä, liggtimmer	-34	\N	-19	2	1	-116	\N	C	2019-12-20 22:14:09.31687+00	335
115	2 Plan	-33	\N	-19	2	1	-115	\N	C	2019-12-20 22:14:09.31687+00	336
114	Enkelstuga	-32	\N	-19	2	1	-114	\N	C	2019-12-20 22:14:09.31687+00	337
113	Mangårdsbyggnad	-31	\N	-19	2	1	-113	\N	C	2019-12-20 22:14:09.31687+00	338
112	Bostadshus	-30	\N	-19	2	1	-112	\N	C	2019-12-20 22:14:09.31687+00	339
111	Nybyggnad (efter 1753). Huset byggdes  1754 eller något senare på okänt ställe men troligen i norra Kalmar län. Efter år 1800 flyttades huset till Kvarnholmen i Kalmar 	-39	\N	-17	2	1	-111	\N	C	2019-12-20 22:14:09.31687+00	340
110	Takpannor, enkupiga lertegel	-38	\N	-17	2	1	-110	\N	C	2019-12-20 22:14:09.31687+00	341
109	Sadeltak	-37	\N	-17	2	1	-109	\N	C	2019-12-20 22:14:09.31687+00	342
108	Träpanel, stående	-36	\N	-17	2	1	-108	\N	C	2019-12-20 22:14:09.31687+00	343
107	Fyrkanttimmer med utknut	-35	\N	-17	2	1	-107	\N	C	2019-12-20 22:14:09.31687+00	344
106	Trä, liggtimmer	-34	\N	-17	2	1	-106	\N	C	2019-12-20 22:14:09.31687+00	345
105	2 Plan	-33	\N	-17	2	1	-105	\N	C	2019-12-20 22:14:09.31687+00	346
104	Bostadshus	-31	\N	-17	2	1	-104	\N	C	2019-12-20 22:14:09.31687+00	347
103	Bostadshus	-30	\N	-17	2	1	-103	\N	C	2019-12-20 22:14:09.31687+00	348
102	Nybyggnad (efter 1760). Den så kallade Lagerhamnska gården ligger i Pataholm, en välbevarad handelsplats som har sitt ursprung i 1600-talet. Till husets äldsta delar tillhör källaren. Virket till källarens takbjälklag daterades dendrokronologiskt till vinterhalvåret 1760/61. Därmed får vi en terminus post quem för gårdens mangårdsbyggnad. Tapeter och inredningsdetaljer i husets övriga våningar bekräftar en datering till 1700-talets andra hälft. I den dendrokonologiska undersökningen ingick också en ganska märkligt konstruktion i källarens mitt: En ca 4 x 4 meter stora knuttimrade stenkista som bildar underkonstruktionen till husets murstock. Stenkistan liknar i sin konstruktion en båtbrygga. Byggmaterial verka vara ”lite av allt”, den består både av stora tillhuggna ekbjälkar, av tillhuggna granbjälkar och av rundtimmer. Stenkistan kunde inte dateras , men eftersom en del av takbjälkarna är inbyggda i stenkistan är det sannolikt att tak och stenkista är lika gamla.  Anmärkningsvärd är virkets proveniens: Eken till takbjälkarna härstammar från Polen eller möjligen centrala östra Tyskland.	-39	\N	-16	2	1	-102	\N	C	2019-12-20 22:14:09.31687+00	349
101	Takpannor, enkupiga lertegel	-38	\N	-16	2	1	-101	\N	C	2019-12-20 22:14:09.31687+00	350
100	Sadeltak, frontespis	-37	\N	-16	2	1	-100	\N	C	2019-12-20 22:14:09.31687+00	351
99	Träpanel, stående	-36	\N	-16	2	1	-99	\N	C	2019-12-20 22:14:09.31687+00	352
98	Fyrkanttimmer med utknut	-35	\N	-16	2	1	-98	\N	C	2019-12-20 22:14:09.31687+00	353
97	Trä, liggtimmer	-34	\N	-16	2	1	-97	\N	C	2019-12-20 22:14:09.31687+00	354
96	1 Plan	-33	\N	-16	2	1	-96	\N	C	2019-12-20 22:14:09.31687+00	355
95	Mangårdsbyggnad	-31	\N	-16	2	1	-95	\N	C	2019-12-20 22:14:09.31687+00	356
94	Bostadshus	-30	\N	-16	2	1	-94	\N	C	2019-12-20 22:14:09.31687+00	357
35	2 Plan	-33	\N	-6	2	1	-35	\N	C	2019-12-20 22:14:09.31687+00	416
34	Gårdshus	-31	\N	-6	2	1	-34	\N	C	2019-12-20 22:14:09.31687+00	417
33	Ekonomibyggnad	-30	\N	-6	2	1	-33	\N	C	2019-12-20 22:14:09.31687+00	418
1854	Open-air; Inland	3	\N	-910	4	1	-1854	\N	C	2019-12-20 22:14:28.053842+00	485
93	Nybyggnad (efter 1778). Byggnaden var en fiskestuga som uppfördes under 1700-talets senare decennier vid Kalmarsundsparken. Huset  tillhör därmed Stensö fiskeläges äldsta bebyggelse.  Som den dendrokronologiska  dateringen visade var huset redan från början en ryggåsstuga med 2 rum. Dateringen vederläggar därmed äldre uppgifter att huset förlängdes vid ett senare tillfälle. 	-39	\N	-15	2	1	-93	\N	C	2019-12-20 22:14:09.31687+00	358
92	Papp	-38	\N	-15	2	1	-92	\N	C	2019-12-20 22:14:09.31687+00	359
91	Sadeltak	-37	\N	-15	2	1	-91	\N	C	2019-12-20 22:14:09.31687+00	360
90	Träpanel, stående	-36	\N	-15	2	1	-90	\N	C	2019-12-20 22:14:09.31687+00	361
89	Fyrkanttimmer med utknut	-35	\N	-15	2	1	-89	\N	C	2019-12-20 22:14:09.31687+00	362
88	Trä, liggtimmer	-34	\N	-15	2	1	-88	\N	C	2019-12-20 22:14:09.31687+00	363
87	1 Plan	-33	\N	-15	2	1	-87	\N	C	2019-12-20 22:14:09.31687+00	364
86	Ryggåsstuga	-32	\N	-15	2	1	-86	\N	C	2019-12-20 22:14:09.31687+00	365
85	Fiskestuga	-31	\N	-15	2	1	-85	\N	C	2019-12-20 22:14:09.31687+00	366
84	Bostadshus	-30	\N	-15	2	1	-84	\N	C	2019-12-20 22:14:09.31687+00	367
83	Okänt (efter 1784). interpretation av analysresultatet är inte möjligt eftersom bara ett prov analyserades 	-39	\N	-14	2	1	-83	\N	C	2019-12-20 22:14:09.31687+00	368
82	Fyrkanttimmer med utknut	-35	\N	-14	2	1	-82	\N	C	2019-12-20 22:14:09.31687+00	369
81	Trä, liggtimmer	-34	\N	-14	2	1	-81	\N	C	2019-12-20 22:14:09.31687+00	370
80	Mangårdsbyggnad	-31	\N	-14	2	1	-80	\N	C	2019-12-20 22:14:09.31687+00	371
79	Bostadshus	-30	\N	-14	2	1	-79	\N	C	2019-12-20 22:14:09.31687+00	372
78	Nybyggnad (1831-35). Byggnaden är uppförd 1830/1831 eller något år senare på ökänt ställe.	-39	\N	-13	2	1	-78	\N	C	2019-12-20 22:14:09.31687+00	373
77	Takpannorr, tvåkupig lertegel	-38	\N	-13	2	1	-77	\N	C	2019-12-20 22:14:09.31687+00	374
76	Sadeltak	-37	\N	-13	2	1	-76	\N	C	2019-12-20 22:14:09.31687+00	375
75	Träpanel, stående	-36	\N	-13	2	1	-75	\N	C	2019-12-20 22:14:09.31687+00	376
74	Fyrkanttimmer med utknut	-35	\N	-13	2	1	-74	\N	C	2019-12-20 22:14:09.31687+00	377
73	Trä, liggtimmer	-34	\N	-13	2	1	-73	\N	C	2019-12-20 22:14:09.31687+00	378
72	2 Plan	-33	\N	-13	2	1	-72	\N	C	2019-12-20 22:14:09.31687+00	379
71	Bostadshus	-31	\N	-13	2	1	-71	\N	C	2019-12-20 22:14:09.31687+00	380
70	Bostadshus	-30	\N	-13	2	1	-70	\N	C	2019-12-20 22:14:09.31687+00	381
69	Nybyggnad (efter 1830). Om allt daterat virke i undersökningen (61362-365 samt 61385-387) är avverkat vid en säsong har detta skett vinterhalvåret 1830/31. Byggnaden bör därför vara uppförd 1831. (Linderson 2010)	-39	\N	-12	2	1	-69	\N	C	2019-12-20 22:14:09.31687+00	382
68	Sadeltak	-37	\N	-12	2	1	-68	\N	C	2019-12-20 22:14:09.31687+00	383
67	Trä, liggtimmer	-34	\N	-12	2	1	-67	\N	C	2019-12-20 22:14:09.31687+00	384
66	Mangårdsbyggnad	-31	\N	-12	2	1	-66	\N	C	2019-12-20 22:14:09.31687+00	385
65	Bostadshus	-30	\N	-12	2	1	-65	\N	C	2019-12-20 22:14:09.31687+00	386
64	Nybyggnad; Ombyggnad (efter 1807). Prov 9 (catras 61340) dateras till vinterhalvåret 1806/07. Prov 8 (catras 61329) kan inte dendrokronologisk sammanföras med prov 9 eller någon annan jämförelsekronologi. Förhöjda korrelationer antyder avverkningstid 1814/15 eller 1866/67. Detta kan vara ett indicium för att byggnaden består av timmer med olika dateringar.	-39	\N	-11	2	1	-64	\N	C	2019-12-20 22:14:09.31687+00	387
63	Trä, liggtimmer	-34	\N	-11	2	1	-63	\N	C	2019-12-20 22:14:09.31687+00	388
62	1 Plan	-33	\N	-11	2	1	-62	\N	C	2019-12-20 22:14:09.31687+00	389
61	Svinhus	-31	\N	-11	2	1	-61	\N	C	2019-12-20 22:14:09.31687+00	390
60	Ekonomibyggnad	-30	\N	-11	2	1	-60	\N	C	2019-12-20 22:14:09.31687+00	391
59	Nybyggnad (efter 1851). Västra ladan uppfördes 1852 eller något år senare. I byggnadens golv förekom dock återanvänt virke som dateras till V 1757/58 resp. V 1758/59 och som således utgör beståndsdelar av en äldre okänd byggnad.	-39	\N	-10	2	1	-59	\N	C	2019-12-20 22:14:09.31687+00	392
58	Trä, liggtimmer	-34	\N	-10	2	1	-58	\N	C	2019-12-20 22:14:09.31687+00	393
57	1 Plan	-33	\N	-10	2	1	-57	\N	C	2019-12-20 22:14:09.31687+00	394
56	Lada	-31	\N	-10	2	1	-56	\N	C	2019-12-20 22:14:09.31687+00	395
55	Ekonomibyggnad	-30	\N	-10	2	1	-55	\N	C	2019-12-20 22:14:09.31687+00	396
54	Okänt (efter 1795). interpretation av analysresultatet är inte möjligt eftersom bara ett prov analyserades 	-39	\N	-9	2	1	-54	\N	C	2019-12-20 22:14:09.31687+00	397
53	Trä, liggtimmer	-34	\N	-9	2	1	-53	\N	C	2019-12-20 22:14:09.31687+00	398
52	Huvudbyggnad	-31	\N	-9	2	1	-52	\N	C	2019-12-20 22:14:09.31687+00	399
51	Bostadshus	-30	\N	-9	2	1	-51	\N	C	2019-12-20 22:14:09.31687+00	400
50	Okänt (efter 1842). Fem av sex bjälkar dateras entydigt till V 1842/43. Den sjätte golvbjälke avverkades troligen redan på 1830-talet. (Linderson 2008)	-39	\N	-8	2	1	-50	\N	C	2019-12-20 22:14:09.31687+00	401
49	Mangårdsbyggnad	-31	\N	-8	2	1	-49	\N	C	2019-12-20 22:14:09.31687+00	402
48	Bostadshus	-30	\N	-8	2	1	-48	\N	C	2019-12-20 22:14:09.31687+00	403
47	Sadeltak; frontespis	-37	\N	-7	2	1	-47	\N	C	2019-12-20 22:14:09.31687+00	404
46	Puts	-36	\N	-7	2	1	-46	\N	C	2019-12-20 22:14:09.31687+00	405
45	Murverk, natursten, tegel	-34	\N	-7	2	1	-45	\N	C	2019-12-20 22:14:09.31687+00	406
44	2 Plan	-33	\N	-7	2	1	-44	\N	C	2019-12-20 22:14:09.31687+00	407
43	Mangårdsbyggnad	-31	\N	-7	2	1	-43	\N	C	2019-12-20 22:14:09.31687+00	408
42	Bostadshus	-30	\N	-7	2	1	-42	\N	C	2019-12-20 22:14:09.31687+00	409
41	Nybyggnad (efter 1765). Natten mot den 19 oktober 1765 uppstod en eldsvåda i ett brygghus strax intill Larmtorgets nordöstra hörn. Branden spred sig hastigt och pågick i drygt ett dygn. När släckningsarbetet avslutats hade bebyggelse på 131 tomter förstörts . I nuvarande kvarteret Hattmakaren stod enligt uppgift endast stenhuset på tomt nr. 36 kvar. Återuppbyggnaden påbörjades snart därefter av de som hade råd eller medel. Den dendrokronologiska dateringen visar alltså med stor säkerhet att eventuella tidigare hus på platsen förstördes i stadsbranden 1765. Dateringen visar också att man har avverkat timret till det nya och nuvarande huset, direkt under följande vinter. Vi har inga uppgifter som visar när huset stod klart men det kan antas troligt att det var inom ett eller ett par år. 	-39	\N	-6	2	1	-41	\N	C	2019-12-20 22:14:09.31687+00	410
40	Takpannor, enkupiga lertegel	-38	\N	-6	2	1	-40	\N	C	2019-12-20 22:14:09.31687+00	411
39	Mansardtak	-37	\N	-6	2	1	-39	\N	C	2019-12-20 22:14:09.31687+00	412
38	Målat, faluröd 	-36	\N	-6	2	1	-38	\N	C	2019-12-20 22:14:09.31687+00	413
37	Fyrkanttimmer med utknut	-35	\N	-6	2	1	-37	\N	C	2019-12-20 22:14:09.31687+00	414
36	Trä, liggtimmer	-34	\N	-6	2	1	-36	\N	C	2019-12-20 22:14:09.31687+00	415
32	Nybyggnad (1480-1720). Det dendroprov som togs i källaren ger två möjligheter. Enligt resultatet var dateringen 1720-tal, om inte bjälken var hämtad från sydsvenskt område, då den istället dateras till 1480-tal. För att få ett säkrare resultat skickades samma prov för 14C-datering. Denna gav med 95 % säkerhet en datering på mellan 1410-1635. Dessa två gemensamt gör att man kan våga dra slutsatsen att källarbyggnaden är byggd under samma tid som klosterkyrkan, d.v.s. slutet av 1400-talet.	-39	\N	-5	2	1	-32	\N	C	2019-12-20 22:14:09.31687+00	419
31	Takpannor, lertegel	-38	\N	-5	2	1	-31	\N	C	2019-12-20 22:14:09.31687+00	420
30	Sadeltak	-37	\N	-5	2	1	-30	\N	C	2019-12-20 22:14:09.31687+00	421
29	Ohuggen gråsten, delvis murtegel	-35	\N	-5	2	1	-29	\N	C	2019-12-20 22:14:09.31687+00	422
28	Murverk, natursten, granit; tegel	-34	\N	-5	2	1	-28	\N	C	2019-12-20 22:14:09.31687+00	423
27	1 Plan	-33	\N	-5	2	1	-27	\N	C	2019-12-20 22:14:09.31687+00	424
26	Stenkällare	-31	\N	-5	2	1	-26	\N	C	2019-12-20 22:14:09.31687+00	425
25	Ekonomibyggnad	-30	\N	-5	2	1	-25	\N	C	2019-12-20 22:14:09.31687+00	426
24	Okänt (efter 1780). Flöxhults säteri har troligen medeltida ursprung. Under 1500-talet och fram till 1729 ägdes gården av ätten Silversparre. Från mitten av 1800-talet finns inga adliga ägare till gården. 1896 anlade ägaren Rudolf Hagström ett glasbruk på säteriets ägor som 1910 lades ner. 1935 förvärvades fastigheten av brukspatron Gustav Meijer på Rydefors. Gården är fortfarande i denna släkts ägo. 2007  kunde golvbjälklaget samt en innerdörr i arrendatorbostadens källare dateras  till 1780-talet, virket till dörrtröskeln var däremot avverkat 1836/37. 	-39	\N	-4	2	1	-24	\N	C	2019-12-20 22:14:09.31687+00	427
23	Arrendatorbostad	-31	\N	-4	2	1	-23	\N	C	2019-12-20 22:14:09.31687+00	428
22	Bostadshus	-30	\N	-4	2	1	-22	\N	C	2019-12-20 22:14:09.31687+00	429
21	Nybyggnad (1100-1150). Under 1100-talets första hälft byggdes en första stenkyrka som ersatte en äldre träkyrka (trol. från 1000-talets mitt). 	-39	\N	-3	2	1	-21	\N	C	2019-12-20 22:14:09.31687+00	430
20	Tegel; plåt	-38	\N	-3	2	1	-20	\N	C	2019-12-20 22:14:09.31687+00	431
19	Sadeltak; lanternin	-37	\N	-3	2	1	-19	\N	C	2019-12-20 22:14:09.31687+00	432
18	Puts	-36	\N	-3	2	1	-18	\N	C	2019-12-20 22:14:09.31687+00	433
17	Murverk, natursten	-34	\N	-3	2	1	-17	\N	C	2019-12-20 22:14:09.31687+00	434
16	Långhus; Västtorn; Vapenhus; Kapell; Sakristia	-33	\N	-3	2	1	-16	\N	C	2019-12-20 22:14:09.31687+00	435
15	Salkyrka	-32	\N	-3	2	1	-15	\N	C	2019-12-20 22:14:09.31687+00	436
14	Kyrka	-31	\N	-3	2	1	-14	\N	C	2019-12-20 22:14:09.31687+00	437
13	Kyrka	-30	\N	-3	2	1	-13	\N	C	2019-12-20 22:14:09.31687+00	438
12	Nybyggnad (1170-1250). Förmodligen omkring 1170 började man bygga en stenkyrka runt den lilla stavbyggnaden. Denna stenkyrka, som måste har stått färdig någon gång i mitten av 1200-talet, var en typisk öländsk klövsadelkyrka. 	-39	\N	-2	2	1	-12	\N	C	2019-12-20 22:14:09.31687+00	439
11	Takpannor, lertegel	-38	\N	-2	2	1	-11	\N	C	2019-12-20 22:14:09.31687+00	440
10	Sadeltak; lanternin	-37	\N	-2	2	1	-10	\N	C	2019-12-20 22:14:09.31687+00	441
9	Puts	-36	\N	-2	2	1	-9	\N	C	2019-12-20 22:14:09.31687+00	442
8	Murverk, natursten	-34	\N	-2	2	1	-8	\N	C	2019-12-20 22:14:09.31687+00	443
7	Långhus; Västtorn	-33	\N	-2	2	1	-7	\N	C	2019-12-20 22:14:09.31687+00	444
6	Salkyrka	-32	\N	-2	2	1	-6	\N	C	2019-12-20 22:14:09.31687+00	445
5	Kyrka	-31	\N	-2	2	1	-5	\N	C	2019-12-20 22:14:09.31687+00	446
4	Kyrka	-30	\N	-2	2	1	-4	\N	C	2019-12-20 22:14:09.31687+00	447
3	Mansardtak	-37	\N	-1	2	1	-3	\N	C	2019-12-20 22:14:09.31687+00	448
2	Stall	-31	\N	-1	2	1	-2	\N	C	2019-12-20 22:14:09.31687+00	449
1	Ekonomibyggnad	-30	\N	-1	2	1	-1	\N	C	2019-12-20 22:14:09.31687+00	450
1888	Open-air; Inland	3	\N	-944	4	1	-1888	\N	C	2019-12-20 22:14:28.053842+00	451
1887	Open-air; Inland	3	\N	-943	4	1	-1887	\N	C	2019-12-20 22:14:28.053842+00	452
1886	Open-air; Inland	3	\N	-942	4	1	-1886	\N	C	2019-12-20 22:14:28.053842+00	453
1885	Open-air; Inland	3	\N	-941	4	1	-1885	\N	C	2019-12-20 22:14:28.053842+00	454
1884	Open-air; Inland	3	\N	-940	4	1	-1884	\N	C	2019-12-20 22:14:28.053842+00	455
1883	Open-air; Inland	3	\N	-939	4	1	-1883	\N	C	2019-12-20 22:14:28.053842+00	456
1882	Open-air; Inland	3	\N	-938	4	1	-1882	\N	C	2019-12-20 22:14:28.053842+00	457
1881	Open-air; Inland	3	\N	-937	4	1	-1881	\N	C	2019-12-20 22:14:28.053842+00	458
1880	Open-air; Inland	3	\N	-936	4	1	-1880	\N	C	2019-12-20 22:14:28.053842+00	459
1879	Open-air; Inland	3	\N	-935	4	1	-1879	\N	C	2019-12-20 22:14:28.053842+00	460
1878	Open-air; Lake shore	3	\N	-934	4	1	-1878	\N	C	2019-12-20 22:14:28.053842+00	461
1877	Open-air; Lake shore	3	\N	-933	4	1	-1877	\N	C	2019-12-20 22:14:28.053842+00	462
1876	Open-air; Lake shore	3	\N	-932	4	1	-1876	\N	C	2019-12-20 22:14:28.053842+00	463
1875	Open-air; Lake shore	3	\N	-931	4	1	-1875	\N	C	2019-12-20 22:14:28.053842+00	464
1874	Open-air; Lake shore	3	\N	-930	4	1	-1874	\N	C	2019-12-20 22:14:28.053842+00	465
1873	Open-air; Lake shore	3	\N	-929	4	1	-1873	\N	C	2019-12-20 22:14:28.053842+00	466
1872	Open-air; Lake shore	3	\N	-928	4	1	-1872	\N	C	2019-12-20 22:14:28.053842+00	467
1871	Open-air; Lake shore	3	\N	-927	4	1	-1871	\N	C	2019-12-20 22:14:28.053842+00	468
1870	Open-air; Lake shore	3	\N	-926	4	1	-1870	\N	C	2019-12-20 22:14:28.053842+00	469
1869	Open-air; Lake shore	3	\N	-925	4	1	-1869	\N	C	2019-12-20 22:14:28.053842+00	470
1868	Open-air; Lake shore	3	\N	-924	4	1	-1868	\N	C	2019-12-20 22:14:28.053842+00	471
1867	Open-air; Lake shore	3	\N	-923	4	1	-1867	\N	C	2019-12-20 22:14:28.053842+00	472
1866	Open-air; Lake shore	3	\N	-922	4	1	-1866	\N	C	2019-12-20 22:14:28.053842+00	473
1865	Open-air; Inland	3	\N	-921	4	1	-1865	\N	C	2019-12-20 22:14:28.053842+00	474
1864	Open-air; Inland	3	\N	-920	4	1	-1864	\N	C	2019-12-20 22:14:28.053842+00	475
1863	Open-air; Inland	3	\N	-919	4	1	-1863	\N	C	2019-12-20 22:14:28.053842+00	476
1862	Open-air; Inland	3	\N	-918	4	1	-1862	\N	C	2019-12-20 22:14:28.053842+00	477
1861	Open-air; Inland	3	\N	-917	4	1	-1861	\N	C	2019-12-20 22:14:28.053842+00	478
1860	Open-air; Inland	3	\N	-916	4	1	-1860	\N	C	2019-12-20 22:14:28.053842+00	479
1859	Open-air; Inland	3	\N	-915	4	1	-1859	\N	C	2019-12-20 22:14:28.053842+00	480
1858	Open-air; Inland	3	\N	-914	4	1	-1858	\N	C	2019-12-20 22:14:28.053842+00	481
1857	Open-air; Inland	3	\N	-913	4	1	-1857	\N	C	2019-12-20 22:14:28.053842+00	482
1856	Open-air; Inland	3	\N	-912	4	1	-1856	\N	C	2019-12-20 22:14:28.053842+00	483
1855	Open-air; Inland	3	\N	-911	4	1	-1855	\N	C	2019-12-20 22:14:28.053842+00	484
1853	Open-air; Inland	3	\N	-909	4	1	-1853	\N	C	2019-12-20 22:14:28.053842+00	486
1852	Open-air; Inland	3	\N	-908	4	1	-1852	\N	C	2019-12-20 22:14:28.053842+00	487
1851	Open-air; Inland	3	\N	-907	4	1	-1851	\N	C	2019-12-20 22:14:28.053842+00	488
1850	Open-air; Inland	3	\N	-906	4	1	-1850	\N	C	2019-12-20 22:14:28.053842+00	489
1849	Open-air; Inland	3	\N	-905	4	1	-1849	\N	C	2019-12-20 22:14:28.053842+00	490
1848	Open-air; Inland	3	\N	-904	4	1	-1848	\N	C	2019-12-20 22:14:28.053842+00	491
1847	Open-air; Inland	3	\N	-903	4	1	-1847	\N	C	2019-12-20 22:14:28.053842+00	492
1846	Open-air; Inland	3	\N	-902	4	1	-1846	\N	C	2019-12-20 22:14:28.053842+00	493
1845	Open-air; Inland	3	\N	-901	4	1	-1845	\N	C	2019-12-20 22:14:28.053842+00	494
1844	Open-air; Inland	3	\N	-900	4	1	-1844	\N	C	2019-12-20 22:14:28.053842+00	495
1843	Open-air; Inland	3	\N	-899	4	1	-1843	\N	C	2019-12-20 22:14:28.053842+00	496
1842	Open-air; Inland	3	\N	-898	4	1	-1842	\N	C	2019-12-20 22:14:28.053842+00	497
1841	Open-air; Inland	3	\N	-897	4	1	-1841	\N	C	2019-12-20 22:14:28.053842+00	498
1840	Open-air; Inland	3	\N	-896	4	1	-1840	\N	C	2019-12-20 22:14:28.053842+00	499
1839	Open-air; Inland	3	\N	-895	4	1	-1839	\N	C	2019-12-20 22:14:28.053842+00	500
1838	Open-air; Inland	3	\N	-894	4	1	-1838	\N	C	2019-12-20 22:14:28.053842+00	501
1837	Open-air; Inland	3	\N	-893	4	1	-1837	\N	C	2019-12-20 22:14:28.053842+00	502
1836	Open-air; Inland	3	\N	-892	4	1	-1836	\N	C	2019-12-20 22:14:28.053842+00	503
1835	Open-air; Inland	3	\N	-891	4	1	-1835	\N	C	2019-12-20 22:14:28.053842+00	504
1834	Open-air; Inland	3	\N	-890	4	1	-1834	\N	C	2019-12-20 22:14:28.053842+00	505
1833	Open-air; Close to the coast	3	\N	-889	4	1	-1833	\N	C	2019-12-20 22:14:28.053842+00	506
1832	Open-air; Close to the coast	3	\N	-888	4	1	-1832	\N	C	2019-12-20 22:14:28.053842+00	507
1831	Open-air; Close to the coast	3	\N	-887	4	1	-1831	\N	C	2019-12-20 22:14:28.053842+00	508
1830	Open-air; Close to the coast	3	\N	-886	4	1	-1830	\N	C	2019-12-20 22:14:28.053842+00	509
1829	Open-air; Close to the coast	3	\N	-885	4	1	-1829	\N	C	2019-12-20 22:14:28.053842+00	510
1828	Open-air; Close to the coast	3	\N	-884	4	1	-1828	\N	C	2019-12-20 22:14:28.053842+00	511
1827	Open-air; Close to the coast	3	\N	-883	4	1	-1827	\N	C	2019-12-20 22:14:28.053842+00	512
1826	Open-air; Close to the coast	3	\N	-882	4	1	-1826	\N	C	2019-12-20 22:14:28.053842+00	513
1825	Open-air; Close to the coast	3	\N	-881	4	1	-1825	\N	C	2019-12-20 22:14:28.053842+00	514
1824	Open-air; Close to the coast	3	\N	-880	4	1	-1824	\N	C	2019-12-20 22:14:28.053842+00	515
1823	Open-air; Close to the coast	3	\N	-879	4	1	-1823	\N	C	2019-12-20 22:14:28.053842+00	516
1822	Open-air; Close to the coast	3	\N	-878	4	1	-1822	\N	C	2019-12-20 22:14:28.053842+00	517
1821	Open-air; Close to the coast	3	\N	-877	4	1	-1821	\N	C	2019-12-20 22:14:28.053842+00	518
1820	Open-air; Close to the coast	3	\N	-876	4	1	-1820	\N	C	2019-12-20 22:14:28.053842+00	519
1819	Open-air; Close to the coast	3	\N	-875	4	1	-1819	\N	C	2019-12-20 22:14:28.053842+00	520
1818	Open-air; Close to the coast	3	\N	-874	4	1	-1818	\N	C	2019-12-20 22:14:28.053842+00	521
1817	Open-air; Close to the coast	3	\N	-873	4	1	-1817	\N	C	2019-12-20 22:14:28.053842+00	522
1816	Open-air; Close to the coast	3	\N	-872	4	1	-1816	\N	C	2019-12-20 22:14:28.053842+00	523
1815	Open-air; Close to the coast	3	\N	-871	4	1	-1815	\N	C	2019-12-20 22:14:28.053842+00	524
1814	Open-air; Close to the coast	3	\N	-870	4	1	-1814	\N	C	2019-12-20 22:14:28.053842+00	525
1813	Open-air; Close to the coast	3	\N	-869	4	1	-1813	\N	C	2019-12-20 22:14:28.053842+00	526
1812	Open-air; Close to the coast	3	\N	-868	4	1	-1812	\N	C	2019-12-20 22:14:28.053842+00	527
1811	Open-air; Inland	3	\N	-867	4	1	-1811	\N	C	2019-12-20 22:14:28.053842+00	528
1810	Open-air; Inland	3	\N	-866	4	1	-1810	\N	C	2019-12-20 22:14:28.053842+00	529
1809	Open-air; Inland	3	\N	-865	4	1	-1809	\N	C	2019-12-20 22:14:28.053842+00	530
1808	Open-air; Inland	3	\N	-864	4	1	-1808	\N	C	2019-12-20 22:14:28.053842+00	531
1807	Open-air; Inland	3	\N	-863	4	1	-1807	\N	C	2019-12-20 22:14:28.053842+00	532
1806	Open-air; Close to the coast	3	\N	-862	4	1	-1806	\N	C	2019-12-20 22:14:28.053842+00	533
1805	Shell midden; Lake shore	3	\N	-861	4	1	-1805	\N	C	2019-12-20 22:14:28.053842+00	534
1804	Shell midden; Lake shore	3	\N	-860	4	1	-1804	\N	C	2019-12-20 22:14:28.053842+00	535
1803	Shell midden; Lake shore	3	\N	-859	4	1	-1803	\N	C	2019-12-20 22:14:28.053842+00	536
1802	Shell midden; Lake shore	3	\N	-858	4	1	-1802	\N	C	2019-12-20 22:14:28.053842+00	537
1801	Shell midden; Lake shore	3	\N	-857	4	1	-1801	\N	C	2019-12-20 22:14:28.053842+00	538
1800	Shell midden; Lake shore	3	\N	-856	4	1	-1800	\N	C	2019-12-20 22:14:28.053842+00	539
1799	Shell midden; Lake shore	3	\N	-855	4	1	-1799	\N	C	2019-12-20 22:14:28.053842+00	540
1798	Shell midden; Lake shore	3	\N	-854	4	1	-1798	\N	C	2019-12-20 22:14:28.053842+00	541
1797	Shell midden; Lake shore	3	\N	-853	4	1	-1797	\N	C	2019-12-20 22:14:28.053842+00	542
1796	Shell midden; Lake shore	3	\N	-852	4	1	-1796	\N	C	2019-12-20 22:14:28.053842+00	543
1795	Shell midden; Lake shore	3	\N	-851	4	1	-1795	\N	C	2019-12-20 22:14:28.053842+00	544
1794	Shell midden; Lake shore	3	\N	-850	4	1	-1794	\N	C	2019-12-20 22:14:28.053842+00	545
1793	Shell midden; Lake shore	3	\N	-849	4	1	-1793	\N	C	2019-12-20 22:14:28.053842+00	546
1792	Shell midden; Lake shore	3	\N	-848	4	1	-1792	\N	C	2019-12-20 22:14:28.053842+00	547
1791	Shell midden; Lake shore	3	\N	-847	4	1	-1791	\N	C	2019-12-20 22:14:28.053842+00	548
1790	Shell midden; Lake shore	3	\N	-846	4	1	-1790	\N	C	2019-12-20 22:14:28.053842+00	549
1789	Shell midden; Lake shore	3	\N	-845	4	1	-1789	\N	C	2019-12-20 22:14:28.053842+00	550
1788	Shell midden; Lake shore	3	\N	-844	4	1	-1788	\N	C	2019-12-20 22:14:28.053842+00	551
1787	Shell midden; Lake shore	3	\N	-843	4	1	-1787	\N	C	2019-12-20 22:14:28.053842+00	552
1786	Shell midden; Lake shore	3	\N	-842	4	1	-1786	\N	C	2019-12-20 22:14:28.053842+00	553
1785	Shell midden; Lake shore	3	\N	-841	4	1	-1785	\N	C	2019-12-20 22:14:28.053842+00	554
1784	Shell midden; Lake shore	3	\N	-840	4	1	-1784	\N	C	2019-12-20 22:14:28.053842+00	555
1783	Shell midden; Lake shore	3	\N	-839	4	1	-1783	\N	C	2019-12-20 22:14:28.053842+00	556
1782	Shell midden; Lake shore	3	\N	-838	4	1	-1782	\N	C	2019-12-20 22:14:28.053842+00	557
1781	Shell midden; Lake shore	3	\N	-837	4	1	-1781	\N	C	2019-12-20 22:14:28.053842+00	558
1780	Shell midden; Lake shore	3	\N	-836	4	1	-1780	\N	C	2019-12-20 22:14:28.053842+00	559
1779	Shell midden; Lake shore	3	\N	-835	4	1	-1779	\N	C	2019-12-20 22:14:28.053842+00	560
1778	Shell midden; Lake shore	3	\N	-834	4	1	-1778	\N	C	2019-12-20 22:14:28.053842+00	561
1777	Shell midden; Lake shore	3	\N	-833	4	1	-1777	\N	C	2019-12-20 22:14:28.053842+00	562
1776	Shell midden; Lake shore	3	\N	-832	4	1	-1776	\N	C	2019-12-20 22:14:28.053842+00	563
1775	Shell midden; Lake shore	3	\N	-831	4	1	-1775	\N	C	2019-12-20 22:14:28.053842+00	564
1774	Shell midden; Lake shore	3	\N	-830	4	1	-1774	\N	C	2019-12-20 22:14:28.053842+00	565
1773	Shell midden; Lake shore	3	\N	-829	4	1	-1773	\N	C	2019-12-20 22:14:28.053842+00	566
1772	Shell midden; Lake shore	3	\N	-828	4	1	-1772	\N	C	2019-12-20 22:14:28.053842+00	567
1771	Shell midden; Lake shore	3	\N	-827	4	1	-1771	\N	C	2019-12-20 22:14:28.053842+00	568
1770	Shell midden; Lake shore	3	\N	-826	4	1	-1770	\N	C	2019-12-20 22:14:28.053842+00	569
1769	Shell midden; Lake shore	3	\N	-825	4	1	-1769	\N	C	2019-12-20 22:14:28.053842+00	570
1768	Shell midden; Lake shore	3	\N	-824	4	1	-1768	\N	C	2019-12-20 22:14:28.053842+00	571
1767	Shell midden; Lake shore	3	\N	-823	4	1	-1767	\N	C	2019-12-20 22:14:28.053842+00	572
1766	Shell midden; Lake shore	3	\N	-822	4	1	-1766	\N	C	2019-12-20 22:14:28.053842+00	573
1765	Shell midden; Lake shore	3	\N	-821	4	1	-1765	\N	C	2019-12-20 22:14:28.053842+00	574
1764	Shell midden; Lake shore	3	\N	-820	4	1	-1764	\N	C	2019-12-20 22:14:28.053842+00	575
1763	Shell midden; Lake shore	3	\N	-819	4	1	-1763	\N	C	2019-12-20 22:14:28.053842+00	576
1762	Shell midden; Lake shore	3	\N	-818	4	1	-1762	\N	C	2019-12-20 22:14:28.053842+00	577
1761	Shell midden; Lake shore	3	\N	-817	4	1	-1761	\N	C	2019-12-20 22:14:28.053842+00	578
1760	Shell midden; Lake shore	3	\N	-816	4	1	-1760	\N	C	2019-12-20 22:14:28.053842+00	579
1759	Shell midden; Lake shore	3	\N	-815	4	1	-1759	\N	C	2019-12-20 22:14:28.053842+00	580
1758	Shell midden; Lake shore	3	\N	-814	4	1	-1758	\N	C	2019-12-20 22:14:28.053842+00	581
1757	Shell midden; Lake shore	3	\N	-813	4	1	-1757	\N	C	2019-12-20 22:14:28.053842+00	582
1756	Shell midden; Lake shore	3	\N	-812	4	1	-1756	\N	C	2019-12-20 22:14:28.053842+00	583
1755	Shell midden; Lake shore	3	\N	-811	4	1	-1755	\N	C	2019-12-20 22:14:28.053842+00	584
1754	Shell midden; Lake shore	3	\N	-810	4	1	-1754	\N	C	2019-12-20 22:14:28.053842+00	585
1753	Shell midden; Lake shore	3	\N	-809	4	1	-1753	\N	C	2019-12-20 22:14:28.053842+00	586
1752	Shell midden; Lake shore	3	\N	-808	4	1	-1752	\N	C	2019-12-20 22:14:28.053842+00	587
1751	Shell midden; Lake shore	3	\N	-807	4	1	-1751	\N	C	2019-12-20 22:14:28.053842+00	588
1750	Shell midden; Lake shore	3	\N	-806	4	1	-1750	\N	C	2019-12-20 22:14:28.053842+00	589
1749	Shell midden; Lake shore	3	\N	-805	4	1	-1749	\N	C	2019-12-20 22:14:28.053842+00	590
1748	Shell midden; Lake shore	3	\N	-804	4	1	-1748	\N	C	2019-12-20 22:14:28.053842+00	591
1747	Shell midden; Lake shore	3	\N	-803	4	1	-1747	\N	C	2019-12-20 22:14:28.053842+00	592
1746	Shell midden; Lake shore	3	\N	-802	4	1	-1746	\N	C	2019-12-20 22:14:28.053842+00	593
1745	Shell midden; Lake shore	3	\N	-801	4	1	-1745	\N	C	2019-12-20 22:14:28.053842+00	594
1744	Shell midden; Lake shore	3	\N	-800	4	1	-1744	\N	C	2019-12-20 22:14:28.053842+00	595
1743	Shell midden; Lake shore	3	\N	-799	4	1	-1743	\N	C	2019-12-20 22:14:28.053842+00	596
1742	Shell midden; Lake shore	3	\N	-798	4	1	-1742	\N	C	2019-12-20 22:14:28.053842+00	597
1741	Shell midden; Lake shore	3	\N	-797	4	1	-1741	\N	C	2019-12-20 22:14:28.053842+00	598
1740	Shell midden; Lake shore	3	\N	-796	4	1	-1740	\N	C	2019-12-20 22:14:28.053842+00	599
1739	Shell midden; Lake shore	3	\N	-795	4	1	-1739	\N	C	2019-12-20 22:14:28.053842+00	600
1738	Shell midden; Lake shore	3	\N	-794	4	1	-1738	\N	C	2019-12-20 22:14:28.053842+00	601
1737	Shell midden; Lake shore	3	\N	-793	4	1	-1737	\N	C	2019-12-20 22:14:28.053842+00	602
1736	Shell midden; Lake shore	3	\N	-792	4	1	-1736	\N	C	2019-12-20 22:14:28.053842+00	603
1735	Shell midden; Lake shore	3	\N	-791	4	1	-1735	\N	C	2019-12-20 22:14:28.053842+00	604
1734	Shell midden; Lake shore	3	\N	-790	4	1	-1734	\N	C	2019-12-20 22:14:28.053842+00	605
1733	Shell midden; Lake shore	3	\N	-789	4	1	-1733	\N	C	2019-12-20 22:14:28.053842+00	606
1732	Shell midden; Lake shore	3	\N	-788	4	1	-1732	\N	C	2019-12-20 22:14:28.053842+00	607
1731	Shell midden; Lake shore	3	\N	-787	4	1	-1731	\N	C	2019-12-20 22:14:28.053842+00	608
1730	Shell midden; Lake shore	3	\N	-786	4	1	-1730	\N	C	2019-12-20 22:14:28.053842+00	609
1729	Shell midden; Lake shore	3	\N	-785	4	1	-1729	\N	C	2019-12-20 22:14:28.053842+00	610
1728	Shell midden; Lake shore	3	\N	-784	4	1	-1728	\N	C	2019-12-20 22:14:28.053842+00	611
1727	Shell midden; Lake shore	3	\N	-783	4	1	-1727	\N	C	2019-12-20 22:14:28.053842+00	612
1726	Shell midden; Lake shore	3	\N	-782	4	1	-1726	\N	C	2019-12-20 22:14:28.053842+00	613
1725	Open-air; Lake shore	3	\N	-781	4	1	-1725	\N	C	2019-12-20 22:14:28.053842+00	614
1724	Open-air; Lake shore	3	\N	-780	4	1	-1724	\N	C	2019-12-20 22:14:28.053842+00	615
1723	Open-air; Lake shore	3	\N	-779	4	1	-1723	\N	C	2019-12-20 22:14:28.053842+00	616
1722	Open-air; Lake shore	3	\N	-778	4	1	-1722	\N	C	2019-12-20 22:14:28.053842+00	617
1721	Open-air; Lake shore	3	\N	-777	4	1	-1721	\N	C	2019-12-20 22:14:28.053842+00	618
1720	Open-air; Lake shore	3	\N	-776	4	1	-1720	\N	C	2019-12-20 22:14:28.053842+00	619
1719	Open-air; Lake shore	3	\N	-775	4	1	-1719	\N	C	2019-12-20 22:14:28.053842+00	620
1718	Open-air; Lake shore	3	\N	-774	4	1	-1718	\N	C	2019-12-20 22:14:28.053842+00	621
1717	Open-air; Lake shore	3	\N	-773	4	1	-1717	\N	C	2019-12-20 22:14:28.053842+00	622
1716	Open-air; Lake shore	3	\N	-772	4	1	-1716	\N	C	2019-12-20 22:14:28.053842+00	623
1715	Open-air; Lake shore	3	\N	-771	4	1	-1715	\N	C	2019-12-20 22:14:28.053842+00	624
1714	Open-air; Lake shore	3	\N	-770	4	1	-1714	\N	C	2019-12-20 22:14:28.053842+00	625
1713	Open-air; Lake shore	3	\N	-769	4	1	-1713	\N	C	2019-12-20 22:14:28.053842+00	626
1712	Open-air; Lake shore	3	\N	-768	4	1	-1712	\N	C	2019-12-20 22:14:28.053842+00	627
1711	Open-air; Lake shore	3	\N	-767	4	1	-1711	\N	C	2019-12-20 22:14:28.053842+00	628
1710	Open-air; Lake shore	3	\N	-766	4	1	-1710	\N	C	2019-12-20 22:14:28.053842+00	629
1709	Open-air; Lake shore	3	\N	-765	4	1	-1709	\N	C	2019-12-20 22:14:28.053842+00	630
1708	Open-air; Lake shore	3	\N	-764	4	1	-1708	\N	C	2019-12-20 22:14:28.053842+00	631
1707	Open-air; Lake shore	3	\N	-763	4	1	-1707	\N	C	2019-12-20 22:14:28.053842+00	632
1706	Open-air; Lake shore	3	\N	-762	4	1	-1706	\N	C	2019-12-20 22:14:28.053842+00	633
1705	Open-air; Lake shore	3	\N	-761	4	1	-1705	\N	C	2019-12-20 22:14:28.053842+00	634
1704	Open-air; Lake shore	3	\N	-760	4	1	-1704	\N	C	2019-12-20 22:14:28.053842+00	635
1703	Open-air; Lake shore	3	\N	-759	4	1	-1703	\N	C	2019-12-20 22:14:28.053842+00	636
1702	Open-air; Lake shore	3	\N	-758	4	1	-1702	\N	C	2019-12-20 22:14:28.053842+00	637
1701	Open-air; Lake shore	3	\N	-757	4	1	-1701	\N	C	2019-12-20 22:14:28.053842+00	638
1700	Open-air; Lake shore	3	\N	-756	4	1	-1700	\N	C	2019-12-20 22:14:28.053842+00	639
1699	Open-air; Lake shore	3	\N	-755	4	1	-1699	\N	C	2019-12-20 22:14:28.053842+00	640
1698	Open-air; Lake shore	3	\N	-754	4	1	-1698	\N	C	2019-12-20 22:14:28.053842+00	641
1697	Open-air; Lake shore	3	\N	-753	4	1	-1697	\N	C	2019-12-20 22:14:28.053842+00	642
1696	Open-air; Lake shore	3	\N	-752	4	1	-1696	\N	C	2019-12-20 22:14:28.053842+00	643
1695	Open-air; Lake shore	3	\N	-751	4	1	-1695	\N	C	2019-12-20 22:14:28.053842+00	644
1694	Open-air; Lake shore	3	\N	-750	4	1	-1694	\N	C	2019-12-20 22:14:28.053842+00	645
1693	Open-air; Lake shore	3	\N	-749	4	1	-1693	\N	C	2019-12-20 22:14:28.053842+00	646
1692	Open-air; Lake shore	3	\N	-748	4	1	-1692	\N	C	2019-12-20 22:14:28.053842+00	647
1691	Open-air; Lake shore	3	\N	-747	4	1	-1691	\N	C	2019-12-20 22:14:28.053842+00	648
1690	Open-air; Lake shore	3	\N	-746	4	1	-1690	\N	C	2019-12-20 22:14:28.053842+00	649
1689	Open-air; Lake shore	3	\N	-745	4	1	-1689	\N	C	2019-12-20 22:14:28.053842+00	650
1688	Open-air; Lake shore	3	\N	-744	4	1	-1688	\N	C	2019-12-20 22:14:28.053842+00	651
1687	Open-air; Lake shore	3	\N	-743	4	1	-1687	\N	C	2019-12-20 22:14:28.053842+00	652
1686	Open-air; Lake shore	3	\N	-742	4	1	-1686	\N	C	2019-12-20 22:14:28.053842+00	653
1685	Open-air; Lake shore	3	\N	-741	4	1	-1685	\N	C	2019-12-20 22:14:28.053842+00	654
1684	Open-air; Lake shore	3	\N	-740	4	1	-1684	\N	C	2019-12-20 22:14:28.053842+00	655
1683	Open-air; Lake shore	3	\N	-739	4	1	-1683	\N	C	2019-12-20 22:14:28.053842+00	656
1682	Open-air; Lake shore	3	\N	-738	4	1	-1682	\N	C	2019-12-20 22:14:28.053842+00	657
1681	Open-air; Lake shore	3	\N	-737	4	1	-1681	\N	C	2019-12-20 22:14:28.053842+00	658
1680	Open-air; Lake shore	3	\N	-736	4	1	-1680	\N	C	2019-12-20 22:14:28.053842+00	659
1679	Open-air; Lake shore	3	\N	-735	4	1	-1679	\N	C	2019-12-20 22:14:28.053842+00	660
1678	Open-air; Lake shore	3	\N	-734	4	1	-1678	\N	C	2019-12-20 22:14:28.053842+00	661
1677	Open-air; Lake shore	3	\N	-733	4	1	-1677	\N	C	2019-12-20 22:14:28.053842+00	662
1676	Open-air; Lake shore	3	\N	-732	4	1	-1676	\N	C	2019-12-20 22:14:28.053842+00	663
1675	Open-air; Lake shore	3	\N	-731	4	1	-1675	\N	C	2019-12-20 22:14:28.053842+00	664
1674	Open-air; Lake shore	3	\N	-730	4	1	-1674	\N	C	2019-12-20 22:14:28.053842+00	665
1673	Open-air; Lake shore	3	\N	-729	4	1	-1673	\N	C	2019-12-20 22:14:28.053842+00	666
1672	Open-air; Lake shore	3	\N	-728	4	1	-1672	\N	C	2019-12-20 22:14:28.053842+00	667
1671	Open-air; Lake shore	3	\N	-727	4	1	-1671	\N	C	2019-12-20 22:14:28.053842+00	668
1670	Open-air; Lake shore	3	\N	-726	4	1	-1670	\N	C	2019-12-20 22:14:28.053842+00	669
1669	Open-air; Lake shore	3	\N	-725	4	1	-1669	\N	C	2019-12-20 22:14:28.053842+00	670
1668	Open-air; Lake shore	3	\N	-724	4	1	-1668	\N	C	2019-12-20 22:14:28.053842+00	671
1667	Open-air; Lake shore	3	\N	-723	4	1	-1667	\N	C	2019-12-20 22:14:28.053842+00	672
1666	Open-air; Lake shore	3	\N	-722	4	1	-1666	\N	C	2019-12-20 22:14:28.053842+00	673
1665	Open-air; Lake shore	3	\N	-721	4	1	-1665	\N	C	2019-12-20 22:14:28.053842+00	674
1664	Open-air; Lake shore	3	\N	-720	4	1	-1664	\N	C	2019-12-20 22:14:28.053842+00	675
1663	Open-air; Lake shore	3	\N	-719	4	1	-1663	\N	C	2019-12-20 22:14:28.053842+00	676
1662	Open-air; Lake shore	3	\N	-718	4	1	-1662	\N	C	2019-12-20 22:14:28.053842+00	677
1661	Open-air; Lake shore	3	\N	-717	4	1	-1661	\N	C	2019-12-20 22:14:28.053842+00	678
1660	Open-air; Lake shore	3	\N	-716	4	1	-1660	\N	C	2019-12-20 22:14:28.053842+00	679
1659	Open-air; Lake shore	3	\N	-715	4	1	-1659	\N	C	2019-12-20 22:14:28.053842+00	680
1658	Open-air; Lake shore	3	\N	-714	4	1	-1658	\N	C	2019-12-20 22:14:28.053842+00	681
1657	Open-air; Lake shore	3	\N	-713	4	1	-1657	\N	C	2019-12-20 22:14:28.053842+00	682
1656	Open-air; Lake shore	3	\N	-712	4	1	-1656	\N	C	2019-12-20 22:14:28.053842+00	683
1655	Open-air; Lake shore	3	\N	-711	4	1	-1655	\N	C	2019-12-20 22:14:28.053842+00	684
1654	Open-air; Lake shore	3	\N	-710	4	1	-1654	\N	C	2019-12-20 22:14:28.053842+00	685
1653	Open-air; Lake shore	3	\N	-709	4	1	-1653	\N	C	2019-12-20 22:14:28.053842+00	686
1652	Open-air; Lake shore	3	\N	-708	4	1	-1652	\N	C	2019-12-20 22:14:28.053842+00	687
1651	Open-air; Lake shore	3	\N	-707	4	1	-1651	\N	C	2019-12-20 22:14:28.053842+00	688
1650	Open-air; Lake shore	3	\N	-706	4	1	-1650	\N	C	2019-12-20 22:14:28.053842+00	689
1649	Open-air; Lake shore	3	\N	-705	4	1	-1649	\N	C	2019-12-20 22:14:28.053842+00	690
1648	Open-air; Lake shore	3	\N	-704	4	1	-1648	\N	C	2019-12-20 22:14:28.053842+00	691
1647	Open-air; Lake shore	3	\N	-703	4	1	-1647	\N	C	2019-12-20 22:14:28.053842+00	692
1646	Open-air; Lake shore	3	\N	-702	4	1	-1646	\N	C	2019-12-20 22:14:28.053842+00	693
1645	Open-air; Lake shore	3	\N	-701	4	1	-1645	\N	C	2019-12-20 22:14:28.053842+00	694
1644	Open-air; Lake shore	3	\N	-700	4	1	-1644	\N	C	2019-12-20 22:14:28.053842+00	695
1643	Open-air; Close to the coast	3	\N	-699	4	1	-1643	\N	C	2019-12-20 22:14:28.053842+00	696
1642	Open-air; Close to the coast	3	\N	-698	4	1	-1642	\N	C	2019-12-20 22:14:28.053842+00	697
1641	Open-air; Close to the coast	3	\N	-697	4	1	-1641	\N	C	2019-12-20 22:14:28.053842+00	698
1640	Open-air; Close to the coast	3	\N	-696	4	1	-1640	\N	C	2019-12-20 22:14:28.053842+00	699
1639	Open-air; Close to the coast	3	\N	-695	4	1	-1639	\N	C	2019-12-20 22:14:28.053842+00	700
1638	Open-air; Close to the coast	3	\N	-694	4	1	-1638	\N	C	2019-12-20 22:14:28.053842+00	701
1637	Open-air; Close to the coast	3	\N	-693	4	1	-1637	\N	C	2019-12-20 22:14:28.053842+00	702
1636	Open-air; Close to the coast	3	\N	-692	4	1	-1636	\N	C	2019-12-20 22:14:28.053842+00	703
1635	Open-air; Close to the coast	3	\N	-691	4	1	-1635	\N	C	2019-12-20 22:14:28.053842+00	704
1634	Open-air; Close to the coast	3	\N	-690	4	1	-1634	\N	C	2019-12-20 22:14:28.053842+00	705
1633	Open-air; Close to the coast	3	\N	-689	4	1	-1633	\N	C	2019-12-20 22:14:28.053842+00	706
1632	Open-air; Close to the coast	3	\N	-688	4	1	-1632	\N	C	2019-12-20 22:14:28.053842+00	707
1631	Open-air; Close to the coast	3	\N	-687	4	1	-1631	\N	C	2019-12-20 22:14:28.053842+00	708
1630	Open-air; Close to the coast	3	\N	-686	4	1	-1630	\N	C	2019-12-20 22:14:28.053842+00	709
1629	Open-air; Close to the coast	3	\N	-685	4	1	-1629	\N	C	2019-12-20 22:14:28.053842+00	710
1628	Open-air; Close to the coast	3	\N	-684	4	1	-1628	\N	C	2019-12-20 22:14:28.053842+00	711
1627	Open-air; Close to the coast	3	\N	-683	4	1	-1627	\N	C	2019-12-20 22:14:28.053842+00	712
1626	Open-air; Close to the coast	3	\N	-682	4	1	-1626	\N	C	2019-12-20 22:14:28.053842+00	713
1625	Open-air; Close to the coast	3	\N	-681	4	1	-1625	\N	C	2019-12-20 22:14:28.053842+00	714
1624	Open-air; Close to the coast	3	\N	-680	4	1	-1624	\N	C	2019-12-20 22:14:28.053842+00	715
1623	Open-air; Close to the coast	3	\N	-679	4	1	-1623	\N	C	2019-12-20 22:14:28.053842+00	716
1622	Open-air; Close to the coast	3	\N	-678	4	1	-1622	\N	C	2019-12-20 22:14:28.053842+00	717
1621	Open-air; Close to the coast	3	\N	-677	4	1	-1621	\N	C	2019-12-20 22:14:28.053842+00	718
1620	Shell midden; Inland	3	\N	-676	4	1	-1620	\N	C	2019-12-20 22:14:28.053842+00	719
1619	Shell midden; Inland	3	\N	-675	4	1	-1619	\N	C	2019-12-20 22:14:28.053842+00	720
1618	Shell midden; Inland	3	\N	-674	4	1	-1618	\N	C	2019-12-20 22:14:28.053842+00	721
1617	Shell midden; Inland	3	\N	-673	4	1	-1617	\N	C	2019-12-20 22:14:28.053842+00	722
1616	Shell midden; Inland	3	\N	-672	4	1	-1616	\N	C	2019-12-20 22:14:28.053842+00	723
1615	Shell midden; Inland	3	\N	-671	4	1	-1615	\N	C	2019-12-20 22:14:28.053842+00	724
1614	Shell midden; Inland	3	\N	-670	4	1	-1614	\N	C	2019-12-20 22:14:28.053842+00	725
1613	Shell midden; Inland	3	\N	-669	4	1	-1613	\N	C	2019-12-20 22:14:28.053842+00	726
1612	Shell midden; Inland	3	\N	-668	4	1	-1612	\N	C	2019-12-20 22:14:28.053842+00	727
1611	Shell midden; Inland	3	\N	-667	4	1	-1611	\N	C	2019-12-20 22:14:28.053842+00	728
1610	Shell midden; Inland	3	\N	-666	4	1	-1610	\N	C	2019-12-20 22:14:28.053842+00	729
1609	Shell midden; Inland	3	\N	-665	4	1	-1609	\N	C	2019-12-20 22:14:28.053842+00	730
1608	Shell midden; Inland	3	\N	-664	4	1	-1608	\N	C	2019-12-20 22:14:28.053842+00	731
1607	Shell midden; Inland	3	\N	-663	4	1	-1607	\N	C	2019-12-20 22:14:28.053842+00	732
1606	Shell midden; Inland	3	\N	-662	4	1	-1606	\N	C	2019-12-20 22:14:28.053842+00	733
1605	Shell midden; Inland	3	\N	-661	4	1	-1605	\N	C	2019-12-20 22:14:28.053842+00	734
1604	Shell midden; Inland	3	\N	-660	4	1	-1604	\N	C	2019-12-20 22:14:28.053842+00	735
1603	Shell midden; Inland	3	\N	-659	4	1	-1603	\N	C	2019-12-20 22:14:28.053842+00	736
1602	Shell midden; Inland	3	\N	-658	4	1	-1602	\N	C	2019-12-20 22:14:28.053842+00	737
1601	Shell midden; Inland	3	\N	-657	4	1	-1601	\N	C	2019-12-20 22:14:28.053842+00	738
1600	Shell midden; Inland	3	\N	-656	4	1	-1600	\N	C	2019-12-20 22:14:28.053842+00	739
1599	Shell midden; Inland	3	\N	-655	4	1	-1599	\N	C	2019-12-20 22:14:28.053842+00	740
1598	Shell midden; Inland	3	\N	-654	4	1	-1598	\N	C	2019-12-20 22:14:28.053842+00	741
1597	Shell midden; Inland	3	\N	-653	4	1	-1597	\N	C	2019-12-20 22:14:28.053842+00	742
1596	Shell midden; Inland	3	\N	-652	4	1	-1596	\N	C	2019-12-20 22:14:28.053842+00	743
1595	Shell midden; Inland	3	\N	-651	4	1	-1595	\N	C	2019-12-20 22:14:28.053842+00	744
1594	Shell midden; Inland	3	\N	-650	4	1	-1594	\N	C	2019-12-20 22:14:28.053842+00	745
1593	Shell midden; Inland	3	\N	-649	4	1	-1593	\N	C	2019-12-20 22:14:28.053842+00	746
1592	Shell midden; Inland	3	\N	-648	4	1	-1592	\N	C	2019-12-20 22:14:28.053842+00	747
1591	Shell midden; Inland	3	\N	-647	4	1	-1591	\N	C	2019-12-20 22:14:28.053842+00	748
1590	Shell midden; Inland	3	\N	-646	4	1	-1590	\N	C	2019-12-20 22:14:28.053842+00	749
1589	Shell midden; Inland	3	\N	-645	4	1	-1589	\N	C	2019-12-20 22:14:28.053842+00	750
1588	Shell midden; Inland	3	\N	-644	4	1	-1588	\N	C	2019-12-20 22:14:28.053842+00	751
1587	Shell midden; Inland	3	\N	-643	4	1	-1587	\N	C	2019-12-20 22:14:28.053842+00	752
1586	Shell midden; Inland	3	\N	-642	4	1	-1586	\N	C	2019-12-20 22:14:28.053842+00	753
1585	Shell midden; Inland	3	\N	-641	4	1	-1585	\N	C	2019-12-20 22:14:28.053842+00	754
1584	Shell midden; Inland	3	\N	-640	4	1	-1584	\N	C	2019-12-20 22:14:28.053842+00	755
1583	Shell midden; Inland	3	\N	-639	4	1	-1583	\N	C	2019-12-20 22:14:28.053842+00	756
1582	Shell midden; Inland	3	\N	-638	4	1	-1582	\N	C	2019-12-20 22:14:28.053842+00	757
1581	Shell midden; Inland	3	\N	-637	4	1	-1581	\N	C	2019-12-20 22:14:28.053842+00	758
1580	Shell midden; Inland	3	\N	-636	4	1	-1580	\N	C	2019-12-20 22:14:28.053842+00	759
1579	Shell midden; Inland	3	\N	-635	4	1	-1579	\N	C	2019-12-20 22:14:28.053842+00	760
1578	Shell midden; Inland	3	\N	-634	4	1	-1578	\N	C	2019-12-20 22:14:28.053842+00	761
1577	Shell midden; Inland	3	\N	-633	4	1	-1577	\N	C	2019-12-20 22:14:28.053842+00	762
1576	Shell midden; Inland	3	\N	-632	4	1	-1576	\N	C	2019-12-20 22:14:28.053842+00	763
1575	Shell midden; Inland	3	\N	-631	4	1	-1575	\N	C	2019-12-20 22:14:28.053842+00	764
1574	Shell midden; Inland	3	\N	-630	4	1	-1574	\N	C	2019-12-20 22:14:28.053842+00	765
1573	Shell midden; Inland	3	\N	-629	4	1	-1573	\N	C	2019-12-20 22:14:28.053842+00	766
1572	Shell midden; Inland	3	\N	-628	4	1	-1572	\N	C	2019-12-20 22:14:28.053842+00	767
1571	Shell midden; Inland	3	\N	-627	4	1	-1571	\N	C	2019-12-20 22:14:28.053842+00	768
1570	Shell midden; Inland	3	\N	-626	4	1	-1570	\N	C	2019-12-20 22:14:28.053842+00	769
1569	Shell midden; Inland	3	\N	-625	4	1	-1569	\N	C	2019-12-20 22:14:28.053842+00	770
1568	Shell midden; Inland	3	\N	-624	4	1	-1568	\N	C	2019-12-20 22:14:28.053842+00	771
1567	Shell midden; Inland	3	\N	-623	4	1	-1567	\N	C	2019-12-20 22:14:28.053842+00	772
1566	Shell midden; Inland	3	\N	-622	4	1	-1566	\N	C	2019-12-20 22:14:28.053842+00	773
1565	Shell midden; Inland	3	\N	-621	4	1	-1565	\N	C	2019-12-20 22:14:28.053842+00	774
1564	Shell midden; Inland	3	\N	-620	4	1	-1564	\N	C	2019-12-20 22:14:28.053842+00	775
1563	Shell midden; Inland	3	\N	-619	4	1	-1563	\N	C	2019-12-20 22:14:28.053842+00	776
1562	Shell midden; Inland	3	\N	-618	4	1	-1562	\N	C	2019-12-20 22:14:28.053842+00	777
1561	Shell midden; Inland	3	\N	-617	4	1	-1561	\N	C	2019-12-20 22:14:28.053842+00	778
1560	Shell midden; Inland	3	\N	-616	4	1	-1560	\N	C	2019-12-20 22:14:28.053842+00	779
1559	Shell midden; Inland	3	\N	-615	4	1	-1559	\N	C	2019-12-20 22:14:28.053842+00	780
1558	Shell midden; Inland	3	\N	-614	4	1	-1558	\N	C	2019-12-20 22:14:28.053842+00	781
1557	Shell midden; Close to the coast	3	\N	-613	4	1	-1557	\N	C	2019-12-20 22:14:28.053842+00	782
1556	Shell midden; Close to the coast	3	\N	-612	4	1	-1556	\N	C	2019-12-20 22:14:28.053842+00	783
1555	Shell midden; Close to the coast	3	\N	-611	4	1	-1555	\N	C	2019-12-20 22:14:28.053842+00	784
1554	Shell midden; Close to the coast	3	\N	-610	4	1	-1554	\N	C	2019-12-20 22:14:28.053842+00	785
1553	Shell midden; Close to the coast	3	\N	-609	4	1	-1553	\N	C	2019-12-20 22:14:28.053842+00	786
1552	Shell midden; Close to the coast	3	\N	-608	4	1	-1552	\N	C	2019-12-20 22:14:28.053842+00	787
1551	Shell midden; Close to the coast	3	\N	-607	4	1	-1551	\N	C	2019-12-20 22:14:28.053842+00	788
1550	Shell midden; Close to the coast	3	\N	-606	4	1	-1550	\N	C	2019-12-20 22:14:28.053842+00	789
1549	Shell midden; Close to the coast	3	\N	-605	4	1	-1549	\N	C	2019-12-20 22:14:28.053842+00	790
1548	Shell midden; Close to the coast	3	\N	-604	4	1	-1548	\N	C	2019-12-20 22:14:28.053842+00	791
1547	Shell midden; Close to the coast	3	\N	-603	4	1	-1547	\N	C	2019-12-20 22:14:28.053842+00	792
1546	Shell midden; Close to the coast	3	\N	-602	4	1	-1546	\N	C	2019-12-20 22:14:28.053842+00	793
1545	Shell midden; Close to the coast	3	\N	-601	4	1	-1545	\N	C	2019-12-20 22:14:28.053842+00	794
1544	Shell midden; Close to the coast	3	\N	-600	4	1	-1544	\N	C	2019-12-20 22:14:28.053842+00	795
1543	Shell midden; Close to the coast	3	\N	-599	4	1	-1543	\N	C	2019-12-20 22:14:28.053842+00	796
1542	Shell midden; Close to the coast	3	\N	-598	4	1	-1542	\N	C	2019-12-20 22:14:28.053842+00	797
1541	Open-air; Close to the coast	3	\N	-597	4	1	-1541	\N	C	2019-12-20 22:14:28.053842+00	798
1540	Open-air; Close to the coast	3	\N	-596	4	1	-1540	\N	C	2019-12-20 22:14:28.053842+00	799
1539	Open-air; Close to the coast	3	\N	-595	4	1	-1539	\N	C	2019-12-20 22:14:28.053842+00	800
1538	Open-air; Close to the coast	3	\N	-594	4	1	-1538	\N	C	2019-12-20 22:14:28.053842+00	801
1537	Open-air; Close to the coast	3	\N	-593	4	1	-1537	\N	C	2019-12-20 22:14:28.053842+00	802
1536	Open-air; Close to the coast	3	\N	-592	4	1	-1536	\N	C	2019-12-20 22:14:28.053842+00	803
1535	Open-air; Close to the coast	3	\N	-591	4	1	-1535	\N	C	2019-12-20 22:14:28.053842+00	804
1534	Open-air; Close to the coast	3	\N	-590	4	1	-1534	\N	C	2019-12-20 22:14:28.053842+00	805
1533	Open-air; Close to the coast	3	\N	-589	4	1	-1533	\N	C	2019-12-20 22:14:28.053842+00	806
1532	Open-air; Close to the coast	3	\N	-588	4	1	-1532	\N	C	2019-12-20 22:14:28.053842+00	807
1531	Open-air; Close to the coast	3	\N	-587	4	1	-1531	\N	C	2019-12-20 22:14:28.053842+00	808
1530	Open-air; Close to the coast	3	\N	-586	4	1	-1530	\N	C	2019-12-20 22:14:28.053842+00	809
1529	Open-air; Close to the coast	3	\N	-585	4	1	-1529	\N	C	2019-12-20 22:14:28.053842+00	810
1528	Open-air; Close to the coast	3	\N	-584	4	1	-1528	\N	C	2019-12-20 22:14:28.053842+00	811
1527	Open-air; Close to the coast	3	\N	-583	4	1	-1527	\N	C	2019-12-20 22:14:28.053842+00	812
1526	Open-air; Close to the coast	3	\N	-582	4	1	-1526	\N	C	2019-12-20 22:14:28.053842+00	813
1525	Open-air; Close to the coast	3	\N	-581	4	1	-1525	\N	C	2019-12-20 22:14:28.053842+00	814
1524	Open-air; Close to the coast	3	\N	-580	4	1	-1524	\N	C	2019-12-20 22:14:28.053842+00	815
1523	Open-air; Close to the coast	3	\N	-579	4	1	-1523	\N	C	2019-12-20 22:14:28.053842+00	816
1522	Open-air; Close to the coast	3	\N	-578	4	1	-1522	\N	C	2019-12-20 22:14:28.053842+00	817
1521	Open-air; Close to the coast	3	\N	-577	4	1	-1521	\N	C	2019-12-20 22:14:28.053842+00	818
1520	Open-air; Close to the coast	3	\N	-576	4	1	-1520	\N	C	2019-12-20 22:14:28.053842+00	819
1519	Open-air; Close to the coast	3	\N	-575	4	1	-1519	\N	C	2019-12-20 22:14:28.053842+00	820
1518	Open-air; Close to the coast	3	\N	-574	4	1	-1518	\N	C	2019-12-20 22:14:28.053842+00	821
1517	Open-air; Close to the coast	3	\N	-573	4	1	-1517	\N	C	2019-12-20 22:14:28.053842+00	822
1516	Open-air; Close to the coast	3	\N	-572	4	1	-1516	\N	C	2019-12-20 22:14:28.053842+00	823
1515	Open-air; Close to the coast	3	\N	-571	4	1	-1515	\N	C	2019-12-20 22:14:28.053842+00	824
1514	Open-air; Close to the coast	3	\N	-570	4	1	-1514	\N	C	2019-12-20 22:14:28.053842+00	825
1513	Open-air; Close to the coast	3	\N	-569	4	1	-1513	\N	C	2019-12-20 22:14:28.053842+00	826
1512	Open-air; Close to the coast	3	\N	-568	4	1	-1512	\N	C	2019-12-20 22:14:28.053842+00	827
1511	Open-air; Close to the coast	3	\N	-567	4	1	-1511	\N	C	2019-12-20 22:14:28.053842+00	828
1510	Open-air; Close to the coast	3	\N	-566	4	1	-1510	\N	C	2019-12-20 22:14:28.053842+00	829
1509	Open-air; Close to the coast	3	\N	-565	4	1	-1509	\N	C	2019-12-20 22:14:28.053842+00	830
1508	Open-air; Close to the coast	3	\N	-564	4	1	-1508	\N	C	2019-12-20 22:14:28.053842+00	831
1507	Open-air; Close to the coast	3	\N	-563	4	1	-1507	\N	C	2019-12-20 22:14:28.053842+00	832
1506	Open-air; Close to the coast	3	\N	-562	4	1	-1506	\N	C	2019-12-20 22:14:28.053842+00	833
1505	Open-air; Close to the coast	3	\N	-561	4	1	-1505	\N	C	2019-12-20 22:14:28.053842+00	834
1504	Open-air; Close to the coast	3	\N	-560	4	1	-1504	\N	C	2019-12-20 22:14:28.053842+00	835
1503	Open-air; Close to the coast	3	\N	-559	4	1	-1503	\N	C	2019-12-20 22:14:28.053842+00	836
1502	Open-air; Close to the coast	3	\N	-558	4	1	-1502	\N	C	2019-12-20 22:14:28.053842+00	837
1501	Open-air; Close to the coast	3	\N	-557	4	1	-1501	\N	C	2019-12-20 22:14:28.053842+00	838
1500	Open-air; Close to the coast	3	\N	-556	4	1	-1500	\N	C	2019-12-20 22:14:28.053842+00	839
1499	Open-air; Close to the coast	3	\N	-555	4	1	-1499	\N	C	2019-12-20 22:14:28.053842+00	840
1498	Open-air; Close to the coast	3	\N	-554	4	1	-1498	\N	C	2019-12-20 22:14:28.053842+00	841
1497	Open-air; Close to the coast	3	\N	-553	4	1	-1497	\N	C	2019-12-20 22:14:28.053842+00	842
1496	Open-air; Close to the coast	3	\N	-552	4	1	-1496	\N	C	2019-12-20 22:14:28.053842+00	843
1495	Open-air; Close to the coast	3	\N	-551	4	1	-1495	\N	C	2019-12-20 22:14:28.053842+00	844
1494	Open-air; Close to the coast	3	\N	-550	4	1	-1494	\N	C	2019-12-20 22:14:28.053842+00	845
1493	Open-air; Close to the coast	3	\N	-549	4	1	-1493	\N	C	2019-12-20 22:14:28.053842+00	846
1492	Open-air; Close to the coast	3	\N	-548	4	1	-1492	\N	C	2019-12-20 22:14:28.053842+00	847
1491	Open-air; Close to the coast	3	\N	-547	4	1	-1491	\N	C	2019-12-20 22:14:28.053842+00	848
1490	Open-air; Close to the coast	3	\N	-546	4	1	-1490	\N	C	2019-12-20 22:14:28.053842+00	849
1489	Open-air; Close to the coast	3	\N	-545	4	1	-1489	\N	C	2019-12-20 22:14:28.053842+00	850
1488	Open-air; Close to the coast	3	\N	-544	4	1	-1488	\N	C	2019-12-20 22:14:28.053842+00	851
1487	Open-air; Close to the coast	3	\N	-543	4	1	-1487	\N	C	2019-12-20 22:14:28.053842+00	852
1486	Open-air; Close to the coast	3	\N	-542	4	1	-1486	\N	C	2019-12-20 22:14:28.053842+00	853
1485	Open-air; Close to the coast	3	\N	-541	4	1	-1485	\N	C	2019-12-20 22:14:28.053842+00	854
1484	Open-air; Close to the coast	3	\N	-540	4	1	-1484	\N	C	2019-12-20 22:14:28.053842+00	855
1483	Open-air; Close to the coast	3	\N	-539	4	1	-1483	\N	C	2019-12-20 22:14:28.053842+00	856
1482	Open-air; Close to the coast	3	\N	-538	4	1	-1482	\N	C	2019-12-20 22:14:28.053842+00	857
1481	Open-air; Close to the coast	3	\N	-537	4	1	-1481	\N	C	2019-12-20 22:14:28.053842+00	858
1480	Open-air; Close to the coast	3	\N	-536	4	1	-1480	\N	C	2019-12-20 22:14:28.053842+00	859
1479	Open-air; Close to the coast	3	\N	-535	4	1	-1479	\N	C	2019-12-20 22:14:28.053842+00	860
1478	Open-air; Close to the coast	3	\N	-534	4	1	-1478	\N	C	2019-12-20 22:14:28.053842+00	861
1477	Open-air; Close to the coast	3	\N	-533	4	1	-1477	\N	C	2019-12-20 22:14:28.053842+00	862
1476	Open-air; Close to the coast	3	\N	-532	4	1	-1476	\N	C	2019-12-20 22:14:28.053842+00	863
1475	Open-air; Close to the coast	3	\N	-531	4	1	-1475	\N	C	2019-12-20 22:14:28.053842+00	864
1474	Open-air; Close to the coast	3	\N	-530	4	1	-1474	\N	C	2019-12-20 22:14:28.053842+00	865
1473	Open-air; Close to the coast	3	\N	-529	4	1	-1473	\N	C	2019-12-20 22:14:28.053842+00	866
1472	Open-air; Close to the coast	3	\N	-528	4	1	-1472	\N	C	2019-12-20 22:14:28.053842+00	867
1471	Open-air; Close to the coast	3	\N	-527	4	1	-1471	\N	C	2019-12-20 22:14:28.053842+00	868
1470	Open-air; Close to the coast	3	\N	-526	4	1	-1470	\N	C	2019-12-20 22:14:28.053842+00	869
1469	Open-air; Close to the coast	3	\N	-525	4	1	-1469	\N	C	2019-12-20 22:14:28.053842+00	870
1468	Open-air; Close to the coast	3	\N	-524	4	1	-1468	\N	C	2019-12-20 22:14:28.053842+00	871
1467	Open-air; Close to the coast	3	\N	-523	4	1	-1467	\N	C	2019-12-20 22:14:28.053842+00	872
1466	Open-air; Close to the coast	3	\N	-522	4	1	-1466	\N	C	2019-12-20 22:14:28.053842+00	873
1465	Open-air; Close to the coast	3	\N	-521	4	1	-1465	\N	C	2019-12-20 22:14:28.053842+00	874
1464	Open-air; Close to the coast	3	\N	-520	4	1	-1464	\N	C	2019-12-20 22:14:28.053842+00	875
1463	Open-air; Close to the coast	3	\N	-519	4	1	-1463	\N	C	2019-12-20 22:14:28.053842+00	876
1462	Open-air; Close to the coast	3	\N	-518	4	1	-1462	\N	C	2019-12-20 22:14:28.053842+00	877
1461	Open-air; Close to the coast	3	\N	-517	4	1	-1461	\N	C	2019-12-20 22:14:28.053842+00	878
1460	Open-air; Close to the coast	3	\N	-516	4	1	-1460	\N	C	2019-12-20 22:14:28.053842+00	879
1459	Open-air; Close to the coast	3	\N	-515	4	1	-1459	\N	C	2019-12-20 22:14:28.053842+00	880
1458	Open-air; Close to the coast	3	\N	-514	4	1	-1458	\N	C	2019-12-20 22:14:28.053842+00	881
1457	Open-air; Close to the coast	3	\N	-513	4	1	-1457	\N	C	2019-12-20 22:14:28.053842+00	882
1456	Open-air; Close to the coast	3	\N	-512	4	1	-1456	\N	C	2019-12-20 22:14:28.053842+00	883
1455	Open-air; Close to the coast	3	\N	-511	4	1	-1455	\N	C	2019-12-20 22:14:28.053842+00	884
1454	Open-air; Close to the coast	3	\N	-510	4	1	-1454	\N	C	2019-12-20 22:14:28.053842+00	885
1453	Open-air; Close to the coast	3	\N	-509	4	1	-1453	\N	C	2019-12-20 22:14:28.053842+00	886
1452	Open-air; Close to the coast	3	\N	-508	4	1	-1452	\N	C	2019-12-20 22:14:28.053842+00	887
1451	Open-air; Close to the coast	3	\N	-507	4	1	-1451	\N	C	2019-12-20 22:14:28.053842+00	888
1450	Open-air; Close to the coast	3	\N	-506	4	1	-1450	\N	C	2019-12-20 22:14:28.053842+00	889
1449	Open-air; Close to the coast	3	\N	-505	4	1	-1449	\N	C	2019-12-20 22:14:28.053842+00	890
1448	Open-air; Close to the coast	3	\N	-504	4	1	-1448	\N	C	2019-12-20 22:14:28.053842+00	891
1447	Open-air; Close to the coast	3	\N	-503	4	1	-1447	\N	C	2019-12-20 22:14:28.053842+00	892
1446	Open-air; Close to the coast	3	\N	-502	4	1	-1446	\N	C	2019-12-20 22:14:28.053842+00	893
1445	Open-air; Close to the coast	3	\N	-501	4	1	-1445	\N	C	2019-12-20 22:14:28.053842+00	894
1444	Open-air; Close to the coast	3	\N	-500	4	1	-1444	\N	C	2019-12-20 22:14:28.053842+00	895
1443	Open-air; Close to the coast	3	\N	-499	4	1	-1443	\N	C	2019-12-20 22:14:28.053842+00	896
1442	Open-air; Close to the coast	3	\N	-498	4	1	-1442	\N	C	2019-12-20 22:14:28.053842+00	897
1441	Open-air; Close to the coast	3	\N	-497	4	1	-1441	\N	C	2019-12-20 22:14:28.053842+00	898
1440	Open-air; Close to the coast	3	\N	-496	4	1	-1440	\N	C	2019-12-20 22:14:28.053842+00	899
1439	Open-air; Close to the coast	3	\N	-495	4	1	-1439	\N	C	2019-12-20 22:14:28.053842+00	900
1438	Open-air; Close to the coast	3	\N	-494	4	1	-1438	\N	C	2019-12-20 22:14:28.053842+00	901
1437	Open-air; Close to the coast	3	\N	-493	4	1	-1437	\N	C	2019-12-20 22:14:28.053842+00	902
1436	Open-air; Inland	3	\N	-492	4	1	-1436	\N	C	2019-12-20 22:14:28.053842+00	903
1435	Open-air; Inland	3	\N	-491	4	1	-1435	\N	C	2019-12-20 22:14:28.053842+00	904
1434	Open-air; Inland	3	\N	-490	4	1	-1434	\N	C	2019-12-20 22:14:28.053842+00	905
1433	Open-air; Lake shore	3	\N	-489	4	1	-1433	\N	C	2019-12-20 22:14:28.053842+00	906
1432	Open-air; Inland	3	\N	-488	4	1	-1432	\N	C	2019-12-20 22:14:28.053842+00	907
1431	Open-air; Inland	3	\N	-487	4	1	-1431	\N	C	2019-12-20 22:14:28.053842+00	908
1430	Open-air; Inland	3	\N	-486	4	1	-1430	\N	C	2019-12-20 22:14:28.053842+00	909
1429	Open-air; Inland	3	\N	-485	4	1	-1429	\N	C	2019-12-20 22:14:28.053842+00	910
1428	Open-air; Inland	3	\N	-484	4	1	-1428	\N	C	2019-12-20 22:14:28.053842+00	911
1427	Open-air; Inland	3	\N	-483	4	1	-1427	\N	C	2019-12-20 22:14:28.053842+00	912
1426	Open-air; Inland	3	\N	-482	4	1	-1426	\N	C	2019-12-20 22:14:28.053842+00	913
1425	Open-air; Inland	3	\N	-481	4	1	-1425	\N	C	2019-12-20 22:14:28.053842+00	914
1424	Open-air; Inland	3	\N	-480	4	1	-1424	\N	C	2019-12-20 22:14:28.053842+00	915
1423	Open-air; Inland	3	\N	-479	4	1	-1423	\N	C	2019-12-20 22:14:28.053842+00	916
1422	Open-air; Inland	3	\N	-478	4	1	-1422	\N	C	2019-12-20 22:14:28.053842+00	917
1421	Open-air; Inland	3	\N	-477	4	1	-1421	\N	C	2019-12-20 22:14:28.053842+00	918
1420	Open-air; Inland	3	\N	-476	4	1	-1420	\N	C	2019-12-20 22:14:28.053842+00	919
1419	Open-air; Inland	3	\N	-475	4	1	-1419	\N	C	2019-12-20 22:14:28.053842+00	920
1418	Open-air; Inland	3	\N	-474	4	1	-1418	\N	C	2019-12-20 22:14:28.053842+00	921
1417	Open-air; Inland	3	\N	-473	4	1	-1417	\N	C	2019-12-20 22:14:28.053842+00	922
1416	Open-air; Inland	3	\N	-472	4	1	-1416	\N	C	2019-12-20 22:14:28.053842+00	923
1415	Open-air; Inland	3	\N	-471	4	1	-1415	\N	C	2019-12-20 22:14:28.053842+00	924
1414	Open-air; Inland	3	\N	-470	4	1	-1414	\N	C	2019-12-20 22:14:28.053842+00	925
1413	Open-air; Inland	3	\N	-469	4	1	-1413	\N	C	2019-12-20 22:14:28.053842+00	926
1412	Rock shelter/Cave; Inland	3	\N	-468	4	1	-1412	\N	C	2019-12-20 22:14:28.053842+00	927
1411	Rock shelter/Cave; Inland	3	\N	-467	4	1	-1411	\N	C	2019-12-20 22:14:28.053842+00	928
1410	Rock shelter/Cave; Inland	3	\N	-466	4	1	-1410	\N	C	2019-12-20 22:14:28.053842+00	929
1409	Rock shelter/Cave; Inland	3	\N	-465	4	1	-1409	\N	C	2019-12-20 22:14:28.053842+00	930
1408	Rock shelter/Cave; Inland	3	\N	-464	4	1	-1408	\N	C	2019-12-20 22:14:28.053842+00	931
1407	Rock shelter/Cave; Inland	3	\N	-463	4	1	-1407	\N	C	2019-12-20 22:14:28.053842+00	932
1406	Open-air; Inland	3	\N	-462	4	1	-1406	\N	C	2019-12-20 22:14:28.053842+00	933
1405	Open-air; Inland	3	\N	-461	4	1	-1405	\N	C	2019-12-20 22:14:28.053842+00	934
1404	Open-air; Inland	3	\N	-460	4	1	-1404	\N	C	2019-12-20 22:14:28.053842+00	935
1403	Open-air; Inland	3	\N	-459	4	1	-1403	\N	C	2019-12-20 22:14:28.053842+00	936
1402	Open-air; Inland	3	\N	-458	4	1	-1402	\N	C	2019-12-20 22:14:28.053842+00	937
1401	Open-air; Inland	3	\N	-457	4	1	-1401	\N	C	2019-12-20 22:14:28.053842+00	938
1400	Open-air; Inland	3	\N	-456	4	1	-1400	\N	C	2019-12-20 22:14:28.053842+00	939
1399	Open-air; Inland	3	\N	-455	4	1	-1399	\N	C	2019-12-20 22:14:28.053842+00	940
1398	Open-air; Inland	3	\N	-454	4	1	-1398	\N	C	2019-12-20 22:14:28.053842+00	941
1397	Open-air; Inland	3	\N	-453	4	1	-1397	\N	C	2019-12-20 22:14:28.053842+00	942
1396	Open-air; Inland	3	\N	-452	4	1	-1396	\N	C	2019-12-20 22:14:28.053842+00	943
1395	Open-air; Inland	3	\N	-451	4	1	-1395	\N	C	2019-12-20 22:14:28.053842+00	944
1394	Rock shelter/Cave; Inland	3	\N	-450	4	1	-1394	\N	C	2019-12-20 22:14:28.053842+00	945
1393	Open-air; Close to the coast	3	\N	-449	4	1	-1393	\N	C	2019-12-20 22:14:28.053842+00	946
1392	Open-air; Close to the coast	3	\N	-448	4	1	-1392	\N	C	2019-12-20 22:14:28.053842+00	947
1391	Open-air; Close to the coast	3	\N	-447	4	1	-1391	\N	C	2019-12-20 22:14:28.053842+00	948
1390	Open-air; Close to the coast	3	\N	-446	4	1	-1390	\N	C	2019-12-20 22:14:28.053842+00	949
1389	Open-air; Close to the coast	3	\N	-445	4	1	-1389	\N	C	2019-12-20 22:14:28.053842+00	950
1388	Open-air; Close to the coast	3	\N	-444	4	1	-1388	\N	C	2019-12-20 22:14:28.053842+00	951
1387	Open-air; Inland	3	\N	-443	4	1	-1387	\N	C	2019-12-20 22:14:28.053842+00	952
1386	Open-air; Inland	3	\N	-442	4	1	-1386	\N	C	2019-12-20 22:14:28.053842+00	953
1385	Open-air; Inland	3	\N	-441	4	1	-1385	\N	C	2019-12-20 22:14:28.053842+00	954
1384	Shell midden; Lake shore	3	\N	-440	4	1	-1384	\N	C	2019-12-20 22:14:28.053842+00	955
1383	Shell midden; Lake shore	3	\N	-439	4	1	-1383	\N	C	2019-12-20 22:14:28.053842+00	956
1382	Shell midden; Lake shore	3	\N	-438	4	1	-1382	\N	C	2019-12-20 22:14:28.053842+00	957
1381	Open-air; Close to the coast	3	\N	-437	4	1	-1381	\N	C	2019-12-20 22:14:28.053842+00	958
1380	Open-air; Close to the coast	3	\N	-436	4	1	-1380	\N	C	2019-12-20 22:14:28.053842+00	959
1379	Open-air; Close to the coast	3	\N	-435	4	1	-1379	\N	C	2019-12-20 22:14:28.053842+00	960
1378	Open-air; Close to the coast	3	\N	-434	4	1	-1378	\N	C	2019-12-20 22:14:28.053842+00	961
1377	Open-air; Close to the coast	3	\N	-433	4	1	-1377	\N	C	2019-12-20 22:14:28.053842+00	962
1376	Open-air; Close to the coast	3	\N	-432	4	1	-1376	\N	C	2019-12-20 22:14:28.053842+00	963
1375	Open-air; Close to the coast	3	\N	-431	4	1	-1375	\N	C	2019-12-20 22:14:28.053842+00	964
1374	Open-air; Close to the coast	3	\N	-430	4	1	-1374	\N	C	2019-12-20 22:14:28.053842+00	965
1373	Open-air; Close to the coast	3	\N	-429	4	1	-1373	\N	C	2019-12-20 22:14:28.053842+00	966
1372	Open-air; Close to the coast	3	\N	-428	4	1	-1372	\N	C	2019-12-20 22:14:28.053842+00	967
1371	Open-air; Close to the coast	3	\N	-427	4	1	-1371	\N	C	2019-12-20 22:14:28.053842+00	968
1370	Open-air; Close to the coast	3	\N	-426	4	1	-1370	\N	C	2019-12-20 22:14:28.053842+00	969
1369	Open-air; Close to the coast	3	\N	-425	4	1	-1369	\N	C	2019-12-20 22:14:28.053842+00	970
1368	Open-air; Close to the coast	3	\N	-424	4	1	-1368	\N	C	2019-12-20 22:14:28.053842+00	971
1367	Open-air; Close to the coast	3	\N	-423	4	1	-1367	\N	C	2019-12-20 22:14:28.053842+00	972
1366	Open-air; Close to the coast	3	\N	-422	4	1	-1366	\N	C	2019-12-20 22:14:28.053842+00	973
1365	Open-air; Close to the coast	3	\N	-421	4	1	-1365	\N	C	2019-12-20 22:14:28.053842+00	974
1364	Open-air; Close to the coast	3	\N	-420	4	1	-1364	\N	C	2019-12-20 22:14:28.053842+00	975
1363	Open-air; Close to the coast	3	\N	-419	4	1	-1363	\N	C	2019-12-20 22:14:28.053842+00	976
1362	Open-air; Close to the coast	3	\N	-418	4	1	-1362	\N	C	2019-12-20 22:14:28.053842+00	977
1361	Open-air; Close to the coast	3	\N	-417	4	1	-1361	\N	C	2019-12-20 22:14:28.053842+00	978
1360	Open-air; Close to the coast	3	\N	-416	4	1	-1360	\N	C	2019-12-20 22:14:28.053842+00	979
1359	Open-air; Close to the coast	3	\N	-415	4	1	-1359	\N	C	2019-12-20 22:14:28.053842+00	980
1358	Open-air; Close to the coast	3	\N	-414	4	1	-1358	\N	C	2019-12-20 22:14:28.053842+00	981
1357	Open-air; Close to the coast	3	\N	-413	4	1	-1357	\N	C	2019-12-20 22:14:28.053842+00	982
1356	Open-air; Close to the coast	3	\N	-412	4	1	-1356	\N	C	2019-12-20 22:14:28.053842+00	983
1355	Open-air; Close to the coast	3	\N	-411	4	1	-1355	\N	C	2019-12-20 22:14:28.053842+00	984
1354	Open-air; Close to the coast	3	\N	-410	4	1	-1354	\N	C	2019-12-20 22:14:28.053842+00	985
1353	Open-air; Close to the coast	3	\N	-409	4	1	-1353	\N	C	2019-12-20 22:14:28.053842+00	986
1352	Open-air; Close to the coast	3	\N	-408	4	1	-1352	\N	C	2019-12-20 22:14:28.053842+00	987
1351	Open-air; Close to the coast	3	\N	-407	4	1	-1351	\N	C	2019-12-20 22:14:28.053842+00	988
1350	Open-air; Close to the coast	3	\N	-406	4	1	-1350	\N	C	2019-12-20 22:14:28.053842+00	989
1349	Open-air; Close to the coast	3	\N	-405	4	1	-1349	\N	C	2019-12-20 22:14:28.053842+00	990
1348	Open-air; Close to the coast	3	\N	-404	4	1	-1348	\N	C	2019-12-20 22:14:28.053842+00	991
1347	Open-air; Close to the coast	3	\N	-403	4	1	-1347	\N	C	2019-12-20 22:14:28.053842+00	992
1346	Open-air; Close to the coast	3	\N	-402	4	1	-1346	\N	C	2019-12-20 22:14:28.053842+00	993
1345	Open-air; Close to the coast	3	\N	-401	4	1	-1345	\N	C	2019-12-20 22:14:28.053842+00	994
1344	Open-air; Close to the coast	3	\N	-400	4	1	-1344	\N	C	2019-12-20 22:14:28.053842+00	995
1343	Open-air; Close to the coast	3	\N	-399	4	1	-1343	\N	C	2019-12-20 22:14:28.053842+00	996
1342	Open-air; Close to the coast	3	\N	-398	4	1	-1342	\N	C	2019-12-20 22:14:28.053842+00	997
1341	Open-air; Inland	3	\N	-397	4	1	-1341	\N	C	2019-12-20 22:14:28.053842+00	998
1340	Open-air; Inland	3	\N	-396	4	1	-1340	\N	C	2019-12-20 22:14:28.053842+00	999
1339	Open-air; Inland	3	\N	-395	4	1	-1339	\N	C	2019-12-20 22:14:28.053842+00	1000
1338	Open-air; Inland	3	\N	-394	4	1	-1338	\N	C	2019-12-20 22:14:28.053842+00	1001
1337	Open-air; Inland	3	\N	-393	4	1	-1337	\N	C	2019-12-20 22:14:28.053842+00	1002
1336	Open-air; Inland	3	\N	-392	4	1	-1336	\N	C	2019-12-20 22:14:28.053842+00	1003
1335	Open-air; Inland	3	\N	-391	4	1	-1335	\N	C	2019-12-20 22:14:28.053842+00	1004
1334	Open-air; Inland	3	\N	-390	4	1	-1334	\N	C	2019-12-20 22:14:28.053842+00	1005
1333	Open-air; Inland	3	\N	-389	4	1	-1333	\N	C	2019-12-20 22:14:28.053842+00	1006
1332	Open-air; Inland	3	\N	-388	4	1	-1332	\N	C	2019-12-20 22:14:28.053842+00	1007
1331	Open-air; Inland	3	\N	-387	4	1	-1331	\N	C	2019-12-20 22:14:28.053842+00	1008
1330	Open-air; Inland	3	\N	-386	4	1	-1330	\N	C	2019-12-20 22:14:28.053842+00	1009
1329	Open-air; Inland	3	\N	-385	4	1	-1329	\N	C	2019-12-20 22:14:28.053842+00	1010
1328	Open-air; Inland	3	\N	-384	4	1	-1328	\N	C	2019-12-20 22:14:28.053842+00	1011
1327	Open-air; Inland	3	\N	-383	4	1	-1327	\N	C	2019-12-20 22:14:28.053842+00	1012
1326	Open-air; Inland	3	\N	-382	4	1	-1326	\N	C	2019-12-20 22:14:28.053842+00	1013
1325	Open-air; Inland	3	\N	-381	4	1	-1325	\N	C	2019-12-20 22:14:28.053842+00	1014
1324	Open-air; Inland	3	\N	-380	4	1	-1324	\N	C	2019-12-20 22:14:28.053842+00	1015
1323	Open-air; Inland	3	\N	-379	4	1	-1323	\N	C	2019-12-20 22:14:28.053842+00	1016
1322	Open-air; Inland	3	\N	-378	4	1	-1322	\N	C	2019-12-20 22:14:28.053842+00	1017
1321	Open-air; Inland	3	\N	-377	4	1	-1321	\N	C	2019-12-20 22:14:28.053842+00	1018
1320	Open-air; Inland	3	\N	-376	4	1	-1320	\N	C	2019-12-20 22:14:28.053842+00	1019
1319	Open-air; Inland	3	\N	-375	4	1	-1319	\N	C	2019-12-20 22:14:28.053842+00	1020
1318	Open-air; Inland	3	\N	-374	4	1	-1318	\N	C	2019-12-20 22:14:28.053842+00	1021
1317	Open-air; Inland	3	\N	-373	4	1	-1317	\N	C	2019-12-20 22:14:28.053842+00	1022
1316	Open-air; Inland	3	\N	-372	4	1	-1316	\N	C	2019-12-20 22:14:28.053842+00	1023
1315	Open-air; Inland	3	\N	-371	4	1	-1315	\N	C	2019-12-20 22:14:28.053842+00	1024
1314	Open-air; Inland	3	\N	-370	4	1	-1314	\N	C	2019-12-20 22:14:28.053842+00	1025
1313	Open-air; Inland	3	\N	-369	4	1	-1313	\N	C	2019-12-20 22:14:28.053842+00	1026
1312	Open-air; Inland	3	\N	-368	4	1	-1312	\N	C	2019-12-20 22:14:28.053842+00	1027
1311	Open-air; Inland	3	\N	-367	4	1	-1311	\N	C	2019-12-20 22:14:28.053842+00	1028
1310	Open-air; Inland	3	\N	-366	4	1	-1310	\N	C	2019-12-20 22:14:28.053842+00	1029
1309	Open-air; Inland	3	\N	-365	4	1	-1309	\N	C	2019-12-20 22:14:28.053842+00	1030
1308	Open-air; Inland	3	\N	-364	4	1	-1308	\N	C	2019-12-20 22:14:28.053842+00	1031
1307	Open-air; Inland	3	\N	-363	4	1	-1307	\N	C	2019-12-20 22:14:28.053842+00	1032
1306	Open-air; Inland	3	\N	-362	4	1	-1306	\N	C	2019-12-20 22:14:28.053842+00	1033
1305	Open-air; Inland	3	\N	-361	4	1	-1305	\N	C	2019-12-20 22:14:28.053842+00	1034
1304	Open-air; Inland	3	\N	-360	4	1	-1304	\N	C	2019-12-20 22:14:28.053842+00	1035
1303	Open-air; Inland	3	\N	-359	4	1	-1303	\N	C	2019-12-20 22:14:28.053842+00	1036
1302	Open-air; Inland	3	\N	-358	4	1	-1302	\N	C	2019-12-20 22:14:28.053842+00	1037
1301	Shell midden; Lake shore	3	\N	-357	4	1	-1301	\N	C	2019-12-20 22:14:28.053842+00	1038
1300	Shell midden; Lake shore	3	\N	-356	4	1	-1300	\N	C	2019-12-20 22:14:28.053842+00	1039
1299	Shell midden; Lake shore	3	\N	-355	4	1	-1299	\N	C	2019-12-20 22:14:28.053842+00	1040
1298	Shell midden; Lake shore	3	\N	-354	4	1	-1298	\N	C	2019-12-20 22:14:28.053842+00	1041
1297	Shell midden; Lake shore	3	\N	-353	4	1	-1297	\N	C	2019-12-20 22:14:28.053842+00	1042
1296	Shell midden; Lake shore	3	\N	-352	4	1	-1296	\N	C	2019-12-20 22:14:28.053842+00	1043
1295	Shell midden; Lake shore	3	\N	-351	4	1	-1295	\N	C	2019-12-20 22:14:28.053842+00	1044
1294	Shell midden; Lake shore	3	\N	-350	4	1	-1294	\N	C	2019-12-20 22:14:28.053842+00	1045
1293	Shell midden; Lake shore	3	\N	-349	4	1	-1293	\N	C	2019-12-20 22:14:28.053842+00	1046
1292	Shell midden; Lake shore	3	\N	-348	4	1	-1292	\N	C	2019-12-20 22:14:28.053842+00	1047
1291	Open-air; Close to the coast	3	\N	-347	4	1	-1291	\N	C	2019-12-20 22:14:28.053842+00	1048
1290	Open-air; Close to the coast	3	\N	-346	4	1	-1290	\N	C	2019-12-20 22:14:28.053842+00	1049
1289	Open-air; Close to the coast	3	\N	-345	4	1	-1289	\N	C	2019-12-20 22:14:28.053842+00	1050
1288	Open-air; Close to the coast	3	\N	-344	4	1	-1288	\N	C	2019-12-20 22:14:28.053842+00	1051
1287	Open-air; Close to the coast	3	\N	-343	4	1	-1287	\N	C	2019-12-20 22:14:28.053842+00	1052
1286	Open-air; Inland	3	\N	-342	4	1	-1286	\N	C	2019-12-20 22:14:28.053842+00	1053
1285	Open-air; Inland	3	\N	-341	4	1	-1285	\N	C	2019-12-20 22:14:28.053842+00	1054
1284	Open-air; Inland	3	\N	-340	4	1	-1284	\N	C	2019-12-20 22:14:28.053842+00	1055
1283	Open-air; Inland	3	\N	-339	4	1	-1283	\N	C	2019-12-20 22:14:28.053842+00	1056
1282	Open-air; Inland	3	\N	-338	4	1	-1282	\N	C	2019-12-20 22:14:28.053842+00	1057
1281	Open-air; Inland	3	\N	-337	4	1	-1281	\N	C	2019-12-20 22:14:28.053842+00	1058
1280	Open-air; Inland	3	\N	-336	4	1	-1280	\N	C	2019-12-20 22:14:28.053842+00	1059
1279	Open-air; Inland	3	\N	-335	4	1	-1279	\N	C	2019-12-20 22:14:28.053842+00	1060
1278	Open-air; Inland	3	\N	-334	4	1	-1278	\N	C	2019-12-20 22:14:28.053842+00	1061
1277	Open-air; Inland	3	\N	-333	4	1	-1277	\N	C	2019-12-20 22:14:28.053842+00	1062
1276	Open-air; Inland	3	\N	-332	4	1	-1276	\N	C	2019-12-20 22:14:28.053842+00	1063
1275	Open-air; Inland	3	\N	-331	4	1	-1275	\N	C	2019-12-20 22:14:28.053842+00	1064
1274	Open-air; Inland	3	\N	-330	4	1	-1274	\N	C	2019-12-20 22:14:28.053842+00	1065
1273	Open-air; Inland	3	\N	-329	4	1	-1273	\N	C	2019-12-20 22:14:28.053842+00	1066
1272	Open-air; Inland	3	\N	-328	4	1	-1272	\N	C	2019-12-20 22:14:28.053842+00	1067
1271	Open-air; Inland	3	\N	-327	4	1	-1271	\N	C	2019-12-20 22:14:28.053842+00	1068
1270	Open-air; Inland	3	\N	-326	4	1	-1270	\N	C	2019-12-20 22:14:28.053842+00	1069
1269	Open-air; Inland	3	\N	-325	4	1	-1269	\N	C	2019-12-20 22:14:28.053842+00	1070
1268	Open-air; Inland	3	\N	-324	4	1	-1268	\N	C	2019-12-20 22:14:28.053842+00	1071
1267	Open-air; Inland	3	\N	-323	4	1	-1267	\N	C	2019-12-20 22:14:28.053842+00	1072
1266	Open-air; Inland	3	\N	-322	4	1	-1266	\N	C	2019-12-20 22:14:28.053842+00	1073
1265	Open-air; Inland	3	\N	-321	4	1	-1265	\N	C	2019-12-20 22:14:28.053842+00	1074
1264	Open-air; Inland	3	\N	-320	4	1	-1264	\N	C	2019-12-20 22:14:28.053842+00	1075
1263	Open-air; Inland	3	\N	-319	4	1	-1263	\N	C	2019-12-20 22:14:28.053842+00	1076
1262	Open-air; Inland	3	\N	-318	4	1	-1262	\N	C	2019-12-20 22:14:28.053842+00	1077
1261	Open-air; Inland	3	\N	-317	4	1	-1261	\N	C	2019-12-20 22:14:28.053842+00	1078
1260	Open-air; Inland	3	\N	-316	4	1	-1260	\N	C	2019-12-20 22:14:28.053842+00	1079
1259	Open-air; Inland	3	\N	-315	4	1	-1259	\N	C	2019-12-20 22:14:28.053842+00	1080
1258	Open-air; Inland	3	\N	-314	4	1	-1258	\N	C	2019-12-20 22:14:28.053842+00	1081
1257	Open-air; Inland	3	\N	-313	4	1	-1257	\N	C	2019-12-20 22:14:28.053842+00	1082
1256	Open-air; Inland	3	\N	-312	4	1	-1256	\N	C	2019-12-20 22:14:28.053842+00	1083
1255	Open-air; Inland	3	\N	-311	4	1	-1255	\N	C	2019-12-20 22:14:28.053842+00	1084
1254	Open-air; Inland	3	\N	-310	4	1	-1254	\N	C	2019-12-20 22:14:28.053842+00	1085
1253	Open-air; Inland	3	\N	-309	4	1	-1253	\N	C	2019-12-20 22:14:28.053842+00	1086
1252	Open-air; Inland	3	\N	-308	4	1	-1252	\N	C	2019-12-20 22:14:28.053842+00	1087
1251	Open-air; Inland	3	\N	-307	4	1	-1251	\N	C	2019-12-20 22:14:28.053842+00	1088
1250	Open-air; Inland	3	\N	-306	4	1	-1250	\N	C	2019-12-20 22:14:28.053842+00	1089
1249	Open-air; Inland	3	\N	-305	4	1	-1249	\N	C	2019-12-20 22:14:28.053842+00	1090
1248	Open-air; Inland	3	\N	-304	4	1	-1248	\N	C	2019-12-20 22:14:28.053842+00	1091
1247	Open-air; Inland	3	\N	-303	4	1	-1247	\N	C	2019-12-20 22:14:28.053842+00	1092
1246	Open-air; Inland	3	\N	-302	4	1	-1246	\N	C	2019-12-20 22:14:28.053842+00	1093
1245	Open-air; Inland	3	\N	-301	4	1	-1245	\N	C	2019-12-20 22:14:28.053842+00	1094
1244	Open-air; Inland	3	\N	-300	4	1	-1244	\N	C	2019-12-20 22:14:28.053842+00	1095
1243	Open-air; Inland	3	\N	-299	4	1	-1243	\N	C	2019-12-20 22:14:28.053842+00	1096
1242	Open-air; Inland	3	\N	-298	4	1	-1242	\N	C	2019-12-20 22:14:28.053842+00	1097
1241	Open-air; Inland	3	\N	-297	4	1	-1241	\N	C	2019-12-20 22:14:28.053842+00	1098
1240	Open-air; Inland	3	\N	-296	4	1	-1240	\N	C	2019-12-20 22:14:28.053842+00	1099
1239	Open-air; Inland	3	\N	-295	4	1	-1239	\N	C	2019-12-20 22:14:28.053842+00	1100
1238	Open-air; Inland	3	\N	-294	4	1	-1238	\N	C	2019-12-20 22:14:28.053842+00	1101
1237	Open-air; Inland	3	\N	-293	4	1	-1237	\N	C	2019-12-20 22:14:28.053842+00	1102
1236	Open-air; Inland	3	\N	-292	4	1	-1236	\N	C	2019-12-20 22:14:28.053842+00	1103
1235	Open-air; Inland	3	\N	-291	4	1	-1235	\N	C	2019-12-20 22:14:28.053842+00	1104
1234	Open-air; Inland	3	\N	-290	4	1	-1234	\N	C	2019-12-20 22:14:28.053842+00	1105
1233	Open-air; Inland	3	\N	-289	4	1	-1233	\N	C	2019-12-20 22:14:28.053842+00	1106
1232	Open-air; Inland	3	\N	-288	4	1	-1232	\N	C	2019-12-20 22:14:28.053842+00	1107
1231	Open-air; Inland	3	\N	-287	4	1	-1231	\N	C	2019-12-20 22:14:28.053842+00	1108
1230	Open-air; Inland	3	\N	-286	4	1	-1230	\N	C	2019-12-20 22:14:28.053842+00	1109
1229	Open-air; Inland	3	\N	-285	4	1	-1229	\N	C	2019-12-20 22:14:28.053842+00	1110
1228	Open-air; Inland	3	\N	-284	4	1	-1228	\N	C	2019-12-20 22:14:28.053842+00	1111
1227	Open-air; Inland	3	\N	-283	4	1	-1227	\N	C	2019-12-20 22:14:28.053842+00	1112
1226	Open-air; Inland	3	\N	-282	4	1	-1226	\N	C	2019-12-20 22:14:28.053842+00	1113
1225	Open-air; Inland	3	\N	-281	4	1	-1225	\N	C	2019-12-20 22:14:28.053842+00	1114
1224	Open-air; Inland	3	\N	-280	4	1	-1224	\N	C	2019-12-20 22:14:28.053842+00	1115
1223	Open-air; Inland	3	\N	-279	4	1	-1223	\N	C	2019-12-20 22:14:28.053842+00	1116
1222	Open-air; Inland	3	\N	-278	4	1	-1222	\N	C	2019-12-20 22:14:28.053842+00	1117
1221	Open-air; Inland	3	\N	-277	4	1	-1221	\N	C	2019-12-20 22:14:28.053842+00	1118
1220	Open-air; Inland	3	\N	-276	4	1	-1220	\N	C	2019-12-20 22:14:28.053842+00	1119
1219	Open-air; Inland	3	\N	-275	4	1	-1219	\N	C	2019-12-20 22:14:28.053842+00	1120
1218	Open-air; Inland	3	\N	-274	4	1	-1218	\N	C	2019-12-20 22:14:28.053842+00	1121
1217	Open-air; Inland	3	\N	-273	4	1	-1217	\N	C	2019-12-20 22:14:28.053842+00	1122
1216	Open-air; Inland	3	\N	-272	4	1	-1216	\N	C	2019-12-20 22:14:28.053842+00	1123
1215	Open-air; Inland	3	\N	-271	4	1	-1215	\N	C	2019-12-20 22:14:28.053842+00	1124
1214	Open-air; Inland	3	\N	-270	4	1	-1214	\N	C	2019-12-20 22:14:28.053842+00	1125
1213	Open-air; Inland	3	\N	-269	4	1	-1213	\N	C	2019-12-20 22:14:28.053842+00	1126
1212	Open-air; Inland	3	\N	-268	4	1	-1212	\N	C	2019-12-20 22:14:28.053842+00	1127
1211	Open-air; Inland	3	\N	-267	4	1	-1211	\N	C	2019-12-20 22:14:28.053842+00	1128
1210	Open-air; Inland	3	\N	-266	4	1	-1210	\N	C	2019-12-20 22:14:28.053842+00	1129
1209	Open-air; Inland	3	\N	-265	4	1	-1209	\N	C	2019-12-20 22:14:28.053842+00	1130
1208	Open-air; Inland	3	\N	-264	4	1	-1208	\N	C	2019-12-20 22:14:28.053842+00	1131
1207	Open-air; Inland	3	\N	-263	4	1	-1207	\N	C	2019-12-20 22:14:28.053842+00	1132
1206	Open-air; Inland	3	\N	-262	4	1	-1206	\N	C	2019-12-20 22:14:28.053842+00	1133
1205	Open-air; Inland	3	\N	-261	4	1	-1205	\N	C	2019-12-20 22:14:28.053842+00	1134
1204	Open-air; Inland	3	\N	-260	4	1	-1204	\N	C	2019-12-20 22:14:28.053842+00	1135
1203	Open-air; Inland	3	\N	-259	4	1	-1203	\N	C	2019-12-20 22:14:28.053842+00	1136
1202	Open-air; Inland	3	\N	-258	4	1	-1202	\N	C	2019-12-20 22:14:28.053842+00	1137
1201	Open-air; Inland	3	\N	-257	4	1	-1201	\N	C	2019-12-20 22:14:28.053842+00	1138
1200	Open-air; Inland	3	\N	-256	4	1	-1200	\N	C	2019-12-20 22:14:28.053842+00	1139
1199	Open-air; Inland	3	\N	-255	4	1	-1199	\N	C	2019-12-20 22:14:28.053842+00	1140
1198	Open-air; Inland	3	\N	-254	4	1	-1198	\N	C	2019-12-20 22:14:28.053842+00	1141
1197	Open-air; Inland	3	\N	-253	4	1	-1197	\N	C	2019-12-20 22:14:28.053842+00	1142
1196	Open-air; Inland	3	\N	-252	4	1	-1196	\N	C	2019-12-20 22:14:28.053842+00	1143
1195	Open-air; Inland	3	\N	-251	4	1	-1195	\N	C	2019-12-20 22:14:28.053842+00	1144
1194	Open-air; Inland	3	\N	-250	4	1	-1194	\N	C	2019-12-20 22:14:28.053842+00	1145
1193	Open-air; Inland	3	\N	-249	4	1	-1193	\N	C	2019-12-20 22:14:28.053842+00	1146
1192	Open-air; Inland	3	\N	-248	4	1	-1192	\N	C	2019-12-20 22:14:28.053842+00	1147
1191	Open-air; Inland	3	\N	-247	4	1	-1191	\N	C	2019-12-20 22:14:28.053842+00	1148
1190	Open-air; Inland	3	\N	-246	4	1	-1190	\N	C	2019-12-20 22:14:28.053842+00	1149
1189	Open-air; Inland	3	\N	-245	4	1	-1189	\N	C	2019-12-20 22:14:28.053842+00	1150
1188	Open-air; Inland	3	\N	-244	4	1	-1188	\N	C	2019-12-20 22:14:28.053842+00	1151
1187	Open-air; Inland	3	\N	-243	4	1	-1187	\N	C	2019-12-20 22:14:28.053842+00	1152
1186	Open-air; Inland	3	\N	-242	4	1	-1186	\N	C	2019-12-20 22:14:28.053842+00	1153
1185	Open-air; Inland	3	\N	-241	4	1	-1185	\N	C	2019-12-20 22:14:28.053842+00	1154
1184	Open-air; Inland	3	\N	-240	4	1	-1184	\N	C	2019-12-20 22:14:28.053842+00	1155
1183	Open-air; Inland	3	\N	-239	4	1	-1183	\N	C	2019-12-20 22:14:28.053842+00	1156
1182	Open-air; Mountainous	3	\N	-238	4	1	-1182	\N	C	2019-12-20 22:14:28.053842+00	1157
1181	Open-air; Mountainous	3	\N	-237	4	1	-1181	\N	C	2019-12-20 22:14:28.053842+00	1158
1180	Open-air; Mountainous	3	\N	-236	4	1	-1180	\N	C	2019-12-20 22:14:28.053842+00	1159
1179	Open-air; Mountainous	3	\N	-235	4	1	-1179	\N	C	2019-12-20 22:14:28.053842+00	1160
1178	Open-air; Mountainous	3	\N	-234	4	1	-1178	\N	C	2019-12-20 22:14:28.053842+00	1161
1177	Open-air; Mountainous	3	\N	-233	4	1	-1177	\N	C	2019-12-20 22:14:28.053842+00	1162
1176	Open-air; Mountainous	3	\N	-232	4	1	-1176	\N	C	2019-12-20 22:14:28.053842+00	1163
1175	Open-air; Mountainous	3	\N	-231	4	1	-1175	\N	C	2019-12-20 22:14:28.053842+00	1164
1174	Shell midden; Inland	3	\N	-230	4	1	-1174	\N	C	2019-12-20 22:14:28.053842+00	1165
1173	Shell midden; Inland	3	\N	-229	4	1	-1173	\N	C	2019-12-20 22:14:28.053842+00	1166
1172	Shell midden; Inland	3	\N	-228	4	1	-1172	\N	C	2019-12-20 22:14:28.053842+00	1167
1171	Shell midden; Inland	3	\N	-227	4	1	-1171	\N	C	2019-12-20 22:14:28.053842+00	1168
1170	Shell midden; Inland	3	\N	-226	4	1	-1170	\N	C	2019-12-20 22:14:28.053842+00	1169
1169	Shell midden; Inland	3	\N	-225	4	1	-1169	\N	C	2019-12-20 22:14:28.053842+00	1170
1168	Shell midden; Inland	3	\N	-224	4	1	-1168	\N	C	2019-12-20 22:14:28.053842+00	1171
1167	Shell midden; Inland	3	\N	-223	4	1	-1167	\N	C	2019-12-20 22:14:28.053842+00	1172
1166	Shell midden; Inland	3	\N	-222	4	1	-1166	\N	C	2019-12-20 22:14:28.053842+00	1173
1165	Shell midden; Inland	3	\N	-221	4	1	-1165	\N	C	2019-12-20 22:14:28.053842+00	1174
1164	Shell midden; Inland	3	\N	-220	4	1	-1164	\N	C	2019-12-20 22:14:28.053842+00	1175
1163	Shell midden; Inland	3	\N	-219	4	1	-1163	\N	C	2019-12-20 22:14:28.053842+00	1176
1162	Shell midden; Inland	3	\N	-218	4	1	-1162	\N	C	2019-12-20 22:14:28.053842+00	1177
1161	Shell midden; Inland	3	\N	-217	4	1	-1161	\N	C	2019-12-20 22:14:28.053842+00	1178
1160	Shell midden; Inland	3	\N	-216	4	1	-1160	\N	C	2019-12-20 22:14:28.053842+00	1179
1159	Shell midden; Inland	3	\N	-215	4	1	-1159	\N	C	2019-12-20 22:14:28.053842+00	1180
1158	Shell midden; Inland	3	\N	-214	4	1	-1158	\N	C	2019-12-20 22:14:28.053842+00	1181
1157	Shell midden; Inland	3	\N	-213	4	1	-1157	\N	C	2019-12-20 22:14:28.053842+00	1182
1156	Shell midden; Inland	3	\N	-212	4	1	-1156	\N	C	2019-12-20 22:14:28.053842+00	1183
1155	Shell midden; Inland	3	\N	-211	4	1	-1155	\N	C	2019-12-20 22:14:28.053842+00	1184
1154	Shell midden; Inland	3	\N	-210	4	1	-1154	\N	C	2019-12-20 22:14:28.053842+00	1185
1153	Shell midden; Inland	3	\N	-209	4	1	-1153	\N	C	2019-12-20 22:14:28.053842+00	1186
1152	Shell midden; Inland	3	\N	-208	4	1	-1152	\N	C	2019-12-20 22:14:28.053842+00	1187
1151	Shell midden; Inland	3	\N	-207	4	1	-1151	\N	C	2019-12-20 22:14:28.053842+00	1188
1150	Shell midden; Inland	3	\N	-206	4	1	-1150	\N	C	2019-12-20 22:14:28.053842+00	1189
1149	Shell midden; Inland	3	\N	-205	4	1	-1149	\N	C	2019-12-20 22:14:28.053842+00	1190
1148	Shell midden; Inland	3	\N	-204	4	1	-1148	\N	C	2019-12-20 22:14:28.053842+00	1191
1147	Shell midden; Inland	3	\N	-203	4	1	-1147	\N	C	2019-12-20 22:14:28.053842+00	1192
1146	Shell midden; Inland	3	\N	-202	4	1	-1146	\N	C	2019-12-20 22:14:28.053842+00	1193
1145	Shell midden; Inland	3	\N	-201	4	1	-1145	\N	C	2019-12-20 22:14:28.053842+00	1194
1144	Shell midden; Inland	3	\N	-200	4	1	-1144	\N	C	2019-12-20 22:14:28.053842+00	1195
1143	Shell midden; Inland	3	\N	-199	4	1	-1143	\N	C	2019-12-20 22:14:28.053842+00	1196
1142	Shell midden; Inland	3	\N	-198	4	1	-1142	\N	C	2019-12-20 22:14:28.053842+00	1197
1141	Shell midden; Inland	3	\N	-197	4	1	-1141	\N	C	2019-12-20 22:14:28.053842+00	1198
1140	Rock shelter/Cave; Mountainous	3	\N	-196	4	1	-1140	\N	C	2019-12-20 22:14:28.053842+00	1199
1139	Rock shelter/Cave; Mountainous	3	\N	-195	4	1	-1139	\N	C	2019-12-20 22:14:28.053842+00	1200
1138	Rock shelter/Cave; Mountainous	3	\N	-194	4	1	-1138	\N	C	2019-12-20 22:14:28.053842+00	1201
1137	Rock shelter/Cave; Mountainous	3	\N	-193	4	1	-1137	\N	C	2019-12-20 22:14:28.053842+00	1202
1136	Rock shelter/Cave; Mountainous	3	\N	-192	4	1	-1136	\N	C	2019-12-20 22:14:28.053842+00	1203
1135	Rock shelter/Cave; Mountainous	3	\N	-191	4	1	-1135	\N	C	2019-12-20 22:14:28.053842+00	1204
1134	Rock shelter/Cave; Mountainous	3	\N	-190	4	1	-1134	\N	C	2019-12-20 22:14:28.053842+00	1205
1133	Rock shelter/Cave; Mountainous	3	\N	-189	4	1	-1133	\N	C	2019-12-20 22:14:28.053842+00	1206
1132	Rock shelter/Cave; Mountainous	3	\N	-188	4	1	-1132	\N	C	2019-12-20 22:14:28.053842+00	1207
1131	Rock shelter/Cave; Mountainous	3	\N	-187	4	1	-1131	\N	C	2019-12-20 22:14:28.053842+00	1208
1130	Rock shelter/Cave; Mountainous	3	\N	-186	4	1	-1130	\N	C	2019-12-20 22:14:28.053842+00	1209
1129	Rock shelter/Cave; Mountainous	3	\N	-185	4	1	-1129	\N	C	2019-12-20 22:14:28.053842+00	1210
1128	Rock shelter/Cave; Mountainous	3	\N	-184	4	1	-1128	\N	C	2019-12-20 22:14:28.053842+00	1211
1127	Rock shelter/Cave; Mountainous	3	\N	-183	4	1	-1127	\N	C	2019-12-20 22:14:28.053842+00	1212
1126	Rock shelter/Cave; Mountainous	3	\N	-182	4	1	-1126	\N	C	2019-12-20 22:14:28.053842+00	1213
1125	Rock shelter/Cave; Inland	3	\N	-181	4	1	-1125	\N	C	2019-12-20 22:14:28.053842+00	1214
1124	Rock shelter/Cave; Inland	3	\N	-180	4	1	-1124	\N	C	2019-12-20 22:14:28.053842+00	1215
1123	Rock shelter/Cave; Inland	3	\N	-179	4	1	-1123	\N	C	2019-12-20 22:14:28.053842+00	1216
1122	Rock shelter/Cave; Inland	3	\N	-178	4	1	-1122	\N	C	2019-12-20 22:14:28.053842+00	1217
1121	Rock shelter/Cave; Inland	3	\N	-177	4	1	-1121	\N	C	2019-12-20 22:14:28.053842+00	1218
1120	Rock shelter/Cave; Inland	3	\N	-176	4	1	-1120	\N	C	2019-12-20 22:14:28.053842+00	1219
1119	Rock shelter/Cave; Inland	3	\N	-175	4	1	-1119	\N	C	2019-12-20 22:14:28.053842+00	1220
1118	Shell midden; Inland	3	\N	-174	4	1	-1118	\N	C	2019-12-20 22:14:28.053842+00	1221
1117	Shell midden; Inland	3	\N	-173	4	1	-1117	\N	C	2019-12-20 22:14:28.053842+00	1222
1116	Shell midden; Inland	3	\N	-172	4	1	-1116	\N	C	2019-12-20 22:14:28.053842+00	1223
1115	Shell midden; Inland	3	\N	-171	4	1	-1115	\N	C	2019-12-20 22:14:28.053842+00	1224
1114	Shell midden; Inland	3	\N	-170	4	1	-1114	\N	C	2019-12-20 22:14:28.053842+00	1225
1113	Shell midden; Inland	3	\N	-169	4	1	-1113	\N	C	2019-12-20 22:14:28.053842+00	1226
1112	Shell midden; Inland	3	\N	-168	4	1	-1112	\N	C	2019-12-20 22:14:28.053842+00	1227
1111	Shell midden; Inland	3	\N	-167	4	1	-1111	\N	C	2019-12-20 22:14:28.053842+00	1228
1110	Shell midden; Inland	3	\N	-166	4	1	-1110	\N	C	2019-12-20 22:14:28.053842+00	1229
1109	Shell midden; Inland	3	\N	-165	4	1	-1109	\N	C	2019-12-20 22:14:28.053842+00	1230
1108	Shell midden; Inland	3	\N	-164	4	1	-1108	\N	C	2019-12-20 22:14:28.053842+00	1231
1107	Shell midden; Inland	3	\N	-163	4	1	-1107	\N	C	2019-12-20 22:14:28.053842+00	1232
1106	Shell midden; Inland	3	\N	-162	4	1	-1106	\N	C	2019-12-20 22:14:28.053842+00	1233
1105	Rock shelter/Cave; Mountainous	3	\N	-161	4	1	-1105	\N	C	2019-12-20 22:14:28.053842+00	1234
1104	Rock shelter/Cave; Mountainous	3	\N	-160	4	1	-1104	\N	C	2019-12-20 22:14:28.053842+00	1235
1103	Rock shelter/Cave; Mountainous	3	\N	-159	4	1	-1103	\N	C	2019-12-20 22:14:28.053842+00	1236
1102	Rock shelter/Cave; Mountainous	3	\N	-158	4	1	-1102	\N	C	2019-12-20 22:14:28.053842+00	1237
1101	Rock shelter/Cave; Mountainous	3	\N	-157	4	1	-1101	\N	C	2019-12-20 22:14:28.053842+00	1238
1100	Rock shelter/Cave; Mountainous	3	\N	-156	4	1	-1100	\N	C	2019-12-20 22:14:28.053842+00	1239
1099	Rock shelter/Cave; Mountainous	3	\N	-155	4	1	-1099	\N	C	2019-12-20 22:14:28.053842+00	1240
1098	Rock shelter/Cave; Mountainous	3	\N	-154	4	1	-1098	\N	C	2019-12-20 22:14:28.053842+00	1241
1097	Rock shelter/Cave; Mountainous	3	\N	-153	4	1	-1097	\N	C	2019-12-20 22:14:28.053842+00	1242
1096	Rock shelter/Cave; Mountainous	3	\N	-152	4	1	-1096	\N	C	2019-12-20 22:14:28.053842+00	1243
1095	Rock shelter/Cave; Mountainous	3	\N	-151	4	1	-1095	\N	C	2019-12-20 22:14:28.053842+00	1244
1094	Rock shelter/Cave; Mountainous	3	\N	-150	4	1	-1094	\N	C	2019-12-20 22:14:28.053842+00	1245
1093	Rock shelter/Cave; Mountainous	3	\N	-149	4	1	-1093	\N	C	2019-12-20 22:14:28.053842+00	1246
1092	Rock shelter/Cave; Mountainous	3	\N	-148	4	1	-1092	\N	C	2019-12-20 22:14:28.053842+00	1247
1091	Rock shelter/Cave; Mountainous	3	\N	-147	4	1	-1091	\N	C	2019-12-20 22:14:28.053842+00	1248
1090	Rock shelter/Cave; Mountainous	3	\N	-146	4	1	-1090	\N	C	2019-12-20 22:14:28.053842+00	1249
1089	Rock shelter/Cave; Mountainous	3	\N	-145	4	1	-1089	\N	C	2019-12-20 22:14:28.053842+00	1250
1088	Rock shelter/Cave; Mountainous	3	\N	-144	4	1	-1088	\N	C	2019-12-20 22:14:28.053842+00	1251
1087	Rock shelter/Cave; Mountainous	3	\N	-143	4	1	-1087	\N	C	2019-12-20 22:14:28.053842+00	1252
1086	Rock shelter/Cave; Mountainous	3	\N	-142	4	1	-1086	\N	C	2019-12-20 22:14:28.053842+00	1253
1085	Rock shelter/Cave; Mountainous	3	\N	-141	4	1	-1085	\N	C	2019-12-20 22:14:28.053842+00	1254
1084	Rock shelter/Cave; Mountainous	3	\N	-140	4	1	-1084	\N	C	2019-12-20 22:14:28.053842+00	1255
1083	Rock shelter/Cave; Mountainous	3	\N	-139	4	1	-1083	\N	C	2019-12-20 22:14:28.053842+00	1256
1082	Rock shelter/Cave; Mountainous	3	\N	-138	4	1	-1082	\N	C	2019-12-20 22:14:28.053842+00	1257
1081	Rock shelter/Cave; Mountainous	3	\N	-137	4	1	-1081	\N	C	2019-12-20 22:14:28.053842+00	1258
1080	Rock shelter/Cave; Mountainous	3	\N	-136	4	1	-1080	\N	C	2019-12-20 22:14:28.053842+00	1259
1079	Rock shelter/Cave; Mountainous	3	\N	-135	4	1	-1079	\N	C	2019-12-20 22:14:28.053842+00	1260
1078	Rock shelter/Cave; Mountainous	3	\N	-134	4	1	-1078	\N	C	2019-12-20 22:14:28.053842+00	1261
1077	Rock shelter/Cave; Mountainous	3	\N	-133	4	1	-1077	\N	C	2019-12-20 22:14:28.053842+00	1262
1076	Rock shelter/Cave; Mountainous	3	\N	-132	4	1	-1076	\N	C	2019-12-20 22:14:28.053842+00	1263
1075	Rock shelter/Cave; Mountainous	3	\N	-131	4	1	-1075	\N	C	2019-12-20 22:14:28.053842+00	1264
1074	Rock shelter/Cave; Mountainous	3	\N	-130	4	1	-1074	\N	C	2019-12-20 22:14:28.053842+00	1265
1073	Rock shelter/Cave; Mountainous	3	\N	-129	4	1	-1073	\N	C	2019-12-20 22:14:28.053842+00	1266
1072	Rock shelter/Cave; Mountainous	3	\N	-128	4	1	-1072	\N	C	2019-12-20 22:14:28.053842+00	1267
1071	Rock shelter/Cave; Mountainous	3	\N	-127	4	1	-1071	\N	C	2019-12-20 22:14:28.053842+00	1268
1070	Rock shelter/Cave; Mountainous	3	\N	-126	4	1	-1070	\N	C	2019-12-20 22:14:28.053842+00	1269
1069	Rock shelter/Cave; Mountainous	3	\N	-125	4	1	-1069	\N	C	2019-12-20 22:14:28.053842+00	1270
1068	Rock shelter/Cave; Mountainous	3	\N	-124	4	1	-1068	\N	C	2019-12-20 22:14:28.053842+00	1271
1067	Rock shelter/Cave; Mountainous	3	\N	-123	4	1	-1067	\N	C	2019-12-20 22:14:28.053842+00	1272
1066	Rock shelter/Cave; Mountainous	3	\N	-122	4	1	-1066	\N	C	2019-12-20 22:14:28.053842+00	1273
1065	Rock shelter/Cave; Mountainous	3	\N	-121	4	1	-1065	\N	C	2019-12-20 22:14:28.053842+00	1274
1064	Rock shelter/Cave; Mountainous	3	\N	-120	4	1	-1064	\N	C	2019-12-20 22:14:28.053842+00	1275
1063	Rock shelter/Cave; Mountainous	3	\N	-119	4	1	-1063	\N	C	2019-12-20 22:14:28.053842+00	1276
1062	Rock shelter/Cave; Mountainous	3	\N	-118	4	1	-1062	\N	C	2019-12-20 22:14:28.053842+00	1277
1061	Open-air; Close to the coast	3	\N	-117	4	1	-1061	\N	C	2019-12-20 22:14:28.053842+00	1278
1060	Open-air; Close to the coast	3	\N	-116	4	1	-1060	\N	C	2019-12-20 22:14:28.053842+00	1279
1059	Open-air; Close to the coast	3	\N	-115	4	1	-1059	\N	C	2019-12-20 22:14:28.053842+00	1280
1058	Open-air; Close to the coast	3	\N	-114	4	1	-1058	\N	C	2019-12-20 22:14:28.053842+00	1281
1057	Open-air; Close to the coast	3	\N	-113	4	1	-1057	\N	C	2019-12-20 22:14:28.053842+00	1282
1056	Open-air; Close to the coast	3	\N	-112	4	1	-1056	\N	C	2019-12-20 22:14:28.053842+00	1283
1055	Open-air; Close to the coast	3	\N	-111	4	1	-1055	\N	C	2019-12-20 22:14:28.053842+00	1284
1054	Open-air; Close to the coast	3	\N	-110	4	1	-1054	\N	C	2019-12-20 22:14:28.053842+00	1285
1053	Open-air; Close to the coast	3	\N	-109	4	1	-1053	\N	C	2019-12-20 22:14:28.053842+00	1286
1052	Open-air; Close to the coast	3	\N	-108	4	1	-1052	\N	C	2019-12-20 22:14:28.053842+00	1287
1051	Open-air; Close to the coast	3	\N	-107	4	1	-1051	\N	C	2019-12-20 22:14:28.053842+00	1288
1050	Open-air; Close to the coast	3	\N	-106	4	1	-1050	\N	C	2019-12-20 22:14:28.053842+00	1289
1049	Open-air; Close to the coast	3	\N	-105	4	1	-1049	\N	C	2019-12-20 22:14:28.053842+00	1290
1048	Open-air; Close to the coast	3	\N	-104	4	1	-1048	\N	C	2019-12-20 22:14:28.053842+00	1291
1047	Open-air; Close to the coast	3	\N	-103	4	1	-1047	\N	C	2019-12-20 22:14:28.053842+00	1292
1046	Open-air; Close to the coast	3	\N	-102	4	1	-1046	\N	C	2019-12-20 22:14:28.053842+00	1293
1045	Open-air; Close to the coast	3	\N	-101	4	1	-1045	\N	C	2019-12-20 22:14:28.053842+00	1294
1044	Open-air; Close to the coast	3	\N	-100	4	1	-1044	\N	C	2019-12-20 22:14:28.053842+00	1295
1043	Open-air; Close to the coast	3	\N	-99	4	1	-1043	\N	C	2019-12-20 22:14:28.053842+00	1296
1042	Open-air; Close to the coast	3	\N	-98	4	1	-1042	\N	C	2019-12-20 22:14:28.053842+00	1297
1041	Open-air; Close to the coast	3	\N	-97	4	1	-1041	\N	C	2019-12-20 22:14:28.053842+00	1298
1040	Open-air; Close to the coast	3	\N	-96	4	1	-1040	\N	C	2019-12-20 22:14:28.053842+00	1299
1039	Open-air; Close to the coast	3	\N	-95	4	1	-1039	\N	C	2019-12-20 22:14:28.053842+00	1300
1038	Open-air; Close to the coast	3	\N	-94	4	1	-1038	\N	C	2019-12-20 22:14:28.053842+00	1301
1037	Open-air; Close to the coast	3	\N	-93	4	1	-1037	\N	C	2019-12-20 22:14:28.053842+00	1302
1036	Open-air; Close to the coast	3	\N	-92	4	1	-1036	\N	C	2019-12-20 22:14:28.053842+00	1303
1035	Open-air; Close to the coast	3	\N	-91	4	1	-1035	\N	C	2019-12-20 22:14:28.053842+00	1304
1034	Open-air; Close to the coast	3	\N	-90	4	1	-1034	\N	C	2019-12-20 22:14:28.053842+00	1305
1033	Open-air; Close to the coast	3	\N	-89	4	1	-1033	\N	C	2019-12-20 22:14:28.053842+00	1306
1032	Open-air; Close to the coast	3	\N	-88	4	1	-1032	\N	C	2019-12-20 22:14:28.053842+00	1307
1031	Open-air; Close to the coast	3	\N	-87	4	1	-1031	\N	C	2019-12-20 22:14:28.053842+00	1308
1030	Open-air; Close to the coast	3	\N	-86	4	1	-1030	\N	C	2019-12-20 22:14:28.053842+00	1309
1029	Open-air; Close to the coast	3	\N	-85	4	1	-1029	\N	C	2019-12-20 22:14:28.053842+00	1310
1028	Open-air; Close to the coast	3	\N	-84	4	1	-1028	\N	C	2019-12-20 22:14:28.053842+00	1311
1027	Open-air; Close to the coast	3	\N	-83	4	1	-1027	\N	C	2019-12-20 22:14:28.053842+00	1312
1026	Open-air; Close to the coast	3	\N	-82	4	1	-1026	\N	C	2019-12-20 22:14:28.053842+00	1313
1025	Open-air; Close to the coast	3	\N	-81	4	1	-1025	\N	C	2019-12-20 22:14:28.053842+00	1314
1024	Open-air; Close to the coast	3	\N	-80	4	1	-1024	\N	C	2019-12-20 22:14:28.053842+00	1315
1023	Open-air; Close to the coast	3	\N	-79	4	1	-1023	\N	C	2019-12-20 22:14:28.053842+00	1316
1022	Open-air; Close to the coast	3	\N	-78	4	1	-1022	\N	C	2019-12-20 22:14:28.053842+00	1317
1021	Open-air; Close to the coast	3	\N	-77	4	1	-1021	\N	C	2019-12-20 22:14:28.053842+00	1318
1020	Open-air; Close to the coast	3	\N	-76	4	1	-1020	\N	C	2019-12-20 22:14:28.053842+00	1319
1019	Open-air; Close to the coast	3	\N	-75	4	1	-1019	\N	C	2019-12-20 22:14:28.053842+00	1320
1018	Open-air; Close to the coast	3	\N	-74	4	1	-1018	\N	C	2019-12-20 22:14:28.053842+00	1321
1017	Open-air; Close to the coast	3	\N	-73	4	1	-1017	\N	C	2019-12-20 22:14:28.053842+00	1322
1016	Open-air; Close to the coast	3	\N	-72	4	1	-1016	\N	C	2019-12-20 22:14:28.053842+00	1323
1015	Open-air; Close to the coast	3	\N	-71	4	1	-1015	\N	C	2019-12-20 22:14:28.053842+00	1324
1014	Open-air; Close to the coast	3	\N	-70	4	1	-1014	\N	C	2019-12-20 22:14:28.053842+00	1325
1013	Open-air; Close to the coast	3	\N	-69	4	1	-1013	\N	C	2019-12-20 22:14:28.053842+00	1326
1012	Open-air; Close to the coast	3	\N	-68	4	1	-1012	\N	C	2019-12-20 22:14:28.053842+00	1327
1011	Open-air; Close to the coast	3	\N	-67	4	1	-1011	\N	C	2019-12-20 22:14:28.053842+00	1328
1010	Open-air; Close to the coast	3	\N	-66	4	1	-1010	\N	C	2019-12-20 22:14:28.053842+00	1329
1009	Open-air; Close to the coast	3	\N	-65	4	1	-1009	\N	C	2019-12-20 22:14:28.053842+00	1330
1008	Open-air; Close to the coast	3	\N	-64	4	1	-1008	\N	C	2019-12-20 22:14:28.053842+00	1331
1007	Open-air; Close to the coast	3	\N	-63	4	1	-1007	\N	C	2019-12-20 22:14:28.053842+00	1332
1006	Open-air; Close to the coast	3	\N	-62	4	1	-1006	\N	C	2019-12-20 22:14:28.053842+00	1333
1005	Open-air; Close to the coast	3	\N	-61	4	1	-1005	\N	C	2019-12-20 22:14:28.053842+00	1334
1004	Open-air; Close to the coast	3	\N	-60	4	1	-1004	\N	C	2019-12-20 22:14:28.053842+00	1335
1003	Open-air; Close to the coast	3	\N	-59	4	1	-1003	\N	C	2019-12-20 22:14:28.053842+00	1336
1002	Open-air; Close to the coast	3	\N	-58	4	1	-1002	\N	C	2019-12-20 22:14:28.053842+00	1337
1001	Open-air; Close to the coast	3	\N	-57	4	1	-1001	\N	C	2019-12-20 22:14:28.053842+00	1338
1000	Open-air; Close to the coast	3	\N	-56	4	1	-1000	\N	C	2019-12-20 22:14:28.053842+00	1339
999	Open-air; Close to the coast	3	\N	-55	4	1	-999	\N	C	2019-12-20 22:14:28.053842+00	1340
998	Open-air; Close to the coast	3	\N	-54	4	1	-998	\N	C	2019-12-20 22:14:28.053842+00	1341
997	Open-air; Close to the coast	3	\N	-53	4	1	-997	\N	C	2019-12-20 22:14:28.053842+00	1342
996	Open-air; Close to the coast	3	\N	-52	4	1	-996	\N	C	2019-12-20 22:14:28.053842+00	1343
995	Open-air; Close to the coast	3	\N	-51	4	1	-995	\N	C	2019-12-20 22:14:28.053842+00	1344
994	Open-air; Close to the coast	3	\N	-50	4	1	-994	\N	C	2019-12-20 22:14:28.053842+00	1345
993	Open-air; Close to the coast	3	\N	-49	4	1	-993	\N	C	2019-12-20 22:14:28.053842+00	1346
992	Open-air; Close to the coast	3	\N	-48	4	1	-992	\N	C	2019-12-20 22:14:28.053842+00	1347
991	Open-air; Close to the coast	3	\N	-47	4	1	-991	\N	C	2019-12-20 22:14:28.053842+00	1348
990	Open-air; Close to the coast	3	\N	-46	4	1	-990	\N	C	2019-12-20 22:14:28.053842+00	1349
988	Open-air; Close to the coast	3	\N	-44	4	1	-988	\N	C	2019-12-20 22:14:28.053842+00	1351
987	Open-air; Close to the coast	3	\N	-43	4	1	-987	\N	C	2019-12-20 22:14:28.053842+00	1352
986	Open-air; Close to the coast	3	\N	-42	4	1	-986	\N	C	2019-12-20 22:14:28.053842+00	1353
985	Open-air; Close to the coast	3	\N	-41	4	1	-985	\N	C	2019-12-20 22:14:28.053842+00	1354
984	Open-air; Close to the coast	3	\N	-40	4	1	-984	\N	C	2019-12-20 22:14:28.053842+00	1355
983	Open-air; Close to the coast	3	\N	-39	4	1	-983	\N	C	2019-12-20 22:14:28.053842+00	1356
982	Open-air; Close to the coast	3	\N	-38	4	1	-982	\N	C	2019-12-20 22:14:28.053842+00	1357
981	Open-air; Close to the coast	3	\N	-37	4	1	-981	\N	C	2019-12-20 22:14:28.053842+00	1358
980	Open-air; Close to the coast	3	\N	-36	4	1	-980	\N	C	2019-12-20 22:14:28.053842+00	1359
979	Open-air; Close to the coast	3	\N	-35	4	1	-979	\N	C	2019-12-20 22:14:28.053842+00	1360
978	Open-air; Close to the coast	3	\N	-34	4	1	-978	\N	C	2019-12-20 22:14:28.053842+00	1361
977	Open-air; Close to the coast	3	\N	-33	4	1	-977	\N	C	2019-12-20 22:14:28.053842+00	1362
976	Open-air; Close to the coast	3	\N	-32	4	1	-976	\N	C	2019-12-20 22:14:28.053842+00	1363
975	Open-air; Close to the coast	3	\N	-31	4	1	-975	\N	C	2019-12-20 22:14:28.053842+00	1364
974	Open-air; Close to the coast	3	\N	-30	4	1	-974	\N	C	2019-12-20 22:14:28.053842+00	1365
973	Open-air; Close to the coast	3	\N	-29	4	1	-973	\N	C	2019-12-20 22:14:28.053842+00	1366
972	Open-air; Close to the coast	3	\N	-28	4	1	-972	\N	C	2019-12-20 22:14:28.053842+00	1367
971	Open-air; Inland	3	\N	-27	4	1	-971	\N	C	2019-12-20 22:14:28.053842+00	1368
970	Open-air; Inland	3	\N	-26	4	1	-970	\N	C	2019-12-20 22:14:28.053842+00	1369
969	Open-air; Inland	3	\N	-25	4	1	-969	\N	C	2019-12-20 22:14:28.053842+00	1370
968	Open-air; Inland	3	\N	-24	4	1	-968	\N	C	2019-12-20 22:14:28.053842+00	1371
967	Open-air; Inland	3	\N	-23	4	1	-967	\N	C	2019-12-20 22:14:28.053842+00	1372
966	Open-air; Inland	3	\N	-22	4	1	-966	\N	C	2019-12-20 22:14:28.053842+00	1373
965	Open-air; Inland	3	\N	-21	4	1	-965	\N	C	2019-12-20 22:14:28.053842+00	1374
964	Open-air; Inland	3	\N	-20	4	1	-964	\N	C	2019-12-20 22:14:28.053842+00	1375
963	Open-air; Inland	3	\N	-19	4	1	-963	\N	C	2019-12-20 22:14:28.053842+00	1376
962	Open-air; Inland	3	\N	-18	4	1	-962	\N	C	2019-12-20 22:14:28.053842+00	1377
961	Open-air; Inland	3	\N	-17	4	1	-961	\N	C	2019-12-20 22:14:28.053842+00	1378
960	Open-air; Inland	3	\N	-16	4	1	-960	\N	C	2019-12-20 22:14:28.053842+00	1379
959	Open-air; Inland	3	\N	-15	4	1	-959	\N	C	2019-12-20 22:14:28.053842+00	1380
958	Open-air; Inland	3	\N	-14	4	1	-958	\N	C	2019-12-20 22:14:28.053842+00	1381
957	Open-air; Inland	3	\N	-13	4	1	-957	\N	C	2019-12-20 22:14:28.053842+00	1382
956	Open-air; Inland	3	\N	-12	4	1	-956	\N	C	2019-12-20 22:14:28.053842+00	1383
955	Open-air; Inland	3	\N	-11	4	1	-955	\N	C	2019-12-20 22:14:28.053842+00	1384
954	Open-air; Inland	3	\N	-10	4	1	-954	\N	C	2019-12-20 22:14:28.053842+00	1385
953	Open-air; Inland	3	\N	-9	4	1	-953	\N	C	2019-12-20 22:14:28.053842+00	1386
952	Open-air; Inland	3	\N	-8	4	1	-952	\N	C	2019-12-20 22:14:28.053842+00	1387
951	Open-air; Inland	3	\N	-7	4	1	-951	\N	C	2019-12-20 22:14:28.053842+00	1388
950	Open-air; Inland	3	\N	-6	4	1	-950	\N	C	2019-12-20 22:14:28.053842+00	1389
949	Open-air; Inland	3	\N	-5	4	1	-949	\N	C	2019-12-20 22:14:28.053842+00	1390
948	Open-air; Inland	3	\N	-4	4	1	-948	\N	C	2019-12-20 22:14:28.053842+00	1391
947	Open-air; Inland	3	\N	-3	4	1	-947	\N	C	2019-12-20 22:14:28.053842+00	1392
946	Open-air; Inland	3	\N	-2	4	1	-946	\N	C	2019-12-20 22:14:28.053842+00	1393
945	Open-air; Inland	3	\N	-1	4	1	-945	\N	C	2019-12-20 22:14:28.053842+00	1394
944	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-944	4	1	-944	\N	C	2019-12-20 22:14:28.053842+00	1395
943	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-943	4	1	-943	\N	C	2019-12-20 22:14:28.053842+00	1396
942	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-942	4	1	-942	\N	C	2019-12-20 22:14:28.053842+00	1397
941	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-941	4	1	-941	\N	C	2019-12-20 22:14:28.053842+00	1398
940	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-940	4	1	-940	\N	C	2019-12-20 22:14:28.053842+00	1399
939	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-939	4	1	-939	\N	C	2019-12-20 22:14:28.053842+00	1400
938	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-938	4	1	-938	\N	C	2019-12-20 22:14:28.053842+00	1401
937	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-937	4	1	-937	\N	C	2019-12-20 22:14:28.053842+00	1402
936	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-936	4	1	-936	\N	C	2019-12-20 22:14:28.053842+00	1403
935	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-935	4	1	-935	\N	C	2019-12-20 22:14:28.053842+00	1404
934	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-934	4	1	-934	\N	C	2019-12-20 22:14:28.053842+00	1405
933	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-933	4	1	-933	\N	C	2019-12-20 22:14:28.053842+00	1406
932	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-932	4	1	-932	\N	C	2019-12-20 22:14:28.053842+00	1407
931	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-931	4	1	-931	\N	C	2019-12-20 22:14:28.053842+00	1408
930	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-930	4	1	-930	\N	C	2019-12-20 22:14:28.053842+00	1409
929	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-929	4	1	-929	\N	C	2019-12-20 22:14:28.053842+00	1410
928	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-928	4	1	-928	\N	C	2019-12-20 22:14:28.053842+00	1411
927	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-927	4	1	-927	\N	C	2019-12-20 22:14:28.053842+00	1412
926	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-926	4	1	-926	\N	C	2019-12-20 22:14:28.053842+00	1413
925	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-925	4	1	-925	\N	C	2019-12-20 22:14:28.053842+00	1414
924	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-924	4	1	-924	\N	C	2019-12-20 22:14:28.053842+00	1415
923	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-923	4	1	-923	\N	C	2019-12-20 22:14:28.053842+00	1416
922	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-922	4	1	-922	\N	C	2019-12-20 22:14:28.053842+00	1417
921	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-921	4	1	-921	\N	C	2019-12-20 22:14:28.053842+00	1418
920	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-920	4	1	-920	\N	C	2019-12-20 22:14:28.053842+00	1419
919	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-919	4	1	-919	\N	C	2019-12-20 22:14:28.053842+00	1420
918	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-918	4	1	-918	\N	C	2019-12-20 22:14:28.053842+00	1421
917	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-917	4	1	-917	\N	C	2019-12-20 22:14:28.053842+00	1422
916	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-916	4	1	-916	\N	C	2019-12-20 22:14:28.053842+00	1423
915	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-915	4	1	-915	\N	C	2019-12-20 22:14:28.053842+00	1424
914	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-914	4	1	-914	\N	C	2019-12-20 22:14:28.053842+00	1425
913	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-913	4	1	-913	\N	C	2019-12-20 22:14:28.053842+00	1426
912	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-912	4	1	-912	\N	C	2019-12-20 22:14:28.053842+00	1427
911	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-911	4	1	-911	\N	C	2019-12-20 22:14:28.053842+00	1428
910	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-910	4	1	-910	\N	C	2019-12-20 22:14:28.053842+00	1429
909	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-909	4	1	-909	\N	C	2019-12-20 22:14:28.053842+00	1430
908	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-908	4	1	-908	\N	C	2019-12-20 22:14:28.053842+00	1431
907	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-907	4	1	-907	\N	C	2019-12-20 22:14:28.053842+00	1432
906	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-906	4	1	-906	\N	C	2019-12-20 22:14:28.053842+00	1433
905	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-905	4	1	-905	\N	C	2019-12-20 22:14:28.053842+00	1434
904	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-904	4	1	-904	\N	C	2019-12-20 22:14:28.053842+00	1435
903	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-903	4	1	-903	\N	C	2019-12-20 22:14:28.053842+00	1436
902	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-902	4	1	-902	\N	C	2019-12-20 22:14:28.053842+00	1437
901	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-901	4	1	-901	\N	C	2019-12-20 22:14:28.053842+00	1438
900	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-900	4	1	-900	\N	C	2019-12-20 22:14:28.053842+00	1439
899	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-899	4	1	-899	\N	C	2019-12-20 22:14:28.053842+00	1440
898	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-898	4	1	-898	\N	C	2019-12-20 22:14:28.053842+00	1441
897	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-897	4	1	-897	\N	C	2019-12-20 22:14:28.053842+00	1442
896	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-896	4	1	-896	\N	C	2019-12-20 22:14:28.053842+00	1443
895	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-895	4	1	-895	\N	C	2019-12-20 22:14:28.053842+00	1444
894	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-894	4	1	-894	\N	C	2019-12-20 22:14:28.053842+00	1445
893	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-893	4	1	-893	\N	C	2019-12-20 22:14:28.053842+00	1446
892	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-892	4	1	-892	\N	C	2019-12-20 22:14:28.053842+00	1447
891	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-891	4	1	-891	\N	C	2019-12-20 22:14:28.053842+00	1448
890	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-890	4	1	-890	\N	C	2019-12-20 22:14:28.053842+00	1449
889	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-889	4	1	-889	\N	C	2019-12-20 22:14:28.053842+00	1450
888	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-888	4	1	-888	\N	C	2019-12-20 22:14:28.053842+00	1451
887	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-887	4	1	-887	\N	C	2019-12-20 22:14:28.053842+00	1452
886	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-886	4	1	-886	\N	C	2019-12-20 22:14:28.053842+00	1453
885	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-885	4	1	-885	\N	C	2019-12-20 22:14:28.053842+00	1454
884	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-884	4	1	-884	\N	C	2019-12-20 22:14:28.053842+00	1455
883	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-883	4	1	-883	\N	C	2019-12-20 22:14:28.053842+00	1456
882	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-882	4	1	-882	\N	C	2019-12-20 22:14:28.053842+00	1457
881	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-881	4	1	-881	\N	C	2019-12-20 22:14:28.053842+00	1458
880	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-880	4	1	-880	\N	C	2019-12-20 22:14:28.053842+00	1459
879	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-879	4	1	-879	\N	C	2019-12-20 22:14:28.053842+00	1460
878	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-878	4	1	-878	\N	C	2019-12-20 22:14:28.053842+00	1461
877	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-877	4	1	-877	\N	C	2019-12-20 22:14:28.053842+00	1462
876	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-876	4	1	-876	\N	C	2019-12-20 22:14:28.053842+00	1463
875	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-875	4	1	-875	\N	C	2019-12-20 22:14:28.053842+00	1464
874	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-874	4	1	-874	\N	C	2019-12-20 22:14:28.053842+00	1465
873	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-873	4	1	-873	\N	C	2019-12-20 22:14:28.053842+00	1466
872	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-872	4	1	-872	\N	C	2019-12-20 22:14:28.053842+00	1467
871	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-871	4	1	-871	\N	C	2019-12-20 22:14:28.053842+00	1468
870	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-870	4	1	-870	\N	C	2019-12-20 22:14:28.053842+00	1469
869	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-869	4	1	-869	\N	C	2019-12-20 22:14:28.053842+00	1470
868	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-868	4	1	-868	\N	C	2019-12-20 22:14:28.053842+00	1471
867	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-867	4	1	-867	\N	C	2019-12-20 22:14:28.053842+00	1472
866	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-866	4	1	-866	\N	C	2019-12-20 22:14:28.053842+00	1473
865	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-865	4	1	-865	\N	C	2019-12-20 22:14:28.053842+00	1474
864	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-864	4	1	-864	\N	C	2019-12-20 22:14:28.053842+00	1475
863	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-863	4	1	-863	\N	C	2019-12-20 22:14:28.053842+00	1476
862	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-862	4	1	-862	\N	C	2019-12-20 22:14:28.053842+00	1477
861	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-861	4	1	-861	\N	C	2019-12-20 22:14:28.053842+00	1478
860	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-860	4	1	-860	\N	C	2019-12-20 22:14:28.053842+00	1479
859	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-859	4	1	-859	\N	C	2019-12-20 22:14:28.053842+00	1480
858	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-858	4	1	-858	\N	C	2019-12-20 22:14:28.053842+00	1481
857	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-857	4	1	-857	\N	C	2019-12-20 22:14:28.053842+00	1482
856	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-856	4	1	-856	\N	C	2019-12-20 22:14:28.053842+00	1483
855	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-855	4	1	-855	\N	C	2019-12-20 22:14:28.053842+00	1484
854	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-854	4	1	-854	\N	C	2019-12-20 22:14:28.053842+00	1485
853	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-853	4	1	-853	\N	C	2019-12-20 22:14:28.053842+00	1486
852	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-852	4	1	-852	\N	C	2019-12-20 22:14:28.053842+00	1487
851	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-851	4	1	-851	\N	C	2019-12-20 22:14:28.053842+00	1488
850	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-850	4	1	-850	\N	C	2019-12-20 22:14:28.053842+00	1489
849	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-849	4	1	-849	\N	C	2019-12-20 22:14:28.053842+00	1490
848	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-848	4	1	-848	\N	C	2019-12-20 22:14:28.053842+00	1491
847	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-847	4	1	-847	\N	C	2019-12-20 22:14:28.053842+00	1492
846	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-846	4	1	-846	\N	C	2019-12-20 22:14:28.053842+00	1493
845	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-845	4	1	-845	\N	C	2019-12-20 22:14:28.053842+00	1494
844	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-844	4	1	-844	\N	C	2019-12-20 22:14:28.053842+00	1495
843	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-843	4	1	-843	\N	C	2019-12-20 22:14:28.053842+00	1496
842	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-842	4	1	-842	\N	C	2019-12-20 22:14:28.053842+00	1497
841	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-841	4	1	-841	\N	C	2019-12-20 22:14:28.053842+00	1498
840	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-840	4	1	-840	\N	C	2019-12-20 22:14:28.053842+00	1499
839	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-839	4	1	-839	\N	C	2019-12-20 22:14:28.053842+00	1500
838	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-838	4	1	-838	\N	C	2019-12-20 22:14:28.053842+00	1501
837	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-837	4	1	-837	\N	C	2019-12-20 22:14:28.053842+00	1502
836	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-836	4	1	-836	\N	C	2019-12-20 22:14:28.053842+00	1503
835	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-835	4	1	-835	\N	C	2019-12-20 22:14:28.053842+00	1504
834	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-834	4	1	-834	\N	C	2019-12-20 22:14:28.053842+00	1505
833	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-833	4	1	-833	\N	C	2019-12-20 22:14:28.053842+00	1506
832	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-832	4	1	-832	\N	C	2019-12-20 22:14:28.053842+00	1507
831	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-831	4	1	-831	\N	C	2019-12-20 22:14:28.053842+00	1508
830	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-830	4	1	-830	\N	C	2019-12-20 22:14:28.053842+00	1509
829	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-829	4	1	-829	\N	C	2019-12-20 22:14:28.053842+00	1510
828	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-828	4	1	-828	\N	C	2019-12-20 22:14:28.053842+00	1511
827	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-827	4	1	-827	\N	C	2019-12-20 22:14:28.053842+00	1512
826	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-826	4	1	-826	\N	C	2019-12-20 22:14:28.053842+00	1513
825	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-825	4	1	-825	\N	C	2019-12-20 22:14:28.053842+00	1514
824	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-824	4	1	-824	\N	C	2019-12-20 22:14:28.053842+00	1515
823	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-823	4	1	-823	\N	C	2019-12-20 22:14:28.053842+00	1516
822	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-822	4	1	-822	\N	C	2019-12-20 22:14:28.053842+00	1517
821	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-821	4	1	-821	\N	C	2019-12-20 22:14:28.053842+00	1518
820	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-820	4	1	-820	\N	C	2019-12-20 22:14:28.053842+00	1519
819	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-819	4	1	-819	\N	C	2019-12-20 22:14:28.053842+00	1520
818	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-818	4	1	-818	\N	C	2019-12-20 22:14:28.053842+00	1521
817	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-817	4	1	-817	\N	C	2019-12-20 22:14:28.053842+00	1522
816	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-816	4	1	-816	\N	C	2019-12-20 22:14:28.053842+00	1523
815	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-815	4	1	-815	\N	C	2019-12-20 22:14:28.053842+00	1524
814	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-814	4	1	-814	\N	C	2019-12-20 22:14:28.053842+00	1525
813	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-813	4	1	-813	\N	C	2019-12-20 22:14:28.053842+00	1526
812	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-812	4	1	-812	\N	C	2019-12-20 22:14:28.053842+00	1527
811	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-811	4	1	-811	\N	C	2019-12-20 22:14:28.053842+00	1528
810	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-810	4	1	-810	\N	C	2019-12-20 22:14:28.053842+00	1529
809	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-809	4	1	-809	\N	C	2019-12-20 22:14:28.053842+00	1530
808	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-808	4	1	-808	\N	C	2019-12-20 22:14:28.053842+00	1531
807	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-807	4	1	-807	\N	C	2019-12-20 22:14:28.053842+00	1532
806	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-806	4	1	-806	\N	C	2019-12-20 22:14:28.053842+00	1533
805	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-805	4	1	-805	\N	C	2019-12-20 22:14:28.053842+00	1534
804	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-804	4	1	-804	\N	C	2019-12-20 22:14:28.053842+00	1535
803	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-803	4	1	-803	\N	C	2019-12-20 22:14:28.053842+00	1536
802	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-802	4	1	-802	\N	C	2019-12-20 22:14:28.053842+00	1537
801	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-801	4	1	-801	\N	C	2019-12-20 22:14:28.053842+00	1538
800	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-800	4	1	-800	\N	C	2019-12-20 22:14:28.053842+00	1539
799	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-799	4	1	-799	\N	C	2019-12-20 22:14:28.053842+00	1540
798	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-798	4	1	-798	\N	C	2019-12-20 22:14:28.053842+00	1541
797	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-797	4	1	-797	\N	C	2019-12-20 22:14:28.053842+00	1542
796	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-796	4	1	-796	\N	C	2019-12-20 22:14:28.053842+00	1543
795	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-795	4	1	-795	\N	C	2019-12-20 22:14:28.053842+00	1544
794	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-794	4	1	-794	\N	C	2019-12-20 22:14:28.053842+00	1545
793	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-793	4	1	-793	\N	C	2019-12-20 22:14:28.053842+00	1546
792	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-792	4	1	-792	\N	C	2019-12-20 22:14:28.053842+00	1547
791	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-791	4	1	-791	\N	C	2019-12-20 22:14:28.053842+00	1548
790	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-790	4	1	-790	\N	C	2019-12-20 22:14:28.053842+00	1549
789	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-789	4	1	-789	\N	C	2019-12-20 22:14:28.053842+00	1550
788	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-788	4	1	-788	\N	C	2019-12-20 22:14:28.053842+00	1551
787	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-787	4	1	-787	\N	C	2019-12-20 22:14:28.053842+00	1552
786	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-786	4	1	-786	\N	C	2019-12-20 22:14:28.053842+00	1553
785	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-785	4	1	-785	\N	C	2019-12-20 22:14:28.053842+00	1554
784	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-784	4	1	-784	\N	C	2019-12-20 22:14:28.053842+00	1555
783	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-783	4	1	-783	\N	C	2019-12-20 22:14:28.053842+00	1556
782	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-782	4	1	-782	\N	C	2019-12-20 22:14:28.053842+00	1557
781	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-781	4	1	-781	\N	C	2019-12-20 22:14:28.053842+00	1558
780	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-780	4	1	-780	\N	C	2019-12-20 22:14:28.053842+00	1559
779	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-779	4	1	-779	\N	C	2019-12-20 22:14:28.053842+00	1560
778	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-778	4	1	-778	\N	C	2019-12-20 22:14:28.053842+00	1561
777	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-777	4	1	-777	\N	C	2019-12-20 22:14:28.053842+00	1562
776	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-776	4	1	-776	\N	C	2019-12-20 22:14:28.053842+00	1563
775	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-775	4	1	-775	\N	C	2019-12-20 22:14:28.053842+00	1564
774	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-774	4	1	-774	\N	C	2019-12-20 22:14:28.053842+00	1565
773	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-773	4	1	-773	\N	C	2019-12-20 22:14:28.053842+00	1566
772	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-772	4	1	-772	\N	C	2019-12-20 22:14:28.053842+00	1567
771	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-771	4	1	-771	\N	C	2019-12-20 22:14:28.053842+00	1568
770	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-770	4	1	-770	\N	C	2019-12-20 22:14:28.053842+00	1569
769	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-769	4	1	-769	\N	C	2019-12-20 22:14:28.053842+00	1570
768	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-768	4	1	-768	\N	C	2019-12-20 22:14:28.053842+00	1571
767	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-767	4	1	-767	\N	C	2019-12-20 22:14:28.053842+00	1572
766	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-766	4	1	-766	\N	C	2019-12-20 22:14:28.053842+00	1573
765	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-765	4	1	-765	\N	C	2019-12-20 22:14:28.053842+00	1574
764	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-764	4	1	-764	\N	C	2019-12-20 22:14:28.053842+00	1575
763	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-763	4	1	-763	\N	C	2019-12-20 22:14:28.053842+00	1576
762	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-762	4	1	-762	\N	C	2019-12-20 22:14:28.053842+00	1577
761	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-761	4	1	-761	\N	C	2019-12-20 22:14:28.053842+00	1578
760	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-760	4	1	-760	\N	C	2019-12-20 22:14:28.053842+00	1579
759	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-759	4	1	-759	\N	C	2019-12-20 22:14:28.053842+00	1580
758	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-758	4	1	-758	\N	C	2019-12-20 22:14:28.053842+00	1581
757	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-757	4	1	-757	\N	C	2019-12-20 22:14:28.053842+00	1582
756	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-756	4	1	-756	\N	C	2019-12-20 22:14:28.053842+00	1583
755	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-755	4	1	-755	\N	C	2019-12-20 22:14:28.053842+00	1584
754	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-754	4	1	-754	\N	C	2019-12-20 22:14:28.053842+00	1585
753	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-753	4	1	-753	\N	C	2019-12-20 22:14:28.053842+00	1586
752	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-752	4	1	-752	\N	C	2019-12-20 22:14:28.053842+00	1587
751	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-751	4	1	-751	\N	C	2019-12-20 22:14:28.053842+00	1588
750	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-750	4	1	-750	\N	C	2019-12-20 22:14:28.053842+00	1589
749	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-749	4	1	-749	\N	C	2019-12-20 22:14:28.053842+00	1590
748	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-748	4	1	-748	\N	C	2019-12-20 22:14:28.053842+00	1591
747	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-747	4	1	-747	\N	C	2019-12-20 22:14:28.053842+00	1592
746	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-746	4	1	-746	\N	C	2019-12-20 22:14:28.053842+00	1593
745	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-745	4	1	-745	\N	C	2019-12-20 22:14:28.053842+00	1594
744	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-744	4	1	-744	\N	C	2019-12-20 22:14:28.053842+00	1595
743	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-743	4	1	-743	\N	C	2019-12-20 22:14:28.053842+00	1596
742	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-742	4	1	-742	\N	C	2019-12-20 22:14:28.053842+00	1597
741	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-741	4	1	-741	\N	C	2019-12-20 22:14:28.053842+00	1598
740	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-740	4	1	-740	\N	C	2019-12-20 22:14:28.053842+00	1599
739	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-739	4	1	-739	\N	C	2019-12-20 22:14:28.053842+00	1600
738	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-738	4	1	-738	\N	C	2019-12-20 22:14:28.053842+00	1601
737	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-737	4	1	-737	\N	C	2019-12-20 22:14:28.053842+00	1602
736	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-736	4	1	-736	\N	C	2019-12-20 22:14:28.053842+00	1603
735	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-735	4	1	-735	\N	C	2019-12-20 22:14:28.053842+00	1604
734	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-734	4	1	-734	\N	C	2019-12-20 22:14:28.053842+00	1605
733	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-733	4	1	-733	\N	C	2019-12-20 22:14:28.053842+00	1606
732	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-732	4	1	-732	\N	C	2019-12-20 22:14:28.053842+00	1607
731	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-731	4	1	-731	\N	C	2019-12-20 22:14:28.053842+00	1608
730	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-730	4	1	-730	\N	C	2019-12-20 22:14:28.053842+00	1609
729	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-729	4	1	-729	\N	C	2019-12-20 22:14:28.053842+00	1610
728	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-728	4	1	-728	\N	C	2019-12-20 22:14:28.053842+00	1611
727	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-727	4	1	-727	\N	C	2019-12-20 22:14:28.053842+00	1612
726	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-726	4	1	-726	\N	C	2019-12-20 22:14:28.053842+00	1613
725	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-725	4	1	-725	\N	C	2019-12-20 22:14:28.053842+00	1614
724	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-724	4	1	-724	\N	C	2019-12-20 22:14:28.053842+00	1615
723	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-723	4	1	-723	\N	C	2019-12-20 22:14:28.053842+00	1616
722	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-722	4	1	-722	\N	C	2019-12-20 22:14:28.053842+00	1617
721	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-721	4	1	-721	\N	C	2019-12-20 22:14:28.053842+00	1618
720	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-720	4	1	-720	\N	C	2019-12-20 22:14:28.053842+00	1619
719	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-719	4	1	-719	\N	C	2019-12-20 22:14:28.053842+00	1620
718	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-718	4	1	-718	\N	C	2019-12-20 22:14:28.053842+00	1621
717	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-717	4	1	-717	\N	C	2019-12-20 22:14:28.053842+00	1622
716	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-716	4	1	-716	\N	C	2019-12-20 22:14:28.053842+00	1623
715	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-715	4	1	-715	\N	C	2019-12-20 22:14:28.053842+00	1624
714	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-714	4	1	-714	\N	C	2019-12-20 22:14:28.053842+00	1625
713	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-713	4	1	-713	\N	C	2019-12-20 22:14:28.053842+00	1626
712	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-712	4	1	-712	\N	C	2019-12-20 22:14:28.053842+00	1627
711	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-711	4	1	-711	\N	C	2019-12-20 22:14:28.053842+00	1628
710	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-710	4	1	-710	\N	C	2019-12-20 22:14:28.053842+00	1629
709	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-709	4	1	-709	\N	C	2019-12-20 22:14:28.053842+00	1630
708	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-708	4	1	-708	\N	C	2019-12-20 22:14:28.053842+00	1631
707	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-707	4	1	-707	\N	C	2019-12-20 22:14:28.053842+00	1632
706	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-706	4	1	-706	\N	C	2019-12-20 22:14:28.053842+00	1633
705	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-705	4	1	-705	\N	C	2019-12-20 22:14:28.053842+00	1634
704	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-704	4	1	-704	\N	C	2019-12-20 22:14:28.053842+00	1635
703	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-703	4	1	-703	\N	C	2019-12-20 22:14:28.053842+00	1636
702	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-702	4	1	-702	\N	C	2019-12-20 22:14:28.053842+00	1637
701	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-701	4	1	-701	\N	C	2019-12-20 22:14:28.053842+00	1638
700	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-700	4	1	-700	\N	C	2019-12-20 22:14:28.053842+00	1639
699	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-699	4	1	-699	\N	C	2019-12-20 22:14:28.053842+00	1640
698	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-698	4	1	-698	\N	C	2019-12-20 22:14:28.053842+00	1641
697	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-697	4	1	-697	\N	C	2019-12-20 22:14:28.053842+00	1642
696	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-696	4	1	-696	\N	C	2019-12-20 22:14:28.053842+00	1643
695	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-695	4	1	-695	\N	C	2019-12-20 22:14:28.053842+00	1644
694	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-694	4	1	-694	\N	C	2019-12-20 22:14:28.053842+00	1645
693	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-693	4	1	-693	\N	C	2019-12-20 22:14:28.053842+00	1646
692	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-692	4	1	-692	\N	C	2019-12-20 22:14:28.053842+00	1647
691	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-691	4	1	-691	\N	C	2019-12-20 22:14:28.053842+00	1648
690	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-690	4	1	-690	\N	C	2019-12-20 22:14:28.053842+00	1649
689	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-689	4	1	-689	\N	C	2019-12-20 22:14:28.053842+00	1650
688	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-688	4	1	-688	\N	C	2019-12-20 22:14:28.053842+00	1651
687	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-687	4	1	-687	\N	C	2019-12-20 22:14:28.053842+00	1652
686	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-686	4	1	-686	\N	C	2019-12-20 22:14:28.053842+00	1653
685	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-685	4	1	-685	\N	C	2019-12-20 22:14:28.053842+00	1654
684	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-684	4	1	-684	\N	C	2019-12-20 22:14:28.053842+00	1655
683	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-683	4	1	-683	\N	C	2019-12-20 22:14:28.053842+00	1656
682	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-682	4	1	-682	\N	C	2019-12-20 22:14:28.053842+00	1657
681	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-681	4	1	-681	\N	C	2019-12-20 22:14:28.053842+00	1658
680	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-680	4	1	-680	\N	C	2019-12-20 22:14:28.053842+00	1659
679	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-679	4	1	-679	\N	C	2019-12-20 22:14:28.053842+00	1660
678	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-678	4	1	-678	\N	C	2019-12-20 22:14:28.053842+00	1661
677	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-677	4	1	-677	\N	C	2019-12-20 22:14:28.053842+00	1662
676	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-676	4	1	-676	\N	C	2019-12-20 22:14:28.053842+00	1663
675	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-675	4	1	-675	\N	C	2019-12-20 22:14:28.053842+00	1664
674	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-674	4	1	-674	\N	C	2019-12-20 22:14:28.053842+00	1665
673	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-673	4	1	-673	\N	C	2019-12-20 22:14:28.053842+00	1666
672	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-672	4	1	-672	\N	C	2019-12-20 22:14:28.053842+00	1667
671	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-671	4	1	-671	\N	C	2019-12-20 22:14:28.053842+00	1668
670	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-670	4	1	-670	\N	C	2019-12-20 22:14:28.053842+00	1669
669	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-669	4	1	-669	\N	C	2019-12-20 22:14:28.053842+00	1670
668	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-668	4	1	-668	\N	C	2019-12-20 22:14:28.053842+00	1671
667	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-667	4	1	-667	\N	C	2019-12-20 22:14:28.053842+00	1672
666	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-666	4	1	-666	\N	C	2019-12-20 22:14:28.053842+00	1673
665	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-665	4	1	-665	\N	C	2019-12-20 22:14:28.053842+00	1674
664	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-664	4	1	-664	\N	C	2019-12-20 22:14:28.053842+00	1675
663	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-663	4	1	-663	\N	C	2019-12-20 22:14:28.053842+00	1676
662	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-662	4	1	-662	\N	C	2019-12-20 22:14:28.053842+00	1677
661	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-661	4	1	-661	\N	C	2019-12-20 22:14:28.053842+00	1678
660	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-660	4	1	-660	\N	C	2019-12-20 22:14:28.053842+00	1679
659	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-659	4	1	-659	\N	C	2019-12-20 22:14:28.053842+00	1680
658	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-658	4	1	-658	\N	C	2019-12-20 22:14:28.053842+00	1681
657	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-657	4	1	-657	\N	C	2019-12-20 22:14:28.053842+00	1682
656	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-656	4	1	-656	\N	C	2019-12-20 22:14:28.053842+00	1683
655	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-655	4	1	-655	\N	C	2019-12-20 22:14:28.053842+00	1684
654	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-654	4	1	-654	\N	C	2019-12-20 22:14:28.053842+00	1685
653	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-653	4	1	-653	\N	C	2019-12-20 22:14:28.053842+00	1686
652	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-652	4	1	-652	\N	C	2019-12-20 22:14:28.053842+00	1687
651	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-651	4	1	-651	\N	C	2019-12-20 22:14:28.053842+00	1688
650	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-650	4	1	-650	\N	C	2019-12-20 22:14:28.053842+00	1689
649	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-649	4	1	-649	\N	C	2019-12-20 22:14:28.053842+00	1690
648	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-648	4	1	-648	\N	C	2019-12-20 22:14:28.053842+00	1691
647	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-647	4	1	-647	\N	C	2019-12-20 22:14:28.053842+00	1692
646	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-646	4	1	-646	\N	C	2019-12-20 22:14:28.053842+00	1693
645	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-645	4	1	-645	\N	C	2019-12-20 22:14:28.053842+00	1694
644	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-644	4	1	-644	\N	C	2019-12-20 22:14:28.053842+00	1695
643	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-643	4	1	-643	\N	C	2019-12-20 22:14:28.053842+00	1696
642	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-642	4	1	-642	\N	C	2019-12-20 22:14:28.053842+00	1697
641	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-641	4	1	-641	\N	C	2019-12-20 22:14:28.053842+00	1698
640	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-640	4	1	-640	\N	C	2019-12-20 22:14:28.053842+00	1699
639	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-639	4	1	-639	\N	C	2019-12-20 22:14:28.053842+00	1700
638	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-638	4	1	-638	\N	C	2019-12-20 22:14:28.053842+00	1701
637	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-637	4	1	-637	\N	C	2019-12-20 22:14:28.053842+00	1702
636	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-636	4	1	-636	\N	C	2019-12-20 22:14:28.053842+00	1703
635	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-635	4	1	-635	\N	C	2019-12-20 22:14:28.053842+00	1704
634	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-634	4	1	-634	\N	C	2019-12-20 22:14:28.053842+00	1705
633	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-633	4	1	-633	\N	C	2019-12-20 22:14:28.053842+00	1706
632	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-632	4	1	-632	\N	C	2019-12-20 22:14:28.053842+00	1707
631	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-631	4	1	-631	\N	C	2019-12-20 22:14:28.053842+00	1708
630	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-630	4	1	-630	\N	C	2019-12-20 22:14:28.053842+00	1709
629	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-629	4	1	-629	\N	C	2019-12-20 22:14:28.053842+00	1710
628	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-628	4	1	-628	\N	C	2019-12-20 22:14:28.053842+00	1711
627	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-627	4	1	-627	\N	C	2019-12-20 22:14:28.053842+00	1712
626	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-626	4	1	-626	\N	C	2019-12-20 22:14:28.053842+00	1713
625	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-625	4	1	-625	\N	C	2019-12-20 22:14:28.053842+00	1714
624	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-624	4	1	-624	\N	C	2019-12-20 22:14:28.053842+00	1715
623	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-623	4	1	-623	\N	C	2019-12-20 22:14:28.053842+00	1716
622	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-622	4	1	-622	\N	C	2019-12-20 22:14:28.053842+00	1717
621	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-621	4	1	-621	\N	C	2019-12-20 22:14:28.053842+00	1718
620	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-620	4	1	-620	\N	C	2019-12-20 22:14:28.053842+00	1719
619	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-619	4	1	-619	\N	C	2019-12-20 22:14:28.053842+00	1720
618	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-618	4	1	-618	\N	C	2019-12-20 22:14:28.053842+00	1721
617	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-617	4	1	-617	\N	C	2019-12-20 22:14:28.053842+00	1722
616	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-616	4	1	-616	\N	C	2019-12-20 22:14:28.053842+00	1723
615	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-615	4	1	-615	\N	C	2019-12-20 22:14:28.053842+00	1724
614	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-614	4	1	-614	\N	C	2019-12-20 22:14:28.053842+00	1725
613	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-613	4	1	-613	\N	C	2019-12-20 22:14:28.053842+00	1726
612	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-612	4	1	-612	\N	C	2019-12-20 22:14:28.053842+00	1727
611	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-611	4	1	-611	\N	C	2019-12-20 22:14:28.053842+00	1728
610	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-610	4	1	-610	\N	C	2019-12-20 22:14:28.053842+00	1729
609	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-609	4	1	-609	\N	C	2019-12-20 22:14:28.053842+00	1730
608	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-608	4	1	-608	\N	C	2019-12-20 22:14:28.053842+00	1731
607	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-607	4	1	-607	\N	C	2019-12-20 22:14:28.053842+00	1732
606	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-606	4	1	-606	\N	C	2019-12-20 22:14:28.053842+00	1733
605	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-605	4	1	-605	\N	C	2019-12-20 22:14:28.053842+00	1734
604	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-604	4	1	-604	\N	C	2019-12-20 22:14:28.053842+00	1735
603	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-603	4	1	-603	\N	C	2019-12-20 22:14:28.053842+00	1736
602	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-602	4	1	-602	\N	C	2019-12-20 22:14:28.053842+00	1737
601	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-601	4	1	-601	\N	C	2019-12-20 22:14:28.053842+00	1738
600	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-600	4	1	-600	\N	C	2019-12-20 22:14:28.053842+00	1739
599	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-599	4	1	-599	\N	C	2019-12-20 22:14:28.053842+00	1740
598	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-598	4	1	-598	\N	C	2019-12-20 22:14:28.053842+00	1741
597	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-597	4	1	-597	\N	C	2019-12-20 22:14:28.053842+00	1742
596	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-596	4	1	-596	\N	C	2019-12-20 22:14:28.053842+00	1743
595	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-595	4	1	-595	\N	C	2019-12-20 22:14:28.053842+00	1744
594	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-594	4	1	-594	\N	C	2019-12-20 22:14:28.053842+00	1745
593	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-593	4	1	-593	\N	C	2019-12-20 22:14:28.053842+00	1746
592	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-592	4	1	-592	\N	C	2019-12-20 22:14:28.053842+00	1747
591	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-591	4	1	-591	\N	C	2019-12-20 22:14:28.053842+00	1748
590	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-590	4	1	-590	\N	C	2019-12-20 22:14:28.053842+00	1749
589	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-589	4	1	-589	\N	C	2019-12-20 22:14:28.053842+00	1750
588	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-588	4	1	-588	\N	C	2019-12-20 22:14:28.053842+00	1751
587	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-587	4	1	-587	\N	C	2019-12-20 22:14:28.053842+00	1752
586	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-586	4	1	-586	\N	C	2019-12-20 22:14:28.053842+00	1753
585	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-585	4	1	-585	\N	C	2019-12-20 22:14:28.053842+00	1754
584	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-584	4	1	-584	\N	C	2019-12-20 22:14:28.053842+00	1755
583	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-583	4	1	-583	\N	C	2019-12-20 22:14:28.053842+00	1756
582	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-582	4	1	-582	\N	C	2019-12-20 22:14:28.053842+00	1757
581	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-581	4	1	-581	\N	C	2019-12-20 22:14:28.053842+00	1758
580	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-580	4	1	-580	\N	C	2019-12-20 22:14:28.053842+00	1759
579	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-579	4	1	-579	\N	C	2019-12-20 22:14:28.053842+00	1760
578	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-578	4	1	-578	\N	C	2019-12-20 22:14:28.053842+00	1761
577	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-577	4	1	-577	\N	C	2019-12-20 22:14:28.053842+00	1762
576	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-576	4	1	-576	\N	C	2019-12-20 22:14:28.053842+00	1763
575	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-575	4	1	-575	\N	C	2019-12-20 22:14:28.053842+00	1764
574	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-574	4	1	-574	\N	C	2019-12-20 22:14:28.053842+00	1765
573	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-573	4	1	-573	\N	C	2019-12-20 22:14:28.053842+00	1766
572	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-572	4	1	-572	\N	C	2019-12-20 22:14:28.053842+00	1767
571	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-571	4	1	-571	\N	C	2019-12-20 22:14:28.053842+00	1768
570	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-570	4	1	-570	\N	C	2019-12-20 22:14:28.053842+00	1769
569	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-569	4	1	-569	\N	C	2019-12-20 22:14:28.053842+00	1770
568	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-568	4	1	-568	\N	C	2019-12-20 22:14:28.053842+00	1771
567	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-567	4	1	-567	\N	C	2019-12-20 22:14:28.053842+00	1772
566	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-566	4	1	-566	\N	C	2019-12-20 22:14:28.053842+00	1773
565	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-565	4	1	-565	\N	C	2019-12-20 22:14:28.053842+00	1774
564	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-564	4	1	-564	\N	C	2019-12-20 22:14:28.053842+00	1775
563	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-563	4	1	-563	\N	C	2019-12-20 22:14:28.053842+00	1776
562	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-562	4	1	-562	\N	C	2019-12-20 22:14:28.053842+00	1777
561	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-561	4	1	-561	\N	C	2019-12-20 22:14:28.053842+00	1778
560	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-560	4	1	-560	\N	C	2019-12-20 22:14:28.053842+00	1779
559	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-559	4	1	-559	\N	C	2019-12-20 22:14:28.053842+00	1780
558	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-558	4	1	-558	\N	C	2019-12-20 22:14:28.053842+00	1781
557	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-557	4	1	-557	\N	C	2019-12-20 22:14:28.053842+00	1782
556	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-556	4	1	-556	\N	C	2019-12-20 22:14:28.053842+00	1783
555	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-555	4	1	-555	\N	C	2019-12-20 22:14:28.053842+00	1784
554	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-554	4	1	-554	\N	C	2019-12-20 22:14:28.053842+00	1785
553	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-553	4	1	-553	\N	C	2019-12-20 22:14:28.053842+00	1786
552	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-552	4	1	-552	\N	C	2019-12-20 22:14:28.053842+00	1787
551	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-551	4	1	-551	\N	C	2019-12-20 22:14:28.053842+00	1788
550	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-550	4	1	-550	\N	C	2019-12-20 22:14:28.053842+00	1789
549	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-549	4	1	-549	\N	C	2019-12-20 22:14:28.053842+00	1790
548	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-548	4	1	-548	\N	C	2019-12-20 22:14:28.053842+00	1791
547	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-547	4	1	-547	\N	C	2019-12-20 22:14:28.053842+00	1792
546	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-546	4	1	-546	\N	C	2019-12-20 22:14:28.053842+00	1793
545	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-545	4	1	-545	\N	C	2019-12-20 22:14:28.053842+00	1794
544	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-544	4	1	-544	\N	C	2019-12-20 22:14:28.053842+00	1795
543	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-543	4	1	-543	\N	C	2019-12-20 22:14:28.053842+00	1796
542	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-542	4	1	-542	\N	C	2019-12-20 22:14:28.053842+00	1797
541	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-541	4	1	-541	\N	C	2019-12-20 22:14:28.053842+00	1798
540	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-540	4	1	-540	\N	C	2019-12-20 22:14:28.053842+00	1799
539	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-539	4	1	-539	\N	C	2019-12-20 22:14:28.053842+00	1800
538	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-538	4	1	-538	\N	C	2019-12-20 22:14:28.053842+00	1801
537	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-537	4	1	-537	\N	C	2019-12-20 22:14:28.053842+00	1802
536	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-536	4	1	-536	\N	C	2019-12-20 22:14:28.053842+00	1803
535	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-535	4	1	-535	\N	C	2019-12-20 22:14:28.053842+00	1804
534	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-534	4	1	-534	\N	C	2019-12-20 22:14:28.053842+00	1805
533	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-533	4	1	-533	\N	C	2019-12-20 22:14:28.053842+00	1806
532	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-532	4	1	-532	\N	C	2019-12-20 22:14:28.053842+00	1807
531	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-531	4	1	-531	\N	C	2019-12-20 22:14:28.053842+00	1808
530	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-530	4	1	-530	\N	C	2019-12-20 22:14:28.053842+00	1809
529	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-529	4	1	-529	\N	C	2019-12-20 22:14:28.053842+00	1810
528	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-528	4	1	-528	\N	C	2019-12-20 22:14:28.053842+00	1811
527	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-527	4	1	-527	\N	C	2019-12-20 22:14:28.053842+00	1812
526	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-526	4	1	-526	\N	C	2019-12-20 22:14:28.053842+00	1813
525	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-525	4	1	-525	\N	C	2019-12-20 22:14:28.053842+00	1814
524	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-524	4	1	-524	\N	C	2019-12-20 22:14:28.053842+00	1815
523	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-523	4	1	-523	\N	C	2019-12-20 22:14:28.053842+00	1816
522	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-522	4	1	-522	\N	C	2019-12-20 22:14:28.053842+00	1817
521	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-521	4	1	-521	\N	C	2019-12-20 22:14:28.053842+00	1818
520	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-520	4	1	-520	\N	C	2019-12-20 22:14:28.053842+00	1819
519	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-519	4	1	-519	\N	C	2019-12-20 22:14:28.053842+00	1820
518	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-518	4	1	-518	\N	C	2019-12-20 22:14:28.053842+00	1821
517	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-517	4	1	-517	\N	C	2019-12-20 22:14:28.053842+00	1822
516	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-516	4	1	-516	\N	C	2019-12-20 22:14:28.053842+00	1823
515	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-515	4	1	-515	\N	C	2019-12-20 22:14:28.053842+00	1824
514	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-514	4	1	-514	\N	C	2019-12-20 22:14:28.053842+00	1825
513	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-513	4	1	-513	\N	C	2019-12-20 22:14:28.053842+00	1826
512	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-512	4	1	-512	\N	C	2019-12-20 22:14:28.053842+00	1827
511	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-511	4	1	-511	\N	C	2019-12-20 22:14:28.053842+00	1828
510	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-510	4	1	-510	\N	C	2019-12-20 22:14:28.053842+00	1829
509	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-509	4	1	-509	\N	C	2019-12-20 22:14:28.053842+00	1830
508	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-508	4	1	-508	\N	C	2019-12-20 22:14:28.053842+00	1831
507	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-507	4	1	-507	\N	C	2019-12-20 22:14:28.053842+00	1832
506	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-506	4	1	-506	\N	C	2019-12-20 22:14:28.053842+00	1833
505	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-505	4	1	-505	\N	C	2019-12-20 22:14:28.053842+00	1834
504	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-504	4	1	-504	\N	C	2019-12-20 22:14:28.053842+00	1835
503	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-503	4	1	-503	\N	C	2019-12-20 22:14:28.053842+00	1836
502	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-502	4	1	-502	\N	C	2019-12-20 22:14:28.053842+00	1837
501	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-501	4	1	-501	\N	C	2019-12-20 22:14:28.053842+00	1838
500	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-500	4	1	-500	\N	C	2019-12-20 22:14:28.053842+00	1839
499	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-499	4	1	-499	\N	C	2019-12-20 22:14:28.053842+00	1840
498	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-498	4	1	-498	\N	C	2019-12-20 22:14:28.053842+00	1841
497	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-497	4	1	-497	\N	C	2019-12-20 22:14:28.053842+00	1842
496	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-496	4	1	-496	\N	C	2019-12-20 22:14:28.053842+00	1843
495	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-495	4	1	-495	\N	C	2019-12-20 22:14:28.053842+00	1844
494	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-494	4	1	-494	\N	C	2019-12-20 22:14:28.053842+00	1845
493	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-493	4	1	-493	\N	C	2019-12-20 22:14:28.053842+00	1846
492	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-492	4	1	-492	\N	C	2019-12-20 22:14:28.053842+00	1847
491	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-491	4	1	-491	\N	C	2019-12-20 22:14:28.053842+00	1848
490	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-490	4	1	-490	\N	C	2019-12-20 22:14:28.053842+00	1849
489	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-489	4	1	-489	\N	C	2019-12-20 22:14:28.053842+00	1850
488	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-488	4	1	-488	\N	C	2019-12-20 22:14:28.053842+00	1851
487	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-487	4	1	-487	\N	C	2019-12-20 22:14:28.053842+00	1852
486	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-486	4	1	-486	\N	C	2019-12-20 22:14:28.053842+00	1853
485	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-485	4	1	-485	\N	C	2019-12-20 22:14:28.053842+00	1854
484	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-484	4	1	-484	\N	C	2019-12-20 22:14:28.053842+00	1855
483	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-483	4	1	-483	\N	C	2019-12-20 22:14:28.053842+00	1856
482	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-482	4	1	-482	\N	C	2019-12-20 22:14:28.053842+00	1857
481	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-481	4	1	-481	\N	C	2019-12-20 22:14:28.053842+00	1858
480	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-480	4	1	-480	\N	C	2019-12-20 22:14:28.053842+00	1859
479	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-479	4	1	-479	\N	C	2019-12-20 22:14:28.053842+00	1860
478	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-478	4	1	-478	\N	C	2019-12-20 22:14:28.053842+00	1861
477	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-477	4	1	-477	\N	C	2019-12-20 22:14:28.053842+00	1862
476	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-476	4	1	-476	\N	C	2019-12-20 22:14:28.053842+00	1863
475	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-475	4	1	-475	\N	C	2019-12-20 22:14:28.053842+00	1864
474	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-474	4	1	-474	\N	C	2019-12-20 22:14:28.053842+00	1865
473	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-473	4	1	-473	\N	C	2019-12-20 22:14:28.053842+00	1866
472	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-472	4	1	-472	\N	C	2019-12-20 22:14:28.053842+00	1867
471	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-471	4	1	-471	\N	C	2019-12-20 22:14:28.053842+00	1868
470	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-470	4	1	-470	\N	C	2019-12-20 22:14:28.053842+00	1869
469	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-469	4	1	-469	\N	C	2019-12-20 22:14:28.053842+00	1870
468	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-468	4	1	-468	\N	C	2019-12-20 22:14:28.053842+00	1871
467	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-467	4	1	-467	\N	C	2019-12-20 22:14:28.053842+00	1872
466	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-466	4	1	-466	\N	C	2019-12-20 22:14:28.053842+00	1873
465	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-465	4	1	-465	\N	C	2019-12-20 22:14:28.053842+00	1874
464	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-464	4	1	-464	\N	C	2019-12-20 22:14:28.053842+00	1875
463	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-463	4	1	-463	\N	C	2019-12-20 22:14:28.053842+00	1876
462	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-462	4	1	-462	\N	C	2019-12-20 22:14:28.053842+00	1877
461	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-461	4	1	-461	\N	C	2019-12-20 22:14:28.053842+00	1878
460	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-460	4	1	-460	\N	C	2019-12-20 22:14:28.053842+00	1879
459	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-459	4	1	-459	\N	C	2019-12-20 22:14:28.053842+00	1880
458	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-458	4	1	-458	\N	C	2019-12-20 22:14:28.053842+00	1881
457	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-457	4	1	-457	\N	C	2019-12-20 22:14:28.053842+00	1882
456	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-456	4	1	-456	\N	C	2019-12-20 22:14:28.053842+00	1883
455	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-455	4	1	-455	\N	C	2019-12-20 22:14:28.053842+00	1884
454	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-454	4	1	-454	\N	C	2019-12-20 22:14:28.053842+00	1885
453	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-453	4	1	-453	\N	C	2019-12-20 22:14:28.053842+00	1886
452	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-452	4	1	-452	\N	C	2019-12-20 22:14:28.053842+00	1887
451	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-451	4	1	-451	\N	C	2019-12-20 22:14:28.053842+00	1888
450	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-450	4	1	-450	\N	C	2019-12-20 22:14:28.053842+00	1889
449	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-449	4	1	-449	\N	C	2019-12-20 22:14:28.053842+00	1890
448	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-448	4	1	-448	\N	C	2019-12-20 22:14:28.053842+00	1891
447	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-447	4	1	-447	\N	C	2019-12-20 22:14:28.053842+00	1892
446	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-446	4	1	-446	\N	C	2019-12-20 22:14:28.053842+00	1893
445	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-445	4	1	-445	\N	C	2019-12-20 22:14:28.053842+00	1894
444	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-444	4	1	-444	\N	C	2019-12-20 22:14:28.053842+00	1895
443	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-443	4	1	-443	\N	C	2019-12-20 22:14:28.053842+00	1896
442	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-442	4	1	-442	\N	C	2019-12-20 22:14:28.053842+00	1897
441	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-441	4	1	-441	\N	C	2019-12-20 22:14:28.053842+00	1898
440	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-440	4	1	-440	\N	C	2019-12-20 22:14:28.053842+00	1899
439	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-439	4	1	-439	\N	C	2019-12-20 22:14:28.053842+00	1900
438	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-438	4	1	-438	\N	C	2019-12-20 22:14:28.053842+00	1901
437	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-437	4	1	-437	\N	C	2019-12-20 22:14:28.053842+00	1902
436	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-436	4	1	-436	\N	C	2019-12-20 22:14:28.053842+00	1903
435	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-435	4	1	-435	\N	C	2019-12-20 22:14:28.053842+00	1904
434	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-434	4	1	-434	\N	C	2019-12-20 22:14:28.053842+00	1905
433	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-433	4	1	-433	\N	C	2019-12-20 22:14:28.053842+00	1906
432	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-432	4	1	-432	\N	C	2019-12-20 22:14:28.053842+00	1907
431	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-431	4	1	-431	\N	C	2019-12-20 22:14:28.053842+00	1908
430	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-430	4	1	-430	\N	C	2019-12-20 22:14:28.053842+00	1909
429	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-429	4	1	-429	\N	C	2019-12-20 22:14:28.053842+00	1910
428	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-428	4	1	-428	\N	C	2019-12-20 22:14:28.053842+00	1911
427	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-427	4	1	-427	\N	C	2019-12-20 22:14:28.053842+00	1912
426	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-426	4	1	-426	\N	C	2019-12-20 22:14:28.053842+00	1913
425	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-425	4	1	-425	\N	C	2019-12-20 22:14:28.053842+00	1914
424	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-424	4	1	-424	\N	C	2019-12-20 22:14:28.053842+00	1915
423	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-423	4	1	-423	\N	C	2019-12-20 22:14:28.053842+00	1916
422	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-422	4	1	-422	\N	C	2019-12-20 22:14:28.053842+00	1917
421	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-421	4	1	-421	\N	C	2019-12-20 22:14:28.053842+00	1918
420	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-420	4	1	-420	\N	C	2019-12-20 22:14:28.053842+00	1919
419	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-419	4	1	-419	\N	C	2019-12-20 22:14:28.053842+00	1920
418	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-418	4	1	-418	\N	C	2019-12-20 22:14:28.053842+00	1921
417	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-417	4	1	-417	\N	C	2019-12-20 22:14:28.053842+00	1922
416	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-416	4	1	-416	\N	C	2019-12-20 22:14:28.053842+00	1923
415	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-415	4	1	-415	\N	C	2019-12-20 22:14:28.053842+00	1924
414	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-414	4	1	-414	\N	C	2019-12-20 22:14:28.053842+00	1925
413	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-413	4	1	-413	\N	C	2019-12-20 22:14:28.053842+00	1926
412	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-412	4	1	-412	\N	C	2019-12-20 22:14:28.053842+00	1927
411	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-411	4	1	-411	\N	C	2019-12-20 22:14:28.053842+00	1928
410	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-410	4	1	-410	\N	C	2019-12-20 22:14:28.053842+00	1929
409	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-409	4	1	-409	\N	C	2019-12-20 22:14:28.053842+00	1930
408	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-408	4	1	-408	\N	C	2019-12-20 22:14:28.053842+00	1931
407	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-407	4	1	-407	\N	C	2019-12-20 22:14:28.053842+00	1932
406	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-406	4	1	-406	\N	C	2019-12-20 22:14:28.053842+00	1933
405	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-405	4	1	-405	\N	C	2019-12-20 22:14:28.053842+00	1934
404	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-404	4	1	-404	\N	C	2019-12-20 22:14:28.053842+00	1935
403	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-403	4	1	-403	\N	C	2019-12-20 22:14:28.053842+00	1936
402	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-402	4	1	-402	\N	C	2019-12-20 22:14:28.053842+00	1937
401	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-401	4	1	-401	\N	C	2019-12-20 22:14:28.053842+00	1938
400	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-400	4	1	-400	\N	C	2019-12-20 22:14:28.053842+00	1939
399	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-399	4	1	-399	\N	C	2019-12-20 22:14:28.053842+00	1940
398	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-398	4	1	-398	\N	C	2019-12-20 22:14:28.053842+00	1941
397	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-397	4	1	-397	\N	C	2019-12-20 22:14:28.053842+00	1942
396	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-396	4	1	-396	\N	C	2019-12-20 22:14:28.053842+00	1943
395	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-395	4	1	-395	\N	C	2019-12-20 22:14:28.053842+00	1944
394	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-394	4	1	-394	\N	C	2019-12-20 22:14:28.053842+00	1945
393	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-393	4	1	-393	\N	C	2019-12-20 22:14:28.053842+00	1946
392	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-392	4	1	-392	\N	C	2019-12-20 22:14:28.053842+00	1947
391	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-391	4	1	-391	\N	C	2019-12-20 22:14:28.053842+00	1948
390	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-390	4	1	-390	\N	C	2019-12-20 22:14:28.053842+00	1949
389	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-389	4	1	-389	\N	C	2019-12-20 22:14:28.053842+00	1950
388	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-388	4	1	-388	\N	C	2019-12-20 22:14:28.053842+00	1951
387	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-387	4	1	-387	\N	C	2019-12-20 22:14:28.053842+00	1952
386	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-386	4	1	-386	\N	C	2019-12-20 22:14:28.053842+00	1953
385	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-385	4	1	-385	\N	C	2019-12-20 22:14:28.053842+00	1954
384	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-384	4	1	-384	\N	C	2019-12-20 22:14:28.053842+00	1955
383	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-383	4	1	-383	\N	C	2019-12-20 22:14:28.053842+00	1956
382	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-382	4	1	-382	\N	C	2019-12-20 22:14:28.053842+00	1957
381	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-381	4	1	-381	\N	C	2019-12-20 22:14:28.053842+00	1958
380	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-380	4	1	-380	\N	C	2019-12-20 22:14:28.053842+00	1959
379	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-379	4	1	-379	\N	C	2019-12-20 22:14:28.053842+00	1960
378	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-378	4	1	-378	\N	C	2019-12-20 22:14:28.053842+00	1961
377	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-377	4	1	-377	\N	C	2019-12-20 22:14:28.053842+00	1962
376	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-376	4	1	-376	\N	C	2019-12-20 22:14:28.053842+00	1963
375	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-375	4	1	-375	\N	C	2019-12-20 22:14:28.053842+00	1964
374	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-374	4	1	-374	\N	C	2019-12-20 22:14:28.053842+00	1965
373	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-373	4	1	-373	\N	C	2019-12-20 22:14:28.053842+00	1966
372	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-372	4	1	-372	\N	C	2019-12-20 22:14:28.053842+00	1967
371	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-371	4	1	-371	\N	C	2019-12-20 22:14:28.053842+00	1968
370	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-370	4	1	-370	\N	C	2019-12-20 22:14:28.053842+00	1969
369	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-369	4	1	-369	\N	C	2019-12-20 22:14:28.053842+00	1970
368	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-368	4	1	-368	\N	C	2019-12-20 22:14:28.053842+00	1971
367	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-367	4	1	-367	\N	C	2019-12-20 22:14:28.053842+00	1972
366	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-366	4	1	-366	\N	C	2019-12-20 22:14:28.053842+00	1973
365	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-365	4	1	-365	\N	C	2019-12-20 22:14:28.053842+00	1974
364	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-364	4	1	-364	\N	C	2019-12-20 22:14:28.053842+00	1975
363	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-363	4	1	-363	\N	C	2019-12-20 22:14:28.053842+00	1976
362	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-362	4	1	-362	\N	C	2019-12-20 22:14:28.053842+00	1977
361	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-361	4	1	-361	\N	C	2019-12-20 22:14:28.053842+00	1978
360	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-360	4	1	-360	\N	C	2019-12-20 22:14:28.053842+00	1979
359	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-359	4	1	-359	\N	C	2019-12-20 22:14:28.053842+00	1980
358	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-358	4	1	-358	\N	C	2019-12-20 22:14:28.053842+00	1981
357	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-357	4	1	-357	\N	C	2019-12-20 22:14:28.053842+00	1982
356	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-356	4	1	-356	\N	C	2019-12-20 22:14:28.053842+00	1983
355	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-355	4	1	-355	\N	C	2019-12-20 22:14:28.053842+00	1984
354	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-354	4	1	-354	\N	C	2019-12-20 22:14:28.053842+00	1985
353	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-353	4	1	-353	\N	C	2019-12-20 22:14:28.053842+00	1986
352	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-352	4	1	-352	\N	C	2019-12-20 22:14:28.053842+00	1987
351	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-351	4	1	-351	\N	C	2019-12-20 22:14:28.053842+00	1988
350	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-350	4	1	-350	\N	C	2019-12-20 22:14:28.053842+00	1989
349	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-349	4	1	-349	\N	C	2019-12-20 22:14:28.053842+00	1990
348	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-348	4	1	-348	\N	C	2019-12-20 22:14:28.053842+00	1991
347	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-347	4	1	-347	\N	C	2019-12-20 22:14:28.053842+00	1992
346	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-346	4	1	-346	\N	C	2019-12-20 22:14:28.053842+00	1993
345	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-345	4	1	-345	\N	C	2019-12-20 22:14:28.053842+00	1994
344	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-344	4	1	-344	\N	C	2019-12-20 22:14:28.053842+00	1995
343	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-343	4	1	-343	\N	C	2019-12-20 22:14:28.053842+00	1996
342	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-342	4	1	-342	\N	C	2019-12-20 22:14:28.053842+00	1997
341	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-341	4	1	-341	\N	C	2019-12-20 22:14:28.053842+00	1998
340	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-340	4	1	-340	\N	C	2019-12-20 22:14:28.053842+00	1999
339	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-339	4	1	-339	\N	C	2019-12-20 22:14:28.053842+00	2000
338	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-338	4	1	-338	\N	C	2019-12-20 22:14:28.053842+00	2001
337	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-337	4	1	-337	\N	C	2019-12-20 22:14:28.053842+00	2002
336	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-336	4	1	-336	\N	C	2019-12-20 22:14:28.053842+00	2003
335	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-335	4	1	-335	\N	C	2019-12-20 22:14:28.053842+00	2004
334	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-334	4	1	-334	\N	C	2019-12-20 22:14:28.053842+00	2005
333	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-333	4	1	-333	\N	C	2019-12-20 22:14:28.053842+00	2006
332	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-332	4	1	-332	\N	C	2019-12-20 22:14:28.053842+00	2007
331	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-331	4	1	-331	\N	C	2019-12-20 22:14:28.053842+00	2008
330	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-330	4	1	-330	\N	C	2019-12-20 22:14:28.053842+00	2009
329	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-329	4	1	-329	\N	C	2019-12-20 22:14:28.053842+00	2010
328	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-328	4	1	-328	\N	C	2019-12-20 22:14:28.053842+00	2011
327	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-327	4	1	-327	\N	C	2019-12-20 22:14:28.053842+00	2012
326	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-326	4	1	-326	\N	C	2019-12-20 22:14:28.053842+00	2013
325	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-325	4	1	-325	\N	C	2019-12-20 22:14:28.053842+00	2014
324	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-324	4	1	-324	\N	C	2019-12-20 22:14:28.053842+00	2015
323	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-323	4	1	-323	\N	C	2019-12-20 22:14:28.053842+00	2016
322	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-322	4	1	-322	\N	C	2019-12-20 22:14:28.053842+00	2017
321	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-321	4	1	-321	\N	C	2019-12-20 22:14:28.053842+00	2018
320	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-320	4	1	-320	\N	C	2019-12-20 22:14:28.053842+00	2019
319	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-319	4	1	-319	\N	C	2019-12-20 22:14:28.053842+00	2020
318	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-318	4	1	-318	\N	C	2019-12-20 22:14:28.053842+00	2021
317	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-317	4	1	-317	\N	C	2019-12-20 22:14:28.053842+00	2022
316	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-316	4	1	-316	\N	C	2019-12-20 22:14:28.053842+00	2023
315	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-315	4	1	-315	\N	C	2019-12-20 22:14:28.053842+00	2024
314	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-314	4	1	-314	\N	C	2019-12-20 22:14:28.053842+00	2025
313	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-313	4	1	-313	\N	C	2019-12-20 22:14:28.053842+00	2026
312	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-312	4	1	-312	\N	C	2019-12-20 22:14:28.053842+00	2027
311	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-311	4	1	-311	\N	C	2019-12-20 22:14:28.053842+00	2028
310	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-310	4	1	-310	\N	C	2019-12-20 22:14:28.053842+00	2029
309	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-309	4	1	-309	\N	C	2019-12-20 22:14:28.053842+00	2030
308	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-308	4	1	-308	\N	C	2019-12-20 22:14:28.053842+00	2031
307	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-307	4	1	-307	\N	C	2019-12-20 22:14:28.053842+00	2032
306	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-306	4	1	-306	\N	C	2019-12-20 22:14:28.053842+00	2033
305	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-305	4	1	-305	\N	C	2019-12-20 22:14:28.053842+00	2034
304	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-304	4	1	-304	\N	C	2019-12-20 22:14:28.053842+00	2035
303	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-303	4	1	-303	\N	C	2019-12-20 22:14:28.053842+00	2036
302	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-302	4	1	-302	\N	C	2019-12-20 22:14:28.053842+00	2037
301	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-301	4	1	-301	\N	C	2019-12-20 22:14:28.053842+00	2038
300	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-300	4	1	-300	\N	C	2019-12-20 22:14:28.053842+00	2039
299	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-299	4	1	-299	\N	C	2019-12-20 22:14:28.053842+00	2040
298	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-298	4	1	-298	\N	C	2019-12-20 22:14:28.053842+00	2041
297	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-297	4	1	-297	\N	C	2019-12-20 22:14:28.053842+00	2042
296	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-296	4	1	-296	\N	C	2019-12-20 22:14:28.053842+00	2043
295	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-295	4	1	-295	\N	C	2019-12-20 22:14:28.053842+00	2044
294	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-294	4	1	-294	\N	C	2019-12-20 22:14:28.053842+00	2045
293	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-293	4	1	-293	\N	C	2019-12-20 22:14:28.053842+00	2046
292	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-292	4	1	-292	\N	C	2019-12-20 22:14:28.053842+00	2047
291	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-291	4	1	-291	\N	C	2019-12-20 22:14:28.053842+00	2048
290	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-290	4	1	-290	\N	C	2019-12-20 22:14:28.053842+00	2049
289	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-289	4	1	-289	\N	C	2019-12-20 22:14:28.053842+00	2050
288	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-288	4	1	-288	\N	C	2019-12-20 22:14:28.053842+00	2051
287	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-287	4	1	-287	\N	C	2019-12-20 22:14:28.053842+00	2052
286	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-286	4	1	-286	\N	C	2019-12-20 22:14:28.053842+00	2053
285	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-285	4	1	-285	\N	C	2019-12-20 22:14:28.053842+00	2054
284	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-284	4	1	-284	\N	C	2019-12-20 22:14:28.053842+00	2055
283	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-283	4	1	-283	\N	C	2019-12-20 22:14:28.053842+00	2056
282	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-282	4	1	-282	\N	C	2019-12-20 22:14:28.053842+00	2057
281	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-281	4	1	-281	\N	C	2019-12-20 22:14:28.053842+00	2058
280	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-280	4	1	-280	\N	C	2019-12-20 22:14:28.053842+00	2059
279	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-279	4	1	-279	\N	C	2019-12-20 22:14:28.053842+00	2060
278	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-278	4	1	-278	\N	C	2019-12-20 22:14:28.053842+00	2061
277	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-277	4	1	-277	\N	C	2019-12-20 22:14:28.053842+00	2062
276	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-276	4	1	-276	\N	C	2019-12-20 22:14:28.053842+00	2063
275	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-275	4	1	-275	\N	C	2019-12-20 22:14:28.053842+00	2064
274	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-274	4	1	-274	\N	C	2019-12-20 22:14:28.053842+00	2065
273	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-273	4	1	-273	\N	C	2019-12-20 22:14:28.053842+00	2066
272	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-272	4	1	-272	\N	C	2019-12-20 22:14:28.053842+00	2067
271	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-271	4	1	-271	\N	C	2019-12-20 22:14:28.053842+00	2068
270	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-270	4	1	-270	\N	C	2019-12-20 22:14:28.053842+00	2069
269	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-269	4	1	-269	\N	C	2019-12-20 22:14:28.053842+00	2070
268	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-268	4	1	-268	\N	C	2019-12-20 22:14:28.053842+00	2071
267	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-267	4	1	-267	\N	C	2019-12-20 22:14:28.053842+00	2072
266	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-266	4	1	-266	\N	C	2019-12-20 22:14:28.053842+00	2073
265	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-265	4	1	-265	\N	C	2019-12-20 22:14:28.053842+00	2074
264	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-264	4	1	-264	\N	C	2019-12-20 22:14:28.053842+00	2075
263	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-263	4	1	-263	\N	C	2019-12-20 22:14:28.053842+00	2076
262	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-262	4	1	-262	\N	C	2019-12-20 22:14:28.053842+00	2077
261	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-261	4	1	-261	\N	C	2019-12-20 22:14:28.053842+00	2078
260	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-260	4	1	-260	\N	C	2019-12-20 22:14:28.053842+00	2079
259	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-259	4	1	-259	\N	C	2019-12-20 22:14:28.053842+00	2080
258	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-258	4	1	-258	\N	C	2019-12-20 22:14:28.053842+00	2081
257	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-257	4	1	-257	\N	C	2019-12-20 22:14:28.053842+00	2082
256	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-256	4	1	-256	\N	C	2019-12-20 22:14:28.053842+00	2083
255	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-255	4	1	-255	\N	C	2019-12-20 22:14:28.053842+00	2084
254	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-254	4	1	-254	\N	C	2019-12-20 22:14:28.053842+00	2085
253	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-253	4	1	-253	\N	C	2019-12-20 22:14:28.053842+00	2086
252	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-252	4	1	-252	\N	C	2019-12-20 22:14:28.053842+00	2087
251	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-251	4	1	-251	\N	C	2019-12-20 22:14:28.053842+00	2088
250	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-250	4	1	-250	\N	C	2019-12-20 22:14:28.053842+00	2089
249	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-249	4	1	-249	\N	C	2019-12-20 22:14:28.053842+00	2090
248	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-248	4	1	-248	\N	C	2019-12-20 22:14:28.053842+00	2091
247	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-247	4	1	-247	\N	C	2019-12-20 22:14:28.053842+00	2092
246	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-246	4	1	-246	\N	C	2019-12-20 22:14:28.053842+00	2093
245	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-245	4	1	-245	\N	C	2019-12-20 22:14:28.053842+00	2094
244	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-244	4	1	-244	\N	C	2019-12-20 22:14:28.053842+00	2095
243	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-243	4	1	-243	\N	C	2019-12-20 22:14:28.053842+00	2096
242	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-242	4	1	-242	\N	C	2019-12-20 22:14:28.053842+00	2097
241	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-241	4	1	-241	\N	C	2019-12-20 22:14:28.053842+00	2098
240	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-240	4	1	-240	\N	C	2019-12-20 22:14:28.053842+00	2099
239	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-239	4	1	-239	\N	C	2019-12-20 22:14:28.053842+00	2100
238	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-238	4	1	-238	\N	C	2019-12-20 22:14:28.053842+00	2101
237	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-237	4	1	-237	\N	C	2019-12-20 22:14:28.053842+00	2102
236	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-236	4	1	-236	\N	C	2019-12-20 22:14:28.053842+00	2103
235	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-235	4	1	-235	\N	C	2019-12-20 22:14:28.053842+00	2104
234	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-234	4	1	-234	\N	C	2019-12-20 22:14:28.053842+00	2105
233	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-233	4	1	-233	\N	C	2019-12-20 22:14:28.053842+00	2106
232	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-232	4	1	-232	\N	C	2019-12-20 22:14:28.053842+00	2107
231	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-231	4	1	-231	\N	C	2019-12-20 22:14:28.053842+00	2108
230	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-230	4	1	-230	\N	C	2019-12-20 22:14:28.053842+00	2109
229	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-229	4	1	-229	\N	C	2019-12-20 22:14:28.053842+00	2110
228	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-228	4	1	-228	\N	C	2019-12-20 22:14:28.053842+00	2111
227	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-227	4	1	-227	\N	C	2019-12-20 22:14:28.053842+00	2112
226	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-226	4	1	-226	\N	C	2019-12-20 22:14:28.053842+00	2113
225	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-225	4	1	-225	\N	C	2019-12-20 22:14:28.053842+00	2114
224	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-224	4	1	-224	\N	C	2019-12-20 22:14:28.053842+00	2115
223	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-223	4	1	-223	\N	C	2019-12-20 22:14:28.053842+00	2116
222	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-222	4	1	-222	\N	C	2019-12-20 22:14:28.053842+00	2117
221	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-221	4	1	-221	\N	C	2019-12-20 22:14:28.053842+00	2118
220	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-220	4	1	-220	\N	C	2019-12-20 22:14:28.053842+00	2119
219	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-219	4	1	-219	\N	C	2019-12-20 22:14:28.053842+00	2120
218	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-218	4	1	-218	\N	C	2019-12-20 22:14:28.053842+00	2121
217	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-217	4	1	-217	\N	C	2019-12-20 22:14:28.053842+00	2122
216	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-216	4	1	-216	\N	C	2019-12-20 22:14:28.053842+00	2123
215	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-215	4	1	-215	\N	C	2019-12-20 22:14:28.053842+00	2124
214	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-214	4	1	-214	\N	C	2019-12-20 22:14:28.053842+00	2125
213	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-213	4	1	-213	\N	C	2019-12-20 22:14:28.053842+00	2126
212	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-212	4	1	-212	\N	C	2019-12-20 22:14:28.053842+00	2127
211	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-211	4	1	-211	\N	C	2019-12-20 22:14:28.053842+00	2128
210	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-210	4	1	-210	\N	C	2019-12-20 22:14:28.053842+00	2129
209	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-209	4	1	-209	\N	C	2019-12-20 22:14:28.053842+00	2130
208	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-208	4	1	-208	\N	C	2019-12-20 22:14:28.053842+00	2131
207	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-207	4	1	-207	\N	C	2019-12-20 22:14:28.053842+00	2132
206	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-206	4	1	-206	\N	C	2019-12-20 22:14:28.053842+00	2133
205	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-205	4	1	-205	\N	C	2019-12-20 22:14:28.053842+00	2134
204	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-204	4	1	-204	\N	C	2019-12-20 22:14:28.053842+00	2135
203	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-203	4	1	-203	\N	C	2019-12-20 22:14:28.053842+00	2136
202	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-202	4	1	-202	\N	C	2019-12-20 22:14:28.053842+00	2137
201	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-201	4	1	-201	\N	C	2019-12-20 22:14:28.053842+00	2138
200	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-200	4	1	-200	\N	C	2019-12-20 22:14:28.053842+00	2139
199	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-199	4	1	-199	\N	C	2019-12-20 22:14:28.053842+00	2140
198	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-198	4	1	-198	\N	C	2019-12-20 22:14:28.053842+00	2141
197	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-197	4	1	-197	\N	C	2019-12-20 22:14:28.053842+00	2142
196	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-196	4	1	-196	\N	C	2019-12-20 22:14:28.053842+00	2143
195	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-195	4	1	-195	\N	C	2019-12-20 22:14:28.053842+00	2144
194	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-194	4	1	-194	\N	C	2019-12-20 22:14:28.053842+00	2145
193	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-193	4	1	-193	\N	C	2019-12-20 22:14:28.053842+00	2146
192	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-192	4	1	-192	\N	C	2019-12-20 22:14:28.053842+00	2147
191	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-191	4	1	-191	\N	C	2019-12-20 22:14:28.053842+00	2148
190	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-190	4	1	-190	\N	C	2019-12-20 22:14:28.053842+00	2149
189	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-189	4	1	-189	\N	C	2019-12-20 22:14:28.053842+00	2150
188	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-188	4	1	-188	\N	C	2019-12-20 22:14:28.053842+00	2151
187	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-187	4	1	-187	\N	C	2019-12-20 22:14:28.053842+00	2152
186	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-186	4	1	-186	\N	C	2019-12-20 22:14:28.053842+00	2153
185	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-185	4	1	-185	\N	C	2019-12-20 22:14:28.053842+00	2154
184	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-184	4	1	-184	\N	C	2019-12-20 22:14:28.053842+00	2155
183	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-183	4	1	-183	\N	C	2019-12-20 22:14:28.053842+00	2156
182	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-182	4	1	-182	\N	C	2019-12-20 22:14:28.053842+00	2157
181	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-181	4	1	-181	\N	C	2019-12-20 22:14:28.053842+00	2158
180	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-180	4	1	-180	\N	C	2019-12-20 22:14:28.053842+00	2159
179	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-179	4	1	-179	\N	C	2019-12-20 22:14:28.053842+00	2160
178	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-178	4	1	-178	\N	C	2019-12-20 22:14:28.053842+00	2161
177	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-177	4	1	-177	\N	C	2019-12-20 22:14:28.053842+00	2162
176	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-176	4	1	-176	\N	C	2019-12-20 22:14:28.053842+00	2163
175	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-175	4	1	-175	\N	C	2019-12-20 22:14:28.053842+00	2164
174	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-174	4	1	-174	\N	C	2019-12-20 22:14:28.053842+00	2165
173	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-173	4	1	-173	\N	C	2019-12-20 22:14:28.053842+00	2166
172	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-172	4	1	-172	\N	C	2019-12-20 22:14:28.053842+00	2167
171	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-171	4	1	-171	\N	C	2019-12-20 22:14:28.053842+00	2168
170	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-170	4	1	-170	\N	C	2019-12-20 22:14:28.053842+00	2169
169	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-169	4	1	-169	\N	C	2019-12-20 22:14:28.053842+00	2170
168	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-168	4	1	-168	\N	C	2019-12-20 22:14:28.053842+00	2171
167	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-167	4	1	-167	\N	C	2019-12-20 22:14:28.053842+00	2172
166	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-166	4	1	-166	\N	C	2019-12-20 22:14:28.053842+00	2173
165	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-165	4	1	-165	\N	C	2019-12-20 22:14:28.053842+00	2174
164	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-164	4	1	-164	\N	C	2019-12-20 22:14:28.053842+00	2175
163	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-163	4	1	-163	\N	C	2019-12-20 22:14:28.053842+00	2176
162	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-162	4	1	-162	\N	C	2019-12-20 22:14:28.053842+00	2177
161	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-161	4	1	-161	\N	C	2019-12-20 22:14:28.053842+00	2178
160	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-160	4	1	-160	\N	C	2019-12-20 22:14:28.053842+00	2179
159	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-159	4	1	-159	\N	C	2019-12-20 22:14:28.053842+00	2180
158	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-158	4	1	-158	\N	C	2019-12-20 22:14:28.053842+00	2181
157	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-157	4	1	-157	\N	C	2019-12-20 22:14:28.053842+00	2182
156	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-156	4	1	-156	\N	C	2019-12-20 22:14:28.053842+00	2183
155	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-155	4	1	-155	\N	C	2019-12-20 22:14:28.053842+00	2184
154	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-154	4	1	-154	\N	C	2019-12-20 22:14:28.053842+00	2185
153	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-153	4	1	-153	\N	C	2019-12-20 22:14:28.053842+00	2186
152	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-152	4	1	-152	\N	C	2019-12-20 22:14:28.053842+00	2187
151	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-151	4	1	-151	\N	C	2019-12-20 22:14:28.053842+00	2188
150	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-150	4	1	-150	\N	C	2019-12-20 22:14:28.053842+00	2189
149	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-149	4	1	-149	\N	C	2019-12-20 22:14:28.053842+00	2190
148	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-148	4	1	-148	\N	C	2019-12-20 22:14:28.053842+00	2191
147	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-147	4	1	-147	\N	C	2019-12-20 22:14:28.053842+00	2192
146	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-146	4	1	-146	\N	C	2019-12-20 22:14:28.053842+00	2193
145	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-145	4	1	-145	\N	C	2019-12-20 22:14:28.053842+00	2194
144	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-144	4	1	-144	\N	C	2019-12-20 22:14:28.053842+00	2195
143	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-143	4	1	-143	\N	C	2019-12-20 22:14:28.053842+00	2196
142	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-142	4	1	-142	\N	C	2019-12-20 22:14:28.053842+00	2197
141	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-141	4	1	-141	\N	C	2019-12-20 22:14:28.053842+00	2198
140	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-140	4	1	-140	\N	C	2019-12-20 22:14:28.053842+00	2199
139	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-139	4	1	-139	\N	C	2019-12-20 22:14:28.053842+00	2200
138	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-138	4	1	-138	\N	C	2019-12-20 22:14:28.053842+00	2201
137	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-137	4	1	-137	\N	C	2019-12-20 22:14:28.053842+00	2202
136	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-136	4	1	-136	\N	C	2019-12-20 22:14:28.053842+00	2203
135	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-135	4	1	-135	\N	C	2019-12-20 22:14:28.053842+00	2204
134	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-134	4	1	-134	\N	C	2019-12-20 22:14:28.053842+00	2205
133	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-133	4	1	-133	\N	C	2019-12-20 22:14:28.053842+00	2206
132	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-132	4	1	-132	\N	C	2019-12-20 22:14:28.053842+00	2207
131	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-131	4	1	-131	\N	C	2019-12-20 22:14:28.053842+00	2208
130	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-130	4	1	-130	\N	C	2019-12-20 22:14:28.053842+00	2209
129	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-129	4	1	-129	\N	C	2019-12-20 22:14:28.053842+00	2210
128	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-128	4	1	-128	\N	C	2019-12-20 22:14:28.053842+00	2211
127	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-127	4	1	-127	\N	C	2019-12-20 22:14:28.053842+00	2212
126	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-126	4	1	-126	\N	C	2019-12-20 22:14:28.053842+00	2213
125	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-125	4	1	-125	\N	C	2019-12-20 22:14:28.053842+00	2214
124	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-124	4	1	-124	\N	C	2019-12-20 22:14:28.053842+00	2215
123	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-123	4	1	-123	\N	C	2019-12-20 22:14:28.053842+00	2216
122	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-122	4	1	-122	\N	C	2019-12-20 22:14:28.053842+00	2217
121	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-121	4	1	-121	\N	C	2019-12-20 22:14:28.053842+00	2218
120	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-120	4	1	-120	\N	C	2019-12-20 22:14:28.053842+00	2219
119	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-119	4	1	-119	\N	C	2019-12-20 22:14:28.053842+00	2220
118	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-118	4	1	-118	\N	C	2019-12-20 22:14:28.053842+00	2221
117	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-117	4	1	-117	\N	C	2019-12-20 22:14:28.053842+00	2222
116	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-116	4	1	-116	\N	C	2019-12-20 22:14:28.053842+00	2223
115	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-115	4	1	-115	\N	C	2019-12-20 22:14:28.053842+00	2224
114	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-114	4	1	-114	\N	C	2019-12-20 22:14:28.053842+00	2225
113	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-113	4	1	-113	\N	C	2019-12-20 22:14:28.053842+00	2226
112	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-112	4	1	-112	\N	C	2019-12-20 22:14:28.053842+00	2227
111	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-111	4	1	-111	\N	C	2019-12-20 22:14:28.053842+00	2228
110	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-110	4	1	-110	\N	C	2019-12-20 22:14:28.053842+00	2229
109	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-109	4	1	-109	\N	C	2019-12-20 22:14:28.053842+00	2230
108	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-108	4	1	-108	\N	C	2019-12-20 22:14:28.053842+00	2231
107	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-107	4	1	-107	\N	C	2019-12-20 22:14:28.053842+00	2232
106	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-106	4	1	-106	\N	C	2019-12-20 22:14:28.053842+00	2233
105	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-105	4	1	-105	\N	C	2019-12-20 22:14:28.053842+00	2234
104	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-104	4	1	-104	\N	C	2019-12-20 22:14:28.053842+00	2235
103	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-103	4	1	-103	\N	C	2019-12-20 22:14:28.053842+00	2236
102	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-102	4	1	-102	\N	C	2019-12-20 22:14:28.053842+00	2237
101	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-101	4	1	-101	\N	C	2019-12-20 22:14:28.053842+00	2238
100	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-100	4	1	-100	\N	C	2019-12-20 22:14:28.053842+00	2239
99	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-99	4	1	-99	\N	C	2019-12-20 22:14:28.053842+00	2240
98	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-98	4	1	-98	\N	C	2019-12-20 22:14:28.053842+00	2241
97	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-97	4	1	-97	\N	C	2019-12-20 22:14:28.053842+00	2242
96	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-96	4	1	-96	\N	C	2019-12-20 22:14:28.053842+00	2243
95	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-95	4	1	-95	\N	C	2019-12-20 22:14:28.053842+00	2244
94	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-94	4	1	-94	\N	C	2019-12-20 22:14:28.053842+00	2245
93	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-93	4	1	-93	\N	C	2019-12-20 22:14:28.053842+00	2246
92	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-92	4	1	-92	\N	C	2019-12-20 22:14:28.053842+00	2247
91	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-91	4	1	-91	\N	C	2019-12-20 22:14:28.053842+00	2248
90	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-90	4	1	-90	\N	C	2019-12-20 22:14:28.053842+00	2249
89	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-89	4	1	-89	\N	C	2019-12-20 22:14:28.053842+00	2250
88	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-88	4	1	-88	\N	C	2019-12-20 22:14:28.053842+00	2251
87	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-87	4	1	-87	\N	C	2019-12-20 22:14:28.053842+00	2252
86	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-86	4	1	-86	\N	C	2019-12-20 22:14:28.053842+00	2253
85	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-85	4	1	-85	\N	C	2019-12-20 22:14:28.053842+00	2254
84	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-84	4	1	-84	\N	C	2019-12-20 22:14:28.053842+00	2255
83	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-83	4	1	-83	\N	C	2019-12-20 22:14:28.053842+00	2256
82	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-82	4	1	-82	\N	C	2019-12-20 22:14:28.053842+00	2257
81	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-81	4	1	-81	\N	C	2019-12-20 22:14:28.053842+00	2258
80	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-80	4	1	-80	\N	C	2019-12-20 22:14:28.053842+00	2259
79	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-79	4	1	-79	\N	C	2019-12-20 22:14:28.053842+00	2260
78	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-78	4	1	-78	\N	C	2019-12-20 22:14:28.053842+00	2261
77	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-77	4	1	-77	\N	C	2019-12-20 22:14:28.053842+00	2262
76	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-76	4	1	-76	\N	C	2019-12-20 22:14:28.053842+00	2263
75	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-75	4	1	-75	\N	C	2019-12-20 22:14:28.053842+00	2264
74	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-74	4	1	-74	\N	C	2019-12-20 22:14:28.053842+00	2265
73	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-73	4	1	-73	\N	C	2019-12-20 22:14:28.053842+00	2266
72	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-72	4	1	-72	\N	C	2019-12-20 22:14:28.053842+00	2267
71	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-71	4	1	-71	\N	C	2019-12-20 22:14:28.053842+00	2268
70	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-70	4	1	-70	\N	C	2019-12-20 22:14:28.053842+00	2269
69	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-69	4	1	-69	\N	C	2019-12-20 22:14:28.053842+00	2270
68	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-68	4	1	-68	\N	C	2019-12-20 22:14:28.053842+00	2271
67	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-67	4	1	-67	\N	C	2019-12-20 22:14:28.053842+00	2272
66	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-66	4	1	-66	\N	C	2019-12-20 22:14:28.053842+00	2273
65	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-65	4	1	-65	\N	C	2019-12-20 22:14:28.053842+00	2274
64	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-64	4	1	-64	\N	C	2019-12-20 22:14:28.053842+00	2275
63	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-63	4	1	-63	\N	C	2019-12-20 22:14:28.053842+00	2276
62	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-62	4	1	-62	\N	C	2019-12-20 22:14:28.053842+00	2277
61	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-61	4	1	-61	\N	C	2019-12-20 22:14:28.053842+00	2278
60	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-60	4	1	-60	\N	C	2019-12-20 22:14:28.053842+00	2279
59	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-59	4	1	-59	\N	C	2019-12-20 22:14:28.053842+00	2280
58	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-58	4	1	-58	\N	C	2019-12-20 22:14:28.053842+00	2281
57	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-57	4	1	-57	\N	C	2019-12-20 22:14:28.053842+00	2282
56	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-56	4	1	-56	\N	C	2019-12-20 22:14:28.053842+00	2283
55	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-55	4	1	-55	\N	C	2019-12-20 22:14:28.053842+00	2284
54	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-54	4	1	-54	\N	C	2019-12-20 22:14:28.053842+00	2285
53	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-53	4	1	-53	\N	C	2019-12-20 22:14:28.053842+00	2286
52	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-52	4	1	-52	\N	C	2019-12-20 22:14:28.053842+00	2287
51	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-51	4	1	-51	\N	C	2019-12-20 22:14:28.053842+00	2288
50	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-50	4	1	-50	\N	C	2019-12-20 22:14:28.053842+00	2289
49	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-49	4	1	-49	\N	C	2019-12-20 22:14:28.053842+00	2290
48	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-48	4	1	-48	\N	C	2019-12-20 22:14:28.053842+00	2291
47	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-47	4	1	-47	\N	C	2019-12-20 22:14:28.053842+00	2292
46	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-46	4	1	-46	\N	C	2019-12-20 22:14:28.053842+00	2293
45	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-45	4	1	-45	\N	C	2019-12-20 22:14:28.053842+00	2294
44	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-44	4	1	-44	\N	C	2019-12-20 22:14:28.053842+00	2295
43	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-43	4	1	-43	\N	C	2019-12-20 22:14:28.053842+00	2296
42	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-42	4	1	-42	\N	C	2019-12-20 22:14:28.053842+00	2297
41	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-41	4	1	-41	\N	C	2019-12-20 22:14:28.053842+00	2298
40	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-40	4	1	-40	\N	C	2019-12-20 22:14:28.053842+00	2299
39	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-39	4	1	-39	\N	C	2019-12-20 22:14:28.053842+00	2300
38	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-38	4	1	-38	\N	C	2019-12-20 22:14:28.053842+00	2301
37	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-37	4	1	-37	\N	C	2019-12-20 22:14:28.053842+00	2302
36	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-36	4	1	-36	\N	C	2019-12-20 22:14:28.053842+00	2303
35	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-35	4	1	-35	\N	C	2019-12-20 22:14:28.053842+00	2304
34	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-34	4	1	-34	\N	C	2019-12-20 22:14:28.053842+00	2305
33	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-33	4	1	-33	\N	C	2019-12-20 22:14:28.053842+00	2306
32	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-32	4	1	-32	\N	C	2019-12-20 22:14:28.053842+00	2307
31	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-31	4	1	-31	\N	C	2019-12-20 22:14:28.053842+00	2308
30	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-30	4	1	-30	\N	C	2019-12-20 22:14:28.053842+00	2309
29	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-29	4	1	-29	\N	C	2019-12-20 22:14:28.053842+00	2310
28	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-28	4	1	-28	\N	C	2019-12-20 22:14:28.053842+00	2311
27	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-27	4	1	-27	\N	C	2019-12-20 22:14:28.053842+00	2312
26	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-26	4	1	-26	\N	C	2019-12-20 22:14:28.053842+00	2313
25	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-25	4	1	-25	\N	C	2019-12-20 22:14:28.053842+00	2314
24	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-24	4	1	-24	\N	C	2019-12-20 22:14:28.053842+00	2315
23	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-23	4	1	-23	\N	C	2019-12-20 22:14:28.053842+00	2316
22	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-22	4	1	-22	\N	C	2019-12-20 22:14:28.053842+00	2317
21	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-21	4	1	-21	\N	C	2019-12-20 22:14:28.053842+00	2318
20	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-20	4	1	-20	\N	C	2019-12-20 22:14:28.053842+00	2319
19	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-19	4	1	-19	\N	C	2019-12-20 22:14:28.053842+00	2320
18	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-18	4	1	-18	\N	C	2019-12-20 22:14:28.053842+00	2321
17	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-17	4	1	-17	\N	C	2019-12-20 22:14:28.053842+00	2322
16	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-16	4	1	-16	\N	C	2019-12-20 22:14:28.053842+00	2323
15	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-15	4	1	-15	\N	C	2019-12-20 22:14:28.053842+00	2324
14	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-14	4	1	-14	\N	C	2019-12-20 22:14:28.053842+00	2325
13	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-13	4	1	-13	\N	C	2019-12-20 22:14:28.053842+00	2326
12	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-12	4	1	-12	\N	C	2019-12-20 22:14:28.053842+00	2327
11	This groupe is represented by a single shard of Jomon pottery withought any known relation to other shards from the same vessle.	1	\N	-11	4	1	-11	\N	C	2019-12-20 22:14:28.053842+00	2328
