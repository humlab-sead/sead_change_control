15	Disposed of	Sample has been disposed of and information on its original character is unavailable.	\N	3	1	-15	\N	C	2019-12-20 22:14:19.067462+00	17
1	Ceramic part	Describes what part of ceramic vessel/structure was sampled	\N	4	1	-1	\N	C	2019-12-20 22:14:28.053842+00	19
2	Sample position	Describes what substance and possibly more accurate information on where on the ceramic part the sample came from (e.g. charred deposit from inside the vessel)	\N	4	1	-2	\N	C	2019-12-20 22:14:28.053842+00	18
