1	Ware	Collective term for groups of ceramics, e.g. Samian, A, A1, earthenware, mortaria.	2012-10-11 12:07:08.144511+00
2	Firing atmostphere	Type and quality of kiln air during firing process, e.g. oxidation, reduction	2012-10-11 13:20:18.45334+00
3	Sampling environment	Environment in which the (majority of the) group of samples was taken, e.g. lake, woodland, arable field	2012-11-01 12:34:53.435206+00
