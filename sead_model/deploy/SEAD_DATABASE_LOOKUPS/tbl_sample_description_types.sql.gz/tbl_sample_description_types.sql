1	Decoration	Decoration, e.g. marks, painting, protrusions, texture, glaze, varnish, perforated	2012-10-11 11:49:11.282266+00
2	Vessel part	Part of the vessel represented by the sample, e.g. lid, base, neck, rim.	2012-10-11 11:52:35.974652+00
4	Surface treatment	Type of surface treatment vessel part subjected to, e.g. glaze, slip, polished, smoothed.	2012-10-11 13:29:18.371071+00
5	Linked sample	Specifies relationship between a pseudosample and its constituent samples, within a sample group. I.e. Each sample description contains the name of a sample which is contained within a pseudosample; collectively these descriptions list the entire pseudosample aggregation.	2013-04-30 06:44:38.674238+00
