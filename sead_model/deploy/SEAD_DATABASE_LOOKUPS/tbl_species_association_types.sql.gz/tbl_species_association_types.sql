22	in runs of	\N	2012-09-21 16:51:47.967181+00
23	in runs with	\N	2012-09-21 16:51:47.967181+00
24	in same habitat (subsp purpurescens)	\N	2012-09-21 16:51:47.967181+00
15	cuckoo parasite in burrows of	\N	2012-09-21 16:51:47.967181+00
16	feeds on nest debris of	\N	2012-09-21 16:51:47.967181+00
17	if coastal, in same habitat as	\N	2012-09-21 16:51:47.967181+00
18	imagines in nests of	\N	2012-09-21 16:51:47.967181+00
19	in borings of	\N	2012-09-21 16:51:47.967181+00
29	inquiline	\N	2012-09-21 16:51:47.967181+00
30	inquiline in nests of	\N	2012-09-21 16:51:47.967181+00
31	inquiline?	\N	2012-09-21 16:51:47.967181+00
33	larvae in nests of	\N	2012-09-21 16:51:47.967181+00
34	larvae parasitic on	\N	2012-09-21 16:51:47.967181+00
35	larvae predated by	\N	2012-09-21 16:51:47.967181+00
36	larvae predatory on	\N	2012-09-21 16:51:47.967181+00
39	occasional	\N	2012-09-21 16:51:47.967181+00
40	occurs in nest of	\N	2012-09-21 16:51:47.967181+00
41	often in same habitat as	\N	2012-09-21 16:51:47.967181+00
44	on burnt ground	\N	2012-09-21 16:51:47.967181+00
47	parasite of	\N	2012-09-21 16:51:47.967181+00
61	pupae parasitised by	\N	2012-09-21 16:51:47.967181+00
63	pupae probably parasitized by	\N	2012-09-21 16:51:47.967181+00
67	same host plant as	\N	2012-09-21 16:51:47.967181+00
69	semi-parasitic with	\N	2012-09-21 16:51:47.967181+00
74	Swarming	\N	2012-09-21 16:51:47.967181+00
73	subsp purpurescens in same habitat as	\N	2012-09-21 16:51:47.967181+00
75	undefined association with	\N	2012-09-21 16:51:47.967181+00
76	with	\N	2012-09-21 16:51:47.967181+00
77	synonym of	\N	2013-09-24 11:43:59.115233+00
3	parasitizes	The selected taxon is a parasite of the indicated taxon. Covers interaction within and between all forms of organism.	2014-01-17 10:45:42.870735+00
4	is parasitized by	The selected taxon is parasitized by the indicated taxon. Covers interaction within and between all forms of organism.	2014-01-17 10:45:42.870735+00
9	is scavenger in nests of	The selected taxon collects or feeds on debris in the nests of the indicated taxon.	2012-09-21 16:51:47.967181+00
53	is predated in own nests by	\N	2012-09-21 16:51:47.967181+00
6	is predator in nests of	The selected taxon hunts and/or feeds on other species in the nests of the indicated taxon.	2012-09-21 16:51:47.967181+00
54	is predator on	The selected taxon eats, or predates on, the indicated taxon. Covers both plant-animal and animal-animal interactions.	2012-09-21 16:51:47.967181+00
58	is predator on?	(Not confirmed) The selected taxon may eat, or predate on, the indicated taxon although this is not known for certain. Covers both plant-animal and animal-animal interactions.	2012-09-21 16:51:47.967181+00
59	is prey of	\N	2012-09-21 16:51:47.967181+00
10	is social parasite in nests of	\N	2012-09-21 16:51:47.967181+00
8	is predator on larvae of	The selected taxon hunts and/or feeds on the larvae of the indicated taxon.	2012-09-21 16:51:47.967181+00
57	is predator on larvae of?	(Not confirmed) The selected taxon hunts and/or feeds on the larvae of the indicated taxon.	2012-09-21 16:51:47.967181+00
11	adults found in nests of	\N	2012-09-21 16:51:47.967181+00
12	around nests of	General association of the taxon with the external habitat of nests of the indicated taxon. Potentially covers observation and/or collection of the taxon, but vaguely defined in the literature.	2012-09-21 16:51:47.967181+00
14	is commensal with?	\N	2012-09-21 16:51:47.967181+00
21	in nests of	General association of the taxon with the internal habitat of nests of the indicated taxon. Potentially covers observation and/or collection of the taxon, but not always defined in the literature.	2012-09-21 16:51:47.967181+00
20	in burrows of	General association of the taxon with the internal habitat of burrows of the indicated taxon. Potentially covers observation and/or collection of the taxon, but not always defined in the literature.	2012-09-21 16:51:47.967181+00
78	bores in	The taxon creates burrows in the indicated taxon.	2014-03-05 09:41:36.353719+00
79	pollinates	The taxon spreads the pollen of the indicated taxon.	2014-03-05 09:42:26.014618+00
80	is pollinated by	The pollen of the selected taxon is spread by the indicated taxon.	2014-03-05 09:43:52.751759+00
81	is bored by	The taxon is bored by the indicated taxon.	2014-03-05 09:45:49.947847+00
25	in same habitat as	The selected taxon is commonly found within the same habitat as the indicated taxon. Although this is a somewhat vague association it may provide important information for taxonomic revisions. The association may also help corroborate environmental reconstructions if both taxa are found.	2012-09-21 16:51:47.967181+00
64	in same habitat, but rarer than	\N	2012-09-21 16:51:47.967181+00
38	in same habitat, but more common than	\N	2012-09-21 16:51:47.967181+00
26	in same lake as	The selected taxon has been found or observed in the same lake as the indicated taxon.	2012-09-21 16:51:47.967181+00
27	in same riverine habitat as	The selected taxon has been found or observed in the same riverine habitat as the indicated taxon.	2012-09-21 16:51:47.967181+00
28	in same trees as	The selected taxon has been found or observed in the same trees as the indicated taxon.	2012-09-21 16:51:47.967181+00
32	larvae develop in nests of	\N	2012-09-21 16:51:47.967181+00
13	is associated with	General association of taxa by observation or collection, but without a well established relationship between the taxa.	2012-09-21 16:51:47.967181+00
82	on host	The selected taxon requires the indicated taxon for at least part of its lifecycle.	2014-03-05 13:09:27.712871+00
42	often together on same foodplant as	[Will be rationalised with time as insect-plant associations are entered]	2012-09-21 16:51:47.967181+00
43	often together on same hostplant as	[Will be rationalised with time as insect-plant associations are entered]	2012-09-21 16:51:47.967181+00
83	feeds on (but not parasite or predator of)	\N	2014-03-05 13:14:07.403447+00
84	is predator on adults of	\N	2014-03-05 13:14:32.264877+00
45	on same host plant as	[Will be rationalised with time as insect-plant associations are entered]	2012-09-21 16:51:47.967181+00
46	is parasite in nests of	\N	2012-09-21 16:51:47.967181+00
50	is parasitoid on	The larvae of the selected taxon develop in or on the host taxon and ineviatbly result in the latter's death. This relationship essentially represents a combination of predator and parasitic characteristics.	2014-01-17 10:45:42.870735+00
51	is predated by	The selected taxon is eaten, or predated on by the indicated taxon. Covers both plant-animal and animal-animal interactions.	2012-09-21 16:51:47.967181+00
5	is predated by?	(Not confirmed) The selected taxon may be hunted by the indicated taxon, although this has not been established for certain. Covers interaction within and between all forms of organism.	2014-01-17 10:45:42.870735+00
52	is predated by larvae of	\N	2012-09-21 16:51:47.967181+00
70	in similar habitat as	\N	2012-09-21 16:51:47.967181+00
72	is social parasite of	\N	2012-09-21 16:51:47.967181+00
48	is parasitic on pupae of	\N	2012-09-21 16:51:47.967181+00
60	is parasitic on pupae of?	\N	2012-09-21 16:51:47.967181+00
86	overwintering in burrows of	ASSOCIATION NEEDS DESCRIPTION	2014-04-17 05:56:03.101+00
85	if coastal, same habitat as	DELETE THIS - IS DUPLICATE	2014-04-17 05:56:03.101+00
89	pupae is parasitized by	ASSOCIATION NEEDS DESCRIPTION	2014-04-17 05:56:03.101+00
90	larvae is predated by	ASSOCIATION NEEDS DESCRIPTION	2014-04-17 05:56:03.101+00
91	is scavanger in nests of	ASSOCIATION NEEDS DESCRIPTION	2014-04-17 05:56:03.101+00
92	in same habitat as, often in numbers,	ASSOCIATION NEEDS DESCRIPTION	2014-04-17 05:56:03.101+00
93	often together with, and in same habitat, as	ASSOCIATION NEEDS DESCRIPTION	2014-04-17 05:56:03.101+00
94	often together on same foodplant	ASSOCIATION NEEDS DESCRIPTION	2014-04-17 05:56:03.101+00
95	often together on same host plant	ASSOCIATION NEEDS DESCRIPTION	2014-04-17 05:56:03.101+00
88	is parasite on pupae of?	DELETE THIS - IS DUPLICATE	2014-04-17 05:56:03.101+00
87	is parasite on pupae of	DELETE THIS - IS DUPLICATE	2014-04-17 05:56:03.101+00
