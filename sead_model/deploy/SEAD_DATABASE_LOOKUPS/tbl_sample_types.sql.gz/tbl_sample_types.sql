2	Kubiena subsample	Unit of sediment extracted from a kubiena box	2012-09-21 16:51:47.967181+00
3	Core subsample	Unit of sediment extracted from a core	2012-09-21 16:51:47.967181+00
4	Monolith subsample	Unit of sediment extracted from a monolithic soil/peat sample	2012-09-21 16:51:47.967181+00
7	Modern insect collection	Sample from field sampling or hunting of insects (e.g. contents of a tube)	2012-09-21 16:51:47.967181+00
8	Modern vegetation collection	Vegetation survey sample unit.	2012-09-21 16:51:47.967181+00
5	Tent trap contents	Contents of tent trap(s), any trap bulking details in notes.	2012-09-21 16:51:47.967181+00
6	Pitfall trap contents	Contents of pitfall trap(s), any trap bulking details in notes.	2012-09-21 16:51:47.967181+00
9	Unspecified	Sample type not known or documented	2012-09-21 16:51:47.967181+00
1	Bulk sample	Sample in a container such as bag, box.	2012-09-21 16:51:47.967181+00
10	Dendro cross-cut sample	Cross-cut disc used for dendrochronology analysis	2012-12-06 09:13:21.640675+00
11	Dendro cross-cut wedge sample	Cross-cut wedge shaped sample used for dendrochronolgy analysis	2012-12-06 09:14:41.266256+00
12	Dendro core sample	Wood core sample used for dendrochronolgy analysis	2012-12-06 09:15:09.178222+00
13	Field measurement	Values measured in field without physical sample (e.g. metal detector, MS-loop, fluxgate magnetometer)	2013-04-23 08:56:47.673888+00
14	Dating pseudosample	Virtual sample consisting of aggregated material from multiple samples to bulk up weight for radiocarbon dating (or other dating method)	2013-04-30 06:38:16.438182+00
