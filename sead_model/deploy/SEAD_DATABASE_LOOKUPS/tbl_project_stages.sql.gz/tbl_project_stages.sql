1	Desktop study	A pre-field map and document based study	2012-09-21 16:51:47.967181+00
2	Prospection	A field based, either non-invasive or low impact, investigation to delimit potential areas of interest.	2012-09-21 16:51:47.967181+00
3	Excavation	Site excavation, digging holes in the ground.	2012-09-21 16:51:47.967181+00
4	Preliminary investigation	A field or office (or both) based investigation with the aim of identifying potential areas of interest and evaluating the importance of an area for future studies and/or preservation.	2012-09-21 16:51:47.967181+00
