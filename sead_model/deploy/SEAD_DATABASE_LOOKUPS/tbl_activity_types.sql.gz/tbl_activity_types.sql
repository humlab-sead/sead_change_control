1	Flowering	Plant is in flower.	2012-09-21 16:51:47.967181+00
2	Breeding	Organisms are actively breeding, i.e. mating season.	2012-09-21 16:51:47.967181+00
3	Adult active	Adult organisms are active.	2012-09-21 16:51:47.967181+00
4	Larva active	Larval stages are active.	2012-09-21 16:51:47.967181+00
5	Pupating	Organism is in pupal stage.	2012-09-21 16:51:47.967181+00
6	Growing season	Organism, most commonly plant, is growing.	2012-09-21 16:51:47.967181+00
7	Shedding leaves	Deciduous plant is shedding leaves.	2012-09-21 16:51:47.967181+00
8	Hibernating	Organisim is dowmant, in hibernation.	2012-09-21 16:51:47.967181+00
9	Migrating	Organism is migrating, seasonally changing its geographical base.	2012-09-21 16:51:47.967181+00
10	Dormant	Oganism is dormant for reason other than hibernation.	2012-09-21 16:51:47.967181+00
