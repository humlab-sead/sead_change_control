1	Latitude	2012-09-21 16:51:47.967181+00	AggregateDataset samples are ordered by, in order of priority, either (1) CollectionUnits.GPSLatitude or (2) the mean of Sites.LatitudeNorth and Sites.LatitudeSouth.
2	Longitude	2012-09-21 16:51:47.967181+00	AggregateDataset samples are ordered by, in order of priority, either (1) CollectionUnits.GPSLongitude or (2) the mean of Sites.LongitudeWest and Sites.LongitudeEast.
3	Altitude	2012-09-21 16:51:47.967181+00	AggregateDataset samples are ordered by Sites.Altitude.
4	Age	2012-09-21 16:51:47.967181+00	AggregateDataset samples are ordered by SampleAges.Age, where SampleAges.SampleAgeID is from AggregateSampleAges.SampleAgeID.
5	Alphabetical by site name	2012-09-21 16:51:47.967181+00	AggregateDataset samples are ordered alphabetically by Sites.SiteName.
6	Alphabetical by collection unit name	2012-09-21 16:51:47.967181+00	AggregateDataset samples are ordered alphabetically by CollectionUnits.CollUnitName.
7	Alphabetical by collection units handle	2012-09-21 16:51:47.967181+00	AggregateDataset samples are ordered alphabetically by CollectionUnits.Handle.
8	Depth	2012-09-21 16:51:47.967181+00	By sample subsurface depth
