12	Soil chemistry/properties	Soil chemistry/property data, such as magnetic susceptibility, pH etc. Does not include ambient field measurement such as field based metal detector, MS-loop, fluxgate magnetaometer.	2012-09-21 16:51:47.967181+00
1	Insects & similar	Insect and other arthrapod taxa, allong with other remains commonly extracted when analysing insect samples.	2012-09-21 16:51:47.967181+00
2	Plants & pollen	Plants taxa and their pollen.	2012-09-21 16:51:47.967181+00
3	Non-pollen palynomorphs	(Fossil) remains often extracted in association with pollen analyses.	2012-09-21 16:51:47.967181+00
5	Diatoms	A major group of eukaryotic algae encased in a silica based cell wall.	2012-09-21 16:51:47.967181+00
4	Molluscs	Snails and shellfish, terrestrial or aquatic.	2012-09-21 16:51:47.967181+00
6	Ostracods	A class of the Crustacea, mainly microscopic aquatic organisms encased in a bivalve like shell.	2012-09-21 16:51:47.967181+00
7	Chironomids	Non-biting midges, a Diptera family commonly treated as a separate proxy in palaeoecology, where the larval head capsules are preserved in sediments.	2012-09-21 16:51:47.967181+00
8	Cladocera	Water fleas, an order of the class Brachiopoda, small aquatic crustaceans, of which Daphnia is the most commonly useful genus. 	2012-09-21 16:51:47.967181+00
9	Charcoal	Carbonised remains of organic matter, the product of incomplete burning or heating.	2012-09-21 16:51:47.967181+00
11	Subjective metadata	Subject descriptions of properties\n	2012-09-21 16:51:47.967181+00
13	Isotopes	Isotpic data of any nature	2012-09-21 16:51:47.967181+00
16	Other archaeology	More archaeology data is available through sources listed.	2012-09-21 16:51:47.967181+00
14	Animal bones	Animal bone data available, external to SEAD. Note: human osteaology has own category.	2012-09-21 16:51:47.967181+00
15	Human bones	Human osteology data available outside of SEAD.	2012-09-21 16:51:47.967181+00
17	External pollen data	Pollen data available through other sources, i.e. not stored in SEAD	2012-09-21 16:51:47.967181+00
18	External plant macro data	Plant macrofossil data available through other sources, i.e. not stored in SEAD	2012-09-21 16:51:47.967181+00
10	Non-biological taxa	Records for taxon based chemical/physical properties. Provides future support for chemical taxa not yet implemented.	2012-09-21 16:51:47.967181+00
19	Dating	General dating data, includes geochronologies and tephra dates	2014-02-06 10:11:43.394203+00
