1	Archaeological period	Culturally, typologically or otherwise defined archaeological period	2013-12-02 17:51:00+00
2	Historical period	Period defined by historical rather than archaeological records	2013-12-02 17:51:00+00
3	Blytt-Sernander	Blytt and Sernander climate zones	2013-12-02 17:51:00+00
6	Geological periods	\N	2013-12-02 17:51:00+00
8	Geological ages	\N	2013-12-02 17:51:00+00
7	Geological epochs	\N	2013-12-02 17:51:00+00
5	Pollen Zone	Temporal period as defined by pollen stratigraphy	2013-12-02 17:51:00+00
4	Oxygen Isotope Stage	Oxygen Isotope Stage, Marine isotope stages (MIS), marine oxygen-isotope stages. Periods defined by analysis of (mainly) oxygen isotopes in marine cores.	2013-12-02 17:51:00+00
9	Geological period	Subdivision of geological time period which is divided into epochs.	2014-04-17 05:56:03.101+00
10	Geological	General geological age. Either crosses established temporal type definitions, or may need correctly assigning.	2014-04-17 05:56:03.101+00
11	Other age type	Age type either undefined or questioned	2014-04-17 05:56:03.101+00
12	Calendar date	Absolute date in calendar years (single year)	2014-04-17 05:56:03.101+00
13	Calendar date range	Absolute date range in calendar years (range of years)	2014-07-04 09:24:37.417742+00
