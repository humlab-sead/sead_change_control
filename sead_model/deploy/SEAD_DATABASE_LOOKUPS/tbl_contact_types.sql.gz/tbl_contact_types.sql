1	Identified by	2012-09-21 16:51:47.967181+00	Specimens identified by contact
2	Analysed by	2012-09-21 16:51:47.967181+00	Data produced through analytical means by contact
3	Samples processed by	2012-09-21 16:51:47.967181+00	Samples processed by contact
4	Samples taked by	2012-09-21 16:51:47.967181+00	Samples taken by contact
5	Specimen repository	2012-09-21 16:51:47.967181+00	Specimens are stored at this location
6	Dataset imported by	2012-09-21 16:51:47.967181+00	Dataset uploaded to SEAD by this contact
7	Dataset originally digitised by	2012-09-21 16:51:47.967181+00	Original storage in a database by this contact
8	Specimen location	2013-07-25 07:47:53.933878+00	Specimens identified in this dataset are stored at this location
