4	2012-09-21 16:51:47.967181+00	Angular positional measurement	dd	Decimal degrees
5	2012-09-21 16:51:47.967181+00	Intrinsic units of scale system	\N	Units
6	2012-09-21 16:51:47.967181+00	1.4959787e08 kilometres	\N	Astronomical unit
1	2012-09-21 16:51:47.967181+00	Distance measure SI unit	m	metres
2	2012-09-21 16:51:47.967181+00	Weight measure SI unit	kg	kilograms
3	2012-09-21 16:51:47.967181+00	Volume measurement SI unit	l	litres
8	2012-09-21 16:51:47.967181+00	Calendar years	yrs	Years
7	2012-09-21 16:51:47.967181+00	Uncalibrated Carbon 14 years	C14yrs	14C years
9	2012-09-21 16:51:47.967181+00	Degrees Celcius	°C	Degrees Celcius
12	2012-09-21 16:51:47.967181+00	Distance measure 1/1 000 000 metres	µm	microns
10	2012-09-21 16:51:47.967181+00	Distance measure 1/1 000 metres	mm	millimetres
13	2012-09-21 16:51:47.967181+00	Weight measure 1/1 000 kilograms	g	grams
14	2012-09-21 16:51:47.967181+00	Volume measurement 1/1000 litres	ml	millilitres
15	2014-04-17 05:56:03.101+00	Undefined and uncalibrated years other than 14C years. May be result of age determination through a variety of methods and reflect years as defined within the framework of the method.	uncal yrs	undefined uncalibrated years
