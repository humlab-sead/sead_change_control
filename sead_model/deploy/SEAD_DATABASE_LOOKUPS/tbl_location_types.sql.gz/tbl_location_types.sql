10	2012-09-21 16:51:47.967181+00	Specific street address of site (e.g. 19-22 Coppergate)	Street address
5	2012-09-21 16:51:47.967181+00	Continent	Continent
4	2012-09-21 16:51:47.967181+00	Nearest or containing area of human occupation, e.g. a farm, town, city etc.	Settlement
2	2012-09-21 16:51:47.967181+00	Administrative units such as county, parish, län, socken. Country specific terms. Includes historical or non-active regions.	Sub-country administrative region
7	2012-09-21 16:51:47.967181+00	Geographical areas which are not necessarily defined as single administrative units. E.g. part of a continent: Central Europe, Southern Scandinavia; Geomorphological regions: Eastern Alps; An island: Andoya, Holmön. The terms may coincide with administrative units.	Aggregate/non-admin geographical region
9	2012-09-21 16:51:47.967181+00	Seas, lakes, rivers given as a location name.	Water body
8	2012-09-21 16:51:47.967181+00	Specific constructions, buildings or formal administrative units given as locations. E.g. The British Museum, House of Lords...	Institution
14	2012-09-21 16:51:47.967181+00	Historical administrative unit (e.g. Yugoslavia, Roman Britannia)	Historical administrative unit
16	2013-10-21 12:43:10.855392+00	Region defined by geographical extent, often reflecting environmental boundaries such as mountain ranges, deserts, valleys etc.	Geographical area
17	2013-10-21 13:32:16.322433+00	Location ascribed to an archaeological site rather than a contemporary settlement or region. May be used where the interpretation of the site is contested, and so designation is perhaps best left as archaeological.	Archaeological site
1	2012-09-21 16:51:47.967181+00	Country or other nation state. For practical purposes territories such as England and Wales are considered countries (due to common usage)	Country
18	2013-10-21 13:41:15.6662+00	Geographical area consisting entirely of a specific (smaller) landmass in a water body (lake, sea etc.). Often used to increase accuracy where an administrative region includes multiple islands.	Island
19	2013-10-22 14:48:00.502697+00	Archaeological or historical settlement, now abandoned, lost or absorbed into a more recent settlement.	Historical settlement
20	2014-04-17 05:56:03.101+00	Undetermined location type from a Bugs transfer, needs processing.	Unprocessed Bugs Transfer
