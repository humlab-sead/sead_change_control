1	Original submission from data contributor	Submission (data entry) into primary database system (not SEAD)	2012-09-21 16:51:47.967181+00
2	Resubmission or revision from data contributor	Merger of multiple datasets from primary source into a single dataset submission (not SEAD)	2012-09-21 16:51:47.967181+00
3	Compilation into a flat file database	Incorporation of dataset into any flat (single, or unrelated tables) 'database' form, including Excel or flat form structures in relational database management system	2012-09-21 16:51:47.967181+00
5	Compilation into SEAD from another database	Single dataset from another database submission into SEAD	2012-09-21 16:51:47.967181+00
6	Recompilation into SEAD from another database	Merger of multiple datasets from another database into a single dataset submission into SEAD	2012-09-21 16:51:47.967181+00
7	Compilation into SEAD from primary source	Submission (data entry) into SEAD	2012-09-21 16:51:47.967181+00
8	Recompilation into or revisions to SEAD	Merger of either multiple primary datasets, or combination of an existing dataset with external primary data, into a single dataset submission into SEAD	2012-09-21 16:51:47.967181+00
9	Recompilation or revisions to a another relational database	Multiple datasets from previous system combined into single dataset in subsequent relational database system	2012-09-21 16:51:47.967181+00
4	Compilation into another relational database	Incorporation of dataset into any relational database management system	2012-09-21 16:51:47.967181+00
10	Samples collected	Samples collected in the field (e.g. excavation, field survey) or sample prepared from source (e.g. thin section from pottery)	2012-09-21 16:51:47.967181+00
11	Samples analysed	Samples analysed	2012-09-21 16:51:47.967181+00
