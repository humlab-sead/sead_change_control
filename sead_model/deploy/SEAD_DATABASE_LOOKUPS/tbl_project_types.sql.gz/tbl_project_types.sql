4	Teaching	A project either fully or primarily orientated towards the teaching of students.	2012-09-21 16:51:47.967181+00
5	Consultancy	A project either fully or primarily funded as contract work.	2012-09-21 16:51:47.967181+00
6	Research	A project either fully or primarily orientated towards research.	2012-09-21 16:51:47.967181+00
