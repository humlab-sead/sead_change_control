2	2012-09-21 16:51:47.967181+00	Specifically plans/maps of excavated archaeological sites or sampling areas.	Site plan
3	2012-09-21 16:51:47.967181+00	Any graphical representation not covered by the other image categories.	Diagram
5	2012-09-21 16:51:47.967181+00	A graphical representation of numerical values, any form.	Graph
4	2012-09-21 16:51:47.967181+00	Schematic diagram showing process flow	Flow chart
7	2012-09-21 16:51:47.967181+00	\N	Aerial photograph
1	2012-09-21 16:51:47.967181+00	Any non-aerial photograph.	Photograph
8	2012-09-21 16:51:47.967181+00	Diagram describing details of an exposed strategraphic sequence or archaeological profile.	Stratigraphic plan
6	2012-09-21 16:51:47.967181+00	Any cartographic representation of points or data that is not a site plan. May include satelite maps.	Map
