3	Lab number	2012-09-21 16:51:47.967181+00	Sample number/name used by the lab which performed the analyses or managed the samples for analysis.
4	Other alternative sample name	2012-09-21 16:51:47.967181+00	Any other form of reference used in the sample documentation.
5	Archaeological excavation sample number	2012-09-21 16:51:47.967181+00	Sample number used on-site during archaeological excavation, and relating to excavation documentation.
6	Field number	2012-09-21 16:51:47.967181+00	Sampling number used during field survey.
1	Museum number	2012-09-21 16:51:47.967181+00	Sample number/name used by a museum. Include prefix if present.
2	Contractor sample number	2012-09-21 16:51:47.967181+00	Sample number/name used by contractor, as submitted to lab or extracted from site documentation. Include prefix if present.
7	Trap number	2012-09-21 16:51:47.967181+00	Number/name of the insect/sediment etc trap.
8	Quadrat or grid number	2012-09-21 16:51:47.967181+00	Survey grid unit number.
