1	Carbonised	Organic matter converted to carbon, most commonly though heating.	2012-09-21 16:51:47.967181+00
2	Calcified	Organic matter replaced by calcium.	2012-09-21 16:51:47.967181+00
3	Eroded	Surface of fossil has been worn away by physical processes, such as sediment abbraision.	2012-09-21 16:51:47.967181+00
4	Fragmented	Fossil is not whole.	2012-09-21 16:51:47.967181+00
5	Mineralised (unspecific)	Organic matter replaced by unspecified mineral(s).	2012-09-21 16:51:47.967181+00
6	Pyritified	Organic matter replaced by pyrite or marcasite.	2012-09-21 16:51:47.967181+00
7	Discoloured (more than expected)	Expected colour of fossil, considering preservation factors, is of an unexpected colour. E.g. as a result of dying.	2012-09-21 16:51:47.967181+00
8	Petrified	Organic matter converted to stone by impregnation with silica.	2012-09-21 16:51:47.967181+00
9	Encased in amber	Fossil is encapsulated in a piece of amber.	2012-09-21 16:51:47.967181+00
10	Corroded	Surface of fossil has been damage by chemical processes.	2012-09-21 16:51:47.967181+00
